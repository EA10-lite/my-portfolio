import type { Config } from 'tailwindcss'
const config: Config = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
        fontFamily: {
            raleway: ['Raleway', 'sans-serif'],
        },
        colors: {
            primary: "#2786C1",
            background: "#F1FAFF",
        },
    },
  },
  plugins: [
  ],
}

export default config

