import { type HTMLMotionProps, motion } from "framer-motion";
import { type ReactNode } from "react";

/**
 * PageHeading centralizes the typography used for top-level page headings so that
 * every route starts with the same visual hierarchy. The component wraps `motion.h1`
 * to keep compatibility with existing Framer Motion animations while exposing the
 * same props API. Callers can still pass animation variants, ids, and aria labels
 * through `...rest`.
 *
 * Assumptions:
 * - All primary page titles should follow the shared responsive scale defined in
 *   `BASE_CLASSES` so that marketing pages feel consistent.
 * - Consumers may occasionally need to extend the base styles (for example, to tweak
 *   margins inside a hero block). They can use the optional `className` prop, which
 *   gets appended after the defaults.
 */
type PageHeadingProps = HTMLMotionProps<"h1"> & {
    children: ReactNode;
    className?: string;
};

const BASE_CLASSES =
    "text-[32px] sm:text-[40px] md:text-[48px] lg:text-[52px] font-[500] text-black mb-4 sm:mb-6 leading-tight";

const PageHeading = ({ children, className = "", ...rest }: PageHeadingProps) => {
    const mergedClassName = className
        ? `${BASE_CLASSES} ${className}`.trim()
        : BASE_CLASSES;

    return (
        <motion.h1 className={mergedClassName} {...rest}>
            {children}
        </motion.h1>
    );
};

export default PageHeading;

