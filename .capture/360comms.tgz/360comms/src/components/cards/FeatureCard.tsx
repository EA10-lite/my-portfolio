import { motion } from "framer-motion";

type FeatureItemProps = {
    title: string;
    description: string;
    image: string;
    index?: number;
}

const FeatureCard = ({ title, description, image, index = 0 }: FeatureItemProps) => {
    // Animation variants for card entrance
    const cardVariants = {
        hidden: {
            opacity: 0,
            y: 50,
            scale: 0.9
        },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 0.5,
                delay: index * 0.1,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    return (
        <motion.div 
            className="feature-item bg-white shadow-md rounded-[15px] p-6"
            variants={cardVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            whileHover="hover"
            animate="rest"
        >
            <motion.div 
                className="w-[48px] h-[51px] rounded-[6px] flex items-center justify-center bg-primary overflow-hidden mb-2"
                whileHover={{ rotate: [0, -10, 10, -10, 0], scale: 1.1 }}
                transition={{ duration: 0.5 }}
            >
                <img src={image} className="" alt={title} />
            </motion.div>
            <motion.h2 
                className="text-lg lg:text-[24px] font-[500] text-black mb-2"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 + 0.2 }}
            >
                {title}
            </motion.h2>
            <motion.p 
                className="text-[13px] font-[400] text-black"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 + 0.3 }}
            >
                {description}
            </motion.p>
        </motion.div>
    )
}


export default FeatureCard;