import { motion } from "framer-motion";

type BlogCardProps = {
    title: string;
    description: string;
    image: string;
    date: string;
    author: string;
    link: string;
    comments: number;
    index?: number;
}

const BlogCard = ({ title, description, image, date, author, link, comments, index = 0 }: BlogCardProps) => {
    // Animation variants for blog card entrance
    const cardVariants = {
        hidden: {
            opacity: 0,
            x: -50,
            y: 20
        },
        visible: {
            opacity: 1,
            x: 0,
            y: 0,
            transition: {
                duration: 0.5,
                delay: index * 0.1,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    // Image hover animation
    const imageVariants = {
        rest: { scale: 1 },
        hover: { 
            scale: 1.05,
            transition: {
                duration: 0.3,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    return (
        <motion.div 
            className="blog-card overflow-hidden"
            variants={cardVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            whileHover={{ y: -5, transition: { duration: 0.3 } }}
        >
            <div className="blog-body">
                <div className="flex flex-col sm:flex-row gap-4 md:gap-6">
                    <motion.div 
                        className="blog-image w-full lg:w-[212px] lg:min-h-[128px] flex-shrink-0 overflow-hidden"
                        variants={imageVariants}
                        initial="rest"
                        whileHover="hover"
                    >
                        <img 
                            src={image} 
                            alt={title} 
                            className="w-full h-full lg:w-[212px] lg:min-h-[128px] object-cover" 
                        />
                    </motion.div>
                    <div className="blog-content flex-1">
                        <motion.h4 
                            className="text-base md:text-lg font-[500] text-primary mb-2 md:mb-3"
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 + 0.2 }}
                        >
                            {title}
                        </motion.h4>
                        <motion.p 
                            className="text-sm md:text-base font-[300] leading-[25px] text-black line-clamp-3"
                            initial={{ opacity: 0 }}
                            whileInView={{ opacity: 1 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 + 0.3 }}
                        >
                            {description}
                        </motion.p>
                    </div>
                </div>
            </div>

            <motion.div 
                className="blog-footer border-t border-b border-[#DFDDDD] py-2.5"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 + 0.4 }}
            >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-4">
                    <div className="flex flex-wrap items-center gap-2 text-xs md:text-sm">
                        <p className="font-[500]">
                            By <span className="text-primary">{author}</span>
                        </p>
                        <span className="text-[#DFDDDD]">|</span>
                        <p className="font-[500]">{date}</p>
                        <span className="text-[#DFDDDD]">|</span>
                        <p className="font-[500]">{comments} {comments === 1 ? 'comment' : 'comments'}</p>
                    </div>

                    <motion.a 
                        href={link} 
                        className="text-primary text-xs md:text-sm font-[500] hover:underline"
                        whileHover={{ x: 5 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        Read More
                    </motion.a>
                </div>
            </motion.div>
        </motion.div>
    )
}


export default BlogCard;