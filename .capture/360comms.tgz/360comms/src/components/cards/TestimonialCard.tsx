import { motion } from "framer-motion";
import type { TestimonialItem } from "../../data/testimonials";

type TestimonialCardProps = TestimonialItem & {
    index?: number;
}

const TestimonialCard = ({ quote, author, title, company, companyLogo, index = 0 }: TestimonialCardProps) => {
    return (
        <motion.div 
            className="testimonial-card bg-white rounded-lg p-4 sm:p-5 md:p-6 lg:p-8 min-h-0 flex flex-col shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ 
                duration: 0.5, 
                delay: index * 0.1,
                ease: [0, 0, 0.58, 1] as const
            }}
            whileHover={{ y: -5, transition: { duration: 0.3 } }}
        >
            {/* Quote */}
            <div className="flex-1 mb-4 sm:mb-5 md:mb-6 min-h-0 overflow-hidden">
                <motion.p 
                    className="text-sm sm:text-base md:text-base lg:text-lg font-[400] text-black leading-relaxed break-words"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: index * 0.1 + 0.2 }}
                >
                    "{quote}"
                </motion.p>
            </div>

            {/* Author Info */}
            <div className="flex items-center gap-3 sm:gap-4 pt-3 sm:pt-4 border-t border-[#DFDDDD] flex-shrink-0">
                <motion.div 
                    className=""
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 + 0.3 }}
                >
                    <img 
                        src={companyLogo} 
                        alt={company} 
                        className="w-full max-h-[60px] object-contain p-1.5 sm:p-2"
                    />
                </motion.div>
                <div className="flex-1 min-w-0 overflow-hidden">
                    <motion.h4 
                        className="text-xs sm:text-sm md:text-base font-[600] text-black mb-0.5 sm:mb-1 truncate"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 + 0.4 }}
                        title={author}
                    >
                        {author}
                    </motion.h4>
                    <motion.p 
                        className="text-[10px] sm:text-xs md:text-sm font-[400] text-gray-600 line-clamp-2"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 + 0.5 }}
                        title={title}
                    >
                        {title}
                    </motion.p>
                </div>
            </div>
        </motion.div>
    )
}

export default TestimonialCard;