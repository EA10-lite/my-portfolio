import { motion } from "framer-motion";
import type { SolutionItem } from "../../data/solution"

type SolutionCardProps = SolutionItem & {
    index?: number;
}

const SolutionCard = ({ title, description, image, index = 0 }: SolutionCardProps) => {
    // Animation variants for card entrance
    const cardVariants = {
        hidden: {
            opacity: 0,
            y: 50,
            scale: 0.9
        },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 0.5,
                delay: index * 0.1,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    // Image hover animation
    const imageVariants = {
        rest: { scale: 1 },
        hover: { 
            scale: 1.1,
            transition: {
                duration: 0.4,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    return (
        <motion.div 
            className="bg-white rounded-[15px] overflow-hidden shadow-[0px_6px_5px_0px_#65636340] hover:shadow-lg transition-shadow"
            variants={cardVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-50px" }}
            whileHover={{ y: -10, transition: { duration: 0.3 } }}
        >
            {/* Solution Illustration Image */}
            <motion.div 
                className="w-full h-[200px] overflow-hidden"
                variants={imageVariants}
                initial="rest"
                whileHover="hover"
            >
                <img 
                    src={image} 
                    alt={title} 
                    className="w-full h-full object-cover"
                />
            </motion.div>
            
            {/* Solution Content */}
            <div className="p-6">
                <motion.h3 
                    className="text-lg lg:text-[30px] font-[600] text-black mb-4"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 + 0.2 }}
                >
                    {title}
                </motion.h3>
                <ul className="space-y-2">
                    {description.map((item, itemIndex) => (
                        <motion.li 
                            key={itemIndex} 
                            className="text-sm lg:text-lg font-[400] text-black flex items-start"
                            initial={{ opacity: 0, x: -10 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: index * 0.1 + 0.3 + itemIndex * 0.05 }}
                        >
                            <span className="text-primary mr-2">•</span>
                            <span>{item}</span>
                        </motion.li>
                    ))}
                </ul>
            </div>
        </motion.div>
    )
}


export default SolutionCard