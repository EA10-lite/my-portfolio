import { useState, useEffect } from "react";
import { IoSearch, IoClose } from "react-icons/io5";
import { motion, AnimatePresence } from "framer-motion";

const Search = () => {
    const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
    const [searchQuery, setSearchQuery] = useState<string>("");

    // Close modal on ESC key press
    useEffect(() => {
        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === "Escape" && isSearchOpen) {
                setIsSearchOpen(false);
                setSearchQuery("");
            }
        };

        if (isSearchOpen) {
            document.addEventListener("keydown", handleEscape);
            // Prevent body scroll when modal is open
            document.body.style.overflow = "hidden";
        }

        return () => {
            document.removeEventListener("keydown", handleEscape);
            document.body.style.overflow = "unset";
        };
    }, [isSearchOpen]);

    // Animation variants
    const overlayVariants = {
        hidden: { opacity: 0 },
        visible: { 
            opacity: 1,
            transition: {
                duration: 0.3,
                ease: [0, 0, 0.58, 1] as const
            }
        },
        exit: { 
            opacity: 0,
            transition: {
                duration: 0.2,
                ease: [0.42, 0, 1, 1] as const
            }
        }
    };

    const modalVariants = {
        hidden: { 
            opacity: 0, 
            scale: 0.95,
            y: -20
        },
        visible: { 
            opacity: 1, 
            scale: 1,
            y: 0,
            transition: {
                duration: 0.3,
                ease: [0, 0, 0.58, 1] as const
            }
        },
        exit: { 
            opacity: 0, 
            scale: 0.95,
            y: -20,
            transition: {
                duration: 0.2,
                ease: [0.42, 0, 1, 1] as const
            }
        }
    };

    const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
        if (e.target === e.currentTarget) {
            setIsSearchOpen(false);
            setSearchQuery("");
        }
    };

    const handleSiteSearch = () => {
        // Handle site search logic here
        console.log("Site search:", searchQuery);
    };

    const handleAISearch = () => {
        // Handle AI search logic here
        console.log("AI search:", searchQuery);
    };

    return (
        <div className="search">
            <IoSearch 
                className="text-white cursor-pointer hover:opacity-80 transition-opacity" 
                size={20}
                onClick={() => setIsSearchOpen(true)}
            />

            <AnimatePresence>
                {isSearchOpen && (
                    <motion.div 
                        className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4"
                        variants={overlayVariants}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                        onClick={handleOverlayClick}
                    >
                        {/* Dark overlay */}
                        <motion.div 
                            className="fixed inset-0 bg-[#092A3D99] backdrop-blur-sm"
                            variants={overlayVariants}
                            initial="hidden"
                            animate="visible"
                            exit="exit"
                        />

                        {/* Search Modal */}
                        <motion.div 
                            className="relative bg-white rounded-[9px] w-full max-w-[776px] h-[64px] flex items-center gap-2 px-4 shadow-2xl"
                            variants={modalVariants}
                            initial="hidden"
                            animate="visible"
                            exit="exit"
                            onClick={(e) => e.stopPropagation()}
                        >
                            {/* Close button */}
                            <button
                                onClick={() => {
                                    setIsSearchOpen(false);
                                    setSearchQuery("");
                                }}
                                className="absolute -top-10 right-0 text-white hover:text-white/80 transition-colors"
                                aria-label="Close search"
                            >
                                <IoClose size={24} />
                            </button>

                            {/* Search Input */}
                            <input 
                                type="text" 
                                placeholder="What do you want to know"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                        handleSiteSearch();
                                    }
                                }}
                                className="flex-1 h-full outline-none text-sm md:text-base text-black placeholder:text-gray-400"
                                autoFocus
                            />

                            {/* Buttons */}
                            <div className="flex items-center gap-2">
                                <motion.button
                                    onClick={handleSiteSearch}
                                    className="px-4 md:px-6 py-2 bg-gray-100 hover:bg-gray-200 text-black text-xs md:text-sm font-[500] rounded-md transition-colors whitespace-nowrap"
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    Site Search
                                </motion.button>
                                <motion.button
                                    onClick={handleAISearch}
                                    className="px-4 md:px-6 py-2 bg-[#029FF0] hover:bg-[#0280CC] text-white text-xs md:text-sm font-[500] rounded-md transition-colors whitespace-nowrap"
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    Ask 360Comms AI
                                </motion.button>
                            </div>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}

export default Search;