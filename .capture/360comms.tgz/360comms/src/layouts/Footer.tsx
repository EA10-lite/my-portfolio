import { useState } from "react";
import { FiDownload } from "react-icons/fi";
import { motion } from "framer-motion";


const footerColumns = [
    {
        title: 'Company',
        items: [
            { label: 'About 360Comms', href: '/about' },
            { label: 'Careers', href: '/careers' },
            { label: 'Partners', href: '/partners' },
            { label: 'Awards', href: '/awards' },
            { label: 'Case Studies', href: '/case-studies' },
            { label: 'Global Sites', href: '/global-sites' },
            { label: 'Contact Us', href: '/contact' },
        ],
    },
    {
        title: 'Solutions',
        items: [
            { label: 'Enterprise', href: '/solutions/enterprise' },
            { label: 'Small Business', href: '/solutions/small-business' },
            { label: 'Contact Center', href: '/solutions/contact-center' },
            { label: 'Multi-talent PBX', href: '/solutions/multi-talent-pbx' },
            { label: 'Hotel PBX', href: '/solutions/hotel-pbx' },
            { label: 'Education', href: '/solutions/education' },
            { label: 'Healthcare', href: '/solutions/healthcare' },
            { label: 'Fintech', href: '/solutions/fintech' },
        ],
    },
    {
        title: 'Useful Links',
        items: [
            { label: 'Virtual PBX', href: '/virtual-pbx' },
            { label: 'Build Voice Apps', href: '/build-voice-apps' },
            { label: 'SIP Server', href: '/sip-server' },
            { label: 'Free Softphone', href: '/free-softphone' },
            { label: 'Call Reporting', href: '/call-reporting' },
            { label: 'Arielle Chat Plugin', href: '/arielle-chat-plugin' },
            { label: '360Comms AI', href: '/360comms-ai' },
            { label: 'SIP Trunks', href: '/sip-trunks' },
        ],
    },
    {
        title: 'Learn More',
        items: [
            { label: 'Blog', href: '/blog' },
            { label: '360Comms Academy', href: '/academy' },
            { label: 'VOIP FAQs', href: '/faqs' },
            { label: 'Configuration Guides', href: '/configuration-guides' },
            { label: 'OneWorld Alternative', href: '/oneworld-alternative' },
            { label: 'Command & Control', href: '/command-control' },
            { label: 'Security', href: '/security' },
            { label: 'Testimonials', href: '/testimonials' },
        ],
    },
]

const Footer = () => {
    // Track which footer column is expanded on mobile. Desktop view always shows all links,
    // so this state only influences the `sm` breakpoint and below.
    const [openColumnIndex, setOpenColumnIndex] = useState<number | null>(null);

    // Animation variants for footer sections
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.2
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                duration: 0.5,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    return (
        <motion.footer 
            className="w-full bg-background"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={containerVariants}
        >
            <div className="container mx-auto px-4 py-8 md:py-16">
                {/* Newsletter Section - Responsive */}
                <motion.div 
                    className="newsletter"
                    variants={itemVariants}
                >
                    <form action="">
                        <div className="flex items-stretch sm:items-center justify-center gap-1">
                            <motion.button 
                                type="submit"
                                className="bg-[#029FF0] border-[1.5px] border-[#029FF0] text-white px-4 py-2 rounded-tl-[35px] rounded-bl-[35px] text-sm sm:text-base font-[500] whitespace-nowrap"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                Subscribe <span className="hidden sm:inline">to our Newsletter</span>
                            </motion.button>
                            <motion.input 
                                type="email" 
                                placeholder="Enter your email" 
                                required
                                className="border-[1.5px] border-[#A3A1A1] bg-white px-4 py-2 rounded-tr-[35px] rounded-br-[35px] text-sm sm:text-base font-[400] grow max-w-full sm:max-w-[454px]"
                                whileFocus={{ scale: 1.02 }}
                            />
                        </div>
                    </form>
                </motion.div>

                {/* Main Footer Content - Responsive */}
                <motion.div 
                    className="border-t border-b border-[#B8C8D0] py-8 my-8 flex flex-col lg:flex-row justify-between gap-8"
                    variants={itemVariants}
                >
                    {/* Left Section - Full width on mobile, 23% on desktop */}
                    <motion.div 
                        className="left w-full lg:w-[23%] border-b lg:border-b-0 lg:border-r border-[#B8C8D0] pb-8 lg:pb-0 lg:pr-8 flex flex-col items-center lg:items-start text-center lg:text-left"
                        variants={itemVariants}
                    >
                        <motion.img 
                            src="/images/logo-alt.svg" 
                            alt="360comms" 
                            className="h-8 md:h-auto mx-auto lg:mx-0"
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5 }}
                        />

                        <div className="mt-6">
                            <h3 className="text-lg sm:text-xl md:text-[24px] font-[500] mb-2">
                                Start your 1-month 360Comms free trial
                            </h3>
                            <p className="text-xs sm:text-[13px] font-[400]">
                                Connecting, collaborating and communicating with your team and customers have never been easier. Take advantage of our free 30-day trial and discover the right solution for your
                            </p>

                            {/* Button wrapper ensures the CTA stays centered on mobile while left-aligned on larger screens */}
                            <div className="mt-4 flex w-full justify-center lg:justify-start">
                                <motion.a 
                                    href="/download"
                                    className="text-white bg-[#029FF0] inline-flex items-center justify-center gap-4 rounded-[35px] px-6 py-2.5 text-sm sm:text-base font-[500] w-full sm:w-auto"
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    <span className="sm:inline">Download</span>
                                    <FiDownload color="#fff" />
                                </motion.a>
                            </div>
                        </div>
                    </motion.div>

                    {/* Right Section - Grid responsive columns */}
                    <div className="w-full lg:w-[70%] grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-4">
                        {footerColumns.map((column, index) => (
                            <motion.div
                                key={column.title}
                                variants={itemVariants}
                                custom={index}
                            >
                                <FooterColumn
                                    {...column}
                                    index={index}
                                    isOpen={openColumnIndex === index}
                                    onToggle={(selectedIndex) =>
                                        setOpenColumnIndex((prev) =>
                                            prev === selectedIndex ? null : selectedIndex
                                        )
                                    }
                                />
                            </motion.div>
                        ))}
                    </div>
                </motion.div>

                {/* Bottom Links - Responsive */}
                <motion.div 
                    className="flex flex-col sm:flex-row items-center sm:items-center justify-center sm:justify-between gap-4 sm:gap-12 text-center sm:text-left"
                    variants={itemVariants}
                >
                    <p className="text-[#797979] text-sm sm:text-base font-[500]">
                        2025 &copy; 360Comms Network. All rights reserved
                    </p>
                    <div className="flex gap-6 sm:gap-12 justify-center sm:justify-start">
                        <motion.p 
                            className="text-[#797979] text-sm sm:text-base font-[500] cursor-pointer hover:text-primary transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            Sitemap
                        </motion.p>
                        <motion.p 
                            className="text-[#797979] text-sm sm:text-base font-[500] cursor-pointer hover:text-primary transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            Privacy
                        </motion.p>
                    </div>
                </motion.div>
            </div>
        </motion.footer>
    )
}



type FooterColumnProps = {
    title: string;
    items: {
        label: string;
        href: string;
    }[];
    index: number;
    isOpen: boolean;
    onToggle: (index: number) => void;
}

const FooterColumn = ({ title, items, index, isOpen, onToggle }: FooterColumnProps) => {
    // Each column exposes a unique ID so the disclosure button can refer to the
    // list for accessibility. The parent index is stable because the array of
    // footer columns is static.
    const listId = `footer-column-${index}`;

    return (
        <div className="col-span-1 flex flex-col items-center sm:items-start text-center sm:text-left w-full">
            <motion.button 
                type="button"
                aria-expanded={isOpen}
                aria-controls={listId}
                className="w-full sm:w-auto text-sm sm:text-[16px] font-[500] leading-[24px] mb-2 sm:mb-0 flex items-center justify-center gap-2 sm:block sm:text-left sm:cursor-default"
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3 }}
                onClick={() => onToggle(index)}
            >
                <span>{title}</span>
            </motion.button>
            {/*
                The list collapses on mobile (`hidden`) until its column is toggled
                open. From the `sm` breakpoint upward we force it to stay visible by
                re-applying `flex`, ensuring desktop users always see every link.
            */}
            <ul
                id={listId}
                className={`mt-2 sm:mt-4 space-y-2 ${isOpen ? 'flex' : 'hidden'} sm:flex flex-col items-center sm:items-start w-full`}
            >
                {items.map((item, itemIndex) => (
                    <motion.li 
                        key={item.label}
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.3, delay: itemIndex * 0.05 }}
                    >
                        <motion.a 
                            href={item.href} 
                            className="text-xs sm:text-sm font-[400] hover:text-primary transition-colors"
                            whileHover={{ x: 5 }}
                        >
                            {item.label}
                        </motion.a>
                    </motion.li>
                ))}
            </ul>
        </div>
    )
}

export default Footer