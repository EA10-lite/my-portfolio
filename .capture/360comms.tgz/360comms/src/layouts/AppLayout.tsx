import Footer from "./Footer";
import { Outlet, useLocation } from "react-router-dom";
import Navbar from "./Navbar";
import { motion } from "framer-motion";

// Page transition variants for smooth page changes
const pageVariants = {
    initial: {
        opacity: 0,
        y: 20
    },
    animate: {
        opacity: 1,
        y: 0,
        transition: {
            duration: 0.4,
            ease: [0, 0, 0.58, 1] as const
        }
    },
    exit: {
        opacity: 0,
        y: -20,
        transition: {
            duration: 0.3,
            ease: [0.42, 0, 1, 1] as const
        }
    }
};

const AppLayout = () => {
    const location = useLocation();
    
    return (
        <div className="min-h-screen w-full">
            <Navbar />
            <motion.div 
                className="min-h-screen w-full"
                key={location.pathname}
                initial="initial"
                animate="animate"
                exit="exit"
                variants={pageVariants}
            >
                <Outlet />
            </motion.div>
            <Footer />
        </div>
    )
}

export default AppLayout