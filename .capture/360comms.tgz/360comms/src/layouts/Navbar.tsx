import { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { FiDownload } from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";
import { Search } from "../components";



const menuItems = [
    {
        label: 'Home',
        href: '/',
    },
    {
        label: 'Features',
        href: '/features',
    },
    {
        label: 'Solutions',
        href: '/solutions',
    },
    {
        label: 'Help Center',
        href: '/help-center',
    },
    {
        label: 'Blog',
        href: '/blog',
    },
]

const Navbar = () => {
    const { pathname } = useLocation();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    // Toggle mobile menu visibility
    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
    };

    // Close mobile menu when a link is clicked
    const handleLinkClick = () => {
        setIsMobileMenuOpen(false);
    };

    // Animation variants for menu items
    const menuItemVariants = {
        hidden: { opacity: 0, y: -10 },
        visible: (i: number) => ({
            opacity: 1,
            y: 0,
            transition: {
                delay: i * 0.1,
                duration: 0.3
            }
        })
    };

    // Mobile menu animation variants
    const mobileMenuVariants = {
        hidden: {
            opacity: 0,
            height: 0,
            transition: {
                duration: 0.3,
                ease: [0.42, 0, 0.58, 1] as const
            }
        },
        visible: {
            opacity: 1,
            height: "auto",
            transition: {
                duration: 0.3,
                ease: [0.42, 0, 0.58, 1] as const,
                staggerChildren: 0.1,
                delayChildren: 0.1
            }
        }
    };

    return (
        <motion.nav 
            className="w-full bg-primary sticky top-0 z-50"
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            transition={{ duration: 0.5, ease: [0, 0, 0.58, 1] }}
        >
            <div className="container mx-auto px-4 py-4">
                <div className="flex items-center justify-between">
                    {/* Logo */}
                    <motion.div 
                        className="logo"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                    >
                        <Link to="/">
                            <img src="/images/logo.svg" alt="360comms" className="h-8 md:h-auto" />
                        </Link>
                    </motion.div>

                    {/* Desktop Menu - Hidden on mobile */}
                    <div className="menu hidden md:block">
                        <ul className="flex items-center gap-8">
                            {menuItems.map((item, index) => (
                                <motion.li
                                    key={item.href}
                                    custom={index}
                                    initial="hidden"
                                    animate="visible"
                                    variants={menuItemVariants}
                                >
                                    <MenuItem 
                                        {...item} 
                                        isActive={pathname === item.href} 
                                    />
                                </motion.li>
                            ))}
                        </ul>
                    </div>

                    {/* Desktop Actions - Hidden on mobile */}
                    <motion.div 
                        className="actions hidden md:flex items-center gap-4"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: 0.3 }}
                    >
                        <Search />
                        <motion.div
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                        >
                            <Link 
                                to="/download"
                                className="text-black bg-[#EDEBF9] inline-flex items-center gap-4 rounded-[35px] px-6 py-2.5 text-base font-[500]"
                            >
                                <span className="sm:inline">Download</span>
                                <FiDownload color="#666666" />
                            </Link>
                        </motion.div>
                    </motion.div>

                    {/* Mobile Menu Button - Visible only on mobile */}
                    <motion.button
                        onClick={toggleMobileMenu}
                        className="md:hidden text-white p-2 focus:outline-none"
                        aria-label="Toggle mobile menu"
                        whileTap={{ scale: 0.9 }}
                    >
                        {/* Hamburger Icon */}
                        <svg
                            className="w-6 h-6"
                            fill="none"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="2"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            {isMobileMenuOpen ? (
                                <path d="M6 18L18 6M6 6l12 12" />
                            ) : (
                                <path d="M4 6h16M4 12h16M4 18h16" />
                            )}
                        </svg>
                    </motion.button>
                </div>

                {/* Mobile Menu - Visible when isMobileMenuOpen is true */}
                <AnimatePresence>
                    {isMobileMenuOpen && (
                        <motion.div 
                            className="md:hidden mt-4 pb-4 border-t border-white/20 overflow-hidden"
                            variants={mobileMenuVariants}
                            initial="hidden"
                            animate="visible"
                            exit="hidden"
                        >
                            <ul className="flex flex-col gap-4 pt-4">
                                {menuItems.map((item, index) => (
                                    <motion.li
                                        key={item.href}
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ delay: index * 0.1 }}
                                    >
                                        <MenuItem 
                                            {...item} 
                                            isActive={pathname === item.href}
                                            onClick={handleLinkClick}
                                        />
                                    </motion.li>
                                ))}
                            </ul>



                            <motion.div 
                                className="mt-4"
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: menuItems.length * 0.1 }}
                            >
                                <Link 
                                    to="/download"
                                    onClick={handleLinkClick}
                                    className="text-black bg-white inline-flex items-center justify-center gap-4 rounded-[35px] px-6 py-2.5 text-base font-[500] w-full"
                                >
                                    <span className="sm:inline">Download</span>
                                    <FiDownload color="#666666" />
                                </Link>
                            </motion.div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </motion.nav>
    )
}


type MenuItemProps = {
    label: string;
    href: string;
    isActive: boolean;
    onClick?: () => void;
}

const MenuItem = ({ label, href, isActive, onClick }: MenuItemProps) => {
    return (
        <motion.div
            className={`text-base font-[500] uppercase text-white ${
                isActive ? "border-b-2 border-[#00F6FF]" : ""
            } ${onClick ? "py-2" : ""}`}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
        >
            <Link to={href} onClick={onClick}>{label}</Link>
        </motion.div>
    )
}

export default Navbar