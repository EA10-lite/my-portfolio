import { useState, useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import { solutionItems } from '../../data/solution'
import { differentiatorItems } from '../../data/differentiators'
import { testimonialItems } from '../../data/testimonials'
import { FeatureCard, SolutionCard, TestimonialCard } from '../../components';
import { IoIosArrowForward } from "react-icons/io";
import { Link } from 'react-router-dom'


// Hero carousel images configuration
const heroImages = [
    {
        link: "/",
        image: '/images/hero-bg-1.png',
    },
    {
        url: "/",
        image: '/images/hero-bg-2.png',
    },
    {
        url: "/download",
        image: '/images/hero-bg-3.png',
    },
];

const companies = [
    {
        url: "Logo-1",
        logo: "/images/logos/logo-1.svg",
    },
    {
        url: "Logo-2",
        logo: "/images/logos/logo-2.svg",
    },
    {
        url: "Logo-3",
        logo: "/images/logos/logo-3.svg",
    },
    {
        url: "Logo-4",
        logo: "/images/logos/logo-4.svg",
    },
    {
        url: "Logo-5",
        logo: "/images/logos/logo-5.svg",
    },
    {
        url: "Logo-6",
        logo: "/images/logos/logo-6.svg",
    },
    {
        url: "Logo-7",
        logo: "/images/logos/logo-7.svg",
    },
    {
        url: "Logo-8",
        logo: "/images/logos/logo-8.svg",
    },
    {
        url: "Logo-9",
        logo: "/images/logos/logo-9.svg",
    },
]

const heroContentItems = [
    {
        title: 'Trusted by 100k+',
        description: '360Comms powers communications for leading brands OneWorld, Loveworld Inc, NCC, and Nigeria Government. Join over 100,000 businesses globally that rely on us to stay connected, productive, and in control.',
        image: '/icons/flexible.svg',
    },
    {
        title: 'Scalable Communication',
        description: 'From the get-go, 360Comms has grown from a PBX system into a full communications platform. Our solutions simplify calling, video, live chat, conferencing and letting you message communications on your terms.',
        image: '/icons/scalable.svg',
    },
    {
        title: 'Flexible & Affordable',
        description: '360Comms offers a secure, private solution with no data uploads to third parties. With flexible on-premise and cloud options, free, pay-as-you-go, and it`s an affordable choice that grows with you.',
        image: '/icons/flexible.svg',
    },
    {
        title: 'Global Network',
        description: 'With a global reach and a network of 2,000,000 partners across 350 countries, 360Comms is always close by. Our partner program ensures expert support and local knowledge wherever you are.',
        image: '/icons/network.svg',
    },
]

const Home = () => {
    const [currentSlide, setCurrentSlide] = useState(1) // Start at 1 because 0 is a clone
    const [isPaused, setIsPaused] = useState(false)
    const [isDragging, setIsDragging] = useState(false)
    const [dragOffset, setDragOffset] = useState(0)
    const [isTransitioning, setIsTransitioning] = useState(false)
    const carouselRef = useRef<HTMLDivElement>(null)
    const dragStartRef = useRef(0)

    // Create infinite scroll array: [last, ...original, first]
    const infiniteImages = [heroImages[heroImages.length - 1], ...heroImages, heroImages[0]]
    const totalSlides = infiniteImages.length

    // Handle infinite scroll jump - seamless loop
    useEffect(() => {
        if (isTransitioning) return;

        if (currentSlide === 0) {
            // At cloned last slide, jump to real last slide without animation
            const timer = setTimeout(() => {
                setIsTransitioning(true);
                setCurrentSlide(heroImages.length);
                requestAnimationFrame(() => {
                    setTimeout(() => setIsTransitioning(false), 0);
                });
            }, 500); // Wait for transition to complete
            return () => clearTimeout(timer);
        } else if (currentSlide === totalSlides - 1) {
            // At cloned first slide, jump to real first slide without animation
            const timer = setTimeout(() => {
                setIsTransitioning(true);
                setCurrentSlide(1);
                requestAnimationFrame(() => {
                    setTimeout(() => setIsTransitioning(false), 0);
                });
            }, 500); // Wait for transition to complete
            return () => clearTimeout(timer);
        }
    }, [currentSlide, totalSlides, isTransitioning])

    // Auto-play carousel functionality
    useEffect(() => {
        if (isPaused || isDragging || isTransitioning) return

        const interval = setInterval(() => {
            setCurrentSlide((prev) => {
                const next = prev + 1
                if (next >= totalSlides - 1) {
                    // Will trigger jump to real first slide via useEffect
                    return totalSlides - 1
                }
                return next
            })
        }, 5000) // Change slide every 5 seconds

        return () => clearInterval(interval)
    }, [isPaused, isDragging, isTransitioning, totalSlides])

    // Navigate to specific slide
    const goToSlide = (index: number) => {
        setCurrentSlide(index + 1) // +1 because we have a clone at the beginning
    }

    // Navigate to next slide
    const nextSlide = () => {
        setCurrentSlide((prev) => {
            const next = prev + 1
            if (next >= totalSlides - 1) {
                // Will trigger jump to real first slide
                return totalSlides - 1
            }
            return next
        })
    }

    // Navigate to previous slide
    const prevSlide = () => {
        setCurrentSlide((prev) => {
            const next = prev - 1
            if (next <= 0) {
                // Will trigger jump to real last slide
                return 0
            }
            return next
        })
    }

    // Get the X coordinate from mouse or touch event
    const getX = (e: MouseEvent | TouchEvent): number => {
        if ('touches' in e) {
            return e.touches[0].clientX
        }
        return e.clientX
    }

    // Handle drag start (mouse or touch)
    const handleDragStart = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
        setIsDragging(true)
        setIsPaused(true)
        const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX
        dragStartRef.current = clientX
        setDragOffset(0)
    }

    // Handle drag move (mouse or touch)
    const handleDragMove = useCallback((e: MouseEvent | TouchEvent, startX: number) => {
        const clientX = getX(e)
        const container = carouselRef.current
        if (!container) return

        const containerWidth = container.offsetWidth
        const deltaX = clientX - startX
        const offset = (deltaX / containerWidth) * 100

        // Limit drag offset to prevent over-dragging
        const maxOffset = 100
        const clampedOffset = Math.max(-maxOffset, Math.min(maxOffset, offset))
        setDragOffset(clampedOffset)
    }, [])

    // Handle drag end (mouse or touch)
    const handleDragEnd = useCallback(() => {
        const container = carouselRef.current
        if (!container) return

        setDragOffset((currentOffset) => {
            const containerWidth = container.offsetWidth
            const threshold = containerWidth * 0.3 // 30% of container width to trigger slide change
            const dragDistance = (currentOffset / 100) * containerWidth

            setCurrentSlide((prevSlide) => {
                let newSlide = prevSlide

                if (Math.abs(dragDistance) > threshold) {
                    if (dragDistance > 0) {
                        // Dragged right - go to previous slide
                        newSlide = prevSlide - 1
                        if (newSlide < 0) newSlide = 0 // Will trigger jump
                    } else {
                        // Dragged left - go to next slide
                        newSlide = prevSlide + 1
                        if (newSlide >= totalSlides) newSlide = totalSlides - 1 // Will trigger jump
                    }
                }

                return newSlide
            })

            return 0
        })
        setIsDragging(false)
        setIsPaused(false)
    }, [])

    // Mouse event handlers
    useEffect(() => {
        if (!isDragging) return

        const handleMouseMove = (e: MouseEvent) => {
            handleDragMove(e, dragStartRef.current)
        }
        const handleMouseUp = () => handleDragEnd()

        document.addEventListener('mousemove', handleMouseMove)
        document.addEventListener('mouseup', handleMouseUp)

        return () => {
            document.removeEventListener('mousemove', handleMouseMove)
            document.removeEventListener('mouseup', handleMouseUp)
        }
    }, [isDragging, handleDragMove, handleDragEnd])

    // Touch event handlers
    const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
        e.preventDefault() // Prevent scrolling while dragging
        handleDragMove(e.nativeEvent, dragStartRef.current)
    }

    const handleTouchEnd = () => {
        handleDragEnd()
    }

    return (
        <div className="h-full w-full">
            <div 
                ref={carouselRef}
                className="hero-slider-images relative overflow-hidden cursor-grab active:cursor-grabbing select-none bg-primary"
                onMouseEnter={() => !isDragging && setIsPaused(true)}
                onMouseLeave={() => {
                    if (!isDragging) {
                        setIsPaused(false)
                    }
                }}
                onMouseDown={handleDragStart}
                onTouchStart={handleDragStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
            >
                {/* Carousel Images Container */}
                <div 
                    className="flex"
                    style={{ 
                        transform: `translateX(calc(-${currentSlide * 100}% + ${dragOffset}%))`,
                        transition: isDragging || isTransitioning ? 'none' : 'transform 0.5s ease-in-out'
                    }}
                >
                    {infiniteImages.map((item, index) => (
                        <motion.div 
                            key={`${item.image}-${index}`}
                            className="min-w-full h-full"
                            initial={{ opacity: 0 }}
                            animate={{ 
                                opacity: index === currentSlide ? 1 : 0.7,
                                scale: index === currentSlide ? 1 : 0.95
                            }}
                            transition={{ duration: 0.5 }}
                        >
                            <a href={item.link} className='w-full h-full'>
                                <img 
                                    src={item.image} 
                                    alt={`hero-slider-${index}`} 
                                    className="w-full h-auto object-cover loading-lazy"
                                />
                            </a>
                        </motion.div>
                    ))}
                </div>

                {/* Navigation Arrows */}
                {/* Hide manual arrows on small screens; auto-play handles navigation on touch devices */}
                <motion.button
                    onClick={prevSlide}
                    className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-2 rounded-full shadow-lg transition-all duration-200 z-10"
                    aria-label="Previous slide"
                    whileHover={{ scale: 1.1, backgroundColor: "rgba(255, 255, 255, 1)" }}
                    whileTap={{ scale: 0.9 }}
                >
                    <svg 
                        className="w-6 h-6" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                    >
                        <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M15 19l-7-7 7-7" 
                        />
                    </svg>
                </motion.button>
                <motion.button
                    onClick={nextSlide}
                    className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-gray-800 p-2 rounded-full shadow-lg transition-all duration-200 z-10"
                    aria-label="Next slide"
                    whileHover={{ scale: 1.1, backgroundColor: "rgba(255, 255, 255, 1)" }}
                    whileTap={{ scale: 0.9 }}
                >
                    <svg 
                        className="w-6 h-6" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                    >
                        <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M9 5l7 7-7 7" 
                        />
                    </svg>
                </motion.button>

                {/* Slide Indicators */}
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
                    {heroImages.map((_, index) => {
                        // Map to actual slide index (currentSlide - 1 because we start at index 1)
                        const actualIndex = currentSlide === 0 ? heroImages.length - 1 : 
                                          currentSlide === totalSlides - 1 ? 0 : 
                                          currentSlide - 1
                        const isActive = index === actualIndex
                        
                        return (
                            <motion.button
                                key={index}
                                onClick={() => goToSlide(index)}
                                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                                    isActive
                                        ? 'bg-white w-8' 
                                        : 'bg-white/50 hover:bg-white/75'
                                }`}
                                aria-label={`Go to slide ${index + 1}`}
                                whileHover={{ scale: 1.2 }}
                                whileTap={{ scale: 0.9 }}
                                animate={{
                                    width: isActive ? 32 : 10,
                                    opacity: isActive ? 1 : 0.5
                                }}
                                transition={{ duration: 0.3 }}
                            />
                        )
                    })}
                </div>
            </div>

            <motion.div 
                className="hero-content bg-primary"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
            >
                <div className="container mx-auto px-4 py-12">
                    <motion.h2 
                        className="text-lg lg:text-[28px] font-[500] text-white mb-8"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                    >
                        360Comms - Take Control of your Voice Communications
                    </motion.h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
                        {heroContentItems.map((item, index) => (
                            <HeroContentItem key={index} {...item} index={index} />
                        ))}
                    </div>
                </div>
            </motion.div>

            <section className="solutions-section">
                <motion.div 
                    className="hero-content bg-white"
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.6 }}
                >
                    <div className="container mx-auto px-4 py-12 lg:py-16">
                        <div className="grid grid-cols-1 lg:grid-cols-2 items-center">
                            {/* Left Side - Text Content */}
                            <motion.div
                                initial={{ opacity: 0, x: -50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.6 }}
                            >
                                <h2 className="text-xl md:text-[28px] lg:text-[40px] font-bold text-black mb-6">
                                    Unified Communications Systems
                                </h2>
                                <ul className="space-y-4">
                                    {[
                                        "Integrated voice, video, messaging, and conferencing tools",
                                        "Cross-platform (web, mobile, embedded, and IoT-capable)",
                                        "Designed for multilingual, low-bandwidth environments"
                                    ].map((text, index) => (
                                        <motion.li 
                                            key={index}
                                            className="text-[16px] md:text-[18px] lg:text-[30px] font-[400] text-black flex items-start"
                                            initial={{ opacity: 0, x: -20 }}
                                            whileInView={{ opacity: 1, x: 0 }}
                                            viewport={{ once: true }}
                                            transition={{ duration: 0.4, delay: index * 0.1 }}
                                        >
                                            <span className="text-primary mr-3 mt-2">•</span>
                                            <span>{text}</span>
                                        </motion.li>
                                    ))}
                                </ul>

                                <Link 
                                    to="/solutions"
                                    className='text-sm font-[400] flex items-center gap-2 ml-4 mt-4'
                                >
                                    <span className='border-b-[1.5px] border-primary pb-[1.5px]'>See more solutions</span>
                                    <IoIosArrowForward />
                                </Link>
                            </motion.div>

                            {/* Right Side - Visual Content */}
                            <motion.div 
                                className="relative"
                                initial={{ opacity: 0, x: 50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.6, delay: 0.2 }}
                            >
                                <motion.img 
                                    src="/images/sol.png" 
                                    alt="Unified Communications Systems - Laptop, Desk Phone, and Smartphone" 
                                    className="w-full h-auto object-contain"
                                    whileHover={{ scale: 1.05 }}
                                    transition={{ duration: 0.3 }}
                                />
                            </motion.div>
                        </div>
                    </div>
                </motion.div>
                <div className="solutions-content">
                    <div className="container mx-auto px-4 py-6 lg:py-12">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {solutionItems?.slice(0, 3).map((item, index) => (
                                <SolutionCard key={index} {...item} index={index} />
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            <section className="target-section">
                <motion.div 
                    className="bg-background"
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.6 }}
                >
                    <div className="container mx-auto px-4 py-12">
                        <motion.h2 
                            className="text-xl md:text-[28px] lg:text-[40px] font-bold text-black mb-6"
                            initial={{ opacity: 0, y: -20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5 }}
                        >
                            Target Sectors
                        </motion.h2>
                        <motion.div 
                            className=''
                            initial={{ opacity: 0, scale: 0.9 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                        >
                            <img 
                                src="/images/target.png" 
                                alt="Target Sectors" 
                                className="w-full h-full object-cover" 
                            />
                        </motion.div>
                    </div>

                </motion.div>
            </section>

            <section className="features-section">
                <motion.div 
                    className='container mx-auto px-4 py-12'
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.6 }}
                >
                    <motion.h2 
                        className="text-xl md:text-[28px] lg:text-[40px] font-bold text-black mb-6"
                        initial={{ opacity: 0, y: -20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5 }}
                    >
                        Core Differentiators
                    </motion.h2>
                    <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'>
                        {differentiatorItems.map((item, index) => {
                            const isLastItem = index === differentiatorItems.length - 1;
                            const hasRemainderLg = differentiatorItems.length % 3 !== 0;
                            
                            // Center the last item in the 3-column grid if there's a remainder
                            const centerClass = isLastItem && hasRemainderLg ? 'lg:col-start-2' : '';
                            
                            return (
                                <div 
                                    key={index}
                                    className={centerClass || undefined}
                                >
                                    <FeatureCard {...item} index={index} />
                                </div>
                            );
                        })}
                    </div>
                </motion.div>
            </section>

            <section className="testimonials-section">
                <motion.div 
                    className='bg-primary'
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.6 }}
                >
                    <div className='container mx-auto px-4 py-12 lg:py-16'>
                        {/* Header Section */}
                        <motion.div 
                            className='flex flex-col lg:flex-row lg:gap-24 justify-between items-start lg:items-center pb-10 mb-10 border-b border-white/20'
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5 }}
                        >
                            <div className="mb-6 lg:mb-0">
                                <h2 className='text-white text-xl md:text-[28px] lg:text-[40px] font-[500] mb-4 lg:mb-6'>
                                    Trusted by <b>100K+</b><br />Companies
                                </h2>
                                <motion.a 
                                    href='#' 
                                    className='text-white text-sm md:text-base font-[400] flex items-center gap-2 border-b border-[#029FF0] pb-1.5 w-fit hover:opacity-80 transition-opacity'
                                    whileHover={{ x: 5 }}
                                >
                                    <span>See more</span>
                                    <IoIosArrowForward className='text-white' />
                                </motion.a>
                            </div>

                            {/* Company Logos */}
                            <motion.div 
                                className='w-full lg:w-[50%] grid grid-cols-5 justify-end gap-4 md:gap-6'
                                initial={{ opacity: 0, x: 50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.6, delay: 0.2 }}
                            >
                                {companies?.slice(0,5)?.map((company, index) => (
                                    <motion.a 
                                        href={""} 
                                        key={index}
                                        className={`opacity-70 hover:opacity-100 transition-opacity grid-${index}`}
                                        initial={{ opacity: 0, scale: 0.8 }}
                                        whileInView={{ opacity: 1, scale: 1 }}
                                        viewport={{ once: true }}
                                        transition={{ duration: 0.3, delay: index * 0.05 }}
                                        whileHover={{ scale: 1.1 }}
                                    >
                                        <img 
                                            src={company.logo} 
                                            alt={company.url} 
                                            className='w-auto h-[50px] lg:h-[100px]' 
                                        />
                                    </motion.a>
                                ))}
                                {companies?.slice(5,10)?.map((company, index) => (
                                    <motion.a 
                                        href={""} 
                                        key={index}
                                        className={`opacity-70 hover:opacity-100 transition-opacity grid-${index}`}
                                        initial={{ opacity: 0, scale: 0.8 }}
                                        whileInView={{ opacity: 1, scale: 1 }}
                                        viewport={{ once: true }}
                                        transition={{ duration: 0.3, delay: index * 0.05 }}
                                        whileHover={{ scale: 1.1 }}
                                    >
                                        <img 
                                            src={company.logo} 
                                            alt={company.url} 
                                            className='w-auto h-[50px] lg:h-[100px]' 
                                        />
                                    </motion.a>
                                ))}
                            </motion.div>
                        </motion.div>

                        {/* Testimonials Grid - simplified for two testimonials while keeping responsive stacking */}
                        <motion.div
                            className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-24"
                            initial={{ opacity: 0, y: 30 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.6 }}
                        >
                            {testimonialItems.map((testimonial, index) => (
                                <motion.div
                                    key={testimonial.id}
                                    className="h-full"
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ duration: 0.4, delay: index * 0.1 }}
                                >
                                    {/* Using the existing card to maintain visual consistency across the site */}
                                    <TestimonialCard {...testimonial} index={index} />
                                </motion.div>
                            ))}
                        </motion.div>
                    </div>
                </motion.div>
            </section>
        </div>
    )
}

type HeroContentItemProps = {
    title: string;
    description: string;
    image: string;
    index?: number;
}

const HeroContentItem = ({ title, description, image, index = 0 }: HeroContentItemProps) => {
    return (
        <motion.div 
            className="hero-content-item"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ y: -5, transition: { duration: 0.3 } }}
        >
            <div className="content">
                <div className="flex items-center gap-[10px]">
                    <motion.div 
                        className="icon w-[30px] h-[30px]"
                        whileHover={{ rotate: 360, scale: 1.2 }}
                        transition={{ duration: 0.5 }}
                    >
                        {image && <img src={image} alt={title} className="w-[30px]" />}
                    </motion.div>
                    <h3 className="text-base font-[700] mb-2 text-white">{title}</h3>
                </div>
                <p className="text-sm font-[500] text-white ml-[40px]">{description}</p>
            </div>
        </motion.div>
    )
}
export default Home