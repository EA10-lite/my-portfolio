export { default as Home } from './home'
export { default as Solutions } from './solutions'
export { default as HelpCenter } from './help-center'
export { default as Features } from './features'
export { default as Download } from './download'
export { default as Blog } from './blog'
export { default as Search } from "./search";
export { default as AiChat } from "./ai-chat";