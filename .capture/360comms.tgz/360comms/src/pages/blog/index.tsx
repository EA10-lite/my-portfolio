import { motion } from 'framer-motion';
import { BlogCard } from '../../components';
import { blogItems, blogCategories, latestTechArticles, adminGetStartedLinks } from '../../data/blog';

const Blog = () => {
    // Sidebar panel animation variants
    const sidebarVariants = {
        hidden: { opacity: 0, x: 50 },
        visible: {
            opacity: 1,
            x: 0,
            transition: {
                duration: 0.5,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    const panelVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: (i: number) => ({
            opacity: 1,
            y: 0,
            transition: {
                duration: 0.4,
                delay: i * 0.1,
                ease: [0, 0, 0.58, 1] as const
            }
        })
    };

    const panelItemVariants = {
        hidden: { opacity: 0, x: -10 },
        visible: (i: number) => ({
            opacity: 1,
            x: 0,
            transition: {
                duration: 0.3,
                delay: i * 0.05,
                ease: [0, 0, 0.58, 1] as const
            }
        })
    };

    return (
        <div className="w-full h-full mb-[120px]">
            <motion.div 
                className="hero-image"
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
            >
                <img 
                    src="/images/blog-bg.png" 
                    alt="Blog" 
                    className="w-full h-auto object-cover loading-lazy" 
                />
            </motion.div>

            <div className="blog-content">
                <div className="container mx-auto px-4 py-6 lg:py-12">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 xl:gap-24">
                        {/* Left Side - Blog Posts */}
                        <div className="lg:col-span-8 xl:col-span-9">
                            <motion.div 
                                className="space-y-6"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.6 }}
                            >
                                {blogItems.map((blog, index) => (
                                    <BlogCard key={index} {...blog} index={index} />
                                ))}
                            </motion.div>
                        </div>

                        {/* Right Side - Sidebar Panels */}
                        <motion.aside 
                            className="lg:col-span-4 xl:col-span-3 space-y-6 lg:space-y-8"
                            variants={sidebarVariants}
                            initial="hidden"
                            whileInView="visible"
                            viewport={{ once: true, margin: "-50px" }}
                        >
                            {/* Blog Categories Panel */}
                            <motion.div 
                                className='blog-categories'
                                custom={0}
                                variants={panelVariants}
                                initial="hidden"
                                whileInView="visible"
                                viewport={{ once: true }}
                            >
                                <h3 className='text-base md:text-lg font-[500] text-black border-b-[2px] border-primary mb-4 pb-2'>
                                    Blog Categories
                                </h3>
                                <div className="space-y-0">
                                    {blogCategories.map((category, index) => (
                                        <motion.div 
                                            key={index} 
                                            className='blog-category'
                                            custom={index}
                                            variants={panelItemVariants}
                                            initial="hidden"
                                            whileInView="visible"
                                            viewport={{ once: true }}
                                        >
                                            <motion.a 
                                                href={`/blog?category=${category}`} 
                                                className='w-full block text-sm md:text-base font-[400] text-primary border-b border-[#CCCCCC] py-2 hover:text-primary/80 transition-colors'
                                                whileHover={{ x: 5 }}
                                                whileTap={{ scale: 0.98 }}
                                            >
                                                {category}
                                            </motion.a>
                                        </motion.div>
                                    ))}
                                </div>
                            </motion.div>

                            {/* Latest Tech Articles Panel */}
                            <motion.div 
                                className='latest-tech-articles'
                                custom={1}
                                variants={panelVariants}
                                initial="hidden"
                                whileInView="visible"
                                viewport={{ once: true }}
                            >
                                <h3 className='text-base md:text-lg font-[500] text-black border-b-[2px] border-primary mb-4 pb-2'>
                                    Latest Tech Articles
                                </h3>
                                <ul className='list-disc list-inside space-y-2 ml-2'>
                                    {latestTechArticles.map((article, index) => (
                                        <motion.li
                                            key={index}
                                            custom={index}
                                            variants={panelItemVariants}
                                            initial="hidden"
                                            whileInView="visible"
                                            viewport={{ once: true }}
                                            className="marker:text-primary"
                                        >
                                            <motion.a 
                                                href={article.link} 
                                                className='text-sm md:text-base font-[400] text-primary hover:text-primary/80 transition-colors line-clamp-2 inline-block'
                                                whileHover={{ x: 5 }}
                                                whileTap={{ scale: 0.98 }}
                                            >
                                                {article.title}
                                            </motion.a>
                                        </motion.li>
                                    ))}
                                </ul>
                            </motion.div>

                            {/* Get Started - Admin Panel */}
                            <motion.div 
                                className='get-started'
                                custom={2}
                                variants={panelVariants}
                                initial="hidden"
                                whileInView="visible"
                                viewport={{ once: true }}
                            >
                                <h3 className='text-base md:text-lg font-[500] text-black border-b-[2px] border-primary mb-4 pb-2'>
                                    Get Started - Admin
                                </h3>
                                <ul className='list-disc list-inside space-y-2 ml-2'>
                                    {adminGetStartedLinks.map((link, index) => (
                                        <motion.li
                                            key={index}
                                            custom={index}
                                            variants={panelItemVariants}
                                            initial="hidden"
                                            whileInView="visible"
                                            viewport={{ once: true }}
                                            className="marker:text-primary"
                                        >
                                            <motion.a 
                                                href={link.link} 
                                                className='text-sm md:text-base font-[400] text-primary hover:text-primary/80 transition-colors inline-block'
                                                whileHover={{ x: 5 }}
                                                whileTap={{ scale: 0.98 }}
                                            >
                                                {link.title}
                                            </motion.a>
                                        </motion.li>
                                    ))}
                                </ul>
                            </motion.div>
                        </motion.aside>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Blog;