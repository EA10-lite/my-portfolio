import { motion } from "framer-motion";
import { PageHeading, SolutionCard } from "../../components";
import { solutionItems } from "../../data/solution";


const Solutions = () => {
    return (
        <div className="w-full h-full mb-[120px]">
            <motion.div 
                className="hero-content bg-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
            >
                <div className="container mx-auto px-4 py-12 lg:py-16">
                    <div className="grid grid-cols-1 lg:grid-cols-2 items-center">
                        {/* Left Side - Text Content */}
                        <motion.div
                            initial={{ opacity: 0, x: -50 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.6 }}
                        >
                            <PageHeading>
                                Unified Communications Systems
                            </PageHeading>
                            <ul className="space-y-4">
                                {[
                                    "Integrated voice, video, messaging, and conferencing tools",
                                    "Cross-platform (web, mobile, embedded, and IoT-capable)",
                                    "Designed for multilingual, low-bandwidth environments"
                                ].map((text, index) => (
                                    <motion.li 
                                        key={index}
                                        className="text-[16px] md:text-[18px] lg:text-[30px] font-[400] text-black flex items-start"
                                        initial={{ opacity: 0, x: -20 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        transition={{ duration: 0.4, delay: index * 0.1 }}
                                    >
                                        <span className="text-primary mr-3 mt-2">•</span>
                                        <span>{text}</span>
                                    </motion.li>
                                ))}
                            </ul>
                        </motion.div>

                        {/* Right Side - Visual Content */}
                        <motion.div 
                            className="relative"
                            initial={{ opacity: 0, x: 50 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ duration: 0.6, delay: 0.2 }}
                        >
                            <motion.img 
                                src="/images/sol.png" 
                                alt="Unified Communications Systems - Laptop, Desk Phone, and Smartphone" 
                                className="w-full h-auto object-contain"
                                whileHover={{ scale: 1.05 }}
                                transition={{ duration: 0.3 }}
                            />
                        </motion.div>
                    </div>
                </div>
            </motion.div>
            <motion.div 
                className="solutions-content"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6 }}
            >
                <div className="container mx-auto px-4 py-6 lg:py-12">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {solutionItems.map((item, index) => (
                            <SolutionCard key={index} {...item} index={index} />
                        ))}
                    </div>
                </div>
            </motion.div>
        </div>
    )
}


export default Solutions;