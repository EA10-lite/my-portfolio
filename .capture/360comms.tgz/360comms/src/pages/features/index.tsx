import { motion } from "framer-motion";
import { FeatureCard } from "../../components";

const featureItems = [
    {
        title: 'Voice Calling',
        description: 'Make voice calls to friends and loved ones instantly without limits.',
        image: '/icons/ft-1.svg',
    },
    {
        title: 'Video Calling',
        description: 'Make voice and video calls to friends and loved ones instantly without limits.',
        image: '/icons/ft-2.svg',

    },
    {
        title: 'Call Transfer',
        description: 'Whether attended on unattended, you can easily re-allocate an existing call to another phone line or person.',
        image: '/icons/ft-3.svg',
    },
    {
        title: 'Messaging',
        description: 'Chat and group chat enables users to communicate without having to start to phone call.',
        image: '/icons/ft-4.svg',
    },
    {
        title: 'Voice-enabled Chat',
        description: 'In case you\'re busy with your hand and want to send out an urgent message, now you can activate the Voice-enable Chat and dictate your message to your friend and loved one.',
        image: '/icons/ft-5.svg',
    },
    {
        title: 'Contact Management',
        description: 'Easily store, find and manage contacts information.',
        image: '/icons/ft-6.svg',
    },
    {
        title: 'Screen Sharing',
        description: 'Have an excellent presentation. Instantly share your screen with colleagues who you are talking or chatting with.',
        image: '/icons/ft-7.svg',
    },
    {
        title: 'Conference Call',
        description: 'Get connected and talk to several people at the same time on voice and video conferencing.',
        image: '/icons/ft-8.svg',
    },
    {
        title: 'Call Recording',
        description: 'Record your voice and video calls sessions for later playback.',
        image: '/icons/ft-9.svg',
    },
]

const Features = () => {
    return (
        <div className="w-full h-full mb-[120px]">
            <motion.div 
                className="hero-image"
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
            >
                <img 
                    src="/images/feature-bg.png" 
                    alt="Features" 
                    className="w-full h-full loading-lazy" 
                />
            </motion.div>

            <motion.div 
                className="feature-items"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6 }}
            >
                <div className="container mx-auto px-4 py-12">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {featureItems.map((item, index) => (
                            <FeatureCard key={index} {...item} index={index} />
                        ))}
                    </div>
                </div>
            </motion.div>
        </div>
    )
}

export default Features;