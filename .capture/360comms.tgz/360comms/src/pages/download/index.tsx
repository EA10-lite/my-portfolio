import { motion } from 'framer-motion'
import { BsPhone, BsDisplay, BsApple, BsWindows } from 'react-icons/bs'
import { FaLinux } from 'react-icons/fa'
import { PageHeading } from '../../components'


const Download = () => {
    // Animation variants for download sections
    const sectionVariants = {
        hidden: { opacity: 0, y: 50 },
        visible: (i: number) => ({
            opacity: 1,
            y: 0,
            transition: {
                duration: 0.6,
                delay: i * 0.2,
                ease: [0, 0, 0.58, 1] as const
            }
        })
    };

    return (
        <div className="w-full min-h-screen mb-[120px]">
            <motion.div 
                className="hero-image"
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
            >
                <img 
                    src="/images/download-bg.png" 
                    alt="Download" 
                    className="w-full min-h-[120px] sm:min-h-[165px] md:min-h-[200px] h-full object-cover loading-lazy" 
                />
            </motion.div>

            <div className="download-items">
                <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-6 md:py-8 lg:py-12">
                    <motion.div 
                        className="mb-6 sm:mb-8 relative"
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.6 }}
                    >
                        <PageHeading>
                            Available for Download
                        </PageHeading>
                        <h2 className="text-[14px] sm:text-[16px] md:text-[24px] lg:text-[40px] text-black font-[400]">
                            Mobile, PC and More!
                        </h2>
                    </motion.div>

                    <div className="space-y-6 sm:space-y-8">
                        {/* Section 1: 360Comms Mobile */}
                        <motion.div 
                            className="bg-white rounded-[15px] p-4 sm:p-5 md:p-6 shadow-[0px_6px_5px_0px_#65636340] max-w-[1000px] mx-auto"
                            custom={0}
                            initial="hidden"
                            animate="visible"
                            variants={sectionVariants}
                            whileHover={{ y: -5, transition: { duration: 0.3 } }}
                        >
                            <div className="flex items-center justify-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                                <motion.div
                                    whileHover={{ rotate: 360, scale: 1.2 }}
                                    transition={{ duration: 0.5 }}
                                >
                                    <BsPhone className="text-xl sm:text-2xl" color="#4D4C4C" />
                                </motion.div>
                                <h3 className="text-[18px] sm:text-[20px] md:text-[24px] font-[500] text-black text-center">360Comms Mobile</h3>
                            </div>
                            <div className="flex flex-wrap justify-center items-center gap-4 sm:gap-6 md:gap-8 lg:gap-12">
                                {/* Loveworld App Store Button */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_lwappstore"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.9 }}
                                    className="w-full sm:w-auto"
                                >
                                    <img src="/icons/love-world.svg" alt="Loveworld" className="w-full max-w-[140px] sm:max-w-none mx-auto sm:mx-0" />
                                </motion.a>

                                {/* Google Play Button */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_vDownload"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.9 }}
                                    className="w-full sm:w-auto"
                                >
                                    <img src="/icons/google-store.svg" alt="Google Play" className="w-full max-w-[140px] sm:max-w-none mx-auto sm:mx-0" />
                                </motion.a>

                                {/* App Store Button */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_Applestore"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.9 }}
                                    className="w-full sm:w-auto"
                                >
                                    <img src="/icons/app-store.svg" alt="App Store" className="w-full max-w-[140px] sm:max-w-none mx-auto sm:mx-0" />
                                </motion.a>
                            </div>
                        </motion.div>

                        {/* Section 2: 360Comms Lite */}
                        <motion.div 
                            className="bg-white rounded-[15px] p-4 sm:p-5 md:p-6 shadow-[0px_6px_5px_0px_#65636340] max-w-[1000px] mx-auto mt-6 sm:mt-8 md:mt-12"
                            custom={1}
                            initial="hidden"
                            animate="visible"
                            variants={sectionVariants}
                            whileHover={{ y: -5, transition: { duration: 0.3 } }}
                        >
                            <div className="flex items-center justify-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                                <motion.div
                                    whileHover={{ rotate: 360, scale: 1.2 }}
                                    transition={{ duration: 0.5 }}
                                >
                                    <BsPhone className="text-xl sm:text-2xl" color="#4D4C4C" />
                                </motion.div>
                                <h3 className="text-[18px] sm:text-[20px] md:text-[24px] font-[500] text-black text-center">360Comms Lite</h3>
                            </div>
                            <div className="flex flex-wrap justify-center items-center gap-4">
                                {/* Progressive Web App Button */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_PWA"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    whileHover={{ scale: 1.1 }}
                                    whileTap={{ scale: 0.9 }}
                                    className="w-full sm:w-auto"
                                >
                                    <img src="/icons/pwa.svg" alt="Progressive Web App" className="w-full max-w-[200px] sm:max-w-none mx-auto sm:mx-0" />
                                </motion.a>
                            </div>
                        </motion.div>

                        {/* Section 3: 360 Communicator for Desktops */}
                        <motion.div 
                            className="bg-white rounded-[15px] p-4 sm:p-5 md:p-6 shadow-[0px_6px_5px_0px_#65636340] max-w-[1000px] mx-auto"
                            custom={2}
                            initial="hidden"
                            animate="visible"
                            variants={sectionVariants}
                            whileHover={{ y: -5, transition: { duration: 0.3 } }}
                        >
                            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-3 mb-4 sm:mb-6">
                                <motion.div
                                    whileHover={{ rotate: 360, scale: 1.2 }}
                                    transition={{ duration: 0.5 }}
                                >
                                    <BsDisplay className="text-xl sm:text-2xl" color="#4D4C4C" />
                                </motion.div>
                                <h3 className="text-[16px] sm:text-[18px] md:text-[20px] lg:text-[24px] font-[500] text-black text-center">360 Communicator for Desktops</h3>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-6 sm:gap-8 md:gap-10 lg:gap-12 justify-center items-center">
                                {/* macOS Download */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_MacOS"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex flex-col items-center w-full sm:w-auto"
                                    whileHover={{ scale: 1.05 }}
                                >
                                    <motion.div 
                                        className="mb-3 sm:mb-4"
                                        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
                                        transition={{ duration: 0.5 }}
                                    >
                                        <BsApple className="text-5xl sm:text-6xl" color="#4D4C4C" />
                                    </motion.div>
                                    <motion.span 
                                        className="w-full sm:w-auto bg-[#029FF0] text-white rounded-[45px] px-6 py-2.5 sm:py-2 text-sm sm:text-base font-semibold max-w-[149px] mx-auto min-w-[120px] sm:min-w-[149px]"
                                        whileHover={{ scale: 1.05 }}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        Download
                                    </motion.span>
                                </motion.a>

                                {/* Windows Download */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_Windows"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex flex-col items-center w-full sm:w-auto"
                                    whileHover={{ scale: 1.05 }}
                                >
                                    <motion.div 
                                        className="mb-3 sm:mb-4"
                                        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
                                        transition={{ duration: 0.5 }}
                                    >
                                        <BsWindows className="text-5xl sm:text-6xl" color="#4D4C4C" />
                                    </motion.div>
                                    <motion.span 
                                        className="w-full sm:w-auto bg-[#029FF0] text-white rounded-[45px] px-6 py-2.5 sm:py-2 text-sm sm:text-base font-semibold max-w-[149px] mx-auto min-w-[120px] sm:min-w-[149px]"
                                        whileHover={{ scale: 1.05 }}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        Download
                                    </motion.span>
                                </motion.a>

                                {/* Linux Download */}
                                <motion.a 
                                    href="https://bit.ly/360CommsNexus_Linux"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex flex-col items-center w-full sm:w-auto"
                                    whileHover={{ scale: 1.05 }}
                                >
                                    <motion.div 
                                        className="mb-3 sm:mb-4"
                                        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
                                        transition={{ duration: 0.5 }}
                                    >
                                        <FaLinux className="text-5xl sm:text-6xl" color="#4D4C4C" />
                                    </motion.div>
                                    <motion.span 
                                        className="w-full sm:w-auto bg-[#029FF0] text-white rounded-[45px] px-6 py-2.5 sm:py-2 text-sm sm:text-base font-semibold max-w-[149px] mx-auto min-w-[120px] sm:min-w-[149px]"
                                        whileHover={{ scale: 1.05 }}
                                        whileTap={{ scale: 0.95 }}
                                    >
                                        Download
                                    </motion.span>
                                </motion.a>
                            </div>
                        </motion.div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Download;