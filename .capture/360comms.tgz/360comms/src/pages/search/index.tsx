import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useRef } from "react";
import { IoIosArrowDown } from "react-icons/io";
import { IoSearch } from "react-icons/io5";

const tabItems = [
    {
        label: "All Results",
        value: "all",
    },
    {
        label: "Forum",
        value: "forum",
    },
    {
        label: "Blogs",
        value: "blog",
    },
    {
        label: "Docs",
        value: "docs",
    },
]

const Search = () => {
    const [activeTab, setActiveTab] = useState("all");
    const [searchQuery, setSearchQuery] = useState("");

    // Animation variants
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.2
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                duration: 0.5,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    return (
        <div className="w-full h-full mb-[120px]">
            <motion.div 
                className="hero-image"
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
            >
                <img 
                    src="/images/search-bg.png" 
                    alt="Download" 
                    className="w-full h-auto object-cover loading-lazy" 
                />
            </motion.div>

            {/* Search Section */}
            <motion.div 
                className=""
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.6 }}
            >
                <div className="container mx-auto px-4 py-6 lg:py-12">
                    <motion.div 
                        className="border border-[#CDCDCD] rounded-[9px] flex  items-center justify-between gap-2 px-3 sm:px-4 py-2 mb-4"
                        initial={{ opacity: 0, scale: 0.95 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: 0.2 }}
                        whileHover={{ boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)" }}
                    >
                        <input 
                            type="text" 
                            placeholder="Search" 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full h-full outline-none text-sm sm:text-base flex-1" 
                        />
                        
                        <motion.div className="ml-4 pl-4 border-l border-[#CDCDCD] h-full"
                            initial={{ opacity: 0, x: -20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.4, delay: 0.2 }}
                        >
                            <motion.button 
                                className="p-2 flex items-center justify-center bg-primary rounded-[35px] w-[57px] h-[40px]"
                                onClick={() => {
                                    console.log("Search:", searchQuery);
                                }}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                <IoSearch 
                                    className="text-white cursor-pointer hover:opacity-80 transition-opacity" 
                                    size={20}
                                />
                            </motion.button>
                        </motion.div>

                    </motion.div>

                    <motion.div 
                        className="bg-[#f4f4f6] py-4 sm:py-5 text-center rounded-[9px]"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.4, delay: 0.3 }}
                    >
                        <p className="text-xs sm:text-sm md:text-base">
                            try using <a href="/ai-chat" className="font-bold">360Comms AI</a> for this query
                        </p>
                    </motion.div>
                </div>
            </motion.div>

            {/* Tabs Section */}
            <motion.div 
                className="tabs"
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
            >
                <div className="container mx-auto px-4 py-6 lg:py-12">
                    {/* Tab Navigation */}
                    <motion.div 
                        className="tab-nav border-b border-[#DFDDDD] flex items-center gap-4 sm:gap-6 md:gap-8 overflow-x-auto scrollbar-hide pb-2"
                        variants={itemVariants}
                    >
                        {tabItems.map((item, index) => (
                            <motion.button 
                                key={item.value}
                                className={`text-xs sm:text-sm font-[500] pb-2 cursor-pointer whitespace-nowrap relative ${
                                    activeTab === item.value 
                                        ? "text-black" 
                                        : "text-[#807E7E]"
                                }`}
                                onClick={() => setActiveTab(item.value)}
                                initial={{ opacity: 0, x: -20 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.3, delay: index * 0.1 }}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                {item.label}
                                {activeTab === item.value && (
                                    <motion.div
                                        className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-[#797777]"
                                        layoutId="activeTab"
                                        initial={false}
                                        transition={{
                                            type: "spring",
                                            stiffness: 500,
                                            damping: 30
                                        }}
                                    />
                                )}
                            </motion.button>
                        ))}
                    </motion.div>

                    {/* Results Header */}
                    <motion.div 
                        className="results border-b border-[#DFDDDD] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 py-3 sm:py-2 mb-6 sm:mb-8"
                        variants={itemVariants}
                    >
                        <motion.p 
                            className="text-xs sm:text-sm font-[400] text-[#484747]"
                            initial={{ opacity: 0, x: -20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.4, delay: 0.2 }}
                        >
                            About 1000 results (0.36 seconds)
                        </motion.p>

                        <motion.div 
                            className="flex items-center gap-2"
                            initial={{ opacity: 0, x: 20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.4, delay: 0.3 }}
                        >
                            <p className="text-xs sm:text-sm font-[400] text-[#484747] whitespace-nowrap">
                                Sort by:
                            </p>
                            <FilterDropdown />
                        </motion.div>
                    </motion.div>

                    {/* Tab Content */}
                    <motion.div 
                        className="tab-content"
                        variants={itemVariants}
                    >
                        <div className="flex flex-col gap-4 sm:gap-6">
                            {[1,2,3,4,5,6,7,8,9,10]?.map((_, index)=> (
                                <SearchResultCard 
                                    key={index} 
                                    title="Just setup 360Comms but can't make calls | 360Comms Forums"
                                    description="11 August 2025... To test, create an outbound rule and add +,0-9 then it through your SIP Trunk and try to make the call again."
                                    label="Forum"
                                    index={index}
                                />
                            ))}
                        </div>
                    </motion.div>
                </div>
            </motion.div>
        </div>
    )
}


const filterOptions = [
    { label: "Relevance", value: "relevance" },
    { label: "Date (Newest)", value: "date-newest" },
    { label: "Date (Oldest)", value: "date-oldest" },
    { label: "Alphabetical (A-Z)", value: "alphabetical-asc" },
    { label: "Alphabetical (Z-A)", value: "alphabetical-desc" },
    { label: "Popularity", value: "popularity" },
]

const FilterDropdown = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedValue, setSelectedValue] = useState("relevance");
    const dropdownRef = useRef<HTMLDivElement>(null);

    // Close dropdown when clicking outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };

        if (isOpen) {
            document.addEventListener("mousedown", handleClickOutside);
        }

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [isOpen]);

    // Close dropdown on ESC key
    useEffect(() => {
        const handleEscape = (e: KeyboardEvent) => {
            if (e.key === "Escape" && isOpen) {
                setIsOpen(false);
            }
        };

        document.addEventListener("keydown", handleEscape);
        return () => document.removeEventListener("keydown", handleEscape);
    }, [isOpen]);

    const selectedOption = filterOptions.find(option => option.value === selectedValue) || filterOptions[0];

    // Dropdown animation variants
    const dropdownVariants = {
        hidden: {
            opacity: 0,
            y: -10,
            scale: 0.95
        },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 0.2,
                ease: [0, 0, 0.58, 1] as const
            }
        },
        exit: {
            opacity: 0,
            y: -10,
            scale: 0.95,
            transition: {
                duration: 0.15,
                ease: [0.42, 0, 1, 1] as const
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, x: -10 },
        visible: (i: number) => ({
            opacity: 1,
            x: 0,
            transition: {
                duration: 0.2,
                delay: i * 0.03,
                ease: [0, 0, 0.58, 1] as const
            }
        })
    };

    const handleSelect = (value: string) => {
        setSelectedValue(value);
        setIsOpen(false);
        // Handle filter change logic here
        console.log("Filter changed to:", value);
    };

    return (
        <div className="relative w-full sm:w-auto" ref={dropdownRef}>
            <motion.button
                onClick={() => setIsOpen(!isOpen)}
                className="flex items-center justify-between sm:justify-center gap-2 rounded-[35px] bg-[#EBEBEB] px-3 sm:px-4 py-2 hover:bg-[#E0E0E0] transition-colors cursor-pointer w-full sm:w-auto"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                aria-label="Sort by"
                aria-expanded={isOpen}
            >
                <p className="text-xs sm:text-sm font-[400] text-black whitespace-nowrap">
                    {selectedOption.label}
                </p>
                <motion.div
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex-shrink-0"
                >
                    <IoIosArrowDown className="text-black" size={16} />
                </motion.div>
            </motion.button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        className="absolute right-0 sm:right-0 left-0 sm:left-auto mt-2 bg-white rounded-lg shadow-lg border border-[#DFDDDD] min-w-[200px] w-full sm:w-auto z-50 overflow-hidden"
                        variants={dropdownVariants}
                        initial="hidden"
                        animate="visible"
                        exit="exit"
                    >
                        <ul className="py-2">
                            {filterOptions.map((option, index) => (
                                <motion.li
                                    key={option.value}
                                    custom={index}
                                    variants={itemVariants}
                                    initial="hidden"
                                    animate="visible"
                                >
                                    <button
                                        onClick={() => handleSelect(option.value)}
                                        className={`w-full text-left px-4 py-2 text-xs sm:text-sm font-[400] hover:bg-[#EBEBEB] transition-colors ${
                                            selectedValue === option.value
                                                ? "bg-[#EBEBEB] text-primary font-[500]"
                                                : "text-black"
                                        }`}
                                    >
                                        {option.label}
                                    </button>
                                </motion.li>
                            ))}
                        </ul>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    )
}



type SearchResultCardProps = {
    title: string;
    description: string;
    label: string;
    breadcrumbs?: string[];
    index?: number;
}

const SearchResultCard = ({ title, description, label, breadcrumbs, index = 0 }: SearchResultCardProps) => {
    // Default breadcrumbs if not provided
    const defaultBreadcrumbs = ["360Comms", "Forums", "Categories", "Phone System PBX"];
    const breadcrumbItems = breadcrumbs || defaultBreadcrumbs;

    // Breadcrumb animation variants
    const breadcrumbVariants = {
        hidden: { opacity: 0, x: -10 },
        visible: (i: number) => ({
            opacity: 1,
            x: 0,
            transition: {
                duration: 0.3,
                delay: index * 0.05 + i * 0.03,
                ease: [0, 0, 0.58, 1] as const
            }
        })
    };

    return (
        <motion.div 
            className="search-result-card border-b border-[#DFDDDD] pb-6 last:border-b-0"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.4, delay: index * 0.05 }}
        >
            <motion.h4 
                className="text-base md:text-lg font-[400] text-primary mb-2 hover:underline cursor-pointer"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 + 0.1 }}
                whileHover={{ x: 5 }}
            >
                {title}
            </motion.h4>
            
            <nav 
                className="breadcrumbs flex flex-wrap items-center gap-1 md:gap-2 mb-2 text-xs md:text-sm"
                aria-label="Breadcrumb"
            >
                {breadcrumbItems.map((crumb, crumbIndex) => {
                    const isLast = crumbIndex === breadcrumbItems.length - 1;
                    
                    return (
                        <div key={crumbIndex} className="flex items-center gap-1 md:gap-2">
                            {crumbIndex > 0 && (
                                <span className="text-[#807E7E] mx-1">/</span>
                            )}
                            <motion.a
                                href={isLast ? undefined : `/${crumb.toLowerCase().replace(/\s+/g, '-')}`}
                                className={`font-[400] transition-colors ${
                                    isLast 
                                        ? "text-[#484747] cursor-default" 
                                        : "text-[#807E7E] hover:text-primary"
                                }`}
                                custom={crumbIndex}
                                variants={breadcrumbVariants}
                                initial="hidden"
                                whileInView="visible"
                                viewport={{ once: true }}
                                whileHover={!isLast ? { x: 2 } : {}}
                                onClick={(e) => {
                                    if (isLast) {
                                        e.preventDefault();
                                    }
                                }}
                            >
                                {crumb}
                            </motion.a>
                        </div>
                    );
                })}
            </nav>
            
            <motion.p 
                className="text-sm md:text-base font-[400] text-[#484747] leading-[25px] mb-2"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 + 0.2 }}
            >
                {description}
            </motion.p>
            
            <motion.p 
                className="text-xs md:text-sm font-[400] text-[#484747]"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 + 0.3 }}
            >
                Labeled: <span className="text-primary underline font-[500]">{label}</span>
            </motion.p>
        </motion.div>
    )
}

export default Search;