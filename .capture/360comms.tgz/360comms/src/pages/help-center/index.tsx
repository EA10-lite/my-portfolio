import { motion } from "framer-motion";
import { PageHeading } from "../../components";

const HelpCenter = () => {
    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.2,
                delayChildren: 0.1
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: {
            opacity: 1,
            y: 0,
            transition: {
                duration: 0.6,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    const imageVariants = {
        hidden: { opacity: 0, x: 20, scale: 0.95 },
        visible: {
            opacity: 1,
            x: 0,
            scale: 1,
            transition: {
                duration: 0.6,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    return (
        <motion.div
            className="w-full min-h-screen bg-[#E7EEFF] py-8 sm:py-12 md:py-16 lg:py-20 mb-[120px]"
            initial="hidden"
            animate="visible"
            variants={containerVariants}
        >
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col lg:flex-row items-center justify-center gap-8 lg:gap-12 xl:gap-16">
                    <motion.div
                        className="w-full lg:max-w-[343px] flex flex-col"
                        variants={itemVariants}
                    >
                        <PageHeading variants={itemVariants}>
                            Help Center
                        </PageHeading>
                        
                        <motion.h2
                            className="text-[20px] sm:text-[24px] md:text-[28px] lg:text-[32px] font-[400] text-black mb-4 sm:mb-6 leading-tight"
                            variants={itemVariants}
                        >
                            Get answers with Xceptia Arielle
                        </motion.h2>
                        
                        <motion.p
                            className="text-sm sm:text-base md:text-lg text-black font-[400] leading-relaxed max-w-[600px]"
                            variants={itemVariants}
                        >
                            Chat with Xceptia Arielle, and Arielle would direct you to to next customer care agent for more technical issues.
                        </motion.p>
                    </motion.div>

                    <motion.div
                        className="w-full lg:w-1/2 flex items-center justify-center"
                        variants={imageVariants}
                    >
                        <motion.div
                            className="w-full max-w-[517px] h-auto"
                            whileHover={{ scale: 1.02 }}
                            transition={{ duration: 0.3 }}
                        >
                            <img
                                src="/images/help-center.png"
                                alt="Xceptia Arielle Chat Interface"
                                className="w-full h-auto object-contain rounded-lg shadow-[0px_4px_50px_7px_#9E9D9D40]"
                            />
                        </motion.div>
                    </motion.div>
                </div>
            </div>
        </motion.div>
    );
};

export default HelpCenter;