import { useState } from "react";
import { motion } from "framer-motion";
import { IoMdInformationCircle, IoMdSend } from "react-icons/io";
import { PageHeading } from "../../components";

const AiChat = () => {
    const [question, setQuestion] = useState("");

    // Handle form submission
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (question.trim()) {
            // TODO: Implement chat functionality
            console.log("Question submitted:", question);
            setQuestion("");
        }
    };

    // Animation variants for the chat card
    const cardVariants = {
        hidden: { opacity: 0, y: 30, scale: 0.95 },
        visible: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                duration: 0.5,
                ease: [0, 0, 0.58, 1] as const
            }
        }
    };

    // Animation variants for inner elements
    const itemVariants = {
        hidden: { opacity: 0, y: 10 },
        visible: (i: number) => ({
            opacity: 1,
            y: 0,
            transition: {
                delay: i * 0.1,
                duration: 0.4
            }
        })
    };

    return (
        <motion.div
            className="w-full lg:min-h-screen py-8 md:py-12 lg:py-16 flex items-center justify-center mb-[120px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
        >
            <div className="container mx-auto px-4">
                {/* Centered Chat Card */}
                <motion.div
                    className="max-w-3xl mx-auto bg-white rounded-[9px] shadow-[0px_4px_50px_7px_#9E9D9D40] p-4 md:p-6 lg:p-8"
                    variants={cardVariants}
                    initial="hidden"
                    animate="visible"
                >
                    {/* Header Section with Info Icon and Heading */}
                    <motion.div
                        className="mb-4 md:mb-6"
                        custom={0}
                        initial="hidden"
                        animate="visible"
                        variants={itemVariants}
                    >
                        <div className="flex flex-col items-center gap-3 md:gap-4 mb-3">
                            {/* Blue Information Icon */}
                            <motion.div
                                className="flex-shrink-0 mt-1"
                                whileHover={{ scale: 1.1, rotate: 5 }}
                                transition={{ duration: 0.2 }}
                            >
                                <IoMdInformationCircle className="w-6 h-6 md:w-7 md:h-7 text-primary" />
                            </motion.div>
                            
                            {/* Main Heading */}
                            <PageHeading>
                                Hi, how can I help?
                            </PageHeading>
                        </div>

                        {/* Sub-text with Guides Link */}
                        <motion.p
                            className="text-sm md:text-base text-[#666666] ml-9 md:ml-11"
                            custom={1}
                            initial="hidden"
                            animate="visible"
                            variants={itemVariants}
                        >
                            Prefer reading over chatting? Check out our{" "}
                            <a
                                href="/help-center"
                                className="text-primary hover:underline font-[500] transition-colors"
                            >
                                guides
                            </a>{" "}
                            for detailed help.
                        </motion.p>
                    </motion.div>

                    {/* Input Section */}
                    <motion.form
                        onSubmit={handleSubmit}
                        className="mb-4 md:mb-6"
                        custom={2}
                        initial="hidden"
                        animate="visible"
                        variants={itemVariants}
                    >
                        <div className="relative flex items-center">
                            {/* Text Input Field */}
                            <input
                                type="text"
                                value={question}
                                onChange={(e) => setQuestion(e.target.value)}
                                placeholder="Ask a question..."
                                className="w-full border border-[#E6E2E2] rounded-[9px] px-4 md:px-6 py-3 md:py-4 pr-12 md:pr-14 text-sm md:text-base font-[400] focus:outline-none focus:border-primary transition-colors shadow-[0px_3px_3px_0px_#00000040]"
                                aria-label="Ask a question"
                            />
                            
                            {/* Send Button (Paper Airplane Icon) */}
                            <motion.button
                                type="submit"
                                className="absolute right-2 md:right-3"
                                whileHover={{ scale: 1.1 }}
                                whileTap={{ scale: 0.9 }}
                                aria-label="Send message"
                            >
                                <IoMdSend className="w-4 h-4 md:w-5 md:h-5 text-primary" />
                            </motion.button>
                        </div>
                    </motion.form>

                    {/* Disclaimer Section */}
                    <motion.div
                        className="text-xs md:text-sm text-[#666666] leading-relaxed text-center"
                        custom={3}
                        initial="hidden"
                        animate="visible"
                        variants={itemVariants}
                    >
                        <p>
                            This chatbot uses OpenAI technology and may produce content that is inaccurate or not based on{" "}
                            <a
                                href="#"
                                className="text-primary hover:underline font-[500] transition-colors"
                                onClick={(e) => {
                                    e.preventDefault();
                                    // TODO: Navigate to verified news page
                                }}
                            >
                                verified news
                            </a>
                            . 360Comms is not liable for how you use this content, and it carries no legal weight. All data shared through this chatbot is processed in accordance with the{" "}
                            <a
                                href="#"
                                className="text-primary hover:underline font-[500] transition-colors"
                                onClick={(e) => {
                                    e.preventDefault();
                                    // TODO: Navigate to privacy notice page
                                }}
                            >
                                360Comms Privacy Notice
                            </a>
                            .
                        </p>
                    </motion.div>
                </motion.div>
            </div>
        </motion.div>
    );
};

export default AiChat;