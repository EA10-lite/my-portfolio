export type BlogItem = {
    title: string;
    description: string;
    image: string;
    date: string;
    author: string;
    link: string;
    comments: number;
    category?: string;
}

export const blogItems: BlogItem[] = [
    {
        title: '360Comms V3.0 Beta- Transcription Snippets, Call Blocking & SMS Restrictions',
        description: 'This beta introduces several update focused on visibility, control and usability. The Beta releases of 360Comms Loveworld App Store, Android App V3.0 is now available. There\'s some general improvements along with new features available from Version 2.0 Update 7, including voicemail transcription previews, number blocking, and SMS restrictions for enhanced communication management.',
        image: '/images/blog-img-1.png',
        date: 'August 6th, 2025',
        author: 'Owen Wallace',
        link: '/blog/360comms-v3-beta',
        comments: 0,
        category: 'Product Releases'
    },
    {
        title: '360Comms V3.0 Beta- Transcription Snippets, Call Blocking & SMS Restrictions',
        description: 'This beta introduces several update focused on visibility, control and usability. The Beta releases of 360Comms Loveworld App Store, Android App V3.0 is now available. There\'s some general improvements along with new features available from Version 2.0 Update 7, including voicemail transcription previews, number blocking, and SMS restrictions for enhanced communication management.',
        image: '/images/blog-img-2.png',
        date: 'August 6th, 2025',
        author: 'Owen Wallace',
        link: '/blog/360comms-v3-beta-2',
        comments: 0,
        category: 'Product Releases'
    },
    {
        title: '360Comms V3.0 Beta- Transcription Snippets, Call Blocking & SMS Restrictions',
        description: 'This beta introduces several update focused on visibility, control and usability. The Beta releases of 360Comms Loveworld App Store, Android App V3.0 is now available. There\'s some general improvements along with new features available from Version 2.0 Update 7, including voicemail transcription previews, number blocking, and SMS restrictions for enhanced communication management.',
        image: '/images/blog-img-3.png',
        date: 'August 6th, 2025',
        author: 'Owen Wallace',
        link: '/blog/360comms-v3-beta-3',
        comments: 0,
        category: 'Product Releases'
    },
    {
        title: '360Comms V3.0 Beta- Transcription Snippets, Call Blocking & SMS Restrictions',
        description: 'This beta introduces several update focused on visibility, control and usability. The Beta releases of 360Comms Loveworld App Store, Android App V3.0 is now available. There\'s some general improvements along with new features available from Version 2.0 Update 7, including voicemail transcription previews, number blocking, and SMS restrictions for enhanced communication management.',
        image: '/images/blog-img-5.png',
        date: 'August 6th, 2025',
        author: 'Owen Wallace',
        link: '/blog/360comms-v3-beta-4',
        comments: 0,
        category: 'Product Releases'
    },
    {
        title: '360Comms V3.0 Beta- Transcription Snippets, Call Blocking & SMS Restrictions',
        description: 'This beta introduces several update focused on visibility, control and usability. The Beta releases of 360Comms Loveworld App Store, Android App V3.0 is now available. There\'s some general improvements along with new features available from Version 2.0 Update 7, including voicemail transcription previews, number blocking, and SMS restrictions for enhanced communication management.',
        image: '/images/blog-img-6.png',
        date: 'August 6th, 2025',
        author: 'Owen Wallace',
        link: '/blog/360comms-v3-beta-5',
        comments: 0,
        category: 'Product Releases'
    },
]

export const blogCategories = [
    'Product Releases',
    'Call Flow',
    'Events & Webinars',
    'Docs and FAQ',
    'News',
    'Vlogs'
]

export const latestTechArticles = [
    {
        title: '360Comms Softphone V3.0 Beta - Transcription Snippets, Call Blocking...',
        link: '/blog/softphone-v3-beta'
    },
    {
        title: '360Comms Softphone V3.0 Beta - Transcription Snippets, Call Blocking...',
        link: '/blog/softphone-v3-beta-2'
    },
    {
        title: '360Comms iOS V3.0 Beta - Transcription Snippets, Call Blocking...',
        link: '/blog/ios-v3-beta'
    },
    {
        title: 'V20 U7 Alpha: Major Boosts to 360Comms System Management for Admin',
        link: '/blog/v20-u7-alpha'
    }
]

export const adminGetStartedLinks = [
    {
        title: 'Install 360Comms',
        link: '/docs/install'
    },
    {
        title: 'Setup Team',
        link: '/docs/setup-team'
    },
    {
        title: 'Configure System',
        link: '/docs/configure'
    }
]

