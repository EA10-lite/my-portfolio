export type SolutionItem = {
    title: string;
    description: string[];
    image: string;
}

export const solutionItems: SolutionItem[] = [
    {
        title: 'Telecom Infrastructure Solutions',
        description: [
            'Asterisk-powered PBX systems',
            'SIP trunking and GSM gateway integration',
            'SIM routing, IVR & VAS platforms',
        ],
        image: '/images/sol-1.png',
    },
    {
        title: 'Command & Control Systems',
        description: [
            'Real-time situational awareness dashboards',
            'Tactical-grade push-to-talk, alerts, and GIS mapping',
            'UAV integration and emergency broadcast tools',
        ],
        image: '/images/sol-2.png',
    },
    {
        title: 'Secure Messaging & Collaboration',
        description: [
            'Encrypted communication apps (desktop, mobile)',
            'File transfer with Data Loss Prevention (DLP), role-based access, remote killswitch',
            'Offline-first delivery for remote or critical environments.',
        ],
        image: '/images/sol-3.png',
    },
    {
        title: 'Custom Telco Service',
        description: [
            'USSD, IVR & VAS platforms for MVNOs',
            'Enterprise customer portals and',
            '24/7 Support automation',
        ],
        image: '/images/sol-4.png',
    },
    {
        title: 'Secure Mobile Payment & Authentication',
        description: [
            'Mobile payment and SIM-based authentication integration.',
        ],
        image: '/images/sol-5.png',
    },
    {
        title: 'Emerging Technologies',
        description: [
            '5G/6G Integration',
            'Multilingual AI & Natural Language Interfaces',
            'Blockchain for secure identity & message trails',
            'Quantum-Resilient Messaging',
            'Multimodal Information Systems (Text + Voice + Video)',
        ],
        image: '/images/sol-6.png',
    },
]