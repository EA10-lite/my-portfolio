export type TestimonialItem = {
    id: number;
    quote: string;
    author: string;
    title: string;
    company: string;
    companyLogo: string;
}

export const testimonialItems: TestimonialItem[] = [
    {
        id: 1,
        quote: "360Comms is forward thinking. It developed a robust software PBX with hypervisor in mind and it’s communication solutions are a great fit for organizations of any size.",
        author: "Smith White",
        title: "HOD Marketing",
        company: "Refuge Mortgage Bank",
        companyLogo: "/images/logos/logo-9.svg"
    },
    {
        id: 2,
        quote: "We are extremely satisfied with 360Comms! It’s helped us take our Partners satisfaction to the next level. We look forward to new product features in future releases.",
        author: "Jennet Owens",
        title: "Partnership Consultant",
        company: "OneWorld",
        companyLogo: "/images/logos/loveworld-school.svg"
    },
]

