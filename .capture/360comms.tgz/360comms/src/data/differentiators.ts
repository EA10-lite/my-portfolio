/**
 * Core Differentiators Data
 * 
 * This file contains the data for the "Core Differentiators" section
 * displayed on the home page. Each differentiator represents a key
 * competitive advantage of the 360Comms platform.
 */

export type DifferentiatorItem = {
    title: string;
    description: string;
    image: string;
}

export const differentiatorItems: DifferentiatorItem[] = [
    {
        title: 'Africa-First Design',
        description: 'Built for regional realities (2G/3G zones, multilingual UI)',
        image: '/icons/dif-1.svg', // Icon: Globe with upward arrow
    },
    {
        title: 'Security-Centric Architecture',
        description: 'AES-256, VPN layers, Biometric access',
        image: '/icons/dif-2.svg', // Icon: Shield with padlock
    },
    {
        title: 'Full Platform Mobility',
        description: 'Runs across mobile, desktop, web, and satellite systems',
        image: '/icons/dif-3.svg', // Icon: Mobile phone to desktop monitor
    },
    {
        title: 'Regulatory Advantage',
        description: 'Powered by OneWorld Mobile\'s Telco licenses',
        image: '/icons/dif-4.svg', // Icon: Legal scale/balance
    },
    {
        title: 'Customizable',
        description: 'Deployments On-premise, cloud, hybrid or air-gapped',
        image: '/icons/dif-5.svg', // Icon: Gear/cogwheel
    },
    {
        title: 'Live Analytics',
        description: 'Real-time traffic, QoS, and usage dashboards',
        image: '/icons/dif-6.svg', // Icon: Dashboard with upward trend
    },
    {
        title: '24/7 Engineering',
        description: 'Support SLA-driven service across sectors',
        image: '/icons/dif-7.svg', // Icon: Clock with gear (24/7)
    },
]

