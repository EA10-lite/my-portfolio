import './App.css'
import {BrowserRouter, Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import { 
  Home,
  Solutions,
  HelpCenter,
  Features,
  Blog,
  Download,
  Search,
  AiChat,
} from './pages';
import { AppLayout } from './layouts';

// Wrapper component to access location for AnimatePresence
function AnimatedRoutes() {
  const location = useLocation()
  
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Home />} />
          <Route path="solutions" element={<Solutions />} />
          <Route path="help-center" element={<HelpCenter />} />
          <Route path="features" element={<Features />} />
          <Route path="blog" element={<Blog />} />
          <Route path="download" element={<Download />} />
          <Route path="search" element={<Search />} />
          <Route path="ai-chat" element={<AiChat />} />
        </Route>
      </Routes>
    </AnimatePresence>
  )
}

function App() {
  return (
    <BrowserRouter>
      <AnimatedRoutes />
    </BrowserRouter>
  )
}

export default App
