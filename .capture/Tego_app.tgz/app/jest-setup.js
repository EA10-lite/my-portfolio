// Jest setup for rendering-based tests.
//
// @gorhom/bottom-sheet (pulled in transitively by the shared component
// barrels) depends on react-native-reanimated, which pulls in
// react-native-worklets. Those are native libraries, so Jest requires their
// bundled mock implementations. See:
//   https://docs.swmansion.com/react-native-reanimated/docs/guides/testing
//   https://docs.swmansion.com/react-native-worklets/docs/guides/testing
jest.mock("react-native-worklets", () =>
  require("react-native-worklets/src/mock"),
);

require("react-native-reanimated").setUpTests();

require("react-native-gesture-handler/jestSetup");

// zustand persist() stores (auth/temp-user) read current token/username on
// import; the AsyncStorage native module is absent under Jest. See:
//   https://react-native-async-storage.github.io/async-storage/docs/advanced/jest
jest.mock("@react-native-async-storage/async-storage", () =>
  require("@react-native-async-storage/async-storage/jest/async-storage-mock"),
);

// CheckoutWebView (pulled in through the shared component barrels by the
// auth screens) imports react-native-webview, whose TurboModule registration
// throws outside a native runtime.
jest.mock("react-native-webview", () => {
  const RN = require("react-native");
  const WebView = (props) =>
    RN.createElement(RN.View, props);
  return { WebView, __esModule: true, default: WebView };
});