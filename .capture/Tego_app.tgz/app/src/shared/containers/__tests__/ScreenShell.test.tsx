import { renderWithProviders } from "@/testing/render";
import React from "react";
import { Text } from "react-native";
import ScreenShell from "../ScreenShell";

describe("ScreenShell", () => {
  it("renders children inside the scrollable area", async () => {
    const ui = await renderWithProviders(
      <ScreenShell>
        <Text>Signed</Text>
      </ScreenShell>,
    );
    expect(ui.getByText("Signed")).toBeTruthy();
  });

  it("renders footer content via the footer prop", async () => {
    const ui = await renderWithProviders(
      <ScreenShell footer={<Text>Proceed</Text>}>
        <Text>body</Text>
      </ScreenShell>,
    );
    expect(ui.getByText("body")).toBeTruthy();
    expect(ui.getByText("Proceed")).toBeTruthy();
  });

  it("renders no footer when the footer prop is omitted", async () => {
    const ui = await renderWithProviders(
      <ScreenShell>
        <Text>body</Text>
      </ScreenShell>,
    );
    expect(ui.queryByText("Proceed")).toBeNull();
  });

  it("keeps inputs above the keyboard via KeyboardAwareScrollView config", async () => {
    const ui = await renderWithProviders(
      <ScreenShell>
        <Text>body</Text>
      </ScreenShell>,
    );
    const tree = JSON.stringify(ui.toJSON());
    expect(tree).toContain('"keyboardShouldPersistTaps":"handled"');
    expect(tree).toContain('"enableOnAndroid":true');
    expect(tree).toContain('"keyboardDismissMode":"on-drag"');
    expect(tree).toContain('"extraScrollHeight":20');
    expect(tree).toContain('"extraHeight":100');
  });

  it("passes through contentContainerStyle", async () => {
    const ui = await renderWithProviders(
      <ScreenShell contentContainerStyle={{ paddingBottom: 24 }}>
        <Text>body</Text>
      </ScreenShell>,
    );
    expect(JSON.stringify(ui.toJSON())).toContain('"paddingBottom":24');
  });

  it("skips the scroll view when scroll={false}", async () => {
    const ui = await renderWithProviders(
      <ScreenShell scroll={false}>
        <Text>body</Text>
      </ScreenShell>,
    );
    const tree = JSON.stringify(ui.toJSON());
    expect(tree).not.toContain("keyboardShouldPersistTaps");
    expect(tree).not.toContain("extraScrollHeight");
    expect(ui.getByText("body")).toBeTruthy();
  });
});