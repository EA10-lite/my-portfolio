import { PALETTE } from "@/constants/colors";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import {
  StyleProp,
  StyleSheet,
  View,
  ViewStyle,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface ScreenShellProps {
  children: React.ReactNode;
  scroll?: boolean;
  extraScrollHeight?: number;
  extraHeight?: number;
  style?: StyleProp<ViewStyle>;
  contentContainerStyle?: StyleProp<ViewStyle>;
  safeAreaBottom?: boolean;
  safeAreaTop?: boolean;
  footer?: React.ReactNode;
  scrollRef?: React.RefObject<any>;
}

const ScreenShell = ({
  children,
  scroll = true,
  extraScrollHeight = 20,
  extraHeight = 100,
  style,
  contentContainerStyle,
  safeAreaBottom = false,
  safeAreaTop = false,
  footer,
  scrollRef,
}: ScreenShellProps) => {
  const insets = useSafeAreaInsets();

  const content = scroll ? (
    <KeyboardAwareScrollView
      ref={scrollRef}
      enableOnAndroid
      extraScrollHeight={extraScrollHeight}
      extraHeight={extraHeight}
      keyboardDismissMode="on-drag"
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
      contentContainerStyle={[
        styles.scrollContent,
        safeAreaTop && { paddingTop: insets.top },
        safeAreaBottom && { paddingBottom: insets.bottom },
        contentContainerStyle,
      ]}
    >
      {children}
    </KeyboardAwareScrollView>
  ) : (
    <View style={styles.content}>{children}</View>
  );

  return (
    <View style={[styles.container, style]}>
      <View style={styles.flex}>{content}</View>

      {footer}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },

  flex: {
    flex: 1,
  },

  scrollContent: {
    flexGrow: 1,
  },

  content: {
    flex: 1,
  },
});

export default ScreenShell;