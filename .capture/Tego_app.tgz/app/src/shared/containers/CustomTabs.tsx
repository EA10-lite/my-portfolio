import { useEffect, useRef } from "react";
import {
  Dimensions,
  ScrollView,
  StyleSheet,
  View,
  ViewStyle,
} from "react-native";
import { CustomTab } from "../components";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

export interface CustomTabItem {
  label: string;
  value: string;
  count?: number;
}

interface CustomTabsProps {
  tabs: CustomTabItem[];
  activeTab: string;
  onTabChange: (value: string) => void;
  showCountWhenZero?: boolean;
  style?: ViewStyle;
}

const CustomTabs = ({
  tabs,
  activeTab,
  onTabChange,
  showCountWhenZero = false,
  style,
}: CustomTabsProps) => {
  const scrollRef = useRef<ScrollView>(null);

  const tabLayouts = useRef<Record<string, { x: number; width: number }>>({});

  /**
   * Scroll the active tab into view whenever it changes.
   */
  useEffect(() => {
    const layout = tabLayouts.current[activeTab];

    if (!layout) return;

    const tabCenter = layout.x + layout.width / 2;

    const scrollPosition = tabCenter - SCREEN_WIDTH / 2;

    scrollRef.current?.scrollTo({
      x: Math.max(scrollPosition, 0),
      animated: true,
    });
  }, [activeTab]);

  return (
    <ScrollView
      ref={scrollRef}
      horizontal
      showsHorizontalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={[styles.contentContainer, style]}
    >
      {tabs.map((tab) => (
        <View
          key={tab.value}
          onLayout={(event) => {
            const { x, width } = event.nativeEvent.layout;

            tabLayouts.current[tab.value] = {
              x,
              width,
            };

            /**
             * If this is the currently active tab,
             * ensure it is visible after layout.
             */
            if (tab.value === activeTab) {
              const tabCenter = x + width / 2;

              const scrollPosition = tabCenter - SCREEN_WIDTH / 2;

              scrollRef.current?.scrollTo({
                x: Math.max(scrollPosition, 0),
                animated: false,
              });
            }
          }}
        >
          <CustomTab
            label={tab.label}
            count={tab.count ?? 0}
            isActive={tab.value === activeTab}
            showCountWhenZero={showCountWhenZero}
            handlePress={() => onTabChange(tab.value)}
          />
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    paddingHorizontal: 20,
    gap: 11,
  },
});

export default CustomTabs;
