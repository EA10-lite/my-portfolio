import { create } from "zustand";

type UIState = {
  isMessageWarning: boolean;
  setMessageWarning: (value: boolean) => void;
  isLocationPopupOpen: boolean;
  setLocationPopupOpen: (value: boolean) => void;
};

export const useUIStore = create<UIState>((set) => ({
  isMessageWarning: false,
  setMessageWarning: (value) => set({ isMessageWarning: value }),
  isLocationPopupOpen: true,
  setLocationPopupOpen: (value) => set({ isLocationPopupOpen: value }),
}));
