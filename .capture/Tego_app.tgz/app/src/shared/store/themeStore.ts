import AsyncStorage from "@react-native-async-storage/async-storage";
import { Appearance } from "react-native";
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface ThemeState {
  is_dark: boolean;
  is_system: boolean;
  toggleTheme: () => void;
  useSystemTheme: () => void;
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set, get) => ({
      is_dark: false,
      is_system: true,

      useSystemTheme: () => {
        const systemColorScheme = Appearance.getColorScheme();
        set({
          is_system: true,
          is_dark: systemColorScheme === "dark",
        });
      },

      toggleTheme: () => {
        const next = !get().is_dark;

        set({
          is_dark: next,
          is_system: false, // user override
        });
      },
    }),
    {
      name: "theme-storage",
      storage: {
        getItem: async (name) => {
          const value = await AsyncStorage.getItem(name);
          return value ? JSON.parse(value) : null;
        },
        setItem: async (name, value) => {
          await AsyncStorage.setItem(name, JSON.stringify(value));
        },
        removeItem: async (name) => {
          await AsyncStorage.removeItem(name);
        },
      },
    },
  ),
);
