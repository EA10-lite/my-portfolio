import * as Device from "expo-device";
import * as Location from "expo-location";
import { create } from "zustand";

type State = {
  address: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  latitude: number | null;
  longitude: number | null;
  device_name: string | null;
  device_ip: string | null;
  loading: boolean;
  hasFetched: boolean;
};

type Actions = {
  getCurrentLocation: () => Promise<void>;
};

export const useLocationStore = create<State & Actions>((set, get) => {
  let inFlight = false; // 🔒 HARD LOCK (important)

  return {
    address: null,
    city: null,
    state: null,
    country: null,
    latitude: null,
    longitude: null,
    device_name: null,
    device_ip: null,
    loading: false,
    hasFetched: false,

    getCurrentLocation: async () => {
      const state = get();

      // 🛑 prevent ANY repeat calls
      if (state.hasFetched || inFlight) return;

      inFlight = true;
      set({ loading: true });

      try {
        const { status } = await Location.requestForegroundPermissionsAsync();

        if (status !== "granted") {
          set({ loading: false });
          inFlight = false;
          return;
        }

        const location = await Location.getCurrentPositionAsync({});

        const [place] = await Location.reverseGeocodeAsync({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        });

        // Public IP is best-effort — a failure must not drop the GPS result
        let device_ip: string | null = null;
        try {
          const response = await fetch("https://api.ipify.org?format=json");
          const ipData = await response.json();
          device_ip = ipData.ip ?? null;
        } catch {
          device_ip = null;
        }

        const formattedAddress = [
          place?.streetNumber,
          place?.street,
          place?.district,
          place?.city,
          place?.region,
          place?.country,
        ]
          .filter(Boolean)
          .join(", ");

        set({
          address: formattedAddress || null,
          city: place?.city ?? null,
          state: place?.region ?? null,
          country: place?.country ?? null,
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
          device_name:
            Device.modelName || Device.deviceName || "Unknown Device",
          device_ip,
          hasFetched: true,
          loading: false,
        });
      } catch (e) {
        console.log("Location error:", e);
      } finally {
        inFlight = false;
      }
    },
  };
});