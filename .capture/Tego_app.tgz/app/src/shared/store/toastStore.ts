import { create } from "zustand";

export type ToastType = "success" | "error" | "info";

/**
 * Toast Store
 * 
 * Usage:
 * import { useToastStore } from "@/src/stores/toastStore";
 * 
 * // Show success toast
 * const { showToast } = useToastStore();
 * showToast("Operation successful!", "success");
 * 
 * // Show error toast
 * showToast("Something went wrong", "error");
 */

interface ToastState {
  title: string;
  message: string;
  type: ToastType | null;
  isVisible: boolean;
  showToast: (title: string, message: string) => void;
  hideToast: () => void;
  position: "top" | "bottom";
}

export const useToastStore = create<ToastState>((set) => ({
  message: "",
  title: "",
  type: null,
  isVisible: false,
  // Show a toast with a message and type. Position defaults to bottom
  // so that existing usages without position continue to work as-is.
  showToast: (title: string, message: string) =>
    set({ title, message, isVisible: true }),
  hideToast: () => set({ isVisible: false }),
  position: "top",
}));
