import { PALETTE } from "@/constants/colors";
import AntDesign from "@expo/vector-icons/AntDesign";
import React from "react";
import { StyleSheet, View } from "react-native";
import { CustomText } from "../custom";

interface ErrorProps {
  error?: string | null;
  visible: boolean;
}

const Error: React.FC<ErrorProps> = ({ error, visible }) => {
  if (!visible || !error) return null;

  return (
    <View style={styles.error}>
      <AntDesign name="info-circle" size={16} color={PALETTE.error} />
      <CustomText size="sm">{error}</CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  error: {
    flexDirection: "row",
    gap: 4,
    alignItems: "center",
  },
});

export default Error;
