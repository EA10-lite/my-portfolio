import { PALETTE } from "@/constants/colors";
import { FastField, type FormikValues } from "formik";
import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, TouchableOpacity, View } from "react-native";
import { fastFieldShouldUpdate } from "./fastField";

interface CustomSwitchProps {
  name: string;
  disabled?: boolean;
}

const Switch = (props: CustomSwitchProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <SwitchInner {...props} form={form} />}
    </FastField>
  );
};

const SwitchInner = (props: CustomSwitchProps & { form: FormikValues }) => {
  const { name, disabled = false, form } = props;
  const { values, setFieldValue } = form;

  const value = Boolean(values[name]);
  const thumbPosition = useRef(new Animated.Value(value ? 1 : 0)).current;

  useEffect(() => {
    Animated.spring(thumbPosition, {
      toValue: value ? 1 : 0,
      friction: 6,
      tension: 40,
      useNativeDriver: true,
    }).start();
  }, [value]);

  const toggleSwitch = () => {
    if (!disabled) {
      setFieldValue(name, !value);
    }
  };

  const translateX = thumbPosition.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 16], // moves thumb 11px to the right
  });

  return (
    <TouchableOpacity
      style={[styles.wrapper, disabled && styles.disabled]}
      onPress={toggleSwitch}
      accessibilityRole="switch"
      accessibilityState={{ checked: value, disabled }}
      activeOpacity={0.7}
      // The visible track is only 39×22, far below Android's ~48dp minimum
      // touch target. Expand the touchable area without moving the layout.
      hitSlop={{ top: 16, bottom: 16, left: 10, right: 10 }}
    >
      <View style={[styles.track, value ? styles.trackOn : styles.trackOff]}>
        <Animated.View
          style={[
            styles.thumb,
            value ? styles.thumbOn : styles.thumbOff,
            {
              transform: [{ translateX }],
            },
          ]}
        />
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
  },

  wrapper: {
    padding: 0,
  },

  disabled: {
    opacity: 0.5,
  },

  track: {
    width: 39,
    height: 22,
    borderRadius: 22,
    backgroundColor: PALETTE.primary20,
    borderWidth: 1,
    borderColor: PALETTE.primary50,
    justifyContent: "center",
    paddingHorizontal: 1,
  },

  thumb: {
    width: 17.5,
    height: 17.5,
    borderRadius: 12,
  },
  trackOn: {
    backgroundColor: PALETTE.primary20,
    borderColor: PALETTE.primary50,
  },

  trackOff: {
    backgroundColor: PALETTE.white,
    borderColor: PALETTE.gray200
  },

  thumbOn: {
    backgroundColor: PALETTE.primary,
  },

  thumbOff: {
    backgroundColor: PALETTE.gray200,
  },
});

export default Switch;
