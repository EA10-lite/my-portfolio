import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import { hexToRgba } from "@/shared/utils/converter";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import React, { useState } from "react";
import { StyleSheet, TextInput, View } from "react-native";
import Error from "./Error";

interface TextBoxProps {
  name: string;
  placeholder?: string;
  numberOfLines?: number;
  maxLength?: number;
  onChange?: (text: string) => void;
  disabled?: boolean;
}

const TextBox = (props: TextBoxProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <TextBoxInner {...props} form={form} />}
    </FastField>
  );
};

const TextBoxInner = (props: TextBoxProps & { form: FormikValues }) => {
  const {
    name,
    placeholder,
    numberOfLines = 4,
    maxLength,
    onChange,
    disabled,
    form,
  } = props;
  const { handleChange, values, errors, touched } = form;

  const [isFocused, setIsFocused] = useState<boolean>(false);

  const value = values[name] ?? "";
  const hasError = !!errors?.[name] && !!touched[name];
  const isFilled = value.length > 0 && !isFocused;

  return (
    <View style={styles.container}>
      <View
        style={[
          styles.textBoxContainer,
          isFocused && styles.inputFocused,
          hasError && styles.inputError,
          isFilled && styles.inputFilled,
        ]}
      >
        <TextInput
          style={[
            styles.textBox,
            (isFocused || value.length > 0) && styles.textFocused,
          ]}
          placeholder={placeholder}
          placeholderTextColor={hexToRgba(PALETTE.black, 0.6)}
          value={value}
          onChangeText={onChange ?? handleChange(name)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          multiline
          numberOfLines={numberOfLines}
          maxLength={maxLength}
          textAlignVertical="top" // 👈 text starts at top on Android
          editable={!disabled}
        />
        {maxLength && (
          <View style={styles.counter}>
            <Error error={`${value.length}/${maxLength}`} visible={true} />
          </View>
        )}
      </View>
      <Error
        error={errors?.[name] as string | undefined}
        visible={!!touched[name]}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  textBoxContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    paddingHorizontal: 20,
    paddingVertical: 14,
    minHeight: 103,
  },
  textBox: {
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    color: PALETTE.black,
    opacity: 0.6,
    flex: 1,
    textAlignVertical: "top",
  },
  textFocused: {
    color: PALETTE.black,
    opacity: 1,
  },
  inputFocused: {
    borderColor: PALETTE.primary,
  },
  inputError: {
    borderColor: PALETTE.error,
  },
  inputFilled: {
    borderColor: PALETTE.black,
  },
  counter: {
    alignItems: "flex-end",
    marginTop: 8,
  },
});

export default TextBox;
