import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { hexToRgba } from "@/shared/utils/converter";
import { Pressable, StyleSheet, View } from "react-native";
import { CustomText } from "../custom";
interface RadioSelectorProps<T> {
  label?: string;
  items: T[];
  handleSelect: (item: T) => void;
  selectedValue: string;

  getValue?: (item: T) => string;
  getLabel?: (item: T) => string;
}

const RadioSelector = <T,>({
  label,
  items,
  handleSelect,
  selectedValue,
  getValue = (item) =>
    (item as { value: string }).value,
  getLabel = (item) =>
    (item as { label: string }).label,
}: RadioSelectorProps<T>) => {
  return (
    <View style={styles.field}>
      {label && (
        <CustomText size="sm" weight="semibold">
          {label}
        </CustomText>
      )}

      <View style={styles.items}>
        {items.map((item, index) => {
          const value = getValue(item);
          const label = getLabel(item);

          return (
            <Pressable
              key={value}
              onPress={() => handleSelect(item)}
              style={{
                borderBottomWidth:
                  index + 1 !== items.length ? 1 : 0,
                borderBottomColor:
                  index + 1 !== items.length
                    ? hexToRgba(PALETTE.black, 0.04)
                    : "transparent",
                paddingVertical: 20,
              }}
            >
              <View style={styles.item}>
                <CustomText
                  weight="medium"
                  style={{ fontSize: 13 }}
                >
                  {label}
                </CustomText>

                <View
                  style={[
                    styles.outerRadioBox,
                    CUSTOM_STYLES.center,
                  ]}
                >
                  {selectedValue === value && (
                    <View style={styles.innerRadioBox} />
                  )}
                </View>
              </View>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  field: {
    gap: 20,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  optional: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 50,
  },
  items: {
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 6,
    paddingHorizontal: 16,
  },
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  description: {
    opacity: 0.6,
  },
  outerRadioBox: {
    width: 18,
    height: 18,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: PALETTE.black20,
  },
  innerRadioBox: {
    width: 12,
    height: 12,
    borderRadius: 28,
    backgroundColor: PALETTE.primary,
  },
});

export default RadioSelector;
