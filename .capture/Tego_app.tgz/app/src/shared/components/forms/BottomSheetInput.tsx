import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { TYPOGRAPHY } from "@/constants/typography";
import { hexToRgba } from "@/shared/utils/converter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { BottomSheetTextInput } from "@gorhom/bottom-sheet";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import React, { useState } from "react";
import {
  KeyboardTypeOptions,
  StyleSheet,
  TextStyle,
  View,
} from "react-native";
import { CustomText } from "../custom";
import Error from "./Error";

interface BottomSheetInputProps {
  label?: string;
  name: string;
  placeholder?: string;
  isSecureText?: boolean;
  disabled?: boolean;
  type?: KeyboardTypeOptions;
  ActionButton?: React.ReactElement;
  onChange?: (text: string) => void;
  style?: TextStyle;
  info?: string;
}

const BottomSheetInput = (props: BottomSheetInputProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <BottomSheetInputInner {...props} form={form} />}
    </FastField>
  );
};

const BottomSheetInputInner = (
  props: BottomSheetInputProps & { form: FormikValues },
) => {
  const {
    name,
    placeholder,
    type,
    isSecureText,
    disabled = false,
    onChange,
    info,
    style,
    form,
  } = props;
  const { handleChange, values, errors, touched, setFieldTouched } = form;

  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState<boolean>(false);
  return (
    <View style={styles.container}>
      <View
        style={[
          styles.inputContainer,
          isFocused && styles.inputFocused,
          values[name]?.length > 0 && !isFocused && styles.inputFilled,
          errors?.[name] && !!touched[name] && styles.inputError,
        ]}
      >
        <BottomSheetTextInput
          style={[
            styles.input,
            style,
            (isFocused || values[name]?.length > 0) && styles.textInputFocused,
          ]}
          placeholder={placeholder}
          placeholderTextColor={"#00000088"}
          secureTextEntry={isSecureText && !isPasswordVisible}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            setFieldTouched(name, true);
          }}
          value={values[name] ? values[name] : ""}
          onChangeText={onChange ? onChange : handleChange(name)}
          keyboardType={type as KeyboardTypeOptions}
          editable={!disabled}
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete="off"
          spellCheck={false}
        />
      </View>
      {info && (
        <View style={[CUSTOM_STYLES.row, { gap: 4, alignItems: "center" }]}>
          <AntDesign
            name="info-circle"
            size={12}
            color={hexToRgba(PALETTE.black, 0.6)}
          />
          <CustomText size="xs" weight="regular" style={{ opacity: 0.6 }}>
            {info}
          </CustomText>
        </View>
      )}
      <Error
        error={errors?.[name] as string | undefined}
        visible={!!touched[name]}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  input: {
    height: 56,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    flex: 1,
  },
  inputFocused: {
    borderColor: PALETTE.primary,
  },
  textInputFocused: {
    color: PALETTE.black,
    opacity: 1,
  },
  inputError: {
    borderColor: PALETTE.error,
  },
  inputFilled: {
    borderColor: PALETTE.black,
  },
});

export default BottomSheetInput;