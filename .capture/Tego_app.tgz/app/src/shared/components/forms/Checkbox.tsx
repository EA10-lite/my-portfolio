import { PALETTE } from "@/constants/colors";
import FontAwesome6 from "@expo/vector-icons/FontAwesome6";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { CustomText } from "../custom";

interface CheckboxProps {
  title: string;
  name: string;
}
const Checkbox = (props: CheckboxProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <CheckboxInner {...props} form={form} />}
    </FastField>
  );
};

const CheckboxInner = (props: CheckboxProps & { form: FormikValues }) => {
  const { title, name, form } = props;
  const { values, setFieldValue } = form;
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => setFieldValue(name, !values[name])}
      hitSlop={{ top: 14, bottom: 14 }}
    >
      <View style={[styles.checkbox, values[name] && styles.checkboxChecked]}>
        {values[name] && (
          <FontAwesome6 name="check" size={10} color={PALETTE.white} />
        )}
      </View>
      <CustomText size="sm" weight="medium">
        {title}
      </CustomText>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  checkbox: {
    width: 18,
    height: 18,
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    justifyContent: "center",
    alignItems: "center",
  },
  checkboxChecked: {
    backgroundColor: PALETTE.black,
  },
});

export default Checkbox;
