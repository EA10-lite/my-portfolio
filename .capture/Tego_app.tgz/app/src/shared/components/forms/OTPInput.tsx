import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import { useRef, useState } from "react";
import {
  Dimensions,
  NativeSyntheticEvent,
  StyleSheet,
  TextInput,
  TextInputKeyPressEventData,
  View,
} from "react-native";
import Error from "./Error";

const { width: SCREEN_WIDTH } = Dimensions.get("window");
const HORIZONTAL_PADDING = 40; // matches your screen's paddingHorizontal * 2
const GAP = 8;

interface OTPInputProps {
  name: string;
  length?: number;
}

const OTPInput = (props: OTPInputProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ meta, form }: any) => (
        <OTPInputInner {...props} meta={meta} setFieldValue={form.setFieldValue} />
      )}
    </FastField>
  );
};

const OTPInputInner = ({
  name,
  length = 6,
  meta,
  setFieldValue,
}: OTPInputProps & {
  meta: FormikValues;
  setFieldValue: (
    name: string,
    value: any,
    shouldValidate?: boolean,
  ) => void;
}) => {
  const error = meta.error;
  const touched = meta.touched;

  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);
  const inputRefs = useRef<(TextInput | null)[]>([]);

  const otpValue: string = meta.value ?? "";

  const boxWidth =
    (SCREEN_WIDTH - HORIZONTAL_PADDING - GAP * (length - 1)) / length;

  const handleChange = (text: string, index: number) => {
    // Only take the last character in case somehow multiple are pasted
    const char = text.slice(-1);
    if (!/^\d$/.test(char) && char !== "") return; // digits only

    const otpArray = otpValue.split("");
    otpArray[index] = char;
    const newOtp = otpArray.join("").slice(0, length);
    setFieldValue(name, newOtp);

    // Auto-focus next
    if (char && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (
    e: NativeSyntheticEvent<TextInputKeyPressEventData>,
    index: number,
  ) => {
    if (e.nativeEvent.key === "Backspace") {
      const otpArray = otpValue.split("");

      if (otpArray[index]) {
        // Clear current box
        otpArray[index] = "";
        setFieldValue(name, otpArray.join(""));
      } else if (index > 0) {
        // Move to previous box and clear it
        otpArray[index - 1] = "";
        setFieldValue(name, otpArray.join(""));
        inputRefs.current[index - 1]?.focus();
      }
    }
  };

  const handleFocus = (index: number) => {
    // Prevent user from focusing a box ahead of the current fill position
    const firstEmptyIndex = otpValue.length;
    if (index > firstEmptyIndex) {
      inputRefs.current[firstEmptyIndex]?.focus();
      return;
    }
    setFocusedIndex(index);
  };

  return (
    <View style={styles.container}>
      <View style={[styles.inputRow, { gap: GAP }]}>
        {Array.from({ length }).map((_, index) => {
          const char = otpValue[index] ?? "";
          const isFocused = focusedIndex === index;
          const isFilled = char.length > 0;
          const hasError = !!error && !!touched;

          return (
            <TextInput
              key={index}
              ref={(ref) => {
                inputRefs.current[index] = ref;
              }}
              style={[
                styles.box,
                { width: boxWidth },
                isFocused && styles.boxFocused,
                isFilled && !isFocused && styles.boxFilled,
                hasError && styles.boxError,
              ]}
              value={char}
              onChangeText={(text) => handleChange(text, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
              onFocus={() => handleFocus(index)}
              onBlur={() => setFocusedIndex(null)}
              keyboardType="number-pad"
              maxLength={1}
              textAlign="center"
              selectTextOnFocus
            />
          );
        })}
      </View>
      <Error error={error} visible={!!touched} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  box: {
    height: 56,
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    fontSize: TYPOGRAPHY.fontSize.lg,
    fontFamily: TYPOGRAPHY.fontFamily.bold,
    color: PALETTE.black,
  },
  boxFocused: {
    borderColor: PALETTE.primary,
  },
  boxFilled: {
    borderColor: PALETTE.black,
  },
  boxError: {
    borderColor: PALETTE.error,
  },
});

export default OTPInput;
