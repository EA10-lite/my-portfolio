import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import { formatTimeForDisplay } from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import { useState } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { CustomText, CustomTimePicker } from "../custom";
import Error from "./Error";

interface TimePickerProps {
  name: string;
  placeholder?: string;
}

const TimePicker = (props: TimePickerProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <TimePickerInner {...props} form={form} />}
    </FastField>
  );
};

const TimePickerInner = (props: TimePickerProps & { form: FormikValues }) => {
  const { name, placeholder, form } = props;
  const { errors, values, touched, setFieldValue } = form;
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const hasValue = !!values[name];
  const displayTime = formatTimeForDisplay(values[name]);

  const convertTo24Hour = (time12h: string): string => {
    // "08:30AM" or "08:30PM" → "08:30" or "20:30"
    const period = time12h.slice(-2).toUpperCase(); // "AM" or "PM"
    const [hoursStr, minutesStr] = time12h.slice(0, -2).split(":");
    let hours = parseInt(hoursStr, 10);

    if (period === "PM" && hours !== 12) {
      hours += 12;
    } else if (period === "AM" && hours === 12) {
      hours = 0;
    }

    return `${hours.toString().padStart(2, "0")}:${minutesStr}`;
  };

  const handleTimeChange = (value: string) => {
    setFieldValue(name, convertTo24Hour(value));
  };

  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity
          style={[
            styles.inputContainer,
            isFocused && styles.inputFocused,
            errors[name] && touched[name] && styles.inputError,
            hasValue && !isFocused && styles.inputFilled,
          ]}
          onPress={() => setIsOpen(true)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        >
          <View style={styles.input}>
            <CustomText
              size="sm"
              weight="regular"
              style={
                hasValue ? styles.textInputFocused : styles.placeholderItem
              }
            >
              {hasValue ? displayTime : placeholder}
            </CustomText>
            <Ionicons name="time-outline" size={20} color={PALETTE.primary} />
          </View>
        </TouchableOpacity>
        <Error
          error={errors?.[name] as string | undefined}
          visible={!!touched[name]}
        />
      </View>
      <CustomTimePicker
        visible={isOpen}
        closeModal={() => setIsOpen(false)}
        onChange={handleTimeChange}
      />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    paddingHorizontal: 20,
    justifyContent: "center",
  },
  input: {
    height: 56,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    // color: PALETTE.black,
    // opacity: 0.6,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },
  placeholderItem: {
    color: PALETTE.black,
    opacity: 0.6,
  },
  textInputFocused: {
    color: PALETTE.black,
    opacity: 1,
  },
  inputFocused: {
    borderColor: PALETTE.primary,
  },
  inputError: {
    borderColor: PALETTE.error,
  },
  inputFilled: {
    borderColor: PALETTE.black,
  },
});

export default TimePicker;
