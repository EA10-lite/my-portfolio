import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import { hexToRgba } from "@/shared/utils/converter";
import { BottomSheetTextInput } from "@gorhom/bottom-sheet";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import Error from "./Error";

interface BottomSheetTextBoxProps {
  name: string;
  placeholder?: string;
  numberOfLines?: number;
  maxLength?: number;
  onChange?: (text: string) => void;
  disabled?: boolean;
}

const BottomSheetTextBox = (props: BottomSheetTextBoxProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ meta, form }: any) => (
        <BottomSheetTextBoxInner
          {...props}
          meta={meta}
          handleChange={form.handleChange}
        />
      )}
    </FastField>
  );
};

interface BottomSheetTextboxInnerProps extends BottomSheetTextBoxProps {
  meta: FormikValues;
  handleChange: (name: string) => (e: any) => void;
}

const BottomSheetTextBoxInner = ({
  name,
  placeholder,
  numberOfLines = 4,
  maxLength,
  onChange,
  disabled,
  meta,
  handleChange,
}: BottomSheetTextboxInnerProps) => {
  const value: string = meta.value ?? "";
  const error = meta.error;
  const touched = meta.touched;

  const [isFocused, setIsFocused] = useState<boolean>(false);

  const hasError = !!error && !!touched;
  const isFilled = value.length > 0 && !isFocused;

  return (
    <View style={styles.container}>
      <View
        style={[
          styles.textBoxContainer,
          isFocused && styles.inputFocused,
          hasError && styles.inputError,
          isFilled && styles.inputFilled,
        ]}
      >
        <BottomSheetTextInput
          style={[
            styles.textBox,
            (isFocused || value.length > 0) && styles.textFocused,
          ]}
          placeholder={placeholder}
          placeholderTextColor={hexToRgba(PALETTE.black, 0.6)}
          value={value}
          onChangeText={onChange ?? handleChange(name)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          multiline
          numberOfLines={numberOfLines}
          maxLength={maxLength}
          editable={!disabled}
        />
        {maxLength && (
          <View style={styles.counter}>
            <Error error={`${value.length}/${maxLength}`} visible={true} />
          </View>
        )}
      </View>
      <Error error={error} visible={!!touched} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  textBoxContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    paddingHorizontal: 20,
    paddingVertical: 14,
    minHeight: 103,
  },
  textBox: {
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    color: PALETTE.black,
    opacity: 0.6,
    flex: 1,
    textAlignVertical: "top",
  },
  textFocused: {
    color: PALETTE.black,
    opacity: 1,
  },
  inputFocused: {
    borderColor: PALETTE.primary,
  },
  inputError: {
    borderColor: PALETTE.error,
  },
  inputFilled: {
    borderColor: PALETTE.black,
  },
  counter: {
    alignItems: "flex-end",
    marginTop: 8,
  },
});

export default BottomSheetTextBox;