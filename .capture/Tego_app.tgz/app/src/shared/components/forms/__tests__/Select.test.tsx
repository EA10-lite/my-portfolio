import { fireEvent, screen } from "@testing-library/react-native";
import { Formik } from "formik";
import React from "react";
import { renderWithProviders } from "../../../../testing/render";
import Select from "../Select";

jest.mock("../../custom/Sheet", () => {
  const { View: RNView } = require("react-native");
  const React = require("react");
  return {
    __esModule: true,
    default: React.forwardRef(
      (
        props: { children: React.ReactNode } & Record<string, unknown>,
        ref: unknown,
      ) => React.createElement(RNView, { ref, testID: "mocked-sheet" }, props.children),
    ),
  };
});

jest.mock("@gorhom/bottom-sheet", () => {
  const { TextInput } = require("react-native");
  const React = require("react");
  return {
    __esModule: true,
    BottomSheetModalProvider: ({ children }: { children: React.ReactNode }) =>
      React.createElement(React.Fragment, null, children),
    BottomSheetTextInput: React.forwardRef(
      (props: Record<string, unknown>, ref: unknown) =>
        React.createElement(TextInput, { ...props, ref }),
    ),
  };
});

type Service = {
  id: string;
  service_name: string;
  price: number;
  pricing_type: "FIXED" | "REQUEST_QUOTE";
};

/**
 * Mirrors src/app/(service-provider)/profile/service-offered.tsx exactly:
 * controlled `value` (services_list ids), an `onChange` that rebuilds
 * services_list from ids, an `onCreateOption` that appends the custom
 * option, and a `customLabelResolver` reading names back from the list.
 */
const renderOfferingSelect = async (
  initialServices: Service[],
  options: { label: string; value: string }[],
) => {
  let latestValues: Service[] = initialServices;

  const ui = await renderWithProviders(
    <Formik
      initialValues={{
        services_list: initialServices,
        services_list_ids: initialServices.map((s) => s.id),
      }}
      onSubmit={jest.fn()}
    >
      {({ values, setFieldValue }) => {
        latestValues = values.services_list;
        return (
          <Select
            name="services_list_ids"
            placeholder="Select services"
            options={options}
            value={values.services_list.map((s) => s.id)}
            customLabelResolver={(id) =>
              values.services_list.find((s) => s.id === id)?.service_name
            }
            onChange={(nextIds: string[]) => {
              const updatedList = nextIds.map((id) => {
                const existing = latestValues.find((s) => s.id === id);
                if (existing) return existing;
                const serviceObj = options.find((o) => o.value === id);
                return {
                  id,
                  service_name: serviceObj?.label || "",
                  price: 0,
                  pricing_type: "REQUEST_QUOTE" as const,
                };
              });
              setFieldValue("services_list", updatedList);
            }}
            onCreateOption={(option) => {
              setFieldValue("services_list", [
                ...values.services_list,
                {
                  id: option.value,
                  service_name: option.label,
                  price: 0,
                  pricing_type: "REQUEST_QUOTE" as const,
                },
              ]);
            }}
            allowCustom
            customInputPlaceholder="Enter your own service"
            multiple
          />
        );
      }}
    </Formik>,
  );

  return { ui, latestValues: () => latestValues };
};

describe("Select custom options (provider service-offered flow)", () => {
  it("adds a typed custom service to services_list with its name", async () => {
    const { latestValues } = await renderOfferingSelect([], []);

    const customInput = screen.getByPlaceholderText("Enter your own service");
    await fireEvent.changeText(customInput, "Gardening");
    await fireEvent(customInput, "submitEditing");

    const values = latestValues();
    expect(values).toHaveLength(1);
    expect(values[0].service_name).toBe("Gardening");
  });

  it("keeps the typed custom entry listed and selected", async () => {
    const { latestValues } = await renderOfferingSelect([], []);

    const customInput = screen.getByPlaceholderText("Enter your own service");
    await fireEvent.changeText(customInput, "Gardening");
    await fireEvent(customInput, "submitEditing");

    // Listed as an option row and reflected in the form value (2 = trigger + row).
    expect(screen.getAllByText("Gardening").length).toBe(2);
    expect(latestValues().map((v) => v.service_name)).toEqual(["Gardening"]);
  });

  it("keeps an existing predefined selection when adding a custom", async () => {
    const { latestValues } = await renderOfferingSelect(
      [
        {
          id: "srv-99",
          service_name: "Painting",
          price: 0,
          pricing_type: "REQUEST_QUOTE",
        },
      ],
      [{ label: "Painting", value: "srv-99" }],
    );

    const customInput = screen.getByPlaceholderText("Enter your own service");
    await fireEvent.changeText(customInput, "Flooring");
    await fireEvent(customInput, "submitEditing");

    const values = latestValues();
    expect(values.map((v) => v.service_name)).toEqual(["Painting", "Flooring"]);
  });
});