import { fireEvent, render } from "@testing-library/react-native";
import { Formik } from "formik";
import React from "react";
import Checkbox from "../Checkbox";

// The checkbox box is only 18×18, but the row it sits in is ~20px tall
// (18px box + `sm` label leading). Vertical hitSlop of 14 each side takes the
// interactive row to 48dp. No horizontal hitSlop: the row is wide.
describe("Checkbox touch target", () => {
  it("carries the calculated asymmetric vertical hitSlop", async () => {
    const ui = await render(
      <Formik initialValues={{ rememberMe: false }} onSubmit={jest.fn()}>
        {() => <Checkbox name="rememberMe" title="Remember me" />}
      </Formik>,
    );
    const row = ui.getByText("Remember me").parent as any;
    expect(row.props.hitSlop).toEqual({ top: 14, bottom: 14 });
  });

  it("toggles the bound Formik value on press", async () => {
    let captured: any;
    const ui = await render(
      <Formik
        initialValues={{ rememberMe: false }}
        onSubmit={jest.fn()}
      >
        {({ values }: any) => {
          captured = values;
          return <Checkbox name="rememberMe" title="Remember me" />;
        }}
      </Formik>,
    );

    expect(captured.rememberMe).toBe(false);
    await fireEvent.press(ui.getByText("Remember me"));
    expect(captured.rememberMe).toBe(true);
  });
});