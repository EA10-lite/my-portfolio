import { fastFieldShouldUpdate } from "../fastField";

type Fixture = {
  name?: string;
  formik?: { isSubmitting?: boolean; values?: any; errors?: any; touched?: any };
  children?: any;
  shouldUpdate?: any;
  [key: string]: any;
};

const makeField = (overrides: Fixture = {}): Fixture => ({
  name: "username",
  formik: {
    isSubmitting: false,
    values: { username: "ada" },
    errors: {},
    touched: {},
  },
  ...overrides,
});

describe("fastFieldShouldUpdate", () => {
  it("returns false for two identical fields", () => {
    expect(fastFieldShouldUpdate(makeField(), makeField())).toBe(false);
  });

  it("returns true when the field name changes", () => {
    const next = makeField({ name: "email" });
    expect(fastFieldShouldUpdate(next, makeField())).toBe(true);
  });

  it("returns true when isSubmitting changes", () => {
    const next = makeField({ formik: { ...makeField().formik, isSubmitting: true } });
    expect(fastFieldShouldUpdate(next, makeField())).toBe(true);
  });

  it("returns true when the field's value slice changes (nested paths included)", () => {
    const next = makeField({
      name: "address.city",
      formik: {
        ...makeField().formik,
        values: { address: { city: "Lagos" } },
      },
    });
    const prev = makeField({
      name: "address.city",
      formik: { ...makeField().formik, values: { address: { city: "Abuja" } } },
    });
    expect(fastFieldShouldUpdate(next, prev)).toBe(true);
  });

  it("returns true when the field's error slice changes", () => {
    const next = makeField({
      formik: { ...makeField().formik, errors: { username: "Required" } },
    });
    expect(fastFieldShouldUpdate(next, makeField())).toBe(true);
  });

  it("returns true when the field's touched slice changes", () => {
    const next = makeField({
      formik: { ...makeField().formik, touched: { username: true } },
    });
    expect(fastFieldShouldUpdate(next, makeField())).toBe(true);
  });

  it("returns true when any own prop changes value", () => {
    const next = makeField({ disabled: true });
    expect(fastFieldShouldUpdate(next, makeField({ disabled: false }))).toBe(
      true,
    );
  });

  it("returns true when own-prop values for sibling-derived props change", () => {
    const next = makeField({ options: [{ label: "A", value: "a" }] });
    const prev = makeField({ options: [{ label: "B", value: "b" }] });
    expect(fastFieldShouldUpdate(next, prev)).toBe(true);
  });

  it("returns false when only children/formik/shouldUpdate change", () => {
    const next = makeField({ children: TextNode });
    const prev = makeField({ children: DifferentNode });
    expect(fastFieldShouldUpdate(next, prev)).toBe(false);
  });

  it("returns true when a new prop key is added", () => {
    const next = makeField({ trailing: undefined });
    expect(fastFieldShouldUpdate(next, makeField())).toBe(true);
  });
});

const TextNode = () => null;
const DifferentNode = () => null;