import { fireEvent, render } from "@testing-library/react-native";
import { Formik } from "formik";
import React from "react";
import Input from "../Input";

// The eye toggle is a 19×13 icon — far below 48dp. It must carry the
// calculated asymmetric hitSlop (top/bottom 17 → ~48 tall inside the 56px row;
// left/right limited to avoid the input text). Toggling the eye must still work.
describe("Input eye toggle touch target", () => {
  const eyeToggleFor = (ui: any) => {
    const input = ui.getByPlaceholderText("Password");
    const row = input.parent;
    return row?.children?.find(
      (child: any) => child?.props?.hitSlop != null,
    );
  };

  it("carries the calculated asymmetric hitSlop", async () => {
    const ui = await render(
      <Formik initialValues={{ password: "" }} onSubmit={jest.fn()}>
        {() => <Input name="password" placeholder="Password" isSecureText />}
      </Formik>,
    );
    expect(eyeToggleFor(ui).props.hitSlop).toEqual({
      top: 17,
      bottom: 17,
      left: 8,
      right: 8,
    });
  });

  it("toggles secure text entry without breaking the form value", async () => {
    const ui = await render(
      <Formik initialValues={{ password: "" }} onSubmit={jest.fn()}>
        {() => <Input name="password" placeholder="Password" isSecureText />}
      </Formik>,
    );

    const input = ui.getByPlaceholderText("Password");
    expect(input.props.secureTextEntry).toBe(true);

    await fireEvent.changeText(input, "s3cret");
    expect(ui.getByPlaceholderText("Password").props.value).toBe("s3cret");

    await fireEvent.press(eyeToggleFor(ui));
    expect(ui.getByPlaceholderText("Password").props.secureTextEntry).toBe(
      false,
    );
  });
});