import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { TYPOGRAPHY } from "@/constants/typography";
import { BottomSheetTextInput } from "@gorhom/bottom-sheet";
import { getIn, useFormikContext, type FormikValues } from "formik";
import { useRef, useState } from "react";
import {
  Dimensions,
  Keyboard,
  Pressable,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { CustomButton, CustomText } from "../custom";
import Sheet from "../custom/Sheet";
import { Arrow } from "../general";
import Error from "./Error";
import { useModalState } from "@/shared/hooks/useModalState";

// const MAX_SHEET_HEIGHT = Math.round(Dimensions.get("window").height * 0.6);

interface SelectOption {
  label: string;
  value: string;
}

interface SelectProps {
  name: string;
  placeholder?: string;
  disabled?: boolean;
  options: SelectOption[];
  multiple?: boolean;
  onChange?: (value: any) => void;
  value?: any;
  customLabelResolver?: (value: string) => string | undefined;

  /**
   * When true, show an input inside the BottomSheet
   * that allows users to create their own options.
   */
  allowCustom?: boolean;

  /**
   * Called after Select creates a custom option.
   * The same option that was added to the list is passed here.
   */
  onCreateOption?: (option: SelectOption) => void;

  customInputPlaceholder?: string;
  emptyStateMessage?: string;
}

/**
 * Select is a fully controlled component: its `value`/`options` (and the
 * labels resolved via `customLabelResolver`) are derived from *sibling* form
 * values (e.g. `services_list` in service-offered), never from its own field
 * slice. A FastField would gate those updates away (it ignores the render
 * closure), so the parent's writes to a sibling field would never reach the
 * trigger or option rows. Subscribing to the whole form context keeps the
 * component in sync with any values change.
 */
const Select = (props: SelectProps) => {
  const { name } = props;
  const formik = useFormikContext();

  const meta: FormikValues = {
    value: getIn(formik.values, name),
    error: getIn(formik.errors, name),
    touched: !!getIn(formik.touched, name),
  };

  return (
    <SelectInner
      {...props}
      meta={meta}
      setFieldValue={formik.setFieldValue}
    />
  );
};

interface SelectInnerProps extends SelectProps {
  meta: FormikValues;
  setFieldValue: (
    name: string,
    value: any,
    shouldValidate?: boolean,
  ) => void;
}

const SelectInner = ({
  name,
  placeholder,
  options,
  disabled,
  multiple = false,
  onChange,
  value: controlledValue,
  customLabelResolver,
  allowCustom = false,
  onCreateOption,
  customInputPlaceholder = "Add Custom",
  emptyStateMessage,
  meta,
  setFieldValue,
}: SelectInnerProps) => {
  const error = meta.error;
  const touched = meta.touched;

  const [isFocused, setIsFocused] = useState(false);
  const [customLabel, setCustomLabel] = useState("");

  /**
   * Custom options created by the user.
   *
   * These are separate from the predefined `options`
   * because `options` comes from the parent/category.
   */
  const [customOptions, setCustomOptions] = useState<SelectOption[]>([]);

  const sheetRef = useModalState();
  const customInputRef = useRef<any>(null);

  const rawValue =
    controlledValue !== undefined ? controlledValue : meta.value;

  const selectedValues: string[] = multiple
    ? Array.isArray(rawValue)
      ? rawValue
      : []
    : rawValue
      ? [rawValue]
      : [];

  const hasValue = selectedValues.length > 0;

  /**
   * Options the parent already saved which are NOT predefined.
   *
   * These exist in the form value (e.g. `services_list` ids) but are not
   * part of the current `options` or the session's `customOptions`. We
   * reconstruct them (using `customLabelResolver` for the label) so they:
   *   1. render in the list and show as already-selected, and
   *   2. participate in the duplicate-check when adding new customs.
   */
  const savedCustomOptions: SelectOption[] = selectedValues
    .filter(
      (value) =>
        !options.some((option) => option.value === value) &&
        !customOptions.some((option) => option.value === value),
    )
    .map((value) => ({
      value,
      label: customLabelResolver?.(value) ?? value,
    }));

  /**
   * Combine predefined options, options created this session, and options
   * already saved by the parent, then deduplicate by label (case-insensitive).
   *
   * Deduplication is needed because the predefined `options` (from
   * category_services) may have different ids than the saved services
   * (from the API). Keeping the first occurrence means the predefined
   * row wins; the saved row is dropped. The saved value's id is still
   * in `selectedValues`, so `isSelected` on the predefined row is true.
   */
  const allOptions = [
    ...options,
    ...customOptions,
    ...savedCustomOptions,
  ].filter((option, index, list) => {
    const duplicateIndex = list.findIndex(
      (item) => item.label.toLowerCase() === option.label.toLowerCase(),
    );
    return duplicateIndex === index;
  });

  const openSheet = () => {
    sheetRef.open();
    Keyboard.dismiss();
  };

  /**
   * Select/deselect an existing option.
   */
  const handleSelect = (value: string) => {
    if (!multiple) {
      if (onChange) {
        onChange(value);
      } else {
        setFieldValue(name, value);
      }

      sheetRef.close();
      return;
    }

    const alreadySelected = selectedValues.includes(value);

    const next = alreadySelected
      ? selectedValues.filter((item) => item !== value)
      : [...selectedValues, value];

    if (onChange) {
      onChange(next);
    } else {
      setFieldValue(name, next);
    }
  };

  /**
   * Create a completely new option.
   *
   * Example:
   *
   * User types:
   * "Car Washing"
   *
   * We create:
   *
   * {
   *   label: "Car Washing",
   *   value: "custom-123"
   * }
   *
   * Then:
   * 1. Add it to customOptions
   * 2. Automatically select it
   * 3. Tell the parent about it
   * 4. Clear the input
   */
  const handleAddCustom = () => {
    const label = customLabel.trim();

    if (!label) return;

    /**
     * Prevent creating the exact same custom option twice.
     */
    const alreadyExists = allOptions.some(
      (option) => option.label.toLowerCase() === label.toLowerCase(),
    );

    if (alreadyExists) {
      setCustomLabel("");
      return;
    }

    const id = `custom-${Date.now()}`;

    const newOption: SelectOption = {
      label,
      value: id,
    };

    /**
     * 1. Add to the Select's option list.
     */
    setCustomOptions((prev) => [...prev, newOption]);

    /**
     * 2. Automatically select the new option.
     */
    if (multiple) {
      const nextValues = selectedValues.includes(id)
        ? selectedValues
        : [...selectedValues, id];

      if (onChange) {
        onChange(nextValues);
      } else {
        setFieldValue(name, nextValues);
      }
    } else {
      if (onChange) {
        onChange(id);
      } else {
        setFieldValue(name, id);
      }

      sheetRef.close();
    }

    /**
     * 3. Tell the parent about the newly-created option.
     *
     * The parent receives the exact same ID that was selected.
     */
    onCreateOption?.(newOption);

    /**
     * 4. Clear the input.
     */
    setCustomLabel("");

    /**
     * 5. In multiple mode, keep the sheet open
     * and allow the user to immediately type another option.
     */
  };

  /**
   * Focus the custom input when the sheet opens.
   */
  /**
   * Reset custom options when the sheet closes.
   *
   * The predefined `options` list (and the parent context, e.g. selected
   * category) may have changed while the sheet was open. Starting fresh on
   * each open avoids showing stale custom options from a previous context.
   */
  const handleSheetClose = () => {
    setCustomOptions([]);
    setCustomLabel("");
  };

  const handleSheetOpen = () => {
    if (!allowCustom) return;

    setTimeout(() => {
      customInputRef.current?.focus();
    }, 250);
  };

  const getDisplayLabel = () => {
    if (!hasValue) {
      return placeholder;
    }

    /**
     * Single select
     */
    if (!multiple) {
      const value = selectedValues[0];

      return (
        customLabelResolver?.(value) ??
        allOptions.find((option) => option.value === value)?.label ??
        value
      );
    }

    /**
     * Multiple select
     */
    const [first, ...rest] = selectedValues;

    const firstLabel =
      customLabelResolver?.(first) ??
      allOptions.find((option) => option.value === first)?.label ??
      first;

    return rest.length > 0
      ? `${firstLabel} + ${rest.length} ${
          rest.length === 1 ? "other" : "others"
        }`
      : firstLabel;
  };

  return (
    <>
      <View style={styles.container}>
        <TouchableOpacity
          style={[
            styles.inputContainer,
            isFocused && styles.inputFocused,
            error && touched && styles.inputError,
            hasValue && !isFocused && styles.inputFilled,
          ]}
          onPress={openSheet}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          disabled={disabled}
        >
          <View style={styles.input}>
            <CustomText
              size="sm"
              weight="regular"
              style={
                hasValue
                  ? styles.textInputFocused
                  : styles.placeholderItem
              }
            >
              {getDisplayLabel()}
            </CustomText>

            <Arrow
              direction="bottom"
              size={18}
              color={PALETTE.primary}
            />
          </View>
        </TouchableOpacity>

        <Error error={error} visible={!!touched} />
      </View>

      <Sheet
        ref={sheetRef.ref}
        onOpen={handleSheetOpen}
        onClose={handleSheetClose}
      >
        <View style={styles.sheetHeader}>
          <CustomText
            weight="bold"
            size="sm"
            style={{ letterSpacing: -0.24 }}
          >
            {placeholder || "Option"}
          </CustomText>
        </View>

        {/* Custom option input */}
        {allowCustom && (
          <View style={styles.customInputContainer}>
            <BottomSheetTextInput
              ref={customInputRef}
              style={[
                styles.customInput,
                isFocused && styles.customInputFocused,
                customLabel.length > 0 &&
                  !isFocused &&
                  styles.customInputFilled,
              ]}
              placeholder={customInputPlaceholder}
              placeholderTextColor="#00000088"
              value={customLabel}
              onChangeText={setCustomLabel}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              onSubmitEditing={handleAddCustom}
              returnKeyType="done"
              autoCapitalize="none"
              autoCorrect={false}
              autoComplete="off"
              spellCheck={false}
            />

            {emptyStateMessage && allOptions.length === 0 && (
              <CustomText
                size="xs"
                weight="regular"
                style={styles.emptyStateMessage}
              >
                {emptyStateMessage}
              </CustomText>
            )}
          </View>
        )}

        {/* Options */}
        <View style={styles.options}>
          {allOptions.map((option) => {
            const isSelected = selectedValues.includes(option.value);

            return (
              <Pressable
                key={option.value}
                onPress={() => handleSelect(option.value)}
              >
                <View style={styles.option}>
                  <CustomText
                    weight="semibold"
                    style={{ fontSize: 13 }}
                  >
                    {option.label}
                  </CustomText>

                  <View
                    style={[
                      styles.radioOuter,
                      CUSTOM_STYLES.center,
                    ]}
                  >
                    {isSelected && (
                      <View style={styles.radioInner} />
                    )}
                  </View>
                </View>
              </Pressable>
            );
          })}

          {multiple && (
            <View style={styles.continueContainer}>
              <CustomButton
                title="Continue"
                disabled={selectedValues.length === 0}
                onPress={() => sheetRef.close()}
              />
            </View>
          )}
        </View>
      </Sheet>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },

  inputContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    paddingHorizontal: 20,
    justifyContent: "center",
  },

  input: {
    height: 56,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
  },

  placeholderItem: {
    color: PALETTE.black,
    opacity: 0.6,
  },

  textInputFocused: {
    color: PALETTE.black,
    opacity: 1,
  },

  inputFocused: {
    borderColor: PALETTE.primary,
  },

  inputError: {
    borderColor: PALETTE.error,
  },

  inputFilled: {
    borderColor: PALETTE.black,
  },

  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },

  /**
   * Custom input wrapper
   */
  customInputContainer: {
    marginBottom: 24,
  },

  /**
   * Designed to match the regular Input component.
   */
  customInput: {
    height: 56,
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    paddingHorizontal: 20,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    color: PALETTE.black,
  },

  customInputFocused: {
    borderColor: PALETTE.primary,
  },

  customInputFilled: {
    borderColor: PALETTE.black,
  },

  emptyStateMessage: {
    marginTop: 10,
    opacity: 0.6,
  },

  options: {
    gap: 12,
  },

  option: {
    backgroundColor: PALETTE.gray,
    padding: 20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  radioOuter: {
    width: 16,
    height: 16,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: PALETTE.black,
    opacity: 0.8,
  },

  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 20,
    backgroundColor: PALETTE.primary,
  },

  continueContainer: {
    marginTop: 24,
  },
});

export default Select;