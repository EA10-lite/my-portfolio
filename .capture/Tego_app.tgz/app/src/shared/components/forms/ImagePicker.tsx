import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import ImagePreviewModal from "../general/ImagePreviewModal";
import AntDesign from "@expo/vector-icons/AntDesign";
import * as ExpoImagePicker from "expo-image-picker";
import { FastField, type FormikValues } from "formik";
import { useState } from "react";
import { Pressable, StyleSheet, TouchableOpacity, View } from "react-native";
import { CImg, ImagePickerPlaceholder } from "../general";
import { fastFieldShouldUpdate } from "./fastField";

interface ImagePickerProps {
  name: string;
  label: string;
  maxImages?: number;
}

const ImagePicker = (props: ImagePickerProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ meta, form }: any) => (
        <ImagePickerInner
          {...props}
          meta={meta}
          setFieldValue={form.setFieldValue}
        />
      )}
    </FastField>
  );
};

const ImagePickerInner = ({
  label,
  name,
  maxImages = 5,
  meta,
  setFieldValue,
}: ImagePickerProps & {
  meta: FormikValues;
  setFieldValue: (name: string, value: any, shouldValidate?: boolean) => void;
}) => {
  const images: string[] = meta.value ?? [];

  const handlePick = async () => {
    if (images.length >= maxImages) return;

    const result = await ExpoImagePicker.launchImageLibraryAsync({
      mediaTypes: ExpoImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
      selectionLimit: maxImages - images.length, // 👈 only allow remaining slots
    });

    if (!result.canceled) {
      const newUris = result.assets.map((a) => a.uri);
      setFieldValue(name, [...images, ...newUris]);
    }
  };

  const handleRemove = (index: number) => {
    const updated = images.filter((_, i) => i !== index);
    setFieldValue(name, updated);
  };

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [index, setIndex] = useState<number>(0);

  const handleImageClick = (index: number) => {
    setIndex(index);
    setIsOpen(true);
  };

  return (
    <View style={styles.pickerContainer}>
      <ImagePickerPlaceholder
        label={label}
        handlePick={handlePick}
        images={images}
        maxImages={maxImages}
      />

      {images.length > 0 && (
        <View style={styles.preview}>
          {images.map((uri, index) => (
            <TouchableOpacity
              onPress={() => handleImageClick(index)}
              key={index}
              style={styles.previewItem}
            >
              <View>
                <CImg uri={uri} width={400} style={styles.previewImage} />

                <Pressable
                  style={[styles.removeButton, CUSTOM_STYLES.center]}
                  onPress={() => handleRemove(index)}
                  hitSlop={{ top: 12, bottom: 18, left: 18, right: 10 }}
                >
                  <AntDesign name="close" size={12} color={PALETTE.error} />
                </Pressable>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <ImagePreviewModal
        visible={isOpen}
        images={images}
        selectedIndex={index}
        handleClose={() => setIsOpen(false)}
        canDownload={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  pickerContainer: {
    gap: 12,
  },

  preview: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 7,
  },

  previewItem: {
    width: "31.8%",
    aspectRatio: 1,
    position: "relative",
  },

  previewImage: {
    width: "100%",
    height: "100%",
    borderRadius: 7,
  },
  removeButton: {
    position: "absolute",
    top: 6,
    right: 6,
    backgroundColor: PALETTE.white,
    borderRadius: 50,
    width: 18,
    height: 18,
    zIndex: 1,
  },
});

export default ImagePicker;
