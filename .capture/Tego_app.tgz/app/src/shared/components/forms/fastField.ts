import { getIn } from "formik";
import isEqual from "react-fast-compare";

type FieldRenderProps = {
  name?: any;
  formik?: any;
  children?: any;
  shouldUpdate?: any;
};

const stripFormikProps = (props: FieldRenderProps) => {
  const { children, formik, shouldUpdate, ...ownProps } = props;
  return ownProps;
};

/**
 * `shouldUpdate` for <FastField>. Re-renders the field when its own
 * value/error/touched slice, `isSubmitting`, `name`, or any of its own props
 * change value. This is stricter than FastField's default (which only diffs
 * the field slice and the prop-key count), so fields whose props are derived
 * from sibling fields (e.g. `disabled`, `options`, `value`) stay in sync
 * without re-subscribing the whole form to the field.
 */
export const fastFieldShouldUpdate = (
  next: FieldRenderProps,
  prev: FieldRenderProps,
) => {
  if (
    next?.name !== prev?.name ||
    next?.formik?.isSubmitting !== prev?.formik?.isSubmitting ||
    getIn(next?.formik?.values, next?.name) !==
      getIn(prev?.formik?.values, next?.name) ||
    getIn(next?.formik?.errors, next?.name) !==
      getIn(prev?.formik?.errors, next?.name) ||
    getIn(next?.formik?.touched, next?.name) !==
      getIn(prev?.formik?.touched, next?.name)
  ) {
    return true;
  }

  return !isEqual(stripFormikProps(prev), stripFormikProps(next));
};