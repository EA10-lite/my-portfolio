// shared/components/form/DatePicker.tsx
import CalendarIcon from "@/assets/images/app-icons/date.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { TYPOGRAPHY } from "@/constants/typography";
import Ionicons from "@expo/vector-icons/Ionicons";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Dimensions,
  Keyboard,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { CustomText } from "../custom";
import { Arrow } from "../general";
import Error from "./Error";

const ARROW_SIZE = 14;

interface DatePickerProps {
  name: string;
  placeholder?: string;
  disabled?: boolean;
  minDate?: Date;
  value: Date | string;
}

const DatePicker = (props: DatePickerProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <DatePickerInner {...props} form={form} />}
    </FastField>
  );
};

const DatePickerInner = (props: DatePickerProps & { form: FormikValues }) => {
  const {
    name,
    placeholder = "Select date",
    disabled = false,
    minDate = new Date(),
    form,
  } = props;
  const normalizedMinDate = useMemo(() => {
    const date = new Date(minDate);
    date.setHours(0, 0, 0, 0);
    return date;
  }, [minDate]);
  const { values, errors, touched, setFieldValue } = form;

  const value = values[name];

  const [isModalOpen, setIsModalOpen] = useState(false);

  const monthNames = useMemo(
    () => [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ],
    [],
  );
  const years = useMemo(
    () => ["2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033"],
    [],
  );

  // Parse incoming value
  const initialDate = useMemo(() => {
    if (value instanceof Date) return value;

    if (typeof value === "string" && value.trim().length > 0) {
      const s = value.trim();

      // ISO yyyy-mm-dd
      const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
      if (iso) {
        const y = Number(iso[1]);
        const m = Number(iso[2]) - 1;
        const d = Number(iso[3]);

        const local = new Date(y, m, d);

        if (
          local.getFullYear() === y &&
          local.getMonth() === m &&
          local.getDate() === d
        ) {
          return local;
        }
      }

      // Legacy dd-Month-yyyy
      const legacy = /^(\d{1,2})-([A-Za-z]+)-(\d{4})$/.exec(s);

      if (legacy) {
        const d = Number(legacy[1]);
        const monthIdx = monthNames.findIndex((month) => month === legacy[2]);
        const y = Number(legacy[3]);

        if (monthIdx >= 0) {
          return new Date(y, monthIdx, d);
        }
      }

      const parsed = new Date(s);

      if (!isNaN(parsed.getTime())) {
        return parsed;
      }
    }

    return new Date();
  }, [value, monthNames]);

  const [currentMonth, setCurrentMonth] = useState(initialDate.getMonth());

  const [currentYear, setCurrentYear] = useState(initialDate.getFullYear());

  const [selectedDate, setSelectedDate] = useState<Date | null>(initialDate);

  const weekDays = ["S", "M", "T", "W", "T", "F", "S"];

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay();
  };

  const daysInMonth = useMemo(
    () => getDaysInMonth(currentMonth, currentYear),
    [currentMonth, currentYear],
  );

  const firstDayIndex = useMemo(
    () => getFirstDayOfMonth(currentMonth, currentYear),
    [currentMonth, currentYear],
  );

  const toISODateString = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");

    return `${y}-${m}-${d}`;
  };

  const goPrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((prev) => prev - 1);
    } else {
      setCurrentMonth((prev) => prev - 1);
    }
  };

  const goNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((prev) => prev + 1);
    } else {
      setCurrentMonth((prev) => prev + 1);
    }
  };

  const handleSelectDay = (day: number) => {
    const chosen = new Date(currentYear, currentMonth, day);
  
    chosen.setHours(0, 0, 0, 0);
  
    if (chosen < normalizedMinDate) return;
  
    setSelectedDate(chosen);
    setFieldValue(name, chosen);
    setIsModalOpen(false);
  };

  useEffect(()=> {
    setFieldValue(name, selectedDate)
  }, [selectedDate])

  const [isOpen, setIsOpen] = useState<"month" | "year" | null>(null);

  const scrollRef = useRef<ScrollView>(null);
  const [isScrolledToBottom, setIsScrolledToBottom] = useState(false);

  const renderDropdown = (
    item: string[],
    handleSelect: (value: number) => void,
    selectedValue: string | number,
  ) => {
    const select = (index: number) => {
      handleSelect(isOpen === "year" ? Number(item[index]) : index);

      setIsOpen(null);
    };

    const handleScrollToggle = () => {
      if (isScrolledToBottom) {
        scrollRef.current?.scrollTo({
          y: 0,
          animated: true,
        });
        setIsScrolledToBottom(false);
      } else {
        scrollRef.current?.scrollToEnd({
          animated: true,
        });
        setIsScrolledToBottom(true);
      }
    };

    return (
      <View style={styles.monthPicker}>
        <ScrollView
          ref={scrollRef}
          contentContainerStyle={{ gap: 14 }}
          showsVerticalScrollIndicator={false}
          onScroll={(event) => {
            const { layoutMeasurement, contentOffset, contentSize } =
              event.nativeEvent;

            const isBottom =
              layoutMeasurement.height + contentOffset.y >=
              contentSize.height - 10;

            const isTop = contentOffset.y <= 10;

            if (isBottom) {
              setIsScrolledToBottom(true);
            } else if (isTop) {
              setIsScrolledToBottom(false);
            }
          }}
          scrollEventThrottle={16}
        >
          {item.map((i, index) => {
            const isSelected =
              isOpen === "year"
                ? Number(i) === selectedValue
                : index === selectedValue;

            return (
              <Pressable
                style={[
                  CUSTOM_STYLES.row,
                  styles.month,
                  isSelected && {
                    backgroundColor: PALETTE.grey01,
                  },
                ]}
                key={index}
                onPress={() => select(index)}
              >
                <CustomText size="xs" weight="medium">
                  {isOpen === "month" ? i.slice(0, 3) : i}
                </CustomText>

                {isSelected && (
                  <Ionicons
                    name="checkmark-circle"
                    color={PALETTE.primary}
                    size={14}
                  />
                )}
              </Pressable>
            );
          })}
        </ScrollView>

        <Pressable style={styles.scroll} onPress={handleScrollToggle}>
          <Arrow direction={isScrolledToBottom ? "top" : "bottom"} />
        </Pressable>
      </View>
    );
  };

  return (
    <>
      <View style={styles.container}>
        <Pressable
          onPress={() => {
            setIsModalOpen(true)
            Keyboard.dismiss();
          }}
          disabled={disabled}
        >
          <View
            style={[
              styles.inputContainer,
              values[name] && styles.inputFilled,
              disabled && styles.inputDisabled,
            ]}
          >
            <TextInput
              style={[styles.input, values[name] && styles.textInputFocused]}
              placeholder={placeholder}
              placeholderTextColor="#00000088"
              value={selectedDate ? toISODateString(selectedDate) : ""}
              editable={false}
              pointerEvents="none"
            />

            <CalendarIcon width={20} height={20} color={PALETTE.primary} />
          </View>
        </Pressable>

        <Error
          error={errors?.[name] as string | undefined}
          visible={!!touched[name]}
        />
      </View>

      {/* Modal */}
      <Modal
        visible={isModalOpen}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setIsModalOpen(false)}
      >
        <Pressable
          style={styles.backdrop}
          onPress={() => {
            setIsModalOpen(false);
            setIsOpen(null);
          }}
        >
          <Pressable
            style={styles.modalContent}
            onPress={(e) => {
              e.stopPropagation();
              if (isOpen) {
                setIsOpen(null);
              }
            }}
          >
            {/* Header */}
            <View style={[styles.modalHeader, CUSTOM_STYLES.row]}>
              <Pressable
                style={[CUSTOM_STYLES.center, styles.navButton]}
                onPress={goPrevMonth}
                hitSlop={12}
              >
                <Arrow direction="left" size={ARROW_SIZE} />
              </Pressable>

              <View style={[CUSTOM_STYLES.row, styles.dateDisplay]}>
                <Pressable
                  style={[CUSTOM_STYLES.row, { gap: 4 }]}
                  onPress={() => setIsOpen("month")}
                >
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={{
                      textTransform: "uppercase",
                    }}
                  >
                    {monthNames[currentMonth].slice(0, 3)}
                  </CustomText>

                  <Arrow direction="bottom" size={ARROW_SIZE} />
                </Pressable>

                <View style={styles.divider} />

                <Pressable
                  style={[CUSTOM_STYLES.row, { gap: 4 }]}
                  onPress={() => setIsOpen("year")}
                >
                  <CustomText size="xs" weight="medium">
                    {currentYear}
                  </CustomText>

                  <Arrow direction="bottom" size={ARROW_SIZE} />
                </Pressable>

                {isOpen === "month" &&
                  renderDropdown(monthNames, setCurrentMonth, currentMonth)}
                {isOpen === "year" &&
                  renderDropdown(years, setCurrentYear, currentYear)}
              </View>

              <Pressable
                style={[CUSTOM_STYLES.center, styles.navButton]}
                onPress={goNextMonth}
                hitSlop={12}
              >
                <Arrow direction="right" size={ARROW_SIZE} />
              </Pressable>
            </View>

            {/* Body */}
            <View style={styles.modalBody}>
              {/* Week Labels */}
              <View style={styles.weekLabel}>
                {weekDays.map((day, index) => (
                  <View key={index} style={styles.calendarCell}>
                    <CustomText size="xs" weight="semibold">
                      {day}
                    </CustomText>
                  </View>
                ))}
              </View>

              {/* Calendar */}
              <View style={styles.calendarContainer}>
                {/* Empty cells */}
                {Array.from({
                  length: firstDayIndex,
                }).map((_, idx) => (
                  <View key={`empty-${idx}`} style={styles.calendarCell} />
                ))}

                {/* Days */}
                {Array.from({
                  length: daysInMonth,
                }).map((_, i) => {
                  const dayNum = i + 1;

                  const currentDate = new Date(
                    currentYear,
                    currentMonth,
                    dayNum,
                  );

                  const isSelected =
                    selectedDate?.getFullYear() === currentYear &&
                    selectedDate?.getMonth() === currentMonth &&
                    selectedDate?.getDate() === dayNum;

                  const isDisabled = currentDate < normalizedMinDate;

                  return (
                    <View key={dayNum} style={styles.calendarCell}>
                      <Pressable
                        disabled={isDisabled}
                        onPress={() => handleSelectDay(dayNum)}
                        hitSlop={{ top: 5, bottom: 5, left: 4, right: 4 }}
                        style={[
                          CUSTOM_STYLES.center,
                          styles.day,
                          {
                            backgroundColor: isSelected
                              ? PALETTE.primary
                              : PALETTE.gray,
                            opacity: isDisabled ? 0.35 : 1,
                          },
                        ]}
                      >
                        <CustomText
                          size="xs"
                          weight="medium"
                          style={{
                            color: isSelected ? PALETTE.white : PALETTE.black,
                          }}
                        >
                          {dayNum}
                        </CustomText>
                      </Pressable>
                    </View>
                  );
                })}
              </View>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },

  inputContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
    height: 56,
  },

  input: {
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    flex: 1,
    color: PALETTE.black,
  },

  textInputFocused: {
    opacity: 1,
  },

  inputFilled: {
    borderColor: PALETTE.black,
  },

  inputDisabled: {
    opacity: 0.5,
  },

  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.89)",
    justifyContent: "center",
    alignItems: "center",
  },

  modalContent: {
    backgroundColor: PALETTE.white,
    borderRadius: 10,
    width: Dimensions.get("window").width * 0.9,
    maxHeight: Dimensions.get("window").height * 0.8,
    borderWidth: 0.5,
    borderColor: PALETTE.primary20,
  },

  modalHeader: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: PALETTE.gray,
    justifyContent: "space-between",
  },

  dateDisplay: {
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: PALETTE.grey01,
    position: "relative",
  },

  monthPicker: {
    position: "absolute",
    top: 43,
    width: 121,
    height: 258,
    backgroundColor: PALETTE.white,
    padding: 10,
    borderRadius: 6,
    zIndex: 8,
    elevation: 4,
    shadowColor: "#33ABF7",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1, // from 1A alpha ≈ 10%
    shadowRadius: 12, // 24px blur ≈ 12 radius in RN
  },
  month: {
    borderRadius: 3,
    padding: 4,
    justifyContent: "space-between",
  },

  scroll: {
    paddingVertical: 4,
    backgroundColor: PALETTE.white,
    shadowColor: "#33ABF7",
    shadowOffset: {
      width: 0,
      height: -7, // negative for top shadow
    },
    shadowOpacity: 0.06, // 0F alpha ≈ 6%
    shadowRadius: 8.5, // 17px blur ≈ half in RN
    elevation: 2,
  },

  divider: {
    width: 1,
    marginHorizontal: 8,
    height: 25,
    backgroundColor: PALETTE.grey01,
  },

  modalBody: {
    paddingHorizontal: 10,
    paddingTop: 28,
    paddingBottom: 20,
  },

  weekLabel: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingBottom: 12,
    marginBottom: 4,
  },

  calendarContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
  },

  // Exactly 7 columns
  calendarCell: {
    width: `${100 / 7}%`,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 10,
  },

  navButton: {
    width: 25,
    height: 25,
    borderRadius: 50,
    backgroundColor: PALETTE.grey01,
  },

  day: {
    width: 38,
    height: 38,
    borderRadius: 19,
  },
});

export default DatePicker;
