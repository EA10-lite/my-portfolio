import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import XIcon from "@expo/vector-icons/AntDesign";
import { FastField, getIn, type FormikValues } from "formik";
import NaijaStates from "naija-state-local-government";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Animated,
  KeyboardTypeOptions,
  Pressable,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { CustomText } from "../custom";
import Error from "./Error";
import { fastFieldShouldUpdate } from "./fastField";
import Select from "./Select";

interface InputProps {
  name: string;
  isEditable?: boolean;
  type?: KeyboardTypeOptions;
  onChange?: (text: string) => void;
  state: string;
  address: string;
  nested?: boolean;
  stateFieldName?: string;
}

const AddressInput = (props: InputProps) => {
  const { name, nested = true, stateFieldName = "state" } = props;
  return (
    <FastField
      name={name}
      shouldUpdate={(next: any, prev: any) => {
        if (!nested) {
          const tracked = [name, stateFieldName];
          const sliceChanged = tracked.some(
            (field) =>
              getIn(next.formik.values, field) !==
                getIn(prev.formik.values, field) ||
              getIn(next.formik.errors, field) !==
                getIn(prev.formik.errors, field) ||
              getIn(next.formik.touched, field) !==
                getIn(prev.formik.touched, field),
          );
          if (sliceChanged) return true;
        }
        return fastFieldShouldUpdate(next, prev);
      }}
    >
      {({ form }: any) => <AddressInputInner {...props} form={form} />}
    </FastField>
  );
};

const AddressInputInner = (props: InputProps & { form: FormikValues }) => {
  const {
    name,
    type,
    isEditable,
    onChange,
    address,
    state,
    nested = true,
    stateFieldName = "state",
    form,
  } = props;
  const { handleChange, values, errors, touched, setFieldValue } = form;

  const [isFocused, setIsFocused] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const inputRef = useRef<TextInput>(null);

  // Only used for the collapsed "grey bar" animation (when hasValue and not editing)
  const editBoxHeight = useRef(new Animated.Value(0)).current;
  const editBoxOpacity = useRef(new Animated.Value(0)).current;

  const [selectedState, setSelectedState] = useState<string>(
    nested
      ? (values[name]?.state ?? state ?? "")
      : (values[stateFieldName] ?? state ?? ""),
  );

  const hasValue = nested ? !!values[name]?.address : !!values[name];

  useEffect(() => {
    const currentState = nested ? values[name]?.state : values[stateFieldName];
    if (currentState) {
      setSelectedState(currentState);
    }
  }, [nested ? values[name]?.state : values[stateFieldName]]);

  const stateOptions = useMemo(
    () =>
      (NaijaStates.states() as string[]).map((s) => ({
        label: s,
        value: s,
      })),
    [],
  );

  const isExpanded = isEditing || isFocused;

  // Animate the collapsed grey bar (only visible when hasValue and NOT expanded)
  const animateEditBox = (show: boolean) => {
    Animated.parallel([
      Animated.timing(editBoxHeight, {
        toValue: show ? 52 : 0,
        duration: 200,
        useNativeDriver: false,
      }),
      Animated.timing(editBoxOpacity, {
        toValue: show ? 1 : 0,
        duration: 150,
        useNativeDriver: false,
      }),
    ]).start();
  };

  useEffect(() => {
    // Show the grey collapsed bar only when: editable, has value, and not currently editing
    if (isEditable && hasValue && !isExpanded) {
      animateEditBox(true);
    } else {
      animateEditBox(false);
    }
  }, [hasValue, isExpanded, isEditable]);

  useEffect(() => {
    if (values[name].state) {
      setSelectedState(values[name].state);
    }
  }, [values[name].state]);

  const handleEditPress = () => {
    setIsEditing(true);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 300);
  };

  const handleClosePress = () => {
    setIsEditing(false);
    setIsFocused(false);
  };

  const handleFocus = () => {
    setIsFocused(true);
    setIsEditing(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const handleStateChange = (value: string) => {
    setSelectedState(value);
    if (nested) {
      setFieldValue(name, {
        ...values[name],
        state: value,
      });
    } else {
      setFieldValue(stateFieldName, value); // 👈 set flat field
    }
  };

  return (
    <>
      <View style={styles.container}>
        {/* ── Always-visible header row (shown when expanded OR when collapsed with value) ── */}
        {(isExpanded || (isEditable && hasValue)) && (
          <>
            {/* Expanded header — always rendered when editing */}
            {isExpanded ? (
              <View style={styles.header}>
                <CustomText size="sm" weight="medium">
                  Address
                </CustomText>
                <Pressable onPress={handleClosePress} hitSlop={17}>
                  <XIcon name="close" size={14} color={PALETTE.primary} />
                </Pressable>
              </View>
            ) : (
              /* Collapsed animated grey bar — shown when hasValue and not expanded */
              <Animated.View
                style={[
                  styles.header,
                  styles.collapsedHeader,
                  { height: editBoxHeight, opacity: editBoxOpacity },
                ]}
              >
                <CustomText size="sm" weight="medium">
                  Address
                </CustomText>
                <Pressable onPress={handleEditPress} hitSlop={14}>
                  <PencilEditIcon />
                </Pressable>
              </Animated.View>
            )}
          </>
        )}

        {/* ── Main content area ── */}
        <View
          style={[styles.contentArea, isExpanded && styles.expandedContent]}
        >
          {/* Address TextInput — always present */}
          <View
            style={[
              styles.inputContainer,
              isFocused && styles.inputFocused,
              errors?.[name] && !!touched[name] && styles.inputError,
              isEditable && hasValue && !isExpanded && styles.inputEditable,
            ]}
          >
            <TextInput
              ref={inputRef}
              style={[
                styles.input,
                (isFocused || hasValue) && styles.textInputFocused,
              ]}
              placeholder="Enter Address"
              placeholderTextColor="#00000088"
              onFocus={handleFocus}
              onBlur={handleBlur}
              value={
                address ?? (nested ? values[name]?.address : values[name]) ?? ""
              }
              onChangeText={(text) => {
                if (onChange) {
                  onChange(text);
                } else if (nested) {
                  setFieldValue(name, { ...values[name], address: text });
                } else {
                  setFieldValue(name, text); // 👈 flat — just set the address field directly
                }
              }}
              keyboardType={type}
              editable={!isEditable || isEditing || isFocused || !hasValue}
            />
          </View>

          {/* State Select — only shown when expanded */}
          {isExpanded && (
            <Select
              name="state"
              placeholder="Select State"
              options={stateOptions}
              onChange={handleStateChange}
              value={selectedState}
            />
          )}
        </View>
      </View>
      <Error error={errors?.[name] as string} visible={!!touched[name]} />
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 0,
    overflow: "hidden",
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    height: 52,
  },
  collapsedHeader: {
    overflow: "hidden",
  },
  contentArea: {},
  expandedContent: {
    gap: 12,
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderBottomLeftRadius: 6,
    borderBottomRightRadius: 6,
    padding: 16,
    borderRadius: 6,
  },
  inputContainer: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  inputEditable: {
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
  },
  input: {
    height: 56,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    color: PALETTE.black,
    opacity: 0.6,
    flex: 1,
  },
  inputFocused: { borderColor: PALETTE.primary },
  textInputFocused: { color: PALETTE.black, opacity: 1 },
  inputError: { borderColor: PALETTE.error },
});

export default AddressInput;
