import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  KeyboardTypeOptions,
  Pressable,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { CustomText } from "../custom";
import Error from "./Error";
import { CUSTOM_STYLES } from "@/constants/styles";

interface InputProps {
  label?: string;
  name: string;
  placeholder?: string;
  isSecureText?: boolean;
  isEditable?: boolean;
  disabled?: boolean;
  type?: KeyboardTypeOptions;
  ActionButton?: React.ReactElement;
  HeaderLabel?: React.ReactElement;
  onChange?: (text: string) => void;
}

const EditableInput = (props: InputProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ form }: any) => <EditableInputInner {...props} form={form} />}
    </FastField>
  );
};

const EditableInputInner = (props: InputProps & { form: FormikValues }) => {
  const {
    name,
    label,
    placeholder,
    type,
    isEditable,
    disabled = false,
    ActionButton,
    HeaderLabel,
    onChange,
    form,
  } = props;
  const { handleChange, values, errors, touched } = form;

  const [isFocused, setIsFocused] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const editBoxHeight = useRef(new Animated.Value(0)).current;
  const editBoxOpacity = useRef(new Animated.Value(0)).current;

  const hasValue = !!values[name];

  const animateEditBox = (show: boolean) => {
    Animated.parallel([
      Animated.timing(editBoxHeight, {
        toValue: show ? 52 : 0,
        duration: 200,
        useNativeDriver: false,
      }),
      Animated.timing(editBoxOpacity, {
        toValue: show ? 1 : 0,
        duration: 150,
        useNativeDriver: false,
      }),
    ]).start();
  };

  useEffect(() => {
    if (isEditable && hasValue && !isFocused && !isEditing) {
      animateEditBox(true);
    } else {
      animateEditBox(false);
    }
  }, [hasValue, isFocused, isEditable, isEditing]);

  const handleEditPress = () => {
    setIsEditing(true);
    animateEditBox(false);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 200);
  };

  const handleFocus = () => {
    setIsFocused(true);
    setIsEditing(true);
    animateEditBox(false);
  };

  const handleBlur = () => {
    setIsFocused(false);
    setIsEditing(false);
    if (isEditable && hasValue) {
      animateEditBox(true);
    }
  };

  return (
    <View
      style={[
        styles.container,
        isEditable &&
          hasValue &&
          !isEditing &&
          !isFocused &&
          styles.editContainer,
      ]}
    >
      {isEditable && (
        <Animated.View
          style={[
            styles.editBox,
            { height: editBoxHeight, opacity: editBoxOpacity },
          ]}
        >
          <CustomText size="sm" weight="medium">
            {label}
          </CustomText>

          <View style={[CUSTOM_STYLES.row, { gap: 12 }]}>
            {!disabled && (
              <Pressable onPress={handleEditPress} hitSlop={14}>
                <PencilEditIcon />
              </Pressable>
            )}
            {HeaderLabel && HeaderLabel}
          </View>
        </Animated.View>
      )}

      <View
        style={[
          styles.inputContainer,
          isFocused && styles.inputFocused,
          errors?.[name] && !!touched[name] && styles.inputError,
          isEditable &&
            hasValue &&
            !isFocused &&
            !isEditing &&
            styles.inputEditable,
        ]}
      >
        <TextInput
          ref={inputRef}
          style={[
            styles.input,
            (isFocused || hasValue) && styles.textInputFocused,
          ]}
          placeholder={placeholder}
          placeholderTextColor="#00000088"
          onFocus={handleFocus}
          onBlur={handleBlur}
          value={values[name] ?? ""}
          onChangeText={onChange ?? handleChange(name)}
          keyboardType={type}
          editable={
            !disabled && (!isEditable || isEditing || isFocused || !hasValue)
          }
        />

        {ActionButton && (
          <View style={styles.actionButton}>{ActionButton}</View>
        )}
      </View>

      <Error error={errors?.[name] as string} visible={!!touched[name]} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  editContainer: {
    gap: 0,
    overflow: "hidden",
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  editBox: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    overflow: "hidden",
  },
  inputContainer: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    borderRadius: 6,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  inputEditable: {
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
  },
  input: {
    height: 56,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    color: PALETTE.black,
    opacity: 0.6,
    flex: 1,
  },
  inputFocused: { borderColor: PALETTE.primary },
  textInputFocused: { color: PALETTE.black, opacity: 1 },
  inputError: { borderColor: PALETTE.error, marginBottom: 12 },
  actionButton: { marginLeft: "auto" },
});

export default EditableInput;
