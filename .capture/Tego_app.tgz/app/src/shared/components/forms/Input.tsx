import EyeOffIcon from "@/assets/images/app-icons/eye-off.svg";
import EyeIcon from "@/assets/images/app-icons/eye.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { TYPOGRAPHY } from "@/constants/typography";
import { hexToRgba } from "@/shared/utils/converter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { FastField, type FormikValues } from "formik";
import { fastFieldShouldUpdate } from "./fastField";
import React, { useState } from "react";
import {
  KeyboardTypeOptions,
  Pressable,
  StyleSheet,
  TextInput,
  TextStyle,
  View,
} from "react-native";
import { CustomText } from "../custom";
import Error from "./Error";

interface InputProps {
  label?: string;
  name: string;
  placeholder?: string;
  isSecureText?: boolean;
  disabled?: boolean;
  type?: KeyboardTypeOptions;
  ActionButton?: React.ReactElement;
  onChange?: (text: string) => void;
  style?: TextStyle;
  info?: string;
}

const Input = (props: InputProps) => {
  const { name } = props;
  return (
    <FastField name={name} shouldUpdate={fastFieldShouldUpdate}>
      {({ meta, form }: any) => (
        <InputInner
          {...props}
          meta={meta}
          setFieldTouched={form.setFieldTouched}
          handleChange={form.handleChange}
        />
      )}
    </FastField>
  );
};

interface InputInnerProps extends InputProps {
  meta: FormikValues;
  setFieldTouched: (
    name: string,
    isTouched?: boolean,
    shouldValidate?: boolean,
  ) => void;
  handleChange: (name: string) => (e: any) => void;
}

const InputInner = ({
  name,
  placeholder,
  type,
  isSecureText,
  disabled = false,
  ActionButton,
  onChange,
  info,
  style,
  meta,
  handleChange,
  setFieldTouched,
}: InputInnerProps) => {
  const value = meta.value;
  const error = meta.error;
  const touched = meta.touched;

  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState<boolean>(false);
  return (
    <View style={styles.container}>
      <View
        style={[
          styles.inputContainer,
          isFocused && styles.inputFocused,
          value?.length > 0 && !isFocused && styles.inputFilled,
          !!error && !!touched && styles.inputError,
        ]}
      >
        <TextInput
          style={[
            styles.input,
            style,
            (isFocused || value?.length > 0) && styles.textInputFocused,
          ]}
          placeholder={placeholder}
          placeholderTextColor={"#00000088"}
          secureTextEntry={isSecureText && !isPasswordVisible}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            setFieldTouched(name, true);
            // Keyboard.dismiss();
          }}
          value={value ? value : ""}
          onChangeText={onChange ? onChange : handleChange(name)}
          keyboardType={type as KeyboardTypeOptions}
          editable={!disabled}
          // 👇 Fixes
          autoCapitalize="none"
          autoCorrect={false}
          autoComplete={isSecureText ? "password" : "off"}
          textContentType={isSecureText ? "password" : "none"}
          spellCheck={false}
        />

        {isSecureText && (
          <Pressable
            onPress={() => setIsPasswordVisible((prev) => !prev)}
            hitSlop={{ top: 17, bottom: 17, left: 8, right: 8 }}
          >
            {!isPasswordVisible ? <EyeOffIcon /> : <EyeIcon />}
          </Pressable>
        )}

        {ActionButton && (
          <View style={styles.actionButton}>{ActionButton}</View>
        )}
      </View>
      {info && (
        <View style={[CUSTOM_STYLES.row, { gap: 4, alignItems: "center" }]}>
          <AntDesign
            name="info-circle"
            size={12}
            color={hexToRgba(PALETTE.black, 0.6)}
          />
          <CustomText size="xs" weight="regular" style={{ opacity: 0.6 }}>
            {info}
          </CustomText>
        </View>
      )}
      <Error error={error} visible={!!touched} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 12,
  },
  inputContainer: {
    borderWidth: 1,
    borderColor: PALETTE.gray200,
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  input: {
    height: 56,
    fontSize: TYPOGRAPHY.fontSize.sm,
    fontFamily: TYPOGRAPHY.fontFamily.regular,
    flex: 1,
  },
  inputFocused: {
    borderColor: PALETTE.primary,
  },
  textInputFocused: {
    color: PALETTE.black,
    opacity: 1,
  },
  inputError: {
    borderColor: PALETTE.error,
  },
  inputFilled: {
    borderColor: PALETTE.black,
  },
  actionButton: {
    marginLeft: "auto",
  },
});

export default Input;
