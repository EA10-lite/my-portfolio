import { PALETTE } from "@/constants/colors";
import CImg from "@/shared/components/general/CImg";
import React from "react";
import { Image, ImageSourcePropType, Text, View } from "react-native";

type AvatarSize = "xs" | "sm" | "md" | "lg";

interface UserAvatarProps {
  url?: string; // Custom URI from image picker
  source?: ImageSourcePropType; // Predefined avatar image
  name: string;
  size?: AvatarSize;
}

const sizeMap: Record<AvatarSize, { container: number; font: number }> = {
  xs: { container: 20, font: 7 },
  sm: { container: 32, font: 12 },
  md: { container: 44, font: 16 },
  lg: { container: 64, font: 22 },
};

const getInitials = (name: string) => {
  if (!name) return "";
  const parts = name.trim().split(" ");
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
};

const getColorFromName = (name: string) => {
  const colors = [
    "#1D9E75",
    "#378ADD",
    "#D85A30",
    "#D4537E",
    "#7F77DD",
    "#BA7517",
  ];
  const index = name.charCodeAt(0) % colors.length;
  return colors[index];
};

const UserAvatar = ({ url, name, size = "md", source }: UserAvatarProps) => {
  const { container, font } = sizeMap[size];
  const [imgError, setImgError] = React.useState(false);

  // Determine which image to show (url takes priority for custom uploads)
  const imageSource = url
    ? { uri: url } // Custom image from picker
    : source; // Predefined avatar

  const showImage = imageSource && !imgError;

  return (
    <View
      style={{
        width: container,
        height: container,
        borderRadius: container / 2,
        backgroundColor: showImage ? PALETTE.grey : getColorFromName(name),
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
      }}
    >
      {showImage ? (
        url ? (
          <CImg
            uri={url}
            width={container * 4}
            style={{ width: container, height: container }}
            onError={() => setImgError(true)}
          />
        ) : (
          <Image
            source={source}
            style={{ width: container, height: container }}
            onError={() => {
              setImgError(true);
            }}
          />
        )
      ) : (
        <Text
          style={{
            color: "#fff",
            fontSize: font,
            fontWeight: "600",
            letterSpacing: 0.5,
          }}
        >
          {getInitials(name)}
        </Text>
      )}
    </View>
  );
};

export default UserAvatar;
