import { PALETTE } from "@/constants/colors";
import CustomText from "@/shared/components/custom/CustomText";
import { useEffect, useRef, useState } from "react";
import {
  FlatList,
  Modal,
  NativeScrollEvent,
  NativeSyntheticEvent,
  Pressable,
  StyleSheet,
  View,
} from "react-native";

const ITEM_HEIGHT = 38;
const PICKER_HEIGHT = ITEM_HEIGHT * 5; // always 5 visible items

interface TimePickerProps {
  visible: boolean;
  closeModal: () => void;
  onChange?: (time: string) => void;
}

const pad = (n: number) => String(n).padStart(2, "0");

const hours = Array.from({ length: 12 }, (_, i) => pad(i + 1));
const minutes = Array.from({ length: 60 }, (_, i) => pad(i));
const periods = ["AM", "PM"];

const now = new Date();
const currentHour = now.getHours();
const currentMinute = now.getMinutes();
const currentPeriod = currentHour >= 12 ? "PM" : "AM";
const current12Hour = currentHour % 12 || 12; // convert to 12hr format

const getInitialHourIndex = () => current12Hour - 1; // hours start from 01
const getInitialMinuteIndex = () => currentMinute;
const getInitialPeriodIndex = () => (currentPeriod === "AM" ? 0 : 1);

// distance-based opacity: closer to center = more opaque
const getOpacity = (distance: number) => {
  if (distance === 0) return 1;
  if (distance === 1) return 0.5;
  return 0.2;
};

const ScrollColumn = ({
  data,
  onChange,
  initialIndex = 0,
}: {
  data: string[];
  onChange: (value: string) => void;
  initialIndex?: number;
}) => {
  const flatListRef = useRef<FlatList>(null);
  const [selectedIndex, setSelectedIndex] = useState(initialIndex);

  // 👇 scroll to initial position on mount
  useEffect(() => {
    setTimeout(() => {
      flatListRef.current?.scrollToOffset({
        offset: initialIndex * ITEM_HEIGHT,
        animated: false,
      });
    }, 100);
  }, []);

  const paddedData = ["", "", ...data, "", ""];

  const onMomentumScrollEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const index = Math.round(e.nativeEvent.contentOffset.y / ITEM_HEIGHT);
    const clamped = Math.max(0, Math.min(index, data.length - 1));
    setSelectedIndex(clamped);
    onChange(data[clamped]);
    flatListRef.current?.scrollToOffset({
      offset: clamped * ITEM_HEIGHT,
      animated: true,
    });
  };

  return (
    <View style={styles.column}>
      <FlatList
        ref={flatListRef}
        data={paddedData}
        keyExtractor={(_, i) => String(i)}
        showsVerticalScrollIndicator={false}
        snapToInterval={ITEM_HEIGHT}
        decelerationRate="fast"
        onMomentumScrollEnd={onMomentumScrollEnd}
        getItemLayout={(_, index) => ({
          length: ITEM_HEIGHT,
          offset: ITEM_HEIGHT * index,
          index,
        })}
        renderItem={({ item, index }) => {
          const realIndex = index - 2;
          const distance = Math.abs(realIndex - selectedIndex);
          const isSelected = distance === 0;
          const opacity = getOpacity(distance);

          return (
            <View style={styles.item}>
              <CustomText
                weight={isSelected ? "semibold" : "regular"}
                style={[
                  styles.itemText,
                  {
                    opacity,
                    color: isSelected ? PALETTE.primary : PALETTE.black,
                    fontSize: isSelected ? 16 : 14,
                  },
                ]}
              >
                {item}
              </CustomText>
            </View>
          );
        }}
      />
    </View>
  );
};

const CustomTimePicker = ({
  onChange,
  visible,
  closeModal,
}: TimePickerProps) => {
  const [hour, setHour] = useState(pad(current12Hour));
  const [minute, setMinute] = useState(pad(currentMinute));
  const [period, setPeriod] = useState(currentPeriod);

  const handleChange = (type: "hour" | "minute" | "period", value: string) => {
    const updated = { hour, minute, period, [type]: value };
    setHour(updated.hour);
    setMinute(updated.minute);
    setPeriod(updated.period);
    const { hour: h24, minute: m } = to24Hour(
      updated.hour,
      updated.minute,
      updated.period,
    );

    onChange?.(`${h24}:${m}:00`);
  };

  const to24Hour = (hour: string, minute: string, period: string) => {
    let h = parseInt(hour, 10);

    if (period === "AM" && h === 12) h = 0;
    if (period === "PM" && h !== 12) h += 12;

    return {
      hour: String(h).padStart(2, "0"),
      minute,
    };
  };

  return (
    <Modal animationType="fade" transparent visible={visible}>
      <View style={styles.backdrop}>
        <Pressable style={StyleSheet.absoluteFill} onPress={closeModal} />
      </View>
      <View style={styles.bottomWrapper}>
        <View style={styles.body}>
          {/* selection highlight spans all columns */}
          <View style={styles.selectionHighlight} pointerEvents="none" />

          <View style={styles.container}>
            <ScrollColumn
              data={hours}
              initialIndex={getInitialHourIndex()}
              onChange={(v) => handleChange("hour", v)}
            />

            <CustomText weight="bold" style={styles.separator}>
              :
            </CustomText>

            <ScrollColumn
              data={minutes}
              initialIndex={getInitialMinuteIndex()}
              onChange={(v) => handleChange("minute", v)}
            />
            <ScrollColumn // 👈 AM/PM as scroll now
              data={periods}
              initialIndex={getInitialPeriodIndex()}
              onChange={(v) => handleChange("period", v)}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.85)",
  },
  bottomWrapper: {
    flex: 1,
    justifyContent: "flex-end",
    position: "relative",
  },
  body: {
    width: 242,
    borderRadius: 10,
    borderWidth: 0.5,
    borderColor: PALETTE.primary,
    backgroundColor: PALETTE.white,
    overflow: "hidden",
    position: "absolute",
    right: 20,
    top: "50%",
  },
  // highlight sits behind all columns, centered vertically
  selectionHighlight: {
    position: "absolute",
    top: ITEM_HEIGHT * 2, // 👈 center row of 5
    left: 0,
    right: 0,
    height: ITEM_HEIGHT,
    backgroundColor: PALETTE.grey01,
    marginHorizontal: 10,
    borderRadius: 53,
    zIndex: 0,
  },
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: "auto",
    gap: 12,
  },
  column: {
    height: PICKER_HEIGHT,
    overflow: "hidden",
    zIndex: 1,
  },
  // fixed AM/PM — centered vertically, stacked
  periodColumn: {
    height: PICKER_HEIGHT,
    width: 48,
    justifyContent: "center",
    alignItems: "center",
    gap: 16,
    zIndex: 1,
  },
  periodItem: {
    height: ITEM_HEIGHT,
    alignItems: "center",
    justifyContent: "center",
  },
  item: {
    height: ITEM_HEIGHT,
    alignItems: "center",
    justifyContent: "center",
  },
  itemText: {
    fontSize: 14,
  },
  separator: {
    fontSize: 18,
    color: PALETTE.gray200,
    marginBottom: 4,
    paddingHorizontal: 2,
  },
});

export default CustomTimePicker;
