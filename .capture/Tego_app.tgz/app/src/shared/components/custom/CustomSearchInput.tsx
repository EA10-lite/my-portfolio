import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import Octicons from "@expo/vector-icons/Octicons";
import {
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  TextInput,
  View,
} from "react-native";

interface SearchInputProps {
  value: string;
  placeholder?: string;
  onChange: (text: string) => void;
  isFocused: boolean;
  setIsFocused: (focus: boolean) => void;
}

const ICON_BOX_WIDTH = 57;

const CustomSearchInput = ({
  value,
  placeholder,
  onChange,
  isFocused = false,
  setIsFocused,
}: SearchInputProps) => {
  return (
    <View style={[styles.container, isFocused && styles.active]}>
      <View
        style={[
          styles.searchIconBox,
          CUSTOM_STYLES.center,
          isFocused && styles.active,
        ]}
      >
        <Octicons name="search" color={PALETTE.primary} size={20} />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          placeholder={placeholder}
          value={value}
          placeholderTextColor={PALETTE.black}
          onChangeText={(text) => onChange(text)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            Keyboard.dismiss();
          }}
          style={styles.input}
        />

        {value.length > 0 && (
          <Pressable
            onPress={() => onChange("")}
            style={styles.clear}
            hitSlop={16}
          >
            <AntDesign name="close" size={16} color={PALETTE.primary} />
          </Pressable>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#8C8C8C33",
    borderRadius: 66,
    paddingHorizontal: 20,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    overflow: "hidden",
    minHeight: 50, // use minHeight instead
    paddingLeft: ICON_BOX_WIDTH + 12,
  },
  active: {
    borderColor: PALETTE.primary,
    borderRightColor: PALETTE.primary,
  },
  searchIconBox: {
    ...StyleSheet.absoluteFill,
    backgroundColor: PALETTE.white,
    alignItems: "center",
    justifyContent: "center",
    width: ICON_BOX_WIDTH,
    borderRightWidth: 1,
    borderRightColor: "#8C8C8C33",
    right: undefined, // 👈 prevent it from stretching full width
  },
  inputContainer: {
    flexDirection: "row",
  },
  input: {
    fontSize: 12,
    fontWeight: "400",
    letterSpacing: -0.24,
    color: PALETTE.black,
    flex: 1,

    // Android fixes
    ...(Platform.OS === "android" && {
      includeFontPadding: true,
      textAlignVertical: "center",
      paddingVertical: 0,
      lineHeight: 18,
    }),
  },
  clear: {},
});

export default CustomSearchInput;
