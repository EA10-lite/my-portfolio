import { StyleSheet, View } from "react-native";
import CustomText from "./CustomText";

interface TableProps {
  data: { label: string; value: string }[];
}

const Table = ({ data }: TableProps) => {
  return (
    <View style={styles.table}>
      {data.map((item, index) => (
        <View
          key={index}
          style={[
            styles.row,
            index === data.length - 1 && {
              borderBottomWidth: 0,
            },
          ]}
        >
          <CustomText size="xs" weight="medium" style={styles.label}>
            {item.label}
          </CustomText>
          <CustomText size="xs" weight="medium" style={styles.value}>
            {item.value}
          </CustomText>
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  table: {
    borderWidth: 1,
    borderColor: "#E5E5EA",
    borderRadius: 6,
    overflow: "hidden",
  },

  row: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#E5E5EA",
  },

  label: {
    width: "50%",
    padding: 16,
    letterSpacing: -0.24,
    borderRightWidth: 1,
    borderRightColor: "#E5E5EA",
  },

  value: {
    width: "50%",
    padding: 12,
    letterSpacing: -0.24,
  },
});

export default Table;
