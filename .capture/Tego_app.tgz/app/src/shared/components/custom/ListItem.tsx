import { CUSTOM_STYLES } from "@/constants/styles";
import { StyleSheet, View } from "react-native";
import CustomText from "./CustomText";

interface ListItemProps {
  title?: string;
  items: string[];
}

const ListItem = ({ title, items }: ListItemProps) => {
  return (
    <View style={styles.container}>
      {title && (
        <CustomText weight="semibold" size="xs">
          {title}
        </CustomText>
      )}

      {items.map((item, index) => (
        <View key={index} style={[CUSTOM_STYLES.row, styles.listItem]}>
          <CustomText style={styles.bullet}>•</CustomText>

          <CustomText style={styles.text} size="xs" weight="medium">
            {item}
          </CustomText>
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 10,
  },
  listItem: { gap: 4, alignItems: "flex-start" },
  text: {
    lineHeight: 21,
    letterSpacing: -0.24,
  },
  bullet: {},
});

export default ListItem;
