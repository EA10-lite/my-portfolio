import { PALETTE } from "@/constants/colors";
import { Pressable, StyleSheet, View } from "react-native";
import CustomText from "./CustomText";

interface TabProps {
  label: string;
  count: number;
  isActive: boolean;
  handlePress: () => void;
  showCountWhenZero?: boolean;
}

const CustomTab = ({
  label,
  count,
  isActive,
  handlePress,
  showCountWhenZero = false,
}: TabProps) => {
  return (
    <Pressable onPress={handlePress}>
      <View style={[styles.container, isActive && styles.activeContainer]}>
        <CustomText
          style={{
            color: isActive ? PALETTE.white : PALETTE.black,
          }}
          size="sm"
          weight="medium"
        >
          {label}
        </CustomText>
        {(count > 0 || showCountWhenZero) && (
          <View style={[styles.count]}>
            <CustomText
              weight="semibold"
              style={{ color: PALETTE.white, fontSize: 9 }}
            >
              {`${count > 9 ? "9+" : count}`}
            </CustomText>
          </View>
        )}
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 50,
    backgroundColor: PALETTE.grey01,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  activeContainer: {
    backgroundColor: PALETTE.primary,
  },
  label: {},
  count: {
    width: 20,
    height: 20,
    backgroundColor: PALETTE.black,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
  },
});
export default CustomTab;
