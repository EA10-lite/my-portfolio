import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { TYPOGRAPHY } from "@/constants/typography";
import React, { useCallback, useRef } from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  View,
  ViewStyle,
} from "react-native";
import { SvgProps } from "react-native-svg";
import CustomText from "./CustomText";

interface CustomButtonProps {
  title: string;
  onPress?: () => void;

  size?: "xs" | "sm" | "md" | "lg";
  variant?: "primary" | "secondary" | "outline" | "default" | "danger";

  loading?: boolean;
  disabled?: boolean;

  Icon?: React.FC<SvgProps>;

  style?: ViewStyle;
}

const CustomButton = ({
  title,
  onPress,
  size = "md",
  variant = "primary",
  loading = false,
  disabled = false,
  Icon,
  style,
}: CustomButtonProps) => {
  const getBackground = () => {
    if (disabled || loading) return PALETTE.secondary;

    switch (variant) {
      case "default":
        return PALETTE.black;
      case "secondary":
        return PALETTE.secondary;
      case "outline":
        return PALETTE.white;
      case "danger":
        return PALETTE.error;
      default:
        return PALETTE.primary;
    }
  };

  const getTextColor = () => {
    if (disabled || loading) return PALETTE.black;

    if (variant === "default") return PALETTE.white;
    if (variant === "outline") return PALETTE.black;
    if (variant === "secondary") return PALETTE.black;
    if (variant === "danger") return PALETTE.white;
    return "#fff";
  };

  // const getPadding = () => {
  //   switch (size) {
  //     case "sm":
  //       return 10;
  //     case "lg":
  //       return 18;
  //     default:
  //       return 14;
  //   }
  // };

  const lastPress = useRef(0);

  const handlePress = useCallback(() => {
    const now = Date.now();
    if (now - lastPress.current < 500) return;
    lastPress.current = now;
    onPress?.();
  }, [onPress]);

  return (
    <Pressable
      onPress={handlePress}
      disabled={disabled || loading}
      style={[
        styles.base,
        {
          backgroundColor: getBackground(),
          height: size === "md" ? 50 : 35,
        },
        style,
      ]}
      hitSlop={size === "md" ? undefined : 7}
    >
      {loading ? (
        <ActivityIndicator color={getTextColor()} />
      ) : (
        <View style={[styles.buttonContainer, CUSTOM_STYLES.center]}>
          {Icon && <Icon />}
          <CustomText
            size={size}
            numberOfLines={1}
            style={{
              color: getTextColor(),
              fontSize: 13,
              opacity: disabled ? 0.2 : 1,
              fontFamily: TYPOGRAPHY.fontFamily.semibold,
              flexShrink: 1,
              textAlign: "center",

              // Android fixes
              // includeFontPadding: false,
              // textAlignVertical: "center",
            }}
          >
            {title}
          </CustomText>
        </View>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  base: {
    borderRadius: 80,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
  },
  buttonContainer: {
    flexDirection: "row",
    gap: 4,
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
});

export default CustomButton;
