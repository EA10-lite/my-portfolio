import { fireEvent, render } from "@testing-library/react-native";
import React from "react";
import { pressableForLabel } from "@/testing/render";
import CustomButton from "../CustomButton";

// CustomButton draws a ~35px pill for xs/sm/lg and a 50px pill for md
// (styles.base → height: 35 vs 50). hitSlop must never be applied when the
// existing touchable area already satisfies the 48dp target.
describe("CustomButton touch target", () => {
  test.each(["xs", "sm", "lg"] as const)(
    "%s (35px pill) carries hitSlop={7} → 49dp effective",
    async (size) => {
      const ui = await render(<CustomButton title="Action" size={size} />);
      expect(pressableForLabel(ui, "Action").props.hitSlop).toBe(7);
    },
  );

  it("md (50px pill) carries no unnecessary hitSlop", async () => {
    const ui = await render(<CustomButton title="Proceed" />);
    expect(pressableForLabel(ui, "Proceed").props.hitSlop).toBeUndefined();
  });

  it("still triggers onPress", async () => {
    const onPress = jest.fn();
    const ui = await render(<CustomButton title="Go" onPress={onPress} />);
    await fireEvent.press(ui.getByText("Go"));
    expect(onPress).toHaveBeenCalledTimes(1);
  });

  it("marks the pressable disabled while loading", async () => {
    const ui = await render(
      <CustomButton title="Submit" loading onPress={jest.fn()} />,
    );
    // loading swaps the label for an ActivityIndicator; disabled surfaces
    // through the pressable's accessibilityState
    expect(JSON.stringify(ui.toJSON())).toContain('"disabled":true');
  });

  it("marks the pressable disabled when explicitly disabled", async () => {
    const onPress = jest.fn();
    const ui = await render(
      <CustomButton title="Submit" disabled onPress={onPress} />,
    );
    const pressable = pressableForLabel(ui, "Submit");
    expect(pressable.props.accessibilityState).toEqual({ disabled: true });

    await fireEvent.press(ui.getByText("Submit"));
    expect(onPress).not.toHaveBeenCalled();
  });
});