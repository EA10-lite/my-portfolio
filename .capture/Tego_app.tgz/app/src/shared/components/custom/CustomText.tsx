import { PALETTE } from "@/constants/colors";
import { TYPOGRAPHY } from "@/constants/typography";
import {
  LayoutChangeEvent,
  Platform,
  StyleSheet,
  Text,
  TextStyle,
} from "react-native";

interface TextInterface {
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
  weight?: "regular" | "medium" | "bold" | "semibold";
  color?: "primary" | "secondary" | "error" | "success" | "default";
  style?: TextStyle | TextStyle[];
  handlePress?: () => void;
  numberOfLines?: number;
  adjustsFontSizeToFit?: boolean;
  children: React.ReactNode;
  onLayout?: (e: LayoutChangeEvent) => void;
}

const CustomText = ({
  size = "md",
  weight = "regular",
  color = "default",
  style,
  handlePress,
  numberOfLines,
  adjustsFontSizeToFit = false,
  children,
  onLayout,
}: TextInterface) => {
  const getColor = () => {
    switch (color) {
      case "default":
        return PALETTE.black;
      case "secondary":
        return PALETTE.gray200;
      case "error":
        return PALETTE.error;
      case "success":
        return PALETTE.success;
      default:
        return PALETTE.primary;
    }
  };

  const fontSize = TYPOGRAPHY.fontSize[size];

  // Android-only line height
  const getLineHeight = () => {
    if (Platform.OS !== "android") return undefined;

    switch (size) {
      case "xs":
        return fontSize + 4;
      case "sm":
        return fontSize + 5;
      case "md":
        return fontSize + 6;
      case "lg":
        return fontSize + 8;
      case "xl":
        return fontSize + 10;
      case "xxl":
        return fontSize + 12;
      default:
        return Math.round(fontSize * 1.5);
    }
  };

  return (
    <Text
      style={[
        styles.base,
        {
          fontSize,
          lineHeight: getLineHeight(),
          fontFamily: TYPOGRAPHY.fontFamily[weight],
          color: getColor(),
          letterSpacing: -0.24,
        },
        style,
      ]}
      onPress={handlePress}
      onLayout={onLayout}
      numberOfLines={numberOfLines}
      adjustsFontSizeToFit={adjustsFontSizeToFit}
    >
      {children}
    </Text>
  );
};

const styles = StyleSheet.create({
  base: {
    includeFontPadding: true,
    textAlignVertical: "center",
  },
});

export default CustomText;
