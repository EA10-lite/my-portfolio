import { avatars } from "@/constants/avatars";
import { PALETTE } from "@/constants/colors";
import React from "react";
import { StyleSheet, View } from "react-native";
import CustomText from "./CustomText";
import UserAvatar from "./UserAvatar";

type AvatarSize = "xs" | "sm" | "md" | "lg";

interface AvatarUser {
  url?: string;
  name: string;
}

interface UserAvatarGroupProps {
  users: AvatarUser[];
  max?: number;
  size?: AvatarSize;
  showRemaining?: boolean;
}

const overlapMap: Record<AvatarSize, number> = {
  xs: -8,
  sm: -8,
  md: -12,
  lg: -16,
};

const sizeMap: Record<AvatarSize, { container: number; font: number }> = {
  xs: { container: 20, font: 7 },
  sm: { container: 32, font: 12 },
  md: { container: 48, font: 16 },
  lg: { container: 64, font: 22 },
};

const UserAvatarGroup = ({
  users,
  max = 3,
  size = "md",
  showRemaining = true,
}: UserAvatarGroupProps) => {
  const visible = users.slice(0, max);
  const remaining = users.length - max;
  const overlap = overlapMap[size];
  const { container, font } = sizeMap[size];

  return (
    <View style={styles.wrapper}>
      {visible.map((user, index) => (
        <View
          key={index}
          style={[
            styles.avatarWrapper,
            {
              marginLeft: index === 0 ? 0 : overlap,
              zIndex: index + 1,
            },
          ]}
        >
          <UserAvatar
            url={user.url}
            name={user.name}
            size={size}
            // 👇 cycle through avatars when no url
            source={!user.url ? avatars[index % avatars.length].url : undefined}
          />
        </View>
      ))}

      {showRemaining && remaining > 0 && (
        <View
          style={[
            styles.avatarWrapper,
            styles.remaining,
            {
              marginLeft: overlap,
              zIndex: visible.length + 1,
              width: container + 4,
              height: container + 4,
            },
          ]}
        >
          <CustomText
            style={{ fontSize: font, color: PALETTE.white }}
            weight="semibold"
          >
            +{remaining}
          </CustomText>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: "row",
    alignItems: "center",
  },
  avatarWrapper: {
    borderWidth: 1.24,
    borderColor: "#fff",
    borderRadius: 999,
  },
  remaining: {
    backgroundColor: PALETTE.black,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default UserAvatarGroup;
