import { PALETTE } from "@/constants/colors";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { forwardRef, useCallback } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FullWindowOverlay } from "react-native-screens";

interface SheetProps {
  onClose?: () => void;
  onOpen?: () => void; // 👈 new
  children: React.ReactNode;
  snapPoints?: (string | number)[];
  showClose?: boolean;
  showOverlay?: boolean;
  maxHeight?: number; // 👈 cap sheet height; content scrolls internally
}

const Sheet = forwardRef<BottomSheetModal, SheetProps>(
  ({ onClose, onOpen, showClose = true, children, showOverlay = true, snapPoints, maxHeight }, ref) => {
    const insets = useSafeAreaInsets();
    const handleSheetChanges = useCallback(
      (index: number) => {
        if (index === -1) {
          onClose?.();
        } else {
          onOpen?.(); // 👈 fires when the sheet becomes visible
        }
      },
      [onClose, onOpen],
    );

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="close"
        />
      ),
      [],
    );

    const resolvedSnapPoints = maxHeight ? [maxHeight] : snapPoints;
    const dynamicSizing = !resolvedSnapPoints;

    return (
      <BottomSheetModal
        ref={ref}
        stackBehavior="push"
        snapPoints={resolvedSnapPoints}
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}
        enablePanDownToClose
        enableDynamicSizing={dynamicSizing}
        backgroundStyle={styles.container}
        handleIndicatorStyle={styles.handle}
        containerComponent={(props) =>
          Platform.OS === "ios" && showOverlay ? (
            <FullWindowOverlay>{props.children}</FullWindowOverlay>
          ) : (
            <>{props.children}</>
          )
        }
      >
        <BottomSheetScrollView
          contentContainerStyle={[styles.contentContainer, { paddingBottom: insets.bottom }]}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            {showClose && (
              <Pressable
                onPress={() => {
                  if (typeof ref !== "function" && ref?.current) {
                    ref.current.dismiss();
                  }
                }}
                style={styles.close}
              >
                <AntDesign name="close" size={12} color={PALETTE.primary} />
              </Pressable>
            )}
          </View>

          <KeyboardAvoidingView
            behavior={Platform.OS === "ios" ? "padding" : "height"}
            keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
            style={styles.keyboardAvoid}
          >
            {children}
          </KeyboardAvoidingView>
      </BottomSheetScrollView>
      </BottomSheetModal>
    );
  },
);

Sheet.displayName = "Sheet";

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },

  handle: {
    width: 37,
    height: 4,
    backgroundColor: PALETTE.black,
    opacity: 0.2,
    marginTop: 8,
  },

  contentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    flex: 1,
  },

  header: {
    alignItems: "flex-end",
    marginBottom: 20,
  },

  keyboardAvoid: {
    flex: 1,
  },

  close: {
    width: 24,
    height: 24,
    borderRadius: 999,
    backgroundColor: PALETTE.grey01,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default Sheet;
