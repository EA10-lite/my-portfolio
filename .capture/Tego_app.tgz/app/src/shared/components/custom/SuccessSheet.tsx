import Hexagon from "@/assets/images/app-icons/hexagon.svg";
import { PALETTE } from "@/constants/colors";
import AntDesign from "@expo/vector-icons/AntDesign";
import Ionicons from "@expo/vector-icons/Ionicons";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { ImageBackground } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { forwardRef, useCallback } from "react";
import { Platform, Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FullWindowOverlay } from "react-native-screens";
import CustomButton from "./CustomButton";
import CustomText from "./CustomText";

interface SuccessSheetProps {
  title: string;
  description: string;
  buttonText?: string;
  variant?: "default" | "primary";
  onContinue: () => void;
  showClose?: boolean;
  showConfetti?: boolean;
  onClose?: () => void;
  Icon?: React.ReactNode;
  maxWidth?: number;
  ExtraComponent?: React.ReactNode;
}

const SuccessSheet = forwardRef<BottomSheetModal, SuccessSheetProps>(
  (
    {
      title,
      description,
      buttonText = "Continue",
      variant = "primary",
      onContinue,
      showClose = false,
      showConfetti = false,
      onClose,
      Icon,
      maxWidth,
      ExtraComponent,
    },
    ref,
  ) => {
    const insets = useSafeAreaInsets();
    const handleClose = () => {
      if (typeof ref !== "function" && ref?.current) {
        ref.current.dismiss();
      }
      onClose?.();
    };

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    return (
      <BottomSheetModal
        ref={ref}
        enableDynamicSizing
        backdropComponent={renderBackdrop}
        backgroundStyle={styles.container}
        enablePanDownToClose={false}
        containerComponent={(props) =>
          Platform.OS === "ios" ? (
            <FullWindowOverlay>{props.children}</FullWindowOverlay>
          ) : (
            <>{props.children}</>
          )
        }
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/* BODY */}
        <BottomSheetView
          style={[styles.body, { paddingBottom: insets.bottom }]}
        >
          {/* HEADER */}
          <LinearGradient
            colors={["rgba(51, 171, 247, 0.232)", "rgba(255, 255, 255, 0)"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={styles.header}
          >
            {showConfetti ? (
              <ImageBackground
                source={require("../../../../assets/images/app-images/confetti.png")}
                style={[StyleSheet.absoluteFill, styles.center]}
              >
                <View style={styles.hexagon}>
                  <Hexagon width={100} height={100} />

                  <View style={styles.hexagonCenter}>
                    {Icon ? (
                      Icon
                    ) : (
                      <Ionicons
                        name={"checkmark"}
                        color={PALETTE.primary}
                        size={20}
                      />
                    )}
                  </View>
                </View>
              </ImageBackground>
            ) : (
              <View style={styles.hexagon}>
                <Hexagon width={100} height={100} />

                <View style={styles.hexagonCenter}>
                  {Icon ? (
                    Icon
                  ) : (
                    <Ionicons
                      name={"checkmark"}
                      color={PALETTE.primary}
                      size={20}
                    />
                  )}
                </View>
              </View>
            )}

            {showClose && (
              <Pressable
                onPress={handleClose}
                style={styles.close}
                hitSlop={12}
              >
                <AntDesign name="close" size={12} />
              </Pressable>
            )}
          </LinearGradient>

          <View style={styles.content}>
            <View style={styles.textContainer}>
              <CustomText weight="bold" size="lg" style={styles.title}>
                {title}
              </CustomText>

              <CustomText
                weight="medium"
                size="sm"
                style={[styles.description, { maxWidth: maxWidth || 280 }]}
              >
                {description}
              </CustomText>
            </View>

            {ExtraComponent && (
              <View style={styles.extraComponent}>{ExtraComponent}</View>
            )}

            <CustomButton
              title={buttonText}
              onPress={onContinue}
              variant={variant}
              style={styles.button}
            />
          </View>
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

SuccessSheet.displayName = "SuccessSheet";

export default SuccessSheet;

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  header: {
    height: 207,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },

  center: {
    alignItems: "center",
    justifyContent: "center",
  },

  close: {
    width: 24,
    height: 24,
    borderRadius: 999,
    backgroundColor: PALETTE.white,
    position: "absolute",
    right: 20,
    top: 32,
    alignItems: "center",
    justifyContent: "center",
  },

  body: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
    paddingBottom: 36,
  },

  hexagon: {
    width: 81,
    height: 81,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },

  hexagonCenter: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
  },

  content: {
    marginTop: 24,
    paddingHorizontal: 20,
  },

  textContainer: {
    alignItems: "center",
    gap: 8,
  },
  title: {
    textAlign: "center",
  },
  description: {
    textAlign: "center",
    opacity: 0.7,
    lineHeight: 21,
  },

  extraComponent: {
    marginTop: 25,
  },

  button: {
    width: "100%",
    marginTop: 45,
  },
});
