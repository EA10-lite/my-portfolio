import { PALETTE } from "@/constants/colors";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Href, router } from "expo-router";
import { Pressable } from "react-native";

interface GoBackProps {
  handleGoBack?: () => void;
}

const GoBack = ({
  handleGoBack,
}: GoBackProps) => {
  const goBack = handleGoBack ? handleGoBack : () => router.back();

  return (
    <Pressable
      onPress={goBack}
      hitSlop={12}
    >
      <Ionicons name="arrow-back" size={24} color={PALETTE.black} />
    </Pressable>
  );
};

export default GoBack;
