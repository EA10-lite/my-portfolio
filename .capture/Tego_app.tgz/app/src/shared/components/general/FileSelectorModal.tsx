import FileIcon from "@/assets/images/app-icons/file.svg";
import ImageIcon from "@/assets/images/app-icons/image.svg";
import ProfileIcon from "@/assets/images/app-icons/profile-plus.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { forwardRef, useCallback } from "react";
import { Pressable, StyleSheet, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CustomText } from "../custom";
import Arrow from "./Arrow";

interface FileSelectorModalProps {
  onClose?: () => void;
  label?: string;
  handleImagePick: () => void;
  handleFilePick?: () => void;
  sendInvite?: () => void;
  showInvite?: boolean;
  canSelectPdf?: boolean;
}

const FileSelectorModal = forwardRef<BottomSheetModal, FileSelectorModalProps>(
  (
    {
      onClose,
      handleImagePick,
      handleFilePick,
      label = "Add File",
      showInvite = false,
      sendInvite,
      canSelectPdf = false,
    },
    ref,
  ) => {
    const insets = useSafeAreaInsets();
    const handleClose = () => {
      if (typeof ref !== "function" && ref?.current) {
        ref.current.dismiss();
      }
      onClose?.();
    };

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    return (
      <BottomSheetModal
        ref={ref}
        enableDynamicSizing
        backdropComponent={renderBackdrop}
        backgroundStyle={styles.container}
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/* BODY */}
        <BottomSheetView style={styles.body}>
          {/* HEADER */}
          <LinearGradient
            colors={["rgba(51, 171, 247, 0.232)", "rgba(255, 255, 255, 0)"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={styles.header}
          >
            {/* 👇 custom drag handle INSIDE gradient */}
            <View style={styles.dragWrapper}>
              <View style={styles.dragHandle} />
            </View>

            <View
              style={[
                CUSTOM_STYLES.row,
                CUSTOM_STYLES.flex,
                {
                  justifyContent: "space-between",
                  width: "100%",
                  paddingHorizontal: 20,
                  position: "relative",
                },
              ]}
            >
              <CustomText weight="semibold">{label}</CustomText>
              <Pressable
                onPress={handleClose}
                hitSlop={12}
                style={[CUSTOM_STYLES.close, styles.close]}
              >
                <AntDesign name="close" size={12} />
              </Pressable>
            </View>
          </LinearGradient>

          <View style={[styles.body, { paddingBottom: insets.bottom }]}>
            <View style={styles.content}>
              {showInvite && (
                <TouchableOpacity
                  onPress={sendInvite}
                  style={[CUSTOM_STYLES.row, styles.selector]}
                >
                  <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                    <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
                      <ProfileIcon
                        width={16}
                        height={16}
                        color={PALETTE.primary}
                      />
                    </View>
                    <CustomText size="sm" weight="semibold">
                      Invite User
                    </CustomText>
                  </View>
                  <Arrow direction="right" />
                </TouchableOpacity>
              )}
              <TouchableOpacity
                onPress={handleImagePick}
                style={[CUSTOM_STYLES.row, styles.selector]}
              >
                <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                  <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
                    <ImageIcon width={16} height={16} color={PALETTE.primary} />
                  </View>
                  <CustomText size="sm" weight="semibold">
                    Add Photo
                  </CustomText>
                </View>
                <Arrow direction="right" />
              </TouchableOpacity>
              {canSelectPdf && (
                <TouchableOpacity
                  onPress={handleFilePick}
                  style={[CUSTOM_STYLES.row, styles.selector]}
                >
                  <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                    <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
                      <FileIcon
                        width={16}
                        height={16}
                        color={PALETTE.primary}
                      />
                    </View>
                    <CustomText size="sm" weight="semibold">
                      Add File
                    </CustomText>
                  </View>
                  <Arrow direction="right" />
                </TouchableOpacity>
              )}
            </View>
          </View>
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

FileSelectorModal.displayName = "File Selector";

export default FileSelectorModal;

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  header: {
    height: 96,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },

  center: {
    alignItems: "center",
    justifyContent: "center",
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 30,
    backgroundColor: PALETTE.white,
  },

  close: {
    right: 20,
  },

  body: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
    paddingBottom: 24,
  },
  content: {
    paddingHorizontal: 20,
    gap: 12,
  },
  selector: {
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
    justifyContent: "space-between",
    padding: 20,
  },
});
