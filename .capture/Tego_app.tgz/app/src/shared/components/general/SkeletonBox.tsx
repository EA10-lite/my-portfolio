import { PALETTE } from "@/constants/colors";
import { useEffect } from "react";
import Animated, {
    useAnimatedStyle,
    useSharedValue,
    withRepeat,
    withTiming,
} from "react-native-reanimated";


const SkeletonBox = ({
    width,
    height,
    borderRadius = 6,
    style,
  }: {
    width?: number | string;
    height: number;
    borderRadius?: number;
    style?: any;
  }) => {
    const opacity = useSharedValue(1);
  
    useEffect(() => {
      opacity.value = withRepeat(withTiming(0.4, { duration: 800 }), -1, true);
    }, []);
  
    const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));
  
    return (
      <Animated.View
        style={[
          { width, height, borderRadius, backgroundColor: PALETTE.grey01 },
          animatedStyle,
          style,
        ]}
      />
    );
};

export default SkeletonBox;