import { PALETTE } from "@/constants/colors";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { CustomSearchInput, CustomText, UserAvatar } from "../custom";

import { avatars } from "@/constants/avatars";
import { useUIStore } from "@/shared/store/uiStore";
import Octicons from "@expo/vector-icons/Octicons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useState } from "react";
import { Platform, Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Location from "./Location";
import { CUSTOM_STYLES } from "@/constants/styles";

interface HeaderProps {
  title?: string;
  search: string;
  placeholder?: string;
  setSearch: (text: string) => void;
  notificationCount?: number;
}

const Header = ({
  title,
  search,
  placeholder,
  setSearch,
  notificationCount=0
}: HeaderProps) => {
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const { isLocationPopupOpen } = useUIStore();
  const { user } = useAuthStore();
  const insets = useSafeAreaInsets();

  const goToNotification = () => {
    router.push("/(customer)/notifications");
  };

  const goToProfile = () => {
    router.push("/(customer)/(tabs)/profile");
  };

  return (
    <>
      <Location />
      <View
        style={[
          { backgroundColor: PALETTE.white },
          isLocationPopupOpen && styles.roundedCorners,
        ]}
      >
        <LinearGradient
          colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={[
            styles.container,
            isLocationPopupOpen && styles.roundedCorners,
            !isLocationPopupOpen && { paddingTop: insets.top },
            Platform.OS === "android" && { backgroundColor: PALETTE.white },
          ]}
        >
          <View style={[styles.row, styles.heading]}>
            <Pressable onPress={goToProfile}>
              <UserAvatar
                name={`${user?.firstName} ${user?.lastName}`}
                source={
                  avatars.find((avatar) => avatar.id === user?.avatarId)?.url ??
                  avatars[0].url
                }
                url={user?.profilePicture}
              />
            </Pressable>
            <Pressable onPress={goToNotification} style={styles.notification}>
              <Octicons name="bell" size={20} color={PALETTE.black} />
              {notificationCount > 0 && (
                <View style={[styles.notificationCount, styles.count, CUSTOM_STYLES.center]}>
                  <CustomText size="sm" style={{ color: PALETTE.white}}>
                    {notificationCount > 9 ? "9+" : notificationCount}
                  </CustomText>
                </View>
              )}
            </Pressable>
          </View>

          <View style={styles.content}>
            <View style={styles.textContent}>
              <CustomText size="sm" weight="semibold" style={styles.title}>
                Hello {user?.firstName} 👋
              </CustomText>
              <CustomText size="xxl" weight="bold" style={styles.description}>
                {title ?? "What do you need help with?"}
              </CustomText>
            </View>
            <CustomSearchInput
              value={search}
              onChange={setSearch}
              isFocused={isFocused}
              setIsFocused={setIsFocused}
              placeholder={placeholder}
            />
          </View>
        </LinearGradient>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  roundedCorners: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    // elevation: 1,
    zIndex: 1,
  },
  heading: {
    marginTop: 32,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  notification: {
    width: 48,
    height: 48,
    borderRadius: 53,
    backgroundColor: PALETTE.white,
    alignItems: "center",
    justifyContent: "center",
    position: "relative"
  },
  notificationCount: {
    position: "absolute",
    top: -4,
    right: 0,
  },
  count: {
    backgroundColor: PALETTE.error,
    width: 20,
    height: 20,
    borderRadius: 40,
  },
  content: {
    marginTop: 58,
    gap: 30,
  },
  textContent: { gap: 8, width: 267 },
  title: {
    textTransform: "uppercase",
    opacity: 0.5,
  },
  description: {
    lineHeight: 37,
  },
});

export default Header;
