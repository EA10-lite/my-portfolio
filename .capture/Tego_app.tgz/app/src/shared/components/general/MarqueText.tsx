import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useEffect, useRef, useState } from "react";
import { Animated, Easing, StyleSheet, View } from "react-native";
import CustomText from "../custom/CustomText";

const MESSAGE = "For your safety, avoid taking conversations outside the app";

const MarqueeText = ({ message }: { message?: string }) => {
  const translateX = useRef(new Animated.Value(0)).current;
  const [blockWidth, setBlockWidth] = useState(0);

  useEffect(() => {
    if (!blockWidth) return;

    translateX.setValue(0);

    const duration = (blockWidth / 80) * 1000; // 80px/s speed

    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(translateX, {
          toValue: -blockWidth, // scroll left by exactly one block
          duration,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        Animated.timing(translateX, {
          toValue: 0,
          duration,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
      ]),
    );

    anim.start();
    return () => anim.stop();
  }, [blockWidth]);

  const Block = () => (
    <View
      style={[CUSTOM_STYLES.row, styles.block]}
      onLayout={(e) => setBlockWidth(e.nativeEvent.layout.width)}
    >
      <CustomText style={styles.text} numberOfLines={1}>
        {message ? message : MESSAGE}
      </CustomText>
      <View style={[CUSTOM_STYLES.dot, { backgroundColor: PALETTE.white }]} />
    </View>
  );

  return (
    <View style={styles.wrapper}>
      {/* Hidden block to measure width */}
      <View
        style={styles.hiddenBlock}
        onLayout={(e) => setBlockWidth(e.nativeEvent.layout.width)}
      >
        <Block />
      </View>

      <Animated.View
        style={[CUSTOM_STYLES.row, { transform: [{ translateX }] }]}
      >
        <Block />
        <Block />
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    overflow: "hidden",
  },
  block: {
    gap: 4,
    paddingHorizontal: 6,
  },
  hiddenBlock: {
    position: "absolute",
    top: 10000, // off-screen so it doesn't flicker
    opacity: 0,
    width: "auto",
  },
  text: {
    color: PALETTE.white,
    fontSize: 13,
    opacity: 0.7,
  },
});

export default MarqueeText;
