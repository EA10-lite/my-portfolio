import ArrowIcon from "@/assets/images/app-icons/arrow.svg";
import { PALETTE } from "@/constants/colors";
import { StyleSheet, View } from "react-native";

type ARROW_DIRECTION = "top" | "right" | "bottom" | "left";

interface ArrowProps {
  direction?: ARROW_DIRECTION;
  color?: string;
  size?: number;
}

const Arrow = ({
  direction = "right",
  color = PALETTE.primary,
  size = 20,
}: ArrowProps) => {
  const getRotation = () => {
    switch (direction) {
      case "top":
        return "270deg";

      case "right":
        return "0deg";

      case "bottom":
        return "90deg";

      case "left":
        return "180deg";

      default:
        return "0deg";
    }
  };

  return (
    <View
      style={[
        styles.container,
        {
          transform: [{ rotate: getRotation() }],
        },
      ]}
    >
      <ArrowIcon width={size} height={size} color={color} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
  },
});

export default Arrow;
