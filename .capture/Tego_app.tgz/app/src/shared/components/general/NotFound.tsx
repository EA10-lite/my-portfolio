import IconFrame from "@/assets/images/app-icons/frame.svg";
import { PALETTE } from "@/constants/colors";
import Octicons from "@expo/vector-icons/Octicons";
import { router } from "expo-router";
import { StyleSheet, View } from "react-native";
import { CustomButton, CustomText } from "../custom";

interface NotFoundProps {
  title?: string;
  description?: string;
  onGoBack?: () => void;
}

const NotFound = ({
  title = "Not Found",
  description =
    "The content you're looking for doesn't exist or has been removed.",
  onGoBack,
}: NotFoundProps) => {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <IconFrame />
          <View style={styles.iconOverlay}>
            <Octicons name="x-circle" size={20} color={PALETTE.primary} />
          </View>
        </View>
        <View style={styles.textContainer}>
          <CustomText size="sm" weight="semibold" style={styles.title}>
            {title}
          </CustomText>
          <CustomText weight="medium" style={styles.description}>
            {description}
          </CustomText>
        </View>
        <CustomButton
          title="Go Back"
          onPress={onGoBack ?? (() => router.back())}
          style={styles.button}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    flex: 1,
  },
  content: {
    width: 248,
    margin: "auto",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    gap: 18,
  },
  iconContainer: {
    alignItems: "center",
    justifyContent: "center",
    gap: 18,
  },
  iconOverlay: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },
  textContainer: {
    gap: 5,
  },
  title: {
    textAlign: "center",
  },
  description: {
    textAlign: "center",
    opacity: 0.5,
    fontSize: 13,
  },
  button: {
    width: "100%",
    marginTop: 8,
  },
});

export default NotFound;