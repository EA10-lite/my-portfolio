import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { getStatusColor } from "@/shared/utils/colors";
import { StyleSheet, View } from "react-native";
import CustomText from "../custom/CustomText";

interface StatusProps {
  status: string;
  label?: string;
  variant?: "default" | "primary";
}

const Status = ({ status, label, variant }: StatusProps) => {
  const getBackgroundColor = () => {
    return variant === "default"
      ? PALETTE.black
      : status === "completed"
        ? "#34C75917"
        : "#34C75917";
  };

  const getColor = () => {
    return variant === "default"
      ? PALETTE.white
      : status === "cancelled" || status === "failed"
        ? PALETTE.error
        : status === "completed"
          ? PALETTE.success
          : PALETTE.black;
  };
  return (
    <View
      style={[
        styles.status,
        CUSTOM_STYLES.row,
        CUSTOM_STYLES.center,
        {
          backgroundColor: getBackgroundColor(),
          gap: 4,
        },
      ]}
    >
      <View
        style={[
          styles.dot,
          {
            backgroundColor: getStatusColor(status),
          },
        ]}
      />
      <CustomText
        style={[
          styles.text,
          {
            color: getColor(),
          },
        ]}
        weight="semibold"
      >
        {label ? label : status}
      </CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  status: {
    borderRadius: 60,
    paddingHorizontal: 11.67,
    // paddingVertical: 8.17,
    height: 24,
    borderWidth: 1.17,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 60,
  },

  text: {
    fontSize: 8.67,
    textTransform: "uppercase",
  },
});

export default Status;
