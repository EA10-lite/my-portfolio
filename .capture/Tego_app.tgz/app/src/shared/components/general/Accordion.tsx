import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { Animated, Pressable, StyleSheet, View } from "react-native";

import { CustomText } from "../custom";
import Arrow from "./Arrow";

interface AccordionProps {
  title: string;
  description: string;
  isOpen: boolean;
  onToggle: () => void;
}

const Accordion = ({
  title,
  description,
  isOpen,
  onToggle,
}: AccordionProps) => {
  const {
    rotate,
    animatedHeight,
    contentHeight,
    setContentHeight,
    opacityAnim,
  } = useExpandableAnimation({
    initialState: false,
    isOpen,
  });

  return (
    <View style={styles.card}>
      <Pressable
        onPress={onToggle}
        style={[CUSTOM_STYLES.row, styles.cardHeader]}
      >
        <CustomText
          weight="semibold"
          style={{
            fontSize: 13,
            flexShrink: 1,
          }}
        >
          {title}
        </CustomText>

        <Animated.View
          style={[
            styles.arrow,
            CUSTOM_STYLES.center,
            {
              transform: [{ rotate }],
            },
          ]}
        >
          <Arrow direction="bottom" size={14} />
        </Animated.View>
      </Pressable>

      <Animated.View
        style={{
          height: animatedHeight,
          overflow: "hidden",
        }}
      >
        <View
          onLayout={(event) => {
            const height = event.nativeEvent.layout.height;

            if (height > 0 && height !== contentHeight) {
              setContentHeight(height);
            }
          }}
          style={{
            position: "absolute",
            width: "100%",
          }}
        >
          <Animated.View
            style={[
              styles.cardBody,
              {
                opacity: opacityAnim,
              },
            ]}
          >
            <CustomText
              size="xs"
              weight="medium"
              style={{
                opacity: 0.7,
                letterSpacing: -0.24,
              }}
            >
              {description}
            </CustomText>
          </Animated.View>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
  },

  cardHeader: {
    padding: 16,
    justifyContent: "space-between",
  },

  cardBody: {
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
  },

  arrow: {
    width: 20,
    height: 20,
    borderRadius: 50,
    backgroundColor: PALETTE.grey01,
  },
});

export default Accordion;