import AntDesign from "@expo/vector-icons/AntDesign";
import { useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { WebView } from "react-native-webview";

import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText } from "@/shared/components/custom";

interface CheckoutWebViewProps {
  isOpen: boolean;
  checkoutUrl: string | null;
  onClose: () => void;
  onSuccess: () => void;
}

/**
 * Checkout is rendered in a plain `Modal` on every platform because a WebView
 * inside a @gorhom/bottom-sheet BottomSheetModal does not scroll reliably on
 * Android: the sheet's pan gesture steals vertical drags from the WebView, and
 * non-scrollable sheet content clips anything that overflows. A modal gives the
 * WebView a full-size, gesture-free frame so the payment page scrolls natively.
 */
const CheckoutWebView = ({
  isOpen,
  checkoutUrl,
  onClose,
  onSuccess,
}: CheckoutWebViewProps) => {
  const insets = useSafeAreaInsets();
  const [isLoading, setIsLoading] = useState(true);

  const handleNavigationChange = (navState: any) => {
    const { url } = navState;

    if (url.includes("/payment/success")) {
      onSuccess();
      onClose();
    }
  };

  if (!checkoutUrl) {
    return null;
  }

  const webViewContent = (
    <View style={styles.webViewContainer}>
      {isLoading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={PALETTE.primary} />
        </View>
      )}

      <WebView
        source={{ uri: checkoutUrl }}
        style={styles.webView}
        javaScriptEnabled
        domStorageEnabled
        startInLoadingState
        scrollEnabled
        onLoadStart={() => setIsLoading(true)}
        onLoadEnd={() => setIsLoading(false)}
        onNavigationStateChange={handleNavigationChange}
        allowsBackForwardNavigationGestures
      />
    </View>
  );

  /**
   * Modal visibility is driven by the `isOpen` prop. The forwarded ref
   * is retained to preserve the existing API contract with callers that
   * use `useModalState`, but the sheet-present/dismiss calls it triggers
   * are now no-ops — `isOpen` is the single source of truth on both
   * platforms.
   */
  return (
    <Modal
      visible={isOpen}
      animationType="slide"
      presentationStyle={Platform.OS === "ios" ? "pageSheet" : "fullScreen"}
      onRequestClose={onClose}
    >
      <View style={[styles.container, { paddingTop: Platform.OS === "ios" ? 10 : insets.top }]}>
        <Header closeModal={onClose} />

        {webViewContent}
      </View>
    </Modal>
  );
};

CheckoutWebView.displayName = "CheckoutWebView";

const Header = ({ closeModal }: { closeModal: () => void }) => (
  <View style={[CUSTOM_STYLES.row, styles.header]}>
    <CustomText weight="semibold" size="md" style={styles.title}>
      Complete Payment
    </CustomText>

    <Pressable onPress={closeModal} hitSlop={16}>
      <AntDesign name="close" color={PALETTE.black} size={16} />
    </Pressable>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },

  header: {
    height: 57,
    paddingHorizontal: 20,
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#E8E7E766",
  },

  title: {
    letterSpacing: -0.24,
  },

  webViewContainer: {
    flex: 1,
    position: "relative",
  },

  webView: {
    flex: 1,
  },

  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 10,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: PALETTE.white,
  },
});

export default CheckoutWebView;
