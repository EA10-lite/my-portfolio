import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import Ionicons from "@expo/vector-icons/Ionicons";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import MarqueeText from "./MarqueText";

const WarningText = ({ message }: { message?: string }) => {
  const insets = useSafeAreaInsets();
  return (
    <View
      style={[
        styles.carousel,
        CUSTOM_STYLES.row,
        { paddingTop: insets.top + 16 },
      ]}
    >
      <View>
        <Ionicons name="information-circle" size={16} color={PALETTE.white} />
      </View>

      <View style={styles.carouselText}>
        <MarqueeText message={message} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  carousel: {
    padding: 20,
    gap: 10,
    justifyContent: "space-between",
  },

  carouselText: {
    flex: 1,
  },
});

export default WarningText;
