import { PALETTE } from "@/constants/colors";
import { usePulse } from "@/shared/hooks/usePulse";
import { transformImageUrl } from "@/shared/lib/cloudinary";
import { Image } from "expo-image";
import { useState } from "react";
import { Animated, Pressable, StyleSheet, View } from "react-native";
import ImagePreviewModal from "./ImagePreviewModal";

const GAP = 7;

// Thumbs are ~1/3 of the screen; pull at ~500px so they stay sharp on 3x.
const THUMBNAIL_WIDTH = 500;

interface ImagePreviewProps {
  images: string[];
}

const PreviewThumbnail = ({
  uri,
  onPress,
}: {
  uri: string;
  onPress: () => void;
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(!uri);
  const opacity = usePulse();

  const source = uri ? transformImageUrl(uri, THUMBNAIL_WIDTH) : uri;

  return (
    <Pressable style={styles.previewItem} onPress={onPress}>
      <View style={styles.imageWrapper}>
        {isLoading && !hasError && (
          <Animated.View style={[styles.placeholder, { opacity }]} />
        )}
        {hasError ? (
          <View style={[styles.placeholder, styles.errorState]} />
        ) : (
          <Image
            source={{ uri: source }}
            style={[styles.previewImage, isLoading && { opacity: 0 }]}
            contentFit="cover"
            transition={200}
            cachePolicy="memory-disk"
            onLoad={() => setIsLoading(false)}
            onLoadEnd={() => setIsLoading(false)}
            onError={() => {
              setIsLoading(false);
              setHasError(true);
            }}
          />
        )}
      </View>
    </Pressable>
  );
};

const ImagePreview = ({ images }: ImagePreviewProps) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [index, setIndex] = useState<number>(0);

  const handleImageClick = (index: number) => {
    setIndex(index);
    setIsOpen(true);
  };

  return (
    <View style={styles.preview}>
      {images.map((uri, index) => (
        <PreviewThumbnail
          key={index}
          uri={uri}
          onPress={() => handleImageClick(index)}
        />
      ))}

      <ImagePreviewModal
        visible={isOpen}
        images={images}
        selectedIndex={index}
        handleClose={() => setIsOpen(false)}
        canDownload={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  preview: {
    flexDirection: "row",
    flexWrap: "wrap",
    margin: -GAP / 2,
  },
  previewItem: {
    width: "33.3333%",
    padding: GAP / 2,
  },
  imageWrapper: {
    width: "100%",
    aspectRatio: 1,
    borderRadius: 7,
    overflow: "hidden",
  },
  previewImage: {
    width: "100%",
    height: "100%",
  },
  placeholder: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: PALETTE.grey01,
    borderRadius: 7,
  },
  errorState: {
    backgroundColor: PALETTE.grey,
  },
});

export default ImagePreview;
