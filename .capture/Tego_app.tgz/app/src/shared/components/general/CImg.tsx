import { transformImageUrl } from "@/shared/lib/cloudinary";
import { Image as ExpoImage } from "expo-image";
import type { ImageStyle, StyleProp } from "react-native";

interface CImgProps {
  uri?: string;
  /** Content width in dp — the Cloudinary URL is sized to 4x so 3x screens stay crisp. */
  width?: number;
  style?: StyleProp<ImageStyle>;
  contentFit?: "cover" | "contain" | "fill" | "none" | "scale-down";
  transition?: number;
  onError?: () => void;
  onLoad?: () => void;
}

/**
 * Cloudinary-aware image. Applies a sized `w_,f_auto,q_auto` transform when the
 * `uri` is a Cloudinary delivery URL (local URIs pass through) and renders via
 * `expo-image` for disk caching and downscaled decode. Use this instead of a raw
 * `<Image source={{ uri }}>` for any remote image with a known display size.
 */
const CImg = ({
  uri,
  width,
  style,
  contentFit = "cover",
  transition = 200,
  onError,
  onLoad,
}: CImgProps) => {
  const source = uri ? transformImageUrl(uri, width) : undefined;
  if (!source) return null;

  return (
    <ExpoImage
      source={{ uri: source }}
      style={style}
      contentFit={contentFit}
      transition={transition}
      cachePolicy="memory-disk"
      onError={onError}
      onLoad={onLoad}
    />
  );
};

export default CImg;