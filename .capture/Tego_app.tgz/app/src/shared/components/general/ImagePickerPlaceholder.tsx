import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import FontAwesome6 from "@expo/vector-icons/FontAwesome6";
import { Pressable, StyleSheet, View } from "react-native";
import { CustomText } from "../custom";

interface ImagePickerProps {
  label: string;
  maxImages?: number;
  canChange?: boolean;
  handlePick: () => void;
  images: string[];
  HeaderLabel?: React.ReactElement;
  showPlaceholder?: boolean;
}

const ImagePickerPlaceholder = ({
  label,
  handlePick,
  maxImages = 3,
  canChange = false,
  images,
  HeaderLabel,
  showPlaceholder=true,
}: ImagePickerProps) => {
  return (
    <View style={{ gap: 16 }}>
      <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
        <CustomText size="sm" weight="semibold">
          {label}
        </CustomText>
        {HeaderLabel && HeaderLabel}
      </View>

      {showPlaceholder && (
        <Pressable
          onPress={handlePick}
          disabled={images.length >= maxImages && !canChange}
        >
          <View style={styles.picker}>
            <View style={[styles.upload, CUSTOM_STYLES.row]}>
              <FontAwesome6 name="upload" size={14} color={PALETTE.primary} />
              <CustomText size="xs" color="primary" weight="regular">
                Upload
              </CustomText>
            </View>
            <CustomText size="xs" weight="medium" style={styles.placeholder}>
              Format: JPEG, PNG. 5 MB max
            </CustomText>
            {images.length >= maxImages && (
              <CustomText size="xs" style={{ color: PALETTE.error }}>
                Maximum {maxImages} images reached
              </CustomText>
            )}
          </View>
        </Pressable>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  picker: {
    backgroundColor: PALETTE.white50,
    borderWidth: 1,
    borderColor: PALETTE.primaryLight,
    borderStyle: "dashed",
    minHeight: 125,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    borderRadius: 6,
  },
  placeholder: { opacity: 0.4 },
  upload: {
    backgroundColor: PALETTE.white,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: PALETTE.primary14,
    gap: 6,
    borderRadius: 4,
  },
});

export default ImagePickerPlaceholder;
