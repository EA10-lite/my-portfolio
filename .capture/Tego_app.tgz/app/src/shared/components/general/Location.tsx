import { PALETTE } from "@/constants/colors";
import { statusBarHeight } from "@/constants/values";
import { useLocationStore } from "@/shared/store/locationStore";
import { useUIStore } from "@/shared/store/uiStore";
import AntDesign from "@expo/vector-icons/AntDesign";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Pressable, StyleSheet, View } from "react-native";
import { CustomText } from "../custom";

const Location = () => {
  const { setLocationPopupOpen, isLocationPopupOpen } = useUIStore();
  const { address } = useLocationStore();

  const closeLocationPopup = () => {
    setLocationPopupOpen(false);
  };
  return (
    <>
      {isLocationPopupOpen && (
        <View
          style={[styles.locationPopup, { paddingTop: statusBarHeight + 14 }]}
        >
          <View style={styles.location}>
            <View
              style={{ gap: 4, flexDirection: "row", alignItems: "center" }}
            >
              <Ionicons
                name="location-sharp"
                size={16}
                color={PALETTE.primary}
              />
              <CustomText
                size="sm"
                weight="medium"
                style={{ color: PALETTE.white }}
              >
                {address || "14th Avenue Street"}
              </CustomText>
            </View>
          </View>

          <Pressable onPress={closeLocationPopup} hitSlop={15}>
            <AntDesign name="close" color={PALETTE.white} size={18} />
          </Pressable>
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  location: {},
  locationPopup: {
    // backgroundColor: PALETTE.black,
    paddingBottom: 14,
    // marginBottom: -20,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    // opacity: 0.95,
  },
});

export default Location;
