import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import { StyleSheet, View } from "react-native";
import { CustomText } from "../custom";

const Info = ({
  text,
  type = "default",
}: {
  text: string;
  type?: "default" | "error";
}) => {
  return (
    <View
      style={[
        CUSTOM_STYLES.row,
        styles.info,
        {
          backgroundColor:
            type === "error" ? PALETTE.whiteLight : PALETTE.white50,
        },
      ]}
    >
      <AntDesign
        name="info-circle"
        size={13}
        color={type === "error" ? PALETTE.error : PALETTE.black}
      />
      <CustomText weight="regular" style={styles.infoText}>
        {text}
      </CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  info: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 6,
    gap: 6,
    alignItems: "flex-start",
  },
  infoText: {
    lineHeight: 20,
    fontSize: 13,
    flexShrink: 1,
    marginTop: -5,
  },
});

export default Info;
