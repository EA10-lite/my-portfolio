import { PALETTE } from "@/constants/colors";
import { StyleSheet, View } from "react-native";

import BookingIcon from "@/assets/images/app-icons/booking.svg";
import BudgetIcon from "@/assets/images/app-icons/budget.svg";
import CardIcon from "@/assets/images/app-icons/card-alt.svg";
import SuccessIcon from "@/assets/images/app-icons/check.svg";
import ClockIcon from "@/assets/images/app-icons/clock.svg";
import DashboardIcon from "@/assets/images/app-icons/dashboard.svg";
import DateAltIcon from "@/assets/images/app-icons/date-alt.svg";
import DateIcon from "@/assets/images/app-icons/date.svg";
import StatusIcon from "@/assets/images/app-icons/loading.svg";
import LocationIcon from "@/assets/images/app-icons/location-outline.svg";
import Location from "@/assets/images/app-icons/location.svg";
import NoteIcon from "@/assets/images/app-icons/note.svg";
import ProfileIcon from "@/assets/images/app-icons/profile-alt.svg";
import UserIcon from "@/assets/images/app-icons/profile.svg";
import StarAltIcon from "@/assets/images/app-icons/star-outline.svg";
import StarIcon from "@/assets/images/app-icons/star.svg";
import TimeIcon from "@/assets/images/app-icons/time.svg";
import UserAltIcon from "@/assets/images/app-icons/user.svg";
import { CUSTOM_STYLES } from "@/constants/styles";
import { getStatusColor, StatusType } from "@/shared/utils/colors";
import { CustomText } from "../custom";

type FORM_VALUES =
  | "title"
  | "date"
  | "date-alt"
  | "time"
  | "check"
  | "address"
  | "location"
  | "urgency"
  | "note"
  | "budget"
  | "category"
  | "status"
  | "user"
  | "user-alt"
  | "profile"
  | "booking"
  | "star"
  | "star-alt"
  | "payment";

interface FieldProps {
  label: string;
  value: string;
  isLast?: boolean;
  type: FORM_VALUES;
  content?: React.ReactElement;
}

const getIcon = (type: FORM_VALUES) => {
  const props = { width: 16, height: 16, color: PALETTE.primary };
  const iconMap: Record<FORM_VALUES, React.ReactNode> = {
    title: <NoteIcon {...props} />,
    date: <DateIcon {...props} />,
    "date-alt": <DateAltIcon {...props} />,
    check: <SuccessIcon {...props} />,
    time: <ClockIcon {...props} />,
    urgency: <TimeIcon {...props} />,
    address: <LocationIcon {...props} />,
    location: <Location {...props} />,
    note: <NoteIcon {...props} />,
    budget: <BudgetIcon {...props} />,
    category: <DashboardIcon {...props} />,
    status: <StatusIcon {...props} />,
    user: <UserIcon {...props} />,
    "user-alt": <UserAltIcon {...props} />,
    profile: <ProfileIcon {...props} />,
    booking: <BookingIcon {...props} />,
    payment: <CardIcon {...props} />,
    star: <StarIcon {...props} />,
    "star-alt": <StarAltIcon {...props} />,
  };
  return iconMap[type] ?? null;
};

const DetailsField = ({ label, value, isLast, type, content }: FieldProps) => {
  const getStatusText = () => {
    if (value === "in_progress" || value === "IN_PROGRESS")
      return "In Progress";
    if (value === "completion_requested") return "Completion Requested";
    if (value === "IN_NEGOTIATION" || value === "AWAITING_PROVIDER")
      return "Waiting to get started";

    return value.charAt(0).toUpperCase() + value.slice(1);
  };
  return (
    <View style={[styles.detailsField, isLast && { borderBottomWidth: 0 }]}>
      {type && (
        <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
          {getIcon(type as FORM_VALUES)}
        </View>
      )}

      <View style={{ gap: 8, flex: 1, maxWidth: "75%" }}>
        <CustomText weight="medium" size="xs" style={styles.label}>
          {label}
        </CustomText>

        <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
          {type === "status" && (
            <View
              style={[
                CUSTOM_STYLES.dot,
                {
                  backgroundColor: getStatusColor(
                    value.toLowerCase() as StatusType,
                  ),
                },
              ]}
            />
          )}

          <CustomText
            weight="semibold"
            size="xs"
            style={[styles.value, { flexShrink: 1 }]}
            numberOfLines={2}
          >
            {type === "status" ? getStatusText() : value}
          </CustomText>
        </View>
        {content && content}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  details: { gap: 20 },
  group: { gap: 8 },
  detailsField: {
    gap: 14,
    padding: 20,
    borderBottomWidth: 1,
    borderColor: "#0000000A",
    alignItems: "flex-start",
    flexDirection: "row",
  },
  label: {
    opacity: 0.5,
  },
  value: {
    letterSpacing: -0.0024,
  },
});

export default DetailsField;
