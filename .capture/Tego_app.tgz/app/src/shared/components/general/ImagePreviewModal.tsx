import { PALETTE } from "@/constants/colors";
import { transformImageUrl } from "@/shared/lib/cloudinary";
import { useToastStore } from "@/shared/store/toastStore";
import AntDesign from "@expo/vector-icons/AntDesign";
import * as FileSystem from "expo-file-system/legacy";
import * as MediaLibrary from "expo-media-library";
import { useMemo, useState } from "react";
import { Alert, StyleSheet, TouchableOpacity, View } from "react-native";
import ImageViewing from "react-native-image-viewing";

interface ImagePreviewModalProps {
  visible: boolean;
  selectedIndex: number;
  images: string[];
  handleClose: () => void;
  canDelete?: boolean;
  canDownload?: boolean;
  onDelete?: (index: number) => void;
}

const ImagePreviewModal = ({
  visible,
  selectedIndex,
  images,
  handleClose,
  canDelete = false,
  canDownload = false,
  onDelete,
}: ImagePreviewModalProps) => {
  const { showToast } = useToastStore();
  const [isDownloading, setIsDownloading] = useState(false);

  const imageSources = useMemo(
    () => images.map((url) => ({ uri: transformImageUrl(url, 1280) })),
    [images],
  );

  const handleDownload = async (imageIndex: number) => {
    try {
      const { status } = await MediaLibrary.requestPermissionsAsync(true); // write-only: no READ_MEDIA_* needed to save
      if (status !== "granted") {
        Alert.alert(
          "Permission required",
          "Please allow access to save images to your gallery.",
        );
        return;
      }

      setIsDownloading(true);

      const uri = images[imageIndex];
      const filename = uri.split("/").pop() ?? `image_${Date.now()}.jpg`;
      const downloadDest = `${FileSystem.cacheDirectory}${filename}`;

      // If it's already a local URI (during upload), save directly
      if (uri.startsWith("file://") || uri.startsWith("/")) {
        await MediaLibrary.saveToLibraryAsync(uri);
      } else {
        // Download from remote URL first
        const { uri: localUri } = await FileSystem.downloadAsync(
          uri,
          downloadDest,
        );
        await MediaLibrary.saveToLibraryAsync(localUri);
      }

      Alert.alert("Saved", "Image saved to your gallery.");
    } catch (err) {
      console.error("[ImagePreviewModal] download error:", err);
      showToast("Action Failed", "Failed to save image");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <ImageViewing
      images={imageSources}
      imageIndex={selectedIndex}
      visible={visible}
      onRequestClose={handleClose}
      animationType="fade"
      FooterComponent={({ imageIndex }) => {
        const showFooter = canDelete || canDownload;
        if (!showFooter) return null;

        return (
          <View style={styles.footer}>
            {canDownload && (
              <TouchableOpacity
                style={[styles.btn, styles.downloadBtn]}
                onPress={() => handleDownload(imageIndex)}
                disabled={isDownloading}
              >
                <AntDesign name={"download"} size={20} color={PALETTE.white} />
              </TouchableOpacity>
            )}

            {canDelete && (
              <TouchableOpacity
                style={[styles.btn, styles.deleteBtn]}
                onPress={() => {
                  onDelete?.(imageIndex);
                  if (images.length <= 1) handleClose();
                }}
              >
                <AntDesign name="delete" size={20} color={PALETTE.white} />
              </TouchableOpacity>
            )}
          </View>
        );
      }}
    />
  );
};

const styles = StyleSheet.create({
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 16,
    paddingBottom: 40,
  },
  btn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  downloadBtn: {
    backgroundColor: PALETTE.primary,
  },
  deleteBtn: {
    backgroundColor: PALETTE.error,
  },
});

export default ImagePreviewModal;