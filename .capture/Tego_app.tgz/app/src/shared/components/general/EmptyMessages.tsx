import IconFrame from "@/assets/images/app-icons/frame.svg";
import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import Octicons from "@expo/vector-icons/Octicons";
import { Href, Link } from "expo-router";
import React from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { SvgProps } from "react-native-svg";
import { CustomText } from "../custom";

interface EmptyMessageProps {
  title: string;
  description: string;
  Icon?: React.FC<SvgProps>;
  link?: {
    label: string;
    href: Href;
  };
  isInTabView?: boolean;
}

const EmptyMessages = ({
  title,
  description,
  Icon,
  isInTabView,
  link,
}: EmptyMessageProps) => {
  const insets = useSafeAreaInsets();
  return (
    <View
      style={[
        styles.container,
        isInTabView && { marginTop: -(TAB_BAR_HEIGHT + insets.bottom) },
      ]}
    >
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <IconFrame />
          <View style={styles.iconOverlay}>
            {Icon ? (
              <Icon color={PALETTE.primary} />
            ) : (
              <Octicons name="search" size={20} color={PALETTE.primary} />
            )}
          </View>
        </View>
        <View style={styles.textContainer}>
          <CustomText size="sm" weight="semibold" style={styles.title}>
            {title}
          </CustomText>
          <CustomText weight="medium" style={styles.description}>
            {description}
          </CustomText>
          {link && (
            <Link href={link.href} style={styles.link}>
              {link.label}
            </Link>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    flex: 1,
  },
  content: {
    width: 248,
    margin: "auto",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    gap: 18,
  },
  iconContainer: {
    alignItems: "center",
    justifyContent: "center",
    gap: 18,
  },
  iconOverlay: {
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
  },
  textContainer: {
    gap: 5,
  },
  title: {
    textAlign: "center",
  },
  description: {
    textAlign: "center",
    opacity: 0.5,
    fontSize: 13,
  },
  link: {
    color: PALETTE.primary,
    textAlign: "center",
    textDecorationLine: "underline",
    fontSize: 13,
    fontWeight: "500",
  },
});

export default EmptyMessages;
