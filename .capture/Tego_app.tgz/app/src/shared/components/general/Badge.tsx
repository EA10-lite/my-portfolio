import { PALETTE } from "@/constants/colors";
import { hexToRgba } from "@/shared/utils/converter";
import { StyleSheet, View } from "react-native";
import { CustomText } from "../custom";

interface BadgeProps {
  title: string;
  variant:
    | "default"
    | "success"
    | "primary"
    | "secondary"
    | "outline"
    | "pending"
    | "error"
}

const Badge = ({ title, variant = "default" }: BadgeProps) => {
  const getBackground = () => {
    switch (variant) {
      case "default":
        return PALETTE.black;
      case "success":
        return hexToRgba(PALETTE.success, 0.07);
      case "secondary":
        return PALETTE.grey01;
      case "pending":
        return hexToRgba(PALETTE.orange, 0.07);
      case "error":
        return hexToRgba(PALETTE.orange, 0.07);
      case "outline":
        return PALETTE.white;
      default:
        return PALETTE.primary;
    }
  };

  const getTextColor = () => {
    if (variant === "default") return PALETTE.primary;
    if (variant === "secondary") return PALETTE.primary;
    if (variant === "success") return PALETTE.success;
    if (variant === "pending") return PALETTE.orange;
    return PALETTE.primary;
  };
  return (
    <View style={[styles.badge, { backgroundColor: getBackground() }]}>
      <CustomText
        weight="semibold"
        style={[
          styles.badgeText,
          {
            color: getTextColor(),
          },
        ]}
      >
        {title}
      </CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 6.77,
    width: "auto",
    minHeight: 19,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 3,
  },
  badgeText: {
    fontSize: 9,
    textTransform: "uppercase",
    paddingHorizontal: 4,
  },
});

export default Badge;
