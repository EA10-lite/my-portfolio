import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { hexToRgba } from "@/shared/utils/converter";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { StyleSheet, View } from "react-native";
import { CustomText } from "../custom";

interface TrackerProps {
  tracker: {
    label: string;
    content?: React.ReactNode;
    Icon?: React.ReactNode;
  }[];
}

const Tracker = ({ tracker }: TrackerProps) => {
  return (
    <View style={styles.trackerContainer}>
      <View style={{ gap: 4 }}>
        {tracker.map((t, index) => (
          <View style={[styles.row]} key={index}>
            {/* Icon column */}
            <View style={[styles.iconColumn]}>
              <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
                {t.Icon}
              </View>

              {/* Connector line */}

              {tracker.length - 1 !== index && (
                <LinearGradient
                  colors={["rgba(51, 171, 247, 1)", "rgba(51, 171, 247, 0)"]}
                  locations={[0, 1]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={styles.connector}
                />
              )}
            </View>

            {/* Label */}
            <View style={{ marginTop: 8 }}>
              <CustomText size="xs" weight="medium" style={styles.label}>
                {t.label}
              </CustomText>
            </View>
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  trackerContainer: {
    borderRadius: 6,
  },
  row: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 16,
  },
  iconColumn: {
    alignItems: "center",
  },
  connector: {
    width: 2,
    height: 18,
    backgroundColor: hexToRgba(PALETTE.primary, 0.3),
    marginVertical: 2,
  },
  label: {
    letterSpacing: -0.24,
  },
  labelPending: {
    opacity: 0.4,
  },
});

export default Tracker;
