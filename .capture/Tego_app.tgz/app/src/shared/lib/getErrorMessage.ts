// shared/lib/getErrorMessage.ts
import { isAxiosError } from "axios";

export const getErrorMessage = (error: unknown): string => {
  if (isAxiosError(error)) {
    return (
      error.response?.data?.error?.message ?? // { error: { message: "..." } }
      error.response?.data?.message ?? // { message: "..." }
      error.message ??
      "Something went wrong"
    );
  }
  return "Something went wrong";
};
