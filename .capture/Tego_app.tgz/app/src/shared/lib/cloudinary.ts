import * as ImageManipulator from "expo-image-manipulator";

// shared/lib/cloudinary.ts

const CLOUDINARY_CLOUD_NAME = process.env.EXPO_PUBLIC_CLOUDINARY_CLOUD_NAME;
const CLOUDINARY_UPLOAD_PRESET =
  process.env.EXPO_PUBLIC_CLOUDINARY_UPLOAD_PRESET;

/** Images are resized down to at most this width before upload. */
const MAX_UPLOAD_WIDTH = 1600;

export const CLOUDINARY_FOLDERS = {
  PROFILE_PICTURE: "tego/profile_pictures",
  PROFILE_CARD: "tego/profile_cards",
  VERIFICATION_DOCS: "tego/verification_docs",
  ISSUE_IMAGES: "tego/issue_images",
  BOOKING_IMAGES: "tego/booking_images",
  REQUEST_IMAGES: "tego/request_images",
  OFFER_IMAGES: "tego/offer_images",
  MESSAGE_IMAGES: "tego/message_images",
  JOBS: "tego/job_images",
  SERVICES: "tego/service_images",
} as const;

export type CloudinaryFolder =
  (typeof CLOUDINARY_FOLDERS)[keyof typeof CLOUDINARY_FOLDERS];

export type CloudinaryResponse = {
  secure_url: string;
  public_id: string;
  format: string;
  bytes: number;
};

type UploadOptions = {
  folder?: CloudinaryFolder;
  publicIdToDelete?: string;
};

/**
 * Injects sized/optimized Cloudinary transform components into a delivery URL
 * (right after `/upload/`, before the version segment). Non-Cloudinary URIs
 * (local `file://`, Unsplash, etc.) pass through untouched.
 *
 * `f_auto,q_auto` transcodes HEIC and re-encodes with auto quality; an optional
 * `width` bounds the width to avoid downloading full-res originals into small
 * boxes.
 */
export const transformImageUrl = (
  url: string,
  width?: number,
): string => {
  if (!url || !url.includes("res.cloudinary.com/")) {
    return url;
  }

  const transforms: string[] = [];
  if (width) transforms.push(`w_${width}`);
  transforms.push("f_auto", "q_auto");

  return url.replace("/upload/", `/upload/${transforms.join(",")}/`);
};

/** PDFs (identity verification) are not rasterizable — skip resize. */
export const isResizableImageUri = (uri: string): boolean =>
  !uri.toLowerCase().endsWith(".pdf");

/**
 * Bounds upload payloads on the client: raster images are resized to at most
 * `MAX_UPLOAD_WIDTH` and re-encoded as JPEG before they are attached to the
 * upload request. Falls back to the original URI if manipulation fails.
 */
export const prepareImageForUpload = async (uri: string): Promise<string> => {
  if (!isResizableImageUri(uri)) return uri;

  try {
    const manipulated = await ImageManipulator.manipulateAsync(
      uri,
      [{ resize: { width: MAX_UPLOAD_WIDTH } }],
      { compress: 0.8, format: ImageManipulator.SaveFormat.JPEG },
    );
    return manipulated.uri;
  } catch {
    return uri;
  }
};

// ✅ Standard upload — used everywhere except message images
export const uploadToCloudinary = async (
  uri: string,
  options: UploadOptions,
): Promise<CloudinaryResponse> => {
  const uploadUrl = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;

  if (options.publicIdToDelete && options.publicIdToDelete.length > 0) {
    await deleteFromCloudinary(options.publicIdToDelete);
  }

  const preparedUri = await prepareImageForUpload(uri);
  const filename = preparedUri.split("/").pop() ?? "image.jpg";
  const ext = filename.split(".").pop()?.toLowerCase() ?? "jpeg";
  const mimeType = ext === "png" ? "image/png" : "image/jpeg";

  const formData = new FormData();
  formData.append("file", {
    uri: preparedUri,
    name: filename,
    type: mimeType,
  } as any);
  formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET!);
  formData.append("folder", options.folder ?? "tego/others");

  const response = await fetch(uploadUrl, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    const err = await response.text();
    console.error("[Cloudinary] upload failed:", err);
    throw new Error("Image upload failed");
  }

  return response.json() as Promise<CloudinaryResponse>;
};

// ✅ Progress-tracked upload — used only for message images
export const uploadToCloudinaryWithProgress = async (
  uri: string,
  options: UploadOptions,
  onProgress?: (progress: number) => void,
  signal?: AbortSignal,
): Promise<CloudinaryResponse> => {
  const uploadUrl = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;

  const preparedUri = await prepareImageForUpload(uri);
  const formData = new FormData();

  // 👇 Use plain object instead of new File() — works with XHR FormData
  const filename = preparedUri.split("/").pop() ?? "image.jpg";
  const ext = filename.split(".").pop()?.toLowerCase() ?? "jpeg";
  const mimeType = ext === "png" ? "image/png" : "image/jpeg";

  formData.append("file", {
    uri: preparedUri,
    name: filename,
    type: mimeType,
  } as any);

  formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET!);
  formData.append("folder", options.folder ?? "tego/others");

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", uploadUrl);

    signal?.addEventListener("abort", () => {
      xhr.abort();
      reject(new Error("Upload cancelled"));
    });

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        onProgress?.(e.loaded / e.total);
      }
    };

    xhr.onload = () => {
      if (xhr.status === 200) {
        resolve(JSON.parse(xhr.responseText));
      } else {
        console.error(
          "[Cloudinary] upload failed:",
          xhr.status,
          xhr.responseText,
        );
        reject(new Error(`Upload failed: ${xhr.status} - ${xhr.responseText}`));
      }
    };

    xhr.onerror = () => reject(new Error("Network error during upload"));
    xhr.onabort = () => reject(new Error("Upload cancelled"));
    xhr.send(formData);
  });
};

export const deleteFromCloudinary = async (publicId: string): Promise<void> => {
  const deleteUrl = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/destroy`;

  const formData = new FormData();
  formData.append("public_id", publicId);
  formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET!);

  await fetch(deleteUrl, { method: "POST", body: formData });
};

// ✅ Standard batch upload — sequential, so memory stays flat on ≤3-image uploads
export const uploadManyToCloudinary = async (
  uris: string[],
  options: UploadOptions,
): Promise<CloudinaryResponse[]> => {
  const results: CloudinaryResponse[] = [];
  for (const uri of uris) {
    results.push(await uploadToCloudinary(uri, options));
  }
  return results;
};

// ✅ Batch upload that keeps already-remote Cloudinary URLs untouched —
// only local file URIs are uploaded, preserving array order. Used by request
// edit screens that seed the form with the request's existing (remote) images
// and only append newly-picked local ones. `uploadSingle` is injectable for
// tests (defaults to the module's `uploadToCloudinary`).
export const uploadManyKeepingRemote = async (
  uris: string[],
  options: UploadOptions,
  uploadSingle: (
    uri: string,
    opts: UploadOptions,
  ) => Promise<Pick<CloudinaryResponse, "secure_url">> = uploadToCloudinary,
): Promise<string[]> => {
  const results: string[] = [];
  for (const uri of uris) {
    if (/^https?:\/\//i.test(uri)) {
      results.push(uri);
    } else {
      const { secure_url } = await uploadSingle(uri, options);
      results.push(secure_url);
    }
  }
  return results;
};

// ✅ Progress-tracked batch upload — sequential
export const uploadManyWithProgress = async (
  uris: string[],
  options: UploadOptions,
  onProgress?: (index: number, progress: number) => void,
  signal?: AbortSignal,
): Promise<CloudinaryResponse[]> => {
  const results: CloudinaryResponse[] = [];
  for (let index = 0; index < uris.length; index += 1) {
    results.push(
      await uploadToCloudinaryWithProgress(
        uris[index],
        options,
        (progress) => onProgress?.(index, progress),
        signal,
      ),
    );
  }
  return results;
};
