import {
  CLOUDINARY_FOLDERS,
  isResizableImageUri,
  transformImageUrl,
  uploadManyKeepingRemote,
} from "../cloudinary";

describe("transformImageUrl", () => {
  const cloudUrl =
    "https://res.cloudinary.com/depliegy1/image/upload/v1720000000/team/photo.jpg";

  it("injects f_auto,q_auto right after /upload/", () => {
    expect(transformImageUrl(cloudUrl)).toBe(
      "https://res.cloudinary.com/depliegy1/image/upload/f_auto,q_auto/v1720000000/team/photo.jpg",
    );
  });

  it("prepends a width transform before f_auto,q_auto", () => {
    expect(transformImageUrl(cloudUrl, 400)).toBe(
      "https://res.cloudinary.com/depliegy1/image/upload/w_400,f_auto,q_auto/v1720000000/team/photo.jpg",
    );
  });

  it("handles Cloudinary URLs without a version segment", () => {
    const noVersion =
      "https://res.cloudinary.com/depliegy1/image/upload/default/photo.jpg";
    expect(transformImageUrl(noVersion, 100)).toBe(
      "https://res.cloudinary.com/depliegy1/image/upload/w_100,f_auto,q_auto/default/photo.jpg",
    );
  });

  it("passes through local and non-Cloudinary URLs untouched", () => {
    expect(transformImageUrl("file:///tmp/x.jpg", 400)).toBe(
      "file:///tmp/x.jpg",
    );
    expect(transformImageUrl("https://images.unsplash.com/abc", 400)).toBe(
      "https://images.unsplash.com/abc",
    );
    expect(transformImageUrl("", 400)).toBe("");
    expect(transformImageUrl("https://example.com/img.png")).toBe(
      "https://example.com/img.png",
    );
  });
});

describe("isResizableImageUri", () => {
  it("returns true for raster images and false for PDFs", () => {
    expect(isResizableImageUri("file:///tmp/a.jpg")).toBe(true);
    expect(isResizableImageUri("file:///tmp/b.png")).toBe(true);
    expect(isResizableImageUri("file:///tmp/ver.pdf")).toBe(false);
    expect(isResizableImageUri("FILE.PDF")).toBe(false);
  });
});

describe("uploadManyKeepingRemote", () => {
  const options = { folder: CLOUDINARY_FOLDERS.REQUEST_IMAGES };
  const fakeUpload = jest.fn(async (uri: string) => ({
    secure_url: `https://cloud.example/${uri.split("/").pop()}`,
    public_id: uri,
  }));

  beforeEach(() => {
    fakeUpload.mockClear();
  });

  it("returns [] for an empty input and never uploads", async () => {
    await expect(
      uploadManyKeepingRemote([], options, fakeUpload as any),
    ).resolves.toEqual([]);
    expect(fakeUpload).not.toHaveBeenCalled();
  });

  it("passes already-remote URLs through untouched without uploading", async () => {
    const uris = [
      "https://res.cloudinary.com/x/image/upload/v1/a.jpg",
      "https://res.cloudinary.com/x/image/upload/v1/b.jpg",
    ];
    await expect(
      uploadManyKeepingRemote(uris, options, fakeUpload as any),
    ).resolves.toEqual(uris);
    expect(fakeUpload).not.toHaveBeenCalled();
  });

  it("uploads only local file URIs and preserves array order", async () => {
    const remote =
      "https://res.cloudinary.com/x/image/upload/v1/existing.jpg";
    const locals = ["file:///tmp/new1.jpeg", "file:///tmp/new2.jpeg"];

    const result = await uploadManyKeepingRemote(
      [locals[0], remote, locals[1]],
      options,
      fakeUpload as any,
    );

    expect(result).toEqual([
      "https://cloud.example/new1.jpeg",
      remote,
      "https://cloud.example/new2.jpeg",
    ]);
    expect(fakeUpload).toHaveBeenCalledTimes(2);
    expect(fakeUpload).toHaveBeenNthCalledWith(1, locals[0], options);
    expect(fakeUpload).toHaveBeenNthCalledWith(2, locals[1], options);
  });
});