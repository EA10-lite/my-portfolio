import { refreshTokenRequest } from "@/modules/auth/services/refreshToken.service";
import axios from "axios";
import { router } from "expo-router";
import { tokenStorage } from "./tokenStorage";

export const api = axios.create({
  baseURL: process.env.EXPO_PUBLIC_BASE_URL,
  timeout: 60000,
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
});

// ── Request interceptor ──────────────────────────────
api.interceptors.request.use(
  async (config) => {
    if (!config.headers.Authorization) {
      const token = await tokenStorage.get();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => Promise.reject(error),
);

// ── Response interceptor ─────────────────────────────
let isRefreshing = false;

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const status = error.response?.status;
    const originalRequest = error.config;

    if (status === 401 && !originalRequest._retry) {
      if (isRefreshing) return Promise.reject(error);

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const refreshToken = await tokenStorage.getRefreshToken();

        if (!refreshToken) {
          // 👈 handle missing refresh token
          await tokenStorage.clearAll();
          router.replace("/(public)/signin");
          return Promise.reject(error);
        }

        const data = await refreshTokenRequest({ refreshToken });
        await tokenStorage.set(data.accessToken);
        await tokenStorage.setRefreshToken(data.refreshToken);
        originalRequest.headers.Authorization = `Bearer ${data.accessToken}`;
        isRefreshing = false;
        return api(originalRequest);
      } catch {
        isRefreshing = false;
        await tokenStorage.clearAll();
        router.replace("/(public)/signin");
        return Promise.reject(error); // 👈 reject after logout
      }
    }

    // 👇 reject with original axios error, let hooks handle the message
    return Promise.reject(error);
  },
);
