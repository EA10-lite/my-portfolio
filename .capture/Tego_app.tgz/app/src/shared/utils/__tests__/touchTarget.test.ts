import {
  MIN_TOUCH_TARGET,
  effectiveTouchSize,
  symmetricHitSlop,
} from "../touchTarget";

describe("symmetricHitSlop", () => {
  it("targets 48dp by default", () => {
    expect(MIN_TOUCH_TARGET).toBe(48);
  });

  it("pads small controls up to ~48dp", () => {
    // 24 + 12 + 12 = 48
    expect(symmetricHitSlop(24)).toBe(12);
    // 14 + 17 + 17 = 48
    expect(symmetricHitSlop(14)).toBe(17);
  });

  it("rounds up so the effective target never lands below 48", () => {
    // 15 + 34 = 49
    expect(symmetricHitSlop(15)).toBe(17);
    // 29 + 20 = 49
    expect(symmetricHitSlop(29)).toBe(10);
  });

  it("returns 0 for controls that already meet the target", () => {
    expect(symmetricHitSlop(48)).toBe(0);
    expect(symmetricHitSlop(56)).toBe(0);
    expect(symmetricHitSlop(100)).toBe(0);
  });

  it("supports a custom target", () => {
    expect(symmetricHitSlop(40, 44)).toBe(2);
  });

  it("mirrors every hitSlop value applied during the 48dp audit", () => {
    // 24×24 close containers → +12 = 48
    expect(symmetricHitSlop(24)).toBe(12);
    // 25×25 toggle buttons → +12 = 49
    expect(symmetricHitSlop(25)).toBe(12);
    // 16px close buttons → +16 = 48
    expect(symmetricHitSlop(16)).toBe(16);
    // 14px close (negotiation header) → +17 = 48
    expect(symmetricHitSlop(14)).toBe(17);
    // 18px close (Location) → +15 = 48
    expect(symmetricHitSlop(18)).toBe(15);
    // 12px cancel (ChatMessage upload) → +18 = 48
    expect(symmetricHitSlop(12)).toBe(18);
    // 20px pencil (EditableInput/AddressInput) → +14 = 48
    expect(symmetricHitSlop(20)).toBe(14);
    // ~35px CustomButton pill (non-md sizes) → +7 = 49
    expect(symmetricHitSlop(35)).toBe(7);
    // 44×44 message send/add boxes → +2 = 48
    expect(symmetricHitSlop(44)).toBe(2);
    // 38px calendar day cell (vertical) → +5 + 5 = 48
    expect(symmetricHitSlop(38)).toBe(5);
    // 40px rating stars → +4 + 4 = 48
    expect(symmetricHitSlop(40)).toBe(4);
  });
});

describe("effectiveTouchSize", () => {
  it("adds a numeric hitSlop to both dimensions", () => {
    expect(effectiveTouchSize({ width: 24, height: 24 }, 12)).toEqual({
      width: 48,
      height: 48,
    });
  });

  it("preserves asymmetric per-side hitSlop", () => {
    expect(
      effectiveTouchSize(
        { width: 14, height: 14 },
        { top: 12, bottom: 22, left: 15, right: 10 },
      ),
    ).toEqual({ width: 39, height: 48 });
  });

  it("returns the drawn size when no hitSlop is present", () => {
    expect(
      effectiveTouchSize({ width: 50, height: 50 }, undefined),
    ).toEqual({ width: 50, height: 50 });
  });

  it("reports the drawn size for already-oversized controls", () => {
    expect(
      effectiveTouchSize(
        { width: 60, height: 60 },
        { top: 0, bottom: 0, left: 0, right: 0 },
      ),
    ).toEqual({ width: 60, height: 60 });
  });

  it("reaches ~48×48 for the asymmetric controls in the audit", () => {
    // ChatFooter "remove image" button avoids the 60×60 thumbnail on the right
    const remove = effectiveTouchSize(
      { width: 14, height: 14 },
      { top: 12, bottom: 22, left: 15, right: 10 },
    );
    expect(remove.height).toBeGreaterThanOrEqual(48);
    expect(remove.width).toBeLessThan(48); // capped to stay clear of the thumbnail

    // ImagePicker "remove" avoids the preview image to the right
    const pickerRemove = effectiveTouchSize(
      { width: 18, height: 18 },
      { top: 12, bottom: 18, left: 18, right: 10 },
    );
    expect(pickerRemove.height).toBeGreaterThanOrEqual(48);

    // Input eye toggle sits inside a 56px row
    const eye = effectiveTouchSize(
      { width: 19, height: 14 },
      { top: 17, bottom: 17, left: 8, right: 8 },
    );
    expect(eye.height).toBeCloseTo(48);
  });
});