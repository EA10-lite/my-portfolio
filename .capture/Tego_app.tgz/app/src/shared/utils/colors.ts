import { PALETTE } from "@/constants/colors";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";

export type StatusType =
  | "completed"
  | "success"
  | "pending"
  | "failed"
  | "cancelled"
  | "awaiting"
  | "accepted"
  | "declined"
  | "confirmed"
  | "progress"
  | "in_progress"
  | "in_negotiation"
  | "awaiting_provider";

export const getStatusColor = (type: string | AvailabilityStatus) => {
  const status = type.toLowerCase();
  return status === "cancelled" ||
    status === "failed" ||
    status === "declined" ||
    status === "offline"
    ? PALETTE.error
    : status === "completed" ||
        status === "accepted" ||
        status === "success" ||
        status === "online" ||
        status === "available_to_work"
      ? PALETTE.success
      : status === "pending" ||
          status === "in_negotiation" ||
          status === "busy" ||
          status === "completion_requested" ||
          status === "awaiting_provider"
        ? PALETTE.yellow
        : status === "progress" || status === "in_progress"
          ? PALETTE.primary
          : PALETTE.error;
};
