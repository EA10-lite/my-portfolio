import { Href, router } from "expo-router";

export function replaceRoute(url: Href) {
  if (router.canDismiss()) {
    router.dismissAll();
  }
  router.replace(url);
}
