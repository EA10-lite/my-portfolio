// ~48dp touch-target helpers.
//
// iOS HIG and Android's Material Components both land on a minimum touch
// target around 44–48dp; this project targets 48. When an interactive control
// is drawn smaller than the target, hitSlop expands the touchable area without
// changing what is drawn on screen. See docs/ENGINEERING.md → "Touch targets".

export const MIN_TOUCH_TARGET = 48;

export type HitSlop = {
  top: number;
  bottom: number;
  left: number;
  right: number;
};

export type HitSlopValue = number | HitSlop;

/**
 * Per-side padding required to bring `size` up to the target.
 *
 * Returns 0 when the control already meets the target — a control that is
 * already ≥48dp must NOT carry an unnecessary hitSlop.
 */
export function symmetricHitSlop(
  size: number,
  target: number = MIN_TOUCH_TARGET,
): number {
  const pad = (target - size) / 2;
  return pad > 0 ? Math.ceil(pad) : 0;
}

/**
 * Effective touch rectangle for a drawn control given its hitSlop.
 * Accepts a symmetric number or an asymmetric {top,bottom,left,right} object.
 */
export function effectiveTouchSize(
  base: { width: number; height: number },
  hitSlop: HitSlopValue | undefined,
): { width: number; height: number } {
  if (hitSlop === undefined) return { ...base };
  const top = typeof hitSlop === "number" ? hitSlop : hitSlop.top;
  const bottom = typeof hitSlop === "number" ? hitSlop : hitSlop.bottom;
  const left = typeof hitSlop === "number" ? hitSlop : hitSlop.left;
  const right = typeof hitSlop === "number" ? hitSlop : hitSlop.right;
  return {
    width: base.width + left + right,
    height: base.height + top + bottom,
  };
}