export const formatDate = (dateString: string) => {
  const now = new Date();
  const date = new Date(dateString);

  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (diffInSeconds < 60) {
    return "Just now";
  }

  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) {
    return `${diffInMinutes} min${diffInMinutes > 1 ? "s" : ""} ago`;
  }

  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) {
    return `${diffInHours} hr${diffInHours > 1 ? "s" : ""} ago`;
  }

  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays < 7) {
    return `${diffInDays} day${diffInDays > 1 ? "s" : ""} ago`;
  }

  const diffInWeeks = Math.floor(diffInDays / 7);
  if (diffInWeeks < 4) {
    return `${diffInWeeks} week${diffInWeeks > 1 ? "s" : ""} ago`;
  }

  const diffInMonths = Math.floor(diffInDays / 30);
  if (diffInMonths < 12) {
    return `${diffInMonths} month${diffInMonths > 1 ? "s" : ""} ago`;
  }

  const diffInYears = Math.floor(diffInDays / 365);
  return `${diffInYears} year${diffInYears > 1 ? "s" : ""} ago`;
};

export function formatDateTime(
  dateInput: string | Date,
  timeStr?: string,
): string {
  const baseDate = new Date(dateInput);

  if (isNaN(baseDate.getTime())) {
    throw new Error("Invalid date");
  }

  let finalDate = new Date(baseDate);

  // only merge time if it exists
  if (timeStr) {
    const [hours, minutes, seconds] = timeStr.split(":").map(Number);

    finalDate.setHours(hours);
    finalDate.setMinutes(minutes);
    finalDate.setSeconds(seconds || 0);
    finalDate.setMilliseconds(0);
  }

  const weekday = new Intl.DateTimeFormat("en-US", {
    weekday: "short",
  }).format(finalDate);

  const day = new Intl.DateTimeFormat("en-US", {
    day: "2-digit",
  }).format(finalDate);

  const month = new Intl.DateTimeFormat("en-US", {
    month: "short",
  }).format(finalDate);

  const year = finalDate.getFullYear();

  const time = new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(finalDate);

  return timeStr
    ? `${weekday}, ${day} ${month} ${year} ${time}`
    : `${weekday}, ${day} ${month} ${year}`;
}

export const formatDateAndTime = (date: string | Date) => {
  const d = new Date(date);

  const weekday = d.toLocaleDateString("en-US", {
    weekday: "short",
  });

  const day = d.getDate();

  const month = d.toLocaleDateString("en-US", {
    month: "long",
  });

  const year = d.getFullYear();

  const time = d.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return `${weekday}, ${day} ${month} ${year}, ${time}`;
};

export const formatTimeForDisplay = (value: string): string => {
  if (!value) return "";
  return value; // already in "HH:MM AM/PM" format
};

export const formatCurrency = (
  amount: number,
  currency: string = "NGN",
  locale: string = "en-NG",
  showDecimals: boolean = false,
) => {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(amount);
};

export const formatAccountNumber = (accountNumber: string | number) => {
  const account = String(accountNumber).replace(/\s/g, "");

  if (account.length <= 3) return account;

  const lastThree = account.slice(-3);

  return `**** **** ${lastThree}`;
};

// 🔥 Date formatter
export const formatMessageDate = (dateString: string) => {
  const date = new Date(dateString);
  const now = new Date();

  const diffMs = now.getTime() - date.getTime();
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  // Future / skewed timestamp (e.g. server clock ahead of device) → nothing
  // is "X days ago" for an event that hasn't happened yet. Clamp to Just now
  // so a fresh message never renders "-1 days ago" (then corrects on reopen).
  if (diffMs < 0) {
    return "Just now";
  }

  // Same day → show time (e.g. 11:00AM)
  if (diffDays === 0) {
    return date.toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  }

  // Yesterday
  if (diffDays === 1) {
    return "1 day ago";
  }

  // Within a week
  if (diffDays < 7) {
    return `${diffDays} days ago`;
  }

  // Fallback → date
  return date.toLocaleDateString();
};

// shared/utils/nameFormatter.ts
export const truncateName = (fullName: string): string => {
  if (!fullName || typeof fullName !== "string") {
    return "";
  }

  const trimmedName = fullName.trim();

  if (!trimmedName) {
    return "";
  }

  const parts = trimmedName.split(/\s+/); // Split by any whitespace

  if (parts.length === 0) {
    return "";
  }

  if (parts.length === 1) {
    // Single name - return as is
    return parts[0];
  }

  if (parts.length === 2) {
    // Two names - first name + initial of last name
    return `${parts[0]} ${parts[parts.length - 1].charAt(0)}.`;
  }

  // Three or more names - first name + initials of remaining
  const firstNamePart = parts[0];
  const initials = parts
    .slice(1) // Skip first name
    .map((part) => part.charAt(0).toUpperCase())
    .join(". ");

  return `${firstNamePart} ${initials}.`;
};

export const truncateText = (text: string, maxLength: number = 30): string => {
  if (!text) return "";

  return text.length > maxLength ? `${text.slice(0, maxLength)}...` : text;
};

export const getInitials = (name?: string): string => {
  if (!name?.trim()) return "";

  return name
    .trim()
    .split(/\s+/)
    .map((word) => word[0]?.toUpperCase())
    .slice(0, 2)
    .join("");
};

export const formatRelativeTime = (date: string) => {
  const now = new Date().getTime();
  const then = new Date(date).getTime();

  const seconds = Math.floor((now - then) / 1000);

  if (seconds < 60) return "Just now";

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min${minutes > 1 ? "s" : ""} ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr${hours > 1 ? "s" : ""} ago`;

  const days = Math.floor(hours / 24);

  if (days === 1) return "Yesterday";

  return `${days} day${days > 1 ? "s" : ""} ago`;
};
