// shared/utils/categoryIcon.tsx
import {
  Briefcase, Building, Car, ChefHat, Drill,
  Droplets, Dumbbell, Flower2, Hammer, Heart,
  Home, Laptop, Paintbrush, PawPrint, Shield,
  ShoppingBag, Shirt, Smile, Sparkles, SprayCan,
  Scissors, Truck, Tv, Wrench, Zap,
} from "lucide-react-native";


const ICON_MAP: Record<string, any> = {
  SprayCan, Sparkles, Hammer, Drill, Wrench,
  Droplets, Zap, Tv, Laptop, Paintbrush,
  Home, Building, Car, Truck, ChefHat,
  Scissors, Smile, Heart, Dumbbell, PawPrint,
  Flower2, Shirt, ShoppingBag, Shield, Briefcase,
};


export const getCategoryIcon = (
  name: string,
  props?: { size?: number; color?: string },
) => {
  const Icon = ICON_MAP[name];
  if (!Icon) return null;
  return <Icon size={props?.size ?? 20} color={props?.color ?? "#33ABF7"} />;
};