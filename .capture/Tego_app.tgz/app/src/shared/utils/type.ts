export type STATUS = "pending" | "completed" | "cancelled";
