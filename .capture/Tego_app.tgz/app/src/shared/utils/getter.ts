import { CATEGORIES_TYPE } from "@/constants/types";

export const categoryImageMap: Record<CATEGORIES_TYPE, string> = {
  plumbing:
    "https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=1200&q=80",
  electric:
    "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1200&q=80",
  electrician:
    "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=1200&q=80",
  cleaning:
    "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=1200&q=80",
  carpentry:
    "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=1200&q=80",
  laundry:
    "https://images.unsplash.com/photo-1517677129300-07b130802f46?w=1200&q=80",
  beauty:
    "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=1200&q=80",
};
