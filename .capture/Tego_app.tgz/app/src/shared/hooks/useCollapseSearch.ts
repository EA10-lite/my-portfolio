// shared/hooks/useCollapsibleSearch.ts
import { useEffect, useRef, useState } from "react";
import { Animated } from "react-native";

type UseCollapsibleSearchProps = {
  searchBarHeight?: number;
  duration?: number;
};

export const useCollapsibleSearch = ({
  searchBarHeight = 91,
  duration = 200,
}: UseCollapsibleSearchProps = {}) => {
  const [search, setSearch] = useState<string>("");
  const [isFocused, setIsFocused] = useState<boolean>(false);

  const scrollY = useRef(new Animated.Value(0)).current;
  const filterOpacity = useRef(new Animated.Value(1)).current;
  const filterWidth = useRef(new Animated.Value(1)).current;

  // Collapse search bar on scroll
  const collapsibleHeight = scrollY.interpolate({
    inputRange: [0, searchBarHeight],
    outputRange: [searchBarHeight, 0],
    extrapolate: "clamp",
  });

  const collapsibleOpacity = scrollY.interpolate({
    inputRange: [0, 40],
    outputRange: [1, 0],
    extrapolate: "clamp",
  });

  // Hide/show filter when search is focused
  useEffect(() => {
    Animated.parallel([
      Animated.timing(filterOpacity, {
        toValue: isFocused ? 0 : 1,
        duration,
        useNativeDriver: false,
      }),
      Animated.timing(filterWidth, {
        toValue: isFocused ? 0 : 1,
        duration,
        useNativeDriver: false,
      }),
    ]).start();
  }, [isFocused]);

  const filterMaxWidth = filterWidth.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 60],
  });

  const onScroll = Animated.event(
    [{ nativeEvent: { contentOffset: { y: scrollY } } }],
    { useNativeDriver: false },
  );

  return {
    search,
    setSearch,
    isFocused,
    setIsFocused,
    onScroll,
    scrollY,
    collapsibleStyle: {
      height: collapsibleHeight,
      opacity: collapsibleOpacity,
      overflow: "hidden" as const,
    },
    filterStyle: {
      maxWidth: filterMaxWidth,
      opacity: filterOpacity,
      overflow: "hidden" as const,
    },
  };
};
