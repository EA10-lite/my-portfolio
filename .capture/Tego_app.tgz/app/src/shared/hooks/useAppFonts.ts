import { useFonts } from "expo-font";

export const useAppFonts = () => {
  return useFonts({
    GeistRegular: require("../../../assets/fonts/Geist-Regular.ttf"),
    GeistMedium: require("../../../assets/fonts/Geist-Medium.ttf"),
    GeistSemibold: require("../../../assets/fonts/Geist-SemiBold.ttf"),
    GeistBold: require("../../../assets/fonts/Geist-Bold.ttf"),
  });
};
