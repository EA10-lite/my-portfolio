import { DARK_THEME, LIGHT_THEME } from "@/constants/themes";
import { useThemeStore } from "@/shared/store/themeStore";

export const useTheme = () => {
  const isDark = useThemeStore((state) => state.is_dark);

  return isDark ? DARK_THEME : LIGHT_THEME;
};
