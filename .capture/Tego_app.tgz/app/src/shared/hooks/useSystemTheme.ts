import { useEffect } from "react";
import { Appearance } from "react-native";
import { useThemeStore } from "../store/themeStore";

export const useSystemThemeSync = () => {
  const { is_system: isSystem, useSystemTheme } = useThemeStore();

  useEffect(() => {
    if (isSystem) {
      useSystemTheme();
    }

    const listener = Appearance.addChangeListener(({ colorScheme }) => {
      if (useThemeStore.getState().is_system) {
        useThemeStore.setState({
          is_dark: colorScheme === "dark",
        });
      }
    });

    return () => listener.remove();
  }, []);
};
