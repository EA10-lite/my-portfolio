import { POPUP_HEIGHT } from "@/constants/values";
import { resolveScrollState } from "../useHideTabBarOnScroll";
import { useTabBarStore } from "../useTabBarStore";

describe("resolveScrollState", () => {
  it("keeps the tab bar visible and below-popup near the top", () => {
    expect(resolveScrollState(0, 0)).toEqual({
      hidden: false,
      isBelowPopup: true,
      nextLastOffset: 0,
    });
    expect(resolveScrollState(10, 0)).toEqual({
      hidden: false,
      isBelowPopup: true,
      nextLastOffset: 10,
    });
  });

  it("hides the tab bar when scrolling past 20 and keeps it hidden while scrolling down", () => {
    expect(resolveScrollState(100, 0)).toEqual({
      hidden: true,
      isBelowPopup: false,
      nextLastOffset: 100,
    });

    expect(resolveScrollState(140, 100)).toEqual({
      hidden: true,
      isBelowPopup: false,
      nextLastOffset: 140,
    });
  });

  it("shows the tab bar again when scrolling up", () => {
    expect(resolveScrollState(100, 0)).toEqual({
      hidden: true,
      isBelowPopup: false,
      nextLastOffset: 100,
    });

    expect(resolveScrollState(50, 100)).toEqual({
      hidden: false,
      isBelowPopup: true,
      nextLastOffset: 50,
    });
  });

  it("flips isBelowPopup at the POPUP_HEIGHT boundary even on sub-10px deltas", () => {
    expect(resolveScrollState(POPUP_HEIGHT, 0).isBelowPopup).toBe(false);
    expect(resolveScrollState(POPUP_HEIGHT, POPUP_HEIGHT - 5)).toEqual({
      hidden: undefined,
      isBelowPopup: false,
      nextLastOffset: POPUP_HEIGHT - 5,
    });
    expect(resolveScrollState(POPUP_HEIGHT - 5, POPUP_HEIGHT).isBelowPopup).toBe(
      true,
    );
  });

  it("ignores sub-10px deltas for tab-bar visibility changes", () => {
    const settled = resolveScrollState(100, 0);
    expect(settled.hidden).toBe(true);

    expect(resolveScrollState(105, 100)).toEqual({
      hidden: undefined,
      isBelowPopup: false,
      nextLastOffset: 100,
    });

    expect(resolveScrollState(95, 100)).toEqual({
      hidden: undefined,
      isBelowPopup: false,
      nextLastOffset: 100,
    });
  });

  it("reattaches the tab bar when returning to the very top", () => {
    expect(resolveScrollState(100, 0)).toEqual({
      hidden: true,
      isBelowPopup: false,
      nextLastOffset: 100,
    });

    expect(resolveScrollState(0, 100)).toEqual({
      hidden: false,
      isBelowPopup: true,
      nextLastOffset: 0,
    });
  });
});

describe("useTabBarStore", () => {
  beforeEach(() => {
    useTabBarStore.setState({ hidden: false, isBelowPopup: true });
  });

  it("defaults to a visible tab bar and below-popup state", () => {
    expect(useTabBarStore.getState().hidden).toBe(false);
    expect(useTabBarStore.getState().isBelowPopup).toBe(true);
  });

  it("updates hidden and isBelowPopup via setters", () => {
    useTabBarStore.getState().setHidden(true);
    expect(useTabBarStore.getState().hidden).toBe(true);

    useTabBarStore.getState().setIsBelowPopup(false);
    expect(useTabBarStore.getState().isBelowPopup).toBe(false);
  });
});