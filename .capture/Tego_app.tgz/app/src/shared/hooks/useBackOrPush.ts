import { useNavigationState } from "@react-navigation/native";
import { Href, router } from "expo-router";

export function useBackOrPush(targetUrl: Href, key: string) {
  const routes = useNavigationState((state) => state?.routes);
  const currentIndex = useNavigationState((state) => state?.index);

  const previousRoute = routes?.[currentIndex - 1];
  const previousRouteName = previousRoute?.name;

  return () => {
    const normalizedTarget =
      typeof targetUrl === "string"
        ? targetUrl.replace(/^\//, "")
        : (targetUrl as any)?.pathname?.replace(/^\//, "");

    if (previousRouteName === normalizedTarget || previousRouteName === key) {
      router.back();
    } else {
      router.push(targetUrl);
    }
  };
}
