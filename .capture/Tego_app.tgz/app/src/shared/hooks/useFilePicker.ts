// shared/hooks/useFilePicker.ts
import * as DocumentPicker from "expo-document-picker";
import * as ImageManipulator from "expo-image-manipulator";
import * as ImagePicker from "expo-image-picker";

export type PickedFile = {
  name: string;
  size: number;
  uri: string;
  mimeType: string;
};

type UseFilePickerOptions = {
  onFilePicked?: (file: PickedFile) => void;
  imagePickerOptions?: ImagePicker.ImagePickerOptions;
  allowCrop?: boolean; // 👈 opt-in per call site
};

const useFilePicker = (options: UseFilePickerOptions = {}) => {
  const pickImage = async (crop?: ImageManipulator.Action[]) => {
    // No permission needed: launchImageLibraryAsync uses the system photo picker
    // (Android 13+ Photo Picker / iOS PHPicker), as required by Google Play policy.
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: false,
      allowsEditing: options.allowCrop ?? false, // 👈 false by default
      ...(options.allowCrop && {
        aspect: options.imagePickerOptions?.aspect ?? [1, 1],
      }),
      quality: 0.8,
      ...options.imagePickerOptions,
    });

    if (!result.canceled && result.assets.length > 0) {
      const asset = result.assets[0];
      let uri = asset.uri;

      if (crop?.length) {
        const manipulated = await ImageManipulator.manipulateAsync(uri, crop, {
          compress: 0.8,
          format: ImageManipulator.SaveFormat.JPEG,
        });
        uri = manipulated.uri;
      }

      const file: PickedFile = {
        name: asset.fileName ?? uri.split("/").pop() ?? "image.jpg",
        size: asset.fileSize ?? 0,
        uri,
        mimeType: asset.mimeType ?? "image/jpeg",
      };

      options.onFilePicked?.(file);
      return result.assets;
    }

    return null;
  };

  const pickDocument = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      copyToCacheDirectory: true,
      multiple: false,
    });

    if (!result.canceled && result.assets.length > 0) {
      const asset = result.assets[0];
      const file: PickedFile = {
        name: asset.name,
        size: asset.size ?? 0,
        uri: asset.uri,
        mimeType: asset.mimeType ?? "application/octet-stream",
      };

      options.onFilePicked?.(file);
      return result.assets;
    }

    return null;
  };

  return { pickImage, pickDocument };
};

export default useFilePicker;
