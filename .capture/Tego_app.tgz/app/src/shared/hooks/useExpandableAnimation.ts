import { useEffect, useRef, useState } from "react";
import { Animated } from "react-native";

type UseExpandableAnimationProps = {
  initialState?: boolean;
  duration?: number;
  isOpen?: boolean;
};

export const useExpandableAnimation = ({
  initialState = true,
  duration = 300,
  isOpen,
}: UseExpandableAnimationProps = {}) => {
  const [showContent, setShowContent] = useState<boolean>(
    isOpen ?? initialState,
  );

  const [contentHeight, setContentHeight] = useState<number>(0);

  const animatedHeight = useRef(
    new Animated.Value(initialState ? 9999 : 0),
  ).current;

  const rotateAnim = useRef(
    new Animated.Value(initialState ? 1 : 0),
  ).current;

  const opacityAnim = useRef(new Animated.Value(0)).current;

  // Sync with parent's isOpen state
  useEffect(() => {
    if (isOpen !== undefined) {
      setShowContent(isOpen);
    }
  }, [isOpen]);

  // Height + rotation animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(animatedHeight, {
        toValue: showContent ? contentHeight : 0,
        duration,
        useNativeDriver: false,
      }),

      Animated.timing(rotateAnim, {
        toValue: showContent ? 1 : 0,
        duration,
        useNativeDriver: true,
      }),
    ]).start();
  }, [
    showContent,
    contentHeight,
    duration,
    animatedHeight,
    rotateAnim,
  ]);

  // Fade animation
  useEffect(() => {
    Animated.timing(opacityAnim, {
      toValue: showContent ? 1 : 0,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [showContent, opacityAnim]);

  const rotate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "180deg"],
  });

  const toggle = () => {
    setShowContent((prev) => !prev);
  };

  return {
    showContent,
    setShowContent,
    toggle,
    contentHeight,
    setContentHeight,
    animatedHeight,
    rotate,
    opacityAnim,

    animatedStyle: {
      height: animatedHeight,
      overflow: "hidden" as const,
    },

    rotateStyle: {
      transform: [{ rotate }],
    },
  };
};