import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useRef } from "react";
import { POPUP_HEIGHT } from "@/constants/values";
import { useTabBarStore } from "./useTabBarStore";

export interface ScrollDecision {
  /** `undefined` = tab bar visibility should not change. */
  hidden: boolean | undefined;
  isBelowPopup: boolean;
  nextLastOffset: number;
}

/**
 * Pure decision logic for the tab-bar hide/show + status-bar threshold.
 *
 * Kept free of React/store so it can be unit-tested deterministically.
 * - Tab bar hides only when scrolling down past 20, shows when scrolling up.
 * - Deltas under 10px do not change tab-bar visibility.
 * - `isBelowPopup` is recomputed on every event (can flip even on small deltas).
 */
export const resolveScrollState = (
  currentOffset: number,
  lastOffset: number,
): ScrollDecision => {
  const diff = currentOffset - lastOffset;
  const isBelowPopup = currentOffset < POPUP_HEIGHT;

  if (currentOffset <= 20) {
    return { hidden: false, isBelowPopup, nextLastOffset: currentOffset };
  }

  if (Math.abs(diff) < 10) {
    return { hidden: undefined, isBelowPopup, nextLastOffset: lastOffset };
  }

  return { hidden: diff > 0, isBelowPopup, nextLastOffset: currentOffset };
};

export const useHideTabBarOnScroll = () => {
  const setHidden = useTabBarStore((state) => state.setHidden);
  const setIsBelowPopup = useTabBarStore((state) => state.setIsBelowPopup);
  const lastOffset = useRef(0);

  // A screen gains focus on tab switch / navigation back. The `hidden` flag is
  // global (one store shared by every tab), so without a reset here the bar
  // stays hidden on a screen the user never scrolled. Restore it visible and
  // forget the previous scroll offset, so the first scroll re-establishes the
  // hide/show state from the top.
  useFocusEffect(
    useCallback(() => {
      lastOffset.current = 0;
      if (useTabBarStore.getState().hidden) {
        setHidden(false);
      }
      if (!useTabBarStore.getState().isBelowPopup) {
        setIsBelowPopup(true);
      }
    }, [setHidden, setIsBelowPopup]),
  );

  const handleScroll = (event: any) => {
    const { hidden, isBelowPopup, nextLastOffset } = resolveScrollState(
      event.nativeEvent.contentOffset.y,
      lastOffset.current,
    );

    // Only publish on actual changes; zustand notifies subscribers on every
    // set(), so write an unchanged value back per frame would re-render trees
    // subscribed to the whole store.
    if (hidden !== undefined && useTabBarStore.getState().hidden !== hidden) {
      setHidden(hidden);
    }

    if (useTabBarStore.getState().isBelowPopup !== isBelowPopup) {
      setIsBelowPopup(isBelowPopup);
    }

    lastOffset.current = nextLastOffset;
  };

  return { handleScroll };
};