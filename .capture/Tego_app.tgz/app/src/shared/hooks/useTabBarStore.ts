import { create } from "zustand";

interface TabBarStore {
  hidden: boolean;
  setHidden: (hidden: boolean) => void;
  isBelowPopup: boolean;
  setIsBelowPopup: (isBelowPopup: boolean) => void;
}

export const useTabBarStore = create<TabBarStore>((set) => ({
  hidden: false,
  setHidden: (hidden) => set({ hidden }),
  isBelowPopup: true,
  setIsBelowPopup: (isBelowPopup) => set({ isBelowPopup }),
}));