// hooks/useModalState.ts
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useRef, useState } from "react";

export const useModalState = () => {
  const ref = useRef<BottomSheetModal>(null);
  const [isOpen, setIsOpen] = useState(false);

  const open = () => {
    setIsOpen(true);
    ref.current?.present();
  };

  const close = () => {
    setIsOpen(false);
    ref.current?.dismiss();
  };

  return { ref, isOpen, open, close };
};
