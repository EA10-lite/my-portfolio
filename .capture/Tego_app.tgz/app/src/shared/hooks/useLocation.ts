import { useEffect } from "react";
import { useLocationStore } from "@/shared/store/locationStore";

type DeviceLocationData = {
  device_name: string | null;
  device_ip: string | null;
  location: {
    longitude: number | null;
    latitude: number | null;
    address: string | null;
    city: string | null;
    state: string | null;
    country: string | null;
  };
};

// Reads the single shared GPS/IP chain held by `locationStore` (kicked off once
// from the root layout). Previously this hook fired a full permission → GPS →
// reverse-geocode → ipify sequence on every mounted screen, duplicating the
// chain for each consumer.
export const useDeviceInfo = () => {
  const {
    address,
    city,
    state,
    country,
    latitude,
    longitude,
    device_name,
    device_ip,
    loading,
    hasFetched,
    getCurrentLocation,
  } = useLocationStore();

  useEffect(() => {
    if (!hasFetched && !loading) {
      getCurrentLocation();
    }
  }, [hasFetched, loading, getCurrentLocation]);

  const data: DeviceLocationData = {
    device_name,
    device_ip,
    location: {
      longitude,
      latitude,
      address,
      city,
      state,
      country,
    },
  };

  return data;
};