import Logo from "@/assets/images/app-icons/logo.svg";
import { PALETTE } from "@/constants/colors";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
interface AuthLayoutProps {
  children: React.ReactNode;
}

const AuthLayout = ({ children }: AuthLayoutProps) => {
  const { bottom } = useSafeAreaInsets();
  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[
          "rgba(51, 171, 247, 0.472)",
          "rgba(255, 255, 255, 0.4012)",
          "rgba(141, 141, 141, 0.295)",
        ]}
        locations={[0, 1, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.header}
      >
        {/* Logo */}
        <View style={styles.logo}>
          <Logo width={39} height={35} />
        </View>
      </LinearGradient>
      {/* Replace with your gradient component */}

      <View style={[styles.content, { paddingBottom: bottom || 24 }]}>
        {children}
      </View>
    </View>
  );
};

export default AuthLayout;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    height: 164,
    justifyContent: "flex-end",
    paddingHorizontal: 20,
  },
  logo: {
    marginBottom: 28,
  },
  content: {
    flex: 1,
  },
});
