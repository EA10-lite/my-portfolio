import OrderIcon from "@/assets/images/app-icons/book-check.svg";
import BookingIcon from "@/assets/images/app-icons/booking.svg";
import ExploreIcon from "@/assets/images/app-icons/explore.svg";
import ApplicationIcon from "@/assets/images/app-icons/file.svg";
import HomeIcon from "@/assets/images/app-icons/home.svg";
import MessageIcon from "@/assets/images/app-icons/message.svg";
import RequestIcon from "@/assets/images/app-icons/note-plus.svg";
import ProfileIcon from "@/assets/images/app-icons/profile-alt.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ACCOUNT_TYPE } from "@/modules/auth/types/user.dto";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import React from "react";
import {
  Animated,
  Platform,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CustomText } from "../components";
import { useConversations } from "@/modules/message/hooks/useConversations";

const ICON_SIZE = 18;

const icons: Record<string, (color: string) => React.ReactNode> = {
  index: (color) => (
    <HomeIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  explore: (color) => (
    <ExploreIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  requests: (color) => (
    <RequestIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  applications: (color) => (
    <ApplicationIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  orders: (color) => (
    <OrderIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  order: (color) => (
    <BookingIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  message: (color) => (
    <MessageIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
  profile: (color) => (
    <ProfileIcon width={ICON_SIZE} height={ICON_SIZE} color={color} />
  ),
};

const customerRoutes = ["index", "explore", "order", "message", "profile"];
const providerRoutes = [
  "index",
  "requests",
  "applications",
  "orders",
  "profile",
];

interface CustomTabBarProps extends BottomTabBarProps {
  translateY: Animated.Value;
  type?: ACCOUNT_TYPE;
}

export default function CustomTabBar({
  state,
  navigation,
  translateY,
  type = "CUSTOMER",
}: CustomTabBarProps) {
  const insets = useSafeAreaInsets();
  const { totalUnread } = useConversations();

  const routes = {
    CUSTOMER: customerRoutes,
    SERVICE_PROVIDER: providerRoutes,
  };

  return (
    <Animated.View
      style={[
        styles.wrapper,
        {
          paddingBottom:
            Platform.OS === "android"
              ? insets.bottom
              : Math.min(30, insets.bottom),
          transform: [{ translateY }],
        },
      ]}
    >
      <View style={styles.container}>
        {routes[type].map((routeName) => {
          const index = state.routes.findIndex((r) => r.name === routeName);
          if (index === -1) return null;

          const route = state.routes[index];
          const isFocused = state.index === index;
          const isMessage = routeName === "message";
          const color = isFocused ? PALETTE.primary : PALETTE.white;

          const onPress = () => {
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });
            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          const renderIcon = icons[routeName];
          if (!renderIcon) return null;

          return (
            <TouchableOpacity
              key={route.key}
              accessibilityRole="button"
              onPress={onPress}
              activeOpacity={0.8}
              style={styles.tabButton}
            >
              {renderIcon(color)}
              {isMessage && totalUnread > 0 && (
                <View
                  style={[
                    styles.notificationCount,
                    styles.count,
                    CUSTOM_STYLES.center,
                  ]}
                >
                  <CustomText size="xs" style={{ color: PALETTE.white }}>
                    {totalUnread > 9 ? "9+" : totalUnread}
                  </CustomText>
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: "center",
    pointerEvents: "box-none", // lets touches pass through the wrapper to screen
    paddingHorizontal: 20,
  },
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    backgroundColor: PALETTE.black, // dark pill — swap to your bg color
    borderRadius: 60,
    paddingHorizontal: 8,
    paddingVertical: 8,
    gap: 4,
    width: "100%",
    height: 67,
  },
  tabButton: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  notificationCount: {
    position: "absolute",
    top: 4,
    right: 6,
  },
  count: {
    backgroundColor: PALETTE.error,
    width: 18,
    height: 18,
    borderRadius: 40,
  },
});
