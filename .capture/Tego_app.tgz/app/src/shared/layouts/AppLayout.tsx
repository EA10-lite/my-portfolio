import { PALETTE } from "@/constants/colors";
import React from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
interface AuthLayoutProps {
  children: React.ReactNode;
}

const AppLayout = ({ children }: AuthLayoutProps) => {
  const { bottom } = useSafeAreaInsets();
  return (
    <View style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={[
          styles.content,
          { paddingBottom: bottom || 24 },
        ]}
      >
        {children}
      </ScrollView>
    </View>
  );
};

export default AppLayout;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    // flex: 1,
  },
});
