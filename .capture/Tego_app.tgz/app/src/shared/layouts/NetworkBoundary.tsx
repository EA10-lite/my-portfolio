import InfoIcon from "@/assets/images/app-icons/info-alt.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import * as Network from "expo-network";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Animated,
  Platform,
  StyleSheet,
  View,
} from "react-native";
import { FullWindowOverlay } from "react-native-screens";
import { CustomText } from "../components";

type NetworkStatus = "stable" | "poor" | "offline";

const CHECK_INTERVAL = 5000;

const NetworkToast = () => {
  const [status, setStatus] = useState<NetworkStatus>("stable");

  const translateY = useRef(new Animated.Value(-200)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  const isVisible = status !== "stable";

  /**
   * Check the current network status
   */
  const checkNetwork = useCallback(async () => {
    try {
      const networkState = await Network.getNetworkStateAsync();

      /**
       * No network connection at all
       */
      if (!networkState.isConnected) {
        setStatus("offline");
        return;
      }

      /**
       * Device is connected to a network,
       * but internet is not reachable.
       */
      if (networkState.isInternetReachable === false) {
        setStatus("offline");
        return;
      }

      /**
       * If internet reachability is unknown,
       * don't immediately mark it as poor.
       */
      if (networkState.isInternetReachable === null) {
        return;
      }

      /**
       * Network is available and reachable.
       */
      setStatus("stable");
    } catch (error) {
      console.log("Network check error:", error);

      /**
       * If checking the network itself fails,
       * treat the connection as poor rather than offline.
       */
      setStatus("poor");
    }
  }, []);

  /**
   * Monitor network status continuously
   */
  useEffect(() => {
    checkNetwork();

    const interval = setInterval(() => {
      checkNetwork();
    }, CHECK_INTERVAL);

    return () => {
      clearInterval(interval);
    };
  }, [checkNetwork]);

  /**
   * Animate toast in/out
   */
  useEffect(() => {
    if (isVisible) {
      Animated.parallel([
        Animated.spring(translateY, {
          toValue: 0,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }),

        Animated.timing(opacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.spring(translateY, {
          toValue: -200,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }),

        Animated.timing(opacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [isVisible, translateY, opacity]);

  /**
   * Don't render anything when the network is stable.
   */
  if (!isVisible) {
    return null;
  }

  const isOffline = status === "offline";

  const title = isOffline
    ? "No internet connection"
    : "Poor network connection";

  const message = isOffline
    ? "Please check your internet connection and try again."
    : "Your internet connection is unstable. Some features may be slow.";

  const content = (
    <View style={styles.container}>
      <Animated.View
        style={[
          styles.content,
          {
            transform: [{ translateY }],
            opacity,
          },
        ]}
      >
        {/* Header */}
        <View style={[CUSTOM_STYLES.row, styles.box]}>
          <View style={[CUSTOM_STYLES.row, styles.titleContainer]}>
            <InfoIcon
              width={12}
              height={12}
              color={PALETTE.primary}
            />

            <CustomText weight="bold" size="md">
              {title}
            </CustomText>
          </View>

          <AntDesign
            name="wifi"
            size={16}
            color={PALETTE.primary}
          />
        </View>

        {/* Message */}
        <CustomText
          weight="medium"
          size="xs"
          style={styles.message}
        >
          {message}
        </CustomText>
      </Animated.View>
    </View>
  );

  /**
   * FullWindowOverlay is useful on iOS because
   * the toast needs to appear above the rest of the app.
   */
  if (Platform.OS === "ios") {
    return (
      <FullWindowOverlay>
        {content}
      </FullWindowOverlay>
    );
  }

  return content;
};

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 9999,
  },

  content: {
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingTop: 73,
    paddingBottom: 24,
  },

  box: {
    flex: 1,
  },

  titleContainer: {
    flex: 1,
    gap: 4,
  },

  message: {
    opacity: 0.7,
    marginLeft: 16,
    marginTop: 4,
  },
});

export default NetworkToast;