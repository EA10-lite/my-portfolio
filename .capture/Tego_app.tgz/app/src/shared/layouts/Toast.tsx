import InfoIcon from "@/assets/images/app-icons/info-alt.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useEffect, useRef } from "react";
import { Animated, Platform, Pressable, StyleSheet, View } from "react-native";
import { FullWindowOverlay } from "react-native-screens";
import { CustomText } from "../components";
import { useToastStore } from "../store/toastStore";

const Toast = () => {
  const { message, title, isVisible, hideToast, position } = useToastStore();
  const translateY = useRef(new Animated.Value(100)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isVisible) {
      // Set initial offset based on position before animating in
      translateY.setValue(position === "top" ? -200 : 100);

      // Slide in animation
      Animated.parallel([
        Animated.spring(translateY, {
          toValue: 0,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();

      // Auto dismiss after 3 seconds
      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.spring(translateY, {
            toValue: position === "top" ? -200 : 100,
            useNativeDriver: true,
            tension: 50,
            friction: 8,
          }),
          Animated.timing(opacity, {
            toValue: 0,
            duration: 200,
            useNativeDriver: true,
          }),
        ]).start(() => {
          hideToast();
        });
      }, 3000);

      return () => clearTimeout(timer);
    } else {
      // Reset animation values when hidden
      translateY.setValue(position === "top" ? -200 : 100);
      opacity.setValue(0);
    }
  }, [isVisible, hideToast, translateY, opacity, position]);

  if (!isVisible) return null;

  return (
    <>
      {Platform.OS === "ios" ? (
        <FullWindowOverlay>
          <View style={[styles.container]}>
            <Animated.View
              style={[
                {
                  transform: [{ translateY }],
                  opacity,
                },
                styles.content,
              ]}
            >
              <View style={[CUSTOM_STYLES.row, styles.box]}>
                <View style={[CUSTOM_STYLES.row, { flex: 1, gap: 4 }]}>
                  <InfoIcon width={12} height={12} color={PALETTE.primary} />
                  <CustomText weight="bold" size="md">
                    {title}
                  </CustomText>
                </View>

                <Pressable onPress={hideToast} hitSlop={14}>
                  <AntDesign name="close" />
                </Pressable>
              </View>
              <CustomText weight="medium" size="xs" style={styles.message}>
                {message}
              </CustomText>
            </Animated.View>
          </View>
        </FullWindowOverlay>
      ) : (
        <View style={styles.container}>
          <Animated.View
            style={[
              {
                transform: [{ translateY }],
                opacity,
              },
              styles.content,
            ]}
          >
            <View style={[CUSTOM_STYLES.row, styles.box]}>
              <View style={[CUSTOM_STYLES.row, { flex: 1, gap: 4 }]}>
                <InfoIcon width={12} height={12} color={PALETTE.primary} />
                <CustomText weight="bold" size="md">
                  {title}
                </CustomText>
              </View>

              <Pressable onPress={hideToast} hitSlop={14}>
                <AntDesign name="close" />
              </Pressable>
            </View>
            <CustomText weight="medium" size="xs" style={styles.message}>
              {message}
            </CustomText>
          </Animated.View>
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 99,
  },
  content: {
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingTop: 73,
    paddingBottom: 24,
  },
  message: {
    opacity: 0.7,
    marginLeft: 16,
    marginTop: 4,
  },
  box: {
    flex: 1,
  },
});

export default Toast;
