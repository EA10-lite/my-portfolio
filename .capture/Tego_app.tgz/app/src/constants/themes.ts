// constants/themes.ts
import { PALETTE } from "./colors";

export const LIGHT_THEME = {
  background: PALETTE.white,
  surface: PALETTE.gray50,
  black: PALETTE.black,
  white: PALETTE.white,

  textPrimary: PALETTE.primary,
  textSecondary: PALETTE.gray500,

  border: PALETTE.gray200,

  primary: PALETTE.primary,
  secondary: PALETTE.secondary,
  success: PALETTE.green500,
  error: PALETTE.red500,
};

export const DARK_THEME = {
  background: PALETTE.gray900,
  surface: "#1F2937",
  black: PALETTE.white,
  white: PALETTE.black,

  textPrimary: PALETTE.primary,
  textSecondary: PALETTE.gray200,

  border: "#374151",

  primary: PALETTE.primary,
  secondary: PALETTE.secondary,
  success: PALETTE.green500,
  error: PALETTE.red500,
};
