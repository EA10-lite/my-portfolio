// constants/typography.ts
export const TYPOGRAPHY = {
  fontFamily: {
    regular: "GeistRegular",
    medium: "GeistMedium",
    bold: "GeistBold",
    semibold: "GeistSemibold",
  },

  fontSize: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 20,
    xl: 24,
    xxl: 32,
  },

  lineHeight: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 28,
  },
};
