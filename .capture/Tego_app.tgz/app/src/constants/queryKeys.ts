/**
 * Single source of truth for all React Query cache keys.
 *
 * Every `useQuery`/`useInfiniteQuery` `queryKey` and every
 * `invalidateQueries`/`setQueryData`/`removeQueries` call should reference
 * these keys instead of inline string arrays. This prevents cache-key typos,
 * collisions, and the dead `[""]` invalidation pattern.
 *
 * Conventions:
 * - Key prefixes are the FIRST element of the array. Because React Query
 *   invalidates by *prefix*, `invalidateQueries({ queryKey: X.all })` clears
 *   every variant under that prefix (e.g. all `["order-details", id, type]`).
 * - `detail(id)` style helpers return a longer key for a single resource.
 * - Per-user / private keys are excluded from AsyncStorage persistence in
 *   `src/app/_layout.tsx` (see `shouldDehydrateQuery`).
 */
export const queryKeys = {
  categories: {
    all: ["categories"] as const,
    mostBooked: ["most-booked-categories"] as const,
    withProviders: ["categories-with-providers"] as const,
    providers: (params: {
      category_id?: string;
      rating_min?: number;
      preference?: string[];
      latitude?: number | null;
      longitude?: number | null;
      distance_radius?: number;
    }) =>
      [
        "category_providers",
        params.category_id,
        params.rating_min,
        params.preference,
        params.latitude,
        params.longitude,
        params.distance_radius,
      ] as const,
  },

  providers: {
    all: ["providers"] as const,
    list: (params: {
      category_id?: string;
      rating_min?: number;
      preference?: string[];
      latitude?: number | null;
      longitude?: number | null;
      distance_radius?: number;
    }) =>
      [
        "providers",
        params.category_id,
        params.rating_min,
        params.preference,
        params.latitude,
        params.longitude,
        params.distance_radius,
      ] as const,
    detail: (providerId: string) => ["provider-details", providerId] as const,
    review: (providerId: string) => ["providers-review", providerId] as const,
  },

  jobRequests: {
    all: ["job-requests"] as const,
    allWith: (filters: unknown, categoryId?: string, state?: string) => ["job-requests", filters, categoryId, state] as const,
    mine: ["my-job-requests"] as const,
    detail: (id: string) => ["job-request-details", id] as const,
  },

  booking: {
    list: ["my-bookings"] as const,
    listWith: (filters: unknown) => ["my-bookings", filters] as const,
    detail: (requestId: string) => ["booking-details", requestId] as const,
  },

  order: {
    mine: ["my-orders"] as const,
    provider: ["provider-orders"] as const,
    mineWith: (status?: string) => ["my-orders", status] as const,
    providerWith: (status?: string) => ["provider-orders", status] as const,
    detailPrefix: ["order-details"] as const,
    detail: (orderId: string, type?: string) =>
      ["order-details", orderId, type] as const,
  },

  messages: {
    list: ["conversations"] as const,
    offers: ["offer-conversations"] as const,
    support: ["support-message"] as const,
    offerThreadPrefix: ["offer-conversation"] as const,
    offerThread: (jobRequestId: string, userId: string) =>
      ["offer-conversation", jobRequestId, userId] as const,
    jobRequestOffers: (requestId: string, userId: string) =>
      ["job-request-offers", requestId, userId] as const,
  },

  profile: {
    root: ["profile"] as const,
    address: ["user-address"] as const,
    availability: ["availability"] as const,
    services: ["services"] as const,
    verification: ["verification"] as const,
    devices: ["devices"] as const,
    language: ["language"] as const,
    businessLocation: ["business-location"] as const,
  },

  notifications: {
    list: ["notifications"] as const,
    listWith: (type?: string) => ["notifications", type] as const,
    count: ["notifications-count"] as const,
    customerSettings: ["customer-notifications-settings"] as const,
    bookingSettings: ["customer-booking-settings"] as const,
    provider: ["provider-notification"] as const,
  },

  applications: {
    list: ["provider-applications"] as const,
  },

  subscription: {
    plans: ["subscription-plans"] as const,
    mine: ["subscription"] as const,
    paymentHistory: ["payment-history"] as const,
  },

  dashboard: {
    provider: ["provider-dashboard"] as const,
    providerSubscriptionStatus: ["provider-subscription-status"] as const,
  },
} as const;

/**
 * Prefixes that are per-user / private and MUST NOT be persisted to
 * AsyncStorage (see `_layout.tsx` → `shouldDehydrateQuery`). Kept separate
 * from `queryKeys` so persistence excludes stay in one obvious place.
 */
export const PRIVATE_QUERY_PREFIXES = [
  "job-requests",
  "my-job-requests",
  "job-request-details",
  "my-bookings",
  "booking-details",
  "my-orders",
  "provider-orders",
  "order-details",
  "conversations",
  "offer-conversations",
  "offer-conversation",
  "job-request-offers",
  "profile",
  "user-address",
  "availability",
  "services",
  "verification",
  "devices",
  "business-location",
  "notifications",
  "notifications-count",
  "customer-notifications-settings",
  "customer-booking-settings",
  "provider-notification",
  "provider-applications",
  "subscription",
  "payment-history",
  "provider-dashboard",
  "provider-subscription-status",
  "provider-details",
  "providers-review",
  "language",
] as const;
