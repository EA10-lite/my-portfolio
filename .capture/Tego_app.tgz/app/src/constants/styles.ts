import { StyleSheet } from "react-native";
import { PALETTE } from "./colors";

export const CUSTOM_STYLES = StyleSheet.create({
  flex: {
    flex: 1,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
  },
  center: {
    alignItems: "center",
    justifyContent: "center",
  },
  inputs: { gap: 16 },
  divider: {
    backgroundColor: PALETTE.black,
    opacity: 0.04,
    height: 1,
  },
  close: {
    width: 24,
    height: 24,
    borderRadius: 999,
    backgroundColor: PALETTE.white,
    position: "absolute",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 99,
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 50,
  },
  card: {
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
    overflow: "hidden",
  },
  cardHeader: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    gap: 13,
  },
  cardContent: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
  },
  cardBody: {},
  cardFooter: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    justifyContent: "space-between",
  },
  icon: {
    width: 40,
    height: 40,
    backgroundColor: PALETTE.grey01,
    borderRadius: 80,
  },
  toggleButton: {
    width: 25,
    height: 25,
    borderRadius: 50,
    backgroundColor: PALETTE.grey01,
  },
});
