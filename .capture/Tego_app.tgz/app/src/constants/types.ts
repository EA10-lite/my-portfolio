export type CATEGORIES_TYPE =
  | "cleaning"
  | "laundry"
  | "plumbing"
  | "carpentry"
  | "beauty"
  | "electric"
  | "electrician";

export type URGENCY = "TODAY" | "IMMEDIATELY" | "TODAY" | "FLEXIBLE";

export type PRICING_TYPE = "FIXED" | "REQUEST_QUOTE"

export type AVAILABILITY = "available_now";

export type SUBSCRIPTION = "FREE" | "PRO_MONTHLY" | "PRO_YEARLY";

export interface Pagination {
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}
