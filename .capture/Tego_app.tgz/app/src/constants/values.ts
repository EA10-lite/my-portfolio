import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import Constants from "expo-constants";

export const statusBarHeight = Constants.statusBarHeight;

export const TAB_BAR_HEIGHT = 67 + 24;
export const WEBHOOK_TIMER = 60;
export const POPUP_HEIGHT = 70;

export const CATEGROIES = [
  "Cleaning",
  "Beauty",
  "Plumbing",
  "Carpentry",
  "Laundry",
];

export const AVAILABILITIES = [
  {
    label: "Available to work",
    value: "available_to_work" as AvailabilityStatus,
  },
  { label: "Busy", value: "busy" as AvailabilityStatus },
  { label: "Offline", value: "offline" as AvailabilityStatus },
];

export const URGENCY = [
  {
    label: "Immediately",
    value: "IMMEDIATELY",
  },
  {
    label: "Today",
    value: "TODAY",
  },
  {
    label: "Flexible",
    value: "FLEXIBLE",
  },
];

export const BUDGET = [
  {
    label: "Any budget",
    min: 0,
    max: undefined,
  },
  {
    label: "₦5,000 - ₦20,000",
    min: 5000,
    max: 20000,
  },
  {
    label: "₦20,000 - ₦50,000",
    min: 20000,
    max: 50000,
  },
  {
    label: "₦50,000+",
    min: 50000,
    max: undefined,
  },
];

export const freeBenefits = [
  {
    active: true,
    label: "2 services listed",
    limit: true,
  },
  {
    active: true,
    label: "10 inquiries / month",
    limit: true,
  },
  {
    active: true,
    label: "Verified bagde",
    limit: true,
  },
  {
    active: false,
    label: "Priority ranking",
  },
  {
    active: false,
    label: "Analytics dashboard",
  },
];
export const proBenefits = [
  {
    active: true,
    label: "10 services listings",
  },
  {
    active: true,
    label: "10 inquiries / month",
  },
  {
    active: true,
    label: "Verified bagde",
  },
  {
    active: true,
    label: "Priority ranking",
  },
  {
    active: true,
    label: "Analytics dashboard",
  },
];

export const subscriptionPlans = {
  yearly: [
    {
      name: "Free",
      price: 0,
      benefits: freeBenefits,
    },
    {
      name: "Pro Plan",
      price: 48000,
      benefits: proBenefits,
    },
  ],
  monthly: [
    {
      name: "Free",
      price: 0,
      benefits: freeBenefits,
    },
    {
      name: "Pro Plan",
      price: 5000,
      benefits: proBenefits,
    },
  ],
};


export const TIMELINE = [
  "immediately",
  "today",
  "tomorrow",
  "this_week",
  "flexible",
]