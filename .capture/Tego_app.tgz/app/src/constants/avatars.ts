export const avatars = [
  {
    id: "1",
    url: require("../../assets/images/app-images/avatar-1.png"),
  },
  {
    id: "2",
    url: require("../../assets/images/app-images/avatar-2.png"),
  },
  {
    id: "3",
    url: require("../../assets/images/app-images/avatar-3.png"),
  },
  //   { id: 4, url: require("../../../../assets/images/app-images/avatar-1.png") },
  //   { id: 5, url: require("../../../../assets/images/app-images/avatar-2.png") },
  //   { id: 6, url: require("../../../../assets/images/app-images/avatar-3.png") },
  //   { id: 7, url: require("../../../../assets/images/app-images/avatar-3.png") },
];
