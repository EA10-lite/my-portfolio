declare module "naija-state-local-government" {
  const NaijaStates: {
    states: () => string[];
    lgas: (state: string) => {
      state: string;
      lgas: string[];
      senatorial_districts: string[];
    };
  };
  export default NaijaStates;
}
