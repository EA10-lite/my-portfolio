import React from "react";
import { Text } from "react-native";

const VectorIconMock = ({ name, size, color, style, ...rest }: any) => (
  <Text style={[{ fontSize: size, color }, style]} {...rest}>
    {name}
  </Text>
);

export default VectorIconMock;