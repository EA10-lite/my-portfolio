import React from "react";
import { Text } from "react-native";

const SvgMock = ({ width, height, color, style, ...rest }: any) => (
  <Text style={[{ fontSize: width, color }, style]} {...rest} />
);

export default SvgMock;