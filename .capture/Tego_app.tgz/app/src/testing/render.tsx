import { render } from "@testing-library/react-native";
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet";
import React, { ReactElement } from "react";
import type { TestInstance } from "test-renderer";
import { Metrics, SafeAreaProvider } from "react-native-safe-area-context";

/**
 * Fixed safe-area metrics for Jest: `initialWindowMetrics` is null in the test
 * environment (native module absent), and SafeAreaProvider renders nothing
 * without insets.
 */
const TEST_METRICS: Metrics = {
  frame: { x: 0, y: 0, width: 390, height: 844 },
  insets: { top: 47, left: 0, right: 0, bottom: 34 },
};

/**
 * Renders UI wrapped in SafeAreaProvider + BottomSheetModalProvider so that
 * components using `useSafeAreaInsets()` (AuthLayout, ScreenShell, ...) and
 * bottom-sheet modals (SuccessSheet) work under Jest.
 */
export async function renderWithProviders(ui: ReactElement) {
  return render(
    <SafeAreaProvider initialMetrics={TEST_METRICS}>
      <BottomSheetModalProvider>{ui}</BottomSheetModalProvider>
    </SafeAreaProvider>,
  );
}

/**
 * The nearest ancestor Pressable/Touchable* of the Text drawn with `label`.
 * RNTL removes type queries, so the pressable is reached through the label
 * text it renders. Used to read `hitSlop` and to press buttons.
 */
export function pressableForLabel(
  ui: { getByText: (label: string) => TestInstance },
  label: string,
): TestInstance {
  return ui.getByText(label)?.parent?.parent as TestInstance;
}