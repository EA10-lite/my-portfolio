import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import { router } from "expo-router";
import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { Platform } from "react-native";

import { authService } from "@/modules/auth/services/auth.service";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useDeviceInfo } from "@/shared/hooks/useLocation";

interface NotificationContextProps {
  expoPushToken: string | null;
}

const NotificationContext = createContext<NotificationContextProps>({
  expoPushToken: null,
});

export const usePushNotifications = () => useContext(NotificationContext);

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

/**
 * Shared by both the cold-start check and the live listener so the
 * navigation logic only lives in one place.
 */
function navigateForNotificationResponse() {
  const currentUser = useAuthStore.getState().user;

  if (currentUser?.userType === "SERVICE_PROVIDER") {
    router.push("/(service-provider)/notification");
  } else if (currentUser?.userType === "CUSTOMER") {
    router.push("/(customer)/notifications");
  }
}

export default function PushNotificationProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user } = useAuthStore();
  const { device_ip, device_name } = useDeviceInfo();

  const [expoPushToken, setExpoPushToken] = useState<string | null>(null);

  const notificationListener = useRef<Notifications.Subscription | undefined>(
    undefined,
  );

  const responseListener = useRef<Notifications.Subscription | undefined>(
    undefined,
  );

  /**
   * Keeps track of the user/token combination that has already
   * been registered with the backend.
   *
   * This prevents duplicate API calls caused by re-renders.
   */
  const registeredTokenRef = useRef<string | null>(null);

  /**
   * Tracks the identifier of the last notification response we've already
   * acted on, so a cold-start response caught by getLastNotificationResponseAsync
   * doesn't get re-navigated on every remount, and so it doesn't double-fire
   * if the live listener also happens to see it.
   */
  const handledResponseIdRef = useRef<string | null>(null);

  useEffect(() => {
    registerForPushNotifications();

    /**
     * Case 1: app was already running (foreground or backgrounded but
     * alive) when the notification was tapped. This listener catches it.
     */
    responseListener.current =
      Notifications.addNotificationResponseReceivedListener((response) => {
        const id = response.notification.request.identifier;
        if (handledResponseIdRef.current === id) return;
        handledResponseIdRef.current = id;
        navigateForNotificationResponse();
      });

    /**
     * Case 2: app was killed/terminated, and the tap is what launched it.
     * addNotificationResponseReceivedListener attaches too late to catch
     * this — by the time this effect runs, the tap event has already come
     * and gone. getLastNotificationResponseAsync() is Expo's documented
     * way to retrieve it after the fact on startup.
     */
    Notifications.getLastNotificationResponseAsync().then((response) => {
      if (!response) return;
      const id = response.notification.request.identifier;
      if (handledResponseIdRef.current === id) return;
      handledResponseIdRef.current = id;
      navigateForNotificationResponse();
    });

    /**
     * Foreground notification received.
     */
    notificationListener.current =
      Notifications.addNotificationReceivedListener((notification) => {
        console.log(
          "[PushNotification] received:",
          notification.request.content,
        );
      });

    return () => {
      notificationListener.current?.remove();
      responseListener.current?.remove();
    };
  }, []);

  /**
   * Register the Expo push token with the backend AFTER
   * authentication has been established.
   *
   * This effect runs when either:
   *
   * - user becomes available after login
   * - expoPushToken becomes available
   */
  useEffect(() => {
    if (!user || !expoPushToken) {
      return;
    }

    const registrationKey = `${user.id}:${expoPushToken}`;

    /**
     * Prevent registering the exact same user/token
     * combination multiple times.
     */
    if (registeredTokenRef.current === registrationKey) {
      return;
    }

    if (device_ip && device_name) {
      registerTokenWithBackend(expoPushToken, registrationKey);
    }
  }, [user, expoPushToken, device_ip, device_name]);

  /**
   * Get Expo push token.
   */
  const registerForPushNotifications = async () => {
    try {
      /**
       * Android notification channel.
       */
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("default", {
          name: "Default",
          importance: Notifications.AndroidImportance.MAX,
          sound: "default",
          vibrationPattern: [0, 250, 250, 250],
          lightColor: "#33ABF7",
        });
      }

      /**
       * Check existing permission first.
       */
      const existingPermissions = await Notifications.getPermissionsAsync();

      let finalStatus = existingPermissions.status;

      /**
       * Ask the user for permission if necessary.
       */
      if (finalStatus !== "granted") {
        const requestedPermissions =
          await Notifications.requestPermissionsAsync();

        finalStatus = requestedPermissions.status;
      }

      if (finalStatus !== "granted") {
        console.log("[PushNotification] permission denied:", finalStatus);

        return;
      }

      /**
       * Get EAS project ID.
       */
      const projectId =
        Constants.easConfig?.projectId ??
        Constants.expoConfig?.extra?.eas?.projectId;

      if (!projectId) {
        console.log("[PushNotification] EAS project ID not found");

        return;
      }

      /**
       * Get Expo push token.
       */
      const token = await Notifications.getExpoPushTokenAsync({
        projectId,
      });

      console.log("[PushNotification] Expo push token:", token.data);

      /**
       * Store token in context state.
       *
       * We intentionally DO NOT call the backend here.
       */
      setExpoPushToken(token.data);
    } catch (error) {
      console.log("[PushNotification] registration error:", error);
    }
  };

  /**
   * Send the Expo push token to the backend.
   *
   * This function is only called after the user is authenticated.
   */
  const registerTokenWithBackend = async (
    token: string,
    registrationKey: string,
  ) => {
    try {
      console.log("[PushNotification] registering token with backend...");

      await authService.sendToken({
        push_token: {
          type: "EXPO",
          token,
        },
        device_ip: device_ip ?? "",
        device_name: device_name ?? "",
      });

      /**
       * Only mark the token as registered after the API request
       * succeeds.
       */
      registeredTokenRef.current = registrationKey;

      console.log("[PushNotification] token registered successfully");
    } catch (error) {
      console.log(
        "[PushNotification] backend token registration error:",
        error,
      );
    }
  };

  return (
    <NotificationContext.Provider
      value={{
        expoPushToken,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}
