import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { ProfileHeader } from "@/modules/profile/components";
import { useLanguage } from "@/modules/profile/hooks/useLanguage";
import { LanguageSettings } from "@/modules/profile/types/profile.dto";
import { CustomButton, CustomText, SuccessSheet } from "@/shared/components";
import RadioSelector from "@/shared/components/forms/RadioSelector";
import { useModalState } from "@/shared/hooks/useModalState";
import { router } from "expo-router";
import { Formik } from "formik";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const LANGUAGE_OPTIONS = [
  { label: "English (US)", value: "english_us" },
  { label: "English (UK)", value: "english_uk" },
];

const Language = () => {
  const insets = useSafeAreaInsets();
  const { user } = useAuthStore();
  const { update, isUpdating, errorMessage } = useLanguage();

  const modalRef = useModalState();
  const openSuccessModal = () => modalRef.open();
  const closeSuccessModal = () => {
    modalRef.close();
    router.back();
  };

  const handleSubmit = (values: LanguageSettings) => {
    update(values, {
      onSuccess: (data) => {
        console.log("Update language response:", data);
        openSuccessModal();
      },
    });
  };

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Updated Successful"
        description="Your preferred language has been updated successfully."
        onContinue={closeSuccessModal}
        maxWidth={300}
      />
      <ProfileHeader title="Language" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik<LanguageSettings>
            initialValues={{
              language: user?.provider_settings?.language ?? "english_us",
            }}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ values, isSubmitting, handleSubmit, setFieldValue, dirty }) => {
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={[styles.content]}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={CUSTOM_STYLES.flex}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <RadioSelector
                          handleSelect={(value) =>
                            setFieldValue("language", value.value)
                          }
                          selectedValue={values.language}
                          items={LANGUAGE_OPTIONS}
                        />
                        {errorMessage && (
                          <CustomText
                            size="xs"
                            style={{ color: PALETTE.error }}
                          >
                            {errorMessage}
                          </CustomText>
                        )}
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Save"
                      variant="primary"
                      disabled={!dirty || isSubmitting || isUpdating}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    marginTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});

export default Language;
