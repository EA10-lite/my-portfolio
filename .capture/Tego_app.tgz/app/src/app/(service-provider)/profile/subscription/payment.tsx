import BankIcon from "@/assets/images/app-icons/bank.svg";
import BoltIcon from "@/assets/images/app-icons/bolt.svg";
import CardIcon from "@/assets/images/app-icons/card.svg";
import SecuredIcon from "@/assets/images/app-icons/secure.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { WEBHOOK_TIMER } from "@/constants/values";
import { CompletePayment } from "@/modules/payment/components";
import { usePaymentStore } from "@/modules/payment/store/usePaymentStore";
import { PAYMENT_TYPE } from "@/modules/payment/utils/type";
import {
  CustomButton,
  CustomText,
  GoBack,
  SuccessSheet,
} from "@/shared/components";
import { useCountdown } from "@/shared/hooks/useCountdown";
import { formatCurrency } from "@/shared/utils/formatter";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useRef, useState } from "react";
import {
  ImageBackground,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const getIcon = (type: PAYMENT_TYPE) => {
  const props = { width: 20, height: 20, color: PALETTE.primary };
  const iconMap: Record<PAYMENT_TYPE, React.ReactNode> = {
    card: <CardIcon {...props} />,
    bank: <BankIcon {...props} />,
  };
  return iconMap[type] ?? null;
};

const BookingDetails = () => {
  const insets = useSafeAreaInsets();
  const { paymentMethod, setPaymentMethod } = usePaymentStore();

  const [timerStarted, setTimerStarted] = useState(false);
  const { formatted, isExpired, reset } = useCountdown(
    WEBHOOK_TIMER,
    timerStarted,
  );

  const handleGoBack = () => {
    router.back();
  };

  const sheetRef = useRef<BottomSheetModal>(null);
  const completeSheetRef = useRef<BottomSheetModal>(null);

  const openCompleteModal = () => {
    completeSheetRef.current?.present();
  };

  const closeCompleteModal = () => {
    completeSheetRef.current?.dismiss();
  };

  const openSuccess = () => {
    sheetRef.current?.present();
  };
  const closeSuccess = () => {
    sheetRef.current?.dismiss();
  };
  const handlePay = () => {
    openCompleteModal();
    setTimerStarted(true);
    if (isExpired) {
      reset();
    }
  };

  const handleComplete = () => {
    closeCompleteModal();
    setTimerStarted(false);
    // very short delay so modal close animation doesn't clash
    setTimeout(() => openSuccess(), 150);
  };

  const handleSuccess = () => {
    closeSuccess();
    router.dismissAll();
    router.replace("/(customer)/(tabs)");
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={handleGoBack} />
        <CustomText weight="bold" size="lg">
          Payment
        </CustomText>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[styles.content]}
        >
          <LinearGradient
            colors={["#33ABF7", "#3BAEF6", "#070707"]}
            // background: linear-gradient(255.19deg, #33ABF7 -54.53%, #3BAEF6 -54.53%, #070707 101%);

            locations={[1, 0.99, 0]}
            start={{ x: 0, y: 1 }} // 👈 bottom left
            end={{ x: 1, y: 0 }} // 👈 top right (diagonal)
            style={styles.card}
          >
            <ImageBackground
              style={styles.cardImg}
              source={require("../../../../../assets/images/app-images/card-bg.png")}
            ></ImageBackground>
            <View style={{ gap: 1 }}>
              <CustomText
                size="sm"
                style={[styles.amountLabel, styles.textCenter]}
                weight="bold"
              >
                Total Amount
              </CustomText>
              <CustomText
                style={[styles.amount, styles.textCenter]}
                weight="bold"
              >
                {formatCurrency(11600)}
              </CustomText>
            </View>

            <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.center, { gap: 8 }]}>
              <View style={[styles.tab, CUSTOM_STYLES.row]}>
                <BoltIcon color={PALETTE.white} width={14} height={14} />
                <CustomText style={styles.tabText} weight="medium">
                  Fast Payment
                </CustomText>
              </View>
              <View style={[styles.tab, CUSTOM_STYLES.row]}>
                <SecuredIcon color={PALETTE.white} width={12} height={12} />
                <CustomText style={styles.tabText} weight="medium">
                  SSL Secured
                </CustomText>
              </View>
            </View>
          </LinearGradient>
          <View style={{ gap: 20 }}>
            <CustomText size="sm" weight="semibold">
              Select Payment Method
            </CustomText>

            <View style={{ gap: 12 }}>
              <DetailsField
                label="Bank Transfer"
                type="bank"
                value={`Payment Fee: ${formatCurrency(150)}`}
                isSelected={paymentMethod === "bank"}
                handlePress={() => setPaymentMethod("bank")}
              />
              <DetailsField
                label="Debit Card"
                type="card"
                value={`Payment Fee: ${formatCurrency(150)}`}
                isSelected={paymentMethod === "card"}
                handlePress={() => setPaymentMethod("card")}
              />
            </View>
          </View>
        </ScrollView>

        <View
          style={[
            styles.footerContainer,
            { paddingBottom: insets.bottom || 24 },
          ]}
        >
          <CustomButton
            title={`Pay ${formatCurrency(11600)}`}
            variant="primary"
            onPress={handlePay}
          />
        </View>
      </View>

      <CompletePayment
        ref={completeSheetRef}
        closeModal={closeCompleteModal}
        onPress={handleComplete}
        countdown={formatted}
        isExpired={isExpired}
      />

      <SuccessSheet
        ref={sheetRef}
        title="Payment Completed 🎉"
        description="Your monthly pro subscription has been confirmed."
        onContinue={handleSuccess}
        buttonText="Ok, Got it"
        variant="primary"
        showClose={false}
        showConfetti={true}
        maxWidth={252}
      />
    </View>
  );
};

interface FieldProps {
  label: string;
  value: string;
  isLast?: boolean;
  type: PAYMENT_TYPE;
  handlePress: () => void;
  isSelected: boolean;
}

const DetailsField = ({
  label,
  value,
  isLast,
  type,
  handlePress,
  isSelected,
}: FieldProps) => {
  return (
    <Pressable onPress={handlePress}>
      <View
        style={[
          styles.detailsField,
          CUSTOM_STYLES.row,
          isLast && { borderBottomWidth: 0 },
        ]}
      >
        {type && (
          <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
            {getIcon(type as PAYMENT_TYPE)}
          </View>
        )}

        <View style={{ gap: 8, flex: 1 }}>
          <CustomText weight="semibold" size="xs" style={styles.value}>
            {label}
          </CustomText>
          <CustomText
            weight="medium"
            size="xs"
            style={styles.label}
            numberOfLines={2}
          >
            {value}
          </CustomText>
        </View>

        <View style={[styles.radioOuter, CUSTOM_STYLES.center]}>
          {isSelected && <View style={styles.radioInner} />}
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 30,
  },
  body: {},
  card: {
    borderRadius: 10,
    paddingVertical: 33,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    minHeight: 155,
  },
  cardImg: {
    ...StyleSheet.absoluteFillObject,
  },
  textCenter: {
    textAlign: "center",
  },
  amount: {
    fontSize: 30,
    color: PALETTE.white,
  },
  amountLabel: {
    textTransform: "uppercase",
    opacity: 0.4,
    color: PALETTE.white,
  },
  tab: {
    backgroundColor: PALETTE.grey01,
    paddingHorizontal: 6,
    paddingVertical: 4,
    opacity: 0.5,
    borderRadius: 50,
    gap: 4,
  },
  tabText: {
    fontSize: 10,
    color: PALETTE.white,
  },

  details: { gap: 20 },
  detailsField: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 6,
    gap: 14,
    padding: 20,
  },
  label: {
    opacity: 0.5,
  },
  value: {
    letterSpacing: -0.0024,
  },
  radioOuter: {
    width: 16,
    height: 16,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: PALETTE.black10,
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 20,
    backgroundColor: PALETTE.primary,
  },
  footerContainer: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },
});
export default BookingDetails;
