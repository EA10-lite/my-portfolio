import { PALETTE } from "@/constants/colors";
import { queryKeys } from "@/constants/queryKeys";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProfileHeader } from "@/modules/profile/components";
import {
  PaymentHistory,
  PaymentPlan,
  SubscriptionCard,
  SubscriptionCardSkeleton,
} from "@/modules/subscription/components";
import { useSubscriptions } from "@/modules/subscription/hooks/useSubscription";
import { useSubscriptionAction } from "@/modules/subscription/hooks/useSubscriptionAction";
import { SUBSCRIPTION_TYPE } from "@/modules/subscription/types/subscription.dto";
import { CheckoutWebView, CustomButton } from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { useQueryClient } from "@tanstack/react-query";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Subscription = () => {
  const queryClient = useQueryClient();
  const insets = useSafeAreaInsets();

  const ref = useModalState();
  const checkoutRef = useModalState();

  const { subscriptions, isLoading, plans, isPlansLoading } =
    useSubscriptions();
  const { upgrade, isSubmitting, checkoutUrl, setCheckoutUrl } =
    useSubscriptionAction();

  const handlePayment = (planCode: SUBSCRIPTION_TYPE) => {
    if (subscriptions?.plan === planCode) return;

    // Only allow moving from FREE -> PRO_MONTHLY/PRO_ANNUAL,
    // or PRO_MONTHLY -> PRO_ANNUAL. Anything else is a downgrade
    // and is disallowed.
    const isUpgrade =
      subscriptions?.plan === "FREE" ||
      (subscriptions?.plan === "PRO_MONTHLY" && planCode === "PRO_ANNUAL");

    if (!isUpgrade) return;

    upgrade(
      { planCode },
      {
        onSuccess: () => {
          ref.close();
          setTimeout(() => {
            checkoutRef.open();
          }, 800);
        },
      },
    );
  };

  return (
    <View style={styles.container}>
      <ProfileHeader title="Manage Subscription" />

      <View style={[CUSTOM_STYLES.flex]}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.body, CUSTOM_STYLES.flex]}
        >
          <View style={[CUSTOM_STYLES.flex]}>
            <View style={[CUSTOM_STYLES.flex, { gap: 16 }]}>
              {isLoading ? (
                <SubscriptionCardSkeleton />
              ) : (
                <SubscriptionCard
                  plan={subscriptions?.plan_name ?? ""}
                  period={
                    subscriptions?.plan_name.toLowerCase().includes("yearly")
                      ? "yearly"
                      : "monthly"
                  }
                  price={subscriptions?.plan_price ?? 0}
                  renewalDate={
                    subscriptions?.plan !== "FREE"
                      ? subscriptions?.renewed_at
                      : ""
                  }
                />
              )}
              <PaymentHistory />
            </View>
            <View style={[{ paddingBottom: insets.bottom || 24 }]}>
              <CustomButton
                title="Change Plan"
                onPress={ref.open}
                disabled={!plans?.plans || isPlansLoading || !subscriptions}
              />
            </View>
          </View>
        </ScrollView>
      </View>

      {plans?.plans && subscriptions && !checkoutUrl && (
        <PaymentPlan
          isOpen={ref.isOpen}
          ref={ref.ref}
          closeModal={ref.close}
          plans={plans?.plans}
          currentPlan={subscriptions}
          handlePayment={handlePayment}
          isSubmitting={isSubmitting}
        />
      )}

      {checkoutUrl && (
        <CheckoutWebView
          isOpen={checkoutRef.isOpen}
          checkoutUrl={checkoutUrl}
          onClose={() => {
            checkoutRef.close();
            setCheckoutUrl(null);
            queryClient.invalidateQueries({
              queryKey: queryKeys.subscription.mine,
            });
            queryClient.invalidateQueries({
              queryKey: queryKeys.dashboard.provider,
            });
            queryClient.invalidateQueries({
              queryKey: queryKeys.dashboard.providerSubscriptionStatus,
            });
            queryClient.invalidateQueries({
              queryKey: queryKeys.subscription.paymentHistory,
            });
          }}
          onSuccess={() => {
            setCheckoutUrl(null);
            queryClient.invalidateQueries({
              queryKey: queryKeys.subscription.mine,
            });
            queryClient.invalidateQueries({
              queryKey: queryKeys.dashboard.provider,
            });
            queryClient.invalidateQueries({
              queryKey: queryKeys.dashboard.providerSubscriptionStatus,
            });
            queryClient.invalidateQueries({
              queryKey: queryKeys.subscription.paymentHistory,
            });
          }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingHorizontal: 20,
  },
});
export default Subscription;