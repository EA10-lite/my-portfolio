import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProfileHeader } from "@/modules/profile/components";
import { useBusinessLocation } from "@/modules/profile/hooks/useBusinessLocation";
import { BusinessLocationPayload } from "@/modules/profile/types/profile.dto";
import {
  CustomButton,
  CustomText,
  Input,
  Select,
  Sheet,
  SuccessSheet,
} from "@/shared/components";
import RadioSelector from "@/shared/components/forms/RadioSelector";
import { useDeviceInfo } from "@/shared/hooks/useLocation";
import { useModalState } from "@/shared/hooks/useModalState";
import { hexToRgba } from "@/shared/utils/converter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { router } from "expo-router";
import { Formik } from "formik";
import NaijaStates from "naija-state-local-government";
import { useEffect, useMemo, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type selector = { label: string; value: string };

const RADIUS = [
  { label: "5km", value: "custom_5km" },
  { label: "10km", value: "custom_10km" },
  { label: "15km", value: "custom_15km" },
];

const BusinessLocation = () => {
  const insets = useSafeAreaInsets();
  const { location: device } = useDeviceInfo();

  const { location, isLoading, isUpdating, update } = useBusinessLocation();


  const [selectedState, setSelectedState] = useState<string>(
    location?.business_location.state ?? "",
  );

  // Build state options
  const stateOptions = useMemo(
    () =>
      (NaijaStates.states() as string[]).map((state) => ({
        label: state,
        value: state,
      })),
    [],
  );

  // Build LGA options based on selected state
  const lgaOptions = useMemo(() => {
    if (!selectedState) return [];
    try {
      const result = NaijaStates.lgas(selectedState);
      return (result.lgas as string[]).map((lga) => ({
        label: lga,
        value: lga,
      }));
    } catch {
      return [];
    }
  }, [selectedState]);

  const [selectedCustomRadius, setSelectedCustomRadius] =
    useState<selector | null>(null);

  const addCustomRadius = (radius: selector) => {
    setSelectedCustomRadius(radius);
  };

  const modalRef = useModalState();

  const handleSubmit = (values: BusinessLocationPayload) => {
    update(values, {
      onSuccess: (data) => {
        modalRef.open();
      },
    });
  };

  const serviceAreaItems = useMemo(() => {
    const defaultItems = [
      { label: "Within my area only", value: "area_only" },
      { label: "Within my city", value: "city" },
      { label: "Within my state", value: "state" },
    ];

    const savedServiceArea = location?.service_area?.[0];

    const customItem = RADIUS.find((item) => item.value === savedServiceArea);

    return customItem ? [...defaultItems, customItem] : defaultItems;
  }, [location]);

  useEffect(() => {
    const saved = location?.service_area?.[0];

    if (!saved) return;

    const custom = RADIUS.find((item) => item.value === saved);

    if (custom) {
      setSelectedCustomRadius(custom);
    }
  }, [location]);

  const handleContinue = () => {
    modalRef.close();
    router.back();
  };

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Updated Successful"
        description="Your business location has been updated successfully."
        onContinue={handleContinue}
        maxWidth={300}
      />
      <ProfileHeader title="Business Location" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik
            validateOnChange={false}
            initialValues={{
              state: location?.business_location.state ?? "",
              city: location?.business_location.city ?? "",
              area: location?.business_location.area ?? "",
              longitude: device.longitude ?? 0,
              latitude: device.latitude ?? 0,
              service_area: location?.service_area[0] ?? "",
            }}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ values, handleSubmit, setFieldValue, dirty }) => {
              const disabled =
                !values.state ||
                !values.city ||
                !values.area ||
                !values.service_area;
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={[styles.content]}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <Select
                          name="state"
                          placeholder="Select the state"
                          disabled={isUpdating}
                          options={stateOptions}
                          onChange={(value) => {
                            setSelectedState(value);
                            setFieldValue("state", value);
                            setFieldValue("city", "");
                            setFieldValue("area", "");
                          }}
                        />
                        <Select
                          name="city"
                          placeholder="Select the city"
                          disabled={isUpdating || !values.state}
                          options={lgaOptions}
                        />
                        <Input
                          name="area"
                          placeholder="Area / District"
                          disabled={isUpdating}
                        />

                        <View style={styles.divider} />

                        <RadioSelector
                          label="Select Service Area"
                          handleSelect={(items) =>
                            setFieldValue("service_area", items.value)
                          }
                          selectedValue={values.service_area}
                          items={serviceAreaItems}
                        />

                        <CustomRadius
                          selectedRadius={selectedCustomRadius}
                          handleSelect={(radius) => {
                            addCustomRadius(radius);
                            // Auto-select the newly added custom radius
                            setFieldValue("service_area", radius.value);
                          }}
                        />
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Save"
                      variant="primary"
                      disabled={disabled || !dirty}
                      loading={isUpdating}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const CustomRadius = ({
  handleSelect,
  selectedRadius,
}: {
  handleSelect: (radius: selector) => void;
  selectedRadius: selector | null;
}) => {
  const sheetRef = useModalState();

  const [pendingRadius, setPendingRadius] = useState<string>(
    selectedRadius?.value ?? "",
  );

  // 👇 Sync when selectedRadius updates from parent
  useEffect(() => {
    if (selectedRadius?.value) {
      setPendingRadius(selectedRadius.value);
    }
  }, [selectedRadius?.value]);

  const handleSave = () => {
    const selected = RADIUS.find((item) => item.value === pendingRadius);
    if (selected) {
      handleSelect(selected);
      sheetRef.close();
    }
  };

  return (
    <>
      <TouchableOpacity
        style={[styles.triggerButton, CUSTOM_STYLES.row]}
        onPress={sheetRef.open}
      >
        <CustomText
          size="xs"
          weight="medium"
          style={{ color: PALETTE.primary }}
        >
          Custom Radius
        </CustomText>
        <AntDesign name={"plus"} size={14} color={PALETTE.primary} />
      </TouchableOpacity>
      <Sheet ref={sheetRef.ref} onClose={sheetRef.close}>
        <RadioSelector
          items={RADIUS}
          label="Custom Radius"
          handleSelect={(item) => {
            setPendingRadius(item.value);
          }}
          selectedValue={pendingRadius ?? ""}
        />

        <View style={styles.buttonContainer}>
          <CustomButton
            title="Save"
            disabled={!pendingRadius}
            onPress={handleSave}
          />
        </View>
      </Sheet>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },

  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
  divider: {
    height: 1,
    marginVertical: 16,
    backgroundColor: PALETTE.gray100,
  },
  triggerButton: {
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.primary, 0.3),
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
    borderRadius: 53,
    padding: 7.67,
    paddingHorizontal: 11.67,
    gap: 6,
    alignSelf: "flex-start",
  },
  buttonContainer: {
    marginTop: 30,
    paddingBottom: 20,
  },
});
export default BusinessLocation;
