import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useCategories } from "@/modules/categories/hooks/useCategories";
import { ProfileHeader } from "@/modules/profile/components";
import { useServices } from "@/modules/profile/hooks/useServices";
import { AddServiceModal } from "@/modules/service-provider/components";
import {
  Arrow,
  CustomButton,
  CustomText,
  Select,
  SuccessSheet,
} from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { useModalState } from "@/shared/hooks/useModalState";
import { hexToRgba } from "@/shared/utils/converter";
import { formatCurrency } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { router } from "expo-router";
import { Formik } from "formik";
import { useState } from "react";
import {
  Animated,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ServiceOffered = () => {
  const {
    showContent,
    setContentHeight,
    contentHeight,
    setShowContent,
    rotate,
    animatedHeight,
  } = useExpandableAnimation();
  const insets = useSafeAreaInsets();

  const { categories } = useCategories();

  const { services, update, create, isCreating, isUpdating, isLoading } =
    useServices();

  const sheetRef = useModalState();

  /**
   * Build options for the service Select.
   *
   * When a saved service (from the API) has the same name as a
   * category service, we use the saved id so the Select marks it
   * as selected (both lists share the same id). The category id is
   * only used for services not yet saved.
   */
  const getCategoryServices = (categoryId: string, savedList: any[] = []) => {
    const services = categories?.find(
      (category) => category.id === categoryId,
    )?.category_services;

    return (
      services?.map((service) => {
        const saved = savedList.find((s) => s.service_name === service.name);
        return {
          label: service.name,
          value: saved?.id ?? service.id,
        };
      }) || []
    );
  };

  // console.log("get category services", getCategoryServices(services?.service_category?.id, services?.services_list));

  /**
   * Build the payload sent to the API.
   *
   * Predefined services keep their backend `id` so the API can update
   * them in place. Ad-hoc (custom) services have no backend `id` yet,
   * so we omit it and let the API create them from `service_name`,
   * `pricing_type` and `price`.
   */
  const buildServicePayload = (services: any[], predefinedIds: Set<string>) => {
    return services.map((service) => {
      if (predefinedIds.has(service.id)) {
        return service;
      }
      const { id, ...rest } = service;
      return rest;
    });
  };

  const handleSubmit = (values: {
    service_category_id: string;
    services_list: any[];
  }) => {
    /**
     * Use getCategoryServices (with aligned ids) to derive the set of
     * predefined ids. This matches saved service ids to their category
     * counterparts so buildServicePayload correctly identifies them.
     */
    const aligned = getCategoryServices(
      values.service_category_id,
      values.services_list,
    );
    const predefinedIds = new Set(aligned.map((s) => s.value));
    const payload = buildServicePayload(values.services_list, predefinedIds);

    // A services record already exists for this provider → update it.
    // Otherwise create a new one. This is based on whether `services.id`
    // exists, NOT on whether the list is empty (which would prevent
    // clearing an existing record).
    if (
      services?.id &&
      services.service_category &&
      services.service_category_id
    ) {
      console.log("CALLING UPDATE");
      update(
        {
          serviceId: services.id,
          data: { services_list: payload },
        },
        {
          onSuccess: () => {
            sheetRef.open();
          },
        },
      );
    } else {
      console.log("CALLING CREATE");
      create(
        {
          service_category_id: values.service_category_id,
          services_list: payload,
        },
        {
          onSuccess: () => {
            sheetRef.open();
          },
        },
      );
    }
  };

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const ref = useModalState();
  const openSheet = () => {
    setIsOpen(true);
    ref.open();
  };
  const closeSheet = () => {
    setIsOpen(false);
    ref.close();
  };

  const handleContinue = () => {
    sheetRef.close();
    router.back();
  };

  return (
    <View style={styles.container}>
      <ProfileHeader title="Services Offered" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik
            validateOnChange={false}
            initialValues={{
              service_category_id: services?.service_category?.id ?? "",
              services_list: services?.services_list ?? [],
            }}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ handleSubmit, dirty, values, setFieldValue }) => {
              return (
                <>
                  <AddServiceModal
                    ref={ref.ref}
                    closeModal={closeSheet}
                    isOpen={isOpen}
                    services={values.services_list}
                    addService={(data) => {
                      const updated = values.services_list.map((s) => {
                        if (s.service_name === data.name) {
                          return {
                            ...s,
                            pricing_type: data.pricing_type,
                            price: data.price,
                          };
                        }
                        return s;
                      });
                      setFieldValue("services_list", updated);
                      closeSheet();
                    }}
                  />
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={[styles.content]}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <Select
                          name="service_category_id"
                          placeholder="Select category"
                          options={
                            categories?.map((category) => ({
                              label: category.name,
                              value: category.id,
                            })) || []
                          }
                          onChange={(catId) => {
                            setFieldValue("service_category_id", catId);
                            setFieldValue("services_list", []);
                          }}
                          disabled={isLoading}
                        />
                        <Select
                          name="services_list_ids"
                          placeholder="Select services"
                          options={getCategoryServices(
                            values.service_category_id,
                            values.services_list,
                          )}
                          value={values.services_list.map((s) => s.id)}
                          customLabelResolver={(id) => {
                            return values.services_list.find((s) => s.id === id)
                              ?.service_name;
                          }}
                          onChange={(nextIds: string[]) => {
                            const updatedList = nextIds.map((id) => {
                              const existing = values.services_list.find(
                                (s) => s.id === id,
                              );

                              if (existing) {
                                return existing;
                              }

                              const serviceObj = categories
                                ?.find(
                                  (c) => c.id === values.service_category_id,
                                )
                                ?.category_services?.find((s) => s.id === id);

                              return {
                                id,
                                service_name: serviceObj?.name || "",
                                price: 0,
                                pricing_type: "REQUEST_QUOTE" as const,
                              };
                            });

                            setFieldValue("services_list", updatedList);
                          }}
                          allowCustom
                          customInputPlaceholder="Enter your own service"
                          emptyStateMessage="No predefined services for this category yet. Add your own below."
                          onCreateOption={(option) => {
                            setFieldValue("services_list", [
                              ...values.services_list,
                              {
                                id: option.value,
                                service_name: option.label,
                                price: 0,
                                pricing_type: "REQUEST_QUOTE" as const,
                              },
                            ]);
                          }}
                          multiple
                        />
                        <View style={[styles.services]}>
                          {!isLoading && values.service_category_id && (
                            <CustomText
                              weight="medium"
                              style={{ fontSize: 13, letterSpacing: -0.24 }}
                              handlePress={openSheet}
                            >
                              Add Service Price +
                            </CustomText>
                          )}

                          <View
                            style={[
                              CUSTOM_STYLES.row,
                              { gap: 12, flexWrap: "wrap" },
                            ]}
                          >
                            {values?.services_list?.map((list, index) => (
                              <TouchableOpacity
                                style={[
                                  styles.serviceButton,
                                  CUSTOM_STYLES.row,
                                ]}
                                key={index}
                                onPress={() => {
                                  const updated = values.services_list.filter(
                                    (_, i) => i !== index,
                                  );
                                  setFieldValue("services_list", updated);
                                }}
                              >
                                <CustomText
                                  weight="medium"
                                  size="xs"
                                  style={styles.serviceText}
                                >
                                  {list?.service_name || ""}
                                </CustomText>
                                <AntDesign
                                  name="close"
                                  color={PALETTE.primary}
                                  size={10}
                                />
                              </TouchableOpacity>
                            ))}
                          </View>
                        </View>

                        <View style={styles.divider} />

                        <View style={[styles.breakdown]}>
                          <Pressable
                            onPress={() => setShowContent(!showContent)}
                            disabled={values?.services_list?.length <= 0}
                          >
                            <View
                              style={[
                                CUSTOM_STYLES.row,
                                CUSTOM_STYLES.card,
                                styles.breakdownHeading,
                              ]}
                            >
                              <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
                                <CustomText
                                  style={{ fontSize: 13 }}
                                  weight="semibold"
                                >
                                  Pricing
                                </CustomText>
                                <View
                                  style={[CUSTOM_STYLES.center, styles.count]}
                                >
                                  <CustomText
                                    style={{
                                      color: PALETTE.white,
                                      fontSize: 10,
                                    }}
                                  >
                                    {values?.services_list?.length}
                                  </CustomText>
                                </View>
                              </View>

                              <Animated.View
                                style={[
                                  CUSTOM_STYLES.toggleButton,
                                  CUSTOM_STYLES.center,
                                  { transform: [{ rotate }] },
                                ]}
                              >
                                <Arrow
                                  direction="bottom"
                                  color={PALETTE.primary}
                                  size={20}
                                />
                              </Animated.View>
                            </View>
                          </Pressable>
                          {values.services_list.length > 0 && (
                            <Animated.View
                              style={[
                                {
                                  height: animatedHeight,
                                  overflow: "hidden",
                                },
                              ]}
                            >
                              <View
                                onLayout={(event) => {
                                  const height =
                                    event.nativeEvent.layout.height;

                                  if (height > 0 && height !== contentHeight) {
                                    setContentHeight(height);
                                  }
                                }}
                                style={{
                                  position: "absolute",
                                  width: "100%",
                                }}
                              >
                                <View style={styles.breakdownField}>
                                  {values.services_list?.map((list, index) => (
                                    <View key={index}>
                                      <View
                                        style={[
                                          CUSTOM_STYLES.row,
                                          { justifyContent: "space-between" },
                                        ]}
                                      >
                                        <CustomText
                                          weight="medium"
                                          style={{ fontSize: 13, opacity: 0.6 }}
                                        >
                                          {list?.service_name}
                                        </CustomText>
                                        <CustomText
                                          weight="medium"
                                          style={{ fontSize: 13 }}
                                        >
                                          {list?.pricing_type ===
                                          "REQUEST_QUOTE"
                                            ? "Request Quote"
                                            : formatCurrency(list?.price)}
                                        </CustomText>
                                      </View>

                                      {values?.services_list?.length - 1 !==
                                        index && (
                                        <View
                                          style={[
                                            styles.divider,
                                            { marginVertical: 20 },
                                          ]}
                                        />
                                      )}
                                    </View>
                                  ))}
                                </View>
                              </View>
                            </Animated.View>
                          )}
                        </View>
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Update"
                      variant="primary"
                      disabled={!dirty}
                      loading={isUpdating || isCreating}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>

      <SuccessSheet
        ref={sheetRef.ref}
        title="Updated Successfully"
        description="Your services has been updated successfully."
        onContinue={handleContinue}
        onClose={sheetRef.close}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },

  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.gray100,
  },
  serviceButton: {
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.primary, 0.3),
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
    borderRadius: 53,
    padding: 7.67,
    paddingHorizontal: 11.67,
    gap: 4,
    alignSelf: "flex-start",
  },
  serviceText: {
    color: PALETTE.primary,
  },
  buttonContainer: {
    marginTop: 30,
    paddingBottom: 20,
  },
  services: {
    gap: 20,
  },
  breakdown: { gap: 20 },
  breakdownHeading: {
    padding: 16,
    justifyContent: "space-between",
  },
  breakdownField: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  count: {
    width: 20,
    height: 20,
    borderRadius: 40,
    backgroundColor: PALETTE.error,
  },
});
export default ServiceOffered;
