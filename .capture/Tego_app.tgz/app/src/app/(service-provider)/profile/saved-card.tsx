import CardIcon from "@/assets/images/app-icons/card.svg";
import DeleteIcon from "@/assets/images/app-icons/trash-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProfileHeader } from "@/modules/profile/components";
import { AddCardModal } from "@/modules/service-provider/components";
import { SavedCardProps } from "@/modules/service-provider/types/profile.dto";
import {
  CustomButton,
  CustomModal,
  CustomText,
  EmptyMessages,
  SuccessSheet,
} from "@/shared/components";
import { formatAccountNumber } from "@/shared/utils/formatter";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useRef, useState } from "react";
import { ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SaveCard = () => {
  const insets = useSafeAreaInsets();
  const [cards, setCards] = useState<SavedCardProps[]>([]);

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const ref = useRef<BottomSheetModal>(null);
  const openModal = () => {
    ref.current?.present();
    setIsOpen(true);
  };
  const closeModal = () => {
    setIsOpen(false);
    ref.current?.dismiss();
  };

  const successRef = useRef<BottomSheetModal>(null);

  const addCard = (card: SavedCardProps) => {
    setCards([...cards, card]);
    successRef.current?.present();
  };
  const closeSuccessModal = () => {
    closeModal();
    successRef.current?.dismiss();
  };

  const handleDeleteCard = (cardNumber: string) => {
    setCards((card) => card.filter((card) => card.cardNumber !== cardNumber));
  };
  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={successRef}
        title="You're all set 🎉"
        description="Your card has been saved successfully and can now be used for subscription payments."
        onContinue={closeSuccessModal}
        showConfetti={true}
        maxWidth={265}
      />
      <ProfileHeader title="Saved Card" />

      <View style={[CUSTOM_STYLES.flex]}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.body, CUSTOM_STYLES.flex]}
        >
          <View style={[CUSTOM_STYLES.flex]}>
            <View style={[CUSTOM_STYLES.flex]}>
              {cards?.length > 0 ? (
                cards.map((card, index) => (
                  <Card
                    key={index}
                    cardHolderName={card.cardHolderName}
                    cardNumber={card.cardNumber}
                    deleteCard={() => handleDeleteCard(card.cardNumber)}
                  />
                ))
              ) : (
                <EmptyMessages
                  title="No Saved Card"
                  Icon={CardIcon}
                  description="Add a card to make subscription payments faster."
                />
              )}
            </View>
            <View style={[{ paddingBottom: insets.bottom || 24 }]}>
              <CustomButton title="Add Card" onPress={openModal} />
            </View>
          </View>
        </ScrollView>
      </View>

      <AddCardModal
        ref={ref}
        closeModal={closeModal}
        isOpen={isOpen}
        addCard={addCard}
      />
    </View>
  );
};

interface CardProps {
  cardHolderName: string;
  cardNumber: string;
  deleteCard: (cardNumber: string) => void;
}

const Card = ({ cardNumber, cardHolderName, deleteCard }: CardProps) => {
  const deleteModalRef = useRef<BottomSheetModal>(null);
  const openDeleteModal = () => deleteModalRef.current?.present();
  const closeDeleteModal = () => deleteModalRef.current?.dismiss();
  return (
    <>
      <CustomModal
        ref={deleteModalRef}
        onClose={closeDeleteModal}
        title="Delete card"
        description="Are you sure you want to delete the is card?"
        Icon={<CardIcon width={20} height={20} color={PALETTE.primary} />}
        primaryButtonText="Delete"
        primaryAction={() => deleteCard(cardNumber)}
        secondaryButtonText="Cancel"
        secondaryAction={closeDeleteModal}
      />
      <View style={[styles.card, CUSTOM_STYLES.row]}>
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
            <CardIcon color={PALETTE.primary} />
          </View>
          <View style={{ gap: 8 }}>
            <CustomText weight="semibold" style={{ fontSize: 13 }}>
              {cardHolderName}
            </CustomText>
            <View style={[CUSTOM_STYLES.row, { gap: 10, opacity: 0.6 }]}>
              <CustomText weight="medium" size="xs" style={{ opacity: 0.6 }}>
                {formatAccountNumber(cardNumber)}
              </CustomText>
              <View style={[CUSTOM_STYLES.row, { gap: 4 }]}></View>
            </View>
          </View>
        </View>
        <TouchableOpacity onPress={openDeleteModal}>
          <DeleteIcon color={PALETTE.primary} />
        </TouchableOpacity>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingHorizontal: 20,
  },
  card: {
    padding: 20,
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
    justifyContent: "space-between",
  },
});
export default SaveCard;
