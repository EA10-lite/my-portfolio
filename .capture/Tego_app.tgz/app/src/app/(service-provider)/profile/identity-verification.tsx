import ImageIcon from "@/assets/images/app-icons/image.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProfileHeader } from "@/modules/profile/components";
import { useVerification } from "@/modules/profile/hooks/useVerification";
import { identityVerificationSchema } from "@/modules/service-provider/utils/profile.validation";
import {
  Badge,
  CImg,
  CustomButton,
  CustomText,
  EditableInput,
  FileSelectorModal,
  ImagePickerPlaceholder,
  SuccessSheet,
} from "@/shared/components";
import useFilePicker, { PickedFile } from "@/shared/hooks/useFilePicker";
import { useModalState } from "@/shared/hooks/useModalState";
import Ionicons from "@expo/vector-icons/Ionicons";
import { router } from "expo-router";
import { Formik, FormikProps } from "formik";
import { useRef } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type FormValues = {
  nin: string;
  bvn: string;
  personal_document: PickedFile | string | null;
};

const formatSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
};

const IdentityVerification = () => {
  const insets = useSafeAreaInsets();
  const { update, isUpdating, verification } = useVerification();

  const modalRef = useModalState();
  const filePickerRef = useModalState();
  const formikRef = useRef<FormikProps<FormValues>>(null);

  const closeSuccessModal = () => {
    modalRef.close();
    router.back();
  };

  const { pickImage, pickDocument } = useFilePicker({
    onFilePicked: (file) => {
      formikRef.current?.setFieldValue("personal_document", file);
      filePickerRef.close();
    },
  });

  const handleSubmit = (values: FormValues) => {
    if (
      !values.personal_document ||
      typeof values.personal_document === "string"
    )
      return;

    update(
      {
        nin: values.nin,
        bvn: values.bvn,
        uri: values.personal_document.uri,
        mimeType: values.personal_document.mimeType,
      },
      {
        onSuccess: () => modalRef.open(),
      },
    );
  };

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Updated Successfully"
        description="Your identification has been updated successfully."
        onContinue={closeSuccessModal}
        maxWidth={269}
        buttonText="Done"
      />
      <ProfileHeader title="Identity Verification" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <FileSelectorModal
            ref={filePickerRef.ref}
            onClose={filePickerRef.close}
            handleFilePick={pickDocument}
            handleImagePick={pickImage}
          />
          <Formik<FormValues>
            validateOnChange={false}
            innerRef={formikRef}
            initialValues={{
              nin: verification?.bvn.value ?? "",
              bvn: verification?.nin.value ?? "",
              personal_document:
                verification?.professional_document?.file_url ?? null,
            }}
            onSubmit={handleSubmit}
            validationSchema={identityVerificationSchema}
            enableReinitialize
          >
            {({ dirty, handleSubmit, values }) => {
              // const isDisabled = typeof values.personal_document === "string";
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={styles.content}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={CUSTOM_STYLES.flex}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <EditableInput
                          name="nin"
                          placeholder="NIN"
                          label="NIN"
                          isEditable={true}
                          disabled={
                            verification?.status.toLowerCase() === "approved"
                          }
                          HeaderLabel={
                            <Badge
                              variant={
                                verification?.status === "PENDING"
                                  ? "pending"
                                    : verification?.status === "APPROVED"
                                      ? "success"
                                        : "error"
                              }
                              title={
                                verification?.status === "PENDING"
                                  ? "Pending"
                                    : verification?.status === "APPROVED"
                                      ? "Verified"
                                      : verification?.status === "REJECTED"
                                        ? "Rejected"
                                        : "Unverified"
                              }
                            />
                          }
                        />
                        <EditableInput
                          name="bvn"
                          placeholder="BVN"
                          label="BVN"
                          isEditable={true}
                          disabled={
                            verification?.status.toLowerCase() === "approved"
                          }
                          HeaderLabel={
                            <Badge
                              variant={
                                verification?.status === "PENDING"
                                  ? "pending"
                                    : verification?.status === "APPROVED"
                                      ? "success"
                                        : "error"
                              }
                              title={
                                verification?.status === "PENDING"
                                  ? "Pending"
                                    : verification?.status === "APPROVED"
                                      ? "Verified"
                                      : verification?.status === "REJECTED"
                                        ? "Rejected"
                                        : "Unverified"
                              }
                            />
                          }
                        />
                        <View style={styles.divider} />

                        <ImagePickerPlaceholder
                          label="CAC or any relevant Document"
                          HeaderLabel={
                            <Badge
                              variant={
                                verification?.status === "PENDING"
                                  ? "pending"
                                    : verification?.status === "APPROVED"
                                      ? "success"
                                        : "error"
                              }
                              title={
                                verification?.status === "PENDING"
                                  ? "Pending"
                                    : verification?.status === "APPROVED"
                                      ? "Verified"
                                      : verification?.status === "REJECTED"
                                        ? "Rejected"
                                        : "Unverified"
                              }
                            />
                          }
                          maxImages={1}
                          canChange={verification?.status.toLowerCase() !== "approved"}
                          handlePick={filePickerRef.open}
                          images={
                            typeof values.personal_document === "string"
                              ? [values.personal_document] // 👈 show existing URL
                              : []
                          }
                          showPlaceholder={verification?.status === "APPROVED" ? false : true}
                        />

                        {values.personal_document &&
                          typeof values.personal_document !== "string" ? (
                            <View style={[CUSTOM_STYLES.row, styles.document]}>
                              <View
                                style={[
                                  CUSTOM_STYLES.icon,
                                  CUSTOM_STYLES.center,
                                ]}
                              >
                                <ImageIcon
                                  color={PALETTE.primary}
                                  width={13}
                                  height={11}
                                />
                              </View>
                              <View style={{ gap: 8, flex: 1 }}>
                                <CustomText
                                  size="xs"
                                  weight="medium"
                                  style={{ letterSpacing: -0.24 }}
                                  numberOfLines={1}
                                >
                                  {values.personal_document.name}
                                </CustomText>
                                <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                                  <CustomText
                                    weight="medium"
                                    size="xs"
                                    style={styles.fileSize}
                                  >
                                    {formatSize(values.personal_document.size)}
                                  </CustomText>
                                  <View
                                    style={[
                                      CUSTOM_STYLES.dot,
                                      { backgroundColor: "#E3E3E3" },
                                    ]}
                                  />
                                  <View style={[CUSTOM_STYLES.row, { gap: 2 }]}>
                                    <Ionicons
                                      name="checkmark-circle"
                                      color={PALETTE.success}
                                    />
                                    <CustomText
                                      weight="medium"
                                      size="xs"
                                      style={styles.fileSize}
                                    >
                                      Uploaded
                                    </CustomText>
                                  </View>
                                </View>
                              </View>
                            </View>
                          ) : (
                              <View>
                                <CImg
                                  uri={values.personal_document ?? ""}
                                  width={400}
                                  style={styles.previewImage}
                                />
                              </View>
                          )}
                      </View>
                    </View>
                  </ScrollView>

                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Update"
                      variant="primary"
                      disabled={
                        !dirty ||
                        // !isDisabled ||
                        verification?.status.toLowerCase() === "approved"
                      }
                      onPress={handleSubmit}
                      loading={isUpdating}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: PALETTE.white },
  content: { marginTop: 10, paddingHorizontal: 20, paddingBottom: 24 },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
    marginVertical: 8,
  },
  document: {
    backgroundColor: PALETTE.gray,
    padding: 16,
    borderRadius: 6,
    gap: 16,
  },
  previewImage: {
    width: 100,
    height: 100,
    borderRadius: 7,
  },
  fileSize: { opacity: 0.5, letterSpacing: -0.24 },
  form: { gap: 16 },
  footerContainer: { paddingTop: 10, paddingHorizontal: 20 },
});

export default IdentityVerification;
