import TrashIcon from "@/assets/images/app-icons/trash-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useDeleteAccount } from "@/modules/auth/hooks/useDeleteAccount";
import { ProfileHeader } from "@/modules/profile/components";
import { CustomButton, CustomModal, CustomText } from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import Ionicons from "@expo/vector-icons/Ionicons";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const statuses = [
  { isCompleted: true, label: "No Active Bookings" },
  { isCompleted: true, label: "No Pending Payments" },
  { isCompleted: true, label: "No Pending Refunds" },
  { isCompleted: true, label: "No Scheduled Services" },
];

const DeleteAccount = () => {
  const insets = useSafeAreaInsets();
  const deleteModalRef = useModalState()

  const { deleteAccount, isDeleting } = useDeleteAccount();
  const handleDelete = () => {
    deleteAccount();
  }


  return (
    <View style={styles.container}>
      <CustomModal
        ref={deleteModalRef.ref}
        onClose={deleteModalRef.close}
        title="Delete Account"
        description="Your account will be Deleted, and you will lose access to bookings, messages, and account activity."
        Icon={<TrashIcon width={20} height={20} color={PALETTE.error} />}
        primaryButtonText="Delete"
        secondaryButtonText="Cancel"
        secondaryAction={deleteModalRef.open}
        primaryVariant="danger"
        primaryAction={handleDelete}
        primaryLoading={isDeleting}
        hasSecondaryButton={false}
      />
      <ProfileHeader title="Delete Account" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.body}
      >
        <CustomText style={styles.text} weight="medium">
          Before permanently deleting your account, please review the following
          requirements.
        </CustomText>
        <CustomText style={styles.text} weight="medium">
          Your account can only be deleted if there are no active bookings,
          pending payments, or unresolved support requests linked to your
          account.
        </CustomText>
        <CustomText style={styles.text} weight="medium">
          Once deleted, you may lose access to:
        </CustomText>
        <View>
          {[
            "Booking history",
            "Saved addresses",
            "Messages and activity",
            "Account preferences and settings",
          ].map((item, index) => (
            <View key={index} style={[CUSTOM_STYLES.row, styles.listItem]}>
              <CustomText>•</CustomText>

              <CustomText style={styles.text} size="xs" weight="medium">
                {item}
              </CustomText>
            </View>
          ))}
        </View>
        <CustomText style={styles.text} weight="medium">
          Please ensure everything is resolved before continuing.
        </CustomText>

        <View style={{ gap: 16 }}>
          {statuses.map((status, index) => (
            <Status key={index} {...status} />
          ))}
        </View>
      </ScrollView>

      <View
        style={[styles.footerContainer, { paddingBottom: insets.bottom || 24 }]}
      >
        <CustomButton
          title="Delete Account"
          variant="danger"
          disabled={statuses.filter((status) => !status.isCompleted).length > 0}
          onPress={deleteModalRef.open}
        />
      </View>
    </View>
  );
};

const Status = ({
  isCompleted,
  label,
}: {
  isCompleted: boolean;
  label: string;
}) => {
  return (
    <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
      <Ionicons
        name={isCompleted ? "checkmark-circle" : "close-circle-sharp"}
        color={isCompleted ? PALETTE.success : PALETTE.error}
        size={18}
      />
      <CustomText size="sm" weight="medium">
        {label}
      </CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  text: {
    fontSize: 13,
    lineHeight: 19.56,
    letterSpacing: -0.24,
  },
  listItem: { gap: 4, alignItems: "flex-start" },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});
export default DeleteAccount;
