import { PALETTE } from "@/constants/colors";
import { ProfileHeader, Section } from "@/modules/profile/components";
import { CustomText } from "@/shared/components";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const TermsAndConditions = () => {
  const { bottom } = useSafeAreaInsets();
  return (
    <View style={styles.container}>
      <ProfileHeader title="Terms and Conditions" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          {
            paddingBottom: bottom,
          },
        ]}
      >
        <CustomText
          weight="medium"
          size="xs"
          style={{ opacity: 0.6, marginVertical: 12 }}
        >
          Last Update: 10th May, 2026
        </CustomText>
        <View style={styles.sections}>
          <Section
            title="Welcome to Tego"
            description={[
              "Welcome to Tego, a platform that connects customers with independent service providers for a wide range of services.",
              "By creating an account or using Tego, you agree to comply with these Terms and Conditions.",
            ]}
          />
          <Section
            title="Using Tego"
            listTitle="When using Tego, you agree to:"
            list={[
              "Provide accurate information during registration.",
              "Use the platform lawfully and responsibly.",
              "Treat other users respectfully.",
              "Communicate professionally when using platform features.",
            ]}
          />
          <Section
            title="Booking & Payments"
            list={[
              "Payments made through Tego are processed securely.",
              "Users are responsible for reviewing service details before confirming a booking.",
              "Cancellation policies may apply depending on the provider and service type.",
            ]}
          />
          <Section
            title="Safety & Communication"
            description={[
              "For a safer experience, we recommend keeping communications within the Tego platform whenever possible.",
              "Communication outside the platform may limit our ability to assist with support requests or disputes.",
            ]}
          />
          <Section
            title="Prohibited Activities"
            description="The following are not permitted:"
            list={[
              "Fraudulent activity",
              "Impersonation",
              "Harassment or abuse",
              "Misleading information",
              "Illegal services or transactions",
            ]}
          />
          <Section
            title="Account Suspension"
            description="We reserve the right to suspend or terminate accounts that violate these Terms or pose risks to the platform community."
          />
          <Section
            title="Changes to These Terms"
            description="Tego may update these Terms periodically. Continued use of the platform constitutes acceptance of any updates."
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  sections: {
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
  },
});
export default TermsAndConditions;
