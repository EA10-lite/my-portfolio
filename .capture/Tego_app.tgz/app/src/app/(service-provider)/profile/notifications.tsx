import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProfileHeader } from "@/modules/profile/components";
import { useProviderNotification } from "@/modules/profile/hooks/useProviderNotification";
import { ProviderNotificationSettings } from "@/modules/profile/types/profile.dto";
import {
  CustomButton,
  CustomText,
  SuccessSheet,
  Switch,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { hexToRgba } from "@/shared/utils/converter";
import { Formik } from "formik";
import {
  Keyboard,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type NotificationFormValues = {
  new_booking_request: boolean;
  booking_confirmations: boolean;
  booking_reminders: boolean;
  nearby_services: boolean;
  new_categories: boolean;
  customers_review: boolean;
  discount_n_special_deals: boolean;
};

const toFormValues = (
  data?: ProviderNotificationSettings,
): NotificationFormValues => ({
  new_booking_request: data?.bookings.new_booking_request ?? false,
  booking_confirmations: data?.bookings.booking_confirmations ?? false,
  booking_reminders: data?.bookings.booking_reminders ?? false,
  nearby_services: data?.job_posts.nearby_services ?? false,
  new_categories: data?.job_posts.new_categories ?? false,
  customers_review: data?.review_n_ratings.customers_review ?? false,
  discount_n_special_deals:
    data?.promotions_n_offers.discount_n_special_deals ?? false,
});

const toPayload = (
  values: NotificationFormValues,
): ProviderNotificationSettings => ({
  bookings: {
    new_booking_request: values.new_booking_request,
    booking_confirmations: values.booking_confirmations,
    booking_reminders: values.booking_reminders,
  },
  job_posts: {
    nearby_services: values.nearby_services,
    new_categories: values.new_categories,
  },
  review_n_ratings: {
    customers_review: values.customers_review,
  },
  promotions_n_offers: {
    discount_n_special_deals: values.discount_n_special_deals,
  },
});

const Notifications = () => {
  const insets = useSafeAreaInsets();
  const { notification, update, isUpdating } =
    useProviderNotification();

  const sheetRef = useModalState();

  const handleSubmit = (values: NotificationFormValues) => {
    update(toPayload(values), {
      onSuccess: (data) => {
        console.log("Update notification response:", data);
        sheetRef.open();
      },
    });
  };

  return (
    <View style={styles.container}>
      <ProfileHeader title="Notifications" />

      <View style={CUSTOM_STYLES.flex}>
        <View style={styles.container}>
          <Formik<NotificationFormValues>
            initialValues={toFormValues(notification)}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ handleSubmit, dirty }) => (
              <>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  contentContainerStyle={[
                    styles.content,
                    {
                      paddingBottom: insets.bottom,
                    }
                  ]}
                  onScrollBeginDrag={Keyboard.dismiss}
                >
                  <View style={{ gap: 10 }}>
                    <MenuGroup
                      title="Bookings"
                      items={[
                        {
                          label: "New Booking Requests",
                          name: "new_booking_request",
                        },
                        {
                          label: "Booking Confirmations",
                          name: "booking_confirmations",
                        },
                        {
                          label: "Booking Reminders",
                          name: "booking_reminders",
                        },
                      ]}
                    />
                    <MenuGroup
                      title="Job Posts & Service Alerts"
                      items={[
                        {
                          label: "Nearby Requests",
                          name: "nearby_services",
                        },
                        {
                          label: "New Categories",
                          name: "new_categories",
                        },
                      ]}
                    />
                    <MenuGroup
                      title="Reviews & Ratings"
                      items={[
                        {
                          label: "Customer Reviews",
                          name: "customers_review",
                        },
                      ]}
                    />
                    <MenuGroup
                      title="Promotions & Offers"
                      items={[
                        {
                          label: "Discounts and special deals",
                          name: "discount_n_special_deals",
                        },
                      ]}
                    />
                  </View>
                </ScrollView>
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Update"
                    variant="primary"
                    disabled={!dirty}
                    loading={isUpdating}
                    onPress={handleSubmit}
                  />
                </View>
              </>
            )}
          </Formik>
        </View>
      </View>

      <SuccessSheet
        ref={sheetRef.ref}
        title="Updated Successfully"
        description="Your notification preferences has been updated successfully."
        onContinue={sheetRef.close}
        onClose={sheetRef.close}
      />
    </View>
  );
};

interface MenuGroupProps {
  title: string;
  items: { label: string; name: string }[];
}

const MenuGroup = ({ title, items }: MenuGroupProps) => {
  return (
    <View style={styles.menu}>
      <CustomText size="xs" weight="semibold" style={styles.menuTitle}>
        {title}
      </CustomText>
      <View>
        {items.map((item, index) => (
          <View
            key={index}
            style={{
              borderBottomWidth: index + 1 !== items.length ? 1 : 0,
              borderBottomColor:
                index + 1 !== items.length
                  ? hexToRgba(PALETTE.black, 0.04)
                  : "transparent",
              paddingVertical: 16,
              paddingBottom: index + 1 !== items.length ? 16 : 0,
            }}
          >
            <MenuItem title={item.label} name={item.name} />
          </View>
        ))}
      </View>
    </View>
  );
};

const MenuItem = ({ title, name }: { title: string; name: string }) => {
  return (
    <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
      <CustomText weight="medium" style={styles.link}>
        {title}
      </CustomText>
      <Switch name={name} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  menu: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  menuTitle: {
    opacity: 0.5,
    letterSpacing: -0.24,
    textTransform: "uppercase",
  },
  linkItem: {
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  link: {
    fontSize: 13,
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});

export default Notifications;
