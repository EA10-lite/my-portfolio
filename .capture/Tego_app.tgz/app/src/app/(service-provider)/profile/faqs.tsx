import { PALETTE } from "@/constants/colors";
import { ProfileHeader } from "@/modules/profile/components";
import { Accordion } from "@/shared/components";
import { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface FAQ {
  question: string;
  answer: string;
}
const faqs: FAQ[] = [
  {
    question: "How do I create an account?",
    answer:
      "To create an account, download Tego, complete registration, verify your details, and set up your profile.",
  },
  {
    question: "How do I reset my password?",
    answer: "Go to Settings → Security → Change Password.",
  },
  {
    question: "Can I cancel a request?",
    answer: "Yes. Requests can be cancelled before a provider is assigne.",
  },
  {
    question: "What is the difference between a request and a job?",
    answer:
      "Requests are direct service requests sent to providers. Jobs are opportunities posted for providers to review and apply for.",
  },
  {
    question: "How do providers apply for a job?",
    answer:
      "Providers submit proposals that include pricing, timelines, and service details.",
  },
  {
    question: "How do I track my order?",
    answer: "Visit the Orders page to monitor status updates and progress.",
  },
  {
    question: "Should I communicate outside the app?",
    answer:
      "We recommend keeping conversations on Tego to maintain a record of communication and support assistance if needed.",
  },
  {
    question: "How do I contact support?",
    answer: "Open Settings → Support and select Contact Support.",
  },
];

const FAQs = () => {
  const { bottom } = useSafeAreaInsets();

  // null = nothing is open
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const handleToggle = (index: number) => {
    setOpenIndex((currentIndex) =>
      currentIndex === index ? null : index,
    );
  };
  return (
    <View style={styles.container}>
      <ProfileHeader title="FAQs" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          {
            paddingBottom: bottom,
          },
        ]}
      >
        {faqs.map((faq, index) => (
          <Accordion
            key={index}
            title={faq.question}
            description={faq.answer}
            isOpen={openIndex === index}
            onToggle={()=> handleToggle(index)}
          />
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 20,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
});
export default FAQs;
