import LocationIcon from "@/assets/images/app-icons/location.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { CancelRequest } from "@/modules/job/components";
import { useOrder } from "@/modules/order/hooks/useOrder";
import { useOrderActions } from "@/modules/order/hooks/useOrderActions";
import { RequestDetailsSkeleton } from "@/modules/request-job/components";
import {
  CustomButton,
  CustomText,
  DetailsField,
  GoBack,
  ImagePreview,
  NotFound,
  SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useRef, useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type ModalState = "cancel" | "confirmed" | "complete" | null;

const OrderDetails = () => {
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<ScrollView>(null);
  const { showToast } = useToastStore();
  const { orderId } = useLocalSearchParams();
  const { user } = useAuthStore();

  const [modalState, setModalState] = useState<ModalState>(null);

  const sheetRef = useModalState();
  const openCancelModal = () => {
    setModalState("cancel");
    sheetRef.open();
  };

  const { order, isLoading } = useOrder(orderId.toString());
  const {
    update,
    isSubmitting,
    cancelOrder: sendCancellationRequest,
    approveCancellation,
    rejectCancellation,
  } = useOrderActions();

  const startWork = () => {
    update(
      { id: orderId.toString(), status: "IN_PROGRESS" },
      {
        onSuccess: (data) => {
          showToast(
            "Work has started",
            "Customer will be notified that work has started on this job",
          );
        },
      },
    );
  };
  const sendMessage = () => {
    router.push({
      pathname:
        `/(service-provider)/message/${order?.details?.user?.id}` as any,
      params: {
        receiverId: order?.details?.user?.id,
        name: `${order?.details?.user?.first_name} ${order?.details?.user?.last_name}`,
        avatar: order?.details?.user?.profile_picture ?? "",
      },
    });
  };
  const cancelOrder = () => {
    if (order) {
      sendCancellationRequest(
        { id: orderId.toString() },
        {
          onSuccess: () => {
            showToast(
              "Cancellation request sent",
              "Customer has been notified that you want to cancel this order"
            )
          },
        },
      );
    }
  };

  const approveCancellationRequest = () => {
    approveCancellation(
      { id: orderId.toString() },
      {
        onSuccess: () => {
          setModalState("confirmed")
        },
      },
    );
  }

  const rejectCancellationRequest = () => {
    rejectCancellation(
      { id: orderId.toString() },
      {
        onSuccess: () => {
          showToast(
            "Cancellation Rejected",
            `You rejected the cancellation request sent by the ${order?.cancellation_requested_by}`
          )
        },
      },
    );
  }

  const successRef = useModalState();
  const completeOrder = () => {
    if (order) {
      update(
        { id: orderId.toString(), status: "COMPLETION_REQUESTED" },
        {
          onSuccess: () => {
            successRef.open();
          },
        },
      );
    }
  };

  const getPrice = (): string => {
    if (order?.offers[0]?.offer?.price) {
      return formatCurrency(order?.offers[0]?.offer?.price);
    }
    return order?.details?.budget ?? "-";
  };

  const handleGoBack = () => {
    sheetRef.close();
  };

  if (isLoading) return <RequestDetailsSkeleton />;
  if (!order) return <NotFound />;

  return (
    <>
      <CancelRequest
        ref={sheetRef.ref}
        title={modalState === "cancel" ? `Cancel Order?` : `Order Cancelled`}
        description={
          modalState === "cancel"
            ? `Are you sure you want to cancel this Order? You'll stop receiving notifications from customers.`
            : `This Order is no longer active. You can create a new request anytime.`
        }
        type={modalState === "confirmed" ? "warning" : undefined}
        primaryAction={sheetRef.close}
        secondaryAction={modalState === "cancel" ? approveCancellationRequest : sheetRef.close}
        onClose={handleGoBack}
        primaryButtonText={modalState === "cancel" ? `Keep Order` : "Cancel"}
        secondaryButtonText={
          modalState === "cancel" ? "Yes, Cancel" : "Back to order"
        }
        secondaryButtonLoadingState={isSubmitting}
      />
      <SuccessSheet
        ref={successRef.ref}
        title="Completion Request Sent"
        description="Your request has been sent out to the customer. You will be notified once they respond"
        onContinue={successRef.close}
        buttonText="Ok, Got it"
        variant="primary"
        showClose={false}
        showConfetti={true}
      />
      {order && (
        <View style={styles.container}>
          <LinearGradient
            colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
            locations={[0, 1]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={[styles.header, { paddingTop: insets.top + 32 }]}
          >
            <View
              style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}
            >
              <GoBack />
            </View>
            <View style={{ gap: 8 }}>
              <CustomText
                weight="semibold"
                size="xs"
                style={{
                  opacity: 0.5,
                  textTransform: "uppercase",
                  letterSpacing: -0.24,
                }}
              >
                Order Details
              </CustomText>
              <CustomText weight="bold" size="lg">
                {order.title}
              </CustomText>
              <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
                <LocationIcon />
                <CustomText weight="regular" style={{ fontSize: 13 }}>
                  {order.details.address}
                </CustomText>
              </View>
            </View>
          </LinearGradient>

          <View style={CUSTOM_STYLES.flex}>
            <View style={styles.container}>
              <ScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={[styles.content]}
                ref={scrollRef}
              >
                <View style={styles.group}>
                  <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
                    <CustomText size="sm" weight="semibold">
                      Order Details
                    </CustomText>
                  </View>
                  <View style={styles.body}>
                    <View style={styles.detailsField}>
                      <DetailsField
                        type="status"
                        label="Status"
                        value={order.status.toLowerCase().replaceAll("_", " ")}
                      />
                      <DetailsField
                        type="address"
                        label="Address"
                        value={order.details.address}
                      />
                      <DetailsField
                        type="user"
                        label="Customer"
                        value={`${order?.details?.user?.first_name} ${order?.details?.user?.last_name}`}
                        isLast
                      />
                    </View>
                  </View>
                </View>
                <View style={styles.group}>
                  <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
                    <CustomText size="sm" weight="semibold">
                      Budget & Timeline
                    </CustomText>
                  </View>
                  <View style={styles.body}>
                    <View style={styles.detailsField}>
                      <DetailsField
                        type="budget"
                        label="Agreed Amount"
                        value={getPrice()}
                      />
                      <DetailsField
                        type="date"
                        label="Timeline"
                        value={
                          order.details.timeline
                            ? order.details.timeline
                            : order?.offers[0]?.offer.timeline.replaceAll("_", " ") ?? "N/A"
                        }
                      />
                      <DetailsField
                        type="time"
                        label="Start Date"
                        value={
                          order.details.date
                            ? formatDateTime(order.details.date)
                            : "N/A"
                        }
                        isLast
                      />
                    </View>

                    <View style={{ paddingHorizontal: 20, paddingBottom: 16 }}>
                      <ImagePreview images={order.details.images} />
                    </View>
                  </View>
                </View>

                {order?.status && (
                  <View style={styles.info}>
                    <CustomText weight="medium" style={styles.infoText}>
                      {
                        order.status.toLowerCase() === "pending"
                          ? "Customer selected you for the job, but work hasn't started"
                          : order.status.toLowerCase() === "in_progress"
                            ? "Work is currently ongoing"
                            : order.status.toLowerCase() === "completed"
                              ? "Work is currently ongoing"
                              : order.status.toLowerCase() ===
                                "completion_requested"
                                ? "Completion request sent."
                                  : order.status.toLowerCase() === "cancellation_requested" ?
                                    order.cancellation_requested_by === "SERVICE_PROVIDER"
                                      ? "Cancellation request sent."
                                      : "Cancellation request received"
                                    : order.status.toLowerCase() === "cancelled" &&
                                      "This order was cancelled."
                      }
                    </CustomText>
                  </View>
                )}
              </ScrollView>
              <View
                style={[
                  styles.footerContainer,
                  { paddingBottom: insets.bottom || 24 },
                ]}
              >
                {(order.status.toLowerCase() === "pending" ||
                  order.status.toLowerCase() === "in_progress") && (
                  <View style={[CUSTOM_STYLES.row, { gap: 12 }]}>
                    <CustomButton
                      title={
                        order.status.toLowerCase() === "pending"
                          ? "Send Message"
                          : "Cancel"
                      }
                      variant="default"
                      style={CUSTOM_STYLES.flex}
                      onPress={
                        order.status.toLowerCase() === "pending"
                          ? sendMessage
                          : cancelOrder
                      }
                      disabled={isSubmitting}
                    />
                    <CustomButton
                      title={
                        order.status.toLowerCase() === "pending"
                          ? "Start Work"
                          : "Complete Order"
                      }
                      style={CUSTOM_STYLES.flex}
                      onPress={
                        order.status.toLowerCase() === "pending"
                          ? startWork
                          : completeOrder
                      }
                      disabled={isSubmitting}
                    />
                  </View>
                )}

                {
                  order.status.toLowerCase() === "cancellation_requested" &&
                  order.cancellation_requested_by_user_id !== user?.id && (
                    <View style={[CUSTOM_STYLES.row, { gap: 12 }]}>
                      <CustomButton
                        title="Reject"
                        variant="default"
                        onPress={rejectCancellationRequest}
                        disabled={isSubmitting}
                        style={CUSTOM_STYLES.flex}
                      />
                      <CustomButton
                        title="Approve"
                        variant="primary"
                        onPress={openCancelModal}
                        disabled={isSubmitting}
                        style={CUSTOM_STYLES.flex}
                      />
                    </View>
                  )
                }
              </View>
            </View>
          </View>
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
    gap: 16,
  },
  step: {
    backgroundColor: PALETTE.black,
    paddingHorizontal: 11.67,
    paddingVertical: 8.17,
    borderRadius: 1333,
  },
  stepText: {
    fontSize: 8.67,
    color: PALETTE.white,
    textTransform: "uppercase",
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  detailsField: {},
  info: {
    padding: 16,
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  infoText: {
    opacity: 0.5,
    fontSize: 13,
    letterSpacing: -0.24,
  },
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    gap: 12,
  },
});
export default OrderDetails;
