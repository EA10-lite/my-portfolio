import LocationIcon from "@/assets/images/app-icons/location.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useBookingActions } from "@/modules/booking/hooks/useBookingActions";
import { useBookingDetails } from "@/modules/booking/hooks/useBookingDetails";
import { RequestDetailsSkeleton } from "@/modules/request-job/components";
import {
  CustomButton,
  CustomText,
  DetailsField,
  GoBack,
  ImagePreview,
  NotFound,
  SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useRef, useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const RequestDetails = () => {
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<ScrollView>(null);
  const sheetRef = useModalState();
  const [modalState, setModalState] = useState<"rejected" | "accepted" | null>(
    null,
  );

  const [orderId, setOrderId] = useState<string | null>(null);

  const { requestId } = useLocalSearchParams();
  const { requestDetails, isLoading } = useBookingDetails(requestId.toString());
  const { isSubmitting, acceptBookingByProvider, rejectBookingByProvider } =
    useBookingActions();

  const sendOffer = () => {
    router.push({
      pathname: `/request/${requestId.toString()}/send-offer` as any,
      params: {
        title: requestDetails?.title,
        receiverId: requestDetails?.user.id,
      },
    });
  };

  const handleAcceptRequest = () => {
    if (
      requestId &&
      requestDetails?.service_list_item.pricing_type === "FIXED" &&
      requestDetails?.user.id
    ) {
      acceptBookingByProvider(requestId.toString(), {
        onSuccess: (data) => {
          setOrderId(data.id || data.order.id);
          setModalState("accepted");
          sheetRef.open();
        },
      });
    }
  };
  const handleRejectRequest = () => {
    if (
      requestId &&
      requestDetails?.service_list_item.pricing_type === "FIXED" &&
      requestDetails?.user.id
    ) {
      rejectBookingByProvider(requestId.toString(), {
        onSuccess: (data) => {
          setOrderId(data.id || data.order.id);
          setModalState("rejected");
          sheetRef.open();
        },
      });
    }
  };

  const handleGoBack = () => {
    router.back();
  };

  const handleViewOrder = () => {
    sheetRef.close();
    setModalState(null);
    router.replace(`/(service-provider)/order/${orderId}`);
  };

  if (isLoading) return <RequestDetailsSkeleton />;
  if (!requestDetails) return <NotFound />;

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={sheetRef.ref}
        title={
          modalState === "accepted" ? "Request Accepted" : "Request Rejected"
        }
        description={
          modalState === "accepted"
            ? "You can now chat with the customer and manage this order from your Orders page."
            : "This request has been rejected. You will no longer receive updates or notifications for this order."
        }
        buttonText="View Order"
        variant="primary"
        onContinue={handleViewOrder}
        showConfetti={true}
        showClose={false}
      />
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <GoBack handleGoBack={handleGoBack} />
        </View>
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Request Details
          </CustomText>
          <CustomText weight="bold" size="lg">
            {requestDetails?.title
              ? requestDetails.title
              : requestDetails?.service_list_item.service_name}
          </CustomText>
          <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
            <LocationIcon />
            <CustomText weight="regular" style={{ fontSize: 13 }}>
              {`${requestDetails?.address.address}, ${requestDetails?.address.state}`}
            </CustomText>
          </View>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <View style={styles.container}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={[styles.content]}
            ref={scrollRef}
          >
            <View style={styles.group}>
              <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
                <CustomText size="sm" weight="semibold">
                  Job Details
                </CustomText>
              </View>
              <View style={styles.body}>
                {
                (requestDetails.note || requestDetails.images) && 
                (
                  <View
                    style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}
                  >
                    {requestDetails.note && (
                      <CustomText
                        style={{ opacity: 0.6 }}
                        size="sm"
                        weight="medium"
                      >
                        {requestDetails?.note}
                      </CustomText>
                    )}
                    <ImagePreview images={requestDetails?.images ?? []} />
                  </View>
                )}
                <View style={styles.detailsField}>
                  <DetailsField
                    type="address"
                    label="Address"
                    value={`${requestDetails?.address.address} ${requestDetails?.address.state}`}
                  />
                  <DetailsField
                    type="date"
                    label="Date & Time"
                    value={
                      requestDetails?.date
                        ? formatDateTime(requestDetails?.date)
                        : ""
                    }
                    isLast
                  />
                </View>
              </View>
            </View>
            <View style={styles.group}>
              <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
                <CustomText size="sm" weight="semibold">
                  Budget & Timeline
                </CustomText>
              </View>
              <View style={styles.body}>
                <View style={styles.detailsField}>
                  <DetailsField
                    type="budget"
                    label="Budget"
                    value={
                      requestDetails?.price
                        ? `${formatCurrency(requestDetails?.price)}`
                        : requestDetails?.quote_price 
                          ? `${formatCurrency(requestDetails?.price)}`
                          : "Request Quote"
                    }
                  />
                  <DetailsField
                    type="date"
                    label="Timeline"
                    value={`${requestDetails?.urgency}`}
                  />
                  <DetailsField
                    type="user"
                    label="Customer"
                    value={`${requestDetails?.user.first_name} ${requestDetails?.user.last_name}`}
                    isLast
                  />
                </View>
              </View>
            </View>

            {requestDetails?.status && (
              <View style={styles.info}>
                <CustomText weight="medium" style={styles.infoText}>
                  {requestDetails.status.toLowerCase() === "awaiting_provider"
                    ? "Customer selected you for the job, but work hasn't started"
                    : requestDetails.status.toLowerCase() === "pending"
                      ? "Customer selected you for the job, but work hasn't started"
                      : requestDetails.status.toLowerCase() === "in_progress"
                        ? "Work is currently ongoing"
                        : requestDetails.status.toLowerCase() === "completed"
                          ? "Work is currently ongoing"
                          : requestDetails.status.toLowerCase() ===
                              "in_negotiation"
                            ? "Negotiation is currently ongoing"
                            : requestDetails.status.toLowerCase() ===
                                "completion_requested"
                              ? "Completion request sent."
                              : requestDetails.status.toLowerCase() ===
                                  "cancelled" && "This order was cancelled."}
                </CustomText>
              </View>
            )}
          </ScrollView>
          <View
            style={[
              CUSTOM_STYLES.row,
              styles.footerContainer,
              { paddingBottom: insets.bottom || 24 },
            ]}
          >
            {
              (requestDetails.status.toLowerCase() === "pending" ||
                requestDetails.status.toLowerCase() ===
                  "awaiting_provider") && (
                <CustomButton
                  title="Reject"
                  variant="default"
                  onPress={handleRejectRequest}
                  style={CUSTOM_STYLES.flex}
                  disabled={isSubmitting}
                />
              )}
            {requestDetails?.service_list_item.pricing_type === "FIXED" &&
              (requestDetails.status.toLowerCase() === "pending" ||
                requestDetails.status.toLowerCase() ===
                  "awaiting_provider") && (
                <CustomButton
                  title="Accept"
                  variant="primary"
                  onPress={handleAcceptRequest}
                  style={CUSTOM_STYLES.flex}
                  disabled={isSubmitting}
                />
              )}
            {requestDetails?.service_list_item.pricing_type ===
              "REQUEST_QUOTE" &&
              (requestDetails.status.toLowerCase() === "pending" ||
                requestDetails.status.toLowerCase() === "awaiting_provider" ||
                requestDetails.status.toLowerCase() === "in_negotiation") && (
                <CustomButton
                  title="Send Offer"
                  variant="primary"
                  onPress={sendOffer}
                  style={CUSTOM_STYLES.flex}
                  disabled={isSubmitting}
                />
              )}
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
    gap: 16,
  },
  step: {
    backgroundColor: PALETTE.black,
    paddingHorizontal: 11.67,
    paddingVertical: 8.17,
    borderRadius: 1333,
  },
  stepText: {
    fontSize: 8.67,
    color: PALETTE.white,
    textTransform: "uppercase",
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  info: {
    padding: 16,
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  infoText: {
    opacity: 0.5,
    fontSize: 13,
    letterSpacing: -0.24,
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  detailsField: {},
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    gap: 12,
  },
});
export default RequestDetails;
