import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY as URGENCY_TYPE } from "@/constants/types";
import { URGENCY } from "@/constants/values";
import { useOfferActions } from "@/modules/offers/hooks/useOfferActions";
import { Offer } from "@/modules/offers/types/offer.dto";
import { offerValidationSchema } from "@/modules/offers/utils/validation";
import { ProfileHeader } from "@/modules/profile/components";
import {
  CustomButton,
  Input,
  Select,
  SuccessSheet,
  Textbox,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useModalState } from "@/shared/hooks/useModalState";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SendOffer = () => {
  const { requestId, receiverId } = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const modalRef = useModalState();

  const { isSubmitting, sendRequestOffer } = useOfferActions();
  const isButtonDisabled = (values: Offer) => {
    return (
      !values.price ||
      !values.proposal ||
      !values.timeline ||
      !values.availability
    );
  };

  const handleSubmit = (value: Offer) => {
    if (requestId && receiverId) {
      sendRequestOffer(
        {
          offer: {
            ...value,
            price: value.price,
          },
          message: value.proposal,
          receiver_id: receiverId.toString(),
          book_service_id: requestId.toString(),
          content_type: "OFFER",
        },
        {
          onSuccess: (data) => {
            console.log("Job Request Response:", data);
            modalRef.open();
          },
        },
      );
    }
  };

  const goBackToRequest = () => {
    modalRef.close();
    router.back();
  };
  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Offer Submitted"
        description="The Customer will review your offer and notify you if selected"
        onContinue={goBackToRequest}
        maxWidth={300}
        showConfetti={true}
        buttonText="Back to Request"
      />
      <ProfileHeader title="Send Offer" />

      <View style={CUSTOM_STYLES.flex}>
        <Formik<Offer>
          validateOnChange={false}
          initialValues={{
            price: "",
            proposal: "",
            timeline: "",
            availability: "" as URGENCY_TYPE,
          }}
          onSubmit={handleSubmit}
          validationSchema={offerValidationSchema}
        >
          {({ values, handleSubmit }) => {
            const disabled = isButtonDisabled(values);
            return (
              <ScreenShell
                contentContainerStyle={styles.content}
                footer={
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Submit Offer"
                      variant="primary"
                      disabled={disabled || isSubmitting}
                      loading={isSubmitting}
                      onPress={handleSubmit}
                    />
                  </View>
                }
              >
                <View style={styles.form}>
                  <Input name="price" placeholder="Input Price" />
                  <Select
                    name="timeline"
                    placeholder="Timeline"
                    options={[
                      { label: "1 day", value: "1_day" },
                      { label: "3 days", value: "3_days" },
                      { label: "1 week", value: "1_week" },
                      { label: "1 Month", value: "1_month" },
                    ]}
                  />
                  <Textbox
                    name="proposal"
                    placeholder="Short Proposal ( Max 200 words)"
                  />
                  <Select
                    name="availability"
                    placeholder="Availability"
                    options={URGENCY}
                  />
                </View>
              </ScreenShell>
            );
          }}
        </Formik>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },

  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});
export default SendOffer;
