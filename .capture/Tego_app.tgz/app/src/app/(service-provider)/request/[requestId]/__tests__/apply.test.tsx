import { pressableForLabel, renderWithProviders } from "@/testing/render";
import React from "react";
import Apply from "../apply";

const mockSendOffer = jest.fn();

jest.mock("@/modules/offers/hooks/useOfferActions", () => ({
  useOfferActions: () => ({
    isSubmitting: false,
    sendRequestOffer: mockSendOffer,
  }),
}));

jest.mock("expo-router", () => ({
  useLocalSearchParams: () => ({
    title: "Plumbing Repair",
    jobId: "job-1",
    receiverId: "rec-1",
  }),
  router: { back: jest.fn(), push: jest.fn(), replace: jest.fn() },
}));

describe("apply (ScreenShell migration)", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders the request header, form fields and footer submit button", async () => {
    const ui = await renderWithProviders(<Apply />);
    expect(ui.getByText("Request Details")).toBeTruthy();
    expect(ui.getByText("Plumbing Repair")).toBeTruthy();
    expect(ui.getByPlaceholderText("Input Price")).toBeTruthy();
    expect(ui.getByText("Timeline")).toBeTruthy();
    expect(ui.getByText("Availability")).toBeTruthy();
    expect(ui.getByPlaceholderText("Short Proposal ( Max 200 words)")).toBeTruthy();
    expect(ui.getByText("Submit Application")).toBeTruthy();
  });

  it("keeps inputs above the keyboard via ScreenShell config", async () => {
    const ui = await renderWithProviders(<Apply />);
    const tree = JSON.stringify(ui.toJSON());
    expect(tree).toContain('"keyboardShouldPersistTaps":"handled"');
    expect(tree).toContain('"enableOnAndroid":true');
    expect(tree).toContain('"keyboardDismissMode":"on-drag"');
    expect(tree).toContain('"extraScrollHeight":20');
    expect(tree).toContain('"extraHeight":100');
  });

  it("starts with the submit button enabled before the form is touched", async () => {
    const ui = await renderWithProviders(<Apply />);
    const state = pressableForLabel(ui, "Submit Application").props
      .accessibilityState;
    expect(state.disabled).toBe(false);
  });
});