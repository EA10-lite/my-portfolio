import { pressableForLabel, renderWithProviders } from "@/testing/render";
import React from "react";
import SendOffer from "../send-offer";

const mockSendOffer = jest.fn();

jest.mock("@/modules/offers/hooks/useOfferActions", () => ({
  useOfferActions: () => ({
    isSubmitting: false,
    sendRequestOffer: mockSendOffer,
  }),
}));

jest.mock("expo-router", () => ({
  useLocalSearchParams: () => ({ requestId: "req-1", receiverId: "rec-1" }),
  router: { back: jest.fn(), push: jest.fn(), replace: jest.fn() },
}));

describe("send-offer (ScreenShell migration)", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders header, form fields and the footer submit button", async () => {
    const ui = await renderWithProviders(<SendOffer />);
    expect(ui.getByText("Send Offer")).toBeTruthy();
    expect(ui.getByPlaceholderText("Input Price")).toBeTruthy();
    expect(ui.getByText("Timeline")).toBeTruthy();
    expect(ui.getByPlaceholderText("Short Proposal ( Max 200 words)")).toBeTruthy();
    expect(ui.getByText("Availability")).toBeTruthy();
    expect(ui.getByText("Submit Offer")).toBeTruthy();
  });

  it("keeps inputs above the keyboard via ScreenShell config", async () => {
    const ui = await renderWithProviders(<SendOffer />);
    const tree = JSON.stringify(ui.toJSON());
    expect(tree).toContain('"keyboardShouldPersistTaps":"handled"');
    expect(tree).toContain('"enableOnAndroid":true');
    expect(tree).toContain('"keyboardDismissMode":"on-drag"');
    expect(tree).toContain('"extraScrollHeight":20');
    expect(tree).toContain('"extraHeight":100');
  });

  it("starts with the submit button disabled until the form is filled", async () => {
    const ui = await renderWithProviders(<SendOffer />);
    const state = pressableForLabel(ui, "Submit Offer").props.accessibilityState;
    expect(state.disabled).toBe(true);
  });
});