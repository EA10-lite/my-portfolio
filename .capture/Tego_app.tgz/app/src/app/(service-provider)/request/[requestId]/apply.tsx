import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY as URGENCY_TYPE } from "@/constants/types";
import { URGENCY } from "@/constants/values";
import { useOfferActions } from "@/modules/offers/hooks/useOfferActions";
import { Offer } from "@/modules/offers/types/offer.dto";
import { offerValidationSchema } from "@/modules/offers/utils/validation";
import {
  CustomButton,
  CustomText,
  GoBack,
  Input,
  Select,
  SuccessSheet,
  Textbox,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useModalState } from "@/shared/hooks/useModalState";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Apply = () => {
  const insets = useSafeAreaInsets();
  const modalRef = useModalState();

  const { title, jobId, receiverId } = useLocalSearchParams<{
    title: string;
    jobId: string;
    receiverId: string;
  }>();

  const { isSubmitting, sendRequestOffer } = useOfferActions();

  const handleSubmit = (value: Offer) => {
    if (jobId && receiverId) {
      sendRequestOffer(
        {
          offer: {
            ...value,
            price: value.price,
          },
          message: value.proposal,
          receiver_id: receiverId.toString(),
          job_request_id: jobId.toString(),
          content_type: "OFFER",
        },
        {
          onSuccess: (data) => {
            console.log("Job Request Response:", data);
            modalRef.open();
          },
        },
      );
    }
  };

  const handleGoBack = () => {
    router.back();
  };
  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Application Submitted"
        description="The customer will review your proposal and notify you if selected."
        onContinue={modalRef.close}
        maxWidth={300}
        showConfetti={true}
        buttonText="Back to Request"
      />

      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <GoBack handleGoBack={handleGoBack} />
        </View>
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Request Details
          </CustomText>
          <CustomText weight="bold" size="lg">
            {title}
          </CustomText>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <Formik
          validateOnChange={false}
          initialValues={{
            price: "",
            proposal: "",
            timeline: "",
            availability: "" as URGENCY_TYPE,
          }}
          onSubmit={handleSubmit}
          validationSchema={offerValidationSchema}
        >
          {({ handleSubmit, dirty }) => {
            return (
              <ScreenShell
                contentContainerStyle={styles.content}
                footer={
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Submit Application"
                      variant="primary"
                      disabled={isSubmitting || dirty}
                      onPress={handleSubmit}
                    />
                  </View>
                }
              >
                <View style={styles.form}>
                  <Input
                    name="price"
                    placeholder="Input Price"
                    type="numeric"
                  />
                  <Select
                    name="timeline"
                    placeholder="Timeline"
                    options={[
                      { label: "1 day", value: "1_day" },
                      { label: "3 days", value: "3_days" },
                      { label: "1 week", value: "1_week" },
                      { label: "1 Month", value: "1_month" },
                    ]}
                  />
                  <Select
                    name="availability"
                    placeholder="Availability"
                    options={URGENCY}
                  />
                  <Textbox
                    name="proposal"
                    placeholder="Short Proposal ( Max 200 words)"
                  />
                </View>
              </ScreenShell>
            );
          }}
        </Formik>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },

  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },

  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});
export default Apply;
