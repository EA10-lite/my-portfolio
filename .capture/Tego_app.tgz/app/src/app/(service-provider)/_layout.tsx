// app/(customer)/_layout.tsx
import { useAuthGuard } from "@/modules/auth/hooks/useAuthGuard";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { Redirect, Stack } from "expo-router";

export default function ProtectedLayout() {
  useAuthGuard();

  const { isLoggedIn } = useAuthStore();
  if (!isLoggedIn) return <Redirect href="/(public)/signin" />;

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" options={{ gestureEnabled: false }} />
    </Stack>
  );
}
