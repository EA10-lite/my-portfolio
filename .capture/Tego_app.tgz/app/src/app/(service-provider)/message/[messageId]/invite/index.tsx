// import { PALETTE } from "@/constants/colors";
// import { CUSTOM_STYLES } from "@/constants/styles";
// import { bookingFormSchema } from "@/modules/booking/utils/validation";
// import {
//     useInviteStore,
//     type FormValues,
// } from "@/modules/message/store/useInviteMessage";
// import {
//     CustomButton,
//     CustomText,
//     DatePicker,
//     EditableInput,
//     GoBack,
//     Input,
//     Select,
//     Textbox,
//     TimePicker,
// } from "@/shared/components";
// import { LinearGradient } from "expo-linear-gradient";
// import { router, useLocalSearchParams } from "expo-router";
// import { Formik } from "formik";
// import {
//     Keyboard,
//     KeyboardAvoidingView,
//     Platform,
//     ScrollView,
//     StyleSheet,
//     View,
// } from "react-native";
// import { useSafeAreaInsets } from "react-native-safe-area-context";

// const BookingDetails = () => {
//   const { messageId } = useLocalSearchParams();
//   const { clearBooking, setFormData, form } = useInviteStore();
//   const insets = useSafeAreaInsets();

//   const handleGoBack = () => {
//     clearBooking();
//     router.back();
//   };

//   const handleSubmit = (values: FormValues) => {
//     setFormData(values);
//     router.push(`/(service-provider)/message/${messageId.toString()}/invite/preview`);
//   };

//   return (
//     <View style={styles.container}>
//       <LinearGradient
//         colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
//         locations={[0, 1]}
//         start={{ x: 0, y: 0 }}
//         end={{ x: 0, y: 1 }}
//         style={[styles.header, { paddingTop: insets.top + 32 }]}
//       >
//         <GoBack handleGoBack={handleGoBack} />
//         <View style={{ gap: 8 }}>
//           <CustomText
//             weight="semibold"
//             size="xs"
//             style={{
//               opacity: 0.5,
//               textTransform: "uppercase",
//               letterSpacing: -0.24,
//             }}
//           >
//             Step 1 of 3
//           </CustomText>
//           <CustomText weight="bold" size="lg">
//             Booking Details
//           </CustomText>
//         </View>
//       </LinearGradient>

//       <View style={CUSTOM_STYLES.flex}>
//         <KeyboardAvoidingView
//           behavior={Platform.OS === "ios" ? "padding" : "height"}
//           keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
//           style={styles.container}
//         >
//           <Formik
//             initialValues={form}
//             onSubmit={handleSubmit}
//             validationSchema={bookingFormSchema}
//             validateOnChange
//             validateOnBlur
//           >
//             {({ handleSubmit, values }) => (
//               <>
//                 <ScrollView
//                   showsVerticalScrollIndicator={false}
//                   keyboardShouldPersistTaps="handled"
//                   onScrollBeginDrag={Keyboard.dismiss}
//                   contentContainerStyle={[styles.content]}
//                 >
//                   <View style={[CUSTOM_STYLES.flex, styles.formContainer]}>
//                     <View style={[CUSTOM_STYLES.flex, styles.form]}>
//                       <Input name="title" placeholder="Title" />
//                       <Select
//                         name="service"
//                         placeholder="Type of service"
//                         options={[
//                           { label: "Plumbind", value: "plumbing" },
//                           { label: "Cleaning", value: "cleaning" },
//                           { label: "Painting", value: "painting" },
//                           { label: "Other", value: "other" },
//                         ]}
//                       />
//                       <DatePicker
//                         name="date"
//                         placeholder="Select date"
//                         value={values["date"]}
//                       />
//                       <TimePicker name="time" placeholder="Select time" />
//                       <Select
//                         name="urgency"
//                         placeholder="Urgency"
//                         options={[
//                           { label: "Immediately", value: "immediately" },
//                           { label: "Within 1 hour", value: "1_hour" },
//                           { label: "Within a few hours", value: "few_hours" },
//                           { label: "Same day", value: "same_day" },
//                           { label: "Within 24 hours", value: "24_hours" },
//                           { label: "Within 2–3 days", value: "2_3_days" },
//                           { label: "This week", value: "this_week" },
//                           { label: "Flexible", value: "flexible" },
//                         ]}
//                       />
//                       <EditableInput
//                         name="address"
//                         placeholder="Address"
//                         label="Address"
//                         isEditable={true}
//                       />
//                       <Textbox
//                         name="note"
//                         placeholder={
//                           values["service"] === "other"
//                             ? "Describe the issue"
//                             : "Note (optional)"
//                         }
//                       />
//                     </View>
//                   </View>
//                 </ScrollView>
//                 <View
//                   style={[
//                     styles.footerContainer,
//                     { paddingBottom: insets.bottom || 24 },
//                   ]}
//                 >
//                   <CustomButton
//                     title="Continue"
//                     variant="primary"
//                     onPress={handleSubmit}
//                   />
//                 </View>
//               </>
//             )}
//           </Formik>
//         </KeyboardAvoidingView>
//       </View>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: PALETTE.white,
//   },
//   header: {
//     paddingHorizontal: 20,
//     paddingBottom: 10,
//     gap: 34,
//   },
//   content: {
//     marginTop: 24,
//     paddingHorizontal: 20,
//     paddingBottom: 24,
//   },
//   formContainer: {},
//   form: { gap: 15 },
//   info: {
//     borderWidth: 1,
//     borderColor: PALETTE.primary14,
//     backgroundColor: "#F5FBFF",
//     borderRadius: 6,
//     paddingHorizontal: 12,
//     paddingVertical: 10,
//     gap: 4,
//     justifyContent: "center",
//     minWidth: "57%",
//     margin: "auto",
//   },
//   footerContainer: {
//     paddingTop: 10,
//     paddingHorizontal: 20,
//     paddingBottom: 48,
//   },
// });
// export default BookingDetails;

import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY } from "@/constants/values";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import {
  FormValues,
  useInviteStore,
} from "@/modules/message/store/useInviteMessage";
import { useServices } from "@/modules/profile/hooks/useServices";
import {
  AddressInput,
  CustomButton,
  CustomText,
  DatePicker,
  GoBack,
  Input,
  Select,
  Textbox,
  TimePicker,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useDeviceInfo } from "@/shared/hooks/useLocation";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { useMemo } from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const BookingDetails = () => {
  const { user } = useAuthStore();
  const { messageId } = useLocalSearchParams();
  const { location } = useDeviceInfo();
  const { clearBooking, setFormData, form } = useInviteStore();
  const insets = useSafeAreaInsets();

  const { services, isLoading } = useServices();

  const handleGoBack = () => {
    clearBooking();
    router.back();
  };

  const handleSubmit = (values: FormValues) => {
    setFormData(values);
    router.push(
      `/(service-provider)/message/${messageId.toString()}/invite/preview`,
    );
  };

  const initialAddress = useMemo(
    () => ({
      state: user?.user_details?.user_address?.state || location.state || "",

      country:
        user?.user_details?.user_address?.country ||
        location.country ||
        "Nigeria",

      address:
        user?.user_details?.user_address?.address || location.address || "",
    }),
    [user?.user_details?.user_address, location],
  );

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={handleGoBack} />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Step 1 of 3
          </CustomText>
          <CustomText weight="bold" size="lg">
            Booking Details
          </CustomText>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <Formik
          enableReinitialize
          initialValues={{
            ...form,
            address: form.address?.address ? form.address : initialAddress,
          }}
          onSubmit={handleSubmit}
          validateOnChange
          validateOnBlur
        >
          {({ handleSubmit, values, setFieldValue }) => (
            <ScreenShell
              extraScrollHeight={30}
              extraHeight={100}
              contentContainerStyle={[styles.content]}
              footer={
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Continue"
                    variant="primary"
                    onPress={handleSubmit}
                  />
                </View>
              }
            >
              <View style={[CUSTOM_STYLES.flex, styles.formContainer]}>
                <View style={[CUSTOM_STYLES.flex, styles.form]}>
                <Select
                  name="service_list_item_id"
                  placeholder="Type of service"
                  options={
                    services?.services_list.map((service) => ({
                      label: service.service_name,
                      value: service.id,
                    })) || []
                  }
                  onChange={(value: string) => {
                    setFieldValue("service_list_item_id", value);

                    setFieldValue(
                      "price",
                      services?.services_list.find(
                        service => service.id === value
                      )?.price
                    );
                  }}
                  disabled={isLoading}
                />
                  {values.service_list_item_id && services?.services_list?.find(
                    service => service.id === values.service_list_item_id
                  )?.pricing_type !== "FIXED" && (
                    <Input
                      name="price"
                      placeholder="Enter Service Price"
                    />
                  )}
                  <DatePicker
                    name="date"
                    placeholder="Select date"
                    value={values["date"]}
                  />
                  <TimePicker name="time" placeholder="Select time" />
                  <Select
                    name="urgency"
                    placeholder="Urgency"
                    options={URGENCY}
                  />
                  <AddressInput
                    name="address"
                    isEditable={true}
                    address={values.address.address}
                    state={values.address.state}
                  />
                  <Textbox name="note" placeholder="Note (optional)" />
                </View>
              </View>
            </ScreenShell>
          )}
        </Formik>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  formContainer: {
    paddingBottom: 80,
  },
  form: { gap: 15 },
  info: {
    borderWidth: 1,
    borderColor: PALETTE.primary14,
    backgroundColor: "#F5FBFF",
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 4,
    justifyContent: "center",
    minWidth: "57%",
    margin: "auto",
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 48,
  },
});
export default BookingDetails;
