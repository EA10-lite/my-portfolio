// app/(custimport MessageIcon from "@/assets/images/app-icons/mail.svg";
import MessageIcon from "@/assets/images/app-icons/mail.svg";
import { PALETTE } from "@/constants/colors";
import {
  ChatFooter,
  ChatHeader,
  ScrollToBottom,
} from "@/modules/message/components";
import DateSeparator from "@/modules/message/components/DateSeparator";
import { ChatRoom } from "@/modules/message/containers";
import { useChatRoom } from "@/modules/message/hooks/useChatRoom";
import { CHATS_QUERY_KEY } from "@/modules/message/hooks/useConversations";
import {
  FlatListItem,
  MessageGroup,
  groupMessages,
} from "@/modules/message/utils/groupMessages";
import { EmptyMessages, FileSelectorModal } from "@/shared/components";
import useFilePicker from "@/shared/hooks/useFilePicker";
import { useKeyboardStatus } from "@/shared/hooks/useKeyboardStatus";
import { useModalState } from "@/shared/hooks/useModalState";
import { uploadManyWithProgress } from "@/shared/lib/cloudinary";
import { useHeaderHeight } from "@react-navigation/elements";
import { useQueryClient } from "@tanstack/react-query";
import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useCallback, useMemo, useRef, useState } from "react";
import {
  Dimensions,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  View,
} from "react-native";

const MessageRoom = () => {
  const queryClient = useQueryClient();
  const headerHeight = useHeaderHeight();
  const isKeyboardVisible = useKeyboardStatus();
  const { receiverId, messageId, name, avatar, isOnline } =
    useLocalSearchParams<{
      receiverId: string;
      messageId: string;
      name: string;
      avatar: string;
      isOnline: string;
    }>();

  const {
    messages,
    isLoading,
    sendText,
    sendImages,
    addOptimisticImage,
    updateMessage,
    isReceiverOnline,
  } = useChatRoom(messageId, receiverId, name, avatar, isOnline == "true");

  // Refetch conversations when leaving the chat room
  useFocusEffect(
    useCallback(() => {
      return () => {
        // This runs when screen loses focus (navigating back)
        queryClient.invalidateQueries({ queryKey: CHATS_QUERY_KEY });
      };
    }, [queryClient]),
  );

  const groupedMessages = useMemo(() => groupMessages(messages), [messages]);

  const [text, setText] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const sheetRef = useModalState();
  const flatListRef = useRef<FlatList>(null);

  const handleScroll = (event: any) => {
    const { contentOffset } = event.nativeEvent;
    setShowScrollButton(contentOffset.y > 100);
  };

  const scrollToBottom = () => {
    flatListRef.current?.scrollToIndex({ index: 0, animated: true });
    setShowScrollButton(false);
  };

  const handleLoadMore = () => {};

  const { pickImage } = useFilePicker({
    imagePickerOptions: {
      allowsMultipleSelection: true,
      selectionLimit: 3,
    },
  });

  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const handleImagePick = async () => {
    const assets = await pickImage();
    if (!assets || assets.length === 0) return;
    sheetRef.close();
    // Just store locally — don't upload yet
    setSelectedImages(assets.map((a) => a.uri));
  };

  const handleRemoveImage = (index: number) => {
    setSelectedImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSend = useCallback(async () => {
    const hasText = text.trim();
    const hasImages = selectedImages.length > 0;

    if (!hasText && !hasImages) return;
    if (hasImages) {
      const uris = [...selectedImages];
      const caption = text.trim() || undefined;

      // Clear inputs immediately
      setSelectedImages([]);
      if (hasText) setText("");

      // 1. Show optimistic UI with local URIs
      const tempId = addOptimisticImage(uris, caption);
      scrollToBottom();

      try {
        setIsUploading(true);
        const uploaded = await uploadManyWithProgress(
          uris,
          { folder: "tego/message_images" },
          (index, progress) => {
            updateMessage(tempId, {
              uploadProgress: uris.map((_, i) => (i === index ? progress : 1)),
            });
          },
        );
        const urls = uploaded.map((r) => r.secure_url);
        sendImages(urls, tempId, caption);
      } catch (err) {
        console.error("[MessageRoom] image upload failed:", err);
        updateMessage(tempId, { status: "sent" });
      } finally {
        setIsUploading(false);
      }
      return;
    }
    // Text only
    sendText(text);
    setText("");
  }, [
    text,
    selectedImages,
    sendText,
    sendImages,
    addOptimisticImage,
    updateMessage,
  ]);

  const goToInvitation = () => {
    sheetRef.close();
    router.push(`/(service-provider)/message/${messageId}/invite`);
  };

  const renderItem = ({ item }: { item: FlatListItem }) => {
    if (item.type === "date_separator") {
      return <DateSeparator label={item.label} />;
    }

    const group = item as MessageGroup;
    return (
      <View>
        {group.messages.map((message, index) => {
          const isLast = index === group.messages.length - 1;
          return (
            <ChatRoom
              key={message.id}
              message={message}
              hideTime={!isLast}
              hideAvatar={!isLast} // 👈 show avatar only on last message (bottom of group)
            />
          );
        })}
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      enabled={isKeyboardVisible}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === "ios" ? headerHeight : 0}
    >
      <View style={styles.container}>
        <FileSelectorModal
          ref={sheetRef.ref}
          onClose={sheetRef.close}
          handleImagePick={handleImagePick}
          label="Add to conversation"
          showInvite={true}
          sendInvite={goToInvitation}
        />
        <ChatHeader username={name} url={avatar} isOnline={isReceiverOnline} />
        <View style={{ backgroundColor: PALETTE.white, flex: 1 }}>
          <FlatList
            ref={flatListRef}
            data={groupedMessages}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
            onScroll={handleScroll}
            showsVerticalScrollIndicator={false}
            onScrollBeginDrag={Keyboard.dismiss}
            scrollEventThrottle={16}
            inverted
            onEndReached={handleLoadMore}
            onEndReachedThreshold={0.3}
            contentContainerStyle={{
              paddingHorizontal: 20,
              paddingTop: 19,
              flexGrow: 1,
            }}
            ListEmptyComponent={
              !isLoading ? (
                <View style={styles.emptyContainer}>
                  <EmptyMessages
                    title="No Messages yet"
                    description="Be the first to say something"
                    Icon={() => (
                      <MessageIcon
                        color={PALETTE.primary}
                        width={20}
                        height={20}
                      />
                    )}
                  />
                </View>
              ) : null
            }
          />

          {showScrollButton && <ScrollToBottom onPress={scrollToBottom} />}

          <ChatFooter
            value={text}
            handleChange={setText}
            handleFileSelect={sheetRef.open}
            handleSend={handleSend}
            selectedImages={selectedImages}
            onRemoveImage={handleRemoveImage}
          />
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.black,
  },
  emptyContainer: {
    height: Dimensions.get("screen").height / 2,
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
  },
});

export default MessageRoom;
