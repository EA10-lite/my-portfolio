import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import SecureIcon from "@/assets/images/app-icons/secure.svg";

import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY } from "@/constants/types";
import { useInvitation } from "@/modules/message/hooks/useInvitation";
import { useInviteStore } from "@/modules/message/store/useInviteMessage";
import {
    CustomButton,
    CustomText,
    DetailsField,
    GoBack,
    SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { formatDateTime } from "@/shared/utils/formatter";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const BookingDetails = () => {
  const insets = useSafeAreaInsets();
  const { messageId } = useLocalSearchParams();
  const { form, clearBooking } = useInviteStore();
  const { sendInvite, isSubmitting } = useInvitation();

  const handleEdit = () => router.back();

  const handleGoBack = () => {
    router.back();
  };

  const sheetRef = useModalState();
  const handleSuccess = () => {
    sheetRef.close();
    clearBooking();
    router.back();
    router.back();
  };

  const handleSubmit = () => {
    sendInvite(
      {
        receiver_id: messageId.toString(),
        message_type: "INVITE_BOOKING",
        invite: {
          note: form.note,
          address: form.address,
          date: form.date,
          time: form.time,
          urgency: form.urgency as URGENCY,
          service_list_item_id: form.service_list_item_id,
          price: parseInt(form.price.toString())
        }
      },
      {
        onSuccess: () => {
          sheetRef.open();
        },
      },
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={handleGoBack} />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Step 2 of 3
          </CustomText>
          <CustomText weight="bold" size="lg">
            Booking Confirmation
          </CustomText>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[styles.content]}
        >
          <View style={styles.details}>
            <View style={styles.group}>
              <View style={styles.fields}>
                <View
                  style={[
                    CUSTOM_STYLES.row,
                    { justifyContent: "space-between", padding: 20 },
                  ]}
                >
                  <CustomText size="xs" weight="semibold">
                    Booking Details
                  </CustomText>

                  <Pressable onPress={handleEdit}>
                    <PencilEditIcon />
                  </Pressable>
                </View>
              </View>
              <View style={styles.fields}>
                <DetailsField
                  label="Date & Time"
                  value={form.date && formatDateTime(form.date, form.time)}
                  type="date"
                />
                <DetailsField
                  label="Urgency"
                  value={form.urgency}
                  type="urgency"
                />
                <DetailsField
                  label="Address"
                  value={form?.address?.address || "N/A"}
                  type="address"
                />
                <DetailsField
                  label="Note"
                  value={form.note || "N/A"}
                  type="title"
                  isLast
                />
              </View>
            </View>
          </View>
        </ScrollView>

        <View
          style={[
            styles.footerContainer,
            { paddingBottom: insets.bottom || 24 },
          ]}
        >
          <View
            style={[
              CUSTOM_STYLES.row,
              { gap: 4, justifyContent: "center", opacity: 0.5 },
            ]}
          >
            <SecureIcon width={16} height={16} color={PALETTE.black} />
            <CustomText size="xs" weight="medium">
              Secured Booking
            </CustomText>
          </View>
          <CustomButton
            title="Invite"
            variant="primary"
            onPress={handleSubmit}
            loading={isSubmitting}
          />
        </View>
      </View>

      <SuccessSheet
        ref={sheetRef.ref}
        title="Booking Invite Sent 🎉"
        description="Your invite has been sent out to the customer. You will be notified once they respond"
        onContinue={handleSuccess}
        buttonText="Ok, Got it"
        variant="primary"
        showClose={false}
        showConfetti={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 20,
  },
  body: {},

  details: { gap: 20 },
  group: { gap: 8 },
  fields: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 6,
  },
  label: {
    opacity: 0.5,
  },
  value: {
    letterSpacing: -0.0024,
  },
  footerContainer: {
    gap: 14,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
});
export default BookingDetails;
