// app/(customer)/message/[id].tsx
import MessageIcon from "@/assets/images/app-icons/mail.svg";
import { PALETTE } from "@/constants/colors";
import { URGENCY } from "@/constants/types";
import {
  ChatFooter,
  ChatNegotiationHeader,
  ScrollToBottom,
} from "@/modules/message/components";
import { OfferChatRoom } from "@/modules/message/containers";
import { useOfferThread } from "@/modules/message/hooks/useOfferThread";
import { useOfferActions } from "@/modules/offers/hooks/useOfferActions";
import { Offer } from "@/modules/offers/types/offer.dto";
import { EmptyMessages } from "@/shared/components";
import { useLocalSearchParams } from "expo-router";
import { useRef, useState } from "react";
import {
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  View,
} from "react-native";

const OfferChat = () => {
  const { receiverId, messageId, name, avatar } = useLocalSearchParams<{
    receiverId: string;
    messageId: string;
    name: string;
    avatar: string;
    isOnline: string;
  }>();
  const { conversations } = useOfferThread(messageId, receiverId);
  const {
    sendRequestOffer,
    acceptRequestOffer,
    rejectRequestOffer,
    isSubmitting,
  } = useOfferActions();

  const reviseOffer = (values: Offer) => {
    if (messageId && receiverId) {
      sendRequestOffer({
        offer: {
          ...values,
          price: values.price,
          availability: values.availability as URGENCY,
        },
        message: values.proposal,
        receiver_id: receiverId,
        job_request_id: messageId,
        content_type: "OFFER",
      });
    }
  };

  const [showScrollButton, setShowScrollButton] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  const handleScroll = (event: any) => {
    const { contentOffset, contentSize, layoutMeasurement } = event.nativeEvent;

    const distanceFromBottom =
      contentSize.height - (contentOffset.y + layoutMeasurement.height);

    setShowScrollButton(distanceFromBottom > 100);
  };

  const scrollToBottom = () => {
    flatListRef.current?.scrollToEnd({
      animated: true,
    });
    setShowScrollButton(false);
  };

  const handleLoadMore = () => {
    // Fetch previous messages
    console.log("Loading more messages...");
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
    >
      <View style={styles.container}>
        <ChatNegotiationHeader
          name={name ? name : `${conversations?.user?.first_name} ${conversations?.user?.last_name}`}
          profile_picture={avatar ? avatar : `${conversations?.user?.profile_picture}`}
        />
        <View
          style={{
            backgroundColor: PALETTE.white,
            flex: 1,
          }}
        >
          {conversations && conversations?.offers.length > 0 ? (
            <FlatList
              ref={flatListRef}
              data={conversations.offers}
              renderItem={({ item }) => (
                <OfferChatRoom
                  message={item}
                  submitOffer={reviseOffer}
                  acceptOffer={acceptRequestOffer}
                  declineOffer={rejectRequestOffer}
                  isLoading={isSubmitting}
                />
              )}
              keyExtractor={(item) => item.id}
              onScroll={handleScroll}
              showsVerticalScrollIndicator={false}
              onScrollBeginDrag={Keyboard.dismiss}
              scrollEventThrottle={16}
              onEndReached={handleLoadMore}
              onEndReachedThreshold={0.3}
              contentContainerStyle={{
                paddingHorizontal: 20,
                paddingTop: 19,
              }}
            />
          ) : (
            <View style={styles.emptyContainer}>
              <EmptyMessages
                title="No Messages yet"
                description="Be the first to start a conversation"
                Icon={() => (
                  <MessageIcon color={PALETTE.primary} width={20} height={20} />
                )}
              />
            </View>
          )}
          {showScrollButton && <ScrollToBottom onPress={scrollToBottom} />}
          <ChatFooter
            value={""}
            handleChange={() => {}}
            handleFileSelect={() => {}}
            handleSend={() => {}}
          />
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default OfferChat;
