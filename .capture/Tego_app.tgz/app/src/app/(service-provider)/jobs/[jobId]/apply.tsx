import LocationIcon from "@/assets/images/app-icons/location.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY } from "@/constants/types";
import { URGENCY as URGENCY_OPTIONS } from "@/constants/values";
import { useOfferActions } from "@/modules/offers/hooks/useOfferActions";
import { Offer } from "@/modules/offers/types/offer.dto";
import { offerValidationSchema } from "@/modules/offers/utils/validation";
import {
  CustomButton,
  CustomText,
  GoBack,
  Input,
  Select,
  SuccessSheet,
  Textbox,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { ScreenShell } from "@/shared/containers";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";

const Apply = () => {
  const queryClient = useQueryClient();
  const insets = useSafeAreaInsets();
  const { title, location, jobId, receiverId, isNegotiable, price } = useLocalSearchParams<{
    title: string;
    location: string;
    jobId: string;
    receiverId: string;
    isNegotiable: "YES" | "NO"
    price: string;
  }>();

  const modalRef = useModalState();
  const { isSubmitting, sendRequestOffer } = useOfferActions();
  const handleSubmit = (value: Offer) => {
    if (jobId && receiverId) {
      sendRequestOffer(
        {
          offer: {
            ...value,
            price: value.price,
          },
          message: value.proposal,
          receiver_id: receiverId.toString(),
          job_request_id: jobId.toString(),
          content_type: "OFFER",
        },
        {
          onSuccess: (data) => {
            queryClient.invalidateQueries({
              queryKey: queryKeys.jobRequests.detail(jobId ?? ""),
            })
            modalRef.open();
          },
        },
      );
    }
  };

  const handleGoBack = () => {
    router.back();
  };


  const handleContinue = () => {
    modalRef.close();
    handleGoBack();
  }
  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Application Submitted"
        description="The customer will review your proposal and notify you if selected."
        onContinue={handleContinue}
        maxWidth={300}
        showConfetti={true}
        buttonText="Back to Request"
      />

      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <GoBack handleGoBack={handleGoBack} />
        </View>
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Job Details
          </CustomText>
          <CustomText weight="bold" size="lg">
            {title}
          </CustomText>
          <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
            <LocationIcon color={PALETTE.black} />
            <CustomText weight="regular" style={{ fontSize: 13 }}>
              {location}
            </CustomText>
          </View>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <Formik
          validateOnChange={false}
          initialValues={{
            price: isNegotiable === "YES" ? "" : price,
            proposal: "",
            timeline: "",
            availability: "" as URGENCY,
          }}
          onSubmit={handleSubmit}
          validationSchema={offerValidationSchema}
        >
          {({ handleSubmit }) => {
            return (
              <ScreenShell
                contentContainerStyle={styles.content}
                footer={
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Submit Application"
                      variant="primary"
                      onPress={handleSubmit}
                      loading={isSubmitting}
                    />
                  </View>
                }
              >
                <View style={styles.form}>
                  {
                    isNegotiable === "YES" && (
                    <Input name="price" placeholder="Input Price" type="number-pad" />
                  )}
                  <Select
                    name="timeline"
                    placeholder="Timeline"
                    options={[
                      { label: "1 day", value: "1_day" },
                      { label: "3 days", value: "3_days" },
                      { label: "1 week", value: "1_week" },
                      { label: "1 Month", value: "1_month" },
                    ]}
                  />
                  <Select
                    name="availability"
                    placeholder="Availability"
                    options={URGENCY_OPTIONS}
                  />
                  <Textbox
                    name="proposal"
                    placeholder="Short Proposal ( Max 200 words)"
                  />
                </View>
              </ScreenShell>
            );
          }}
        </Formik>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },

  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },

  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});
export default Apply;
