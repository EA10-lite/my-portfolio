import LocationIcon from "@/assets/images/app-icons/location.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { RequestDetailsSkeleton } from "@/modules/request-job/components";
import { useJobRequestDetails } from "@/modules/request-job/hooks/useJobRequestDetails";
import {
  CustomButton,
  CustomText,
  DetailsField,
  GoBack,
  ImagePreview,
  NotFound,
} from "@/shared/components";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useRef } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const RequestDetails = () => {
  const { user } = useAuthStore();
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<ScrollView>(null);

  const { jobId, type } = useLocalSearchParams();
  const { requestDetails, isLoading } = useJobRequestDetails(jobId.toString());

  const handleApply = () => {
    router.push({
      pathname: `/jobs/${jobId.toString()}/apply` as any,
      params: {
        title: requestDetails?.title,
        location: `${requestDetails?.address} ${requestDetails?.state}, ${requestDetails?.country}`,
        receiverId: requestDetails?.user.id,
        isNegotiable: requestDetails?.is_budget_negotiable ? "YES" : "NO",
        price: requestDetails?.start_price,
      },
    });
  };

  const canApply = () => {
    const myOffers =
      requestDetails?.offers.filter((offer) => offer.sender.id === user?.id) ??
      [];

    // User has never applied
    if (myOffers.filter(offer => offer.status !== "WITHDRAWN").length === 0) {
      return true;
    }

    const latestOffer = myOffers.reduce((latest, offer) => {
      return new Date(offer.updated_at) > new Date(latest.updated_at)
        ? offer
        : latest;
    });

    const updatedAt = new Date(latestOffer.updated_at).getTime();
    const expiresAt = updatedAt + 90 * 60 * 1000;

    // Can apply if the previous application has expired
    return Date.now() >= expiresAt;
  };

  const handleGoBack = () => {
    router.back();
  };

  if (isLoading) return <RequestDetailsSkeleton />;
  if (!requestDetails) return <NotFound />;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <GoBack handleGoBack={handleGoBack} />
        </View>
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Job Details
          </CustomText>
          <CustomText weight="bold" size="lg">
            {requestDetails?.title}
          </CustomText>
          <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
            <LocationIcon />
            <CustomText weight="regular" style={{ fontSize: 13 }}>
              {requestDetails?.address}
            </CustomText>
          </View>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <View style={styles.container}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={[
              styles.content,
              { paddingBottom: insets.bottom + 24 },
            ]}
            ref={scrollRef}
          >
            <View style={styles.group}>
              <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
                <CustomText size="sm" weight="semibold">
                  Job Details
                </CustomText>
              </View>
              <View style={styles.body}>
                <View
                  style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}
                >
                  <CustomText
                    style={{ opacity: 0.6 }}
                    size="sm"
                    weight="medium"
                  >
                    {requestDetails?.description}
                  </CustomText>
                  <ImagePreview images={requestDetails?.images ?? []} />
                </View>
                <View style={styles.detailsField}>
                  <DetailsField
                    type="status"
                    label="Status"
                    value={requestDetails.status}
                  />
                  <DetailsField
                    type="address"
                    label="Address"
                    value={`${requestDetails?.address} ${requestDetails?.state}`}
                  />
                  <DetailsField
                    type="date"
                    label="Date & Time"
                    value={
                      requestDetails?.date
                        ? formatDateTime(requestDetails?.date)
                        : ""
                    }
                    isLast
                  />
                </View>
              </View>
            </View>
            <View style={styles.group}>
              <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
                <CustomText size="sm" weight="semibold">
                  Budget & Timeline
                </CustomText>
              </View>
              <View style={styles.body}>
                <View style={styles.detailsField}>
                  {requestDetails?.start_price && requestDetails.end_price && (
                    <DetailsField
                      type="budget"
                      label="Budget"
                      value={
                        requestDetails?.start_price !== requestDetails.end_price
                          ?`${formatCurrency(requestDetails?.start_price)} - ${formatCurrency(requestDetails?.end_price)}`
                          : formatCurrency(requestDetails.start_price)
                      }
                    />
                  )}
                  <DetailsField
                    type="date"
                    label="Urgency"
                    value={`${requestDetails?.urgency}`}
                  />
                  <DetailsField
                    type="user"
                    label="Customer"
                    value={`${requestDetails?.user.first_name} ${requestDetails?.user.last_name}`}
                    isLast
                  />
                </View>
              </View>
            </View>

            {!canApply() && (
              <View style={styles.info}>
                <CustomText weight="medium" style={styles.infoText}>
                  You already applied for this request.
                </CustomText>
              </View>
            )}
          </ScrollView>
          {type === "REQUEST" &&
            requestDetails.status.toLowerCase() === "pending" &&
            canApply() && (
              <View
                style={[
                  CUSTOM_STYLES.row,
                  styles.footerContainer,
                  { paddingBottom: insets.bottom || 24 },
                ]}
              >
                <CustomButton
                  title="Apply"
                  variant="primary"
                  onPress={handleApply}
                  style={CUSTOM_STYLES.flex}
                />
              </View>
            )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 16,
  },
  step: {
    backgroundColor: PALETTE.black,
    paddingHorizontal: 11.67,
    paddingVertical: 8.17,
    borderRadius: 1333,
  },
  stepText: {
    fontSize: 8.67,
    color: PALETTE.white,
    textTransform: "uppercase",
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  info: {
    padding: 16,
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  infoText: {
    opacity: 0.5,
    fontSize: 13,
    letterSpacing: -0.24,
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  detailsField: {},
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    gap: 12,
  },
});
export default RequestDetails;
