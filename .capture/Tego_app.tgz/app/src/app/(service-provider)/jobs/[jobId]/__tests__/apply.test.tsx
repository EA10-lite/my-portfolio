import { pressableForLabel, renderWithProviders } from "@/testing/render";
import React from "react";
import Apply from "../apply";

const mockSendOffer = jest.fn();

jest.mock("@/modules/offers/hooks/useOfferActions", () => ({
  useOfferActions: () => ({
    isSubmitting: false,
    sendRequestOffer: mockSendOffer,
  }),
}));

jest.mock("expo-router", () => ({
  useLocalSearchParams: () => ({
    title: "House Cleaning",
    location: "Ikeja, Lagos",
    jobId: "job-1",
    receiverId: "rec-1",
  }),
  router: { back: jest.fn(), push: jest.fn(), replace: jest.fn() },
}));

describe("jobs apply (ScreenShell migration)", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders the job header, form fields and footer submit button", async () => {
    const ui = await renderWithProviders(<Apply />);
    expect(ui.getByText("Job Details")).toBeTruthy();
    expect(ui.getByText("House Cleaning")).toBeTruthy();
    expect(ui.getByText("Ikeja, Lagos")).toBeTruthy();
    expect(ui.getByPlaceholderText("Input Price")).toBeTruthy();
    expect(ui.getByText("Timeline")).toBeTruthy();
    expect(ui.getByText("Availability")).toBeTruthy();
    expect(ui.getByPlaceholderText("Short Proposal ( Max 200 words)")).toBeTruthy();
    expect(ui.getByText("Submit Application")).toBeTruthy();
  });

  it("keeps inputs above the keyboard via ScreenShell config", async () => {
    const ui = await renderWithProviders(<Apply />);
    const tree = JSON.stringify(ui.toJSON());
    expect(tree).toContain('"keyboardShouldPersistTaps":"handled"');
    expect(tree).toContain('"enableOnAndroid":true');
    expect(tree).toContain('"keyboardDismissMode":"on-drag"');
    expect(tree).toContain('"extraScrollHeight":20');
    expect(tree).toContain('"extraHeight":100');
  });

  it("renders the submit button enabled once not submitting", async () => {
    const ui = await renderWithProviders(<Apply />);
    const state = pressableForLabel(ui, "Submit Application").props
      .accessibilityState;
    expect(state.disabled).toBe(false);
  });
});