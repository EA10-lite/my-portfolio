import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import {
  ApplicationCard,
  ApplicationCardSkeleton,
} from "@/modules/applications/components";
import { useApplicationActions } from "@/modules/applications/hooks/useApplicationAction";
import { useApplications } from "@/modules/applications/hooks/useApplications";
import { ScreenHeader } from "@/modules/service-provider/components";
import { EmptyMessages } from "@/shared/components";

import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useToastStore } from "@/shared/store/toastStore";
import { useMemo, useState } from "react";
import { FlatList, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const APPLICATIONS_TAB = [
  { label: "All", value: "all" },
  { label: "Awaiting Response", value: "pending", count: 0 },
  { label: "Accepted", value: "accepted", count: 0 },
];

const Applications = () => {
  const { bottom } = useSafeAreaInsets();
  const { showToast } = useToastStore();
  const [search, setSearch] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("all");
  const { handleScroll } = useHideTabBarOnScroll();

  const {
    applications,
    isLoading,
    hasNextPage,
    isFetchingNextPage,
    fetchNextPage,
    refetch,
  } = useApplications(activeTab);

  const { cancel, isSubmitting } = useApplicationActions();

  const handleCancel = (id: string) => {
    if (id) {
      cancel(
        { id },
        {
          onSuccess: () => {
            showToast("Application cancelled", "Your application for this request has bee cancelled successfully.");
          },
        },
      );
    }
  };

  const filteredApplications = useMemo(() => {
    const searchTerm = search.toLowerCase().trim();

    return applications.filter((application) => {
      const matchesSearch =
        application?.job_request?.title?.toLowerCase().includes(searchTerm) ||
        application?.job_request?.service_category?.name.toLowerCase().includes(searchTerm);

      const matchesTab =
        activeTab === "all" || application.status === activeTab;

      return matchesSearch && matchesTab;
    });
  }, [search, activeTab, applications]);

  const [applicationId, setOpenApplicationId] = useState<string | null>(null);

  /**
   * Toggle an order.
   *
   * If the selected order is already open,
   * close it.
   *
   * Otherwise, make it the only open order.
   */
  const handleRequestToggle = (orderId: string) => {
    setOpenApplicationId((currentId) =>
      currentId === orderId ? null : orderId,
    );
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: PALETTE.background,
        },
      ]}
    >
      <FlatList
        data={filteredApplications}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        onEndReachedThreshold={0.4}
        refreshing={isLoading}
        onRefresh={refetch}
        onEndReached={() => {
          if (hasNextPage && !isFetchingNextPage) fetchNextPage();
        }}
        ListHeaderComponent={
          <>
            {/* pulled back out to the edges, cancelling the 20px from contentContainerStyle */}
            <View
              style={{ backgroundColor: PALETTE.black, marginHorizontal: -20 }}
            >
              <ScreenHeader
                title="Manage all your applications"
                search={search}
                setSearch={setSearch}
                placeholder={"Search Applications..."}
                TAB={APPLICATIONS_TAB}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            </View>

            <View style={{ height: 24 }} />
          </>
        }
        renderItem={({ item }) => (
          <ApplicationCard
            application={item}
            cancelApplication={() => handleCancel(item.id)}
            loading={isSubmitting}
            isOpen={applicationId === item.id}
            onToggle={()=> handleRequestToggle(item.id)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: 20, paddingBottom: bottom + TAB_BAR_HEIGHT },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <ApplicationCardSkeleton />
              <ApplicationCardSkeleton />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={{ gap: 20 }}>
              <ApplicationCardSkeleton />
              <ApplicationCardSkeleton />
              <ApplicationCardSkeleton />
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <EmptyMessages
                title={
                  search.length > 0
                    ? "No applications match your search"
                    : "No job applications yet"
                }
                link={{
                  href: "/browse-jobs",
                  label: "Browse Jobs",
                }}
                description="Jobs you apply for will appear here for tracking and updates. "
              />
            </View>
          )
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginTop: 24,
    gap: 20,
    paddingHorizontal: 20,
    flexGrow: 1,
  },

  scrollContent: {
    flexGrow: 1,
    backgroundColor: PALETTE.white,
  },
});

export default Applications;
