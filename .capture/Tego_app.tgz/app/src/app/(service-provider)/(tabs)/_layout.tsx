import { TAB_BAR_HEIGHT } from "@/constants/values";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useTabBarStore } from "@/shared/hooks/useTabBarStore";
import { CustomTabBar } from "@/shared/layouts";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { Redirect, Tabs } from "expo-router";
import { useCallback, useEffect, useRef } from "react";
import { Animated } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function ProtectedLayout() {
  const { isLoggedIn } = useAuthStore();

  if (!isLoggedIn) {
    return <Redirect href="/(public)/signin" />;
  }

  const hidden = useTabBarStore((state) => state.hidden);
  const insets = useSafeAreaInsets();

  const translateY = useRef(new Animated.Value(0)).current;

  const hiddenOffset = TAB_BAR_HEIGHT + insets.bottom + 20;

  useEffect(() => {
    Animated.timing(translateY, {
      toValue: hidden ? hiddenOffset : 0,
      duration: 250,
      useNativeDriver: true,
    }).start();
  }, [hidden, hiddenOffset]);

  const renderTabBar = useCallback(
    (props: BottomTabBarProps) => (
      <CustomTabBar {...props} translateY={translateY} type="SERVICE_PROVIDER" />
    ),
    [translateY],
  );

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
      }}
      tabBar={renderTabBar}
    />
  );
}