import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Arrow,
  Badge,
  CustomModal,
  CustomText,
  UserAvatar,
} from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import BellIcon from "@/assets/images/app-icons/bell-2.svg";
import ContactIcon from "@/assets/images/app-icons/contact-alt.svg";
import CrownIcon from "@/assets/images/app-icons/crown.svg";
import CalenderIcon from "@/assets/images/app-icons/date-alt.svg";
import FileIcon from "@/assets/images/app-icons/file.svg";
import GlobeIcon from "@/assets/images/app-icons/globe.svg";
import InfoIcon from "@/assets/images/app-icons/info.svg";
import PinLocation from "@/assets/images/app-icons/location-pin.svg";
import LogoutIcon from "@/assets/images/app-icons/logout.svg";
import PasswordIcon from "@/assets/images/app-icons/password-alt.svg";
import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import PhoneIcon from "@/assets/images/app-icons/phone-alt.svg";
import ProfileIcon from "@/assets/images/app-icons/profile-filled.svg";
import SecureIcon from "@/assets/images/app-icons/secure.svg";
import SettingsIcon from "@/assets/images/app-icons/settings.svg";
import SupportIcon from "@/assets/images/app-icons/support.svg";
import DeleteIcon from "@/assets/images/app-icons/trash.svg";
import VerifiedIcon from "@/assets/images/app-icons/verified.svg";
import { avatars } from "@/constants/avatars";
import { AVAILABILITIES, TAB_BAR_HEIGHT } from "@/constants/values";
import { useLogout } from "@/modules/auth/hooks/useLogout";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import { useAvailability } from "@/modules/profile/hooks/useAvailability";
import { useProfileActions } from "@/modules/profile/hooks/useProfileActions";
import {
  AddPictureModal,
  AvailabilityModal,
} from "@/modules/service-provider/components";
import useFilePicker from "@/shared/hooks/useFilePicker";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import { hexToRgba } from "@/shared/utils/converter";
import { truncateName } from "@/shared/utils/formatter";
interface Link {
  label: string;
  onPress: () => void;
  Icon: React.ReactNode;
  showVerifiedBadge?: boolean;
}

const Profile = () => {
  const insets = useSafeAreaInsets();
  const { user } = useAuthStore();
  const { logout, isLoading } = useLogout();
  const { handleScroll } = useHideTabBarOnScroll();
  const { uploadProfileCard, uploadProfilePicture } = useProfileActions();
  const { showToast } = useToastStore();

  // profile picture — crop enabled, square
  const { pickImage: pickProfilePicture } = useFilePicker({
    allowCrop: true,
    imagePickerOptions: { aspect: [1, 1] },
    onFilePicked: (file) => uploadProfilePicture(file.uri),
  });

  // profile card — crop enabled, landscape
  const { pickImage: pickProfileCard } = useFilePicker({
    allowCrop: true,
    imagePickerOptions: { aspect: [16, 9] },
    onFilePicked: (file) => uploadProfileCard(file.uri),
  });

  const modalRef = useModalState();
  const avatarRef = useModalState();

  const handleLogout = () => {
    logout(undefined, {
      onSuccess: () => {
        modalRef.close();
      },
    });
  };

  const {
    update,
    isUpdating,
    ref: sheetRef,
    openModal: openSheetModal,
    closeModal: closeSheetModal,
  } = useAvailability();

  const businessTools: Link[] = [
    {
      label: "Availability Status",
      Icon: <CalenderIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: openSheetModal,
    },
    {
      label: "Service Offered",
      Icon: <SettingsIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => {
        const onboardingGaps = user?.onboarding_gaps ?? [];

        if (
            user?.is_onboarded &&
            onboardingGaps.length === 0 &&
            user.profilePicture &&
            user.pictureCard
          ) {
          router.push("/(service-provider)/profile/service-offered");
        } else {
          const isPendingApproval = onboardingGaps.includes("admin_approval");

          showToast(
            isPendingApproval ? "Pending Verification" : "Complete Profile",
            isPendingApproval
              ? "Your account is yet to be approved by the admin."
              : !user?.pictureCard || !user?.profilePicture
                ? "Please add your profile picture and picture card"
                : "Please complete your profile.",
          );
        }
      },
    },
    {
      label: "Business Location",
      Icon: <PinLocation width={16} height={16} color={PALETTE.primary} />,
      onPress: () =>
        router.push("/(service-provider)/profile/business-location"),
    },
  ];
  const myAccountLinks: Link[] = [
    {
      label: "Personal Information",
      Icon: <ProfileIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile"),
    },
    {
      label: "Identity Verification",
      Icon: <ContactIcon width={16} height={16} color={PALETTE.primary} />,
      showVerifiedBadge: true,
      onPress: () =>
        router.push("/(service-provider)/profile/identity-verification"),
    },
    {
      label: "Subscription Plan",
      Icon: <CrownIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/subscription"),
    },
    {
      label: "Language",
      Icon: <GlobeIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/language"),
    },
  ];
  const notificationLink: Link[] = [
    {
      label: "Notification Preference",
      Icon: <BellIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/notifications"),
    },
  ];
  const privacyLinks: Link[] = [
    {
      label: "Change Password",
      Icon: <PasswordIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/change-password"),
    },
    {
      label: "Device Management",
      Icon: <PhoneIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () =>
        router.push("/(service-provider)/profile/device-management"),
    },
    {
      label: "Terms and Conditions",
      Icon: <FileIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/terms"),
    },
    {
      label: "Privacy Policy",
      Icon: <SecureIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/privacy"),
    },
  ];
  const supportLinks: Link[] = [
    {
      label: "FAQs",
      Icon: <InfoIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/faqs"),
    },
    {
      label: "Contact Support",
      Icon: <SupportIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(service-provider)/profile/contact"),
    },
  ];
  const accountManagementLinks: Link[] = [
    {
      label: "Log Out",
      Icon: <LogoutIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => modalRef.open(),
    },
    {
      label: "Delete Account",
      Icon: <DeleteIcon width={16} height={16} color={PALETTE.error} />,
      onPress: () => router.push("/(service-provider)/profile/delete-account"),
    },
  ];

  const handleSave = (
    available_status: AvailabilityStatus,
    accept_instant_booking: boolean,
  ) => {
    update(
      { available_status, accept_instant_booking },
      {
        onSuccess: () => {
          closeSheetModal();
          // do whatever Screen A needs
        },
      },
    );
  };
  return (
    <View style={styles.container}>
      <AvailabilityModal
        availabilities={AVAILABILITIES}
        selectedAvailability={
          AVAILABILITIES.find(
            (availability) =>
              availability.value ===
              user?.provider_settings?.available_status.toLowerCase(),
          ) ?? AVAILABILITIES[0]
        }
        instantBookingAccepted={
          user?.provider_settings?.accept_instant_booking ?? false
        }
        handleSave={handleSave}
        ref={sheetRef}
        closeModal={closeSheetModal}
        isUpdating={isUpdating}
      />
      <CustomModal
        ref={modalRef.ref}
        title="Log Out?"
        description="Are you sure you want to log out of your account?"
        onClose={modalRef.close}
        primaryButtonText="Log Out"
        secondaryButtonText="Cancel"
        secondaryAction={modalRef.close}
        primaryAction={handleLogout}
        primaryLoading={isLoading}
        Icon={<LogoutIcon width={16} height={16} color={PALETTE.primary} />}
      />
      <AddPictureModal
        ref={avatarRef.ref}
        onClose={avatarRef.close}
        addProfileCard={pickProfileCard}
        addProfilePicture={pickProfilePicture}
      />
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <CustomText weight="bold" size="lg">
          Profile
        </CustomText>
      </LinearGradient>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          { paddingBottom: insets.bottom + TAB_BAR_HEIGHT },
        ]}
        onScroll={handleScroll}
      >
        <View style={styles.menu}>
          <View>
            <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
              <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                <Pressable onPress={avatarRef.open}>
                  <View style={{ position: "relative" }}>
                    <UserAvatar
                      url={user?.profilePicture}
                      source={
                        avatars.find((avatar) => avatar.id === user?.avatarId)
                          ?.url ?? avatars[0].url
                      }
                      name={`${user?.firstName} ${user?.lastName}`}
                    />
                    <View style={[styles.edit, CUSTOM_STYLES.center]}>
                      <PencilEditIcon width={14} height={14} />
                    </View>
                  </View>
                </Pressable>
              </View>
              <Pressable
                onPress={() => router.push("/(service-provider)/profile")}
                style={[CUSTOM_STYLES.flex]}
              >
                <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
                  <View style={{ gap: 4 }}>
                    <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
                      <CustomText weight="semibold" style={styles.link}>
                        {truncateName(`${user?.firstName} ${user?.lastName}`)}
                      </CustomText>
                      {!user?.onboarding_gaps.includes("admin_approval") ? (
                        <VerifiedIcon width={16} height={16} />
                      ) : (
                        <Badge title="Unverified" variant="secondary" />
                      )}
                    </View>
                    <CustomText
                      size="xs"
                      weight="medium"
                      style={{ opacity: 0.4 }}
                    >
                      {user?.email || user?.phoneNumber}
                    </CustomText>
                  </View>
                  <Arrow size={14} />
                </View>
              </Pressable>
            </View>
          </View>
        </View>
        <MenuItem title="Business Tools" links={businessTools} />
        <MenuItem
          title="Account"
          links={myAccountLinks}
          Badge={
            user?.onboarding_gaps.includes("admin_approval") ? (
              <Badge title="unverified" variant="secondary" />
            ) : undefined
          }
        />
        <MenuItem title="Notification" links={notificationLink} />
        <MenuItem title="Security & Privacy" links={privacyLinks} />
        <MenuItem title="Help & Support" links={supportLinks} />
        <MenuItem title="Account Management" links={accountManagementLinks} />
      </ScrollView>
    </View>
  );
};

const MenuItem = ({
  title,
  links,
  Badge,
}: {
  title: string;
  links: Link[];
  Badge?: React.ReactNode;
}) => {
  return (
    <View style={styles.menu}>
      <View style={styles.menuItem}>
        <CustomText style={styles.label} weight="semibold">
          {title}
        </CustomText>
        <View style={styles.links}>
          {links.map((link, index) => (
            <Pressable
              key={index}
              onPress={link.onPress}
              style={[
                {
                  borderBottomWidth: index + 1 !== links.length ? 1 : 0,
                  borderBottomColor:
                    index + 1 !== links.length
                      ? hexToRgba(PALETTE.black, 0.04)
                      : "transparent",
                  paddingVertical: 16,
                  paddingBottom: index + 1 !== links.length ? 16 : 0,
                },
              ]}
            >
              <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
                <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                  {link.Icon}
                  <CustomText weight="medium" style={styles.link}>
                    {link.label}
                  </CustomText>
                  {link.showVerifiedBadge && Badge}
                </View>

                <Arrow size={14} />
              </View>
            </Pressable>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  edit: {
    width: 20,
    height: 20,
    borderRadius: 40,
    position: "absolute",
    backgroundColor: PALETTE.white,
    left: 24,
    top: 26,
  },
  menu: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  menuItem: {},
  label: {
    fontSize: 11,
    textTransform: "uppercase",
    opacity: 0.5,
  },
  links: {},
  linkItem: {
    justifyContent: "space-between",
    gap: 8,
  },
  link: {
    fontSize: 13,
  },
});
export default Profile;
