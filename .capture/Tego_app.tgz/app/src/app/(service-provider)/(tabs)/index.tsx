import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { useConversations } from "@/modules/message/hooks/useConversations";
import { useUnreadCount } from "@/modules/notifications/hooks/useUnreadCount";
import { useProfile } from "@/modules/profile/hooks/useProfile";
import { HomeHeader, UpgradeCard } from "@/modules/service-provider/components";

import {
  LatestRequest,
  Performance,
} from "@/modules/service-provider/containers";
import { useDashboard } from "@/modules/service-provider/hooks/useDashboard";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useState } from "react";
import {
  NativeScrollEvent,
  NativeSyntheticEvent,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Home = () => {
  useProfile();
  const { bottom } = useSafeAreaInsets();
  const { handleScroll: onScroll } = useHideTabBarOnScroll();
  const { dashboard, subscription, isLoading, refetch } = useDashboard();
  const { count } = useUnreadCount();
  const { totalUnread } = useConversations();

  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);

    try {
      await Promise.all([refetch()]);
    } finally {
      setRefreshing(false);
    }
  };

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    onScroll(event);

    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;

    const paddingToBottom = 300;

    const isNearBottom =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;

    if (isNearBottom) {
      refetch();
    }
  };
  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: PALETTE.black,
        },
      ]}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        contentContainerStyle={{
          flexGrow: 1,
        }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
      >
        <HomeHeader
          requestCount={dashboard?.direct_booking_count ?? 0}
          orderCount={dashboard?.order_count ?? 0}
          notificationCount={count}
          messageCount={totalUnread}
          loading={isLoading}
        />
        <View
          style={{
            backgroundColor: PALETTE.white,
            zIndex: 1,
            elevation: 0,
            paddingBottom: bottom + TAB_BAR_HEIGHT,
            flexGrow: 1,
          }}
        >
          {!isLoading && subscription && subscription?.plan !== "FREE" ? (
            <View style={styles.content}>
              <Performance
                average_rating={dashboard?.average_rating}
                average_response_time={dashboard?.average_response_time}
                completion_percentage={dashboard?.completion_percentage}
                message_response_rate={dashboard?.message_response_rate}
              />
              <LatestRequest
                count={dashboard?.recent_service_bookings?.length ?? 0}
                requests={dashboard?.recent_service_bookings ?? []}
              />
            </View>
          ) : (
            !isLoading &&
            subscription?.plan.toLowerCase() === "free" && (
              <View style={styles.content}>
                <UpgradeCard />
              </View>
            )
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: { marginTop: 24 },
});

export default Home;
