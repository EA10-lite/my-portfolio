import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT, TIMELINE } from "@/constants/values";
import { useBooking } from "@/modules/booking/hooks/useBooking";
import { useBusinessLocation } from "@/modules/profile/hooks/useBusinessLocation";
import {
  DirectRequestCard,
  RequestCardSkeleton,
  RequestFilter,
} from "@/modules/requests/components";
import { ScreenHeader } from "@/modules/service-provider/components";
import { EmptyMessages } from "@/shared/components";

import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import {
  FlatList,
  RefreshControl,
  StyleSheet,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const REQUEST_TAB = [
  { label: "Nearby", value: "nearby", count: 0 },
  { label: "Urgent", value: "urgent", count: 0 },
];

const Requests = () => {
  const { bottom } = useSafeAreaInsets();
  const [search, setSearch] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("nearby");
  const { handleScroll } = useHideTabBarOnScroll();

  const { location } = useBusinessLocation();

  const {
    bookings,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    filters,
    applyFilters,
    clearFilters,
    isFiltered,
    refetch,
  } = useBooking();

  const filteredRequests = useMemo(() => {
    const searchTerm = search.trim().toLowerCase();
    let requests = bookings;
    // Search
    if (searchTerm) {
      requests = requests.filter((request) =>
        request.title.toLowerCase().includes(searchTerm)
      );
    }
    // Urgent tab
    if (activeTab === "urgent") {
      requests = requests
        .filter((request) => TIMELINE.includes(request.urgency.toLowerCase()))
        .sort(
          (a, b) =>
            TIMELINE.indexOf(a.urgency.toLowerCase()) -
            TIMELINE.indexOf(b.urgency.toLowerCase())
        );
    }
    return requests;
  }, [search, bookings, activeTab]);

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: PALETTE.background,
        },
      ]}
    >
      <FlatList
        data={filteredRequests}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        onEndReachedThreshold={0.4}
        refreshing={isLoading}
        onRefresh={refetch}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={refetch}
            tintColor={PALETTE.black}
          />
        }
        onEndReached={() => {
          if (hasNextPage && !isFetchingNextPage) fetchNextPage();
        }}
        ListHeaderComponent={
          <>
            <View
              style={{ backgroundColor: PALETTE.black, marginHorizontal: -20 }}
            >
              <ScreenHeader
                title="Requests from customers near you"
                search={search}
                setSearch={setSearch}
                placeholder={"Search Requests..."}
                Filter={
                  <RequestFilter
                    filters={filters}
                    onApply={applyFilters}
                    onClear={clearFilters}
                  />
                }
                TAB={REQUEST_TAB}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            </View>

            <View style={{ height: 24 }} />
          </>
        }
        renderItem={({ item }) => (
          <DirectRequestCard
            request={item}
            handlePress={() =>
              router.push(`/(service-provider)/request/${item.id}`)
            }
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: 20, paddingBottom: bottom + TAB_BAR_HEIGHT },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <RequestCardSkeleton />
              <RequestCardSkeleton />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={{ gap: 20 }}>
              <RequestCardSkeleton />
              <RequestCardSkeleton />
              <RequestCardSkeleton />
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <EmptyMessages
                title={
                  search.length > 0 || isFiltered
                    ? "No request match your search"
                    : "No new requests yet"
                }
                description={
                  search.length > 0 || isFiltered
                    ? "Clear search or reset filter to see customers requests"
                    : "Urgent customer requests will appear here when available"
                }
              />
            </View>
          )
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    backgroundColor: PALETTE.white,
    zIndex: 1,
    elevation: 0,
    flex: 1,
  },
  content: {
    marginTop: 24,
    gap: 20,
    paddingHorizontal: 20,
    flexGrow: 1,
  },
  scrollContent: {
    flexGrow: 1,
    backgroundColor: PALETTE.white,
  },
});

export default Requests;
