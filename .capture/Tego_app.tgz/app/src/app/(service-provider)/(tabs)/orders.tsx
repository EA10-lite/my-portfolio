import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { useProviderOrders } from "@/modules/order/hooks/useProviderOrders";
import {
  getProcessedOrder,
  matchesStatusTab,
} from "@/modules/order/lib/orderHelpers";
import {
  ProviderOrderCard,
  ProviderOrderCardSkeleton,
  ScreenHeader,
} from "@/modules/service-provider/components";
import { EmptyMessages } from "@/shared/components";

import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useMemo, useState } from "react";
import { FlatList, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ORDERS = [
  { label: "All", value: "all", count: 0 },
  { label: "Active", value: "IN_PROGRESS", count: 0 },
  { label: "Completed", value: "COMPLETED", count: 0 },
  { label: "Cancelled", value: "CANCELLED", count: 0 },
];

const Orders = () => {
  const { bottom } = useSafeAreaInsets();
  const [search, setSearch] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("all");
  const { handleScroll } = useHideTabBarOnScroll();

  const {
    orders,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    refetch,
  } = useProviderOrders(activeTab);

  const filteredOrders = useMemo(() => {
    const searchTerm = search.toLowerCase().trim();

    return orders.filter((order) => {
      const { title, service, status } = getProcessedOrder(order);

      const matchesSearch =
        title.toLowerCase().includes(searchTerm) ||
        service?.toLowerCase().includes(searchTerm);

      const matchesTab = matchesStatusTab(status, activeTab);

      return matchesSearch && matchesTab;
    });
  }, [orders, search, activeTab]);

  const [openOrderId, setOpenOrderId] = useState<string | null>(null);

  /**
   * Toggle an order.
   *
   * If the selected order is already open,
   * close it.
   *
   * Otherwise, make it the only open order.
   */
  const handleOrderToggle = (orderId: string) => {
    setOpenOrderId((currentId) => (currentId === orderId ? null : orderId));
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: PALETTE.background,
        },
      ]}
    >
      <FlatList
        data={filteredOrders}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        onEndReachedThreshold={0.4}
        refreshing={isLoading}
        onRefresh={refetch}
        onEndReached={() => {
          if (hasNextPage && !isFetchingNextPage) fetchNextPage();
        }}
        ListHeaderComponent={
          <>
            {/* pulled back out to the edges, cancelling the 20px from contentContainerStyle */}
            <View
              style={{ backgroundColor: PALETTE.black, marginHorizontal: -20 }}
            >
              <ScreenHeader
                title="Track and manage your orders"
                search={search}
                setSearch={setSearch}
                placeholder={"Search Jobs..."}
                TAB={ORDERS}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            </View>

            <View style={{ height: 24 }} />
          </>
        }
        renderItem={({ item }) => (
          <ProviderOrderCard
            order={item}
            isOpen={openOrderId === item.id}
            onToggle={()=> handleOrderToggle(item.id)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: 20, paddingBottom: bottom + TAB_BAR_HEIGHT },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <ProviderOrderCardSkeleton />
              <ProviderOrderCardSkeleton />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={{ gap: 20 }}>
              <ProviderOrderCardSkeleton />
              <ProviderOrderCardSkeleton />
              <ProviderOrderCardSkeleton />
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <EmptyMessages
                title={
                  search.length > 0
                    ? "No order match your search"
                    : "Your orders will appear here"
                }
                link={{
                  href: "/browse-jobs",
                  label: "Browse Jobs",
                }}
                description="Track active, completed, and cancelled work in one place"
              />
            </View>
          )
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    backgroundColor: PALETTE.white,
    zIndex: 1,
    elevation: 0,
    flex: 1,
  },
  content: {
    marginTop: 24,
    gap: 20,
    paddingHorizontal: 20,
    flexGrow: 1,
  },
  scrollContent: {
    flexGrow: 1,
    backgroundColor: PALETTE.white,
  },
});

export default Orders;
