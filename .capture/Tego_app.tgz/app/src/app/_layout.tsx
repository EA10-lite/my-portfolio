import { PRIVATE_QUERY_PREFIXES } from "@/constants/queryKeys";
import PushNotificationProvider from "@/context/PushNotificationProvider";
import { socketService } from "@/modules/message/services/socket.service";
import { useAppFonts } from "@/shared/hooks/useAppFonts";
import { useSystemThemeSync } from "@/shared/hooks/useSystemTheme";
import { useTabBarStore } from "@/shared/hooks/useTabBarStore";
import { NetworkToast, Toast } from "@/shared/layouts";
import { tokenStorage } from "@/shared/lib/tokenStorage";
import { useLocationStore } from "@/shared/store/locationStore";
import { useUIStore } from "@/shared/store/uiStore";
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createAsyncStoragePersister } from "@tanstack/query-async-storage-persister";
import { QueryClient } from "@tanstack/react-query";
import { PersistQueryClientProvider } from "@tanstack/react-query-persist-client";
import { Stack, usePathname } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { Platform, StatusBar, UIManager } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";

// app/_layout.tsx
if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental?.(true);
}

// Same value as the expo-splash-screen backgroundColor in app.json, and the
// same value the custom SplashScreen's LinearGradient flattens to at its
// top stop. Applied below to both the root container and the navigator's
// own screen background, so there's no frame where either falls back to
// its default white and shows through during the native-splash → JS handoff.
const SPLASH_BACKGROUND_COLOR = "#9FD7FB";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 1000 * 60 * 2,
      refetchOnWindowFocus: true,
      refetchOnMount: "always",
    },
  },
});

const persister = createAsyncStoragePersister({
  storage: AsyncStorage,
});

// 🚫 Prevent auto hide
SplashScreen.setOptions({ duration: 100, fade: true });
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  useSystemThemeSync();
  const isBelowPopup = useTabBarStore((state) => state.isBelowPopup);
  const { isLocationPopupOpen } = useUIStore();
  const pathname = usePathname();
  const [fontsLoaded, fontError] = useAppFonts();
  const fontsReady = fontsLoaded || !!fontError;

  useEffect(() => {
    if (!fontsReady) return;
    if (pathname === "/") return;

    SplashScreen.hideAsync();
  }, [fontsReady, pathname]);

  useEffect(() => {
    const initSocket = async () => {
      const token = await tokenStorage.get();
      if (token) {
        socketService.connect(); // token exists = user is logged in, connect
      }
    };

    initSocket();
  }, []);

  const { getCurrentLocation } = useLocationStore();

  useEffect(() => {
    getCurrentLocation();
  }, []);

  if (!fontsReady) {
    return null;
  }
  const isPopupPage =
    pathname === "/" || pathname === "/explore" || pathname === "/order";

  return (
    <GestureHandlerRootView
      style={{ flex: 1, backgroundColor: SPLASH_BACKGROUND_COLOR }}
    >
      <PushNotificationProvider>
        <PersistQueryClientProvider
          client={queryClient}
          persistOptions={{
            persister,
            maxAge: 1000 * 60 * 60, // 1 hour cap for persisted cache
            dehydrateOptions: {
              shouldDehydrateQuery: (query: any) => {
                const key = query.queryKey[0] as string | undefined;
                if (key && PRIVATE_QUERY_PREFIXES.includes(key as any)) {
                  return false;
                }
                // Persisting an in-flight (pending) query snapshots its live
                // promise; if that request later rejects, TanStack logs
                // "A query that was dehydrated as pending ended up rejecting."
                // Only snapshot settled successful queries (TanStack default).
                return query.state.status === "success";
              },
            },
          }}
        >
          <BottomSheetModalProvider>
            <StatusBar
              barStyle={
                pathname.includes("message/") && !pathname.includes("offer")
                  ? "light-content"
                  : isLocationPopupOpen && isPopupPage && isBelowPopup
                    ? "light-content"
                    : "dark-content"
              }
            />
            <Stack
              screenOptions={{
                headerShown: false,
                animation: "fade",
                contentStyle: { backgroundColor: SPLASH_BACKGROUND_COLOR },
              }}
            />
            <Toast />
            <NetworkToast />
          </BottomSheetModalProvider>
        </PersistQueryClientProvider>
      </PushNotificationProvider>
    </GestureHandlerRootView>
  );
}
