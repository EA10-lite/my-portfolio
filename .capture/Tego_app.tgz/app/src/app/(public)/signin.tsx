import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { LoginPayload, useSignin } from "@/modules/auth/hooks/useSignin";
import { useTempUserStore } from "@/modules/auth/stores/tempUserStore";
import { signInSchema } from "@/modules/auth/utils/validation";
import {
  Checkbox,
  CustomButton,
  CustomText,
  Error,
  Input,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useBackOrPush } from "@/shared/hooks/useBackOrPush";
import { AuthLayout } from "@/shared/layouts";
import { Link } from "expo-router";
import { Formik } from "formik";
import { StyleSheet, View } from "react-native";

const SignIn = () => {
  const { username } = useTempUserStore();
  const { mutate: login, isPending, errorMessage, reset } = useSignin();
  const handleSignup = useBackOrPush("/(public)/account-type", "account-type");

  const isButtonDisabled = (values: Record<string, string>) => {
    return !values.email || !values.password;
  };

  const handleLogin = (values: LoginPayload) => {
    login(values);
  };

  return (
    <AuthLayout>
      <Formik
        initialValues={{
          email: "",
          password: "",
        }}
        onSubmit={(values) => handleLogin(values)}
        validationSchema={signInSchema}
      >
        {({ handleSubmit, values, handleChange }) => {
          const disabled = isButtonDisabled(values);
          // 👇 wrap handleChange to clear error on any field change
          const handleChangeWithClear = (field: string) => (value: string) => {
            if (errorMessage) reset(); // 👈 clears errorMessage
            handleChange(field)(value);
          };
          return (
            <ScreenShell
              contentContainerStyle={{
                paddingBottom: 24,
                paddingHorizontal: 20,
              }}
              footer={
                <View style={styles.footerContainer}>
                  <CustomButton
                    onPress={handleSubmit}
                    variant={!disabled ? "primary" : "secondary"}
                    disabled={isPending || disabled}
                    loading={isPending}
                    title="Proceed"
                  />
                  <CustomText weight="medium" style={styles.footerText}>
                    Don't have an account?{" "}
                    <CustomText
                      handlePress={handleSignup}
                      weight="semibold"
                      style={styles.footerLink}
                    >
                      Sign up
                    </CustomText>
                  </CustomText>
                </View>
              }
            >
              <View style={styles.contentContainer}>
                <View style={styles.textContainer}>
                  <CustomText
                    weight="semibold"
                    size="sm"
                    style={styles.textTitle}
                  >
                    Welcome back
                  </CustomText>
                  <CustomText weight="bold" size="lg">
                    {username}
                  </CustomText>
                </View>

                <View style={styles.formContainer}>
                  <View style={CUSTOM_STYLES.inputs}>
                    <Input
                      name="email"
                      type="email-address"
                      placeholder="Email adress"
                      onChange={handleChangeWithClear("email")}
                    />
                    <Input
                      name="password"
                      placeholder="Password"
                      onChange={handleChangeWithClear("password")}
                      isSecureText
                    />
                  </View>

                  {errorMessage && (
                    <Error error={errorMessage} visible={true} />
                  )}

                  <View style={styles.forgotPasswordContainer}>
                    <Checkbox title="Remember me" name="rememberMe" />

                    <Link
                      href="/(public)/forgotpassword"
                      style={styles.forgotPasswordLink}
                    >
                      <CustomText weight="medium" size="sm">
                        Forgot password?
                      </CustomText>
                    </Link>
                  </View>
                </View>
              </View>
            </ScreenShell>
          );
        }}
      </Formik>
    </AuthLayout>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    flex: 1,
    gap: 32,
    paddingTop: 38,
  },
  textContainer: {
    gap: 5,
  },
  textTitle: {
    textTransform: "uppercase",
  },
  formContainer: { gap: 16 },
  forgotPasswordContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  forgotPasswordLink: {
    backgroundColor: PALETTE.secondary,
    borderRadius: 80,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  footerContainer: {
    gap: 8,
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  footerLink: {
    textDecorationLine: "underline",
  },
  footerText: {
    textAlign: "center",
  },
});

export default SignIn;
