import Logo from "@/assets/images/app-icons/logo.svg";
import { resolveSplashAction } from "@/modules/auth/lib/splashRouting";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { CustomButton, CustomText } from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useEffect, useRef } from "react";
import { Animated, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// Minimum time the branded splash stays visible before routing away, even
// for an already-authenticated user. Without this, resolveSplashAction can
// return a "route" action and navigate away in the same tick auth hydration
// resolves — before the gradient/logo has rendered a single frame.
const MIN_BRAND_HOLD_MS = 400;

const SplashScreen = () => {
  const insets = useSafeAreaInsets();
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    let brandHold: ReturnType<typeof setTimeout> | undefined;
    let routeHold: ReturnType<typeof setTimeout> | undefined;

    const decide = () => {
      const action = resolveSplashAction(
        useAuthStore.persist.hasHydrated(),
        useAuthStore.getState().isLoggedIn,
        useAuthStore.getState().user?.userType,
      );

      if (action.type === "route") {
        // Same minimum hold as the show-buttons branch below, so a
        // returning logged-in user still sees the brand splash for a beat
        // instead of an instant, jarring cut straight to the tabs.
        routeHold = setTimeout(() => {
          router.replace(action.href);
        }, MIN_BRAND_HOLD_MS);
      } else if (action.type === "show-buttons") {
        // Brief brand beat before revealing the sign-in options; avoids the
        // flash of a bare logo once the persisted store rehydrates (~1200ms
        // was previously hard-coded).
        brandHold = setTimeout(() => {
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 600,
            useNativeDriver: true,
          }).start();
        }, MIN_BRAND_HOLD_MS);
      }
    };

    if (useAuthStore.persist.hasHydrated()) {
      decide();
    } else {
      unsubscribe = useAuthStore.persist.onFinishHydration(decide);
    }

    return () => {
      unsubscribe?.();
      if (brandHold) clearTimeout(brandHold);
      if (routeHold) clearTimeout(routeHold);
    };
  }, [fadeAnim]);

  return (
    <LinearGradient
      colors={[
        "rgba(51, 171, 247, 0.472)",
        "rgba(255, 255, 255, 0.4012)",
        "rgba(255, 255, 255, 0.59)",
      ]}
      locations={[0, 0.7846, 1]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={[styles.container]}
    >
      {/* Logo pinned to center */}
      <View style={styles.logoWrapper} pointerEvents="none">
        <Logo width={55} height={48} />
      </View>
      <Animated.View
        style={[
          styles.bottomContent,
          { opacity: fadeAnim, paddingBottom: Math.max(insets.bottom, 30) },
        ]}
      >
        <View style={styles.textContent}>
          <CustomText size="sm" style={styles.title}>
            Welcome to TEGO 👋
          </CustomText>
          <CustomText size="lg" weight="semibold" style={styles.subtitle}>
            Get things done easily. Book services, receive offers, or post a
            job.
          </CustomText>
        </View>

        <View style={styles.buttons}>
          <CustomButton
            title="Have an account"
            variant="default"
            style={styles.button}
            onPress={() => router.push("/(public)/signin")}
          />
          <CustomButton
            title="I'm new here"
            variant="primary"
            style={styles.button}
            onPress={() => router.push("/(public)/onboarding")}
          />
        </View>
      </Animated.View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  // Absolutely centered logo, sits behind/above bottom content
  logoWrapper: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
  },

  // Bottom-anchored animated section
  bottomContent: {
    marginTop: "auto", // pushes to bottom (RN >= 0.71)
    gap: 48,
  },
  textContent: {
    maxWidth: 270,
    margin: "auto",
    gap: 12,
  },
  title: {
    textTransform: "uppercase",
    textAlign: "center",
    opacity: 0.5,
  },
  subtitle: {
    textAlign: "center",
  },
  buttons: {
    flexDirection: "row",
    gap: 10,
    justifyContent: "center",
    rowGap: 12,
    width: "100%",
  },
  button: {
    flex: 1,
  },
});

export default SplashScreen;
