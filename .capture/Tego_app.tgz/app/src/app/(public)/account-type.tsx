import Customer from "@/assets/images/app-icons/customer.svg";
import Helmet from "@/assets/images/app-icons/helmet.svg";
import { PALETTE } from "@/constants/colors";
import { AccountTypeOption } from "@/modules/auth/components";
import { CustomButton, CustomText } from "@/shared/components";
import { useBackOrPush } from "@/shared/hooks/useBackOrPush";
import { AuthLayout } from "@/shared/layouts";
import { Link, router } from "expo-router";
import { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";

type ValidRoute =
  | "/(public)/signup?type=CUSTOMER"
  | "/(public)/signup?type=SERVICE_PROVIDER";

const getStartedOptions = [
  {
    id: 0,
    title: "Register as a Customer",
    description:
      "Find and book services or post jobs to get things done quickly.",
    icon: () => <Customer width={49} height={34} />,
    route: "/(public)/signup?type=CUSTOMER" as ValidRoute,
  },
  {
    id: 1,
    title: "Become a Provider",
    description:
      "Offer your services, get hired by customers, and start earning on your terms.",
    icon: () => <Helmet />,
    route: "/(public)/signup?type=SERVICE_PROVIDER" as ValidRoute,
  },
];

const AccountType = () => {
  const [isSelected, setIsSelected] = useState<{
    id: number;
    route: string;
  } | null>(null);

  const handleSignIn = useBackOrPush("/(public)/signin", "signin");
  return (
    <AuthLayout>
      <View style={styles.container}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            paddingBottom: 24,
            paddingHorizontal: 20,
          }}
        >
          <View style={styles.contentContainer}>
            <View style={styles.titleContainer}>
              <CustomText weight="bold" style={{ fontSize: 28, lineHeight: 32 }}>
                How would you like to use Tego?
              </CustomText>
            </View>
            <View style={styles.optionsContainer}>
              {getStartedOptions.map((option, index) => (
                <AccountTypeOption
                  key={index}
                  title={option.title}
                  description={option.description}
                  Icon={option.icon}
                  isSelected={isSelected?.id === option.id}
                  onPress={() => {
                    setIsSelected(option);
                  }}
                />
              ))}
            </View>
          </View>
        </ScrollView>

        <View style={styles.footerContainer}>
          <CustomButton
            variant={!isSelected ? "secondary" : "primary"}
            disabled={!isSelected}
            title="Proceed"
            onPress={() =>
              router.push(getStartedOptions[isSelected?.id ?? 0].route)
            }
          />
          <CustomText weight="medium" style={styles.footerText}>
            Already have an account?{" "}
            <CustomText
              handlePress={handleSignIn}
              weight="semibold"
              style={styles.footerLink}
            >
              Sign in
            </CustomText>
          </CustomText>
        </View>
      </View>
    </AuthLayout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    gap: 32,
    paddingTop: 38,
  },
  titleContainer: {
    maxWidth: "75%",
  },
  optionsContainer: {
    gap: 16,
  },
  footerContainer: {
    gap: 8,
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  footerText: {
    textAlign: "center",
  },
  footerLink: {
    textDecorationLine: "underline",
  },
});

export default AccountType;
