import { SlideItem } from "@/modules/onboarding/components";
import { router } from "expo-router";
import { useRef, useState } from "react";
import {
  Dimensions,
  FlatList,
  NativeScrollEvent,
  NativeSyntheticEvent,
  StyleSheet,
  View,
} from "react-native";

const { width } = Dimensions.get("window");

const slides = [
  {
    id: 1,
    title: "Need something done?",
    description:
      "From quick fixes to big jobs, find the right person in minutes.",
    image: require("../../../assets/images/app-images/onboarding-img-1.png"),
    imageStyle: {
      ...StyleSheet.absoluteFill,
    },
    textBoxStyle: {
      maxWidth: 248,
    },
  },
  {
    id: 2,
    title: "Book Or Request",
    description:
      "Choose a ready service or tell us what you need — we've got you covered.",
    image: require("../../../assets/images/app-images/onboarding-img-2.png"),
  },
  {
    id: 3,
    title: "Hire with confidence",
    description:
      "Compare offers, check reviews, and pick the best provider for your job",
    image: require("../../../assets/images/app-images/onboarding-img-3.png"),
  },
];

const Onboarding = () => {
  const flatListRef = useRef<FlatList>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex + 1,
        animated: true,
      });
    } else {
      router.dismissAll();
      router.replace("/(public)/account-type");
    }
  };

  const handleBack = () => {
    if (currentIndex > 0) {
      flatListRef.current?.scrollToIndex({
        index: currentIndex - 1,
        animated: true,
      });
    }
  };

  const handleMomentumScrollEnd = (
    event: NativeSyntheticEvent<NativeScrollEvent>,
  ) => {
    const index = Math.round(event.nativeEvent.contentOffset.x / width);

    setCurrentIndex(index);
  };

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={slides}
        keyExtractor={(item) => item.id.toString()}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        bounces={false}
        onMomentumScrollEnd={handleMomentumScrollEnd}
        renderItem={({ item }) => (
          <SlideItem
            item={item}
            currentIndex={currentIndex}
            handleNext={handleNext}
            handleBack={handleBack}
          />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default Onboarding;
