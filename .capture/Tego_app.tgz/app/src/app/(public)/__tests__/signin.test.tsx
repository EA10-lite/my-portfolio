import { fireEvent } from "@testing-library/react-native";
import React from "react";
import { pressableForLabel, renderWithProviders } from "@/testing/render";
import SignIn from "../signin";

const mock = {
  login: jest.fn(),
  reset: jest.fn(),
  isPending: false,
  error: null as string | null,
};

jest.mock("@/modules/auth/hooks/useSignin", () => ({
  useSignin: () => ({
    mutate: mock.login,
    reset: mock.reset,
    isPending: mock.isPending,
    errorMessage: mock.error,
  }),
}));

jest.mock("@/shared/hooks/useBackOrPush", () => ({
  useBackOrPush: () => jest.fn(),
}));

jest.mock("expo-router", () => {
  const { createElement } = require("react");
  const { Text } = require("react-native");
  return {
    Link: (props: { children?: React.ReactNode }) =>
      createElement(Text, null, props.children),
    router: { replace: jest.fn(), push: jest.fn(), back: jest.fn() },
  };
});

describe("signin (ScreenShell migration)", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mock.error = null;
    mock.isPending = false;
  });

  it("renders form fields, checkbox and footer submit button", async () => {
    const ui = await renderWithProviders(<SignIn />);
    expect(ui.getByPlaceholderText("Phone number")).toBeTruthy();
    expect(ui.getByPlaceholderText("Password")).toBeTruthy();
    expect(ui.getByText("Remember me")).toBeTruthy();
    expect(ui.getByText("Forgot password?")).toBeTruthy();
    expect(ui.getByText("Welcome back")).toBeTruthy();
    // Submit button is rendered through the ScreenShell footer
    expect(ui.getByText("Proceed")).toBeTruthy();
  });

  it("keeps the submit button disabled until the fields are filled", async () => {
    const ui = await renderWithProviders(<SignIn />);
    expect(pressableForLabel(ui, "Proceed").props.accessibilityState).toEqual({
      disabled: true,
    });

    await fireEvent.changeText(
      ui.getByPlaceholderText("Phone number"),
      "08012345678",
    );
    await fireEvent.changeText(
      ui.getByPlaceholderText("Password"),
      "secret123",
    );
    expect(pressableForLabel(ui, "Proceed").props.accessibilityState).toEqual({
      disabled: false,
    });
  });

  it("submits the entered values through the footer button", async () => {
    const ui = await renderWithProviders(<SignIn />);
    await fireEvent.changeText(
      ui.getByPlaceholderText("Phone number"),
      "08012345678",
    );
    await fireEvent.changeText(
      ui.getByPlaceholderText("Password"),
      "secret123",
    );

    await fireEvent.press(ui.getByText("Proceed"));
    expect(mock.login).toHaveBeenCalledWith({
      phoneNumber: "08012345678",
      password: "secret123",
    });
  });

  it("does not submit values that fail validation", async () => {
    const ui = await renderWithProviders(<SignIn />);
    await fireEvent.changeText(
      ui.getByPlaceholderText("Phone number"),
      "08012345678",
    );
    await fireEvent.changeText(
      ui.getByPlaceholderText("Password"),
      "1234567", // too short (min 8)
    );

    await fireEvent.press(ui.getByText("Proceed"));
    expect(mock.login).not.toHaveBeenCalled();
  });

  it("surfaces the server error message", async () => {
    mock.error = "Invalid credentials";
    const ui = await renderWithProviders(<SignIn />);
    expect(ui.getByText("Invalid credentials")).toBeTruthy();
  });

  it("clears the error as soon as a field changes", async () => {
    mock.error = "Invalid credentials";
    const ui = await renderWithProviders(<SignIn />);
    await fireEvent.changeText(
      ui.getByPlaceholderText("Phone number"),
      "08012345678",
    );
    expect(mock.reset).toHaveBeenCalled();
  });
});