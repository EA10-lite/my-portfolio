import { fireEvent } from "@testing-library/react-native";
import React from "react";
import { pressableForLabel, renderWithProviders } from "@/testing/render";
import Signup from "../signup";

const mockSendOTP = jest.fn();

jest.mock("@/modules/auth/hooks/useSignup", () => ({
  useSignup: () => ({
    step: "email",
    sendOTP: mockSendOTP,
    verifyOTP: jest.fn(),
    createPassword: jest.fn(),
    completeRegistration: jest.fn(),
    completeProviderRegistration: jest.fn(),
    completeKYC: jest.fn(),
    resetStep: jest.fn(),
    isPending: false,
    errorMessage: null,
  }),
}));

jest.mock("@/shared/hooks/useBackOrPush", () => ({
  useBackOrPush: () => jest.fn(),
}));

jest.mock("expo-router", () => {
  const { createElement } = require("react");
  const { Text } = require("react-native");
  return {
    Link: (props: { children?: React.ReactNode }) =>
      createElement(Text, null, props.children),
    router: { replace: jest.fn(), push: jest.fn(), back: jest.fn() },
    useLocalSearchParams: () => ({ type: "CUSTOMER" }),
  };
});

describe("signup — email step (ScreenShell migration)", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders the email step through ScreenShell with footer submit", async () => {
    const ui = await renderWithProviders(<Signup />);
    expect(ui.getByText("Let's get you started")).toBeTruthy();
    expect(ui.getByPlaceholderText("Email Address")).toBeTruthy();
    // The primary action lives in the ScreenShell footer
    expect(ui.getByText("Send OTP")).toBeTruthy();
    expect(ui.getByText("Sign in")).toBeTruthy();
  });

  it("keeps Send OTP disabled until an email is typed", async () => {
    const ui = await renderWithProviders(<Signup />);
    expect(pressableForLabel(ui, "Send OTP").props.accessibilityState).toEqual({
      disabled: true,
    });
    expect(pressableForLabel(ui, "Send OTP").props.disabled).toBeUndefined();

    await fireEvent.changeText(
      ui.getByPlaceholderText("Email Address"),
      "ada@example.com",
    );
    expect(pressableForLabel(ui, "Send OTP").props.accessibilityState).toEqual({
      disabled: false,
    });
  });

  it("requests an OTP with the entered email", async () => {
    const ui = await renderWithProviders(<Signup />);
    await fireEvent.changeText(
      ui.getByPlaceholderText("Email Address"),
      "ada@example.com",
    );
    await fireEvent.press(ui.getByText("Send OTP"));
    expect(mockSendOTP).toHaveBeenCalledWith("ada@example.com");
  });

  it("never triggers sendOTP while the email field is empty", async () => {
    const ui = await renderWithProviders(<Signup />);
    await fireEvent.press(ui.getByText("Send OTP"));
    expect(mockSendOTP).not.toHaveBeenCalled();
  });
});