import PencilEdit from "@/assets/images/app-icons/pencil-edit.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ForgotPasswordSteps } from "@/modules/auth/components";
import { useForgotPassword } from "@/modules/auth/hooks/useForgotPassword";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import {
  createPasswordSchema,
  signupSchema,
  verifyPhoneNumberSchema,
} from "@/modules/auth/utils/validation";
import {
  CustomButton,
  CustomText,
  Error,
  Input,
  OTPInput,
  SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { AuthLayout } from "@/shared/layouts";
import Feather from "@expo/vector-icons/Feather";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isRunningInExpoGo } from "expo";
import { router } from "expo-router";
import { Formik } from "formik";
import { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";

const OTP_LENGTH = 6;

const stepConfig = {
  email: {
    title: "Forgot your password?",
    description: "Enter the code sent to your email address",
    trackerStep: "email" as const,
    schema: signupSchema,
  },
  verify: {
    title: "Forgot your password?",
    description: "Enter the code sent to your email",
    trackerStep: "email" as const,
    schema: verifyPhoneNumberSchema,
  },
  password: {
    title: "Create a new passwod",
    description: "Choose a new password to secure your account",
    trackerStep: "password" as const,
    schema: createPasswordSchema,
  },
  success: {
    schema: null,
    desription:
      "Your password has been updated. You can now Log in to your account.",
    title: "Password reset successful",
    trackerStep: "success",
    initialValues: {},
  },
};

const ForgotPassword = () => {
  const { user } = useAuthStore();
  const {
    step,
    errorMessage,
    isPending,
    resetStep,
    sendOTP,
    verifyOTP,
    createPassword,
  } = useForgotPassword();
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const isFirstRender = useRef(true);

  const sheetRef = useModalState();

  useEffect(() => {
    // Skip animation on first render
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    Animated.sequence([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 150,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 400,
        easing: Easing.in(Easing.ease),
        useNativeDriver: true,
      }),
    ]).start();
  }, [step]);

  const [timeLeft, setTimeLeft] = useState<number>(600);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  useEffect(() => {
    if (step !== "verify") return;

    setTimeLeft(600); // 10 minutes
    setIsRunning(true);
  }, [step]);

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) {
      setIsRunning(false);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  const config = stepConfig[step as "email" | "verify" | "password"];

  const isButtonDisabled = (values: Record<string, string>) => {
    if (step === "email") return !values.email;
    if (step === "verify") return values.code?.length < OTP_LENGTH;
    if (step === "password") return !values.password || !values.confirmPassword;
    return true;
  };

  const handleContinue = () => {
    sheetRef.close();
    router.dismissAll();
    router.replace("/(public)/signin");
  };

  useEffect(() => {
    if (step === "success") {
      sheetRef.open();
    }
  }, [step]);


  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <AuthLayout>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
        style={styles.container}
      >
        <SuccessSheet
          ref={sheetRef.ref}
          title="Password reset successful"
          description="Your password has been updated. You can now Log in to your account."
          onContinue={handleContinue}
          onClose={handleContinue}
          buttonText="Login"
        />
        <Formik
          validateOnChange={false}
          initialValues={{
            email: user?.email ?? "",
            code: "",
            password: "",
            confirmPassword: "",
          }}
          onSubmit={() => {}}
          validationSchema={config.schema}
        >
          {({ values, errors, dirty }) => {
            const handleStepSubmit = () => {
              if (step === "email") sendOTP(values.email);
              else if (step === "verify")
                verifyOTP({
                  email: values.email,
                  code: values.code,
                });
              else if (step === "password") createPassword(values.password);
            };
            const disabled =
              isButtonDisabled(values) || Object.keys(errors).length > 0;
            return (
              <View style={styles.container}>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  onScrollBeginDrag={Keyboard.dismiss}
                  contentContainerStyle={{
                    paddingBottom: 24,
                    paddingHorizontal: 20,
                  }}
                >
                  <View style={styles.contentContainer}>
                    <View style={styles.animatedContent}>
                      <View style={styles.textContainer}>
                        <CustomText weight="bold" size="lg">
                          {config.title}
                        </CustomText>
                        <CustomText
                          weight="medium"
                          size="sm"
                          style={styles.textDescription}
                        >
                          {config.description}
                        </CustomText>
                      </View>

                      {(step === "email" || step === "verify") && (
                        <View style={styles.formContainer}>
                          <View style={CUSTOM_STYLES.inputs}>
                            {!user?.phoneNumber && (
                              <Input
                                name="email"
                                type="email-address"
                                placeholder="Email Address"
                                ActionButton={
                                  step === "verify" && !isRunning ? (
                                    <Pressable onPress={resetStep}>
                                      <PencilEdit />
                                    </Pressable>
                                  ) : undefined
                                }
                              />
                            )}
                            {step === "verify" && (
                              <Animated.View
                                style={[
                                  styles.animatedContent,
                                  { opacity: fadeAnim },
                                ]}
                              >
                                <OTPInput name="code" length={OTP_LENGTH} />
                              </Animated.View>
                            )}

                            {errorMessage && (
                              <Error error={errorMessage} visible={true} />
                            )}
                          </View>
                          {step === "verify" && (
                            <View style={styles.otpContainer}>
                              <View>
                                {isRunning ? (
                                  <View style={styles.otpTimer}>
                                    <Feather
                                      name="info"
                                      size={16}
                                      color={PALETTE.error}
                                    />
                                    <CustomText size="sm">
                                      OTP Expires in:{" "}
                                      <CustomText weight="bold">
                                        {String(minutes).padStart(2, "0")}:
                                        {String(seconds).padStart(2, "0")}
                                    </CustomText>
                                    </CustomText>
                                  </View>
                                ) : (
                                  <CustomButton
                                    title="Resend OTP"
                                    onPress={() => sendOTP(values.email)}
                                    variant="secondary"
                                    size="sm"
                                    style={styles.otpButton}
                                  />
                                )}
                              </View>
                            </View>
                          )}
                        </View>
                      )}

                      {(step === "password" || step === "success") && (
                        <View style={CUSTOM_STYLES.inputs}>
                          <Input
                            name="password"
                            placeholder="Password"
                            isSecureText
                          />
                          <Input
                            name="confirmPassword"
                            placeholder="Confirm Password"
                            isSecureText
                          />
                        </View>
                      )}
                    </View>

                    <View style={CUSTOM_STYLES.divider} />

                    <View style={styles.verificationTracker}>
                      <ForgotPasswordSteps currentStep={config.trackerStep} />
                    </View>
                  </View>
                </ScrollView>

                <View style={styles.footerContainer}>
                  <CustomButton
                    onPress={handleStepSubmit}
                    variant={disabled ? "secondary" : "primary"}
                    title={step === "password" ? "Create Password" : "Next"}
                    disabled={disabled || isPending}
                    loading={isPending}
                  />
                  <CustomText weight="medium" style={styles.footerText}>
                    Back to{" "}
                    <CustomText
                      handlePress={() => router.back()}
                      weight="semibold"
                      style={styles.footerLink}
                    >
                      Sign in
                    </CustomText>
                  </CustomText>
                </View>
              </View>
            );
          }}
        </Formik>
      </KeyboardAvoidingView>
    </AuthLayout>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  contentContainer: { flex: 1, gap: 20, paddingTop: 38 },
  animatedContent: { gap: 32 },
  textContainer: { gap: 5 },
  textDescription: { opacity: 0.7 },
  formContainer: { gap: 28 },
  verificationTracker: {},
  otpContainer: {},
  otpTimer: {
    backgroundColor: PALETTE.secondary,
    borderRadius: 80,
    paddingHorizontal: 10,
    paddingVertical: 8,
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    gap: 4,
  },
  otpButton: { maxWidth: 128 },
  footerContainer: {
    gap: 8,
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  footerLink: { textDecorationLine: "underline" },
  footerText: { textAlign: "center" },
});

export default ForgotPassword;
