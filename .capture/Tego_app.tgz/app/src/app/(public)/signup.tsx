import PencilEdit from "@/assets/images/app-icons/pencil-edit.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { SignupVerificationSteps } from "@/modules/auth/components";
import { SignupStep, useSignup } from "@/modules/auth/hooks/useSignup";
import { ACCOUNT_TYPE } from "@/modules/auth/types/user.dto";
import {
  createPasswordSchema,
  kycSchema,
  setupProfileSchema,
  setupProviderProfileSchema,
  signupSchema,
  verifyPhoneNumberSchema,
} from "@/modules/auth/utils/validation";
import {
  CustomButton,
  CustomText,
  Error,
  Input,
  OTPInput,
  Select,
  SuccessSheet,
} from "@/shared/components";
import { useBackOrPush } from "@/shared/hooks/useBackOrPush";
import { useModalState } from "@/shared/hooks/useModalState";
import { AuthLayout } from "@/shared/layouts";
import { ScreenShell } from "@/shared/containers";
import { replaceRoute } from "@/shared/utils/routing";
import Feather from "@expo/vector-icons/Feather";
import { Link, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { useEffect, useRef, useState } from "react";
import { Animated, Easing, Pressable, StyleSheet, View } from "react-native";
import { useToastStore } from "@/shared/store/toastStore";

const OTP_LENGTH = 6;

type StepConfig = {
  title: string;
  description: string;
  trackerStep: "email" | "password" | "details" | "kyc";
  schema: any;
};

const importantStep = {
  email: {
    title: "Let's get you started",
    description: "Enter your email address to continue",
    trackerStep: "email" as const,
    schema: signupSchema,
  },
  verify: {
    title: "Verify your email",
    description: "Enter the code sent to your email address",
    trackerStep: "email" as const,
    schema: verifyPhoneNumberSchema,
  },
  success: {
    title: "You're all set 🎉",
    description:
      "Your account has been created successfully. Let's get started.",
    trackerStep: "details" as const,
    schema: setupProfileSchema,
  },
};

const customerStepConfig: StepConfigMap = {
  ...importantStep,
  password: {
    title: "Secure your account",
    description: "Create a secure password you'll remember",
    trackerStep: "password" as const,
    schema: createPasswordSchema,
  },
  details: {
    title: "Set up your profile",
    description: "Add your personal details to get started.",
    trackerStep: "details" as const,
    schema: setupProfileSchema,
  },
};

const providerStepConfig: StepConfigMap = {
  ...importantStep,
  details: {
    title: "Set up your profile",
    description: "Add your personal details to get started.",
    trackerStep: "details" as const,
    schema: setupProviderProfileSchema,
  },
  kyc: {
    title: "Verify Your Identity",
    description: "Your BVN and NIN help us verify your identity securely.",
    trackerStep: "kyc" as const,
    schema: kycSchema,
  },
};

type StepConfigMap = Partial<Record<SignupStep, StepConfig>>;

const Signup = () => {
  const { showToast } = useToastStore();
  const { type } = useLocalSearchParams<{
    type: ACCOUNT_TYPE;
  }>();
  const handleSignIn = useBackOrPush("/(public)/signin", "signin");
  const {
    step,
    sendOTP,
    verifyOTP,
    createPassword,
    completeRegistration,
    completeProviderRegistration,
    completeKYC,
    resetStep,
    isPending,
    errorMessage,
  } = useSignup(type);
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const isFirstRender = useRef(true);

  const sheetRef = useModalState();

  useEffect(() => {
    // Skip animation on first render
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    Animated.sequence([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 150,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 400,
        easing: Easing.in(Easing.ease),
        useNativeDriver: true,
      }),
    ]).start();
  }, [step]);

  const [timeLeft, setTimeLeft] = useState<number>(600);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  useEffect(() => {
    if (step !== "verify") return;

    setTimeLeft(600); // 10 minutes
    setIsRunning(true);
  }, [step]);

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) {
      setIsRunning(false);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  const stepConfig = {
    CUSTOMER: customerStepConfig,
    SERVICE_PROVIDER: providerStepConfig,
  } as const;

  const config = stepConfig[type || "CUSTOMER"]?.[step];

  const isButtonDisabled = (values: Record<string, string>) => {
    if (step === "email") return !values.email;
    if (step === "verify") return values.code?.length < OTP_LENGTH;
    if (step === "password") return !values.password || !values.confirmPassword;
    if (step === "kyc") return !values.nin || !values.bvn;
    if (step === "details") {
      if (type === "CUSTOMER") {
        return (
          !values.email ||
          !values.firstName ||
          !values.lastName ||
          !values.gender
        );
      } else {
        return (
          !values.email ||
          !values.firstName ||
          !values.lastName ||
          !values.password ||
          !values.confirmPassword
        );
      }
    }
    return true;
  };

  const handleSignup = () => {
    if (type === "CUSTOMER") {
      replaceRoute("/(customer)/(tabs)");
    } else {
      replaceRoute("/(service-provider)/(tabs)");
    }

    resetStep();
    sheetRef.close();
  };

  useEffect(() => {
    if (step === "success") {
      sheetRef.open();
    }
  }, [step]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;

  return (
    <AuthLayout>
        <SuccessSheet
          ref={sheetRef.ref}
          title="You're all set 🎉"
          description="Your account has been created successfully. Let's get started."
          onContinue={handleSignup}
          variant="primary"
        />
        <Formik
          validateOnChange={false}
          initialValues={{
            phoneNumber: "",
            code: "",
            password: "",
            confirmPassword: "",
            email: "",
            firstName: "",
            lastName: "",
            gender: "",
            nin: "",
            bvn: "",
          }}
          onSubmit={() => {}} // handled manually per step
          validationSchema={config?.schema}
        >
          {({ values, validateForm }) => {
            const disabled = isButtonDisabled(values);

            const handleSubmit = async () => {
              if (step === "email") sendOTP(values.email);
              else if (step === "verify")
                verifyOTP({
                  email: values.email,
                  code: values.code,
                });
              else if (step === "password") createPassword(values.password);
              else if (step === "details") {
                if (type === "CUSTOMER") {
                  completeRegistration({
                    phoneNumber: values.phoneNumber,
                    firstName: values.firstName,
                    lastName: values.lastName,
                    gender: values.gender as "MALE" | "FEMALE",
                    userType: "CUSTOMER",
                  });
                } else {
                  completeProviderRegistration({
                    phoneNumber: values.phoneNumber,
                    firstName: values.firstName,
                    lastName: values.lastName,
                    userType: "SERVICE_PROVIDER",
                    gender: values.gender as "MALE" | "FEMALE",
                    password: values.password,
                    confirmPassword: values.password,
                  });
                }
              } else if (step === "kyc")
                completeKYC({
                  nin: values.nin,
                  bvn: values.bvn,
                });
            };

            return (
              <ScreenShell
                contentContainerStyle={{
                  paddingBottom: 24,
                  paddingHorizontal: 20,
                }}
                footer={
                  <View style={styles.footerContainer}>
                    <CustomButton
                      onPress={handleSubmit}
                      variant={disabled ? "secondary" : "primary"}
                      title={
                        step === "details"
                          ? "Create Account"
                          : step === "password"
                            ? "Create Password"
                            : step === "email"
                              ? "Send OTP"
                              : "Next"
                      }
                      disabled={disabled || isPending}
                      loading={isPending}
                    />
                    <CustomText weight="medium" style={styles.footerText}>
                      Already have an account?{" "}
                      <CustomText
                        handlePress={handleSignIn}
                        weight="semibold"
                        style={styles.footerLink}
                      >
                        Sign in
                      </CustomText>
                    </CustomText>
                  </View>
                }
              >
                <View style={styles.contentContainer}>
                    <Animated.View
                      style={[styles.animatedContent, { opacity: fadeAnim }]}
                    >
                      <View style={styles.textContainer}>
                        <CustomText weight="bold" size="lg">
                          {config?.title}
                        </CustomText>
                        <CustomText
                          weight="medium"
                          size="sm"
                          style={styles.textDescription}
                        >
                          {config?.description}
                        </CustomText>
                      </View>

                      {(step === "email" || step === "verify") && (
                        <View style={styles.formContainer}>
                          <View style={CUSTOM_STYLES.inputs}>
                            <Input
                              name="email"
                              type="email-address"
                              placeholder="Email Address"
                              ActionButton={
                                step === "verify" ? (
                                  <Pressable onPress={resetStep}>
                                    <PencilEdit />
                                  </Pressable>
                                ) : undefined
                              }
                            />
                            {step === "verify" && (
                              <OTPInput name="code" length={OTP_LENGTH} />
                            )}
                          </View>
                          {step === "verify" && (
                            <View style={styles.otpContainer}>
                              {isRunning ? (
                                <View style={styles.otpTimer}>
                                  <Feather
                                    name="info"
                                    size={16}
                                    color={PALETTE.error}
                                  />
                                  <CustomText size="sm">
                                    OTP Expires in{" "}
                                    <CustomText weight="bold">
                                      {String(minutes).padStart(2, "0")}:
                                      {String(seconds).padStart(2, "0")}
                                    </CustomText>
                                  </CustomText>
                                </View>
                              ) : (
                                <CustomButton
                                  title="Resend OTP"
                                  onPress={() => sendOTP(values.phoneNumber)}
                                  variant="secondary"
                                  size="sm"
                                  style={styles.otpButton}
                                />
                              )}
                            </View>
                          )}
                          {errorMessage && (
                            <View style={{ marginTop: 12 }}>
                              <Error error={errorMessage} visible={true} />
                            </View>
                          )}
                          {step === "email" && (
                            <View style={styles.termsContainer}>
                              <CustomText
                                size="sm"
                                weight="regular"
                                style={styles.termsText}
                              >
                                By continuing, you agree to our{" "}
                                <Link href="/(public)/signin">
                                  <CustomText
                                    weight="semibold"
                                    size="sm"
                                    style={styles.termsText}
                                  >
                                    Terms of Use
                                  </CustomText>{" "}
                                  and{" "}
                                  <CustomText
                                    weight="semibold"
                                    size="sm"
                                    style={styles.termsText}
                                  >
                                    Privacy Policy
                                  </CustomText>
                                </Link>
                                .
                              </CustomText>
                            </View>
                          )}
                        </View>
                      )}

                      {step === "password" && (
                        <View style={styles.formContainer}>
                          <View style={CUSTOM_STYLES.inputs}>
                            <Input
                              name="password"
                              placeholder="Password"
                              isSecureText
                            />
                            <Input
                              name="confirmPassword"
                              placeholder="Confirm Password"
                              isSecureText
                            />
                          </View>
                          {errorMessage && (
                            <View style={{ marginTop: 12 }}>
                              <Error error={errorMessage} visible={true} />
                            </View>
                          )}
                        </View>
                      )}

                      {(step === "details" || step === "success") && (
                        <View style={styles.formContainer}>
                          {type === "CUSTOMER" ? (
                            <View style={CUSTOM_STYLES.inputs}>
                              <Input
                                name="firstName"
                                placeholder="First name"
                              />
                              <Input name="lastName" placeholder="Last name" />
                              <Input
                                name="phoneNumber"
                                placeholder="Phone number"
                                type="number-pad"
                              />
                              <Select
                                name="gender"
                                placeholder="Gender"
                                options={[
                                  { value: "MALE", label: "Male" },
                                  { value: "FEMALE", label: "Female" },
                                ]}
                              />
                              {/* Gender selector goes here */}
                            </View>
                          ) : (
                            <View style={CUSTOM_STYLES.inputs}>
                              <Input
                                name="firstName"
                                placeholder="First name"
                              />
                              <Input name="lastName" placeholder="Last name" />
                              <Input
                                name="phoneNumber"
                                placeholder="Phone number"
                                type="number-pad"
                              />

                              <Select
                                name="gender"
                                placeholder="Gender"
                                options={[
                                  { value: "MALE", label: "Male" },
                                  { value: "FEMALE", label: "Female" },
                                ]}
                              />
                              <Input
                                name="password"
                                placeholder="Password"
                                isSecureText
                              />
                              <Input
                                name="confirmPassword"
                                placeholder="Confirm Password"
                                isSecureText
                              />
                              {/* Gender selector goes here */}
                            </View>
                          )}

                          {errorMessage && (
                            <View style={{ marginTop: 12 }}>
                              <Error error={errorMessage} visible={true} />
                            </View>
                          )}
                        </View>
                      )}

                      {type === "SERVICE_PROVIDER" && step === "kyc" && (
                        <View style={styles.formContainer}>
                          <View style={CUSTOM_STYLES.inputs}>
                            <Input
                              name="nin"
                              placeholder="NIN"
                              type="number-pad"
                            />
                            <Input
                              name="bvn"
                              placeholder="BVN"
                              type="number-pad"
                            />
                          </View>
                        </View>
                      )}
                    </Animated.View>

                    <View style={CUSTOM_STYLES.divider} />

                    <View style={styles.verificationTracker}>
                      <SignupVerificationSteps
                        currentStep={config?.trackerStep || "email"}
                        type={type}
                      />
                    </View>
                  </View>
              </ScreenShell>
            );
          }}
        </Formik>
    </AuthLayout>
  );
};

const styles = StyleSheet.create({
  contentContainer: { flex: 1, gap: 32, paddingTop: 38 },
  animatedContent: { gap: 24 },
  textContainer: { gap: 5 },
  textDescription: { opacity: 0.7 },
  formContainer: {},
  termsContainer: { maxWidth: "75%", marginTop: 16 },
  termsText: { lineHeight: 21 },
  verificationTracker: {},
  otpContainer: { marginTop: 28 },
  otpTimer: {
    backgroundColor: PALETTE.secondary,
    borderRadius: 80,
    paddingHorizontal: 10,
    paddingVertical: 8,
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    gap: 4,
  },
  otpButton: { maxWidth: 128 },
  footerContainer: {
    gap: 8,
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  footerLink: {
    textDecorationLine: "underline",
  },
  footerText: { textAlign: "center", alignItems: "center" },
});

export default Signup;
