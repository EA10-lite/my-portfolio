// app/(customer)/_layout.tsx
import { useAuthGuard } from "@/modules/auth/hooks/useAuthGuard";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useProviderFilterStore } from "@/modules/provider/store/providerFilter";
import { useProviderPrefrenceFilterStore } from "@/modules/provider/store/providerPreferenceFilter";
import { Redirect, Stack, usePathname } from "expo-router";
import { useEffect, useRef } from "react";

export default function ProtectedLayout() {
  useAuthGuard();
  const { clearFilters } = useProviderFilterStore();
  const { clearFilters: clearPreferenceFilter } = useProviderPrefrenceFilterStore();

  const pathname = usePathname();

  useEffect(() => {
      clearFilters();
      clearPreferenceFilter();
  }, [pathname, clearFilters, clearPreferenceFilter]);

  const { isLoggedIn } = useAuthStore();
  if (!isLoggedIn) return <Redirect href="/(public)/signin" />;
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="(tabs)" options={{ gestureEnabled: false }} />
      <Stack.Screen name="booking" />
      <Stack.Screen name="request-job" />
      <Stack.Screen name="categories" />
      <Stack.Screen name="category/[id]" />
      <Stack.Screen name="notifications" />
      <Stack.Screen name="review/[providerId]" />
    </Stack>
  );
}
