import { PALETTE } from "@/constants/colors";
import {
    ProviderCardV2,
    ProviderCardV2Skeleton,
    ProviderPreferenceFilter
} from "@/modules/provider/components";
import { useProviders } from "@/modules/provider/hooks/useProviders";
import { useProviderPrefrenceFilterStore } from "@/modules/provider/store/providerPreferenceFilter";
import { normalizeProviders } from "@/modules/provider/utils/normalizeProvider";
import {
  CustomSearchInput,
  CustomText,
  EmptyMessages,
  GoBack,
} from "@/shared/components";
import { useCollapsibleSearch } from "@/shared/hooks/useCollapseSearch";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useMemo } from "react";
import { Animated, StyleSheet, View } from "react-native";
import { FlatList } from "react-native-gesture-handler";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const CategoryDetails = () => {
  const insets = useSafeAreaInsets();

  const { preference } = useLocalSearchParams<{
    preference: "top_providers" | "near_me"
  }>();

  const { appliedFilters } = useProviderPrefrenceFilterStore();

  const {
    providers,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
    refetch,
  } = useProviders({
    ...appliedFilters,
    preference: [...(appliedFilters.preference ?? []), preference],
  });

  const {
    search,
    setSearch,
    isFocused,
    setIsFocused,
    collapsibleStyle,
    filterStyle,
  } = useCollapsibleSearch({ searchBarHeight: 91 });

  const filteredProviders = useMemo(() => {
    const query = search.toLowerCase().trim();
    const matches = providers?.filter(
      (p) =>
        p.provider.first_name.toLowerCase().includes(query) ||
        p.provider.last_name.toLowerCase().includes(query) ||
        p.service_category.name.toLowerCase().includes(query),
    );

    return normalizeProviders(matches);
  }, [search, providers]);


  const handleBookNow = (id: string) => {
    router.push(`/(customer)/booking/form?category_id=${id}`);
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack />
        <View>
          <CustomText weight="bold" size="lg">
            {
                preference === "near_me"
                ? "Popular Near You"
                : "Top Rated Providers"
            }
          </CustomText>

          {/* 🔥 Collapsible Search */}
          <Animated.View style={collapsibleStyle}>
            <View style={styles.search}>
              <View style={styles.searchBox}>
                <CustomSearchInput
                  value={search}
                  placeholder="Search for service providers"
                  onChange={setSearch}
                  isFocused={isFocused}
                  setIsFocused={setIsFocused}
                />
                <Animated.View style={filterStyle}>
                  <ProviderPreferenceFilter />
                </Animated.View>
              </View>
            </View>
          </Animated.View>
        </View>
      </LinearGradient>

      <FlatList
        data={filteredProviders}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onEndReachedThreshold={0.4}
        refreshing={isLoading}
        onRefresh={refetch}
        onEndReached={() => {
          if (hasNextPage && !isFetchingNextPage) fetchNextPage();
        }}
        renderItem={({ item }) => (
          <ProviderCardV2
            item={item}
            handleBookNow={() => handleBookNow(item.service_category.id)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <ProviderCardV2Skeleton />
              <ProviderCardV2Skeleton />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={{ gap: 20 }}>
              <ProviderCardV2Skeleton />
              <ProviderCardV2Skeleton />
              <ProviderCardV2Skeleton />
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <EmptyMessages
                title="No results found"
                description="We couldn't find any services matching your search."
                isInTabView={false}
              />
            </View>
          )
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  search: {
    gap: 14,
    marginTop: 34,
  },
  scrollContent: {
    flexGrow: 1,
    backgroundColor: PALETTE.white,
    paddingTop: 24,
    paddingHorizontal: 20,
  },
});

export default CategoryDetails;
