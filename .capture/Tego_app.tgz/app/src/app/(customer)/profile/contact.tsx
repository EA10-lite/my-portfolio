import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Arrow, CustomText, SuccessSheet } from "@/shared/components";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import CopyIcon from "@/assets/images/app-icons/copy.svg";
import MessageIcon from "@/assets/images/app-icons/message.svg";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { Message } from "@/modules/message/services/message.service";
import { ContactSupport, ProfileHeader } from "@/modules/profile/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import * as Clipboard from "expo-clipboard";
import { useSupport } from "@/modules/message/hooks/useSupport";
import { DeviceCardSkeleton } from "@/modules/device-management/components";
import { useInitiateSupportMessage } from "@/modules/message/hooks/useInitiateSupport";

const Contact = () => {
  const { showToast } = useToastStore();
  const insets = useSafeAreaInsets();
  const messageModalRef = useModalState();
  const successModalRef = useModalState();

  const { sendSupportMessage, isSubmitting } = useInitiateSupportMessage();
  const { support, isLoading } = useSupport();

  const handleSubmit = (data: Message) => {
    sendSupportMessage(data, {
      onSuccess: () => {
        successModalRef.open();
      },
    });
  };

  const copyToClipboard = async (text: string) => {
    try {
      await Clipboard.setStringAsync(text);
      showToast("Copied", "Support contact copied");
    } catch {
      showToast("Error", "Failed to copy support contact");
    }
  };
  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={successModalRef.ref}
        title="Message sent successfully"
        description="Thanks for contacting Tego Support. We'll review your message and respond as soon as possible."
        onContinue={successModalRef.close}
        Icon={<MessageIcon />}
      />

      <ContactSupport
        ref={messageModalRef.ref}
        onPress={handleSubmit}
        closeModal={messageModalRef.close}
        loading={isSubmitting}
        receiver_id={support?.id ?? ""}
      />
      <ProfileHeader title="Contact Support" />


      {isLoading ? (
        <View style={styles.body}>
          {[1, 2].map((i) => (
            <DeviceCardSkeleton key={i} />
          ))}
        </View>
      ) : support && (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.body,
            { paddingBottom: insets.bottom + TAB_BAR_HEIGHT },
          ]}
        >
          <MenuItem
            title="Call Support"
            subtitle="+234 800 000 0000"
            handlePress={() => copyToClipboard("+234 800 000 0000")}
            Icon={<CopyIcon color={PALETTE.primary} />}
          />
          <MenuItem
            title="Email Us"
            subtitle="Get instant help from our support team"
            handlePress={messageModalRef.open}
            Icon={<Arrow />}
          />
        </ScrollView>
      )}

    </View>
  );
};

const MenuItem = ({
  title,
  subtitle,
  Icon,
  handlePress,
}: {
  title: string;
  subtitle: string;
  Icon: React.ReactNode;
  handlePress: () => void;
}) => {
  return (
    <Pressable onPress={handlePress}>
      <View style={styles.menu}>
        <View style={styles.links}>
          <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
            <View style={{ gap: 8 }}>
              <CustomText weight="semibold" style={styles.link}>
                {title}
              </CustomText>
              <CustomText weight="medium" size="xs" style={{ opacity: 0.6 }}>
                {subtitle}
              </CustomText>
            </View>

            {Icon}
          </View>
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
    gap: 16,
  },
  edit: {
    width: 20,
    height: 20,
    borderRadius: 40,
    position: "absolute",
    backgroundColor: PALETTE.white,
    left: 24,
    top: 26,
  },
  menu: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  menuItem: {
    gap: 16,
  },
  label: {
    textTransform: "uppercase",
    letterSpacing: -0.24,
    opacity: 0.5,
  },
  links: {},
  linkItem: {
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  link: {
    fontSize: 13,
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
    marginVertical: 16,
  },
});
export default Contact;
