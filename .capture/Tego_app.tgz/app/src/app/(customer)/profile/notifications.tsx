import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  CustomButton,
  CustomText,
  SuccessSheet,
  Switch,
} from "@/shared/components";
import {
  Keyboard,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuthStore } from "@/modules/auth/stores/authStore";
import { ProfileHeader } from "@/modules/profile/components";
import { useNotificationSettings } from "@/modules/profile/hooks/useNotifications";
import { NotificationSettings } from "@/modules/profile/types/profile.dto";
import { Formik } from "formik";
import { useModalState } from "@/shared/hooks/useModalState";

const Notifications = () => {
  const { user } = useAuthStore();
  const insets = useSafeAreaInsets();
  const { notification, updateNotifications, isUpdating, errorMessage } =
    useNotificationSettings();

  const sheetRef = useModalState();

  const handleSubmit = (values: NotificationSettings) => {
    updateNotifications(values, {
      onSuccess: (data) => {
        sheetRef.open();
      },
    });
  };
  return (
    <View style={styles.container}>
      <ProfileHeader title="Notifications" />

      <View style={CUSTOM_STYLES.flex}>
        <View style={styles.container}>
          <Formik<NotificationSettings>
            initialValues={{
              booking_updates:
                user?.user_details?.notification_settings.booking_updates ??
                notification?.booking_updates ??
                true,
              messages:
                user?.user_details?.notification_settings?.messages ??
                notification?.messages ??
                true,
              promotions_n_offers:
                user?.user_details?.notification_settings
                  ?.promotions_n_offers ??
                notification?.promotions_n_offers ??
                true,
            }}
            enableReinitialize
            onSubmit={handleSubmit}
          >
            {({ handleSubmit, isSubmitting, dirty }) => (
              <>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  contentContainerStyle={[
                    styles.content,
                    {
                      paddingBottom: insets.bottom,
                    }
                  ]}
                  onScrollBeginDrag={Keyboard.dismiss}
                >
                  <View style={{ gap: 6 }}>
                    <MenuItem
                      title="Booking Updates"
                      subtitle="Get alerts for booking status changes"
                      name="booking_updates"
                    />
                    <MenuItem
                      title="Messages"
                      subtitle="Receive new message notifications"
                      name="messages"
                    />
                    <MenuItem
                      title="Promotions & Offers"
                      subtitle="Discounts and special deals"
                      name="promotions_n_offers"
                    />
                  </View>
                </ScrollView>
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Update"
                    variant="primary"
                    disabled={!dirty}
                    loading={isUpdating}
                    onPress={handleSubmit}
                  />
                </View>
              </>
            )}
          </Formik>
        </View>
      </View>

      <SuccessSheet
        ref={sheetRef.ref}
        title="Updated Successfully"
        description="Your notification preferences has been updated successfully."
        onContinue={sheetRef.close}
        onClose={sheetRef.close}
      />
    </View>
  );
};

const MenuItem = ({
  title,
  subtitle,
  name,
}: {
  title: string;
  subtitle: string;
  name: string;
}) => {
  return (
    <View style={styles.menu}>
      <View style={styles.links}>
        <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
          <View style={{ gap: 8 }}>
            <CustomText weight="medium" style={styles.link}>
              {title}
            </CustomText>
            <CustomText weight="medium" size="xs" style={{ opacity: 0.6 }}>
              {subtitle}
            </CustomText>
          </View>

          <Switch name={name} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  menu: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  menuItem: {
    gap: 16,
  },
  label: {
    textTransform: "uppercase",
    letterSpacing: -0.24,
    opacity: 0.5,
  },
  links: {},
  linkItem: {
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  link: {
    fontSize: 13,
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
    marginVertical: 16,
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});
export default Notifications;
