import { PALETTE } from "@/constants/colors";
import { ProfileHeader, Section } from "@/modules/profile/components";
import { CustomText } from "@/shared/components";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const PrivacyPolicy = () => {
  const { bottom } = useSafeAreaInsets();
  return (
    <View style={styles.container}>
      <ProfileHeader title="Privacy Policy" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          {
            paddingBottom: bottom,
          }
        ]}
      >
        <CustomText
          weight="medium"
          size="xs"
          style={{ opacity: 0.6, marginVertical: 12 }}
        >
          Last Update: 10th May, 2026
        </CustomText>
        <View style={styles.sections}>
          <Section
            title="How Tego collects, uses, and protects your information"
            subtitle="Your Privacy Matters"
            description="Tego is committed to protecting your personal information and providing a safe platform experience."
          />
          <Section
            title="Information We Collect"
            list={[
              "Name and contact details",
              "Saved addresses",
              "Booking activity",
              "Payment information",
            ]}
          />
          <Section
            title="Location Access"
            description="Tego may use your location to improve provider matching and booking accuracy."
          />
          <Section
            title="Payment & Security"
            description="Transactions are processed securely through trusted payment providers."
          />
          <Section
            title="Your Rights"
            list={[
              "Update profile information",
              "Manage notifications",
              "Request account deactivation",
            ]}
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  sections: {
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
  },
});
export default PrivacyPolicy;
