import { PALETTE } from "@/constants/colors";
import { ProfileHeader } from "@/modules/profile/components";
import { Accordion } from "@/shared/components";
import { useState } from "react";
import {
  ScrollView,
  StyleSheet,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface FAQ {
  question: string;
  answer: string;
}
const faqs: FAQ[] = [
  {
    question: "How do i book a service?",
    answer: "You can pay securely through your selected payment method.",
  },
  {
    question: "How do i deactivate my account?",
    answer:
      "You can deactivate your account under Account Management in Profile settings.",
  },
  {
    question: "How do I cancel a booking?",
    answer: "You can pay securely through your selected payment method.",
  },
  {
    question: "Are providers verified?",
    answer:
      "You can deactivate your account under Account Management in Profile settings.",
  },
  {
    question: "Can I report a provider?",
    answer: "You can pay securely through your selected payment method.",
  },
  {
    question: "What do i do if provider doesn't show up?",
    answer:
      "You can deactivate your account under Account Management in Profile settings.",
  },
];

const FAQs = () => {
  const { bottom } = useSafeAreaInsets();

  // null = nothing is open
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const handleToggle = (index: number) => {
    setOpenIndex((currentIndex) =>
      currentIndex === index ? null : index,
    );
  };
  return (
    <View style={styles.container}>
      <ProfileHeader title="FAQs" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          {
            paddingBottom: bottom,
          }
        ]}
      >
        {faqs.map((faq, index) => (
          <Accordion
            key={index}
            title={faq.question}
            description={faq.answer}
            isOpen={openIndex === index}
            onToggle={() => handleToggle(index)}
          />
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 20,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
});
export default FAQs;
