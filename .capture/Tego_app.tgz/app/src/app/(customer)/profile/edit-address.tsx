import LocationOutlineIcon from "@/assets/images/app-icons/location-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { ProfileHeader } from "@/modules/profile/components";
import { useProfileActions } from "@/modules/profile/hooks/useProfileActions";
import { UserAddress } from "@/modules/profile/types/profile.dto";
import {
  CustomButton,
  Input,
  Select,
  SuccessSheet,
} from "@/shared/components";
import { useDeviceInfo } from "@/shared/hooks/useLocation";
import { useModalState } from "@/shared/hooks/useModalState";
import { router } from "expo-router";
import { Formik } from "formik";
import { useMemo, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import NaijaStates from "naija-state-local-government";
import { addressSchema } from "@/modules/profile/utils/validation";
import { useProfile } from "@/modules/profile/hooks/useProfile";
import { useAddress } from "@/modules/profile/hooks/useAddress";

const EditAddress = () => {
  const insets = useSafeAreaInsets();
  const modalRef = useModalState();

  const { address } = useAddress();
  const { updateUserAddress, isUpdating } = useProfileActions();
  const { location } = useDeviceInfo();
  const isButtonDisabled = (values: UserAddress) => {
    return !values.street_name || !values.city || !values.address || !values.state;
  };

  const handleSubmit = (address: UserAddress) => {
    updateUserAddress(address, {
      onSuccess: () => {
        modalRef.open();
      }
    });
  };

  const handleContinue = () => {
    modalRef.close();
    router.back();
  }

  const [selectedState, setSelectedState] = useState<string>(
    address?.state || location.state || ""
  );
  const stateOptions = useMemo(
    () =>
      (NaijaStates.states() as string[]).map((s) => ({
        label: s,
        value: s,
      })),
    [],
  );

  const lgaOptions = useMemo(() => {
    if (!selectedState) return [];
    try {
      const result = NaijaStates.lgas(selectedState);
      return (result.lgas as string[]).map((lga) => ({
        label: lga,
        value: lga,
      }));
    } catch {
      return [];
    }
  }, [selectedState]);

  const initialAddress = useMemo(
    () => ({
      state:
        address?.state ||
        location.state ||
        "",

      country:
        address?.country ||
        location.country ||
        "Nigeria",

      address:
        address?.address ||
        location.address ||
        "",
    }),
    [address, location],
  );

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Address updated"
        description="Your saved address has been updated and is ready for future bookings."
        onContinue={handleContinue}
        Icon={<LocationOutlineIcon color={PALETTE.primary} />}
        maxWidth={300}
      />
      <ProfileHeader title="Edit Address" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik
            validateOnChange={false}
            initialValues={{
              city: address?.city || "",
              street_name: address?.street_name || "",
              nearby_landmark: address?.nearby_landmark || "",
              longitude: address?.longitude || location.longitude || 0,
              latitude: address?.latitude || location.latitude || 0,
              ...initialAddress,
            }}
            onSubmit={handleSubmit}
            validationSchema={addressSchema}
            enableReinitialize
          >
            {({ handleSubmit, values, setFieldValue }) => {
              const disabled = isButtonDisabled(values);
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={[styles.content]}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <Input
                          name="address"
                          placeholder="Address"
                          label="Address"
                        />
                        <Input name="street_name" placeholder="Street Name" />
                        <Input
                          name="nearby_landmark"
                          placeholder="Enter a nearby landmark"
                        />
                        <Select
                          name="state"
                          placeholder="State"
                          options={stateOptions}
                          onChange={(value) => {
                            setSelectedState(value);
                            setFieldValue("state", value);
                          }}
                        />
                        <Select
                          name="city"
                          placeholder="city"
                          options={lgaOptions}
                          disabled={!values["state"]}
                        />
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Save"
                      variant="primary"
                      disabled={disabled}
                      loading={isUpdating}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },

  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});

export default EditAddress;
