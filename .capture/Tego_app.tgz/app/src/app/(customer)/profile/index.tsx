import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { ProfileHeader } from "@/modules/profile/components";
import { useProfileActions } from "@/modules/profile/hooks/useProfileActions";
import { UserProfile } from "@/modules/profile/types/profile.dto";
import { personalInfoValidation } from "@/modules/service-provider/utils/profile.validation";
import {
  CustomButton,
  CustomText,
  EditableInput,
  SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { Formik } from "formik";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Profile = () => {
  const { user } = useAuthStore();
  const { update, isUpdating, errorMessage } = useProfileActions();
  const insets = useSafeAreaInsets();
  const modalRef = useModalState();
  const openSuccessModal = () => modalRef.open();
  const closeSuccessModal = () => modalRef.close();

  const handleSubmit = (values: UserProfile) => {
    update(values, {
      onSuccess: (data) => {
        openSuccessModal();
      },
    });
  };

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Updated Successfully"
        description="Your profile information has been updated successfully."
        onContinue={closeSuccessModal}
        buttonText="Done"
        maxWidth={300}
      />
      <ProfileHeader title="My Profile" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik<UserProfile>
            validateOnChange={false}
            initialValues={{
              first_name: user?.firstName ?? "",
              last_name: user?.lastName ?? "",
              phone_number: user?.phoneNumber ?? "",
              email: user?.email ?? "",
            }}
            onSubmit={handleSubmit}
            validationSchema={personalInfoValidation}
          >
            {({ dirty, handleSubmit }) => {
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={[styles.content]}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <EditableInput
                          label="First Name"
                          name="first_name"
                          isEditable={true}
                          disabled={true}
                        />
                        <EditableInput
                          label="Last Name"
                          name="last_name"
                          isEditable={true}
                          disabled={true}
                        />
                        <EditableInput
                          label="Phone Number"
                          name="phone_number"
                          isEditable={true}
                          disabled={true}
                        />
                        <EditableInput
                          label="Email Address"
                          name="email"
                          isEditable={true}
                        />
                        {errorMessage && (
                          <CustomText
                            size="xs"
                            style={{ color: PALETTE.error }}
                          >
                            {errorMessage}
                          </CustomText>
                        )}
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Update"
                      variant="primary"
                      disabled={!dirty}
                      onPress={handleSubmit}
                      loading={isUpdating}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    marginTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});

export default Profile;
