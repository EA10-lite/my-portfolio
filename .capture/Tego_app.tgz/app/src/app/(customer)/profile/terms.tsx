import { PALETTE } from "@/constants/colors";
import { ProfileHeader, Section } from "@/modules/profile/components";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const TermsAndConditions = () => {
  const { bottom } = useSafeAreaInsets();
  return (
    <View style={styles.container}>
      <ProfileHeader title="Terms and Conditions" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          {
            paddingBottom: bottom,
          }
        ]}
      >
        <View style={styles.sections}>
          <Section
            title="Welcome to Tego"
            description="By using Tego, you agree to follow the terms outlined below. These terms help ensure a safe and reliable experience for both users and service providers."
          />
          <Section
            title="Using Tego"
            list={[
              "Users may browse, book, and communicate with verified service providers through the Tego platform.",
              "Users must provide accurate information when creating bookings and accounts.",
            ]}
          />
          <Section
            title="Booking & Payments"
            list={[
              "Payments made through Tego are processed securely.",
              "Users are responsible for reviewing service details before confirming a booking.",
              "Cancellation policies may apply depending on the provider and service type.",
            ]}
          />
          <Section
            title="Provider Responsibilities"
            list={[
              "Service providers are responsible for delivering services professionally and on time.",
              "Tego may suspend providers who violate platform policies or receive repeated complaints.",
            ]}
          />
          <Section
            title="User Conduct"
            description="Users Must:"
            list={[
              "Treat providers respectfully",
              "Avoid fraudulent activity",
              "Use the platform responsibly",
              "Abusive behavior or misuse of the platform may result in account restrictions.",
              "Tego may suspend providers who violate platform policies or receive repeated complaints.",
            ]}
          />
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  sections: {
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
  },
});
export default TermsAndConditions;
