import { PALETTE } from "@/constants/colors";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import {
  Device,
  DeviceCardSkeleton,
} from "@/modules/device-management/components";
import { ProfileHeader } from "@/modules/profile/components";
import { useDevices } from "@/modules/profile/hooks/useDevices";
import { ScrollView, StyleSheet, View } from "react-native";

const DeviceManagement = () => {
  const { logout } = useAuthStore();
  const { devices, isLoading, remove, isRemoving } = useDevices();

  return (
    <View style={styles.container}>
      <ProfileHeader title="Device Management" />


      {isLoading ? (
        <View style={styles.body}>
          {[1, 2].map((i) => (
            <DeviceCardSkeleton key={i} />
          ))}
        </View>
      ) : devices && (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.body}
        >
          { devices && devices?.length > 0 &&
            devices?.map((device, index) => (
              <Device
                key={index}
                device={device}
                logout={logout}
                deleteDevice={remove}
                isDeleting={isRemoving}
              />
            ))}
        </ScrollView>
      )}

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 16,
    paddingHorizontal: 20,
  },
});
export default DeviceManagement;
