import PasswordIcon from "@/assets/images/app-icons/password.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProfileHeader } from "@/modules/profile/components";
import { useResetPassword } from "@/modules/profile/hooks/useChangePassword";
import { changePasswordValidationSchema } from "@/modules/profile/utils/validation";
import {
  CustomButton,
  CustomText,
  Input,
  SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { router } from "expo-router";
import { Formik } from "formik";
import { useRef } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export interface UpdatePassword {
  old_password: string;
  new_password: string;
  confirm_password: string;
}

const ChangePassword = () => {
  const insets = useSafeAreaInsets();
  const { reset, isResetting, errorMessage } = useResetPassword();

  const modalRef = useModalState();
  const openSuccessModal = () => modalRef.open();
  const closeSuccessModal = () => {
    modalRef.close();
    router.back();
  };

  const handleSubmit = (values: UpdatePassword) => {
    reset(values, {
      onSuccess: (data) => {
        openSuccessModal();
      },
    });
  };

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={modalRef.ref}
        title="Password updated"
        description="Your password has been changed successfully and your account is now secure."
        onContinue={closeSuccessModal}
        Icon={<PasswordIcon color={PALETTE.primary} />}
        maxWidth={300}
      />
      <ProfileHeader title="Change Password" />

      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik<UpdatePassword>
            initialValues={{
              old_password: "",
              new_password: "",
              confirm_password: "",
            }}
            onSubmit={handleSubmit}
            validationSchema={changePasswordValidationSchema}
          >
            {({ values, handleSubmit }) => {
              const disabled =
                !values.old_password ||
                !values.new_password ||
                !values.confirm_password;

              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    contentContainerStyle={styles.content}
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={CUSTOM_STYLES.flex}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <Input
                          name="old_password"
                          placeholder="Current Password"
                          isSecureText
                        />
                        <Input
                          name="new_password"
                          placeholder="New Password"
                          isSecureText
                        />
                        <Input
                          name="confirm_password"
                          placeholder="Confirm New Password"
                          isSecureText
                        />
                        {errorMessage && (
                          <CustomText
                            size="xs"
                            style={{ color: PALETTE.error }}
                          >
                            {errorMessage}
                          </CustomText>
                        )}
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Update Password"
                      variant="primary"
                      disabled={disabled}
                      onPress={handleSubmit}
                      loading={isResetting}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});

export default ChangePassword;
