import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  CustomButton,
  CustomText,
  SuccessSheet,
  Switch,
} from "@/shared/components";
import {
  Keyboard,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuthStore } from "@/modules/auth/stores/authStore";
import { ProfileHeader } from "@/modules/profile/components";
import { useNotificationSettings } from "@/modules/profile/hooks/useNotifications";
import { BookingSettings } from "@/modules/profile/types/profile.dto";
import { useModalState } from "@/shared/hooks/useModalState";
import { router } from "expo-router";
import { Formik } from "formik";
interface Link {
  label: string;
  name: string;
}

const Bookings = () => {
  const { user } = useAuthStore();
  const insets = useSafeAreaInsets();
  const { bookings, updateBookingSettings, isUpdating, errorMessage } =
    useNotificationSettings();

  const sheetRef = useModalState();

  const handleSubmit = (values: BookingSettings) => {
    updateBookingSettings(values, {
      onSuccess: (data) => {
        sheetRef.open();
      },
    });
  };

  const handleContinue = () => {
    sheetRef.close();
    router.back();
  }
  return (
    <View style={styles.container}>
      <ProfileHeader title="Bookings" />

      <View style={CUSTOM_STYLES.flex}>
        <View style={styles.container}>
          <Formik<BookingSettings>
            initialValues={{
              new_booking_request:
                bookings?.new_booking_request ??
                user?.user_details?.bookings_settings?.new_booking_request ?? // 👈 bookings_settings
                true,
              booking_confirmations:
                bookings?.booking_confirmations ??
                user?.user_details?.bookings_settings?.booking_confirmations ??
                true,
              booking_reminders:
                bookings?.booking_reminders ??
                user?.user_details?.bookings_settings?.booking_reminders ??
                true,
              nearby_services:
                bookings?.nearby_services ??
                user?.user_details?.bookings_settings?.nearby_services ??
                true,
              new_categories:
                bookings?.new_categories ??
                user?.user_details?.bookings_settings?.new_categories ??
                true,
              service_started:
                bookings?.service_started ??
                user?.user_details?.bookings_settings?.service_started ??
                true,
              booking_completed:
                bookings?.booking_completed ??
                user?.user_details?.bookings_settings?.booking_completed ??
                true,
            }}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ handleSubmit, dirty }) => (
              <>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  contentContainerStyle={[
                    styles.content,
                    {
                      paddingBottom: insets.bottom,
                    }
                  ]}
                  onScrollBeginDrag={Keyboard.dismiss}
                >
                  <View style={{ gap: 24 }}>
                    <MenuItem
                      title="Request & Offers"
                      links={[
                        {
                          label: "New Booking Requests",
                          name: "new_booking_request",
                        },
                        {
                          label: "Booking Confirmations",
                          name: "booking_confirmations",
                        },
                        {
                          label: "Booking Reminders",
                          name: "booking_reminders",
                        },
                      ]}
                    />
                    <MenuItem
                      title="JOB POSTS & SERVICE ALERTS"
                      links={[
                        { label: "Near by Services", name: "nearby_services" },
                        { label: "New Categories", name: "new_categories" },
                      ]}
                    />
                    <MenuItem
                      title="Active Jobs"
                      links={[
                        { label: "Service Started", name: "service_started" },
                        {
                          label: "Booking Completed",
                          name: "booking_completed",
                        },
                      ]}
                    />
                  </View>
                </ScrollView>
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Update"
                    variant="primary"
                    disabled={!dirty}
                    loading={isUpdating}
                    onPress={handleSubmit}
                  />
                </View>
              </>
            )}
          </Formik>
        </View>
      </View>

      <SuccessSheet
        ref={sheetRef.ref}
        title="Updated Successfully"
        description="Your notification preferences has been updated successfully."
        onContinue={sheetRef.close}
        onClose={handleContinue}
      />
    </View>
  );
};

const MenuItem = ({ title, links }: { title: string; links: Link[] }) => {
  return (
    <View style={styles.menu}>
      <View style={styles.menuItem}>
        <CustomText style={styles.label} size="xs" weight="semibold">
          {title}
        </CustomText>
        <View style={styles.links}>
          {links.map((link, index) => (
            <View key={index}>
              <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
                <CustomText weight="medium" style={styles.link}>
                  {link.label}
                </CustomText>

                <Switch name={link.name} />
              </View>
              {index + 1 !== links.length && <View style={styles.divider} />}
            </View>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  menu: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  menuItem: {
    gap: 16,
  },
  label: {
    textTransform: "uppercase",
    letterSpacing: -0.24,
    opacity: 0.5,
  },
  links: {},
  linkItem: {
    justifyContent: "space-between",
  },
  link: {
    fontSize: 13,
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
    marginVertical: 16,
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
  },
});
export default Bookings;
