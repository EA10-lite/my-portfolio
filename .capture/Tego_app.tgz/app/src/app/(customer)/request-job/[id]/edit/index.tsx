import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY } from "@/constants/values";
import { useCategories } from "@/modules/categories/hooks/useCategories";
import { BudgetSelector } from "@/modules/job/components";
import { useJobRequestActions } from "@/modules/request-job/hooks/useJobRequestActions";
import { useJobRequestDetails } from "@/modules/request-job/hooks/useJobRequestDetails";
import { CreateJobRequest } from "@/modules/request-job/utils/type";
import {
  AddressInput,
  CustomButton,
  CustomText,
  DatePicker,
  GoBack,
  ImagePicker,
  Input,
  Select,
  SuccessSheet,
  Textbox,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { useRef } from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const RequestJob = () => {
  const { showToast } = useToastStore();

  const { id } = useLocalSearchParams();

  const { requestDetails, isLoading } = useJobRequestDetails(id.toString());
  const { update, isSubmitting } = useJobRequestActions();
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<any>(null);

  const { categories } = useCategories();
  const sheetRef = useModalState();

  const handleGoBack = () => {
    router.back();
  };

  const handleSubmit = (values: CreateJobRequest) => {
    if (!values.title?.trim()) {
      showToast("Action failed", "Please enter a title");
      return;
    }

    if (!values.description?.trim()) {
      showToast("Action failed", "Please enter a request description");
      return;
    }

    if (!values.date) {
      showToast("Action failed", "Please select a date");
      return;
    }

    if (!values.service_category_id?.trim()) {
      showToast("Action failed", "Please select service category");
      return;
    }

    if (!values.address?.trim()) {
      showToast("Action failed", "Please enter an address");
      return;
    }

    if (!values?.state?.trim()) {
      showToast("Action failed", "Please select a state");
      return;
    }

    if (!values?.country?.trim()) {
      showToast("Action failed", "Please select a country");
      return;
    }

    if (!values.urgency?.trim()) {
      showToast("Action failed", "Please select an urgency level");
      return;
    }

    if (!values.start_price || !values.end_price) {
      showToast("Action failed", "Please enter budget for this request");
      return;
    }

    update(
      {
        request_id: id.toString(),
        data: values,
      },
      {
        onSuccess: (data) => {
          sheetRef.open();
        },
      },
    );
  };

  const handleContinue = () => {
    sheetRef.close();
    router.back();
  };

  return (
    <View style={styles.container}>
      <SuccessSheet
        ref={sheetRef.ref}
        title="Request sent 🎉"
        description="Providers will review your request and send offers shortly."
        buttonText="View Request"
        variant="primary"
        onContinue={handleContinue}
        showConfetti={true}
        showClose={false}
      />

      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={handleGoBack} />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Edit Request Job
          </CustomText>
          <CustomText weight="bold" size="lg">
            {requestDetails?.title}
          </CustomText>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <Formik
          validateOnChange={false}
          enableReinitialize
          initialValues={{
            title: requestDetails?.title || "",
            description: requestDetails?.description || "",
            date: requestDetails?.date || "",
            service_category_id: requestDetails?.service_category_id || "",
            is_budget_negotiable: requestDetails?.is_budget_negotiable || false,
            start_price: requestDetails?.start_price || 0,
            end_price: requestDetails?.end_price || 0,
            images: requestDetails?.images || [],
            address: requestDetails?.address || "",
            state: requestDetails?.state || "",
            country: requestDetails?.country || "",
            area: requestDetails?.area || "",
            urgency: requestDetails?.urgency || "",
          }}
          onSubmit={handleSubmit}
          validateOnBlur
        >
          {({ handleSubmit, values }) => (
            <ScreenShell
              scrollRef={scrollRef}
              extraScrollHeight={30}
              extraHeight={100}
              contentContainerStyle={styles.content}
              footer={
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Update"
                    variant="primary"
                    onPress={handleSubmit}
                    loading={isSubmitting || isLoading}
                  />
                </View>
              }
            >
              <View style={[CUSTOM_STYLES.flex, styles.formContainer]}>
                <View style={[CUSTOM_STYLES.flex, styles.form]}>
                  <Input
                    name="title"
                    placeholder="Title"
                    disabled={isSubmitting || isLoading}
                  />
                  <Select
                    name="service_category_id"
                    placeholder="Category"
                    options={
                      categories?.map((category) => ({
                        label: category.name,
                        value: category.id,
                      })) ?? []
                    }
                    disabled={isSubmitting || isLoading}
                  />
                  <DatePicker
                    value={values["date"]}
                    name="date"
                    placeholder="Select Date"
                    disabled={isSubmitting || isLoading}
                  />
                  <Textbox
                    name="description"
                    placeholder={"Describe the issue"}
                    disabled={isSubmitting || isLoading}
                  />
                  <Select
                    name="urgency"
                    placeholder="Urgency"
                    options={URGENCY}
                    disabled={isSubmitting || isLoading}
                  />

                  <ImagePicker name="images" label="Upload Image" />

                  <AddressInput
                    name="address"
                    isEditable={true || !isSubmitting}
                    address={values.address}
                    state={values.state}
                    nested={false}
                  />

                  <BudgetSelector
                    scrollRef={scrollRef}
                    disabled={isSubmitting || isLoading}
                    isOpenToOffers
                    isOptional
                  />
                </View>
              </View>
            </ScreenShell>
          )}
        </Formik>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  formContainer: { paddingBottom: 80 },
  form: { gap: 15 },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 48,
  },
});
export default RequestJob;
