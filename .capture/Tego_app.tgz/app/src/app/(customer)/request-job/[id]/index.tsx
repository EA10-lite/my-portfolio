import LocationIcon from "@/assets/images/app-icons/location.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CancelRequest, RequestJobSkeleton } from "@/modules/job/components";
import { Activity, ComparedOffers, Offers, Overview } from "@/modules/job/tabs";
import { RequestDetailsSkeleton } from "@/modules/request-job/components";
import { useJobRequestActions } from "@/modules/request-job/hooks/useJobRequestActions";
import { useJobRequestDetails } from "@/modules/request-job/hooks/useJobRequestDetails";
import {
  CustomButton,
  CustomText,
  GoBack,
  NotFound
} from "@/shared/components";
import { CustomTabs } from "@/shared/containers";
import { useModalState } from "@/shared/hooks/useModalState";
import { getStatusColor } from "@/shared/utils/colors";
import { hexToRgba } from "@/shared/utils/converter";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useMemo, useRef, useState } from "react";
import {
  Animated,
  Pressable,
  StyleSheet,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type TAB = "overview" | "activity" | "offers" | "compare";

const RequestJobModal = () => {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams();

  const { requestDetails, isLoading } = useJobRequestDetails(id.toString());
  const { cancel, isSubmitting } = useJobRequestActions();
  const sheetRef = useModalState();
  const requestCancelledModalRef = useModalState();
  const openRequestCancelledModal = requestCancelledModalRef.open;
  const closeRequestCancelledModal = requestCancelledModalRef.close;

  const handleCancelRequest = () => {
    cancel(id.toString(), {
      onSuccess: () => {
        sheetRef.close();
        openRequestCancelledModal();
      },
    });
  };

  const createNewRequest = () => {
    closeRequestCancelledModal();
    closeRequestCancelledModal();
    router.dismissAll();
    router.replace("/(customer)/request-job");
  };

  const goToHome = () => {
    closeRequestCancelledModal();
    router.dismissAll();
    router.replace("/(customer)/(tabs)");
  };

  const [activeTab, setActiveTab] = useState<TAB>("overview");
  const ACTIVE_TAB = [
    { label: "Overview", value: "overview", count: 0 },
    { label: "Activity", value: "activity", count: 0 },
    {
      label: "Offers",
      value: "offers",
      count: requestDetails?.offers.length ?? 0,
    },
  ];

  const [filterTab, setFilterTab] = useState("all");
  const FILTER_TAB = [
    { label: "All", value: "all" },
    { label: "Best Value", value: "best_value" },
    { label: "Lowest Price", value: "lowest_price" },
    { label: "Top Rated", value: "top_rated" },
  ];

  const scrollY = useRef(new Animated.Value(0)).current;

  const handleClose = () => {
    router.back();
  };

  const filteredOffers = useMemo(() => {
    if (activeTab === "compare") {
      const offers = requestDetails?.offers ?? [];

      if (filterTab === "all") {
        return offers;
      }

      if (filterTab === "lowest_price") {
        return [...offers].sort((a, b) => a.offer.price - b.offer.price);
      }

      if (filterTab === "top_rated") {
        return [...offers].sort(
          (a, b) =>
            (b.sender.average_rating ?? 0) - (a.sender.average_rating ?? 0),
        );
      }

      if (filterTab === "best_value") {
        return [...offers].sort((a, b) => {
          const ratingA = a.sender.average_rating ?? 0;
          const ratingB = b.sender.average_rating ?? 0;

          // Higher rating + lower price = better value
          const valueA = ratingA / Math.max(a.offer.price, 1);
          const valueB = ratingB / Math.max(b.offer.price, 1);

          return valueB - valueA;
        });
      }

      return offers;
    }
  }, [filterTab, requestDetails?.offers, activeTab]);

  const status = requestDetails?.status.toLowerCase();

  const handleTabChange = (tab: string) => {
    if (activeTab === "compare") return setFilterTab(tab);
    setActiveTab(tab as TAB);
  };

  if (isLoading) return <RequestDetailsSkeleton />;
  if (!requestDetails) return <NotFound />;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        {activeTab === "compare" ? (
          <View style={[styles.back]}>
            <GoBack handleGoBack={() => setActiveTab("offers")} />
          </View>
        ) : (
          <Pressable style={styles.close} onPress={handleClose} hitSlop={15}>
            <AntDesign name="close" size={18} />
          </Pressable>
        )}

        <View style={styles.headerContent}>
          <View style={styles.textContent}>
            <View
              style={[
                CUSTOM_STYLES.row,
                styles.statusContainer,
                {
                  gap: 4,
                  backgroundColor:
                    status === "pending"
                      ? hexToRgba(PALETTE.success, 0.09)
                      : status && hexToRgba(getStatusColor(status), 0.09),
                  borderColor:
                    status === "pending"
                      ? PALETTE.success
                      : status && getStatusColor(status),
                },
              ]}
            >
              <View
                style={[
                  CUSTOM_STYLES.dot,
                  styles.dot,
                  {
                    backgroundColor:
                      status === "pending"
                        ? PALETTE.success
                        : status && getStatusColor(status),
                  },
                ]}
              />
              <CustomText
                style={[
                  styles.statusText,
                  {
                    color:
                      status === "pending"
                        ? PALETTE.success
                        : status && getStatusColor(status),
                  },
                ]}
                weight="semibold"
              >
                {status === "pending" ? "Live Request" : status}
              </CustomText>
            </View>
            <View style={{ gap: 8 }}>
              <CustomText weight="bold" style={{ fontSize: 21.24 }}>
                {requestDetails?.title}
              </CustomText>
              <View
                style={[
                  CUSTOM_STYLES.row,
                  {
                    gap: 4,
                    alignItems: "flex-start",
                  },
                ]}
              >
                <LocationIcon color={PALETTE.black} width={14} height={14} />
                <CustomText size="sm" weight="regular">
                  {requestDetails?.address}
                </CustomText>
              </View>
            </View>
          </View>

          <CustomTabs
            tabs={activeTab === "compare" ? FILTER_TAB : ACTIVE_TAB}
            activeTab={activeTab === "compare" ? filterTab : activeTab}
            onTabChange={handleTabChange}
            style={{ marginTop: 32 }}
          />
        </View>
      </LinearGradient>

      {isLoading && <RequestJobSkeleton />}

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          { paddingBottom: insets.bottom + 80 },
        ]}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }, // 👈 required for height animation
        )}
        scrollEventThrottle={16}
      >
        {activeTab === "overview" ? (
          <Overview
            title="Request Details"
            handleGoBack={() => {
              router.push(`/(customer)/request-job/${requestDetails?.id}/edit`);
            }}
            item={{
              budget:
                requestDetails?.start_price !== requestDetails.end_price
                  ?`${formatCurrency(requestDetails?.start_price)} - ${formatCurrency(requestDetails?.end_price)}`
                  : formatCurrency(requestDetails.start_price),
              address: requestDetails?.address ?? "",
              images: requestDetails?.images ?? [],
              note: requestDetails?.description ?? "",
              date: requestDetails?.date
                ? formatDateTime(requestDetails?.date)
                : "",
            }}
          />
        ) : activeTab === "offers" ? (
          <Offers
            offers={requestDetails?.offers ?? []}
            jobId={id?.toString()}
          />
        ) : activeTab === "activity" ? (
          <Activity
            offers={requestDetails?.offers ?? []}
            handleViewOffer={() => setActiveTab("offers")}
            activities={requestDetails?.activities ?? []}
            status={requestDetails?.status}
            type="Request"
          />
        ) : (
          <ComparedOffers
            offers={filteredOffers || []}
            jobId={id?.toString()}
          />
        )}
      </Animated.ScrollView>

      {activeTab !== "compare" && status !== "cancelled" && (
        <View
          style={[
            styles.footerContainer,
            { paddingBottom: insets.bottom || 24 },
          ]}
        >
          <CustomButton
            title="Cancel Request"
            variant={
              requestDetails?.offers &&
              requestDetails?.offers.length > 0 &&
              activeTab === "offers"
                ? "secondary"
                : "primary"
            }
            onPress={sheetRef.open}
            style={styles.button}
          />
          {requestDetails?.offers &&
            requestDetails?.offers?.length > 0 &&
            activeTab === "offers" &&
            status !== "accepted" && (
              <CustomButton
                title="Compare Offers"
                variant="primary"
                style={styles.button}
                onPress={() => setActiveTab("compare")}
              />
            )}
        </View>
      )}

      <CancelRequest
        ref={sheetRef.ref}
        onClose={sheetRef.close}
        primaryAction={sheetRef.close}
        secondaryAction={handleCancelRequest}
        secondaryButtonLoadingState={isSubmitting}
        type="cancel"
      />
      <CancelRequest
        ref={requestCancelledModalRef.ref}
        onClose={closeRequestCancelledModal}
        title="Request Cancelled"
        description="This request is no longer active. You can create a new request anytime."
        secondaryButtonText="Back to Home"
        primaryButtonText="Create New"
        primaryAction={createNewRequest}
        secondaryAction={goToHome}
        type="warning"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingBottom: 10,
  },
  close: {
    justifyContent: "flex-end",
    flexDirection: "row",
    right: 20,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 60,
    backgroundColor: PALETTE.success,
  },
  statusText: {
    fontSize: 8.67,
    textTransform: "uppercase",
  },
  statusContainer: {
    borderWidth: 1,
    paddingHorizontal: 11.67,
    paddingVertical: 8.17,
    borderRadius: 58.3,
    width: 99,
    justifyContent: "center",
    alignItems: "center",
  },
  back: {
    left: 20,
  },
  headerContent: { paddingTop: 47 },
  textContent: { gap: 16, paddingHorizontal: 20 },
  tabContainer: {
    flexDirection: "row",
  },

  body: {
    paddingHorizontal: 20,
    paddingTop: 24,
    flexGrow: 1,
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 48,
    flexDirection: "row",
    gap: 12,
  },
  button: {
    flex: 1,
  },
});

export default RequestJobModal;
