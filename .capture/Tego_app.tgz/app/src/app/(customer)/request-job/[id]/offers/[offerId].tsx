import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";

import DateIcon from "@/assets/images/app-icons/date.svg";
import LocationIcon from "@/assets/images/app-icons/location.svg";
import NoteIcon from "@/assets/images/app-icons/note.svg";
import TimeIcon from "@/assets/images/app-icons/time.svg";

import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useOfferActions } from "@/modules/offers/hooks/useOfferActions";
import { ProviderHeader, ProviderStat } from "@/modules/provider/components";
import { NegotiateModal } from "@/modules/request-job/components";
import {
  CustomButton,
  CustomText,
  DetailsField,
  GoBack,
  SuccessSheet,
} from "@/shared/components";
import { useCountdown } from "@/shared/hooks/useCountdown";
import { useModalState } from "@/shared/hooks/useModalState";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Offer } from "@/modules/offers/types/offer.dto";
import { URGENCY } from "@/constants/types";
import { useProviderDetails } from "@/modules/provider/hooks/useProvider";

type FORM_VALUES = "title" | "date" | "address" | "urgency" | "note";

const getIcon = (type: FORM_VALUES) => {
  const props = { width: 20, height: 20, color: PALETTE.primary };
  const iconMap: Record<FORM_VALUES, React.ReactNode> = {
    title: <NoteIcon {...props} />,
    date: <DateIcon {...props} />,
    urgency: <TimeIcon {...props} />,
    address: <LocationIcon {...props} />,
    note: <NoteIcon {...props} />,
  };
  return iconMap[type] ?? null;
};

const OfferDetails = () => {
  const insets = useSafeAreaInsets();

  const { offerId } = useLocalSearchParams();

  const {
    lastName,
    firstName,
    profile_picture,
    availability,
    date,
    note,
    isVerified,
    offer,
    receiverId,
    jobId,
    providerId,
  } = useLocalSearchParams<{
    providerId: string;
    jobId: string;
    receiverId: string;
    firstName: string;
    lastName: string;
    profile_picture: string;
    rating: string;
    availability: string;
    date: string;
    note: string;
    isVerified: string;
    offer: string;
  }>();

  const { provider: profile, isLoading } = useProviderDetails(providerId);

  const createdAt = new Date(date).getTime();
  const expiresAt = createdAt + 90 * 60 * 1000; // 90 minutes
  const secondsLeft = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
  const { formatted, isExpired } = useCountdown(secondsLeft, true);

  const { acceptRequestOffer, isSubmitting } = useOfferActions();

  const negotiationRef = useModalState();
  const sheetRef = useModalState();

  const handleEdit = () => {
    // Edit Request
  };

  const handleGoBack = () => {
    router.back();
  };

  const handleAcceptOffer = () => {
    acceptRequestOffer(offerId.toString(), {
      onSuccess: () => {
        sheetRef.open();
      },
    });
  };
  const handleSuccess = () => {
    sheetRef.close();
    router.dismissAll();
    router.replace("/(customer)/(tabs)");
  };



  const negotiationSuccess = useModalState();
  const { isSubmitting: isNegotiating, sendRequestOffer } = useOfferActions();
  const negotiateOffer = (values: Offer) => {
    if (jobId && receiverId) {
      sendRequestOffer(
        {
          offer: {
            ...values,
            price: values.price,
            availability: availability as URGENCY,
          },
          message: values.proposal,
          receiver_id: receiverId,
          job_request_id: jobId,
          content_type: "OFFER",
        },
        {
          onSuccess: () => {
            negotiationRef.close();
            negotiationSuccess.open();
          }
        }
      )
    }
  }

  const viewConversation = () => {
    negotiationRef.close();
    negotiationSuccess.close();
    router.push(`/message/${providerId}/offer`)
    router.push({
      pathname:
        `/message/${jobId}/offer` as any,
      params: {
        receiverId: providerId,
        name: `${profile?.provider.name}`,
        avatar: profile?.provider.profile_picture ?? "",
        isOnline:
          profile?.provider.status === "available_to_work"
            ? "true"
            : "false",
      },
    });
  }


  console.log("PROFILE", profile?.provider.location);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={handleGoBack} />
        <CustomText weight="semibold" size="md">
          Offer Received
        </CustomText>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[styles.content]}
        >
          <View style={styles.profileHeader}>
            <ProviderHeader
              provider={{
                user: {
                  name: `${firstName} ${lastName}`,
                  avatar: profile_picture,
                  isVerified: isVerified ? true : false,
                },
                location:
                  profile?.provider.location.city
                  ? `${profile.provider.location.city}, ${profile.provider.location.state}`
                  : '',
              }}
            />
            <ProviderStat
              jobsDone={profile?.stats.jobs_done ?? 0}
              rating={profile?.stats.average_rating ?? 0}
              repeatClient={profile?.stats.repeat_client_percent ?? 0}
            />
          </View>
          <View style={styles.details}>
            <View style={styles.group}>
              <View style={[styles.fields, { display: "none" }]}>
                <View
                  style={[
                    CUSTOM_STYLES.row,
                    { justifyContent: "space-between", padding: 20 },
                  ]}
                >
                  <CustomText size="xs" weight="semibold">
                    Booking Details
                  </CustomText>

                  <Pressable
                    onPress={handleEdit}
                    style={{
                      display: "none",
                    }}
                  >
                    <PencilEditIcon />
                  </Pressable>
                </View>
              </View>
              <View style={styles.fields}>
                <DetailsField
                  label="Date"
                  value={date && formatDateTime(date)}
                  type="date"
                />
                <DetailsField
                  label="Address"
                  value={profile?.provider.location.city ? profile.provider.location.city : "N/A"}
                  type="address"
                />
                <DetailsField
                  label="Note"
                  value={note || "N/A"}
                  type="title"
                  isLast
                />
              </View>
            </View>
            <View style={styles.group}>
              <View style={styles.fields}>
                <View
                  style={[
                    CUSTOM_STYLES.row,
                    { justifyContent: "space-between", padding: 20 },
                  ]}
                >
                  <CustomText size="xs" weight="semibold">
                    Total
                  </CustomText>
                  <CustomText size="xs" weight="semibold">
                    {formatCurrency(parseInt(offer))}
                  </CustomText>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>

        <View
          style={[
            styles.footerContainer,
            { paddingBottom: insets.bottom || 24 },
          ]}
        >
          <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.center, { gap: 4 }]}>
            <Ionicons name="time-sharp" color={PALETTE.black} size={14} />
            <CustomText
              size="xs"
              weight="medium"
              style={{ letterSpacing: -0.24 }}
            >
              {isExpired ? "Expired" : `Expires in ${formatted}`}
            </CustomText>
          </View>
          <View style={[CUSTOM_STYLES.row, { gap: 12 }]}>
            <CustomButton
              title="Negotiate"
              variant="secondary"
              onPress={negotiationRef.open}
              style={styles.button}
              disabled={isExpired}
            />
            <CustomButton
              title="Accept"
              variant="primary"
              onPress={handleAcceptOffer}
              style={styles.button}
              disabled={isExpired}
              loading={isSubmitting}
            />
          </View>
        </View>
      </View>

      <NegotiateModal
        isOpen={negotiationRef.isOpen}
        ref={negotiationRef.ref}
        closeModal={negotiationRef.close}
        submitOffer={negotiateOffer}
        loading={isNegotiating}
      />
      <SuccessSheet
        ref={negotiationSuccess.ref}
        title="Counter offer sent"
        description="The provider has been notified and can respond to your proposed changes."
        onContinue={viewConversation}
        maxWidth={265}
        buttonText="View conversation"
        showConfetti={true}
      />

      <SuccessSheet
        ref={sheetRef.ref}
        title="Booking Confirmed 🎉"
        description="You've accepted this quote and the provider has been assigned to your request. "
        onContinue={handleSuccess}
        buttonText="View Order"
        variant="primary"
        showClose={false}
        showConfetti={true}
      />
    </View>
  );
};

interface FieldProps {
  label: string;
  value: string;
  isLast?: boolean;
}

interface DetailsFieldProps extends FieldProps {
  type: FORM_VALUES;
}

const Field = ({ label, value, isLast = false }: FieldProps) => {
  return (
    <View
      style={[
        styles.field,
        CUSTOM_STYLES.row,
        isLast && { borderBottomWidth: 0 },
      ]}
    >
      <CustomText weight="medium" size="xs" style={styles.label}>
        {label}
      </CustomText>
      <CustomText weight="semibold" size="sm" style={styles.value}>
        {value}
      </CustomText>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 20,
  },
  body: {},
  profileHeader: { gap: 24 },

  details: { gap: 20 },
  group: { gap: 8 },
  fields: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 6,
  },
  field: {
    justifyContent: "space-between",
    padding: 20,
    borderBottomWidth: 1,
    borderColor: "#0000000A",
  },
  detailsField: {
    gap: 14,
    padding: 20,
    borderBottomWidth: 1,
    borderColor: "#0000000A",
    alignItems: "flex-start",
    flexDirection: "row",
  },
  label: {
    opacity: 0.5,
  },
  value: {
    letterSpacing: -0.0024,
  },
  footerContainer: {
    gap: 14,
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  buttons: {},
  button: {
    flex: 1,
  },
});
export default OfferDetails;
