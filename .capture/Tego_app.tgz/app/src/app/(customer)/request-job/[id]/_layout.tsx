import { Stack } from "expo-router";

// app/(customer)/request-job/[id]/_layout.tsx
export default function JobDetailsLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen
        name="offers/[offerId]"
        options={{
          headerShown: false,
          presentation: "card", // 👈 card slide-up
        }}
      />
      <Stack.Screen
        name="edit"
        options={{
          headerShown: false,
        }}
      />
    </Stack>
  );
}
