import { Stack } from "expo-router";

export default function RequestJobLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="[id]" options={{ gestureDirection: "vertical" }} />
    </Stack>
  );
}
