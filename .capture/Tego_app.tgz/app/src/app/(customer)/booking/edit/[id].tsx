import { PALETTE } from "@/constants/colors";
import { CustomText, GoBack } from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const EditBooking = () => {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Booking
          </CustomText>
          <CustomText weight="bold" size="lg">
            Edit Booking
          </CustomText>
        </View>
      </LinearGradient>

      <View style={styles.body}>
        <CustomText weight="medium" style={{ opacity: 0.5 }}>
          This booking can&apos;t be edited right now. Please contact your
          service provider for changes.
        </CustomText>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  body: {
    paddingHorizontal: 20,
    paddingTop: 24,
  },
});

export default EditBooking;