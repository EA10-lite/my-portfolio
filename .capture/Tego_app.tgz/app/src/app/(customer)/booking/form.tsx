import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { URGENCY } from "@/constants/values";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import {
  FormValues,
  useBookingStore,
} from "@/modules/booking/store/booking.store";
import {
  AddressInput,
  CustomButton,
  CustomText,
  DatePicker,
  GoBack,
  ImagePicker,
  Input,
  Select,
  SuccessSheet,
  Textbox,
  TimePicker,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useDeviceInfo } from "@/shared/hooks/useLocation";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Formik } from "formik";
import { useMemo } from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const BookingDetails = () => {
  const { user } = useAuthStore();
  const { showToast } = useToastStore();
  const { location } = useDeviceInfo();
  const { clearBooking, setFormData, form, provider } = useBookingStore();
  const insets = useSafeAreaInsets();

  const handleGoBack = () => {
    clearBooking();
    router.back();
  };

  const sheetRef = useModalState();

  const handleSubmit = (values: FormValues) => {
    if (!values.title?.trim()) {
      showToast("Action failed", "Please enter a title");
      return;
    }

    if (!values.date) {
      showToast("Action failed", "Please select a date");
      return;
    }

    if (!values.time) {
      showToast("Action failed", "Please select a time");
      return;
    }

    const selectedDate = new Date(values.date);
    const [hours, minutes] = values.time.split(":").map(Number);

    const selectedDateTime = new Date(
      selectedDate.getFullYear(),
      selectedDate.getMonth(),
      selectedDate.getDate(),
      hours,
      minutes
    );

    if (selectedDateTime <= new Date()) {
      showToast(
        "Action failed",
        "Please select a future date and time"
      );
      return;
    }

    if (!values.service_list_item_id?.trim()) {
      showToast("Action failed", "Please select a type of service");
      return;
    }

    if (!values.address?.address?.trim()) {
      showToast("Action failed", "Please enter an address");
      return;
    }

    if (!values.address?.state?.trim()) {
      showToast("Action failed", "Please select a state");
      return;
    }

    if (!values.address?.country?.trim()) {
      showToast("Action failed", "Please select a country");
      return;
    }

    if (!values.urgency?.trim()) {
      showToast("Action failed", "Please select an urgency level");
      return;
    }

    setFormData(values);

    if (values.service_list_item_id.trim().toLowerCase() === "other") {
      sheetRef.open();
      return;
    }

    router.push("/booking/preview");
  };

  const initialAddress = useMemo(
    () => ({
      state: user?.user_details?.user_address?.state || location.state || "",

      country:
        user?.user_details?.user_address?.country ||
        location.country ||
        "Nigeria",

      address:
        user?.user_details?.user_address?.address || location.address || "",
    }),
    [user?.user_details?.user_address, location],
  );

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={handleGoBack} />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Step 1 of 3
          </CustomText>
          <CustomText weight="bold" size="lg">
            Booking Details
          </CustomText>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <Formik
          validateOnChange={false}
          enableReinitialize
          initialValues={{
            ...form,
            address: form.address?.address ? form.address : initialAddress,
          }}
          onSubmit={handleSubmit}
          validateOnBlur
        >
          {({ handleSubmit, values }) => (
            <ScreenShell
              extraScrollHeight={30}
              extraHeight={100}
              contentContainerStyle={styles.content}
              footer={
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Continue"
                    variant="primary"
                    onPress={handleSubmit}
                  />
                </View>
              }
            >
              <View style={[CUSTOM_STYLES.flex, styles.formContainer]}>
                <View style={[CUSTOM_STYLES.flex, styles.form]}>
                  <Input name="title" placeholder="Title" />
                  <Select
                    name="service_list_item_id"
                    placeholder="Type of service"
                    options={
                      provider?.services.map((service) => ({
                        label: service.service_name,
                        value: service.id,
                      })) || []
                    }
                  />
                  <DatePicker
                    name="date"
                    placeholder="Select date"
                    value={values["date"]}
                  />
                  <TimePicker name="time" placeholder="Select time" />
                  <Select
                    name="urgency"
                    placeholder="Urgency"
                    options={URGENCY}
                  />
                  <AddressInput
                    name="address"
                    isEditable={true}
                    address={values.address.address}
                    state={values.address.state}
                  />
                  <Textbox
                    name="note"
                    placeholder={
                      values["service_list_item_id"] === "other"
                        ? "Describe the issue"
                        : "Note (optional)"
                    }
                  />
                  <ImagePicker name="images" label="Upload Image" />
                </View>
              </View>
            </ScreenShell>
          )}
        </Formik>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  formContainer: {
    paddingBottom: 80,
  },
  form: { gap: 15 },
  info: {
    borderWidth: 1,
    borderColor: PALETTE.primary14,
    backgroundColor: "#F5FBFF",
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 4,
    justifyContent: "center",
    minWidth: "57%",
    margin: "auto",
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 48,
  },
});
export default BookingDetails;
