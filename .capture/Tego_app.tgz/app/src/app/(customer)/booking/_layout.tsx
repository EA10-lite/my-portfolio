// app/(customer)/_layout.tsx
import { Stack } from "expo-router";

export default function ProtectedLayout() {
  return <Stack screenOptions={{ headerShown: false }}></Stack>;
}
