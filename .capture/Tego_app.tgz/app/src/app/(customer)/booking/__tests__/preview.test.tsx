import { fireEvent } from "@testing-library/react-native";
import React from "react";
import { pressableForLabel, renderWithProviders } from "@/testing/render";
import Preview from "../preview";

const mockCreate = jest.fn();
const mockClearBooking = jest.fn();

jest.mock("@/modules/provider/components", () => ({
  ProviderStat: () => null,
}));

jest.mock("@/modules/booking/store/booking.store", () => ({
  useBookingStore: () => ({
    provider: {
      id: "p-1",
      name: "Akpan Okon",
      profile_picture: "",
      availability_status: "available",
      location: "Lagos",
      rating: 4.5,
      jobs_done: 12,
      repeat_clients: 6,
      is_verified: true,
      services: [],
    },
    form: {
      title: "Fix leaking tap",
      date: "2026-09-15",
      time: "10:00",
      address: { address: "12 Marina Rd", state: "Lagos", country: "Nigeria" },
      note: "",
      urgency: "normal",
      service_list_item_id: "svc-1",
      images: [],
    },
    clearBooking: mockClearBooking,
  }),
}));

jest.mock("@/modules/booking/hooks/useBookingActions", () => ({
  useBookingActions: () => ({
    create: mockCreate,
    isSubmitting: false,
    errorMessage: null,
  }),
}));

jest.mock("expo-router", () => ({
  router: { back: jest.fn(), push: jest.fn(), replace: jest.fn(), dismissAll: jest.fn() },
}));

describe("booking preview (ScreenShell migration)", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders booking summary and the footer confirm button", async () => {
    const ui = await renderWithProviders(<Preview />);
    expect(ui.getByText("Booking Confirmation")).toBeTruthy();
    expect(ui.getByText(/Akpan Okon/)).toBeTruthy();
    expect(ui.getByText("Booking Details")).toBeTruthy();
    expect(ui.getByText("Fix leaking tap")).toBeTruthy();
    expect(ui.getByText("12 Marina Rd")).toBeTruthy();
    expect(ui.getByText("Secured Booking")).toBeTruthy();
    expect(ui.getByText("Confirm Booking")).toBeTruthy();
  });

  it("keeps content above the keyboard via ScreenShell config", async () => {
    const ui = await renderWithProviders(<Preview />);
    const tree = JSON.stringify(ui.toJSON());
    expect(tree).toContain('"keyboardShouldPersistTaps":"handled"');
    expect(tree).toContain('"enableOnAndroid":true');
    expect(tree).toContain('"keyboardDismissMode":"on-drag"');
    expect(tree).toContain('"extraScrollHeight":20');
    expect(tree).toContain('"extraHeight":100');
  });

  it("submits the booking with the provider id", async () => {
    const ui = await renderWithProviders(<Preview />);
    await fireEvent.press(pressableForLabel(ui, "Confirm Booking"));
    expect(mockCreate).toHaveBeenCalledWith(
      expect.objectContaining({ provider_id: "p-1" }),
      expect.anything(),
    );
  });
});