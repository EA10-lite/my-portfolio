import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import SecureIcon from "@/assets/images/app-icons/secure.svg";
import VerifiedIcon from "@/assets/images/app-icons/verified.svg";

import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useBookingActions } from "@/modules/booking/hooks/useBookingActions";
import { useBookingStore } from "@/modules/booking/store/booking.store";
import { ProviderStat } from "@/modules/provider/components";
import {
  CustomButton,
  CustomText,
  DetailsField,
  GoBack,
  SuccessSheet,
  UserAvatar,
} from "@/shared/components";
import { ScreenShell } from "@/shared/containers";
import { useModalState } from "@/shared/hooks/useModalState";
import { getStatusColor } from "@/shared/utils/colors";
import { formatDateTime } from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const BookingDetails = () => {
  const insets = useSafeAreaInsets();
  const { provider, form, clearBooking } = useBookingStore();
  const { create, isSubmitting, errorMessage } = useBookingActions();

  const sheetRef = useModalState();
  const goBack = () => router.back();

  const handleSubmit = () => {
    if (provider && provider.id) {
      create(
        {
          ...form,
          provider_id: provider?.id,
        },
        {
          onSuccess: (data) => {
            sheetRef.open();
          },
        },
      );
    }
  };

  const handleSuccess = () => {
    sheetRef.close();
    clearBooking();
    router.dismissAll();
    router.replace("/(customer)/(tabs)");
  };

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={goBack} />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            Step 2 of 3
          </CustomText>
          <CustomText weight="bold" size="lg">
            Booking Confirmation
          </CustomText>
        </View>
      </LinearGradient>

      <View style={CUSTOM_STYLES.flex}>
        <ScreenShell
          contentContainerStyle={styles.content}
          footer={
            <View
              style={[
                styles.footerContainer,
                { paddingBottom: insets.bottom || 24 },
              ]}
            >
              {/* 👇 Add error message display */}
              {errorMessage && (
                <View style={styles.errorBox}>
                  <Ionicons name="alert-circle" size={16} color={PALETTE.error} />
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={{ color: PALETTE.error, flex: 1 }}
                  >
                    {errorMessage}
                  </CustomText>
                </View>
              )}
              <View
                style={[
                  CUSTOM_STYLES.row,
                  { gap: 4, justifyContent: "center", opacity: 0.5 },
                ]}
              >
                <SecureIcon width={16} height={16} color={PALETTE.black} />
                <CustomText size="xs" weight="medium">
                  Secured Booking
                </CustomText>
              </View>
              <CustomButton
                title="Confirm Booking"
                variant="primary"
                onPress={handleSubmit}
                loading={isSubmitting}
              />
            </View>
          }
        >
          <View style={styles.profile}>
            <View style={styles.profileHeader}>
              <View style={styles.profileRow}>
                <UserAvatar
                  url={provider?.profile_picture}
                  name={provider?.name || ""}
                />
                <View style={styles.profileInfo}>
                  <CustomText weight="semibold" size="md">
                    {provider?.name}{" "}
                    {provider?.is_verified && (
                      <VerifiedIcon width={16} height={16} />
                    )}
                  </CustomText>
                  <View style={styles.profileMeta}>
                    {provider?.availability_status && (
                      <View style={styles.inlineRow}>
                        <View
                          style={[
                            styles.availabilityDot,
                            {
                              backgroundColor: getStatusColor(
                                provider.availability_status,
                              ),
                            },
                          ]}
                        />
                        <CustomText size="xs" weight="regular">
                          {provider.availability_status.toLowerCase() ===
                          "offline"
                            ? "Not Available"
                            : provider.availability_status.toLowerCase() ===
                                "busy"
                              ? "Busy"
                              : "Available"}
                        </CustomText>
                      </View>
                    )}

                    {provider?.location && (
                      <View style={styles.inlineRow}>
                        <Ionicons
                          name="location-sharp"
                          size={12}
                          color={PALETTE.black}
                        />
                        <CustomText size="xs" weight="regular">
                          {provider?.location}
                        </CustomText>
                      </View>
                    )}
                  </View>
                </View>
              </View>
              <View style={styles.profileStats}>
                <ProviderStat
                  jobsDone={provider?.jobs_done ?? 0}
                  rating={provider?.rating ?? 0}
                  repeatClient={provider?.repeat_clients ?? 0}
                />
              </View>
            </View>
          </View>
          <View style={styles.details}>
            <View style={styles.group}>
              <View style={styles.fields}>
                <View
                  style={[
                    CUSTOM_STYLES.row,
                    { justifyContent: "space-between", padding: 20 },
                  ]}
                >
                  <CustomText size="xs" weight="semibold">
                    Booking Details
                  </CustomText>

                  <Pressable onPress={goBack}>
                    <PencilEditIcon />
                  </Pressable>
                </View>
              </View>
              <View style={styles.fields}>
                <DetailsField label="Title" value={form.title} type="title" />
                <DetailsField
                  label="Date & Time"
                  value={form.date && formatDateTime(form.date, form.time)}
                  type="date"
                />
                <DetailsField
                  label="Urgency"
                  value={form.urgency}
                  type="urgency"
                />
                <DetailsField
                  label="Address"
                  value={form?.address?.address || "N/A"}
                  type="address"
                />
                <DetailsField
                  label="Note"
                  value={form.note || "N/A"}
                  type="title"
                  isLast
                />
              </View>
            </View>
          </View>
        </ScreenShell>
      </View>

      <SuccessSheet
        ref={sheetRef.ref}
        title="Booking Request Sent 🎉"
        description="Your request has been sent out to the provider. You will be notified once they respond"
        onContinue={handleSuccess}
        buttonText="Ok, Got it"
        variant="primary"
        showClose={false}
        showConfetti={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 20,
  },
  body: {},
  profile: {},
  profileHeader: { gap: 24 },
  profileRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
  },
  profileInfo: {
    gap: 8,
  },
  profileMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  profileStats: {},

  details: {
    gap: 20,
    paddingBottom: 20,
  },
  group: { gap: 8 },
  fields: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 6,
  },
  footerContainer: {
    gap: 14,
    paddingHorizontal: 20,
    paddingTop: 10,
  },

  // ── Shared ────────────────────────────────────────
  inlineRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  availabilityDot: {
    width: 6,
    height: 6,
    borderRadius: 10,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "rgba(235, 87, 87, 0.08)",
    borderRadius: 6,
    padding: 12,
  },
});
export default BookingDetails;
