import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import {
  CategorySkeletonGrid,
  SubCategories,
} from "@/modules/categories/containers";
import { useCategoriesWithProviders } from "@/modules/categories/hooks/useCategoriesWithProviders";
import { CategoryWithProviders } from "@/modules/categories/types/category.dto";
import { useProfile } from "@/modules/profile/hooks/useProfile";
import { CustomSearchInput, CustomText, GoBack } from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { useMemo, useState } from "react";
import { Keyboard, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Booking = () => {
  useProfile();
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState<string>("");
  const [isFocused, setIsFocused] = useState<boolean>(false);

  const { categories_with_providers, isLoading } = useCategoriesWithProviders();

  const data: CategoryWithProviders[] =
    categories_with_providers?.categories ?? [];

  const filteredCategories = useMemo(() => {
    return data.filter((category) =>
      category.name.toLowerCase().includes(search.toLowerCase().trim()),
    );
  }, [search, data]);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack />
        <View style={{ gap: 4 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{ opacity: 0.5, textTransform: "uppercase" }}
          >
            Book a service
          </CustomText>
          <CustomText weight="bold" size="lg">
            What service do you need?
          </CustomText>
        </View>
        <View style={styles.searchBox}>
          <CustomSearchInput
            value={search}
            placeholder="Search for service providers"
            onChange={(text: string) => setSearch(text)}
            isFocused={isFocused}
            setIsFocused={setIsFocused}
          />
        </View>
      </LinearGradient>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          { paddingBottom: insets.bottom + TAB_BAR_HEIGHT },
        ]}
        onScrollBeginDrag={Keyboard.dismiss}
      >
        {isLoading ? (
          <CategorySkeletonGrid />
        ) : (
          <SubCategories data={filteredCategories} isBooking={true} />
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },

  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
});
export default Booking;
