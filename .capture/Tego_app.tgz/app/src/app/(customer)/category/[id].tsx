import { PALETTE } from "@/constants/colors";
import { useCategoryProviders } from "@/modules/categories/hooks/useCategoryProviders";
import { ProviderFilter } from "@/modules/provider/components";
import { AllProviders, TopProviders } from "@/modules/provider/containers";
import { useProviderFilterStore } from "@/modules/provider/store/providerFilter";
import {
  CustomSearchInput,
  CustomText,
  EmptyMessages,
  GoBack,
} from "@/shared/components";
import { useCollapsibleSearch } from "@/shared/hooks/useCollapseSearch";
import Octicons from "@expo/vector-icons/Octicons";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useEffect, useMemo } from "react";
import {
  Animated,
  NativeScrollEvent,
  NativeSyntheticEvent,
  StyleSheet,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const CategoryDetails = () => {
  const insets = useSafeAreaInsets();

  const { id } = useLocalSearchParams();
  const { appliedFilters, initializeFilters } = useProviderFilterStore();

  const categoryId = id.toString();

  useEffect(() => {
    initializeFilters({
      category_id: categoryId,
    });
  }, [categoryId, initializeFilters]);

  const {
    search,
    setSearch,
    isFocused,
    setIsFocused,
    onScroll,
    collapsibleStyle,
    filterStyle,
  } = useCollapsibleSearch({ searchBarHeight: 91 });

  const {
    category,
    providers,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
  } = useCategoryProviders(appliedFilters.category_id ? appliedFilters : { category_id: categoryId });

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    onScroll(event);

    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;

    const paddingToBottom = 300;

    const isNearBottom =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;

    if (isNearBottom && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  };

  const filteredCategories = useMemo(() => {
    return {
      nearbyProviders: providers.popular_near_you.filter((provider) =>
        provider.first_name.toLowerCase().includes(search.toLowerCase().trim()),
      ),
      topRatedProviders: providers.top_rated.filter((provider) =>
        provider.first_name.toLowerCase().includes(search.toLowerCase().trim()),
      ),
      allProviders: providers.all_providers.filter((provider) =>
        provider.first_name.toLowerCase().includes(search.toLowerCase().trim()),
      ),
    };
  }, [search, providers]);

  const hasProviders =
    (filteredCategories.nearbyProviders?.length ?? 0) > 0 ||
    (filteredCategories.topRatedProviders?.length ?? 0) > 0 ||
    (filteredCategories.allProviders?.length ?? 0) > 0;

  const getTotalResult = () => {
    return filteredCategories?.allProviders?.length || 0;
  };

  const handleBookNow = () => {
    router.push(`/(customer)/booking/form?category_id=${id}`);
  };

  const nearbyProvidersData =
    filteredCategories.nearbyProviders?.map((provider) => ({
      ...provider,
      service_category: {
        id: categoryId ?? "",
        name: category?.name ?? "",
      },
    })) ?? [];

  const topRatedProvidersData =
    filteredCategories.topRatedProviders?.map((provider) => ({
      ...provider,
      service_category: {
        id: categoryId ?? "",
        name: category?.name ?? "",
      },
    })) ?? [];

  const allProvidersData =
    filteredCategories.allProviders?.map((provider) => ({
      ...provider,
      service_category: {
        id: categoryId ?? "",
        name: category?.name ?? "",
      },
      profile_picture: provider.profile_picture ?? category?.cover_image,
      profile_card: provider.profile_card ?? category?.cover_image,
    })) ?? [];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack />
        <View>
          <CustomText weight="bold" size="lg">
            Categories
          </CustomText>

          {/* 🔥 Collapsible Search */}
          <Animated.View style={collapsibleStyle}>
            <View style={styles.search}>
              <View style={styles.searchBox}>
                <CustomSearchInput
                  value={search}
                  placeholder="Search for service providers"
                  onChange={setSearch}
                  isFocused={isFocused}
                  setIsFocused={setIsFocused}
                />
                <Animated.View style={filterStyle}>
                  <ProviderFilter />
                </Animated.View>
              </View>

              {search.length > 0 && getTotalResult() > 0 && (
                <CustomText size="xs" weight="medium">
                  Showing {getTotalResult()} service providers matching your
                  search
                </CustomText>
              )}
            </View>
          </Animated.View>
        </View>
      </LinearGradient>

      {/* Loading state */}
      {isLoading && (
        <Animated.ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.body,
            { paddingBottom: insets.bottom },
          ]}
          onScroll={onScroll}
          scrollEventThrottle={16}
        >
          <TopProviders
            showLink={false}
            title="Popular Near you"
            data={[]}
            isLoading={true}
            handleBookNow={handleBookNow}
          />

          <TopProviders
            title="Top Rated Providers"
            showLink={false}
            data={[]}
            isLoading={true}
            handleBookNow={handleBookNow}
          />

          <AllProviders
            data={[]}
            isLoading={true}
            handleBookNow={handleBookNow}
          />
        </Animated.ScrollView>
      )}

      {/* Results state */}
      {!isLoading && hasProviders && (
        <Animated.ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.body,
            { paddingBottom: insets.bottom },
          ]}
          onScroll={handleScroll}
          scrollEventThrottle={16}
        >
          {nearbyProvidersData?.length > 0 && (
            <TopProviders
              showLink={false}
              title="Popular Near you"
              data={nearbyProvidersData}
              isLoading={false}
              handleBookNow={handleBookNow}
            />
          )}

          {topRatedProvidersData.length > 0 && (
            <TopProviders
              title="Top Rated Providers"
              showLink={false}
              data={topRatedProvidersData}
              isLoading={false}
              handleBookNow={handleBookNow}
            />
          )}

          {allProvidersData.length > 0 && (
            <AllProviders
              data={allProvidersData}
              isLoading={false}
              handleBookNow={handleBookNow}
            />
          )}
        </Animated.ScrollView>
      )}

      {/* Empty state */}
      {!isLoading && !hasProviders && (
        <EmptyMessages
          title="No results found"
          description="We couldn't find any services matching your search."
          Icon={() => (
            <Octicons name="search" size={20} color={PALETTE.primary} />
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  search: {
    gap: 14,
    marginTop: 34,
  },
  results: {},
  body: {
    gap: 24,
    marginTop: 10,
  },
});

export default CategoryDetails;
