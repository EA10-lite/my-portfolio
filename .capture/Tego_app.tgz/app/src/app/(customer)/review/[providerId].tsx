import { PALETTE } from "@/constants/colors";
import { ProviderHeader } from "@/modules/provider/components";
import { ReviewCard, ReviewCardSkeleton } from "@/modules/review/components";
import { useProviderReviews } from "@/modules/review/hooks/useProviderReview";
import { CustomText, EmptyMessages, GoBack } from "@/shared/components";
import { CustomTabs } from "@/shared/containers";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams } from "expo-router";
import { useMemo, useState } from "react";
import { FlatList, Platform, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FullWindowOverlay } from "react-native-screens";

const RATING = [
  { label: "All", value: "all" },
  { label: "5 stars", value: "5_star" },
  { label: "4 stars", value: "4_star" },
  { label: "3 stars", value: "3_star" },
  { label: "2 stars", value: "2_star" },
  { label: "1 stars", value: "1_star" },
];

const Wrapper = ({ children }: { children: React.ReactNode }) => {
  if (Platform.OS === "ios") {
    return <FullWindowOverlay>{children}</FullWindowOverlay>;
  }

  return <>{children}</>;
};

const ProviderReview = () => {
  const insets = useSafeAreaInsets();
  const [activeFilter, setActiveFilter] = useState("all");

  const { providerId, name, avatar, location, isVerified } =
    useLocalSearchParams<{
      providerId: string;
      name: string;
      avatar: string;
      isVerified: string;
      location: string;
    }>();
  const { reviews, isFetchingNextPage, hasNextPage, fetchNextPage, isLoading } =
    useProviderReviews(providerId.toString());

  const filteredReview = useMemo(() => {
    if (activeFilter === "all") {
      return reviews ?? [];
    }

    const rating = parseInt(activeFilter.split("_")[0], 10);

    return (reviews ?? []).filter((review) => review.rating === rating);
  }, [reviews, activeFilter]);

  const ratingFilters = useMemo(() => {
    const data = reviews ?? [];
    return [
      {
        label: "All",
        value: "all",
        count: data.length,
      },
      {
        label: "5 stars",
        value: "5_star",
        count: data.filter((review) => review.rating === 5).length,
      },
      {
        label: "4 stars",
        value: "4_star",
        count: data.filter((review) => review.rating === 4).length,
      },
      {
        label: "3 stars",
        value: "3_star",
        count: data.filter((review) => review.rating === 3).length,
      },
      {
        label: "2 stars",
        value: "2_star",
        count: data.filter((review) => review.rating === 2).length,
      },
      {
        label: "1 star",
        value: "1_star",
        count: data.filter((review) => review.rating === 1).length,
      },
    ];
  }, [reviews]);

  return (
    <Wrapper>
      <View style={styles.container}>
        <FlatList
          data={filteredReview}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          onEndReachedThreshold={0.4}
          contentContainerStyle={{ flexGrow: 1 }}
          onEndReached={() => {
            if (hasNextPage && !isFetchingNextPage) fetchNextPage();
          }}
          ListHeaderComponent={
            <>
              <LinearGradient
                colors={[
                  "rgba(51, 171, 247, 0.472)",
                  "rgba(255, 255, 255, 0.401)",
                ]}
                locations={[0, 1]}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={[styles.header, { paddingTop: insets.top + 32 }]}
              >
                <View style={{ paddingHorizontal: 20, gap: 47 }}>
                  <GoBack />
                  <View style={{ gap: 28 }}>
                    <CustomText
                      weight="semibold"
                      size="xs"
                      style={{ opacity: 0.5, textTransform: "uppercase" }}
                    >
                      Reviews & Ratings
                    </CustomText>
                    <ProviderHeader
                      provider={{
                        user: {
                          name,
                          isVerified: isVerified === "true",
                          avatar,
                        },
                        location,
                      }}
                    />
                  </View>
                </View>

                <View style={{ marginVertical: 24 }}>
                  <CustomTabs
                    tabs={ratingFilters}
                    activeTab={activeFilter}
                    onTabChange={setActiveFilter}
                  />
                </View>
              </LinearGradient>
            </>
          }
          renderItem={({ item }) => <ReviewCard review={item} />}
          ListEmptyComponent={
            isLoading ? (
              <View style={{ gap: 20 }}>
                <ReviewCardSkeleton />
                <ReviewCardSkeleton />
                <ReviewCardSkeleton />
              </View>
            ) : (
              <View style={{ flex: 1 }}>
                <EmptyMessages
                  description="No Reviews for this provider yet"
                  title="No reviews yet"
                  isInTabView={false}
                />
              </View>
            )
          }
        />
      </View>
    </Wrapper>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingBottom: 10,
  },
  body: {
    flexGrow: 1,
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
    position: "relative",
  },
});

export default ProviderReview;
