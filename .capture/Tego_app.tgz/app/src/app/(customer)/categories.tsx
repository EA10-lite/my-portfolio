import { PALETTE } from "@/constants/colors";
import {
  CategorySkeletonGrid,
  SubCategories,
} from "@/modules/categories/containers";
import { useCategoriesWithProviders } from "@/modules/categories/hooks/useCategoriesWithProviders";
import { useMostBookedCateogires } from "@/modules/categories/hooks/useMostBookedCategories";
import { CategoryWithProviders } from "@/modules/categories/types/category.dto";
import { Categories as MostBookedCategories } from "@/modules/home/containers";
import { CustomText, GoBack } from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Categories = () => {
  const insets = useSafeAreaInsets();

  const { most_booked_categories, isLoading } = useMostBookedCateogires();
  const { categories_with_providers, isLoading: isLoading2 } =
    useCategoriesWithProviders();
  const data: CategoryWithProviders[] =
    categories_with_providers?.categories ?? [];
  const categories = most_booked_categories?.categories ?? [];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.232)", "rgba(255, 255, 255, 0.255)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32, }]}
      >
        <GoBack />
        <CustomText weight="bold" size="lg">
          Categories
        </CustomText>
      </LinearGradient>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          { paddingBottom: insets.bottom}
        ]}
      >
        {isLoading2 ? <CategorySkeletonGrid /> : <SubCategories data={data} />}
        <MostBookedCategories
          data={categories}
          isMostBooked={true}
          isLoading={isLoading}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
});
export default Categories;
