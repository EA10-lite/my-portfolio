import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { ActionModal } from "@/modules/home/components";

import { useCategories } from "@/modules/categories/hooks/useCategories";
import { Actions, Categories } from "@/modules/home/containers";
import { useUnreadCount } from "@/modules/notifications/hooks/useUnreadCount";
import { useProfile } from "@/modules/profile/hooks/useProfile";
import { AllProviders, TopProviders } from "@/modules/provider/containers";
import { useProviders } from "@/modules/provider/hooks/useProviders";
import { normalizeProviders } from "@/modules/provider/utils/normalizeProvider";
import { Header } from "@/shared/components";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useLocationStore } from "@/shared/store/locationStore";
import { useUIStore } from "@/shared/store/uiStore";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import {
  NativeScrollEvent,
  NativeSyntheticEvent,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Home = () => {
  useProfile();
  const { bottom } = useSafeAreaInsets();
  const { isLocationPopupOpen } = useUIStore();
  const [search, setSearch] = useState<string>("");
  const { handleScroll: onScroll } = useHideTabBarOnScroll();
  const { count } = useUnreadCount();

  const { latitude, longitude } = useLocationStore();
  const { categories, isLoading: isCategoryLoading } = useCategories();
  const {
    providers: allProviders,
    isLoading: isAllProvidersLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
    refetch,
  } = useProviders();
  const {
    providers: topProviders,
    isLoading: isTopProviderLoading,
    refetch: refetchTopProviders,
  } = useProviders({
    preference: ["top_providers"],
  });
  const {
    providers: nearByProviders,
    isLoading: isProviderNearMeLoading,
    refetch: refetchNearByProviders,
  } = useProviders({
    preference: ["near_me"],
    latitude,
    longitude,
  });

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    onScroll(event);

    const { layoutMeasurement, contentOffset, contentSize } = event.nativeEvent;

    const paddingToBottom = 300;

    const isNearBottom =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;

    if (isNearBottom && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  };

  const handleBookNow = () => {
    router.push("/(customer)/booking/form");
  };

  const normalizedTopProviders = useMemo(() => {
    const query = search.toLowerCase().trim();
    const matches = topProviders?.filter(
      (p) =>
        p.provider.first_name.toLowerCase().includes(query) ||
        p.provider.last_name.toLowerCase().includes(query) ||
        p.service_category.name.toLowerCase().includes(query),
    );

    return normalizeProviders(matches);
  }, [search, topProviders]);

  const normalizedNearByProviders = useMemo(() => {
    const query = search.toLowerCase().trim();
    const matches = nearByProviders?.filter(
      (p) =>
        p.provider.first_name.toLowerCase().includes(query) ||
        p.provider.last_name.toLowerCase().includes(query) ||
        p.service_category.name.toLowerCase().includes(query),
    );

    return normalizeProviders(matches);
  }, [search, nearByProviders]);

  const normalizedAllProviders = useMemo(() => {
    const query = search.toLowerCase().trim();
    const matches = allProviders?.filter(
      (p) =>
        p.provider.first_name.toLowerCase().includes(query) ||
        p.provider.last_name.toLowerCase().includes(query) ||
        p.service_category.name.toLowerCase().includes(query),
    );

    return normalizeProviders(matches);
  }, [search, allProviders]);

  const hasData =
    normalizedTopProviders.length > 0 || (categories && categories.length > 0);

  const isLoading =
    isCategoryLoading || isTopProviderLoading || isAllProvidersLoading;

  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);

    try {
      await Promise.all([
        refetch(),
        refetchNearByProviders(),
        refetchTopProviders(),
      ]);
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: isLocationPopupOpen
            ? PALETTE.black
            : PALETTE.background,
        },
      ]}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
      >
        <Header
          search={search}
          setSearch={setSearch}
          placeholder={"Search categories, services..."}
          notificationCount={count}
        />
        <View
          style={{
            backgroundColor: PALETTE.white,
            zIndex: 1,
            elevation: 0,
            paddingBottom: bottom + TAB_BAR_HEIGHT + 200,
          }}
        >
          <Actions />
          {/* Loading state */}
          {isLoading && (
            <View style={[styles.content]}>
              <Categories data={[]} isLoading={isCategoryLoading} />
              <TopProviders
                showLink={false}
                title="Popular Near you"
                data={[]}
                isLoading={true}
                handleBookNow={handleBookNow}
              />

              <TopProviders
                title="Top Rated Providers"
                showLink={false}
                data={[]}
                isLoading={true}
                handleBookNow={handleBookNow}
              />

              <AllProviders
                data={[]}
                isLoading={true}
                handleBookNow={handleBookNow}
              />
            </View>
          )}

          {hasData && !isLoading && (
            <View style={styles.content}>
              <Categories
                data={categories || []}
                isLoading={isCategoryLoading}
              />
              {normalizedNearByProviders.length > 0 && (
                <TopProviders
                  data={normalizedNearByProviders}
                  title="Popular Near You"
                  type="near_me"
                  isLoading={isProviderNearMeLoading}
                  handleBookNow={handleBookNow}
                  showLink
                />
              )}
              {normalizedTopProviders.length > 0 && (
                <TopProviders
                  data={normalizedTopProviders}
                  title="Top Rated Providers"
                  type="top_providers"
                  isLoading={isTopProviderLoading}
                  handleBookNow={handleBookNow}
                  showLink
                />
              )}
              {normalizedAllProviders.length > 0 && (
                <AllProviders
                  data={normalizedAllProviders}
                  title="All Providers"
                  isLoading={isTopProviderLoading}
                  handleBookNow={handleBookNow}
                />
              )}
            </View>
          )}
        </View>
      </ScrollView>
      <ActionModal />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: { marginTop: 24, gap: 24 },
});

export default Home;
