import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Arrow,
  CustomModal,
  CustomText,
  UserAvatar,
} from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import BellIcon from "@/assets/images/app-icons/bell-2.svg";
import BookingIcon from "@/assets/images/app-icons/booking.svg";
import FileIcon from "@/assets/images/app-icons/file.svg";
import InfoIcon from "@/assets/images/app-icons/info.svg";
import LocationIcon from "@/assets/images/app-icons/location.svg";
import LogoutIcon from "@/assets/images/app-icons/logout.svg";
import PasswordIcon from "@/assets/images/app-icons/password-alt.svg";
import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import PhoneIcon from "@/assets/images/app-icons/phone-alt.svg";
import SecureIcon from "@/assets/images/app-icons/secure.svg";
import SupportIcon from "@/assets/images/app-icons/support.svg";
import DeleteIcon from "@/assets/images/app-icons/trash.svg";
import VerifiedIcon from "@/assets/images/app-icons/verified.svg";
import { avatars } from "@/constants/avatars";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { useLogout } from "@/modules/auth/hooks/useLogout";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { SelectAvatar } from "@/modules/profile/components";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useModalState } from "@/shared/hooks/useModalState";
import { hexToRgba } from "@/shared/utils/converter";
interface Link {
  label: string;
  onPress: () => void;
  Icon: React.ReactNode;
}

const Profile = () => {
  const { user } = useAuthStore();
  const { logout, isLoading } = useLogout();
  const insets = useSafeAreaInsets();
  const { handleScroll } = useHideTabBarOnScroll();

  const modalRef = useModalState();
  const avatarRef = useModalState();

  const handleLogout = () => {
    logout(undefined, {
      onSuccess: () => {
        modalRef.close();
      },
    });
  };

  const myAccountLinks: Link[] = [
    {
      label: "Bookings",
      Icon: <BookingIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/bookings"),
    },
    {
      label: "Saved Address",
      Icon: <LocationIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/edit-address"),
    },
    {
      label: "Notifications",
      Icon: <BellIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/notifications"),
    },
  ];
  const privacyLinks: Link[] = [
    {
      label: "Change Password",
      Icon: <PasswordIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/change-password"),
    },
    {
      label: "Device Management",
      Icon: <PhoneIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/device-management"),
    },
    {
      label: "Terms and Conditions",
      Icon: <FileIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/terms"),
    },
    {
      label: "Privacy Policy",
      Icon: <SecureIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/privacy"),
    },
  ];
  const supportLinks: Link[] = [
    {
      label: "FAQs",
      Icon: <InfoIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/faqs"),
    },
    {
      label: "Contact Support",
      Icon: <SupportIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => router.push("/(customer)/profile/contact"),
    },
  ];
  const accountManagementLinks: Link[] = [
    {
      label: "Log Out",
      Icon: <LogoutIcon width={16} height={16} color={PALETTE.primary} />,
      onPress: () => modalRef.open(),
    },
    {
      label: "Delete Account",
      Icon: <DeleteIcon width={16} height={16} color={PALETTE.error} />,
      onPress: () => router.push("/(customer)/profile/delete-account"),
    },
  ];
  return (
    <View style={styles.container}>
      <CustomModal
        ref={modalRef.ref}
        title="Log Out?"
        description="Are you sure you want to log out of your account?"
        onClose={modalRef.close}
        primaryButtonText="Log Out"
        secondaryButtonText="Cancel"
        secondaryAction={modalRef.close}
        primaryAction={handleLogout}
        primaryLoading={isLoading}
        Icon={<LogoutIcon width={16} height={16} color={PALETTE.primary} />}
      />
      <SelectAvatar
        ref={avatarRef.ref}
        onPress={avatarRef.close}
        closeModal={avatarRef.close}
      />
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <CustomText weight="bold" size="lg">
          Profile
        </CustomText>
      </LinearGradient>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          { paddingBottom: insets.bottom + TAB_BAR_HEIGHT },
        ]}
        onScroll={handleScroll}
      >
        <View style={styles.menu}>
          <View>
            <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
              <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                <Pressable onPress={avatarRef.open}>
                  <View style={{ position: "relative" }}>
                    <UserAvatar
                      url={user?.profilePicture}
                      source={
                        avatars.find((avatar) => avatar.id === user?.avatarId)
                          ?.url ?? avatars[0].url
                      }
                      name={`${user?.firstName} ${user?.lastName}`}
                    />
                    <View
                      style={[styles.edit, CUSTOM_STYLES.center]}
                    >
                      <PencilEditIcon width={14} height={14} />
                    </View>
                  </View>
                </Pressable>
              </View>
              <Pressable
                onPress={() => router.push("/(customer)/profile")}
                style={[CUSTOM_STYLES.flex]}
              >
                <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
                  <View style={{ gap: 4 }}>
                    <CustomText weight="semibold" style={styles.link}>
                      {`${user?.firstName} ${user?.lastName}`}
                      {user?.isVerified && (
                        <VerifiedIcon width={16} height={16} />
                      )}
                    </CustomText>
                    <CustomText
                      size="xs"
                      weight="medium"
                      style={{ opacity: 0.4 }}
                    >
                      {user?.email || user?.phoneNumber}
                    </CustomText>
                  </View>
                  <Arrow size={14} />
                </View>
              </Pressable>
            </View>
          </View>
        </View>
        <MenuItem title="My Account" links={myAccountLinks} />
        <MenuItem title="Security & Privacy" links={privacyLinks} />
        <MenuItem title="Help & Support" links={supportLinks} />
        <MenuItem title="Account Management" links={accountManagementLinks} />
      </ScrollView>
    </View>
  );
};

const MenuItem = ({ title, links }: { title: string; links: Link[] }) => {
  return (
    <View style={styles.menu}>
      <View style={styles.menuItem}>
        <CustomText style={styles.label} weight="semibold">
          {title}
        </CustomText>
        <View style={styles.links}>
          {links.map((link, index) => (
            <Pressable
              key={index}
              onPress={link.onPress}
              style={[
                {
                  borderBottomWidth: index + 1 !== links.length ? 1 : 0,
                  borderBottomColor:
                    index + 1 !== links.length
                      ? hexToRgba(PALETTE.black, 0.04)
                      : "transparent",
                  paddingVertical: 16,
                  paddingBottom: index + 1 !== links.length ? 16 : 0,
                },
              ]}
            >
              <View style={[CUSTOM_STYLES.row, styles.linkItem]}>
                <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                  {link.Icon}
                  <CustomText weight="medium" style={styles.link}>
                    {link.label}
                  </CustomText>
                </View>

                <Arrow size={14} />
              </View>
            </Pressable>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
    paddingHorizontal: 20,
  },
  edit: {
    width: 20,
    height: 20,
    borderRadius: 40,
    position: "absolute",
    backgroundColor: PALETTE.white,
    left: 24,
    top: 26,
  },
  menu: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    borderRadius: 6,
  },
  menuItem: {
    gap: 16,
  },
  label: {
    fontSize: 11,
    textTransform: "uppercase",
    opacity: 0.5,
  },
  links: {},
  linkItem: {
    justifyContent: "space-between",
    gap: 8,
  },
  link: {
    fontSize: 13,
  },
});
export default Profile;
