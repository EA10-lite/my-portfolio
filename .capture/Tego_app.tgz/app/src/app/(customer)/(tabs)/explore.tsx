import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { Header } from "@/modules/explore/components";
import { ActionModal } from "@/modules/home/components";
import { useUnreadCount } from "@/modules/notifications/hooks/useUnreadCount";
import {
  ProviderCardV2,
  ProviderCardV2Skeleton,
} from "@/modules/provider/components";
import { useProviders } from "@/modules/provider/hooks/useProviders";
import { useProviderFilterStore } from "@/modules/provider/store/providerFilter";
import { normalizeProviders } from "@/modules/provider/utils/normalizeProvider";
import { EmptyMessages } from "@/shared/components";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useUIStore } from "@/shared/store/uiStore";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import { FlatList, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Explore = () => {
  const { bottom } = useSafeAreaInsets();
  const { handleScroll } = useHideTabBarOnScroll();
  const { isLocationPopupOpen } = useUIStore();
  const { appliedFilters } = useProviderFilterStore();
  const [search, setSearch] = useState("");
  const [isFocused, setIsFocused] = useState<boolean>(false);

  const { count } = useUnreadCount();

  const {
    providers,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
    refetch,
  } = useProviders(appliedFilters);

  const filteredProviders = useMemo(() => {
    const query = search.toLowerCase().trim();
    const matches = providers?.filter(
      (p) =>
        p.provider.first_name.toLowerCase().includes(query) ||
        p.provider.last_name.toLowerCase().includes(query) ||
        p.service_category.name.toLowerCase().includes(query),
    );

    return normalizeProviders(matches);
  }, [search, providers]);

  const handleBookNow = (id: string) => {
    router.push(`/(customer)/booking/form?category_id=${id}`);
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: isLocationPopupOpen
            ? PALETTE.black
            : PALETTE.background,
        },
      ]}
    >
      <FlatList
        data={filteredProviders}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        onEndReachedThreshold={0.4}
        refreshing={isLoading}
        onRefresh={refetch}
        onEndReached={() => {
          if (hasNextPage && !isFetchingNextPage) fetchNextPage();
        }}
        ListHeaderComponent={
          <>
            {/* pulled back out to the edges, cancelling the 20px from contentContainerStyle */}
            <View
              style={{ backgroundColor: PALETTE.black, marginHorizontal: -20 }}
            >
              <Header
                search={search}
                setSearch={setSearch}
                isFocused={isFocused}
                setIsFocused={setIsFocused}
                notificationCount={count}
              />
            </View>

            <View style={{ height: 24 }} />
          </>
        }
        renderItem={({ item }) => (
          <ProviderCardV2
            item={item}
            handleBookNow={() => handleBookNow(item.service_category.id)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: 20, paddingBottom: bottom + TAB_BAR_HEIGHT },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <ProviderCardV2Skeleton />
              <ProviderCardV2Skeleton />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={{ gap: 20 }}>
              <ProviderCardV2Skeleton />
              <ProviderCardV2Skeleton />
              <ProviderCardV2Skeleton />
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <EmptyMessages
                title="No results found"
                description="We couldn't find any services matching your search."
                isInTabView={false}
              />
            </View>
          )
        }
      />

      <ActionModal />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  body: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 16,
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    backgroundColor: PALETTE.white,
  },
});

export default Explore;
