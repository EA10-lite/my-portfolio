import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { MessageCard, MessageCardSkeleton } from "@/modules/message/components";
import OfferMessageCard from "@/modules/message/components/OfferMessageCard";
import { useConversations } from "@/modules/message/hooks/useConversations";
import { useOfferMessages } from "@/modules/message/hooks/useOfferMessages";
import {
  CustomSearchInput,
  CustomText,
  EmptyMessages,
} from "@/shared/components";
import { CustomTabs } from "@/shared/containers";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { formatMessageDate } from "@/shared/utils/formatter";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useMemo, useRef, useState } from "react";
import { Animated, FlatList, Keyboard, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const MESSAGE_FILTER = [
  { label: "All", value: "all" },
  { label: "Unread", value: "unread" },
  { label: "Offers", value: "offers" },
];

const Message = () => {
  const { chats, isLoading, markAsRead } = useConversations();
  const { offers, isLoading: isOfferLoading } = useOfferMessages();

  const { type } = useLocalSearchParams<{
    type?: string;
  }>()

  const insets = useSafeAreaInsets();
  const { handleScroll } = useHideTabBarOnScroll();

  const [search, setSearch] = useState<string>("");
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [activeFilter, setActiveFilter] = useState(type ? type : "all");

  const scrollY = useRef(new Animated.Value(0)).current;

  // 🔥 Collapsing height
  const searchBarHeight = scrollY.interpolate({
    inputRange: [0, 57],
    outputRange: [57, 0],
    extrapolate: "clamp",
  });

  const searchBarOpacity = scrollY.interpolate({
    inputRange: [0, 40],
    outputRange: [1, 0],
    extrapolate: "clamp",
  });

  const filteredMessages = useMemo(() => {
    if (activeFilter === "unread")
      return chats.filter((message) => message.unread_count > 0);
    return chats;
  }, [activeFilter, chats]);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.headerContainer, { paddingTop: insets.top + 84 }]}
      >
        <View style={styles.header}>
          <View style={{ paddingHorizontal: 20, gap: 16 }}>
            <CustomText size="xl" weight="semibold">
              Messages
            </CustomText>
            {/* 🔥 Collapsible Search */}
            <Animated.View
              style={{
                height: searchBarHeight,
                opacity: searchBarOpacity,
                overflow: "hidden",
              }}
            >
              <View style={styles.searchBox}>
                <CustomSearchInput
                  value={search}
                  setIsFocused={setIsFocused}
                  isFocused={isFocused}
                  onChange={setSearch}
                  placeholder="Search message"
                />
              </View>
            </Animated.View>
          </View>

          {/* 🔥 Tabs (always visible) */}
          <CustomTabs
            tabs={MESSAGE_FILTER}
            onTabChange={setActiveFilter}
            activeTab={activeFilter}
          />
        </View>
      </LinearGradient>

      {/* 🔥 Animated Scroll */}
      {activeFilter !== "offers" && (
        <FlatList
          data={filteredMessages}
          keyExtractor={(message, index) => String(message.contact_id ?? index)}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[
            styles.body,
            styles.bodyContent,
            { paddingBottom: insets.bottom + TAB_BAR_HEIGHT },
          ]}
          onScroll={(event) => {
            handleScroll(event);
            Animated.event(
              [{ nativeEvent: { contentOffset: { y: scrollY } } }],
              {
                useNativeDriver: false,
              },
            )(event);
          }}
          onScrollBeginDrag={Keyboard.dismiss}
          scrollEventThrottle={16}
          ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
          renderItem={({ item: message, index }) => (
            <MessageCard
              key={message.contact_id || index}
              user={{
                name: `${message.first_name} ${message.last_name}`,
                url: message.profile_picture || "",
              }}
              date={formatMessageDate(message.last_message_at)} // ✅ formatted
              isRead={message.unread_count === 0}
              isActive={message.available_status === "ONLINE"}
              message={
                message.last_message_type === "IMAGE"
                  ? message.last_message
                    ? `📷 ${message.last_message}` // has caption
                    : "📷 Photo"
                  : message.last_message
              }
              chatId={message.contact_id}
              currentMessage={message.unread_count}
              goToChat={() => {
                markAsRead(message.contact_id); // ✅ reset unread on tap
                // router.push(`/message/${message.contact_id}`);
                router.push({
                  pathname: `/message/${message.contact_id}` as any,
                  params: {
                    receiverId: message.contact_id,
                    name: `${message.first_name} ${message.last_name}`,
                    avatar: message.profile_picture ?? "",
                    isOnline:
                      message.available_status === "ONLINE" ? "true" : "false",
                  },
                });
              }}
              isNegotation={false}
            />
          )}
          ListEmptyComponent={
            isLoading ? (
              <View style={{ gap: 14 }}>
                <MessageCardSkeleton />
                <MessageCardSkeleton />
              </View>
            ) : (
              <View style={[CUSTOM_STYLES.flex]}>
                <EmptyMessages
                  title={"No message yet"}
                  description={"You don't have any message yet."}
                />
              </View>
            )
          }
        />
      )}

      {activeFilter === "offers" && (
        <FlatList
          data={offers}
          keyExtractor={(message, index) =>
            String(message.job_request_id ?? message.book_service_id ?? index)
          }
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[
            styles.body,
            styles.bodyContent,
            {
              paddingBottom: insets.bottom + TAB_BAR_HEIGHT,
              paddingHorizontal: 20,
            },
          ]}
          onScroll={(event) => {
            handleScroll(event);
            Animated.event(
              [{ nativeEvent: { contentOffset: { y: scrollY } } }],
              {
                useNativeDriver: false,
              },
            )(event);
          }}
          onScrollBeginDrag={Keyboard.dismiss}
          scrollEventThrottle={16}
          ItemSeparatorComponent={() => <View style={{ height: 14 }} />}
          renderItem={({ item: message, index }) => (
            <OfferMessageCard
              key={index}
              user={{
                name: `${message.user.first_name} ${message.user.last_name}`,
                url: message.user.profile_picture || "",
              }}
              date={formatMessageDate(message.last_message_at)} // ✅ formatted
              isRead={message.unread_count === 0}
              isActive={message.user.available_status === "ONLINE"}
              message={message.last_offer.message}
              chatId={message.job_request_id ?? message.book_service_id}
              currentMessage={message.unread_count}
              goToChat={() => {
                markAsRead(message.job_request_id ?? message.book_service_id); // ✅ reset unread on tap
                // router.push(`/message/${message.contact_id}`);
                router.push({
                  pathname:
                    `/message/${message.job_request_id ?? message.book_service_id}/offer` as any,
                  params: {
                    receiverId: message.user.id,
                    name: `${message.user.first_name} ${message.user.last_name}`,
                    avatar: message.user.profile_picture ?? "",
                    isOnline:
                      message.user.available_status === "ONLINE"
                        ? "true"
                        : "false",
                  },
                });
              }}
              isNegotation={false}
              status={message.last_offer.status}
            />
          )}
          ListEmptyComponent={
            isOfferLoading ? (
              <View style={{ gap: 14 }}>
                <MessageCardSkeleton />
                <MessageCardSkeleton />
              </View>
            ) : (
              <View style={[CUSTOM_STYLES.flex]}>
                <EmptyMessages
                  title={"No message yet"}
                  description={"You don't have any message yet."}
                />
              </View>
            )
          }
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  headerContainer: {
    paddingBottom: 10,
  },
  header: {
    gap: 16,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  body: {
    marginTop: 20,
  },
  bodyContent: {
    flexGrow: 1,
  },
});

export default Message;
