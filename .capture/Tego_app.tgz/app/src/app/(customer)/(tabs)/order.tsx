import { PALETTE } from "@/constants/colors";
import { TAB_BAR_HEIGHT } from "@/constants/values";
import { useBookingActions } from "@/modules/booking/hooks/useBookingActions";
import { ActionModal } from "@/modules/home/components";
import { CancelRequest } from "@/modules/job/components";
import { useUnreadCount } from "@/modules/notifications/hooks/useUnreadCount";
import { OrderCard, OrderCardSkeleton } from "@/modules/order/components";
import { useAllOrders } from "@/modules/order/hooks/useAllOrders";
import { useOrderActions } from "@/modules/order/hooks/useOrderActions";

import { NormalizedOrder } from "@/modules/order/types/order.dto";
import { useJobRequestActions } from "@/modules/request-job/hooks/useJobRequestActions";
import { EmptyMessages, Header } from "@/shared/components";
import { CustomTabs } from "@/shared/containers";
import { useHideTabBarOnScroll } from "@/shared/hooks/useHideTabBarOnScroll";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import { useUIStore } from "@/shared/store/uiStore";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import { FlatList, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ORDERS = [
  { label: "All", value: "all", count: 0 },
  { label: "Active", value: "IN_PROGRESS", count: 0 },
  { label: "Pending", value: "PENDING", count: 0 },
  { label: "Completed", value: "COMPLETED", count: 0 },
  { label: "Cancelled", value: "CANCELLED", count: 0 },
];

type ModalState = "cancel" | "confirmed" | null;

const Orders = () => {
  const { bottom } = useSafeAreaInsets();
  const { handleScroll } = useHideTabBarOnScroll();
  const { isLocationPopupOpen } = useUIStore();
  const { showToast } = useToastStore();
  const [search, setSearch] = useState<string>("");
  const [modalState, setModalState] = useState<ModalState>(null);
  const [selectedType, setSelectedType] =
    useState<NormalizedOrder["type"]>("Booking");
  const [activeTab, setActiveTab] = useState<string>("all");
  const [id, setId] = useState<string | null>(null);

  const { count } = useUnreadCount();

  const {
    orders,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
    refetch,
  } = useAllOrders(activeTab);
  const { cancel: cancelBooking, isSubmitting: cancellingBooking } =
    useBookingActions();
  const { cancel: cancelRequest, isSubmitting: cancellingRequest } =
    useJobRequestActions();

  const { cancelOrder, isSubmitting: isOrderSubmitting } = useOrderActions();

  const filteredOrders = useMemo(() => {
    if (!search) return orders;
    return orders.filter((order) =>
      order.title.toLowerCase().includes(search.toLowerCase()),
    );
  }, [orders, search]);

  const sheetRef = useModalState();

  const openCancelModal = (type: NormalizedOrder["type"], id: string) => {
    setSelectedType(type);
    setModalState("cancel");
    setId(id);
    sheetRef.open();
  };

  const handleConfirmCancel = () => {
    if (id) {
      if (selectedType === "Booking") {
        cancelBooking(id, {
          onSuccess: () => {
            setId(null);
            setModalState("confirmed");
          },
        });
      } else {
        cancelRequest(id, {
          onSuccess: () => {
            setId(null);
            setModalState("confirmed");
          },
        });
      }
    }
  };

  const sendCancellationRequest = (id: string) => {
    cancelOrder(
      { id },
        {
          onSuccess: () => {
            showToast(
              "Cancellation request sent",
              "Customer has been notified that you want to cancel this order"
            )
          },
        },
    )
  }

  const handleCreateNew = () => {
    sheetRef.close();
    setModalState(null);
    router.push(
      selectedType === "Booking"
        ? "/(customer)/booking/form"
        : "/(customer)/request-job",
    );
  };

  const handleGoBack = () => {
    sheetRef.close();
    setModalState(null);
    setId(null);
  };

  const [openOrderId, setOpenOrderId] = useState<string | null>(null);

  /**
   * Toggle an order.
   *
   * If the selected order is already open,
   * close it.
   *
   * Otherwise, make it the only open order.
   */
  const handleOrderToggle = (orderId: string) => {
    setOpenOrderId((currentId) =>
      currentId === orderId ? null : orderId,
    );
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: isLocationPopupOpen
            ? PALETTE.black
            : PALETTE.background,
        },
      ]}
    >
      <CancelRequest
        ref={sheetRef.ref}
        title={
          modalState === "cancel"
            ? `Cancel ${selectedType}?`
            : `${selectedType} Cancelled`
        }
        description={
          modalState === "cancel"
            ? `Are you sure you want to cancel this ${selectedType}? You'll stop receiving applications from providers.`
            : `This ${selectedType} is no longer active. You can create a new request anytime.`
        }
        type={modalState === "confirmed" ? "warning" : undefined}
        primaryAction={modalState === "cancel" ? handleGoBack : handleCreateNew}
        secondaryAction={
          modalState === "cancel" ? handleConfirmCancel : handleGoBack
        }
        onClose={handleGoBack}
        primaryButtonText={
          modalState === "cancel" ? `Keep ${selectedType}` : "Create New"
        }
        secondaryButtonText={
          modalState === "cancel" ? undefined : "Back to order"
        }
        secondaryButtonLoadingState={cancellingBooking || cancellingRequest}
      />

      <FlatList
        data={filteredOrders}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        onScroll={handleScroll}
        onEndReachedThreshold={0.4}
        refreshing={isLoading}
        onRefresh={refetch}
        onEndReached={() => {
          if (hasNextPage && !isFetchingNextPage) fetchNextPage();
        }}
        ListHeaderComponent={
          <>
            {/* pulled back out to the edges, cancelling the 20px from contentContainerStyle */}
            <View
              style={{ backgroundColor: PALETTE.black, marginHorizontal: -20 }}
            >
              <Header
                search={search}
                setSearch={setSearch}
                placeholder="Search categories, services..."
                title="Track everything in one place"
                notificationCount={count}
              />
            </View>

            <CustomTabs
              tabs={ORDERS}
              activeTab={activeTab}
              onTabChange={setActiveTab}
              style={{ marginHorizontal: -10 }}
            />

            <View style={{ height: 24 }} />
          </>
        }
        renderItem={({ item }) => (
          <OrderCard
            order={item}
            onCancel={
              () => item.type === "Order"
                ? sendCancellationRequest(item.id)
                : openCancelModal(item.type, item.id)
            }
            isOpen={openOrderId === item.id}
            onToggle={() =>
              handleOrderToggle(item.id)
            }
            viewDetails={() => {
              if (item.type === "Request") {
                router.push(`/(customer)/request-job/${item.id}`);
              } else {
                router.push(`/(customer)/order/${item.id}?type=${item.type}`);
              }
            }}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: 20, paddingBottom: bottom + TAB_BAR_HEIGHT },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <OrderCardSkeleton />
              <OrderCardSkeleton />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={{ gap: 20 }}>
              <OrderCardSkeleton />
              <OrderCardSkeleton />
              <OrderCardSkeleton />
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <EmptyMessages
                description="Book or request a service to get started"
                title="No activity yet"
                isInTabView={false}
              />
            </View>
          )
        }
      />
      <ActionModal />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { marginTop: 24, gap: 20, paddingHorizontal: 20, flexGrow: 1 },
  scrollContent: {
    flexGrow: 1,
    backgroundColor: PALETTE.white,
  },
});

export default Orders;
