import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useBookingActions } from "@/modules/booking/hooks/useBookingActions";
import { useBookingStore } from "@/modules/booking/store/booking.store";
import { CancelRequest } from "@/modules/job/components";
import { Activity } from "@/modules/job/tabs";
import { Overview, ReviewModal } from "@/modules/order/components";
import { useOrder } from "@/modules/order/hooks/useOrder";
import { useOrderActions } from "@/modules/order/hooks/useOrderActions";
import { ReviewData } from "@/modules/order/services/order.service";
import { RequestDetailsSkeleton } from "@/modules/request-job/components";
import { useJobRequestActions } from "@/modules/request-job/hooks/useJobRequestActions";
import {
  CustomButton,
  CustomText,
  GoBack,
  NotFound,
  SuccessSheet,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { useToastStore } from "@/shared/store/toastStore";
import { formatCurrency } from "@/shared/utils/formatter";
import { STATUS } from "@/shared/utils/type";
import Ionicons from "@expo/vector-icons/Ionicons";
import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type ORDER_TYPE = "Booking" | "Request";
type ModalState = "cancel" | "cancelled" | "complete" | "completed" | null;

const OrderDetails = () => {
  const { user } = useAuthStore();
  const insets = useSafeAreaInsets();
  const sheetRef = useModalState();
  const successRef = useModalState();
  const reviewRef = useModalState();
  const { showToast } = useToastStore();
  const [modalState, setModalState] = useState<ModalState>(null);

  const { type, id } = useLocalSearchParams();
  const [selectedType, setSelectedType] = useState<ORDER_TYPE>(
    type.toString() as ORDER_TYPE,
  );

  const { order, isLoading } = useOrder(
    id.toString(),
    type.toString() as "Booking" | "Request" | "Order",
  );

  const { cancel, isSubmitting: isCancelling } = useJobRequestActions();
  const { update, isSubmitting: isUpdating } = useBookingActions();
  const {
    update: updateOrder,
    isSubmitting: isOrderSubmitting,
    review,
    isReviewing,
    approveCancellation,
    rejectCancellation,
    cancelOrder: sendCancellationRequest,
  } = useOrderActions();
  const { setProvider } = useBookingStore();

  const cancelOrder = () => {
    if (id) {
      sendCancellationRequest(
        { id: id.toString() },
        {
          onSuccess: () => {
            showToast(
              "Cancellation request sent",
              "Customer has been notified that you want to cancel this order"
            )
          },
        },
      );
    }
  };

  const openCancelModal = () => {
    setSelectedType(type as ORDER_TYPE);
    setModalState("cancel");
    sheetRef.open();
  };

  const openCompleteModal = () => {
    setSelectedType(type as ORDER_TYPE);
    setModalState("complete");
    sheetRef.open();
  };

  const rejectCancellationRequest = () => {
    rejectCancellation(
      { id: id.toString() },
      {
        onSuccess: () => {
          showToast(
            "Cancellation Rejected",
            `You rejected the cancellation request sent by the ${order?.cancellation_requested_by}`
          )
        },
      },
    );
  }

  const handleConfirmCancel = () => {
    if (type === "Booking" && order?.status === "CANCELLATION_REQUESTED") {
      update(
        { id: id.toString(), status: "CANCELLED" },
        {
          onSuccess: () => {
            setModalState("cancelled");
          },
        },
      );
    }
    if (type === "Request") {
      cancel(id.toString(), {
        onSuccess: () => {
          setModalState("cancelled");
        },
      });
    }
    if (type === "Order") {
      approveCancellation(
        { id: id.toString() },
        {
          onSuccess: () => {
            setModalState("cancelled")
          },
        },
      );
    }
  };

  const handleCreateNew = () => {
    sheetRef.close();
    setModalState(null);
    router.push(
      selectedType.toLowerCase() === "booking"
        ? "/(customer)/booking/form"
        : "/(customer)/request-job",
    );
  };

  const handleGoBack = () => {
    sheetRef.close();
    setModalState(null);
  };

  const openReview = () => reviewRef.open();
  const closeReview = () => reviewRef.close();

  const submitReview = (values: ReviewData) => {
    if (type === "Order") {
      review(
        { id: id.toString(), data: values },
        {
          onSuccess: () => {
            successRef.open();
          },
        },
      );
    }
  };

  const closeSuccess = () => successRef.close();

  const completeOrder = () => {
    updateOrder(
      { id: id.toString(), status: "COMPLETED" },
      {
        onSuccess: () => {
          setModalState("completed");
        },
      },
    );
  };

  const handleRehire = () => {
    if (type === "Order" && order?.details.provider) {
      setProvider(order?.details.provider);
      router.push(`/(customer)/booking/form`);
    }
  };

  const getPrice = (): string => {
    if (order?.offers[0]?.offer?.price) {
      return formatCurrency(order?.offers[0]?.offer?.price);
    }
    if(order?.details.budget) {
      return order.details.budget
    }
    return "Quote";
  };

  if (isLoading) return <RequestDetailsSkeleton />;
  if (!order) return <NotFound />;

  return (
    <View style={styles.container}>
      <CancelRequest
        ref={sheetRef.ref}
        title={
          modalState === "cancel"
            ? `Cancel ${selectedType}?`
            : modalState === "cancelled"
              ? `${selectedType} Cancelled`
              : modalState === "complete"
                ? `Complete ${selectedType}?`
                : modalState === "completed"
                  ? `${selectedType} Completed`
                  : ""
        }
        description={
          modalState === "cancel"
            ? `Are you sure you want to cancel this ${selectedType}? You'll stop receiving applications from providers.`
            : modalState === "cancelled"
              ? `This ${selectedType} is no longer active. You can create a new request anytime.`
              : modalState === "complete"
                ? `Are you sure you want to complete this ${selectedType}? This will mark the order as completed.`
                : modalState === "completed"
                  ? `This ${selectedType} has been successfully completed.`
                  : ""
        }
        type={
          modalState === "cancelled"
            ? "warning"
            : modalState === "complete" || modalState === "completed"
              ? "success"
              : undefined
        }
        primaryAction={
          modalState === "cancel"
            ? handleGoBack
            : modalState === "complete"
              ? handleGoBack
              : handleCreateNew
        }
        secondaryAction={
          modalState === "cancel"
            ? handleConfirmCancel
            : modalState === "complete"
              ? completeOrder
              : handleGoBack
        }
        onClose={handleGoBack}
        primaryButtonText={
          modalState === "cancel"
            ? `Keep ${selectedType}`
            : modalState === "cancelled"
              ? "Create New"
              : modalState === "complete"
                ? `Keep ${selectedType}`
                : modalState === "completed"
                  ? "Done"
                  : ""
        }
        secondaryButtonText={
          modalState === "cancel"
            ? "Cancel"
            : modalState === "complete"
              ? "Complete"
              : modalState === "cancelled" || modalState === "completed"
                ? "Back to order"
                : undefined
        }
        secondaryButtonLoadingState={
          isUpdating || isCancelling || isOrderSubmitting
        }
      />
      <ReviewModal
        ref={reviewRef.ref}
        closeModal={closeReview}
        handleSubmit={submitReview}
        loading={isReviewing}
        user={{
          name: order.details.provider?.name ?? "",
          avatar: order.details.provider?.profile_picture ?? "",
          is_verified: order.details.provider?.is_verified ?? false,
          address: order.details.provider?.location ?? "",
        }}
      />

      <SuccessSheet
        ref={successRef.ref}
        title="Review Submitted"
        description="Thanks for sharing your experience. Your feedback helps others make better decisions."
        onContinue={closeSuccess}
        buttonText="Ok, Got it"
        variant="primary"
        showClose={false}
        showConfetti={true}
      />
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <GoBack handleGoBack={() => router.back()} />
        <View style={{ gap: 8 }}>
          <CustomText
            weight="semibold"
            size="xs"
            style={{
              opacity: 0.5,
              textTransform: "uppercase",
              letterSpacing: -0.24,
            }}
          >
            {type === "Booking"
              ? "Booking Details"
              : type === "Request"
                ? "Request Details"
                : "Order Details"}
          </CustomText>
          <CustomText weight="bold" size="lg">
            {order.title}
          </CustomText>
          <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
            <Ionicons name="location-sharp" size={14} color={PALETTE.black} />
            <CustomText weight="regular" style={styles.location}>
              {order.location}
            </CustomText>
          </View>
        </View>
      </LinearGradient>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.body,
          { paddingBottom: insets.bottom + 60 },
        ]}
      >
        {order.activities.length > 0 && (
          <Activity
            offers={order.offers}
            handleViewOffer={() => {}}
            status={order.status as STATUS}
            activities={order.activities}
            type={type.toString()}
          />
        )}
        <Overview
          title="Request Summary"
          item={{
            ...order.details,
            budget: getPrice(),
            provider: order.details.provider?.name,
          }}
        />
      </ScrollView>
      <View
        style={[styles.footerContainer, { paddingBottom: insets.bottom || 24 }]}
      >
        {order.status.toLowerCase() === "completed" && (
          <View style={[styles.buttons, CUSTOM_STYLES.row, { gap: 12 }]}>
            <CustomButton
              title="Add Review"
              variant="secondary"
              style={CUSTOM_STYLES.flex}
              onPress={openReview}
            />
            <CustomButton
              title="Rehire"
              style={CUSTOM_STYLES.flex}
              onPress={handleRehire}
            />
          </View>
        )}
        {(order.status.toLowerCase() === "pending" ||
          order.status.toLowerCase() === "in_progress" ||
          order.status.toLowerCase() === "awaiting_provider") && (
          <CustomButton
            title={`Cancel ${type}`}
            onPress={type === "Order" ? cancelOrder : openCancelModal}
          />
        )}

        {order.status.toLowerCase() === "completion_requested" && (
          <CustomButton title={`Complete Order`} onPress={openCompleteModal} />
        )}
        {
          order.status.toLowerCase() === "cancellation_requested" &&
          order.cancellation_requested_by_user_id !== user?.id && (
            <View style={[CUSTOM_STYLES.row, { gap: 12 }]}>
              <CustomButton
                title="Reject"
                variant="default"
                onPress={rejectCancellationRequest}
                disabled={isOrderSubmitting}
                style={CUSTOM_STYLES.flex}
              />
              <CustomButton
                title="Approve"
                variant="primary"
                onPress={openCancelModal}
                disabled={isOrderSubmitting}
                style={CUSTOM_STYLES.flex}
              />
            </View>
          )
        }
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  location: {
    fontSize: 13,
  },
  body: {
    paddingHorizontal: 20,
    marginTop: 34,
    gap: 34,
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 48,
    gap: 12,
  },
  buttons: {},
});

export default OrderDetails;
