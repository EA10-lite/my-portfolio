import DoubleCheckMark from "@/assets/images/app-icons/double-checkmark.svg";

import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";

import {
  Notification,
  NotificationModal,
} from "@/modules/notifications/components";
import { useNotificationActions } from "@/modules/notifications/hooks/useNotificationActions";

import { useNotifications } from "@/modules/notifications/hooks/useNotifications";

import {
  NOTIFICATION_TYPE,
  NotificationItem,
} from "@/modules/notifications/types/notification.dto";

import { groupNotificationsByDate } from "@/modules/notifications/utils/getter";

import {
  CustomButton,
  CustomText,
  EmptyMessages,
  GoBack,
} from "@/shared/components";
import { CustomTabs } from "@/shared/containers";

import { useModalState } from "@/shared/hooks/useModalState";

import Octicons from "@expo/vector-icons/Octicons";
import SimpleLineIcons from "@expo/vector-icons/SimpleLineIcons";

import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";

import { useEffect, useMemo, useState } from "react";

import {
  ActivityIndicator,
  Pressable,
  SectionList,
  StyleSheet,
  View,
} from "react-native";

import { useSafeAreaInsets } from "react-native-safe-area-context";

const NOTIFICATION_FILTER = [
  { label: "All", value: "all" },
  { label: "Requests", value: "SERVICE_BOOKING" },
  { label: "Orders", value: "ORDER" },
  { label: "Job Requests", value: "JOB_REQUEST" },
  { label: "Support", value: "MESSAGE" },
  { label: "Reviews", value: "REVIEW" },
  { label: "Tickets", value: "TICKET" },
  { label: "System", value: "SYSTEM" },
] as const;

const NOTIFICATION_LABELS: Record<
  "all" | NOTIFICATION_TYPE,
  string
> = {
  all: "All",
  SERVICE_BOOKING: "Requests",
  ORDER: "Orders",
  JOB_REQUEST: "Job Requests",
  MESSAGE: "Support",
  REVIEW: "Reviews",
  TICKET: "Tickets",
  SUBSCRIPTION: "Subscriptions",
  SYSTEM: "System",
};

const Notifications = () => {
  const insets = useSafeAreaInsets();

  const [activeFilter, setActiveFilter] = useState<
    "all" | NOTIFICATION_TYPE
  >("all");

  const {
    notifications,
    count,
    isFetchingNextPage,
    hasNextPage,
    isLoading,
    fetchNextPage,
    refetch,
  } = useNotifications(
    activeFilter === "all" ? undefined : activeFilter,
  );

  const {
    markNotification,
    isSubmitting,
    markAllNotifications
  } = useNotificationActions();

  const [selectedNotification, setSelectedNotification] =
    useState<NotificationItem | null>(null);

  const notificationModal = useModalState();

  const handleNotificationPress = (
    notification: NotificationItem,
  ) => {
    markNotification(notification.id);
    setSelectedNotification(notification);
  };

  useEffect(() => {
    if (selectedNotification) {
      notificationModal.open();
    }
  }, [selectedNotification]);

  const handleCloseModal = () => {
    setSelectedNotification(null);
    notificationModal.close();
  };

  /**
   * Group the paginated notifications by date.
   *
   * `notifications` already contains all loaded pages,
   * so newly fetched pages will automatically be included.
   */
  const sections = useMemo(() => {
    const grouped = groupNotificationsByDate(notifications);

    return Object.entries(grouped).map(([title, data]) => ({
      title,
      data,
    }));
  }, [notifications]);

  const hasUnread = useMemo(
    () =>
      notifications.some(
        (notification) => !notification.is_read,
      ),
    [notifications],
  );

  const goToSettings = () => {
    router.push("/profile/notifications");
  };

  const tabs = useMemo(() => {
    return NOTIFICATION_FILTER.map((filter) => {
      if (filter.value === "all") {
        return {
          ...filter,
          count: count.reduce(
            (total, item) => total + item.unread_count,
            0,
          ),
        };
      }

      const countItem = count.find(
        (item) => item.type === filter.value,
      );

      return {
        ...filter,
        count: countItem?.unread_count ?? 0,
      };
    });
  }, [count]);

  const handleTabChange = (tab: string) => {
    setActiveFilter(tab as "all" | NOTIFICATION_TYPE);
  };

  const activeFilterLabel =
    NOTIFICATION_LABELS[activeFilter];

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[
          "rgba(51, 171, 247, 0.232)",
          "rgba(255, 255, 255, 0.255)",
        ]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[
          styles.header,
          {
            paddingTop: insets.top + 32,
          },
        ]}
      >
        <View
          style={{
            paddingHorizontal: 20,
            gap: 34,
          }}
        >
          <View style={styles.row}>
            <GoBack />

            <Pressable onPress={goToSettings} hitSlop={14}>
              <SimpleLineIcons
                name="settings"
                size={20}
                color={PALETTE.black}
              />
            </Pressable>
          </View>

          <CustomText
            weight="bold"
            size="lg"
          >
            Notifications
          </CustomText>
        </View>

        <CustomTabs
          tabs={tabs}
          activeTab={activeFilter}
          onTabChange={handleTabChange}
        />
      </LinearGradient>
      <SectionList
        sections={sections}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        stickySectionHeadersEnabled={false}
        onEndReachedThreshold={0.4}
        onRefresh={refetch}
        refreshing={isLoading}
        onEndReached={() => {
          if (
            hasNextPage &&
            !isFetchingNextPage &&
            !isLoading
          ) {
            fetchNextPage();
          }
        }}
        ListHeaderComponent={
          <>
            <View style={{ height: 24 }} />
          </>
        }
        renderSectionHeader={({ section }) => (
          <View style={styles.sectionHeader}>
            <CustomText
              size="sm"
              weight="semibold"
            >
              {section.title}
            </CustomText>
          </View>
        )}
        renderItem={({ item }) => (
          <View style={styles.content}>
            <Notification
              notification={item}
              handlePress={() =>
                handleNotificationPress(
                  item as NotificationItem,
                )
              }
            />
          </View>
        )}
        ItemSeparatorComponent={() => (
          <View style={{ height: 16 }} />
        )}
        SectionSeparatorComponent={() => (
          <View style={{ height: 24 }} />
        )}
        contentContainerStyle={[
          {
            paddingBottom:
              insets.bottom + 100,
              ...(sections.length === 0 && {
                flexGrow: 1,
              }),
          },
        ]}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View
              style={[
                CUSTOM_STYLES.flex,
                CUSTOM_STYLES.center,
                styles.loadingMore,
              ]}
            >
              <ActivityIndicator size="small" />
            </View>
          ) : null
        }
        ListEmptyComponent={
          isLoading ? (
            <View style={styles.loadingContainer}>
            </View>
          ) : (
            <View style={styles.emptyContainer}>
              <EmptyMessages
                title={
                  activeFilter === "all"
                    ? "No notifications yet"
                    : `No ${activeFilterLabel.toLowerCase()} notifications`
                }
                description={
                  activeFilter === "all"
                    ? "Bookings and updates will appear here."
                    : `You have no ${activeFilterLabel.toLowerCase()} notifications at this time.`
                }
                Icon={() => (
                  <Octicons
                    name="bell"
                    size={20}
                    color={PALETTE.primary}
                  />
                )}
              />
            </View>
          )
        }
      />

      {hasUnread && (
        <View
          style={[
            styles.button,
            {
              bottom: insets.bottom + 20,
            },
          ]}
        >
          <CustomButton
            title="Mark all read"
            size="sm"
            variant="default"
            Icon={() => (
              <DoubleCheckMark
                width={18}
                height={18}
                color={PALETTE.white}
              />
            )}
            onPress={markAllNotifications}
            loading={isSubmitting}
            style={{
              paddingVertical: 12,
            }}
          />
        </View>
      )}

      <NotificationModal
        ref={notificationModal.ref}
        notification={selectedNotification}
        onClose={handleCloseModal}
        isOpen={notificationModal.isOpen}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },

  header: {
    paddingBottom: 10,
    gap: 20,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  content: {
    paddingHorizontal: 20,
  },

  sectionHeader: {
    paddingHorizontal: 20,
  },

  section: {
    gap: 16,
  },

  loadingContainer: {
    gap: 20,
    flex: 1,
  },

  loadingMore: {
    paddingVertical: 20,
  },

  emptyContainer: {
    flex: 1,
  },

  button: {
    position: "absolute",
    minWidth: 137,
    maxWidth: 157,
    right: 20,
  },
});

export default Notifications;