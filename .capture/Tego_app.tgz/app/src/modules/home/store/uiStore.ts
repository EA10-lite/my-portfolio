import { create } from "zustand";

type UIState = {
  isMessageWarning: boolean;
  setMessageWarning: (value: boolean) => void;
  isLocationPopupOpen: boolean;
  setLocationPopupOpen: (value: boolean) => void;
};

export const useUIStore = create<UIState>((set) => ({
  isMessageWarning: true,
  setMessageWarning: (value) => set({ isMessageWarning: value }),
  isLocationPopupOpen: false,
  setLocationPopupOpen: (value) => set({ isLocationPopupOpen: value }),
}));
