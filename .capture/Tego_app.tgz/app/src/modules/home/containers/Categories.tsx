import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Category,
  CategoryCardSkeleton,
} from "@/modules/categories/components";
import { CategoryDTO } from "@/modules/categories/types/category.dto";
import { Arrow, CustomText } from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { router } from "expo-router";
import {
  Animated,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  UIManager,
  View,
} from "react-native";

// required for Android
if (Platform.OS === "android") {
  UIManager.setLayoutAnimationEnabledExperimental?.(true);
}

interface CategoriesProps {
  data: CategoryDTO[];
  isMostBooked?: boolean;
  isLoading: boolean;
}

const Categories = ({
  data,
  isMostBooked = false,
  isLoading,
}: CategoriesProps) => {
  const {
    rotate,
    setShowContent,
    contentHeight,
    setContentHeight,
    animatedHeight,
  } = useExpandableAnimation();

  const toggle = () => {
    setShowContent((prev) => !prev);
  };

  return (
    <View style={styles.container}>
      {(data.length > 0 || isLoading) && (
        <View style={styles.heading}>
          {!isMostBooked ? (
            <Pressable onPress={() => router.push("/(customer)/categories")}>
              <View style={styles.headingText}>
                <CustomText size="sm" weight="semibold">
                  Categories
                </CustomText>
                <Arrow direction="right" color={PALETTE.black} />
              </View>
            </Pressable>
          ) : (
            <CustomText size="sm" weight="semibold">
              Most Booked Categories
            </CustomText>
          )}

          {!isMostBooked && (
            <Pressable
              onPress={toggle}
              style={[CUSTOM_STYLES.toggleButton, CUSTOM_STYLES.center]}
              hitSlop={12}
            >
              <Animated.View
                style={[
                  CUSTOM_STYLES.toggleButton,
                  CUSTOM_STYLES.center,
                  {
                    transform: [{ rotate }],
                  },
                ]}
              >
                <Arrow direction={"bottom"} color={PALETTE.primary} size={18} />
              </Animated.View>
            </Pressable>
          )}
        </View>
      )}

      <Animated.View
        style={[
          {
            height: animatedHeight,
            overflow: "hidden",
          },
        ]}
      >
        <View
          onLayout={(event) => {
            const height = event.nativeEvent.layout.height;

            if (height > 0 && height !== contentHeight) {
              setContentHeight(height);
            }
          }}
          style={{
            position: "absolute",
            width: "100%",
            marginTop: 17,
            paddingBottom: 20,
          }}
        >
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 20, paddingHorizontal: 20 }}
          >
            {isLoading
              ? [1, 2, 3].map((_, index) => (
                  <CategoryCardSkeleton key={index} />
                ))
              : data.map((category) => (
                  <Category key={category.id} item={category} />
                ))}
          </ScrollView>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  heading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
  },
  headingText: { flexDirection: "row", alignItems: "center", gap: 2 },
});

export default Categories;
