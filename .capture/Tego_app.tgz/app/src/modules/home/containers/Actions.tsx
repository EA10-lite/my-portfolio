import BookServiceIcon from "@/assets/images/app-icons/book-service.svg";
import RequestServiceIcon from "@/assets/images/app-icons/request-service.svg";
import { router } from "expo-router";
import { ScrollView } from "react-native";
import { Action } from "../components";

const ACTIONS = [
  {
    id: 1,
    label: "Book a\nService",
    icon: BookServiceIcon,
    onPress: () => router.push("/(customer)/booking/"),
  },
  {
    id: 2,
    label: "Request\nService",
    icon: RequestServiceIcon,
    onPress: () => router.push("/(customer)/request-job"),
  },
  // {
  //   id: 3,
  //   label: "Post\nJob",
  //   icon: PostJobIcon,
  //   onPress: () => router.push("/(customer)/post-job"),
  // },
];

const Actions = () => {
  return (
    <ScrollView
      horizontal
      nestedScrollEnabled
      showsHorizontalScrollIndicator={false}
      style={{ marginTop: 18, height: 138 }} // 👈 move here
      contentContainerStyle={{ gap: 11, paddingHorizontal: 20 }}
    >
      {ACTIONS.map((item) => (
        <Action
          onPress={item.onPress}
          key={item.id}
          label={item.label}
          Icon={item.icon}
        />
      ))}
    </ScrollView>
  );
};

export default Actions;
