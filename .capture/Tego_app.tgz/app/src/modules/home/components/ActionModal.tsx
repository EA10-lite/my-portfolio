import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomButton } from "@/shared/components";
import AntDesign from "@expo/vector-icons/AntDesign";
import { router } from "expo-router";
import { useState } from "react";
import { Modal, Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Trigger = ({
  setIsOpen,
  isOpen,
}: {
  isOpen: boolean;
  setIsOpen: (trigger: boolean) => void;
}) => {
  return (
    <Pressable
      onPress={() => setIsOpen(true)}
      style={[styles.trigger, CUSTOM_STYLES.center]}
    >
      <AntDesign
        name={isOpen ? "close" : "plus"}
        size={16}
        color={PALETTE.white}
      />
    </Pressable>
  );
};

const ActionModal = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);

  const insets = useSafeAreaInsets();
  const TAB_BAR_HEIGHT = 67 + 12 + insets.bottom;

  return (
    <View>
      {!isOpen && (
        <View style={[styles.triggerWrapper, { bottom: TAB_BAR_HEIGHT + 16 }]}>
          <Trigger setIsOpen={() => setIsOpen(true)} isOpen={false} />
        </View>
      )}

      <Modal
        visible={isOpen}
        animationType="fade"
        transparent
        statusBarTranslucent
      >
        <View style={styles.overlay} />
        <View style={styles.content}>
          <View style={[styles.buttons, { bottom: TAB_BAR_HEIGHT + 16 }]}>
            <CustomButton
              title="Book a service"
              variant="outline"
              size="xs"
              style={styles.button}
              onPress={() => {
                setIsOpen(false);
                router.push("/(customer)/booking");
              }}
            />
            <CustomButton
              title="Request Service"
              variant="outline"
              size="xs"
              style={styles.button}
              onPress={() => {
                setIsOpen(false);
                router.push("/(customer)/request-job");
              }}
            />
            <Trigger setIsOpen={() => setIsOpen(false)} isOpen={true} />
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  triggerWrapper: {
    position: "absolute",
    right: 20,
  },
  trigger: {
    backgroundColor: PALETTE.primary,
    width: 50,
    height: 50,
    borderRadius: 100,
    marginLeft: "auto",
  },
  modal: {},
  overlay: {
    ...StyleSheet.absoluteFill,
    backgroundColor: PALETTE.black,
    opacity: 0.89,
  },
  content: {
    zIndex: 10,
    flex: 1,
  },
  buttons: {
    gap: 11,
    justifyContent: "flex-end",
    alignItems: "flex-end",
    position: "absolute",
    right: 20,
  },
  button: {
    width: 125,
  },
});

export default ActionModal;
