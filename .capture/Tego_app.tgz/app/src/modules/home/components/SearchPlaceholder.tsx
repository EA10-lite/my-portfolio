import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText } from "@/shared/components";
import Octicons from "@expo/vector-icons/Octicons";
import { StyleSheet, TouchableOpacity, View } from "react-native";

interface SearchPlaceholderProps {
  onPress?: () => void;
}

const ICON_BOX_WIDTH = 57;

const SearchPlaceholder = ({ onPress }: SearchPlaceholderProps) => {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.searchIconBox, CUSTOM_STYLES.center]}>
        <Octicons name="search" color={PALETTE.primary} size={20} />
      </View>
      <CustomText size="sm" weight="regular" style={styles.placeholder}>
        Search for categories, services...
      </CustomText>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderColor: "#8C8C8C33",
    borderRadius: 66,
    paddingHorizontal: 20,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    overflow: "hidden",
    height: 50,
    paddingLeft: ICON_BOX_WIDTH + 12, // 👈 offset text past the absolute icon box
  },
  searchIconBox: {
    ...StyleSheet.absoluteFill,
    backgroundColor: PALETTE.white,
    alignItems: "center",
    justifyContent: "center",
    width: ICON_BOX_WIDTH,
    right: undefined, // 👈 prevent it from stretching full width
  },
  placeholder: {
    opacity: 0.5,
  },
});

export default SearchPlaceholder;
