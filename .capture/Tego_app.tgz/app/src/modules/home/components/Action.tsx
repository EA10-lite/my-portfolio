import { PALETTE } from "@/constants/colors";
import { CustomText } from "@/shared/components";
import { Pressable, StyleSheet, View } from "react-native";
import { SvgProps } from "react-native-svg";

interface ActionProps {
  label: string;
  Icon: React.FC<SvgProps>;
  onPress: () => void;
}
const Action = ({ label, Icon, onPress }: ActionProps) => {
  return (
    <Pressable onPress={onPress}>
      <View style={styles.container}>
        <Icon width={32} height={32} />
        <CustomText size="sm" weight="semibold" style={styles.title}>
          {label}
        </CustomText>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 9,
    padding: 16,
    gap: 38,
    width: 169,
    height: 138,
  },
  title: { width: 64 },
});

export default Action;
