
export interface ProviderDTO {
  id: string;
  name: string;
  location: string;
  minAmount: number;
  rating: number;
  isVerified: boolean;
  isAvailable: boolean;
  category: string;
  imageUrl: string;
}
