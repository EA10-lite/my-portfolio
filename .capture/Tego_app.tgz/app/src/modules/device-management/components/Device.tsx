import LogoutIcon from "@/assets/images/app-icons/logout.svg";
import PhoneIcon from "@/assets/images/app-icons/phone-outline.svg";
import DeleteIcon from "@/assets/images/app-icons/trash-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { GetDevice } from "@/modules/profile/types/profile.dto";
import { CustomModal, CustomText } from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { formatDate } from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useRef } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";

interface DeviceProps {
  device: GetDevice;
  logout: () => void;
  deleteDevice: (id: string) => void;
  isDeleting?: boolean;
}

const Device = ({
  device,
  logout,
  deleteDevice,
  isDeleting = false,
}: DeviceProps) => {
  const deleteModalRef = useModalState();
  const logoutModalRef = useModalState();

  const handleLogout = async () => {
    deleteDevice(device?.device_id);
    logout();
    logoutModalRef.close();
  };

  const handleDeleteAccount = () => {
    deleteDevice(device?.device_id);
  };
  return (
    <>
      <CustomModal
        ref={deleteModalRef.ref}
        onClose={deleteModalRef.close}
        title="Delete Device"
        description="Are you sure you want to delete the is device?"
        Icon={<PhoneIcon width={20} height={20} color={PALETTE.primary} />}
        primaryButtonText="Delete"
        secondaryButtonText="Cancel"
        secondaryAction={deleteModalRef.close}
        primaryAction={handleDeleteAccount}
        primaryLoading={isDeleting}
      />
      <CustomModal
        ref={logoutModalRef.ref}
        title="Log Out?"
        description="Are you sure you want to log out of your account?"
        onClose={logoutModalRef.close}
        primaryButtonText="Log Out"
        secondaryButtonText="Cancel"
        secondaryAction={logoutModalRef.close}
        primaryAction={handleLogout}
        Icon={<LogoutIcon width={16} height={16} color={PALETTE.primary} />}
      />
      <View
        style={[
          styles.card,
          CUSTOM_STYLES.row,
          !device?.is_active && { alignItems: "flex-start" },
        ]}
      >
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
            <PhoneIcon color={PALETTE.primary} />
          </View>
          <View style={{ gap: 8 }}>
            <CustomText weight="semibold">{device?.device_name}</CustomText>
            <View
              style={[
                CUSTOM_STYLES.row,
                { gap: 10, opacity: device?.is_active ? 1 : 0.6 },
              ]}
            >
              <CustomText weight="medium" size="xs" style={{ opacity: 0.6 }}>
                {device?.location?.state} {device?.location?.country}
              </CustomText>
              <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                <View
                  style={[
                    CUSTOM_STYLES.dot,
                    {
                      backgroundColor: device?.is_active
                        ? PALETTE.success
                        : PALETTE.black,
                    },
                  ]}
                />
                <CustomText
                  size="xs"
                  weight="semibold"
                  style={{
                    textTransform: "uppercase",
                    color: device?.is_active ? PALETTE.success : PALETTE.black,
                    fontSize: 10,
                  }}
                >
                  {device?.is_active ? "Active" : "Not Active"}
                </CustomText>
              </View>
            </View>
            {!device?.is_active && (
              <CustomText weight="medium" size="xs" style={{ opacity: 0.6 }}>
                Last active: {formatDate(device?.last_active_at)}
              </CustomText>
            )}
          </View>
        </View>

        {device?.is_active ? (
          <TouchableOpacity onPress={logoutModalRef.open} hitSlop={{ top: 14, bottom: 14 }}>
            <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
              <CustomText size="xs" weight="medium" color="error">
                Log Out
              </CustomText>
              <Ionicons name="arrow-forward" size={20} color={PALETTE.error} />
            </View>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={deleteModalRef.open} hitSlop={17}>
            <DeleteIcon color={PALETTE.error} />
          </TouchableOpacity>
        )}
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 20,
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
    justifyContent: "space-between",
  },
});

export default Device;
