import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useEffect, useRef } from "react";
import { Animated, StyleSheet, View } from "react-native";

const DeviceCardSkeleton = () => {
  const opacity = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0.3,
          duration: 800,
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, []);

  return (
    <Animated.View style={[styles.card, CUSTOM_STYLES.row, { opacity }]}>
      {/* icon */}
      <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
        <View style={styles.icon} />
        <View style={{ gap: 8 }}>
          {/* device name */}
          <View style={styles.lineLong} />
          <View style={[CUSTOM_STYLES.row, { gap: 10 }]}>
            {/* location */}
            <View style={styles.lineShort} />
            {/* status dot + text */}
            <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
              <View style={styles.dot} />
              <View style={styles.lineXShort} />
            </View>
          </View>
        </View>
      </View>
      {/* action */}
      <View style={styles.lineAction} />
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 20,
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
    justifyContent: "space-between",
  },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 80,
    backgroundColor: PALETTE.grey01,
  },
  lineLong: {
    width: 140,
    height: 12,
    borderRadius: 6,
    backgroundColor: PALETTE.grey01,
  },
  lineShort: {
    width: 80,
    height: 10,
    borderRadius: 6,
    backgroundColor: PALETTE.grey01,
  },
  lineXShort: {
    width: 50,
    height: 10,
    borderRadius: 6,
    backgroundColor: PALETTE.grey01,
  },
  lineAction: {
    width: 50,
    height: 10,
    borderRadius: 6,
    backgroundColor: PALETTE.grey01,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 10,
    backgroundColor: PALETTE.grey01,
  },
});

export default DeviceCardSkeleton;
