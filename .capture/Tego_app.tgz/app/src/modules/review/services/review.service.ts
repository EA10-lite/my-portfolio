import { api } from "@/shared/lib/api";
import { ProviderReviews } from "../types/provider.dto";


export const reviewService =  {
    getProviderReviews: async (page: number, limit: number, provider_id: string) => {
        const response = await api.get<ProviderReviews>(
            `/providers/${provider_id}/reviews?page=${page}&limit=${limit}`
        );
        return response.data;
    },
}