import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, UserAvatar } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import { formatDate } from "@/shared/utils/formatter";
import Octicons from "@expo/vector-icons/Octicons";
import { StyleSheet, View } from "react-native";
import { Review } from "../types/provider.dto";

interface ReviewProps {
  review: Review
}

const ReviewCard = ({ review }: ReviewProps) => {
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={[CUSTOM_STYLES.row, { gap: 9, alignItems: "flex-start" }]}>
          <UserAvatar
            url={review.customer.profile_picture}
            name={`${review.customer.first_name} ${review.customer.last_name}`}
          />
          <View style={{ justifyContent: "space-between", gap: 12 }}>
            <CustomText size="xs" weight="medium">
              {review.customer.first_name} {review.customer.last_name}
            </CustomText>
            <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
              {Array.from({ length: review.rating }).map((item, index) => (
                <Octicons
                  key={index}
                  name="star-fill"
                  size={12}
                  color={PALETTE.yellow}
                />
              ))}
            </View>
          </View>
        </View>
        <CustomText weight="medium" style={{ fontSize: 11 }}>
          {formatDate(review.created_at)}
        </CustomText>
      </View>
      <View style={styles.body}>
        <CustomText size="xs" weight="regular" style={styles.message}>
          {review.review_text}
        </CustomText>
        <View style={[CUSTOM_STYLES.row, { gap: 5, flexWrap: "wrap" }]}>
          {review.exception && (
            <View style={[styles.review, CUSTOM_STYLES.center]}>
              <CustomText
                weight="medium"
                color="primary"
                style={{ fontSize: 10 }}
              >
                {review.exception}
              </CustomText>
            </View>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.gray,
    marginHorizontal: 20,
  },
  header: {
    padding: 20,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },
  body: {
    borderWidth: 1,
    borderColor: "#E8E7E766",
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    padding: 20,
    gap: 13,
  },
  message: { letterSpacing: -0.24, lineHeight: 20 },
  review: {
    borderWidth: 1,
    borderRadius: 38,
    paddingHorizontal: 7.67,
    height: 24,
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
    borderColor: hexToRgba(PALETTE.primary, 0.3),
  },
});

export default ReviewCard;
