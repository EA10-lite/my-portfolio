import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { SkeletonBox } from "@/shared/components";
import { StyleSheet, View } from "react-native";

const ReviewCardSkeleton = () => {
  return (
    <View style={styles.card}>
      {/* Header */}
      <View style={styles.header}>
        {/* Avatar + customer info */}
        <View
          style={[
            CUSTOM_STYLES.row,
            {
              gap: 9,
              alignItems: "flex-start",
            },
          ]}
        >
          <SkeletonBox width={40} height={40} borderRadius={20} />

          <View style={styles.customerInfo}>
            {/* Customer name */}
            <SkeletonBox width={120} height={12} borderRadius={4} />

            {/* Rating */}
            <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
              {[1, 2, 3, 4, 5].map((_, index) => (
                <SkeletonBox
                  key={index}
                  width={12}
                  height={12}
                  borderRadius={3}
                />
              ))}
            </View>
          </View>
        </View>

        {/* Date */}
        <SkeletonBox width={65} height={11} borderRadius={4} />
      </View>

      {/* Body */}
      <View style={styles.body}>
        {/* Review text */}
        <View style={{ gap: 7 }}>
          <SkeletonBox width="100%" height={10} borderRadius={4} />
          <SkeletonBox width="92%" height={10} borderRadius={4} />
          <SkeletonBox width="70%" height={10} borderRadius={4} />
        </View>

        {/* Exception/tag */}
        <SkeletonBox width={75} height={24} borderRadius={38} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.gray,
  },

  header: {
    padding: 20,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
  },

  customerInfo: {
    justifyContent: "space-between",
    gap: 6,
  },

  body: {
    borderWidth: 1,
    borderColor: "#E8E7E766",
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    padding: 20,
    gap: 13,
  },
});

export default ReviewCardSkeleton;