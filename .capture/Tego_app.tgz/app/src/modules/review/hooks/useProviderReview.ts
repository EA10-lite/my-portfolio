// hooks/useOrder.ts
import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { reviewService } from "../services/review.service";

export const useProviderReviews = (providerId: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const reviewsQuery = useInfiniteQuery({
    queryKey: queryKeys.providers.review(providerId),
    queryFn: ({ pageParam = 1 }) =>
        reviewService.getProviderReviews(pageParam, 10, providerId),
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
  });

  return {
    reviews: reviewsQuery.data?.pages.flatMap((page) => page.reviews) ?? [],
    fetchNextPage: reviewsQuery.fetchNextPage,
    hasNextPage: reviewsQuery.hasNextPage,
    isFetchingNextPage: reviewsQuery.isFetchingNextPage,
    isLoading: reviewsQuery.isLoading,
    errorMessage,
  };
};
