import { Pagination } from "@/constants/types";

export interface ProviderReviews extends Pagination {
  reviews: Review[];
}

export interface Review {
  id: string;
  order_id: string;
  customer: {
    id: string;
    first_name: string;
    last_name: string;
    user_type: "CUSTOMER";
    average_rating: string;
    profile_picture: string;
  };
  provider: {
    id: string;
    first_name: string;
    last_name: string;
    user_type: "SERVICE_PROVIDER";
    average_rating: number;
    profile_picture: string;
    is_verified: boolean;
    service_category: string;
  };
  exception: string;
  rating: number;
  review_text: string;
  created_at: string;
}
