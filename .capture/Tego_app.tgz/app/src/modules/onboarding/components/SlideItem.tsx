import { PALETTE } from "@/constants/colors";
import { CustomButton, CustomText } from "@/shared/components";
import { useEffect, useRef } from "react";
import {
  Animated,
  Dimensions,
  Easing,
  Image,
  ImageSourcePropType,
  StyleSheet,
  View,
  ViewStyle,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { width } = Dimensions.get("window");

interface SlideItemProps {
  item: {
    id: number;
    title: string;
    description: string;
    image: ReturnType<typeof require>;
    imageStyle?: ViewStyle;
    textBoxStyle?: ViewStyle;
  };
  handleNext: () => void;
  handleBack: () => void;
  currentIndex: number;
}

const SlideItem = ({
  item,
  handleNext,
  handleBack,
  currentIndex,
}: SlideItemProps) => {
  const insets = useSafeAreaInsets();
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    opacity.setValue(0);
    Animated.timing(opacity, {
      toValue: 1,
      duration: 500,
      easing: Easing.in(Easing.ease),
      useNativeDriver: true,
    }).start();
  }, [item.id]);

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.content, { opacity }]}>
        <View style={[styles.imageContainer, item.imageStyle]}>
          <Image
            source={item.image as ImageSourcePropType}
            style={styles.image}
          />
          {!item.imageStyle && (
            <Image
              source={require("../../../../assets/images/app-images/smokey-frame.png")}
              style={styles.smokeyOverlay}
            />
          )}
        </View>

        <View
          style={[
            styles.footerContainer,
            item.imageStyle && {
              backgroundColor: PALETTE.white,
              marginTop: "auto",
            },
            { paddingBottom: Math.max(insets.bottom, 30) },
          ]}
        >
          {item.imageStyle && (
            <Image
              source={require("../../../../assets/images/app-images/smokey-frame.png")}
              style={[styles.smokeyOverlay, styles.firstOnboarding]}
            />
          )}
          <View style={[styles.footerContent]}>
            <View style={{ gap: 31, maxWidth: 298, marginHorizontal: "auto" }}>
              <View style={styles.paginationContainer}>
                {Array.from({ length: 3 }).map((_, index) => (
                  <View
                    key={index}
                    style={[
                      styles.pagination,
                      {
                        backgroundColor:
                          currentIndex === index
                            ? PALETTE.primary
                            : PALETTE.black,
                        opacity: currentIndex === index ? 1 : 0.2,
                      },
                    ]}
                  />
                ))}
              </View>
              <View style={[styles.textContainer, item.textBoxStyle]}>
                <CustomText size="sm" weight="semibold" style={styles.title}>
                  {item.title}
                </CustomText>
                <CustomText
                  size="lg"
                  weight="semibold"
                  style={styles.description}
                >
                  {item.description}
                </CustomText>
              </View>
            </View>

            <View style={styles.buttonContainer}>
              {currentIndex > 0 && (
                <CustomButton
                  title="Back"
                  onPress={handleBack}
                  style={styles.button}
                  variant="default"
                />
              )}
              <CustomButton
                title={currentIndex === 2 ? "Get Started" : "Next"}
                variant="primary"
                onPress={handleNext}
                style={styles.button}
              />
            </View>
          </View>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  content: {
    flex: 1,
    width,
  },
  imageContainer: {
    flex: 1,
    position: "relative",
  },
  image: {
    resizeMode: "cover",
    height: "100%",
    width: "100%",
  },
  footerContainer: {
    width: "100%",
  },
  smokeyOverlay: {
    position: "absolute",
    bottom: -150,
    left: 0,
    right: 0,
    width: "100%",
    height: 300, // adjust to match the exported asset height
    resizeMode: "stretch",
  },
  firstOnboarding: {
    top: -150,
    bottom: "auto",
  },
  footerContent: {
    marginHorizontal: "auto",
    paddingHorizontal: 29,
  },
  paginationContainer: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
    backgroundColor: "#F4F3F3",
    borderRadius: 50,
    width: 42,
    height: 14,
    margin: "auto",
  },
  pagination: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  textContainer: { gap: 8 },
  title: {
    textAlign: "center",
    textTransform: "uppercase",
    opacity: 0.5,
  },
  description: {
    textAlign: "center",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 16,
    marginTop: 51,
    maxWidth: 330,
  },
  button: {
    flex: 1,
    maxWidth: 169,
  },
});

export default SlideItem;
