import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { hexToRgba } from "@/shared/utils/converter";
import { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
    useAnimatedStyle,
    useSharedValue,
    withRepeat,
    withTiming,
} from "react-native-reanimated";

const SkeletonBox = ({
  width,
  height,
  borderRadius = 6,
  style,
}: {
  width?: number | string;
  height: number;
  borderRadius?: number;
  style?: any;
}) => {
  const opacity = useSharedValue(1);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.4, { duration: 800 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[
        { width, height, borderRadius, backgroundColor: PALETTE.grey01 },
        animatedStyle,
        style,
      ]}
    />
  );
};

const RequestCardSkeleton = () => {
  return (
    <View style={[CUSTOM_STYLES.card]}>
      {/* Card Header */}
      <View style={[CUSTOM_STYLES.cardHeader]}>
        {/* User avatar + title */}
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <SkeletonBox width={24} height={24} borderRadius={12} />
          <SkeletonBox width={140} height={14} borderRadius={4} />
        </View>

        {/* Location + time */}
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
            <SkeletonBox width={16} height={16} borderRadius={8} />
            <SkeletonBox width={80} height={12} borderRadius={4} />
          </View>
          <SkeletonBox width={6} height={6} borderRadius={3} />
          <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
            <SkeletonBox width={16} height={16} borderRadius={8} />
            <SkeletonBox width={100} height={12} borderRadius={4} />
          </View>
        </View>
      </View>

      {/* Card Content */}
      <View style={[CUSTOM_STYLES.cardContent]}>
        {/* Body — category tag + images */}
        <View style={styles.body}>
          <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
            {/* Category tag */}
            <SkeletonBox width={80} height={24} borderRadius={3} />

            <SkeletonBox width={6} height={6} borderRadius={3} />

            {/* Image stack + count */}
            <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
              <View style={[CUSTOM_STYLES.row]}>
                {[1, 2, 3].map((_, index) => (
                  <SkeletonBox
                    key={index}
                    width={20}
                    height={20}
                    borderRadius={10}
                    style={{
                      marginLeft: index === 0 ? 0 : -8,
                      zIndex: index + 1,
                    }}
                  />
                ))}
              </View>
              <SkeletonBox width={50} height={12} borderRadius={4} />
            </View>
          </View>
        </View>

        {/* Footer — budget + button */}
        <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.cardFooter]}>
          <View style={{ gap: 4 }}>
            <SkeletonBox width={50} height={10} borderRadius={4} />
            <SkeletonBox width={120} height={14} borderRadius={4} />
          </View>
          <SkeletonBox width={108} height={36} borderRadius={6} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  body: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: hexToRgba(PALETTE.black, 0.1),
  },
});

export default RequestCardSkeleton;
