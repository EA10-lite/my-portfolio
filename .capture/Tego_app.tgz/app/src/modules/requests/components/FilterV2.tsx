import { CustomButton, CustomText } from "@/shared/components";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import BottomSheet, { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef, useState } from "react";
import { Pressable, StyleSheet, View } from "react-native";
import { BookingFilters, BookingStatus, BookingUrgency } from "@/modules/booking/hooks/useBooking";

const STATUS_OPTIONS: { label: string; value: BookingStatus }[] = [
  { label: "Pending", value: "PENDING" },
  { label: "Confirmed", value: "CONFIRMED" },
  { label: "Completed", value: "COMPLETED" },
  { label: "Cancelled", value: "CANCELLED" },
];

const URGENCY_OPTIONS: { label: string; value: BookingUrgency }[] = [
  { label: "Today", value: "TODAY" },
  { label: "Tomorrow", value: "TOMORROW" },
  { label: "Flexible", value: "FLEXIBLE" },
];

interface BookingFilterProps {
  filters: BookingFilters;
  onApply: (filters: BookingFilters) => void;
  onClear: () => void;
  onClose: () => void;
}

const RequestFilter = forwardRef<BottomSheetModal, BookingFilterProps>(
  ({ filters, onApply, onClear, onClose }, ref) => {
    // 👇 lazy initializer — never resets on re-render
    const [local, setLocal] = useState<BookingFilters>(
      () => JSON.parse(JSON.stringify(filters)),
    );

    const handleApply = () => {
      onApply(local);
      onClose();
    };

    const handleClear = () => {
      const cleared: BookingFilters = {
        status: "",
        urgency: "",
        budget_min: undefined,
        budget_max: undefined,
        lat: undefined,
        lng: undefined,
        radius: undefined,
      };
      setLocal(cleared);
      onClear();
      onClose();
    };

    return (
      <BottomSheet ref={ref} onClose={onClose} snapPoints={["60%", "85%"]}>
        <View style={styles.container}>
          <CustomText size="sm" weight="semibold">
            Filters
          </CustomText>

          {/* Status */}
          <View style={styles.section}>
            <CustomText
              size="xs"
              weight="semibold"
              style={{ opacity: 0.5, textTransform: "uppercase" }}
            >
              Status
            </CustomText>
            <View style={styles.options}>
              {STATUS_OPTIONS.map((option) => (
                <Pressable
                  key={option.value}
                  style={[
                    styles.option,
                    local.status === option.value && styles.optionActive,
                  ]}
                  onPress={() =>
                    setLocal((prev) => ({
                      ...prev,
                      // toggle off if already selected
                      status:
                        prev.status === option.value ? "" : option.value,
                    }))
                  }
                >
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={
                      { color: local.status === option.value ?  PALETTE.white : PALETTE.black }
                    }
                  >
                    {option.label}
                  </CustomText>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Urgency */}
          <View style={styles.section}>
            <CustomText
              size="xs"
              weight="semibold"
              style={{ opacity: 0.5, textTransform: "uppercase" }}
            >
              Urgency
            </CustomText>
            <View style={styles.options}>
              {URGENCY_OPTIONS.map((option) => (
                <Pressable
                  key={option.value}
                  style={[
                    styles.option,
                    local.urgency === option.value && styles.optionActive,
                  ]}
                  onPress={() =>
                    setLocal((prev) => ({
                      ...prev,
                      urgency:
                        prev.urgency === option.value ? "" : option.value,
                    }))
                  }
                >
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={
                      { color: local.status === option.value ?  PALETTE.white : PALETTE.black }
                    }
                  >
                    {option.label}
                  </CustomText>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Actions */}
          <View style={[CUSTOM_STYLES.row, styles.actions]}>
            <CustomButton
              title="Clear"
              variant="secondary"
              style={{ flex: 1 }}
              onPress={handleClear}
            />
            <CustomButton
              title="Apply"
              variant="primary"
              style={{ flex: 1 }}
              onPress={handleApply}
            />
          </View>
        </View>
      </BottomSheet>
    );
  },
);

const styles = StyleSheet.create({
  container: {
    gap: 20,
    paddingBottom: 20,
  },
  section: {
    gap: 12,
  },
  options: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  option: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 100,
    borderWidth: 1,
    borderColor: PALETTE.grey01,
    backgroundColor: PALETTE.white,
  },
  optionActive: {
    backgroundColor: PALETTE.primary,
    borderColor: PALETTE.primary,
  },
  actions: {
    gap: 12,
    marginTop: 8,
  },
});

RequestFilter.displayName = "BookingFilter";

export default RequestFilter;