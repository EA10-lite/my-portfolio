import FilterIcon from "@/assets/images/app-icons/filter.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { BUDGET } from "@/constants/values";
import {
  BookingFilters,
  BookingUrgency,
} from "@/modules/booking/hooks/useBooking";
import { CustomButton, CustomText } from "@/shared/components";
import { RadioSelector } from "@/shared/components/forms/";
import { useDeviceInfo } from "@/shared/hooks/useLocation";
import { useModalState } from "@/shared/hooks/useModalState";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetFooter,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { useCallback, useState } from "react";
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const URGENCY_OPTIONS = [
  { label: "Immediately", value: "IMMEDIATELY" },
  { label: "Today", value: "TODAY" },
  { label: "Tomorrow", value: "TOMORROW" },
  { label: "Flexible", value: "FLEXIBLE" },
];

interface BookingFilterProps {
  filters: BookingFilters;
  onApply: (filters: BookingFilters) => void;
  onClear: () => void;
}

const RequestFilter = ({ filters, onApply, onClear }: BookingFilterProps) => {
  const insets = useSafeAreaInsets();
  const ref = useModalState();

  // Draft state for in-progress edits, only committed to the parent on Apply.
  // NOTE: this must be re-derived from `filters` every time the sheet opens
  // (see handleOpen below) — a one-time lazy initializer would go stale as
  // soon as `filters` changes from outside this component while it's closed.
  const [local, setLocal] = useState<BookingFilters>(() =>
    JSON.parse(JSON.stringify(filters)),
  );

  // Re-sync the draft from the true source of truth (`filters`) every time
  // the sheet is opened, so stale/out-of-sync selections never show up.
  const handleOpen = () => {
    setLocal(JSON.parse(JSON.stringify(filters)));
    ref.open();
  };

  const handleApply = () => {
    onApply(local);
    ref.close();
  };

  const handleClear = () => {
    const cleared: BookingFilters = {
      status: "",
      urgency: "",
      budget_min: undefined,
      budget_max: undefined,
      lat: undefined,
      lng: undefined,
      radius: undefined,
    };
    setLocal(cleared);
    onClear();
    ref.close();
  };

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.89}
        pressBehavior="none"
      />
    ),
    [],
  );

  const renderFooter = useCallback(
    (props: any) => (
      <BottomSheetFooter {...props} bottomInset={0}>
        <View
          style={[
            styles.footer,
            { paddingBottom: Math.max(insets.bottom, 34) },
          ]}
        >
          <CustomButton
            title="Reset"
            variant="secondary"
            onPress={handleClear}
            style={styles.buttons}
          />
          <CustomButton
            title="Apply Filter"
            onPress={handleApply}
            variant="primary"
            style={styles.buttons}
          />
        </View>
      </BottomSheetFooter>
    ),
    [],
  );

  return (
    <View>
      <Pressable
        onPress={handleOpen}
        style={[styles.filterTrigger, CUSTOM_STYLES.center]}
      >
        <FilterIcon />
      </Pressable>

      {Platform.OS === "ios" ? (
        <Modal
          visible={ref.isOpen}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={ref.close}
        >
          <Pressable style={styles.overlay} onPress={ref.close} />
          <View style={[styles.content]}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={[{ flexGrow: 1 }]}
            >
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  Filter
                </CustomText>
                <Pressable onPress={ref.close} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <Content filters={local} setFilters={setLocal} />
            </ScrollView>

            <View
              style={[
                styles.footer,
                { paddingBottom: Math.max(insets.bottom, 34) },
              ]}
            >
              <CustomButton
                title="Reset"
                variant="secondary"
                onPress={handleClear}
                style={styles.buttons}
              />
              <CustomButton
                title="Apply"
                variant="primary"
                onPress={handleApply}
                style={styles.buttons}
              />
            </View>
          </View>
        </Modal>
      ) : (
        <BottomSheetModal
          ref={ref.ref}
          enablePanDownToClose
          backdropComponent={renderBackdrop}
          footerComponent={renderFooter}
          backgroundStyle={styles.container}
          handleIndicatorStyle={{ height: 0 }}
          handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
          handleComponent={() => <></>}
          snapPoints={["95%"]}
        >
          <BottomSheetScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{
              paddingBottom: insets.bottom + 90,
            }}
          >
            <View style={[styles.content]}>
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  Filter
                </CustomText>
                <Pressable onPress={ref.close} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <Content filters={local} setFilters={setLocal} />
            </View>
          </BottomSheetScrollView>
        </BottomSheetModal>
      )}
    </View>
  );
};

const Content = ({
  filters,
  setFilters,
}: {
  filters: BookingFilters;
  setFilters: (filters: BookingFilters) => void;
}) => {
  const { location } = useDeviceInfo();
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.body}>
        <RadioSelector
          items={URGENCY_OPTIONS}
          label="Urgency"
          handleSelect={(item) => {
            setFilters({
              ...filters,
              urgency: item.value as BookingUrgency,
            });
          }}
          selectedValue={filters.urgency ?? ""}
        />

        <View style={CUSTOM_STYLES.divider} />

        <RadioSelector
          items={BUDGET}
          label="Budget"
          selectedValue={filters.budget_min?.toString() ?? ""}
          getValue={(item) => item.min.toString()}
          getLabel={(item) => item.label}
          handleSelect={(item) => {
            setFilters({
              ...filters,
              budget_max: item.max,
              budget_min: item.min,
            });
          }}
        />

        <View style={CUSTOM_STYLES.divider} />

        <View style={styles.field}>
          <View style={styles.row}>
            <CustomText size="sm" weight="semibold">
              Location
            </CustomText>
          </View>

          <View style={styles.preferences}>
            <Pressable
              onPress={() => {
                setFilters({
                  ...filters,
                  lat: location.latitude ?? 0,
                  lng: location.longitude ?? 0,
                  preference: "near_me",
                });
              }}
            >
              <View style={styles.preference}>
                <View style={{ gap: 6 }}>
                  <CustomText weight="semibold" style={{ fontSize: 13 }}>
                    Show nearby only
                  </CustomText>
                  <CustomText
                    weight="medium"
                    size="xs"
                    style={styles.description}
                  >
                    Within 5km of your location
                  </CustomText>
                </View>
                <View style={[styles.outerRadioBox, CUSTOM_STYLES.center]}>
                  {filters.preference === "near_me" && (
                    <View style={styles.innerRadioBox} />
                  )}
                </View>
              </View>
            </Pressable>
          </View>
        </View>
      </View>
    </View>
  );
};

RequestFilter.displayName = "Provider Filter";

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  filterTrigger: {
    width: 50,
    height: 50,
    borderRadius: 80,
    backgroundColor: PALETTE.white,
  },
  content: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    borderRadius: 0,
    flex: 1,
    overflow: "hidden",
  },
  overlay: {},
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 20,
    flex: 1,
    marginTop: 20,
    paddingHorizontal: 20,
  },
  field: {
    gap: 20,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  preferences: {
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 6,
    paddingVertical: 10,
  },
  preference: {
    paddingHorizontal: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  description: {
    opacity: 0.6,
  },
  outerRadioBox: {
    width: 18,
    height: 18,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: PALETTE.black20,
  },
  innerRadioBox: {
    width: 12,
    height: 12,
    borderRadius: 28,
    backgroundColor: PALETTE.primary,
  },
  footer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: PALETTE.white,
  },
  buttons: {
    flex: 1,
    height: 50,
  },
});

export default RequestFilter;
