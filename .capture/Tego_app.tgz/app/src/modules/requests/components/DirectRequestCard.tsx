import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { DirectBooking } from "@/modules/booking/types/booking.dto";
import { CustomButton, CustomText, UserAvatar } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import {
    formatCurrency,
    formatDateTime,
    truncateText,
} from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Image, StyleSheet, View } from "react-native";

const DirectRequestCard = ({
  request,
  type = "REQUEST",
  handlePress,
}: {
  request: DirectBooking;
  type?: "REQUEST";
  handlePress: () => void;
}) => {
  const category = request.service_list_item.service_name || request.service_category.name
  return (
    <View style={[CUSTOM_STYLES.card]}>
      <View style={[CUSTOM_STYLES.cardHeader]}>
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <UserAvatar
            name={`${request.user.first_name} ${request.user.last_name}`}
            url={`${request.user.profile_picture}`}
            size="xs"
          />
          <CustomText
            weight="semibold"
            style={{ fontSize: 13, lineHeight: 16 }}
          >
            {request.title
              ? request.title
              : category}
          </CustomText>
        </View>
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <View style={[CUSTOM_STYLES.row, { gap: 4, opacity: 0.5 }]}>
            <Ionicons name="location-sharp" size={16} color={PALETTE.black} />
            <CustomText weight="medium" size="xs">
              {truncateText(request.address.address, 20)}
            </CustomText>
          </View>
          <View style={[CUSTOM_STYLES.dot, { backgroundColor: "#E3E3E3" }]} />
          <View style={[CUSTOM_STYLES.row, { gap: 4, opacity: 0.5 }]}>
            <Ionicons name="time" size={16} color={PALETTE.black} />
            <CustomText weight="semibold" size="xs">
              {request.date && formatDateTime(request.date)}
            </CustomText>
          </View>
        </View>
      </View>
      <View style={[CUSTOM_STYLES.cardContent]}>
        <View style={styles.body}>
          <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
            {category && (
              <View style={[type === "REQUEST" ? styles.tag : styles.activeTag]}>
                <CustomText
                  weight="semibold"
                  style={[
                    type === "REQUEST" ? styles.tagText : styles.activeTagText,
                  ]}
                >
                  {category}
                </CustomText>
              </View>
            )}
            {category && request.images.length > 0 && (
              <View style={[CUSTOM_STYLES.dot, { backgroundColor: "#E3E3E3" }]} />
            )}
            {request.images.length > 0 && (
              <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                <View style={[CUSTOM_STYLES.row]}>
                  {request.images.map((image, index) => (
                    <View
                      style={{
                        marginLeft: index === 0 ? 0 : -8,
                        zIndex: index + 1,
                      }}
                      key={index}
                    >
                      <Image src={image} style={styles.image} />
                    </View>
                  ))}
                </View>
                <CustomText size="xs" weight="medium" style={{ opacity: 0.5 }}>
                  {request.images.length} images
                </CustomText>
              </View>
            )}
            </View>
        </View>
        <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.cardFooter]}>
          <View style={{ gap: 4 }}>
            <CustomText size="xs" weight="medium" style={{ opacity: 0.5 }}>
              Budget
            </CustomText>
            <CustomText weight="semibold" style={{ fontSize: 13 }}>
              {request?.price
                ? formatCurrency(request?.price)
                : request?.quote_price
                  ? formatCurrency(request?.quote_price)
                  : "Request Quote"}
            </CustomText>
          </View>
          <CustomButton
            title="View Details"
            size="sm"
            style={styles.button}
            onPress={handlePress}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  profileName: {
    fontSize: 13,
    letterSpacing: -0.29,
  },
  date: {},
  rating: {
    backgroundColor: PALETTE.white,
    borderRadius: 25,
    paddingHorizontal: 12.19,
    paddingVertical: 6.09,
    gap: 2.44,
  },
  body: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: hexToRgba(PALETTE.black, 0.1),
  },
  tag: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 3,
    paddingHorizontal: 10.77,
    paddingVertical: 4,
  },
  tagText: {
    textTransform: "uppercase",
    fontSize: 11,
    opacity: 0.5,
  },
  activeTag: {
    borderWidth: 1,
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
    borderColor: hexToRgba(PALETTE.primary, 0.3),
    borderRadius: 36,
    paddingHorizontal: 10.77,
    paddingVertical: 4,
  },
  activeTagText: {
    textTransform: "uppercase",
    fontSize: 11,
    color: PALETTE.primary,
  },
  image: {
    width: 20,
    height: 20,
    borderRadius: 40,
    backgroundColor: PALETTE.grey01,
    borderWidth: 1,
    borderColor: PALETTE.gray,
  },
  button: {
    width: 108,
  },
});

export default DirectRequestCard;
