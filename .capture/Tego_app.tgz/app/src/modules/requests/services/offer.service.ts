import { api } from "@/shared/lib/api";
import {
    SendOfferDTO,
    SendOfferImages,
    SendOfferMessage,
} from "../types/offer.dto";

export interface BaseApplicationUserParams {
  page?: number;
  limit?: number;
}

const mapToApiParams = (params?: BaseApplicationUserParams) => {
  if (!params) return undefined;

  const { page, limit } = params;

  return {
    ...(page !== undefined && { page }),
    ...(limit !== undefined && { limit }),
  };
};

export const offerService = {
  sendOffer: async (data: SendOfferDTO) => {
    const response = await api.post(`/job-requests/offers`, data);
    return response.data;
  },
  sendOfferMessage: async (data: SendOfferMessage) => {
    const response = await api.post(`/job-requests/offers`, data);
    return response.data;
  },
  sendOfferMessages: async (data: SendOfferImages) => {
    const response = await api.post(`/job-requests/offers`, data);
    return response.data;
  },
  getAllofferConversations: async (params: BaseApplicationUserParams) => {
    const response = await api.get(`/job-requests/offers/conversations`, {
      params: mapToApiParams(params),
    });
    return response.data;
  },
  getUserOfferConversation: async (job_request_id: string, user_id: string) => {
    const response = await api.get(
      `/job-requests/offers/thread/${job_request_id}/${user_id}`,
    );
    return response.data;
  },
  getOffer: async (job_request_id: string) => {
    const response = await api.get(
      `/job-requests/offers/thread/${job_request_id}`,
    );
    return response.data;
  },
  updateOffer: async (request_id: string, status: "REJECTED" | "ACCEPTED") => {
    const response = await api.patch(`/job-requests/${request_id}/status`, {
      status,
    });
    return response.data;
  },
};
