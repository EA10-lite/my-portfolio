import { api } from "@/shared/lib/api";
import { RequestDTO, UpdateRequestDTO } from "../types/request.dto";

export const requestService = {
  createRequest: async (data: RequestDTO) => {
    const response = await api.post(`/job-requests`, data);
    return response.data;
  },
  getAllRequests: async () => {
    const response = await api.get("/job-requests");
    return response.data;
  },
  getMyRequests: async () => {
    const response = await api.get("/job-requests");
    return response.data;
  },
  getRequestById: async (request_id: string) => {
    const response = await api.get(`/job-requests/${request_id}`);
    return response.data;
  },
  updateRequest: async (request_id: string, data: UpdateRequestDTO) => {
    const response = await api.patch(`/job-requests/${request_id}`, data);
    return response.data;
  },
  cancelRequest: async (request_id: string) => {
    const response = await api.patch(`/job-requests/${request_id}/cancel`, {
      is_cancelled: true,
    });
    return response.data;
  },
};
