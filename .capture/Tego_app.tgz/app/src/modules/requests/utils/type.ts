import { CATEGORIES_TYPE } from "@/constants/types";
import { ImageSourcePropType } from "react-native";

export interface Request {
  id: string;
  user: {
    id: string;
    rating: number;
    isVerified: boolean;
    name: string;
    avatar: string;
  };
  title: string;
  category: CATEGORIES_TYPE;
  location: string;
  createdAt: string;
  images: ImageSourcePropType[];
}
