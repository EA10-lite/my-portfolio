import { create } from "zustand";

interface FilterState {
  budget: string;
  urgency: string;
  nearbyLocation: boolean;
  setBudget: (preference: string) => void;
  setUrgency: (urgency: string) => void;
  showNearbyLocation: (data: boolean) => void;
  clearFilters: () => void;
}

const initialState = {
  budget: "",
  urgency: "",
  nearbyLocation: true,
};

export const useRequestFilter = create<FilterState>((set) => ({
  ...initialState,

  setBudget: (budget) =>
    set((state) => ({
      budget: state.budget === budget ? "" : budget, // 👈 spread instead of push
    })),
  setUrgency: (urgency) =>
    set((state) => ({
      urgency: state.urgency === urgency ? "" : urgency, // 👈 spread instead of push
    })),
  showNearbyLocation: (location) =>
    set((state) => ({
      nearbyLocation: location,
    })),

  clearFilters: () => set(initialState),
}));
