import { URGENCY } from "@/constants/types";

export interface RequestDTO {
  service_category_id: string;
  description: string;
  date: string;
  address: string;
  images: string[];
  start_price: number;
  end_price: number;
  is_budget_negotiable: boolean;
  country: string;
  state: string;
  area: string;
  urgency: URGENCY;
}

export interface UpdateRequestDTO {
  description: string;
  start_price: number;
  end_price: number;
}

// This payload is for when there is no budget
// {
//   service_category_id: 550e8400-e29b-41d4-a716-446655440000,
//   description: Need someone to help move furniture from my old apartment to the new one,
//   date: 2026-06-20T14:30:00Z,
//   address: 456 Oak Avenue, Abuja, Nigeria,
//   is_budget_negotiable: false
//   urgency: TODAY // IMMEDIATELY, TODAY, FLEXIBLE

// }
