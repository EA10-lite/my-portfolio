import { AVAILABILITY, URGENCY } from "@/constants/types";

export interface SendOfferDTO {
  book_service_id: string;
  //   "job_request_id": "3e274f8a-c89d-4b05-b24f-d6c9243a64ba",
  receiver_id: string;
  content_type: "OFFER";
  message: string;
  media: [];
  offer: Offer;
}

export interface Offer {
  price: number;
  timeline: URGENCY;
  proposal: string;
  availability: AVAILABILITY;
}

export interface SendOfferMessage {
  job_request_id: string;
  receiver_id: string;
  content_type: "MESSAGE";
  message: string;
}

export interface SendOfferImages {
  job_request_id: string;
  receiver_id: string;
  content_type: "IMAGES";
  media: string[];
}
