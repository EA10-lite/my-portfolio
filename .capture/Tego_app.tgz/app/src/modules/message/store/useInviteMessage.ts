import { useLocationStore } from "@/shared/store/locationStore";
import { create } from "zustand";

// stores/bookingStore.ts

export type FormValues = {
  date: string;
  time: string;
  note: string;
  address: {
    address: string;
    state: string;
    country: string;
  };
  urgency: string;
  service_list_item_id: string;
  price: number;
};
interface BookingState {
  form: {
    date: string;
    time: string;
    address: {
      address: string;
      state: string;
      country: string;
    };
    note: string;
    urgency: string;
    service_list_item_id: string;
    price: number;
  };

  setFormData: (values: FormValues) => void;
  clearBooking: () => void;
}

const initialState = {
  form: {
    date: "",
    time: "",
    address: {
      address: "",
      state: "",
      country: "Nigeria",
    },
    note: "",
    urgency: "",
    service_list_item_id: "",
    price: 0,
  },
};

export const useInviteStore = create<BookingState>((set) => ({
  ...initialState,

  setFormData: (value: FormValues) => set({ form: value }),
  clearBooking: () => set(initialState),

  hydrateAddress: () => {
    set((state) => ({
      form: {
        ...state.form,
      },
    }));
  },
}));
