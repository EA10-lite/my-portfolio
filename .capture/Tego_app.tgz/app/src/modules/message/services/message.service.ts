import { api } from "@/shared/lib/api";
import { Chat } from "../hooks/useConversations";
import { JobInvite } from "../types/invite.dto";
import { OfferConversations, OfferThread } from "../types/offer-message.dto";

export type Message = {
  receiver_id: string;
  message_type: "TEXT" | "IMAGE";
  message: string;
  media?: string[];
  ticket?: {
    category: string;
    title: string;
  };
};

export interface MessageSupport {
  receiver_id: string;
  title: string;
  categories: string;
  issue: string;
}

export interface Support {
  id: string;
  first_name: string;
  last_name: string;
}

export const messageService = {
  getMessages: async () => {
    const response = await api.get<Chat[]>(`/messages/contacts`);
    return response.data;
  },
  getMessageCount: async () => {
    const response = await api.get<Chat[]>(`/messages/unread`);
    return response.data;
  },
  getMessageThread: async (chatId: string) => {
    const response = await api.get(`/messages/${chatId}`);
    return response.data;
  },
  getOfferConversations: async () => {
    const response = await api.get<OfferConversations[]>(
      `/offers/conversations`,
    );
    return response.data;
  },
  getOfferThread: async (id: string, userId: string) => {
    const response = await api.get<OfferThread>(
      `/offers/thread/${id}/${userId}`,
    );
    return response.data;
  },
  sendMessage: async (data: Message) => {
    const response = await api.post("/messages", data);
    return response.data;
  },
  sendJobInvite: async (data: JobInvite) => {
    const response = await api.post(`/messages`, data);
    return response.data;
  },
  updateJobInvite: async (messageId: string, action: "ACCEPT" | "DECLINE") => {
    const response = await api.post(`/messages/${messageId}/invite`, {
      action,
    });
    return response.data;
  },
  contactSupport: async (data: Message) => {
    const response = await api.post(`/messages`, data);
    return response.data;
  },
  getSupport: async () => {
    const response = await api.get<Support>(`/tickets/support-contact`);
    return response.data;
  },
  getSupportMessages: async () => {
    const response = await api.get(`/tickets/my`);
    return response.data;
  },
};
