// adjust path
import { tokenStorage } from "@/shared/lib/tokenStorage";
import { io, Socket } from "socket.io-client";

const BASE_URL = process.env.EXPO_PUBLIC_SOCKET_URL;

let socket: Socket | null = null;

export const socketService = {
  async connect() {
    if (socket?.connected) return socket;

    const token = await tokenStorage.get();
    console.log("token: ", token);
    if (!token) {
      console.warn("[Socket] No token found, skipping connection");
      return null;
    }

    socket = io(BASE_URL, {
      auth: { token },
      transports: ["websocket"],
    });

    socket.on("connect", () => {
      console.log("[Socket] Connected");
    });

    socket.on("connect_error", (e) => {
      console.error("[Socket] connect_error:", e.message);
    });

    socket.on("disconnect", (reason) => {
      console.log("[Socket] Disconnected:", reason);
    });

    return socket;
  },

  disconnect() {
    socket?.disconnect();
    socket = null;
  },

  getSocket() {
    return socket;
  },
};
