export interface OfferUser {
    id: string;
    first_name: string;
    last_name: string;
    profile_picture: string | null;
    user_type: "CUSTOMER" | "SERVICE_PROVIDER";
    available_status: "ONLINE" | "OFFLINE";
    average_rating: number | null;
}
export interface JobRequest {
    id: string;
    user: OfferUser;
    description: string;
    date: string;
    address: string;
    state: string;
    country: string;
    area: string;
    start_price: number;
    end_price: number;
    urgency: "IMMEDIATELY" | "SCHEDULED";
    status: "PENDING" | "ACCEPTED" | "COMPLETED" | "CANCELLED";
    created_at: string;
}
export interface OfferDetails {
    price: number;
    proposal: string;
    timeline: string;
    expiresAt: string;
    availability: "IMMEDIATELY" | "SCHEDULED";
}
export interface OfferMessage {
    id: string;
    sender: OfferUser;
    receiver: OfferUser;
    content_type: "OFFER";
    message: string;
    media: string[];
    offer: OfferDetails;
    status: "PENDING" | "ACCEPTED" | "REJECTED" | "EXPIRED";
    message_delivery_status: "SENT" | "DELIVERED" | "READ";
    expires_at: string;
    expired_at: string | null;
    created_at: string;
}
export interface BookService {
    // Add fields here when the API starts returning book_service
    [key: string]: unknown;
}
export interface OfferThread {
    user: OfferUser;
    job_request: JobRequest;
    book_service: BookService | null;
    offers: OfferMessage[];
}

export interface OfferConversations {
    user: OfferUser;
    job_request_id: string;
    book_service_id: string;
    last_message_at: string;
    offer_count: number;
    unread_count: number;
    last_offer: {
      id: string;
      content_type: "OFFER";
      message: string;
      offer: {
        price: number;
        proposal: string;
        timeline: string;
        expiresAt: string;
        availability: string;
      };
      status: "PENDING";
      expires_at: string;
      created_at: string;
    };
}