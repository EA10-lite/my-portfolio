import { URGENCY } from "@/constants/types";

export interface JobInvite {
    receiver_id: string;
    message_type: "INVITE_BOOKING",
    invite: Invite
}


export interface Invite {
    service_list_item_id: string;
    price: number;
    date: string;
    time: string;
    address: {
        address: string;
        state: string;
        country: string;
    },
    note?: string;
    urgency: URGENCY
}