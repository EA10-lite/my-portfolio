import { PRICING_TYPE, URGENCY } from "@/constants/types";

// modules/message/types/message.dto.ts
export type MessageType =
  | "text"
  | "image"
  | "file"
  | "system"
  | "INVITE_BOOKING"
  | "offer";
export type SystemMessageType = "booking_invite";

export type Sender = {
  id: string;
  name: string;
  avatar?: string;
};

export interface BaseMessage {
  id: string;
  type: MessageType;
  sender: Sender;
  createdAt: string;
}

export interface TextMessage extends BaseMessage {
  type: "text";
  text: string;
  status?: "sending" | "sent" | "delivered" | "read";
}

export interface ImageMessage extends BaseMessage {
  type: "image";
  text?: string;
  status?: "sending" | "sent" | "delivered" | "read";
  images: string[];
  uploadProgress?: number[]; // 👈 progress per image, 0-1
}

export interface FileMessage extends BaseMessage {
  type: "file";
  text?: string;
  file: {
    name: string;
    size: number;
    uri?: string;
    progress?: number;
    status: "uploading" | "uploaded";
  };
}

export interface SystemMessage extends BaseMessage {
  type: "system";
  systemType: SystemMessageType;
  data: {
    title: string;
    actionText: string;
  };
}

export interface InviteMessage extends BaseMessage {
  type: "INVITE_BOOKING";
  message_status?: "SENT" | "DELIVERED" | "ACCEPT" | "DECLINE";
  invite: Invite;
}


export interface Invite {
  address: {
    address: string;
    country: string;
    state: string;
  }
  date: string;
  note: string;
  price: number;
  pricing_type: PRICING_TYPE;
  service_category: {
    id: string;
    name: string;
  },
  service_list_item_id: string;
  service_name: string;
  status: "PENDING" | "ACCEPTED" | "REJECTED";
  time: string;
  urgency: URGENCY
  path: string[];
  set?: "ACCEPTED" | "DECLINED";
}



// {
//   "id": "message-uuid",
//   "conversation_id": "conversation-uuid",
//   "sender_id": "provider-uuid",
//   "receiver_id": "user-uuid",
//   "message": null,
//   "message_type": "INVITE_BOOKING",
//   "media": [],
//   "message_status": "SENT",
// }

export type Message =
  | TextMessage
  | ImageMessage
  | FileMessage
  | SystemMessage
  | InviteMessage;
