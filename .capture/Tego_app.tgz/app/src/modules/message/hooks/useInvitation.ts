import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useToastStore } from "@/shared/store/toastStore";
import { messageService } from "../services/message.service";
import { JobInvite } from "../types/invite.dto";

export const useInvitation = () => {
    const { showToast } = useToastStore();
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const queryClient = useQueryClient();

    const invalidateConversations = () => {
        queryClient.invalidateQueries({ queryKey: queryKeys.messages.list });
        queryClient.invalidateQueries({ queryKey: queryKeys.messages.offers });
    };

    const sendInvite = useMutation({
        mutationFn: async (data: JobInvite) => {
            return messageService.sendJobInvite(data);
        },
        onMutate: () => setErrorMessage(null),
        onSuccess: () => invalidateConversations,
        onError: (error) => {
            const message = getErrorMessage(error);
            setErrorMessage(message);
            showToast("Action Failed", message);
        },
    });
    const acceptInvitation = useMutation({
        mutationFn: async (messageId: string) => {
            return messageService.updateJobInvite(messageId, "ACCEPT");
        },
        onMutate: () => setErrorMessage(null),
        onSuccess: invalidateConversations,
        onError: (error) => {
            const message = getErrorMessage(error);
            setErrorMessage(message);
            showToast("Action Failed", message);
        },
    });
    const rejectInvitation = useMutation({
        mutationFn: async (messageId: string) => {
            return messageService.updateJobInvite(messageId, "DECLINE");
        },
        onMutate: () => setErrorMessage(null),
        onSuccess: invalidateConversations,
        onError: (error) => {
            const message = getErrorMessage(error);
            setErrorMessage(message);
            showToast("Action Failed", message);
        },
    });

    return {
        errorMessage,
        isSubmitting:
        sendInvite.isPending ||
        acceptInvitation.isPending ||
        rejectInvitation.isPending,
        sendInvite: sendInvite.mutate,
        acceptInvitation: acceptInvitation.mutate,
        rejectInvitation: rejectInvitation.mutate,
    };
};