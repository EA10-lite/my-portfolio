import { queryKeys } from "@/constants/queryKeys";
import { useQuery } from "@tanstack/react-query";
import { messageService } from "../services/message.service";

export const useSupportMessages = () => {
    const {
        data,
        isLoading,
      } = useQuery({
        queryKey: queryKeys.messages.support,
        queryFn: () => messageService.getSupportMessages(),
      });
      return {
        supportMessages: data,
        isLoading,
      };
};
