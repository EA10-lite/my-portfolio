import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useState } from "react";
import { messageService } from "../services/message.service";
import { socketService } from "../services/socket.service";
import { updateConversationPreview } from "../utils/conversation";
import { UserType } from "@/modules/applications/utils/type";

export const CHATS_QUERY_KEY = ["conversations"];

export interface Chat {
  contact_id: string;
  first_name: string;
  last_name: string;
  profile_picture: string | null;
  available_status: "ONLINE" | "OFFLINE" | "AWAY";
  last_message: string;
  last_message_type: "TEXT" | "IMAGE";
  last_message_at: string;
  unread_count: number;
}

export interface Receiver {
  id: string;
  first_name: string;
  last_name: string;
  profile_picture: string;
  user_type: UserType;
  available_status: "ONLINE";
  average_rating: number;
}

interface UnreadCountPayload {
  total_unread: number;
  counts: {
    contact_id: string;
    unread_count: number;
  }[];
}

export function useConversations() {
  const queryClient = useQueryClient();
  const [totalUnread, setTotalUnread] = useState(0);

  // 1. React Query handles caching + background refetch automatically
  const { data: chats = [], isLoading } = useQuery({
    queryKey: CHATS_QUERY_KEY,
    queryFn: () => messageService.getMessages(),
    staleTime: 0, // 2 mins
  });

  // 2. Socket listeners — update cache directly via queryClient
  useEffect(() => {
    let mounted = true;

    const handleNewMessage = (raw: any) => {
      queryClient.setQueryData<Chat[]>(CHATS_QUERY_KEY, (prev = []) =>
        updateConversationPreview(prev, raw, { incrementUnread: true }),
      );
    };

    const handlePresenceChanged = (p: any) => {
      queryClient.setQueryData<Chat[]>(CHATS_QUERY_KEY, (prev = []) =>
        prev.map((c) =>
          c.contact_id === p.user_id
            ? { ...c, available_status: p.available_status }
            : c,
        ),
      );
    };

    const handleUnreadCount = (payload: UnreadCountPayload) => {
      // 1. Update total unread badge
      setTotalUnread(payload.total_unread);

      // 2. Sync per-contact unread counts into the cache
      queryClient.setQueryData<Chat[]>(CHATS_QUERY_KEY, (prev = []) =>
        prev.map((chat) => {
          const match = payload.counts.find(
            (c) => c.contact_id === chat.contact_id,
          );
          return match
            ? { ...chat, unread_count: match.unread_count }
            : chat;
        }),
      );
    };

    const setup = async () => {
      const socket = await socketService.connect();
      if (!socket || !mounted) return;

      socket.on("message:new", handleNewMessage);
      socket.on("presence:changed", handlePresenceChanged);
      socket.on("message:unread-count", handleUnreadCount);
    };

    setup();

    return () => {
      mounted = false;
      const socket = socketService.getSocket();
      socket?.off("message:new", handleNewMessage);
      socket?.off("presence:changed", handlePresenceChanged);
      socket?.off("message:unread-count", handleUnreadCount);
    };
  }, [queryClient]);

  // 3. Mark as read — update cache directly
  const markAsRead = useCallback(
    (contactId: string) => {
      queryClient.setQueryData<Chat[]>(CHATS_QUERY_KEY, (prev = []) =>
        prev.map((c) =>
          c.contact_id === contactId ? { ...c, unread_count: 0 } : c,
        ),
      );

      // Update total unread
      setTotalUnread((prev) => {
        const chat = queryClient
          .getQueryData<Chat[]>(CHATS_QUERY_KEY)
          ?.find((c) => c.contact_id === contactId);
        return Math.max(0, prev - (chat?.unread_count ?? 0));
      });
    },
    [queryClient],
  );

  // 4. Call on logout
  const clearCache = useCallback(() => {
    queryClient.removeQueries({ queryKey: CHATS_QUERY_KEY });
    setTotalUnread(0);
  }, [queryClient]);

  return {
    chats,
    isLoading,
    totalUnread,  // 👈 use this for the tab badge
    refetch: () => queryClient.invalidateQueries({ queryKey: CHATS_QUERY_KEY }),
    markAsRead,
    clearCache,
  };
}
