import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { messageService } from "../services/message.service";

export const useOfferMessages = () => {
  const {
    data,
    isLoading,
  } = useQuery({
    queryKey: queryKeys.messages.offers,
    queryFn: () => messageService.getOfferConversations(),
  });

  return {
    offers: data,
    isLoading,
  };
};
