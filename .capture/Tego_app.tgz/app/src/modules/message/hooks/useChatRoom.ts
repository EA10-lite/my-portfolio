import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useRef, useState } from "react";
import { messageService } from "../services/message.service";
import { socketService } from "../services/socket.service";
import { ImageMessage, InviteMessage, Message, TextMessage } from "../types/message.dto";
import { updateConversationPreview } from "../utils/conversation";
import type { Chat } from "./useConversations";
import { CHATS_QUERY_KEY } from "./useConversations"; // 👈 import

function mapApiMessage(
  raw: any,
  currentUserId?: string,
  receiverName?: string,
  receiverAvatar?: string,
): TextMessage | ImageMessage | InviteMessage {
  const isMe = raw.sender_id === currentUserId;

  const senderName = raw.sender
    ? `${raw.sender.first_name} ${raw.sender.last_name}`
    : isMe
      ? "You"
      : (receiverName ?? "Them");

  const senderAvatar =
    raw.sender?.profile_picture ?? (isMe ? "" : (receiverAvatar ?? ""));

  const base = {
    id: raw.id,
    sender: {
      id: raw.sender_id,
      name: senderName,
      avatar: senderAvatar,
    },
    createdAt: raw.created_at,
    status: (raw.message_status?.toLowerCase() ?? "sent") as any,
  };

  if (raw.message_type === "IMAGE") {
    return {
      ...base,
      type: "image",
      images: raw.media ?? [],
      text: raw.message,
    };
  }
  if (raw.message_type === "INVITE_BOOKING") {
    return {
      ...base,
      type: "INVITE_BOOKING",
      invite: raw.invite,
    };
  }

  return { ...base, type: "text", text: raw.message };
}

export function useChatRoom(
  conversationId: string,
  receiverId: string,
  receiverName: string,
  receiverAvatar: string,
  isOnline: boolean = false,
) {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const [isReceiverOnline, setIsReceiverOnline] = useState(isOnline);
  const socketRef = useRef(socketService.getSocket());

  const THREAD_QUERY_KEY = ["thread", conversationId];

  // 1. Fetch and cache thread
  const { data: messages = [], isLoading } = useQuery({
    queryKey: THREAD_QUERY_KEY,
    queryFn: async () => {
      const data = await messageService.getMessageThread(conversationId);
      const arr = Array.isArray(data) ? data : (data.messages ?? []);
      return arr
        .map((m: any) =>
          mapApiMessage(m, user?.id, receiverName, receiverAvatar),
        )
        .reverse() as Message[];
    },
    staleTime: 0, // 👈 always refetch when invalidated
  });

  // 2. Socket listeners
  useEffect(() => {
    let mounted = true;

    const handleNewMessage = (raw: any) => {
      const isRelevant =
        (raw.sender_id === receiverId && raw.receiver_id === user?.id) ||
        (raw.sender_id === user?.id && raw.receiver_id === receiverId);

      if (!isRelevant) return;

      const incoming = mapApiMessage(
        raw,
        user?.id,
        receiverName,
        receiverAvatar,
      );

      queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) => {
        if (prev.some((m) => m.id === incoming.id)) return prev;
        return [incoming, ...prev];
      });
    };

    const handleStatusUpdate = (s: any) => {
      if (s.conversation_id !== conversationId) return;
      queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
        prev.map((m) =>
          m.sender.id === user?.id
            ? { ...m, status: s.status.toLowerCase() }
            : m,
        ),
      );
    };

    const handlePresenceChanged = (p: any) => {
      if (p.user_id !== receiverId) return;
      setIsReceiverOnline(p.available_status === "ONLINE");
    };

    const setup = async () => {
      const socket = await socketService.connect();
      if (!socket || !mounted) return;

      socketRef.current = socket;
      socket.emit("message:seen", { contact_id: receiverId });
      socket.on("message:new", handleNewMessage);
      socket.on("message:status", handleStatusUpdate);
      socket.on("presence:changed", handlePresenceChanged);
    };

    setup();

    return () => {
      mounted = false;
      const socket = socketRef.current;
      socket?.off("message:new", handleNewMessage);
      socket?.off("message:status", handleStatusUpdate);
      socket?.off("presence:changed", handlePresenceChanged);
    };
  }, [
    conversationId,
    receiverId,
    user?.id,
    receiverName,
    receiverAvatar,
    queryClient,
  ]);

  // 3. Send text
  const sendText = useCallback(
    (text: string) => {
      const socket = socketRef.current;
      if (!text.trim() || !socket) return;

      const tempId = `temp-${Date.now()}`;

      const optimistic: TextMessage = {
        id: tempId,
        type: "text",
        text,
        sender: {
          id: user!.id,
          name: "You",
          avatar: user?.profilePicture ?? "",
        },
        status: "sending",
        createdAt: new Date().toISOString(),
      };

      queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) => [
        optimistic,
        ...prev,
      ]);

      socket.emit(
        "message:send",
        { receiver_id: receiverId, message_type: "TEXT", message: text },
        (ack: any) => {
          if (ack.ok) {
            // Swap optimistic with real message
            queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
              prev.map((m) =>
                m.id === tempId
                  ? mapApiMessage(
                      ack.data,
                      user?.id,
                      receiverName,
                      receiverAvatar,
                    )
                  : m,
              ),
            );
            // Update conversations list
            queryClient.setQueryData<Chat[]>(CHATS_QUERY_KEY, (prev = []) =>
              updateConversationPreview(prev, ack.data, {
                incrementUnread: false,
              }),
            );
          } else {
            console.error("[useChatRoom] send failed:", ack.error);
            queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
              prev.map((m) =>
                m.id === tempId ? ({ ...m, status: "sent" } as Message) : m,
              ),
            );
          }
        },
      );
    },
    [receiverId, receiverName, receiverAvatar, user, queryClient],
  );

  // 4. Send images
  const sendImages = useCallback(
    (uploadedUrls: string[], tempId: string, caption?: string) => {
      const socket = socketRef.current;
      if (!uploadedUrls.length || !socket) return;

      queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
        prev.map((m) =>
          m.id === tempId
            ? ({ ...m, images: uploadedUrls, status: "sending" } as Message)
            : m,
        ),
      );

      socket.emit(
        "message:send",
        {
          receiver_id: receiverId,
          message_type: "IMAGE",
          ...(caption && { message: caption }),
          media: uploadedUrls,
        },
        (ack: any) => {
          if (ack.ok) {
            queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
              prev.map((m) =>
                m.id === tempId
                  ? mapApiMessage(
                      ack.data,
                      user?.id,
                      receiverName,
                      receiverAvatar,
                    )
                  : m,
              ),
            );
            // Update conversations list
            queryClient.setQueryData<Chat[]>(CHATS_QUERY_KEY, (prev = []) =>
              updateConversationPreview(prev, ack.data, {
                incrementUnread: false,
              }),
            );
          } else {
            console.error("[useChatRoom] image send failed:", ack.error);
            queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
              prev.map((m) =>
                m.id === tempId ? ({ ...m, status: "sent" } as Message) : m,
              ),
            );
          }
        },
      );
    },
    [receiverId, receiverName, receiverAvatar, user, queryClient],
  );

  // 5. Add optimistic image
  const addOptimisticImage = useCallback(
    (localUris: string[], caption?: string): string => {
      const tempId = `temp-${Date.now()}`;

      const optimistic: ImageMessage = {
        id: tempId,
        type: "image",
        images: localUris,
        text: caption,
        sender: {
          id: user!.id,
          name: "You",
          avatar: user?.profilePicture ?? "",
        },
        status: "sending",
        createdAt: new Date().toISOString(),
      };

      queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) => [
        optimistic,
        ...prev,
      ]);

      return tempId;
    },
    [user, queryClient],
  );

  // 6. Update a message by tempId
  const updateMessage = useCallback(
    (tempId: string, updatedFields: Partial<ImageMessage>) => {
      queryClient.setQueryData<Message[]>(THREAD_QUERY_KEY, (prev = []) =>
        prev.map((m) =>
          m.id === tempId ? ({ ...m, ...updatedFields } as Message) : m,
        ),
      );
    },
    [queryClient],
  );

  return {
    messages,
    isLoading,
    isReceiverOnline,
    sendText,
    sendImages,
    addOptimisticImage,
    updateMessage,
  };
}
