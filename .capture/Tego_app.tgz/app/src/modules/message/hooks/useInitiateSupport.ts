import { useMutation, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { Message, messageService } from "../services/message.service";
import { useToastStore } from "@/shared/store/toastStore";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";

export const useInitiateSupportMessage = () => {
    const { showToast } = useToastStore();
    const queryClient = useQueryClient();

    const sendMessage = useMutation({
        mutationFn: async (data: Message) => {
          return messageService.contactSupport({
            ...data,
          });
        },
        onMutate: () => {},
        onSuccess: () =>
            queryClient.invalidateQueries({ queryKey: [queryKeys.messages.support]}),
        onError: (error) => {
          const message = getErrorMessage(error);
          showToast("Action Failed", message);
        },
    });

    return {
        sendSupportMessage: sendMessage.mutate,
        isSubmitting: sendMessage.isPending,
    }
};
