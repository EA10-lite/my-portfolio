import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { messageService } from "../services/message.service";


export const useOfferThread = (
    job_request_id: string,
    user_id: string
) => {
  const { data, isLoading } = useQuery({
    queryKey: queryKeys.messages.offerThread(job_request_id, user_id),
    queryFn: () => messageService.getOfferThread(job_request_id, user_id),
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  return {
    conversations: data,
    isLoading,
  };
};
