import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { messageService } from "../services/message.service";

export const useSupport = () => {
  const {
    data,
    isLoading,
  } = useQuery({
    queryKey: queryKeys.messages.offers,
    queryFn: () => messageService.getSupport(),
  });

  return {
    support: data,
    isLoading,
  };
};
