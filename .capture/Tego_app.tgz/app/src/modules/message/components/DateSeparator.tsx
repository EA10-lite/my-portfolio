import { PALETTE } from "@/constants/colors";
import { CustomText } from "@/shared/components";
import { StyleSheet, View } from "react-native";

const DateSeparator = ({ label }: { label: string }) => {
  return (
    <View style={styles.container}>
      <View style={styles.line} />
      <View style={styles.badge}>
        <CustomText size="xs" weight="medium" style={styles.label}>
          {label}
        </CustomText>
      </View>
      <View style={styles.line} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: PALETTE.grey01,
  },
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 100,
    backgroundColor: PALETTE.grey01,
  },
  label: {
    opacity: 0.5,
  },
});

export default DateSeparator;
