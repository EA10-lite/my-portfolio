// modules/message/components/ChatMessage.tsx
import CheckCircleIcon from "@/assets/images/app-icons/check-circle-outline.svg";
import CloseCircleIcon from "@/assets/images/app-icons/close-outline.svg";
import ArrowDouble from "@/assets/images/app-icons/double-arrow.svg";
import ImageIcon from "@/assets/images/app-icons/image.svg";
import StatusIcon from "@/assets/images/app-icons/loading.svg";
import NoteIcon from "@/assets/images/app-icons/note.svg";
import ProfilePlus from "@/assets/images/app-icons/profile-plus.svg";
import SendIcon from "@/assets/images/app-icons/send-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { Offer } from "@/modules/offers/types/offer.dto";
import { NegotiateModal } from "@/modules/request-job/components";
import {
  CustomButton,
  CustomText,
  Tracker,
  UserAvatar,
} from "@/shared/components";
import CImg from "@/shared/components/general/CImg";
import { useModalState } from "@/shared/hooks/useModalState";
import { formatCurrency, formatMessageDate } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useState } from "react";
import { Pressable, StyleSheet, TouchableOpacity, View } from "react-native";
import { useInvitation } from "../hooks/useInvitation";
import {
  ImageMessage,
  InviteMessage,
  Message,
  TextMessage,
} from "../types/message.dto";
import { OfferMessage } from "../types/offer-message.dto";
import DeclineInvite from "./DeclineInvite";
import ImagePreview from "@/shared/components/general/ImagePreviewModal";
import InviteMessageComponent from "./InvitationChat";

interface ChatMessageProps {
  message: Message;
  hideTime?: boolean;
  hideAvatar?: boolean;
}

const ChatMessage = ({ message, hideAvatar, hideTime }: ChatMessageProps) => {
  const { user } = useAuthStore();
  const isMe = message.sender.id === user?.id;
  if (message.type === "text") {
    return (
      <TextMessageComponent
        message={message as TextMessage}
        isMe={isMe}
        hideTime={hideTime}
        hideAvatar={hideAvatar}
      />
    );
  }

  if (message.type === "image") {
    return (
      <ImageMessageComponent
        message={message as ImageMessage}
        isMe={isMe}
        hideTime={hideTime}
        hideAvatar={hideAvatar}
      />
    );
  }

  if (message.type === "INVITE_BOOKING") {
    return (
      <InviteMessageComponentV1 message={message as InviteMessage} isMe={isMe} />
    );
  }

  return null;
};

// Text Message
const TextMessageComponent = ({
  message,
  isMe,
  hideAvatar,
  hideTime,
}: {
  message: TextMessage;
  isMe: boolean;
  hideTime?: boolean;
  hideAvatar?: boolean;
}) => {
  const statusColor =
    message.status === "read" ? PALETTE.primary : PALETTE.grey;

  return (
    <View
      style={[
        styles.messageContainer,
        styles.container,
        isMe && { flexDirection: "row-reverse" },
        {
          marginBottom: hideTime ? 8 : 16,
        },
      ]}
    >
      {/* Avatar placeholder to keep alignment when hidden */}
      {!isMe &&
        (hideAvatar ? (
          <View style={styles.avatarPlaceholder} />
        ) : (
          <UserAvatar
            size="sm"
            name={message.sender.name}
            url={message.sender.avatar}
          />
        ))}

      <View style={[styles.messageGroup, isMe && { alignItems: "flex-end" }]}>
        <View
          style={[
            styles.message,
            isMe ? styles.sender : styles.recipient,
            {
              borderRadius: 10,
              borderBottomLeftRadius: !isMe && !hideTime ? 0 : 10,
              borderBottomRightRadius: isMe && !hideTime ? 0 : 10,
            },
          ]}
        >
          <CustomText
            size="xs"
            weight="medium"
            style={{
              color: isMe ? PALETTE.white : PALETTE.black,
            }}
          >
            {message.text}
          </CustomText>
        </View>

        {!hideTime && (
          <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
            {isMe && message.status && (
              <View
                style={[CUSTOM_STYLES.dot, { backgroundColor: statusColor }]}
              />
            )}
            <CustomText size="xs" weight="medium" style={{ opacity: 0.7 }}>
              {formatMessageDate(message.createdAt)}
            </CustomText>
          </View>
        )}
      </View>
    </View>
  );
};

// Image Message
const ImageMessageComponent = ({
  message,
  isMe,
  hideAvatar,
  hideTime,
}: {
  message: ImageMessage;
  isMe: boolean;
  hideTime?: boolean;
  hideAvatar?: boolean;
}) => {
  const [index, setIndex] = useState<number>(0);
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const isUploading = message.status === "sending";

  const handleImageClick = (index: number) => {
    if (isUploading) return;
    setIndex(index);
    setIsOpen(true);
  };

  const renderImages = () => {
    const count = message.images.length;

    if (count === 1) {
      return (
        <TouchableOpacity
          onPress={() => handleImageClick(0)}
          activeOpacity={isUploading ? 1 : 0.7}
        >
          <CImg uri={message.images[0]} width={240} style={styles.image} />
        </TouchableOpacity>
      );
    }

    if (count === 2) {
      return (
        <View style={styles.doubleContainer}>
          {message.images.map((uri, i) => (
            <TouchableOpacity
              key={i}
              onPress={() => handleImageClick(i)}
              activeOpacity={isUploading ? 1 : 0.7}
            >
              <CImg uri={uri} width={240} style={styles.image} />
            </TouchableOpacity>
          ))}
        </View>
      );
    }

    return (
      <View style={styles.tripleContainer}>
        <TouchableOpacity
          onPress={() => handleImageClick(0)}
          style={[styles.stackCard, styles.leftCard]}
        >
          <CImg uri={message.images[0]} width={240} style={styles.image} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => handleImageClick(1)}
          style={[styles.stackCard, styles.middleCard]}
        >
          <CImg uri={message.images[1]} width={240} style={styles.image} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => handleImageClick(2)}
          style={[styles.stackCard, styles.rightCard]}
        >
          <CImg uri={message.images[2]} width={240} style={styles.image} />
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <>
      <ImagePreview
        visible={isOpen}
        images={message.images}
        selectedIndex={index}
        handleClose={() => setIsOpen(false)}
        canDownload={!isUploading}
      />
      <View
        style={[
          styles.messageContainer,
          styles.container,
          isMe && { flexDirection: "row-reverse" },
        ]}
      >
        {!isMe &&
          (hideAvatar ? (
            <View style={styles.avatarPlaceholder} />
          ) : (
            <UserAvatar
              size="sm"
              name={message.sender.name}
              url={message.sender.avatar}
            />
          ))}

        <View style={[styles.messageGroup, isMe && { alignItems: "flex-end" }]}>
          {/* Images — dimmed while uploading */}
          <View style={{ opacity: isUploading ? 0.5 : 1 }}>
            {renderImages()}
          </View>

          {/* Upload progress card */}
          {isUploading && isMe && (
            <View style={[{ gap: 6, maxWidth: "80%" }]}>
              {message.images.map((uri, i) => {
                const progress = message.uploadProgress?.[i] ?? 0;
                const filename = uri.split("/").pop() ?? `image_${i + 1}.jpg`;

                return (
                  <FileUploading
                    key={i}
                    name={filename}
                    progress={Math.round(progress * 100)}
                    handleCancel={() => {
                      // wire up per-image cancel if needed
                    }}
                  />
                );
              })}
            </View>
          )}

          {/* Caption */}
          {message.text && (
            <View
              style={[styles.message, isMe ? styles.sender : styles.recipient]}
            >
              <CustomText
                size="xs"
                weight="medium"
                style={{ color: isMe ? PALETTE.white : PALETTE.black }}
              >
                {message.text}
              </CustomText>
            </View>
          )}

          {!hideTime && (
            <CustomText size="xs" weight="medium" style={{ opacity: 0.7 }}>
              {formatMessageDate(message.createdAt)}
            </CustomText>
          )}
        </View>
      </View>
    </>
  );
};

const InviteMessageComponentV1 = ({
  message,
  isMe,
}: {
  message: InviteMessage;
  isMe: boolean;
}) => {
  const { user } = useAuthStore();
  const sheetRef = useModalState();

  const { acceptInvitation, rejectInvitation, isSubmitting } = useInvitation();

  const handleDecline = () => {
    rejectInvitation(message.id, {
      onSuccess: () => {
        sheetRef.close();
      },
    });
    sheetRef.close();
  };
  const handleAccept = () => {
    acceptInvitation(message.id, {
      onSuccess: () => {
        sheetRef.close();
      },
    });
    sheetRef.close();
  };
  return (
    <>
      <DeclineInvite ref={sheetRef.ref} secondaryAction={handleDecline} />
      <View style={[styles.messageContainer, styles.container]}>
        {!isMe && (
          <UserAvatar
            size="sm"
            name={message.sender.name}
            url={message.sender.avatar}
          />
        )}

        <View style={[styles.messageGroup, isMe && { alignItems: "flex-end" }]}>
          <View style={styles.invite}>
            <View style={[styles.inviteHeader]}>
              <View style={[CUSTOM_STYLES.center, styles.icon]}>
                <ProfilePlus width={16} height={16} color={PALETTE.primary} />
              </View>
              {user?.userType === "CUSTOMER" ? (
                <View style={{ gap: 4 }}>
                  <CustomText
                    weight="semibold"
                    style={{
                      fontSize: 13,
                      color: PALETTE.black,
                    }}
                  >
                    {
                      message.invite.set
                        ? message.invite.set === "ACCEPTED"
                          ? "Booking accepted"
                          : "Booking declined"
                        : message.sender.name
                    }
                  </CustomText>
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={{
                      opacity: 0.5,
                      letterSpacing: -0.24,
                    }}
                  >
                    {
                      message?.invite?.set
                        ? message.invite.set === "ACCEPTED"
                          ? "You accepted the booking"
                          : message.invite.set === "DECLINED"
                            ? "You declined the booking"
                            : "Invites you to book a service"
                        : "Invites you to book a service"
                    }
                  </CustomText>
                </View>
              ) : (
                <CustomText
                  weight="semibold"
                  style={{
                    fontSize: 13,
                    color: PALETTE.black,
                  }}
                >
                  {
                    message.invite.set
                      ? message.invite.set === "ACCEPTED"
                        ? "Booking accepted"
                        : "Booking declined"
                      : "Booking request sent"
                  }
                </CustomText>
              )}
            </View>
            {user?.userType === "CUSTOMER" ? (
              message.invite.status === "PENDING" && (
                <View style={[CUSTOM_STYLES.row, styles.inviteBody]}>
                  <View style={CUSTOM_STYLES.flex}>
                    <CustomButton
                      variant="secondary"
                      title="Decline"
                      size="sm"
                      onPress={sheetRef.open}
                      disabled={isSubmitting}
                    />
                  </View>
                  <View style={CUSTOM_STYLES.flex}>
                    <CustomButton
                      title="Book Now"
                      size="sm"
                      onPress={handleAccept}
                      disabled={isSubmitting}
                    />
                  </View>
                </View>
              )
            ) : (
              <View style={styles.inviteBody}>
                <CustomText weight="medium" size="xs" style={{ opacity: 0.5 }}>
                  {
                    message.invite.set
                      ? message.invite.set === "ACCEPTED"
                        ? "This customer has accepted your booking invitation based on the agreed terms"
                        : "This customer has declined your booking invitation."
                      : "You've invited this customer to book your service based on the agreed terms."
                  }
                </CustomText>
                {!message.invite.set && <View style={[CUSTOM_STYLES.divider]} />}

                {!message.invite.set && (
                  <View style={{ gap: 12 }}>
                    <CustomText
                      weight="medium"
                      size="xs"
                      style={{
                        opacity: 0.5,
                        textTransform: "uppercase",
                        letterSpacing: -0.24,
                      }}
                    >
                      Status
                    </CustomText>
                    <Tracker
                      tracker={[
                        {
                          label: "Request sent",
                          Icon: (
                            <SendIcon
                              width={16}
                              height={16}
                              color={PALETTE.primary}
                            />
                          ),
                        },
                        {
                          label: "Awaiting Reply",
                          Icon: (
                            <StatusIcon
                              width={16}
                              height={16}
                              color={PALETTE.primary}
                            />
                          ),
                        },
                      ]}
                    />
                  </View>
                )}
              </View>
            )}
          </View>
        </View>
      </View>
    </>
  );
};

export const OfferMessageComponent = ({
  message,
  title = "Proposal Offer",
  submitOffer,
  acceptOffer,
  declineOffer,
  isLoading,
  isMe,
}: {
  message: OfferMessage;
  title?: string;
  acceptOffer?: (id: string) => void;
  declineOffer?: (id: string) => void;
  submitOffer?: (offer: Offer) => void;
  isMe: boolean;
  isLoading: boolean;
}) => {
  const modalRef = useModalState();

  const handleSubmitOffer = (offer: Offer) => {
    submitOffer?.(offer);
    modalRef.close();
  };
  return (
    <>
      <NegotiateModal
        ref={modalRef.ref}
        closeModal={modalRef.close}
        isOpen={modalRef.isOpen}
        title="Revise Offer"
        submitOffer={handleSubmitOffer}
        loading={false}
      />

      <View
        style={[
          styles.messageContainer,
          styles.container,
          isMe && { flexDirection: "row-reverse" },
        ]}
      >
        <UserAvatar
          size="sm"
          name={`${message.sender.first_name} ${message.sender.last_name}`}
          url={message.sender.profile_picture ?? ""}
        />
        <View style={[styles.messageGroup, isMe && { alignItems: "flex-end" }]}>
          <View style={styles.offerContainer}>
            {message.message && (
              <View style={styles.offerText}>
                <CustomText weight="medium" size="xs">
                  {message.message}
                </CustomText>
              </View>
            )}
            <View style={styles.offerCard}>
              <View style={[styles.offerHeader, CUSTOM_STYLES.row]}>
                <View style={[CUSTOM_STYLES.row, { gap: 5 }]}>
                  {message.status === "ACCEPTED" ? (
                    <CheckCircleIcon
                      color={PALETTE.primary}
                      width={12}
                      height={12}
                    />
                  ) : message.status === "REJECTED" ? (
                    <CloseCircleIcon
                      color={PALETTE.primary}
                      width={12}
                      height={12}
                    />
                  ) : message.status === "PENDING" && isMe ? (
                    <ArrowDouble color={PALETTE.primary} width={9} height={9} />
                  ) : (
                    <NoteIcon color={PALETTE.primary} width={12} height={12} />
                  )}
                  <CustomText
                    weight="medium"
                    size="xs"
                  >
                    {message.status === "ACCEPTED"
                      ? "Offer Accepted"
                      : message.status === "REJECTED"
                        ? "Offer Declined"
                        : message.status === "EXPIRED"
                          ? "Offer Expired"
                          : title}
                  </CustomText>
                </View>
                <View style={[styles.offerStatus, CUSTOM_STYLES.center]}>
                  <CustomText style={styles.offerStatusText} weight="semibold">
                    {message.status}
                  </CustomText>
                </View>
              </View>
              <View style={styles.offerBody}>
                <View style={{ padding: 16, gap: 15 }}>
                  <View style={{ gap: 5 }}>
                    <CustomText
                      weight="semibold"
                      size="xs"
                      style={{ opacity: 0.5, letterSpacing: -0.24 }}
                    >
                      Price
                    </CustomText>
                    <CustomText weight="bold" style={{ fontSize: 13 }}>
                      {formatCurrency(message.offer.price)}
                    </CustomText>
                  </View>
                  {message.offer.timeline && (
                    <View style={{ gap: 5 }}>
                      <CustomText
                        weight="semibold"
                        size="xs"
                        style={{ opacity: 0.5, letterSpacing: -0.24 }}
                      >
                        Timeline
                      </CustomText>
                      <CustomText weight="bold" style={{ fontSize: 13 }}>
                        {message.offer.timeline.replaceAll('_', " ")}
                      </CustomText>
                    </View>
                  )}
                </View>

                <View
                  style={{
                    padding: 16,
                    borderTopColor: PALETTE.grey01,
                    borderTopWidth: 1,
                  }}
                >
                  <View style={{ gap: 5 }}>
                    <CustomText
                      weight="medium"
                      style={{
                        fontSize: 13,
                        lineHeight: 20,
                        letterSpacing: -0.24,
                        opacity: 0.5,
                      }}
                    >
                      {message.offer.proposal}
                    </CustomText>
                  </View>
                </View>
              </View>
            </View>

            {message.status === "PENDING" && !isMe && (
              <View
                style={[
                  CUSTOM_STYLES.row,
                  { justifyContent: "space-between", marginTop: 14 },
                ]}
              >
                <CustomButton
                  title="Decline"
                  variant="secondary"
                  style={{ width: 77 }}
                  size="sm"
                  onPress={() => declineOffer?.(message.id)}
                  disabled={isLoading}
                />
                <CustomButton
                  title="Revise"
                  variant="secondary"
                  style={{ width: 77 }}
                  size="sm"
                  onPress={modalRef.open}
                  disabled={isLoading}
                />
                <CustomButton
                  title="Accept"
                  style={{ width: 77 }}
                  size="sm"
                  onPress={() => acceptOffer?.(message.id)}
                  disabled={isLoading}
                />
              </View>
            )}
          </View>
        </View>
      </View>
    </>
  );
};

const FileUploading = ({
  name,
  handleCancel,
  progress = 0, // 👈 add this
}: {
  name: string;
  handleCancel: () => void;
  progress?: number; // 👈 0-100
}) => {
  return (
    <View style={styles.uploadingCard}>
      <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
        <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
          <ImageIcon color={PALETTE.primary} width={12} height={12} />
        </View>
        <View style={{ flex: 1, gap: 8 }}>
          <View
            style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}
          >
            <CustomText weight="medium" size="xs" numberOfLines={1}>
              {name}
            </CustomText>
            <Pressable onPress={handleCancel} hitSlop={18}>
              <AntDesign name="close" size={12} />
            </Pressable>
          </View>
          <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
            <View style={[CUSTOM_STYLES.row, { gap: 2 }]}>
              <StatusIcon />
              <CustomText
                weight="medium"
                size="xs"
                style={{ opacity: 0.5, letterSpacing: -0.24 }}
              >
                {progress > 0 ? `${progress}%` : "Uploading..."}
              </CustomText>
            </View>
          </View>
        </View>
      </View>

      {/* Dynamic progress bar */}
      <View style={styles.progressBarContainer}>
        <View
          style={[
            styles.progressBar,
            { width: `${progress}%` }, // 👈 dynamic
          ]}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  messageContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
  },
  container: {
    gap: 12,
    marginBottom: 16,
  },
  messageGroup: {
    gap: 8,
    flex: 1,
  },
  message: {
    padding: 16,
    maxWidth: "80%",
  },
  sender: {
    backgroundColor: PALETTE.primary,
    borderRadius: 10,
    borderBottomRightRadius: 0,
  },
  recipient: {
    backgroundColor: PALETTE.grey,
    borderRadius: 10,
    borderBottomLeftRadius: 0,
    alignSelf: "flex-start",
  },
  image: {
    width: 86,
    height: 94,
    borderRadius: 9,
    backgroundColor: PALETTE.grey,
  },
  fileContainer: {
    flexDirection: "row",
    padding: 12,
    borderRadius: 10,
    gap: 12,
    alignItems: "center",
    maxWidth: "80%",
  },

  // INVITE STYLES
  invite: {
    width: "80%",
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: PALETTE.gray,
  },
  inviteHeader: {
    padding: 16,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
  },
  inviteBody: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
    padding: 16,
    gap: 16,
  },
  button: {
    flex: 1,
  },
  icon: {
    width: 37,
    height: 37,
    borderRadius: 80,
    backgroundColor: PALETTE.white,
  },

  // TWO IMAGES
  doubleContainer: {
    flexDirection: "row",
    gap: 8,
  },

  // THREE IMAGES
  tripleContainer: {
    width: 240,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
    marginBottom: 8,
  },

  stackCard: {
    overflow: "hidden",
    backgroundColor: "#fff",
  },

  leftCard: {
    left: 25,
    transform: [{ rotate: "-19deg" }],
    zIndex: 1,
  },

  middleCard: {
    zIndex: 3,
    borderWidth: 1.58,
    borderColor: PALETTE.white,
    borderRadius: 9,
  },

  rightCard: {
    transform: [{ rotate: "19deg" }],
    right: 19,
    zIndex: 1,
  },
  offerContainer: {
    width: "80%",
    flex: 1,
    gap: 4,
  },
  offerText: {
    padding: 16,
    borderRadius: 10,
    backgroundColor: PALETTE.gray,
    opacity: 0.7,
    lineHeight: -0.24,
  },
  offerCard: {
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
    overflow: "hidden",
  },
  offerHeader: {
    padding: 16,
    justifyContent: "space-between",
  },
  offerBody: {
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
    backgroundColor: PALETTE.white,
  },
  offerStatus: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 3,
    paddingHorizontal: 7,
    height: 17,
  },
  offerStatusText: {
    textTransform: "uppercase",
    color: PALETTE.primary,
    fontSize: 10,
  },
  avatarPlaceholder: {
    width: 32, // match your "sm" UserAvatar size
    height: 32,
  },
  uploadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.4)",
    borderRadius: 9,
    justifyContent: "flex-end", // progress bar at bottom
  },
  progressBarContainer: {
    height: 5,
    backgroundColor: "#E3E3E3",
    borderRadius: 6,
  },
  progressBar: {
    height: 5,
    backgroundColor: PALETTE.primary,
    borderRadius: 6,
  },
  uploadingCard: {
    backgroundColor: PALETTE.gray,
    padding: 16,
    borderRadius: 6,
    gap: 16,
    minWidth: "80%",
  },
});

export default ChatMessage;
