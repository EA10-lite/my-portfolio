import { PALETTE } from "@/constants/colors";
// modules/message/components/ChatMessage.tsx
import CheckIcon from "@/assets/images/app-icons/check.svg";
import CloseIcon from "@/assets/images/app-icons/close.svg";
import StatusIcon from "@/assets/images/app-icons/loading.svg";
import ProfilePlus from "@/assets/images/app-icons/profile-plus.svg";
import SendIcon from "@/assets/images/app-icons/send-outline.svg";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import {
    CustomButton,
    CustomText,
    Tracker,
    UserAvatar,
} from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { View } from "lucide-react-native";
import { StyleSheet } from "react-native";
import { useInvitation } from "../hooks/useInvitation";
import { Invite, InviteMessage } from "../types/message.dto";
import DeclineInvite from "./DeclineInvite";

// Derive tracker steps from actual invite status
type TrackerStep = {
  label: string;
  Icon: React.ReactNode;
  completed: boolean;
};

const TRACKER_STEPS: Record<Invite["status"], TrackerStep[]> = {
  PENDING: [
    {
      label: "Request sent",
      Icon: <SendIcon width={16} height={16} color={PALETTE.primary} />,
      completed: true,
    },
    {
      label: "Awaiting reply",
      Icon: <StatusIcon width={16} height={16} color={PALETTE.primary} />,
      completed: false,
    },
  ],

  ACCEPTED: [
    {
      label: "Request sent",
      Icon: <SendIcon width={16} height={16} color={PALETTE.primary} />,
      completed: true,
    },
    {
      label: "Booking accepted",
      Icon: <CheckIcon width={16} height={16} color={PALETTE.primary} />,
      completed: true,
    },
  ],

  REJECTED: [
    {
      label: "Request sent",
      Icon: <SendIcon width={16} height={16} color={PALETTE.primary} />,
      completed: true,
    },
    {
      label: "Booking declined",
      Icon: <CloseIcon width={16} height={16} color={PALETTE.error} />,
      completed: true,
    },
  ],
};

const InviteMessageComponent = ({
  message,
  isMe,
}: {
  message: InviteMessage;
  isMe: boolean;
}) => {
  const { user } = useAuthStore();
  const sheetRef = useModalState();

  const { acceptInvitation, rejectInvitation, isSubmitting } = useInvitation();

  const { status } = message.invite;

  // Only close the confirmation sheet on API success — not before.
  // Closing eagerly and again in onSuccess was a silent double-close.
  const handleDecline = () => {
    rejectInvitation(message.id, {
      onSuccess: () => sheetRef.close(),
    });
  };

  const handleAccept = () => {
    acceptInvitation(message.id, {
      onSuccess: () => sheetRef.close(),
    });
  };

  const isCustomer = user?.userType === "CUSTOMER";

  return (
    <>
      <DeclineInvite ref={sheetRef.ref} secondaryAction={handleDecline} />

      <View style={[styles.messageContainer, styles.container]}>
        {!isMe && (
          <UserAvatar
            size="sm"
            name={message.sender.name}
            url={message.sender.avatar}
          />
        )}

        <View style={[styles.messageGroup, isMe && { alignItems: "flex-end" }]}>
          <View style={styles.invite}>
            {/* ── Header ── */}
            <View style={styles.inviteHeader}>
              <View style={[CUSTOM_STYLES.center, styles.icon]}>
                <ProfilePlus width={16} height={16} color={PALETTE.primary} />
              </View>

              {isCustomer ? (
                <View style={{ gap: 4 }}>
                  <CustomText
                    weight="semibold"
                    style={{ fontSize: 13, color: PALETTE.black }}
                  >
                    {message.sender.name}
                  </CustomText>
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={{ opacity: 0.5, letterSpacing: -0.24 }}
                  >
                    Invites you to book a service
                  </CustomText>
                </View>
              ) : (
                <CustomText
                  weight="semibold"
                  style={{ fontSize: 13, color: PALETTE.black }}
                >
                  Booking request sent
                </CustomText>
              )}
            </View>

            {/* ── Body ── */}
            {isCustomer ? (
              <CustomerInviteBody
                status={status}
                isSubmitting={isSubmitting}
                onDecline={sheetRef.open}
                onAccept={handleAccept}
              />
            ) : (
              <ProviderInviteBody status={status} />
            )}
          </View>
        </View>
      </View>
    </>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Customer view
// ─────────────────────────────────────────────────────────────────────────────
const CustomerInviteBody = ({
  status,
  isSubmitting,
  onDecline,
  onAccept,
}: {
  status: Invite["status"];
  isSubmitting: boolean;
  onDecline: () => void;
  onAccept: () => void;
}) => {
  if (status === "PENDING") {
    return (
      <View style={[CUSTOM_STYLES.row, styles.inviteBody]}>
        <View style={CUSTOM_STYLES.flex}>
          <CustomButton
            variant="secondary"
            title="Decline"
            size="sm"
            onPress={onDecline}
            disabled={isSubmitting}
          />
        </View>
        <View style={CUSTOM_STYLES.flex}>
          <CustomButton
            title="Book Now"
            size="sm"
            onPress={onAccept}
            disabled={isSubmitting}
          />
        </View>
      </View>
    );
  }

  // Show resolved state instead of rendering nothing
  const resolvedLabel =
    status === "ACCEPTED"
      ? "You've accepted this booking."
      : "You've declined this booking.";

  return (
    <View style={styles.inviteBody}>
      <CustomText
        weight="medium"
        size="xs"
        style={{
          opacity: 0.5,
          color: status === "REJECTED" ? PALETTE.error : undefined,
        }}
      >
        {resolvedLabel}
      </CustomText>
    </View>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Provider view
// ─────────────────────────────────────────────────────────────────────────────
const ProviderInviteBody = ({ status }: { status: Invite["status"] }) => (
  <View style={styles.inviteBody}>
    <CustomText weight="medium" size="xs" style={{ opacity: 0.5 }}>
      You've invited this customer to book your service based on the agreed
      terms.
    </CustomText>
    <View style={CUSTOM_STYLES.divider} />
    <View style={{ gap: 12 }}>
      <CustomText
        weight="medium"
        size="xs"
        style={{
          opacity: 0.5,
          textTransform: "uppercase",
          letterSpacing: -0.24,
        }}
      >
        Status
      </CustomText>
      {/* Tracker now driven by real invite status */}
      <Tracker tracker={TRACKER_STEPS[status]} />
    </View>
  </View>
);

const styles = StyleSheet.create({
  messageContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
  },
  container: {
    gap: 12,
    marginBottom: 16,
  },
  messageGroup: {
    gap: 8,
    flex: 1,
  },
  message: {
    padding: 16,
    maxWidth: "80%",
  },
  sender: {
    backgroundColor: PALETTE.primary,
    borderRadius: 10,
    borderBottomRightRadius: 0,
  },

  // INVITE STYLES
  invite: {
    width: "80%",
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: PALETTE.gray,
  },
  inviteHeader: {
    padding: 16,
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
  },
  inviteBody: {
    backgroundColor: PALETTE.success,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
    padding: 16,
    gap: 16,
    flex: 1,
  },
  button: {
    flex: 1,
  },
  icon: {
    width: 37,
    height: 37,
    borderRadius: 80,
    backgroundColor: PALETTE.white,
  },
});


export default InviteMessageComponent