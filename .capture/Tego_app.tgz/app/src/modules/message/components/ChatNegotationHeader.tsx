import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, UserAvatar } from "@/shared/components";
import AntDesign from "@expo/vector-icons/AntDesign";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Receiver } from "../hooks/useConversations";

const ChatNegotiatingHeader = ({
  name,
  profile_picture,
} : {
  name: string;
  profile_picture: string;
}) => {
  const insets = useSafeAreaInsets();
  const goBack = () => router.back();
  return (
    <LinearGradient
      colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={[
        CUSTOM_STYLES.row,
        styles.header,
        { paddingTop: insets.top + 32 },
      ]}
    >
      <View style={[CUSTOM_STYLES.row, { gap: 10 }]}>
        <UserAvatar
          url={profile_picture}
          name={name}
        />

        <View style={{ gap: 5 }}>
          <CustomText size="sm" weight="semibold">
            {name}
          </CustomText>
          <CustomText size="xs" weight="regular" style={{ opacity: 0.5 }}>
            Customer · Provider
          </CustomText>
        </View>
      </View>

      <Pressable onPress={goBack} hitSlop={17}>
        <AntDesign name="close" size={14} />
      </Pressable>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  header: {
    gap: 15,
    paddingHorizontal: 20,
    paddingBottom: 29,
    justifyContent: "space-between",
    alignItems: "flex-start",
  },

  roundedCorners: {
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    zIndex: 99,
  },

  text: {
    opacity: 0.7,
    fontSize: 13,
    color: PALETTE.white,
    width: 500,
  },
  dot: {
    width: 1,
  },
});

export default ChatNegotiatingHeader;
