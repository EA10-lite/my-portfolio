import { PALETTE } from "@/constants/colors";
import React from "react";
import { StyleSheet, View } from "react-native";

const SkeletonBox = ({ style }: { style?: any }) => {
  return <View style={[styles.skeleton, style]} />;
};

const MessageCardSkeleton = () => {
  return (
    <View style={styles.card}>
      {/* Avatar */}
      <View style={styles.image}>
        <SkeletonBox style={styles.avatar} />

        {/* status dot placeholder */}
        <View style={styles.activeWrapper}>
          <SkeletonBox style={styles.activeDot} />
        </View>
      </View>

      {/* Text content */}
      <View style={styles.textContent}>
        {/* top row */}
        <View style={styles.row}>
          <SkeletonBox style={styles.name} />
          <SkeletonBox style={styles.time} />
        </View>

        {/* bottom row */}
        <View style={styles.row}>
          <SkeletonBox style={styles.message} />

          <SkeletonBox style={styles.badge} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 6,
    paddingHorizontal: 20,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: PALETTE.grey01,
  },

  image: {
    position: "relative",
  },

  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },

  activeWrapper: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: PALETTE.white,
    justifyContent: "center",
    alignItems: "center",
  },

  activeDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },

  textContent: {
    flex: 1,
    gap: 10,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  skeleton: {
    backgroundColor: "#E1E9EE",
    overflow: "hidden",
  },

  name: {
    width: 120,
    height: 12,
    borderRadius: 4,
  },

  time: {
    width: 40,
    height: 10,
    borderRadius: 4,
  },

  message: {
    width: "60%",
    height: 10,
    borderRadius: 4,
  },

  badge: {
    width: 16,
    height: 16,
    borderRadius: 8,
  },
});

export default MessageCardSkeleton;
