import { View } from "react-native";

interface ChatImagePreviewProps {
  images: string[];
}

const ChatImagePreview = ({ images }: ChatImagePreviewProps) => {
  return <View></View>;
};

export default ChatImagePreview;
