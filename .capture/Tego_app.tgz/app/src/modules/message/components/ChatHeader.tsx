import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  CustomText,
  GoBack,
  UserAvatar,
  WarningText,
} from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet, View } from "react-native";

const ChatHeader = ({
  username,
  url,
  isOnline,
}: {
  username: string;
  url: string;
  isOnline: boolean;
}) => {
  return (
    <View style={styles.container}>
      <WarningText />

      <View style={[styles.roundedCorners, { backgroundColor: PALETTE.white }]}>
        <LinearGradient
          colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
          locations={[0, 1]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={[
            styles.header,
            CUSTOM_STYLES.row,
            styles.roundedCorners,
            { paddingTop: 18 },
          ]}
        >
          <GoBack />

          <View style={[CUSTOM_STYLES.row, { gap: 10 }]}>
            <UserAvatar url={url} name={username} />

            <View style={{ gap: 5 }}>
              <CustomText size="sm" weight="semibold">
                {username}
              </CustomText>

              <View style={[CUSTOM_STYLES.row, { gap: 3.33 }]}>
                <View
                  style={[
                    CUSTOM_STYLES.dot,
                    {
                      backgroundColor: isOnline
                        ? PALETTE.success
                        : PALETTE.black20,
                    },
                  ]}
                />

                <CustomText size="xs" weight="regular" style={{ opacity: 0.5 }}>
                  {isOnline ? "Online" : "Offline"}
                </CustomText>
              </View>
            </View>
          </View>
        </LinearGradient>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},

  header: {
    gap: 15,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },

  roundedCorners: {
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    zIndex: 99,
  },

  text: {
    opacity: 0.7,
    fontSize: 13,
    color: PALETTE.white,
    width: 500,
  },
});

export default ChatHeader;
