import DoubleCheck from "@/assets/images/app-icons/double-checkmark.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, UserAvatar } from "@/shared/components";
import { formatTimeForDisplay, getInitials } from "@/shared/utils/formatter";
import { StyleSheet, TouchableOpacity, View } from "react-native";

interface MessageCardProps {
  chatId: string;
  isActive?: boolean;
  message: string;
  isRead: boolean;
  user: {
    name: string;
    url: string;
  };
  date: string;
  currentMessage: number;
  goToChat: () => void;
  isNegotation?: boolean;
}

const MessageCard = ({
  chatId,
  isActive,
  message,
  isRead,
  user,
  date,
  currentMessage,
  goToChat,
  isNegotation,
}: MessageCardProps) => {
  return (
    <TouchableOpacity onPress={goToChat}>
      <View
        style={[
          styles.card,
          { backgroundColor: isRead ? "transparent" : PALETTE.grey01 },
        ]}
      >
        <View style={styles.content}>
          <View style={styles.image}>
            <UserAvatar name={user.name} url={user.url} size="md" />

            {isActive && (
              <View style={[styles.activeWrapper, CUSTOM_STYLES.center]}>
                <View style={styles.active} />
              </View>
            )}
            {isNegotation && (
              <View
                style={[
                  styles.activeWrapper,
                  styles.activeNegotiationWrapper,
                  CUSTOM_STYLES.center,
                ]}
              >
                <CustomText
                  weight="medium"
                  style={{ fontSize: 6 }}
                  color="primary"
                >
                  {getInitials(user.name)}
                </CustomText>
              </View>
            )}
          </View>

          <View style={styles.textContent}>
            <View style={[styles.row]}>
              <CustomText size="xs" weight="semibold">
                {isNegotation ? message : user.name}
              </CustomText>
              <CustomText size="xs" weight="medium" style={{ opacity: 0.5 }}>
                {formatTimeForDisplay(date)}
              </CustomText>
            </View>
            <View style={[styles.row]}>
              <CustomText
                weight="medium"
                size="xs"
                style={styles.message}
                numberOfLines={1}
              >
                {message}
              </CustomText>
              {isRead ? (
                <DoubleCheck width={16} height={16} color={PALETTE.black} />
              ) : (
                <View style={[styles.count, CUSTOM_STYLES.center]}>
                  <CustomText weight="semibold" style={styles.label}>
                    {currentMessage}
                  </CustomText>
                </View>
              )}
            </View>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 6,
    paddingHorizontal: 20,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  content: { gap: 8, flexDirection: "row", alignItems: "center" },
  image: {
    position: "relative",
  },
  activeWrapper: {
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 8000,
    backgroundColor: PALETTE.white,
  },
  activeNegotiationWrapper: {
    borderWidth: 1.63,
    borderColor: PALETTE.primary10,
    width: 16,
    height: 16,
    borderRadius: 8000,
    backgroundColor: PALETTE.white,
  },
  active: {
    width: 6,
    height: 6,
    borderRadius: 12,
    backgroundColor: PALETTE.success,
  },

  textContent: { flex: 1, gap: 8 },
  row: {
    justifyContent: "space-between",
    flexDirection: "row",
    alignItems: "center",
  },
  message: {
    opacity: 0.6,
    maxWidth: "57%",
  },
  count: {
    width: 16,
    height: 16,
    borderRadius: 36,
    backgroundColor: PALETTE.primary,
  },
  label: {
    color: PALETTE.white,
    fontSize: 9,
    letterSpacing: -0.24,
  },
});

export default MessageCard;
