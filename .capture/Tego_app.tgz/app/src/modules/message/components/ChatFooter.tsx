import SendIcon from "@/assets/images/app-icons/send.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import AntDesign from "@expo/vector-icons/AntDesign";
import { useState } from "react";
import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import ImagePreview from "@/shared/components/general/ImagePreviewModal";

interface ChatFooterProps {
  value: string;
  handleChange: (text: string) => void;
  handleFileSelect: () => void;
  handleSend: () => void;
  disabled?: boolean;
  // Selected images before sending
  selectedImages?: string[];
  onRemoveImage?: (index: number) => void;
}

const ChatFooter = ({
  value,
  handleChange,
  handleFileSelect,
  handleSend,
  disabled = false,
  selectedImages = [],
  onRemoveImage,
}: ChatFooterProps) => {
  const insets = useSafeAreaInsets();
  const [isFocused, setIsFocused] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(0);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const hasImages = selectedImages.length > 0;
  const canSend = value.trim() || hasImages;

  return (
    <>
      {/* Full screen preview with delete option */}
      <ImagePreview
        visible={isPreviewOpen}
        images={selectedImages}
        selectedIndex={previewIndex}
        handleClose={() => setIsPreviewOpen(false)}
        canDelete
        onDelete={(index) => {
          onRemoveImage?.(index);
          setIsPreviewOpen(false);
        }}
      />

      <View
        style={[
          styles.container,
          { paddingBottom: isFocused ? 0 : insets.bottom, paddingTop: 10 },
        ]}
      >
        {/* Selected images preview strip */}
        {hasImages && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.imageStrip}
          >
            {selectedImages.map((uri, index) => (
              <View key={index} style={styles.imageThumbContainer}>
                <Pressable
                  onPress={() => {
                    setPreviewIndex(index);
                    setIsPreviewOpen(true);
                  }}
                >
                  <Image source={{ uri }} style={styles.imageThumb} />
                </Pressable>
                {/* Remove button */}
                <Pressable
                  style={[styles.removeButton, CUSTOM_STYLES.center]}
                  onPress={() => onRemoveImage?.(index)}
                  hitSlop={{ top: 12, bottom: 22, left: 15, right: 10 }}
                >
                  <AntDesign name="close" size={8} color={PALETTE.error} />
                </Pressable>
              </View>
            ))}
          </ScrollView>
        )}

        {/* Input row */}
        <View style={[CUSTOM_STYLES.row, styles.inputRow]}>
          <Pressable
            style={[styles.add, styles.box, CUSTOM_STYLES.center]}
            onPress={handleFileSelect}
            disabled={disabled || selectedImages.length >= 3}
            hitSlop={2}
          >
            <AntDesign name="plus" size={16} color={PALETTE.primary} />
          </Pressable>

          <TextInput
            style={styles.input}
            placeholder="Type a message..."
            placeholderTextColor={PALETTE.grey}
            value={value}
            onChangeText={handleChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            multiline
            maxLength={500}
          />

          <Pressable
            style={[
              styles.send,
              styles.box,
              CUSTOM_STYLES.center,
              !canSend && { opacity: 0.5 },
            ]}
            onPress={handleSend}
            disabled={!canSend || disabled}
            hitSlop={2}
          >
            <SendIcon color={PALETTE.white} />
          </Pressable>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    paddingHorizontal: 20,
  },
  inputRow: {
    justifyContent: "space-between",
    gap: 12,
  },
  input: {
    flex: 1,
    backgroundColor: PALETTE.grey,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 100,
    maxHeight: 45,
  },
  add: {
    backgroundColor: PALETTE.grey,
  },
  send: {
    backgroundColor: PALETTE.primary,
  },
  box: {
    width: 44,
    height: 44,
    borderRadius: 88,
  },
  imageStrip: {
    gap: 8,
    paddingBottom: 10,
  },
  imageThumbContainer: {
    position: "relative",
  },
  imageThumb: {
    width: 60,
    height: 60,
    borderRadius: 8,
  },
  removeBtn: {
    position: "absolute",
    top: -6,
    right: -6,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: PALETTE.black,
    justifyContent: "center",
    alignItems: "center",
  },
  removeButton: {
    position: "absolute",
    top: 4,
    right: 4,
    backgroundColor: PALETTE.white,
    borderRadius: 50,
    width: 14,
    height: 14,
    zIndex: 1,
  },
});

export default ChatFooter;
