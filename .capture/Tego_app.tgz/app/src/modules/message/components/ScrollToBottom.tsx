// modules/message/components/ScrollToBottomButton.tsx
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Arrow } from "@/shared/components";
import { Pressable, StyleSheet } from "react-native";

interface ScrollToBottomButtonProps {
  onPress: () => void;
}

const ScrollToBottomButton = ({ onPress }: ScrollToBottomButtonProps) => {
  return (
    <Pressable style={[styles.button, CUSTOM_STYLES.center]} onPress={onPress} hitSlop={10}>
      <Arrow direction="bottom" size={12} color={PALETTE.primary} />
    </Pressable>
  );
};

const styles = StyleSheet.create({
  button: {
    position: "absolute",
    bottom: 100,
    alignSelf: "center",
    width: 29,
    height: 29,
    borderRadius: 22,
    backgroundColor: "#F8FAFC",
    borderWidth: 0.76,
    borderColor: PALETTE.primary20,
  },
});

export default ScrollToBottomButton;
