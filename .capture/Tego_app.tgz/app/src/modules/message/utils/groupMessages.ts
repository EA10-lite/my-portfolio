import { Message } from "../types/message.dto";

export type DateSeparator = {
  id: string;
  type: "date_separator";
  date: string;
  label: string;
};

export type MessageGroup = {
  id: string;
  type: "message_group";
  messages: Message[];
  senderId: string;
  lastTime: string; // only show time for the last message in the group
};

export type FlatListItem = DateSeparator | MessageGroup;

function parseDate(dateStr: string): Date {
  // Android can choke on ISO strings — ensure it parses correctly
  return new Date(dateStr.replace(" ", "T"));
}

function getDateLabel(dateStr: string): string {
  const date = parseDate(dateStr);
  const now = new Date();

  // Compare by date only, not time
  const dateOnly = new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate(),
  );
  const todayOnly = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const diffMs = todayOnly.getTime() - dateOnly.getTime();
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24)); // 👈 Math.round not floor

  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  if (diffDays <= 6) {
    return date.toLocaleDateString("en-US", { weekday: "long" });
  }
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    ...(date.getFullYear() !== now.getFullYear() && { year: "numeric" }),
  });
}

function isSameDay(a: string, b: string): boolean {
  const da = parseDate(a);
  const db = parseDate(b);
  return (
    da.getFullYear() === db.getFullYear() &&
    da.getMonth() === db.getMonth() &&
    da.getDate() === db.getDate()
  );
}

function minutesDiff(a: string, b: string): number {
  return Math.abs(parseDate(a).getTime() - parseDate(b).getTime()) / 60000;
}

export function groupMessages(messages: Message[]): FlatListItem[] {
  if (!messages.length) return [];

  // messages are in reverse order (FlatList inverted)
  // so we reverse to process chronologically, then reverse back
  const chronological = [...messages].reverse();

  const groups: MessageGroup[] = [];
  let currentGroup: MessageGroup | null = null;

  for (const message of chronological) {
    const shouldStartNewGroup =
      !currentGroup ||
      currentGroup.senderId !== message.sender.id ||
      minutesDiff(currentGroup.lastTime, message.createdAt) > 10;

    if (shouldStartNewGroup) {
      currentGroup = {
        id: `group-${message.id}`,
        type: "message_group",
        messages: [message],
        senderId: message.sender.id,
        lastTime: message.createdAt,
      };
      groups.push(currentGroup);
    } else {
      if (currentGroup) {
        currentGroup.messages.push(message);
        currentGroup.lastTime = message.createdAt;
      }
    }
  }

  // Now inject date separators between groups
  const result: FlatListItem[] = [];
  let lastDate: string | null = null;

  for (const group of groups) {
    const groupDate = group.lastTime;

    if (!lastDate || !isSameDay(lastDate, groupDate)) {
      result.push({
        id: `date-${groupDate}`,
        type: "date_separator",
        date: groupDate,
        label: getDateLabel(groupDate),
      });
      lastDate = groupDate;
    }

    result.push(group);
  }

  // Reverse back for inverted FlatList
  return result.reverse();
}
