import type { Chat } from "../../hooks/useConversations";
import { updateConversationPreview } from "../conversation";

const baseChat: Chat = {
  contact_id: "contact-1",
  first_name: "Ade",
  last_name: "Bello",
  profile_picture: null,
  available_status: "ONLINE",
  last_message: "old",
  last_message_type: "TEXT",
  last_message_at: "2026-01-01T00:00:00Z",
  unread_count: 2,
};

const incomingText: any = {
  sender_id: "contact-1",
  receiver_id: "me",
  message: "hello",
  message_type: "TEXT",
  created_at: "2026-01-02T00:00:00Z",
};

describe("updateConversationPreview", () => {
  it("moves an existing chat to the top and updates the preview", () => {
    const prev = [
      { ...baseChat },
      { ...baseChat, contact_id: "other", unread_count: 0 },
    ];
    const next = updateConversationPreview(prev, incomingText, {
      incrementUnread: false,
    });

    expect(next).toHaveLength(2);
    expect(next[0].contact_id).toBe("contact-1");
    expect(next[0].last_message).toBe("hello");
    expect(next[0].last_message_at).toBe("2026-01-02T00:00:00Z");
    expect(next[0].unread_count).toBe(2);
  });

  it("increments unread when marked as incoming", () => {
    const next = updateConversationPreview([{ ...baseChat }], incomingText, {
      incrementUnread: true,
    });

    expect(next[0].unread_count).toBe(3);
  });

  it("prepends a new chat for a first-time contact when incrementing", () => {
    const next = updateConversationPreview([], incomingText, {
      incrementUnread: true,
    });

    expect(next).toHaveLength(1);
    expect(next[0].contact_id).toBe("contact-1");
    expect(next[0].unread_count).toBe(1);
    expect(next[0].first_name).toBeDefined();
  });

  it("does not invent chats for own-message previews without a match", () => {
    const next = updateConversationPreview(
      [{ ...baseChat, contact_id: "other" }],
      { ...incomingText, sender_id: "me", receiver_id: "contact-1" },
      { incrementUnread: false },
    );

    expect(next[0].contact_id).toBe("other");
  });

  it("renders image previews as photo", () => {
    const next = updateConversationPreview(
      [{ ...baseChat }],
      {
        sender_id: "contact-1",
        receiver_id: "me",
        message: "",
        message_type: "IMAGE",
        created_at: "2026-01-02T00:00:00Z",
      },
      { incrementUnread: true },
    );

    expect(next[0].last_message).toBe("📷 Photo");
    expect(next[0].last_message_type).toBe("IMAGE");
  });
});