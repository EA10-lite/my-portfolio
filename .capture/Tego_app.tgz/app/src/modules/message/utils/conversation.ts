import type { Chat } from "../hooks/useConversations";

interface ConversationUpdateOptions {
  incrementUnread: boolean;
}

const lastMessageText = (raw: any) =>
  raw.message_type === "IMAGE"
    ? raw.message
      ? `📷 ${raw.message}`
      : "📷 Photo"
    : raw.message;

export const updateConversationPreview = (
  prev: Chat[],
  raw: any,
  { incrementUnread }: ConversationUpdateOptions,
): Chat[] => {
  const existingIndex = prev.findIndex(
    (c) =>
      c.contact_id === raw.sender_id || c.contact_id === raw.receiver_id,
  );

  if (existingIndex !== -1) {
    const updated = [...prev];
    updated[existingIndex] = {
      ...updated[existingIndex],
      last_message: lastMessageText(raw),
      last_message_type: raw.message_type,
      last_message_at: raw.created_at,
      ...(incrementUnread
        ? { unread_count: updated[existingIndex].unread_count + 1 }
        : {}),
    };
    const [chat] = updated.splice(existingIndex, 1);
    return [chat, ...updated];
  }

  if (incrementUnread) {
    const contact = raw.receiver ?? raw.sender;
    const newChat: Chat = {
      contact_id: contact?.id ?? raw.sender_id,
      first_name: contact?.first_name ?? "",
      last_name: contact?.last_name ?? "",
      profile_picture: contact?.profile_picture ?? null,
      available_status: contact?.available_status ?? "ONLINE",
      last_message: lastMessageText(raw),
      last_message_type: raw.message_type,
      last_message_at: raw.created_at,
      unread_count: 1,
    };
    return [newChat, ...prev];
  }

  return prev;
};