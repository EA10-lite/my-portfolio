import { useAuthStore } from "@/modules/auth/stores/authStore";
import { Offer } from "@/modules/offers/types/offer.dto";
import { OfferMessageComponent } from "../components/ChatMessage";
import { OfferMessage } from "../types/offer-message.dto";

interface ChatRoomProps {
  message: OfferMessage;
  submitOffer?: (offer: Offer) => void;
  acceptOffer?: (id: string) => void;
  declineOffer?: (id: string) => void;
  isLoading: boolean;
}

const OfferChatRoom = ({
  message,
  submitOffer,
  acceptOffer,
  declineOffer,
  isLoading,
}: ChatRoomProps) => {
  const { user } = useAuthStore();
  const isMe = message.sender.id === user?.id;
  return (
    <OfferMessageComponent
      message={message}
      submitOffer={submitOffer}
      declineOffer={declineOffer}
      acceptOffer={acceptOffer}
      isLoading={isLoading}
      isMe={isMe}
    />
  );
};

export default OfferChatRoom;
