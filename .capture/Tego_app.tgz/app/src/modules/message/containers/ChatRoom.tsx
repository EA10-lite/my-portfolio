import { Offer } from "@/modules/offers/types/offer.dto";
import { ChatMessage } from "../components";
import { Message } from "../types/message.dto";

interface ChatRoomProps {
  message: Message;
  hideTime?: boolean;
  hideAvatar?: boolean;
}

const ChatRoom = ({
  message,
  hideTime,
  hideAvatar,
}: ChatRoomProps) => {
  return (
    <ChatMessage
      message={message}
      hideTime={hideTime}
      hideAvatar={hideAvatar}
    />
  );
};

export default ChatRoom;
