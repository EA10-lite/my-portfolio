import { Pagination } from "@/constants/types";

export type SUBSCRIPTION_TYPE = "PRO_MONTHLY" | "PRO_ANNUAL" | "FREE";
export type SUBSCRIPTION_STATUS = "ACTIVE"
export type CURRENCY = "NGN";


export interface UpgradeSubscription {
    planCode: SUBSCRIPTION_TYPE;
}

export interface SubscriptionPlans {
    plans: SubscriptionPlan[]
}

export interface SubscriptionPlan {
    code: SUBSCRIPTION_TYPE;
    name: string;
    description: string;
    price: number;
    currency: CURRENCY;
    duration_days: number;
    is_active: boolean;
    privileges: string[];
}

export interface MySubscription {
    id: string;
    user_id: string;
    plan: SUBSCRIPTION_TYPE;
    status: SUBSCRIPTION_STATUS;
    plan_name: string;
    plan_price: number;
    plan_currency: CURRENCY;
    privileges: string[];
    amount: number;
    currency: CURRENCY;
    auto_renewal: true,
    started_at: string;
    expires_at: string;
    renewed_at: string;
    created_at: string;
    payment_reference: string;
    payment_provider: string;
    plan_duration_days: number;
}

export interface SubscriptionSuccess {
    amount: number;
    checkout_url:string;
    // "checkout_url": "https://test-checkout.korapay.com/KPY-PI-202608231420Eu7L4z20895/pay",
    currency: "NGN",
    payment_id: string;
    plan_code: SUBSCRIPTION_TYPE
    plan_name: string;
    reference: string;
    status: SUBSCRIPTION_STATUS
}

// GET /api/subscriptions/payment-history?page=1&limit=20

export interface PaymentHistory extends Pagination {
    payments: Payment
}

export interface Payment {
    id: string;
    reference: string;
    status: "SUCCESS" | "FAILED",
    amount: number;
    currency: CURRENCY;
    plan_code: SUBSCRIPTION_TYPE
    checkout_url: string;
    created_at: string;
    paid_at: string
    provider: string;
    channel: string;
    updated_at: string;
}
