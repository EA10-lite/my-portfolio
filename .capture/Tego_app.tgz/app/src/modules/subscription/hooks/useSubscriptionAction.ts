
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { subscriptionService } from "../services/subscription.service";
import { SUBSCRIPTION_TYPE, UpgradeSubscription } from "../types/subscription.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useSubscriptionAction = () => {
    const { showToast } = useToastStore();
    const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const queryClient = useQueryClient();

    const upgrade = useMutation({
        mutationFn: async (data: { planCode: SUBSCRIPTION_TYPE }) => {
            return subscriptionService.upgradePlan({
                ...data,
            });
        },
        onMutate: () => setErrorMessage(null),
        onSuccess: (data) => {
            setCheckoutUrl(data.checkout_url);
            queryClient.invalidateQueries({ queryKey: queryKeys.subscription.mine });
        },
        onError: (error) => {
            const message = getErrorMessage(error);
            setErrorMessage(message);
            showToast("Upgrade Failed", message);
        },
    });

    const downgrade = useMutation({
        mutationFn: () => subscriptionService.downgradePlan(),
        onMutate: () => setErrorMessage(null),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: queryKeys.subscription.mine });
        },
        onError: (error) => {
            const message = getErrorMessage(error);
            setErrorMessage(message);
            showToast("Downgrade Failed", message);
        },
    });

    return {
        errorMessage,
        isSubmitting:
            upgrade.isPending ||
            downgrade.isPending,
        upgrade: upgrade.mutate,
        downgrade: downgrade.mutate,
        checkoutUrl,
        setCheckoutUrl,
    };
};