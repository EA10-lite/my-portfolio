import { useInfiniteQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { subscriptionService } from "../services/subscription.service";


export const usePaymentHistory = () => {
  const {
    data: history,
    isLoading,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useInfiniteQuery({
    queryKey: queryKeys.subscription.paymentHistory,
    queryFn: ({ pageParam }) =>
      subscriptionService.getPaymentHistory(pageParam, 10),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => {
      if (lastPage.page < lastPage.total_pages) {
        return lastPage.page + 1;
      }

      return undefined;
    },
  });

  const payments =
    history?.pages.flatMap((page) => page.payments) ?? [];

  return {
    payments,
    isLoading,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  };
};