import {
  useInfiniteQuery,
  useQueries,
  useQuery,
} from "@tanstack/react-query";

import { queryKeys } from "@/constants/queryKeys";
import { subscriptionService } from "../services/subscription.service";

export const useSubscriptions = () => {
  const [
    {
      data: subscriptions,
      isLoading,
    },
    {
      data: plans,
      isLoading: isPlansLoading,
    }
  ] = useQueries({
    queries: [
      {
        queryKey: queryKeys.subscription.mine,
        queryFn: subscriptionService.getMySubscription,
      },
      {
        queryKey: queryKeys.subscription.plans,
        queryFn: subscriptionService.getSubscriptionPlans,
      }
    ]
  });
  return {
    subscriptions,
    isLoading,
    isPlansLoading,
    plans,
  };
};