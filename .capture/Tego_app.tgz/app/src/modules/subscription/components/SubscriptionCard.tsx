import CalenderIcon from "@/assets/images/app-icons/date-alt.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Badge, CustomText } from "@/shared/components";
import { formatCurrency } from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet, View } from "react-native";

interface SubscriptionPlan {
  plan: string;
  renewalDate?: string;
  price: number;
  period: "monthly" | "yearly";
}

const SubscriptionCard = ({
  plan,
  renewalDate,
  price,
  period,
}: SubscriptionPlan) => {
  return (
    <LinearGradient
      colors={[
        "rgba(51, 171, 247, 0.16)",
        "rgba(255, 255, 255, 0.136)",
        "rgba(141, 141, 141, 0.1)",
      ]}
      locations={[0, 0.867, 1]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={styles.card}
    >
      <View style={styles.body}>
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <Badge title="Current Plan" variant="outline" />
          <Ionicons name="checkmark-circle" size={20} color={PALETTE.primary} />
        </View>

        <View style={{ gap: 4.99 }}>
          <CustomText size="md" weight="bold" style={{ letterSpacing: -0.3 }}>
            {plan}
          </CustomText>
          <CustomText weight="medium" style={styles.price}>
            {formatCurrency(price)} / {period}
          </CustomText>
        </View>
      </View>

      {renewalDate  && (
        <View style={[styles.footer, CUSTOM_STYLES.row]}>
          <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
            <CalenderIcon color={PALETTE.primary} width={12} />
            <CustomText weight="medium" size="xs" style={styles.date}>
              Next Renewal
            </CustomText>
          </View>
          <CustomText weight="medium" size="xs" style={styles.date}>
            {renewalDate}
          </CustomText>
        </View>
        )}
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 6,
    overflow: "hidden",
  },
  body: {
    padding: 20,
    gap: 16,
  },
  price: { letterSpacing: -0.3, fontSize: 13, opacity: 0.5 },
  footer: {
    borderWidth: 1,
    borderColor: PALETTE.grey01,
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    padding: 20,
    justifyContent: "space-between",
  },
  date: {
    opacity: 0.7,
    letterSpacing: -0.24,
  },
});

export default SubscriptionCard;
