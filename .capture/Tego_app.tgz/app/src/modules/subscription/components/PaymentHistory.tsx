import CrownIcon from "@/assets/images/app-icons/crown-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Arrow, CustomText, EmptyMessages } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import {
  formatCurrency,
  formatDateTime,
  truncateText,
} from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetFlatList,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { useCallback, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { usePaymentHistory } from "../hooks/usePaymentHistory";
import { Payment } from "../types/subscription.dto";

interface PaymentHistoryProps {
  histories: Payment[];
  isLoading: boolean;
  hasNextPage: boolean;
  isFetchingNextPage: boolean;
  fetchNextPage: () => void;
}
const PaymentHistory = () => {
  const {
    payments,
    isLoading,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = usePaymentHistory();

  const [isOpen, setIsOpen] = useState<boolean>(false);
  const ref = useRef<BottomSheetModal>(null);
  const openModal = () => {
    setIsOpen(true);
    ref.current?.present();
  };
  const closeModal = () => {
    setIsOpen(false);
    ref.current?.dismiss();
  };

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.89}
        pressBehavior="none"
      />
    ),
    [],
  );

  return (
    <>
      <Pressable
        onPress={openModal}
        style={[CUSTOM_STYLES.row, CUSTOM_STYLES.card, styles.cardHeader]}
      >
        <CustomText weight="semibold" style={{ fontSize: 13 }}>
          PaymentHistory
        </CustomText>
        <Arrow direction="right" size={14} />
      </Pressable>
      <View>
        {Platform.OS === "ios" ? (
          <Modal
            visible={isOpen}
            animationType="slide"
            presentationStyle="pageSheet"
            onRequestClose={closeModal}
            style={{ borderRadius: 50 }}
          >
            <Header closeModal={closeModal} />
            <View style={[styles.content]}>
              <Content
                histories={payments}
                isLoading={isLoading}
                isFetchingNextPage={isFetchingNextPage}
                hasNextPage={hasNextPage}
                fetchNextPage={fetchNextPage}
              />
            </View>
          </Modal>
        ) : (
          <BottomSheetModal
            ref={ref}
            enablePanDownToClose
            backdropComponent={renderBackdrop}
            backgroundStyle={styles.container}
            handleIndicatorStyle={{ height: 0 }}
            handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
            handleComponent={() => <></>}
            snapPoints={["95%"]}
          >
            <BottomSheetView style={styles.container}>
              <Header closeModal={closeModal} />
              <Content
                histories={payments}
                isLoading={isLoading}
                isFetchingNextPage={isFetchingNextPage}
                hasNextPage={hasNextPage}
                fetchNextPage={fetchNextPage}
              />
            </BottomSheetView>
          </BottomSheetModal>
        )}
      </View>
    </>
  );
};

const Content = ({
  histories,
  hasNextPage,
  isFetchingNextPage,
  isLoading,
  fetchNextPage,
}: PaymentHistoryProps) => {
  const { bottom } = useSafeAreaInsets();
  const listProps = {
    data: histories,
    keyExtractor: (item: Payment) => item.id,
    showsVerticalScrollIndicator: false,
    keyboardShouldPersistTaps: "handled",
    onEndReachedThreshold: 0.4,
    onEndReached: () => {
      if (hasNextPage && !isFetchingNextPage) fetchNextPage();
    },
    contentContainerStyle: {
      flexGrow: 1,
      paddingHorizontal: 20,
      paddingTop: 24,
    },
  } as const;

  const renderItem = ({ item, index }: { item: Payment; index: number }) => (
    <PaymentCard history={item} isLast={histories.length - 1 !== index} />
  );

  if (Platform.OS === "ios") {
    return (
      <FlatList
        {...listProps}
        renderItem={renderItem}
        ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
        ListFooterComponent={
          isFetchingNextPage ? (
            <View style={{ gap: 20, marginTop: 20 }}>
              <ActivityIndicator size={"small"} />
            </View>
          ) : null
        }
        contentContainerStyle={{
          paddingBottom: bottom,
          paddingHorizontal: 20,
          flex: 1,
        }}
        ListEmptyComponent={(
            <View style={{ flex: 1 }}>
              <EmptyMessages
                description="Subscribe to our plans to get started"
                title="No activity yet"
                isInTabView={false}
              />
            </View>
          )
        }
      />
    );
  }

  return (
    <BottomSheetFlatList
      {...listProps}
      renderItem={renderItem}
      ItemSeparatorComponent={() => <View style={{ height: 20 }} />}
      ListFooterComponent={
        isFetchingNextPage ? (
          <View style={{ gap: 20, marginTop: 20 }}>
            <ActivityIndicator size={"small"} />
          </View>
        ) : null
      }
      contentContainerStyle={{
        paddingBottom: bottom + 80,
        paddingHorizontal: 20,
      }}
      ListEmptyComponent={
        isLoading ? (
          <View style={{ gap: 20 }}></View>
        ) : (
          <View style={{ flex: 1 }}>
            <EmptyMessages
              description="Subscribe to our plans to get started"
              title="No activity yet"
              isInTabView={false}
            />
          </View>
        )
      }
    />
  );
};

const Header = ({ closeModal }: { closeModal: () => void }) => (
  <View style={[CUSTOM_STYLES.row, styles.header]}>
    <CustomText weight="semibold" size="md" style={{ letterSpacing: -0.24 }}>
      Payment History
    </CustomText>
    <Pressable onPress={closeModal} hitSlop={16}>
      <AntDesign name="close" color={PALETTE.black} size={16} />
    </Pressable>
  </View>
);

const PaymentCard = ({
  isLast,
  history,
}: {
  isLast: boolean;
  history: Payment;
}) => {
  return (
    <View>
      <View style={[styles.field, CUSTOM_STYLES.row]}>
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <View
            style={[
              CUSTOM_STYLES.icon,
              CUSTOM_STYLES.center,
              { backgroundColor: PALETTE.whiteLight },
            ]}
          >
            <CrownIcon color={PALETTE.primary} />
          </View>
          <View style={{ gap: 8 }}>
            <CustomText
              size="xs"
              weight="semibold"
              style={{ textTransform: "capitalize" }}
            >
              {truncateText(history.plan_code.replaceAll("_", " "))}
            </CustomText>
            <CustomText size="xs" weight="medium" style={styles.date}>
              {formatDateTime(history.created_at)}
            </CustomText>
          </View>
        </View>
        <View style={{ gap: 8, alignItems: "flex-end" }}>
          <CustomText size="xs" weight="semibold">
            {formatCurrency(history.amount)}
          </CustomText>

          <View style={[styles.status, CUSTOM_STYLES.row]}>
            <View
              style={[
                CUSTOM_STYLES.dot,
                {
                  backgroundColor:
                    history.status.toLowerCase() === "failed"
                      ? PALETTE.error
                      : history.status.toLowerCase() === "pending"
                        ? PALETTE.yellow
                        : PALETTE.success,
                },
              ]}
            />
            <CustomText weight="semibold" size="xs" style={styles.statusText}>
              {history.status}
            </CustomText>
          </View>
        </View>
      </View>
      {isLast && <View style={styles.divider} />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
    borderRadius: 25,
  },
  header: {
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    flex: 1,
    borderTopEndRadius: 50,
  },
  cardHeader: {
    padding: 20,
    justifyContent: "space-between",
  },
  details: {
    borderWidth: 1,
    borderColor: "#E8E7E766",
    padding: 20,
    borderRadius: 6,
  },
  field: {
    justifyContent: "space-between",
  },
  date: {
    opacity: 0.5,
    letterSpacing: -0.24,
    lineHeight: 19,
  },
  status: {
    borderRadius: 43,
    paddingHorizontal: 10.77,
    gap: 4,
    backgroundColor: PALETTE.gray,
    height: 19,
    alignItems: "center",
    justifyContent: "center",
  },
  statusText: {
    fontSize: 10,
    textTransform: "uppercase",
    opacity: 0.5,
  },
  divider: {
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.black, 0.04),
    marginVertical: 20,
    height: 0,
  },
});

PaymentHistory.displayName = "Report Issue Modal";

export default PaymentHistory;
