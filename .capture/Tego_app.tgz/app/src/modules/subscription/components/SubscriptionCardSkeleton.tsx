import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { LinearGradient } from "expo-linear-gradient";
import { useEffect, useRef } from "react";
import {
  Animated,
  StyleSheet,
  View,
} from "react-native";

const SubscriptionCardSkeleton = () => {
  const opacity = useRef(new Animated.Value(0.4)).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 0.8,
          duration: 700,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0.4,
          duration: 700,
          useNativeDriver: true,
        }),
      ])
    );

    animation.start();

    return () => animation.stop();
  }, [opacity]);

  const SkeletonBox = ({
    width,
    height,
    borderRadius = 4,
  }: {
    width: number;
    height: number;
    borderRadius?: number;
  }) => (
    <Animated.View
      style={[
        styles.skeleton,
        {
          width,
          height,
          borderRadius,
          opacity,
        },
      ]}
    />
  );

  return (
    <LinearGradient
      colors={[
        "rgba(51, 171, 247, 0.16)",
        "rgba(255, 255, 255, 0.136)",
        "rgba(141, 141, 141, 0.1)",
      ]}
      locations={[0, 0.867, 1]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={styles.card}
    >
      {/* Body */}
      <View style={styles.body}>
        {/* Header */}
        <View
          style={[
            CUSTOM_STYLES.row,
            { justifyContent: "space-between" },
          ]}
        >
          <SkeletonBox width={95} height={26} borderRadius={6} />

          <SkeletonBox
            width={20}
            height={20}
            borderRadius={10}
          />
        </View>

        {/* Plan details */}
        <View style={styles.planDetails}>
          <SkeletonBox width={120} height={18} />
          <SkeletonBox width={150} height={14} />
        </View>
      </View>

      {/* Footer */}
      <View style={[styles.footer, CUSTOM_STYLES.row]}>
        <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
          <SkeletonBox
            width={12}
            height={12}
            borderRadius={3}
          />

          <SkeletonBox width={85} height={12} />
        </View>

        <SkeletonBox width={80} height={12} />
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 6,
    overflow: "hidden",
  },

  body: {
    padding: 20,
    gap: 16,
  },

  planDetails: {
    gap: 6,
  },

  footer: {
    borderWidth: 1,
    borderColor: PALETTE.grey01,
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    padding: 20,
    justifyContent: "space-between",
  },

  skeleton: {
    backgroundColor: "rgba(150, 150, 150, 0.25)",
  },
});

export default SubscriptionCardSkeleton;