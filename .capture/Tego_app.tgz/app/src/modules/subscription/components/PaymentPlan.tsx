import CheckIcon from "@/assets/images/app-icons/check.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomButton, CustomText } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import { formatCurrency } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import Ionicons from "@expo/vector-icons/Ionicons";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { forwardRef, useCallback, useState } from "react";
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import {
  MySubscription,
  SUBSCRIPTION_TYPE,
  SubscriptionPlan,
} from "../types/subscription.dto";

interface PaymentPlanProps {
  isOpen: boolean;
  closeModal: () => void;
  plans: SubscriptionPlan[];
  currentPlan: MySubscription;
  handlePayment: (code: SUBSCRIPTION_TYPE) => void;
  isSubmitting: boolean;
}
const PaymentPlan = forwardRef<BottomSheetModal, PaymentPlanProps>(
  (
    { isOpen, closeModal, plans, currentPlan, handlePayment, isSubmitting },
    ref,
  ) => {
    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    return (
      <View>
        {Platform.OS === "ios" ? (
          <Modal
            visible={isOpen}
            animationType="slide"
            presentationStyle="pageSheet"
            onRequestClose={closeModal}
            style={{ borderRadius: 50 }}
          >
            <Header closeModal={closeModal} />
            <View style={[styles.content]}>
              <Content
                activePlan={currentPlan}
                handlePayment={handlePayment}
                plans={plans}
                loading={isSubmitting}
              />
            </View>
          </Modal>
        ) : (
          <BottomSheetModal
            ref={ref}
            enablePanDownToClose
            backdropComponent={renderBackdrop}
            backgroundStyle={styles.container}
            handleIndicatorStyle={{ height: 0 }}
            handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
            handleComponent={() => <></>}
            snapPoints={["95%"]}
          >
            <BottomSheetScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{
                flex: 1,
              }}
            >
              <Header closeModal={closeModal} />
              <View style={[styles.content]}>
                <Content
                  activePlan={currentPlan}
                  handlePayment={handlePayment}
                  plans={plans}
                  loading={isSubmitting}
                />
              </View>
            </BottomSheetScrollView>
          </BottomSheetModal>
        )}
      </View>
    );
  },
);

const Content = ({
  activePlan,
  handlePayment,
  plans,
  loading,
}: {
  activePlan: MySubscription;
  handlePayment: (code: SUBSCRIPTION_TYPE) => void;
  plans: SubscriptionPlan[];
  loading: boolean;
}) => {
  const [selected, setSelected] = useState<"monthly" | "yearly">("monthly");
  return (
    <View style={{}}>
      <View
        style={[
          CUSTOM_STYLES.row,
          { gap: 12, paddingBottom: 10, display: "none" },
        ]}
      >
        <CustomButton
          title="Monthly"
          variant={selected === "monthly" ? "primary" : "secondary"}
          size="sm"
          style={{ width: 90 }}
          onPress={() => setSelected("monthly")}
        />
        <CustomButton
          title="Yearly . 20% off"
          variant={selected === "yearly" ? "primary" : "secondary"}
          size="sm"
          style={{ width: 145 }}
          onPress={() => setSelected("yearly")}
        />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: 80, marginTop: 22 }}
      >
        <View style={{ gap: 12 }}>
          {plans
            .filter((plan) => plan.code !== "FREE")
            .map((plan, index) => (
              <Plan
                key={index}
                period={
                  plan.name.toLowerCase().includes("month") ? "month" : "year"
                }
                name={plan.name}
                price={plan.price}
                benefits={plan.privileges}
                isActivePlan={plan.code === activePlan.plan}
                code={plan.code}
                proceedToPayment={() => handlePayment(plan.code)}
                activePlan={activePlan.plan}
                loading={loading}
              />
            ))}
        </View>
      </ScrollView>
    </View>
  );
};

interface PlanProps {
  isActivePlan: boolean;
  activePlan: SUBSCRIPTION_TYPE;
  name: string;
  benefits: string[];
  price: number;
  period: "month" | "year";
  proceedToPayment: () => void;
  code: SUBSCRIPTION_TYPE;
  loading: boolean;
}

const Plan = ({
  code,
  isActivePlan,
  activePlan,
  name,
  benefits,
  price,
  period,
  loading,
  proceedToPayment,
}: PlanProps) => {
  const isUpgrade =
    activePlan === "FREE" ||
    (activePlan === "PRO_MONTHLY" && code === "PRO_ANNUAL");

  const getPlanActionText = () => {
    if (activePlan === code) return "Current Plan";
    if (isUpgrade) return "Upgrade";
    return "Not Available";
  };
  return (
    <LinearGradient
      colors={[
        "rgba(51, 171, 247, 0.16)",
        "rgba(255, 255, 255, 0.136)",
        "rgba(141, 141, 141, 0.1)",
      ]}
      locations={[0, 0.867, 1]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={styles.plan}
    >
      <View style={styles.planHeader}>
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <CustomText weight="medium" style={styles.planName}>
            {name}
          </CustomText>
          {isActivePlan && (
            <Ionicons
              name="checkmark-circle"
              color={PALETTE.primary}
              size={16.25}
            />
          )}
        </View>
        <CustomText size="lg" weight="bold">
          {formatCurrency(price)}{" "}
          <CustomText weight="medium" style={styles.planName}>
            /per {period}
          </CustomText>
        </CustomText>
      </View>
      <View style={styles.planBody}>
        <View style={{}}>
          {benefits?.map((benefit, index) => (
            <View key={index}>
              <View
                style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}
              >
                <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                  <CheckIcon color={PALETTE.success} width={12.25} height={9} />
                  <CustomText weight="medium" style={styles.benefitName}>
                    {benefit.replaceAll("_", " ")}
                  </CustomText>
                </View>
              </View>

              {benefits?.length - 1 !== index && (
                <View style={styles.divider} />
              )}
            </View>
          ))}
        </View>
        <CustomButton
          title={getPlanActionText()}
          disabled={isActivePlan || loading}
          onPress={proceedToPayment}
        />
      </View>
    </LinearGradient>
  );
};

const Header = ({ closeModal }: { closeModal: () => void }) => (
  <View style={[CUSTOM_STYLES.row, styles.header]}>
    <CustomText weight="semibold" size="md" style={{ letterSpacing: -0.24 }}>
      Payment Plan
    </CustomText>
    <Pressable onPress={closeModal} hitSlop={16}>
      <AntDesign name="close" color={PALETTE.black} size={16} />
    </Pressable>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    flex: 1,
  },
  plan: {
    borderRadius: 6,
    overflow: "hidden",
  },
  planHeader: {
    padding: 20,
  },
  planName: {
    fontSize: 13,
    letterSpacing: -0.3,
    opacity: 0.5,
  },
  benefitName: {
    fontSize: 13,
    letterSpacing: -0.24,
    opacity: 0.7,
    textTransform: "capitalize",
  },
  planBody: {
    backgroundColor: PALETTE.white,
    borderRadius: 6,
    padding: 20,
    gap: 32,
  },
  divider: {
    borderWidth: 1,
    marginVertical: 16,
    borderColor: hexToRgba(PALETTE.black, 0.04),
  },
});

PaymentPlan.displayName = "Report Issue Modal";

export default PaymentPlan;
