import { api } from "@/shared/lib/api";
import {
    MySubscription,
    PaymentHistory,
    SubscriptionPlans,
    SubscriptionSuccess,
    UpgradeSubscription
} from "../types/subscription.dto";


export const subscriptionService =  {
    getSubscriptionPlans: async () => {
        const response = await api.get<SubscriptionPlans>(`/subscriptions/plans`);
        return response.data;
    },
    getSubscriptionStatus: async () => {
        const response = await api.get(`/subscriptions/status`);
        return response.data;
    },
    getMySubscription: async () => {
        const response = await api.get<MySubscription>(`/subscriptions/my-subscription`);
        return response.data;
    },
    getPaymentHistory: async (
        page: number = 1,
        limit: number = 10
    ) => {
        const params = new URLSearchParams({
            page: String(page),
            limit: String(limit),
        });
        const response = await api.get<PaymentHistory>(
            `/subscriptions/payment-history?${params.toString()}`
        );
        return response.data;
    },
    upgradePlan: async (data: UpgradeSubscription) => {
        console.log("DATA:", data);
        const response = await api.post<SubscriptionSuccess>(`/subscriptions/upgrade`, data);
        return response.data;
    },
    downgradePlan: async () => {
        const response = await api.post(`/subscriptions/downgrade`);
        return response.data;
    },
}