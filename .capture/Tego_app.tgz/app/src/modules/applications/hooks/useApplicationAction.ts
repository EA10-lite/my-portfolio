// hooks/useOrder.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { applicationServices } from "../services/applications.services";
import { useToastStore } from "@/shared/store/toastStore";

export const useApplicationActions = () => {
  const  { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const cancel = useMutation({
    mutationFn: ({ id }: { id: string }) => applicationServices.withdraw(id),
    onMutate: () => setErrorMessage(null),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.applications.list });
    },
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message)
    },
  });

  return {
    cancel: cancel.mutate,
    errorMessage,
    isSubmitting: cancel.isPending,
  };
};
