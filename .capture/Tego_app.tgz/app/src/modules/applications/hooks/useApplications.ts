import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { applicationServices } from "../services/applications.services";
import { ApplicationJobRequest, ApplicationOffer } from "../utils/type";

export const useApplications = (status?: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const allApplications = useInfiniteQuery({
    queryKey: queryKeys.applications.list,
    queryFn: ({ pageParam = 1 }) =>
      applicationServices.getProviderApplications(pageParam, 10, status),
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
  });

  const applications: ApplicationOffer[] = useMemo(
    () =>
      allApplications.data?.pages.flatMap((page) => page.offers) ?? [],
    [allApplications.data],
  );

  return {
    applications,
    fetchNextPage: allApplications.fetchNextPage,
    isLoading: allApplications.isLoading,
    hasNextPage: allApplications.hasNextPage,
    isFetchingNextPage: allApplications.isFetchingNextPage,
    errorMessage,
    refetch: allApplications.refetch,
  };
};
