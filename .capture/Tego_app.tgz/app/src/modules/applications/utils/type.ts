import { URGENCY } from "@/constants/types";

export type UserType = "CUSTOMER" | "SERVICE_PROVIDER";
export type AvailableStatus = "ONLINE" | "OFFLINE";
export type Gender = "MALE" | "FEMALE";
export type JobStatus = "PENDING" | "ACCEPTED" | "COMPLETED" | "CANCELLED";
export type OfferStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "WITHDRAWN";
export type MessageDeliveryStatus = "SENT" | "DELIVERED" | "READ";

export interface JobRequestUser {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  gender: Gender;
  user_type: UserType;
  phone_number: string;
  is_phone_verified: boolean;
  is_email_verified: boolean;
  profile_picture: string | null;
  picture_card: string | null;
  available_status: AvailableStatus;
  created_at: string;
  updated_at: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
}

export interface OfferUser {
  id: string;
  first_name: string;
  last_name: string;
  profile_picture: string | null;
  user_type: UserType;
  available_status: AvailableStatus;
  average_rating: number | null;
  is_verified: boolean;
}

export interface OfferDetails {
  price: number;
  proposal: string;
  timeline: string; // or URGENCY if you already have that enum
  availability: string;
}

export interface JobOffer {
  id: string;
  sender: OfferUser;
  receiver: OfferUser;
  content_type: "OFFER";
  message: string;
  media: string[];
  offer: OfferDetails;
  status: OfferStatus;
  message_delivery_status: MessageDeliveryStatus;
  created_at: string;
  updated_at: string;
}

export interface ApplicationJobRequest {
  id: string;
  user: JobRequestUser;

  service_category_id: string;
  service_category: ServiceCategory;

  title: string;
  description: string;

  date: string;

  address: string;
  state: string;
  country: string;
  area: string;

  images: string[];

  start_price: number;
  end_price: number;
  is_budget_negotiable: boolean;

  urgency: URGENCY; // if you already have this type
  status: JobStatus;
  is_cancelled: boolean;

  created_at: string;
  updated_at: string;
}

// export interface ApplicationResponse {
//   job_requests: ApplicationJobRequest[];
//   total: number;
//   page: number;
//   limit: number;
//   total_pages: number;
// }

export interface ApplicationResponse {
  offers: ApplicationOffer[],
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

export interface ApplicationOffer {
  id: string;
  sender: BriefUser;
  receiver: BriefUser;
  content_type: "OFFER",
  message: string;
  offer: {
    price: number;
    proposal: string;
    timeline: string;
    expiresAt: string;
    availability: string;
  }
  job_request: ApplicationJobRequest;
  status: "PENDING",
  message_delivery_status: string;
  expires_at: string;
  expired_at: string;
  created_at: string;
}

export interface BriefUser {
  id: string;
  first_name: string;
  last_name: string;
  profile_picture: string;
  user_type: UserType;
  available_status: AvailableStatus
  average_rating: number;
}