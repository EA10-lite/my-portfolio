import { api } from "@/shared/lib/api";
import { ApplicationResponse } from "../utils/type";

export const applicationServices = {
  getProviderApplications: async (
    page: number = 1,
    limit: number = 10,
    status?: string,
  ) => {
    const response = await api.get<ApplicationResponse>(
      `/offers/provider-offers?page=${page}&limit=${limit}&status=${status}`,
    );
    return response.data;
  },
  withdraw: async (id: string) => {
    console.log(`/offers/job-request/${id}/withdraw`);
    const response = await api.patch(`/offers/job-request/${id}/withdraw`);
    return response.data;
  },
};
