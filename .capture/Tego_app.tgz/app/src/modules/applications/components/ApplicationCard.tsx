import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Arrow,
  CImg,
  CustomButton,
  CustomText,
  DetailsField,
  ImagePreview,
  Status,
  UserAvatar,
} from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { hexToRgba } from "@/shared/utils/converter";
import {
  formatCurrency,
  formatDateTime,
  truncateText,
} from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { router } from "expo-router";
import { Animated, Pressable, StyleSheet, View } from "react-native";
import { ApplicationOffer } from "../utils/type";

const ApplicationCard = ({
  application,
  cancelApplication,
  loading,
  isOpen,
  onToggle,
}: {
  application: ApplicationOffer;
  cancelApplication: () => void;
  loading: boolean;
  isOpen: boolean;
  onToggle: () => void;
}) => {
  const {
    showContent,
    setContentHeight,
    contentHeight,
    rotate,
    animatedHeight,
    opacityAnim,
  } = useExpandableAnimation({ initialState: false, isOpen });

  const handlePress = () => {
    if (application.status.toLowerCase() === "pending") {
      cancelApplication();
    } else if (application.status.toLowerCase() === "accepted") {
      router.push(`/(service-provider)/(tabs)/orders`);
    } else {
      router.push("/(service-provider)/(tabs)/browse-jobs");
    }
  };

  const getPrice = (): string => {
    if (application?.offer.price) {
      return formatCurrency(application?.offer.price);
    }
    return formatCurrency(application.job_request.start_price)
  };
  return (
    <Pressable onPress={onToggle}>
      <View style={[CUSTOM_STYLES.card]}>
        <View style={[CUSTOM_STYLES.cardHeader]}>
          <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
            <UserAvatar
              name={`${application.receiver.first_name} ${application.receiver.last_name}`}
              url={application.receiver.profile_picture ?? ""}
              size="xs"
            />
            <CustomText
              weight="semibold"
              style={{ fontSize: 13, lineHeight: 16, flex: 1 }}
            >
              {application.job_request.title}
            </CustomText>

            <Animated.View
              style={[
                CUSTOM_STYLES.toggleButton,
                CUSTOM_STYLES.center,
                {
                  transform: [{ rotate }],
                  backgroundColor: showContent ? PALETTE.white : PALETTE.grey01,
                },
              ]}
            >
              <Arrow direction="bottom" color={PALETTE.primary} size={20} />
            </Animated.View>
          </View>
          <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
            <View style={[CUSTOM_STYLES.row, { gap: 4, opacity: 0.5 }]}>
              <Ionicons name="location-sharp" size={16} color={PALETTE.black} />
              <CustomText weight="medium" size="xs">
                {truncateText(application.job_request.address, 20)}
              </CustomText>
            </View>
            <View style={[CUSTOM_STYLES.dot, { backgroundColor: "#E3E3E3" }]} />
            <View style={[CUSTOM_STYLES.row, { gap: 4, opacity: 0.5 }]}>
              <Ionicons name="time" size={16} color={PALETTE.black} />
              <CustomText weight="semibold" size="xs">
                {formatDateTime(application.job_request.date)}
              </CustomText>
            </View>
          </View>
        </View>
        <View style={[CUSTOM_STYLES.cardContent]}>
          <View style={styles.body}>
            <View
              style={[CUSTOM_STYLES.row, { gap: 8, paddingHorizontal: 20 }]}
            >
              <View style={styles.tag}>
                <CustomText weight="semibold" style={styles.tagText}>
                  {application.job_request.service_category.name}
                </CustomText>
              </View>
              {application.job_request.images.length > 0 && <View
                style={[CUSTOM_STYLES.dot, { backgroundColor: "#E3E3E3" }]}
              />}
              <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                <View style={[CUSTOM_STYLES.row]}>
                  {application.job_request.images.map((image, index) => (
                    <View
                      style={{
                        marginLeft: index === 0 ? 0 : -8,
                        zIndex: index + 1,
                      }}
                      key={index}
                    >
                      <CImg uri={image} width={80} style={styles.image} />
                    </View>
                  ))}
                </View>
                {application.job_request.images.length > 0 && (
                  <CustomText size="xs" weight="medium" style={{ opacity: 0.5 }}>
                    {application.job_request.images.length} images
                  </CustomText>
                )}
              </View>
            </View>
            <Animated.View
              style={[
                {
                  height: animatedHeight,
                  overflow: "hidden",
                },
              ]}
            >
              <View
                onLayout={(event) => {
                  const height = event.nativeEvent.layout.height;

                  if (height > 0 && height !== contentHeight) {
                    setContentHeight(height);
                  }
                }}
                style={{
                  position: "absolute",
                  width: "100%",
                }}
              >
                <View>
                  <DetailsField
                    type="note"
                    label="Title"
                    value={application.job_request.title}
                  />
                  <DetailsField
                    type="address"
                    label="Location"
                    value={application.job_request.address}
                  />
                  <DetailsField
                    type="budget"
                    label="Budget"
                    value={getPrice()}
                  />
                  <DetailsField
                    type="date"
                    label="Date & Time"
                    value={application.job_request.date && formatDateTime(application.job_request.date)}
                  />
                  <DetailsField
                    type="status"
                    label="Status"
                    value={application.status}
                  />
                  <DetailsField
                    type="check"
                    label="Estimated Completion"
                    value={application.offer.timeline}
                  />
                  <DetailsField
                    type="note"
                    label="Proposal"
                    value={application.offer.proposal}
                    isLast
                  />
                  <View style={{ paddingHorizontal: 20 }}>
                    <ImagePreview images={application.job_request.images} />
                  </View>
                </View>
              </View>
            </Animated.View>
          </View>
          {showContent ? (
            <Animated.View
              style={[CUSTOM_STYLES.cardFooter, { opacity: opacityAnim }]}
            >
              <CustomButton
                title={
                  application.status.toLowerCase() === "accepted"
                    ? "View Order"
                    : application.status.toLowerCase() === "pending"
                      ? "Cancel Application"
                      : "Browse Jobs"
                }
                // onPress={}
                onPress={handlePress}
                loading={loading}
              />
            </Animated.View>
          ) : (
            <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.cardFooter]}>
              <View style={{ gap: 4 }}>
                <CustomText weight="semibold" style={{ fontSize: 13 }}>
                  {application.job_request.start_price !== application.job_request.end_price 
                    ? `${formatCurrency(application.job_request.start_price)} - ${formatCurrency(application.job_request.end_price)}`
                    : formatCurrency(application.job_request.start_price)}
                </CustomText>
              </View>
              <Status
                label={
                  application.status.toLowerCase() === "pending"
                    ? "Awaiting Start"
                    : application.status
                }
                status={application.status}
                variant={"default"}
              />
            </View>
          )}
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  body: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: hexToRgba(PALETTE.black, 0.1),
  },
  tag: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 3,
    paddingHorizontal: 10.77,
    paddingVertical: 4,
  },
  tagText: {
    textTransform: "uppercase",
    fontSize: 11,
    opacity: 0.5,
  },
  image: {
    width: 20,
    height: 20,
    borderRadius: 40,
    backgroundColor: PALETTE.grey01,
    borderWidth: 1,
    borderColor: PALETTE.gray,
  },
  button: {
    width: 108,
  },
});

export default ApplicationCard;
