// components/ProviderOrderCardSkeleton.tsx
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { usePulse } from "@/shared/hooks/usePulse";
import { Animated, StyleSheet, View } from "react-native";

const Block = ({ style }: { style: object }) => {
  const opacity = usePulse();
  return <Animated.View style={[styles.block, style, { opacity }]} />;
};

const ApplicationCardSkeleton = () => {
  return (
    <View style={[CUSTOM_STYLES.card]}>
      <View style={[CUSTOM_STYLES.cardHeader]}>
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <Block style={styles.avatar} />
          <Block style={styles.title} />
          <Block style={styles.toggle} />
        </View>
        <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
          <Block style={styles.metaChip} />
          <Block style={styles.metaChip} />
        </View>
      </View>

      <View style={[CUSTOM_STYLES.cardContent]}>
        <View style={styles.body}>
          <View style={[CUSTOM_STYLES.row, { gap: 8, paddingHorizontal: 20 }]}>
            <Block style={styles.tag} />
            <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
              <Block style={styles.imageStack} />
              <Block style={styles.imageCountText} />
            </View>
          </View>
        </View>

        <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.cardFooter]}>
          <Block style={styles.price} />
          <Block style={styles.statusPill} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  block: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 4,
  },
  avatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
  },
  title: {
    flex: 1,
    height: 14,
  },
  toggle: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  metaChip: {
    width: 80,
    height: 12,
  },
  body: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "transparent",
  },
  tag: {
    width: 64,
    height: 20,
    borderRadius: 3,
  },
  imageStack: {
    width: 56,
    height: 20,
    borderRadius: 40,
  },
  imageCountText: {
    width: 50,
    height: 11,
  },
  price: {
    width: 70,
    height: 14,
  },
  statusPill: {
    width: 90,
    height: 24,
    borderRadius: 20,
  },
});

export default ApplicationCardSkeleton;
