import { api } from "@/shared/lib/api";
import { SendRequestOffer } from "../types/offer.dto";

export const offerServices = {
  getRequestOffers: async (request_id: string, user_id: string) => {
    const response = await api.get(`/offers/${request_id}/${user_id}`);
    return response.data;
  },
  sendRequestOffer: async (data: SendRequestOffer) => {
    const response = await api.post(`/offers`, {
      ...data,
      offer: {
        ...data.offer,
        price: parseInt(data.offer.price)
      }
    });
    return response.data;
  },
  updateRequestOffer: async (
    offer_id: string,
    status: "ACCEPTED" | "REJECTED",
  ) => {
    const response = await api.patch(`/offers/${offer_id}/status`, {
      status,
    });
    return response.data;
  },
};
