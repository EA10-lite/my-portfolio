import { URGENCY } from "@/constants/types";

export interface SendRequestOffer extends SendOffer {
  job_request_id?: string;
  book_service_id?: string;
}

export interface SendBookingOffer extends SendOffer {
  book_service_id: string;
}

export interface SendOffer {
  receiver_id: string;
  content_type: "OFFER";
  message: string;
  media?: string[];
  offer: Offer;
}

export interface Offer {
  price: string;
  timeline: string;
  proposal: string;
  availability?: URGENCY;
}
