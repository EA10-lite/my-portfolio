import { queryKeys } from "@/constants/queryKeys";
import {
  CLOUDINARY_FOLDERS,
  uploadManyToCloudinary,
} from "@/shared/lib/cloudinary";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { offerServices } from "../services/offers.services";
import { SendRequestOffer } from "../types/offer.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useOfferActions = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const invalidateOffers = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.all });
    queryClient.invalidateQueries({ queryKey: queryKeys.messages.offers });
    queryClient.invalidateQueries({
      queryKey: queryKeys.messages.offerThreadPrefix,
    });
  };

  const sendRequestOffer = useMutation({
    mutationFn: async (data: SendRequestOffer) => {
      // 1. Upload images to Cloudinary first if any
      let imageUrls: string[] = [];

      if (data.media && data.media.length > 0) {
        const uploaded = await uploadManyToCloudinary(data.media, {
          folder: CLOUDINARY_FOLDERS.OFFER_IMAGES,
        });
        imageUrls = uploaded.map((r) => r.secure_url);
      }

      // 2. Send to backend with Cloudinary URLs
      return offerServices.sendRequestOffer({
        ...data,
        media: imageUrls,
      });
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOffers,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  const acceptRequestOffer = useMutation({
    mutationFn: async (offerId: string) => {
      return offerServices.updateRequestOffer(offerId, "ACCEPTED");
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOffers,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });
  const rejectRequestOffer = useMutation({
    mutationFn: async (offerId: string) => {
      return offerServices.updateRequestOffer(offerId, "REJECTED");
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOffers,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  return {
    errorMessage,
    isSubmitting:
      sendRequestOffer.isPending ||
      acceptRequestOffer.isPending ||
      rejectRequestOffer.isPending,
    sendRequestOffer: sendRequestOffer.mutate,
    acceptRequestOffer: acceptRequestOffer.mutate,
    rejectRequestOffer: rejectRequestOffer.mutate,
  };
};
