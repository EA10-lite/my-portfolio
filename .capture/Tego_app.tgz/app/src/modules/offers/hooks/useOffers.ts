import { useInfiniteQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { offerServices } from "../services/offers.services";

export const useJobRequest = (request_id: string, user_id: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // All job requests — for providers browsing
  const allOffers = useInfiniteQuery({
    queryKey: queryKeys.messages.jobRequestOffers(request_id, user_id),
    queryFn: () => offerServices.getRequestOffers(request_id, user_id),
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.totalPages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  return {
    offers: allOffers.data,
    errorMessage,
  };
};
