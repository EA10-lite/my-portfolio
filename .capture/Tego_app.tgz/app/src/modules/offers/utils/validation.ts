import * as yup from "yup";

export const offerValidationSchema = yup.object({
  price: yup
    .number()
    .typeError("Price must be a valid number")
    .required("Price is required")
    .positive("Price must be greater than 0")
    .min(100, "Price must be at least ₦100")
    .max(100000000, "Price is too high")
    .test(
      "max-decimal-places",
      "Price can have at most 2 decimal places",
      (value) => {
        if (value === undefined || value === null) return true;
        return Number.isInteger(value * 100);
      }
    ),

  proposal: yup
    .string()
    .trim()
    .required("Proposal is required")
    .min(20, "Proposal must be at least 20 characters")
    .max(1000, "Proposal must not exceed 1000 characters")
    .test(
      "not-only-spaces",
      "Proposal cannot contain only spaces",
      (value) => !!value?.trim()
    ),

  timeline: yup
    .string()
    .trim()
    .required("Timeline is required")
    .min(2, "Timeline is too short")
    .max(100, "Timeline must not exceed 100 characters")
    .test(
      "not-only-spaces",
      "Timeline cannot contain only spaces",
      (value) => !!value?.trim()
    ),

  availability: yup
    .string()
    .trim()
    .required("Availability is required")
    .min(2, "Availability is too short")
    .max(100, "Availability must not exceed 100 characters")
    .test(
      "not-only-spaces",
      "Availability cannot contain only spaces",
      (value) => !!value?.trim()
    ),
});