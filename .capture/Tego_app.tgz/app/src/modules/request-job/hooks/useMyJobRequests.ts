import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { jobRequestService } from "../services/request-job.service";

export const useJobRequest = (requestId?: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // My job requests — for customers
  const myJobRequests = useQuery({
    queryKey: queryKeys.jobRequests.mine,
    queryFn: jobRequestService.getMyRequests,
  });

  return {
    myJobRequests,
    isLoading: myJobRequests.isLoading,
    errorMessage,
  };
};
