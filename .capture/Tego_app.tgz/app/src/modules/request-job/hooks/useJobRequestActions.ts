import {
  CLOUDINARY_FOLDERS,
  uploadManyKeepingRemote,
} from "@/shared/lib/cloudinary";
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { jobRequestService } from "../services/request-job.service";
import {
  CreateJobRequest,
  UpdateJobRequest,
} from "../utils/type";
import { useToastStore } from "@/shared/store/toastStore";

export const useJobRequestActions = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const create = useMutation({
    mutationFn: async (data: CreateJobRequest) => {
      // 1. Upload images to Cloudinary first if any
      let imageUrls: string[] = [];

      if (data.images && data.images.length > 0) {
        imageUrls = await uploadManyKeepingRemote(data.images, {
          folder: CLOUDINARY_FOLDERS.REQUEST_IMAGES,
        });
      }

      // 2. Send to backend with Cloudinary URLs
      return jobRequestService.create({
        ...data,
        area: data.address,
        start_price: parseInt(data.start_price.toString()),
        end_price: parseInt(data.end_price.toString()),
        images: imageUrls,
      });
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.mine });
    },
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  const update = useMutation({
    // 👇 wrap both args in an object — mutationFn only accepts one argument
    mutationFn: async ({
      request_id,
      data }:{
        request_id: string;
        data: CreateJobRequest;
      }) => {
      // 1. Upload images to Cloudinary first if any
      let imageUrls: string[] = [];

      if (data.images && data.images.length > 0) {
        imageUrls = await uploadManyKeepingRemote(data.images, {
          folder: CLOUDINARY_FOLDERS.REQUEST_IMAGES,
        });
      }

      // 2. Send to backend with Cloudinary URLs
      return jobRequestService.update(request_id, {
        ...data,
        area: data.address,
        start_price: parseInt(data.start_price.toString()),
        end_price: parseInt(data.end_price.toString()),
        images: imageUrls,
      });
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: (_, { request_id }) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.mine });
      queryClient.invalidateQueries({
        queryKey: queryKeys.jobRequests.detail(request_id),
      });
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  const cancel = useMutation({
    mutationFn: (request_id: string) => jobRequestService.cancel(request_id),
    onMutate: () => setErrorMessage(null),
    onSuccess: (_, request_id) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.mine });
      queryClient.invalidateQueries({
        queryKey: queryKeys.jobRequests.detail(request_id),
      });
    },
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  const acceptRequest = useMutation({
    mutationFn: (data: { provider_id: string; request_id: string }) =>
      jobRequestService.accept(data.request_id, data.provider_id),
    onMutate: () => setErrorMessage(null),
    onSuccess: (_, data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.jobRequests.mine });
      queryClient.invalidateQueries({
        queryKey: queryKeys.jobRequests.detail(data.request_id),
      });
    },
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  return {
    errorMessage,
    isSubmitting:
      create.isPending ||
      update.isPending ||
      cancel.isPending ||
      acceptRequest.isPending,
    create: create.mutate,
    update: update.mutate,
    cancel: cancel.mutate,
    acceptRequest: acceptRequest.mutate,
  };
};
