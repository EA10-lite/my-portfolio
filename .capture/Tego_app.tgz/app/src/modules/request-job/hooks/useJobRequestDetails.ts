import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { jobRequestService } from "../services/request-job.service";

export const useJobRequestDetails = (requestId: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Single request details — only runs when requestId is provided
  const requestDetails = useQuery({
    queryKey: queryKeys.jobRequests.detail(requestId ?? ""),
    queryFn: () => jobRequestService.getRequestDetails(requestId!),
    enabled: !!requestId, // 👈 only fetch when requestId exists
  });

  return {
    requestDetails: requestDetails.data,
    isLoading: requestDetails.isLoading,
    errorMessage,
  };
};
