import { useInfiniteQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { jobRequestService } from "../services/request-job.service";
import { string } from "yup";

export type STATUS = "PENDING" | "CONFIRMED" | "COMPLETED" | "CANCELLED" | "";
export type TIMELINE = "TODAY" | "TOMORROW" | "FLEXIBLE" | "";

export interface JobRequestFilters {
  status?: STATUS;
  urgency?: TIMELINE;
  budget_min?: number;
  budget_max?: number;
  lat?: number;
  lng?: number;
  radius?: number;
  service_category_id?: string;
  state?: string;
}

const DEFAULT_FILTERS: JobRequestFilters = {
  status: "",
  urgency: "",
  budget_min: undefined,
  budget_max: undefined,
  lat: undefined,
  lng: undefined,
  radius: undefined,
  service_category_id: "",
  state: "",
};

const hasActiveFilters = (filters: JobRequestFilters): boolean => {
  return (
    !!filters.status ||
    !!filters.urgency ||
    filters.budget_min !== undefined ||
    filters.budget_max !== undefined
  );
};

export const useJobRequest = (categoryId?: string, state?: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [filters, setFilters] = useState<JobRequestFilters>(DEFAULT_FILTERS);

  // All job requests — for providers browsing
  const allJobRequests = useInfiniteQuery({
    queryKey: queryKeys.jobRequests.allWith(filters, categoryId, state),
    queryFn: ({ pageParam = 1 }) => {
      // Only pass filters to API if any are active
      const activeFilters = hasActiveFilters(filters) ? filters : undefined;
      return jobRequestService.getAllRequests(pageParam, 10, {
        ...activeFilters,
        ...(categoryId && { service_category_id: categoryId }),
        ...(state && { state })
      })
    },
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.totalPages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
  });

  const applyFilters = (newFilters: JobRequestFilters) => {
    setFilters(newFilters);
  };

  const clearFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  return {
    allJobRequests:
      allJobRequests.data?.pages.flatMap((page) => page.jobRequests) ?? [],
    fetchNextPage: allJobRequests.fetchNextPage,
    hasNextPage: allJobRequests.hasNextPage,
    isFetchingNextPage: allJobRequests.isFetchingNextPage,
    isLoading: allJobRequests.isLoading,
    errorMessage,
    filters,
    applyFilters,
    clearFilters,
    isFiltered: hasActiveFilters(filters),
    refetch: allJobRequests.refetch,
  };
};
