import { api } from "@/shared/lib/api";
import {
  CreateJobRequest,
  GetJobRequestsResponse,
  JobRequestDetails,
} from "../utils/type";
import { JobRequestFilters } from "../hooks/useAllJobRequests";

export const jobRequestService = {
  create: async (data: CreateJobRequest) => {
    const response = await api.post(`/job-requests`, data);
    return response.data;
  },
  getMyRequests: async () => {
    const response = await api.get("/job-requests/my-requests?page=1&limit=10");
    return response.data;
  },
  getAllRequests: async (page: number = 1, limit: number = 10, filters?: JobRequestFilters) => {
    console.log("filters:", filters);
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
      ...(filters?.status && { status: filters.status }),
      ...(filters?.urgency && { urgency: filters.urgency }),
      ...(filters?.budget_min !== undefined && { budget_min: filters.budget_min.toString() }),
      ...(filters?.budget_max !== undefined && { budget_max: filters.budget_max.toString() }),
      ...(filters?.lat !== undefined && { lat: filters.lat.toString() }),
      ...(filters?.lng !== undefined && { lng: filters.lng.toString() }),
      ...(filters?.radius !== undefined && { radius: filters.radius.toString() }),
      ...(filters?.state && { state: filters.state.toString() }),
      ...(filters?.service_category_id && { service_category_id: filters.service_category_id.toString() }),
    });
    const response = await api.get<GetJobRequestsResponse>(
      `/job-requests?${params.toString()}`,
    );
    return response.data;
  },
  getRequestDetails: async (request_id: string) => {
    const response = await api.get<JobRequestDetails>(
      `/job-requests/${request_id}`,
    );
    return response.data;
  },
  update: async (request_id: string, data: CreateJobRequest) => {
    const response = await api.patch(`/job-requests/${request_id}`, data);
    return response.data;
  },
  cancel: async (request_id: string) => {
    const response = await api.patch(`/job-requests/${request_id}/cancel`, {
      is_cancelled: true,
    });
    return response.data;
  },
  accept: async (request_id: string, provider_id: string) => {
    const response = await api.patch(`/job-requests/${request_id}/accept`, {
      provider_id,
    });
    return response.data;
  },
};
