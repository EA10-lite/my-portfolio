// components/RequestDetailsSkeleton.tsx
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { usePulse } from "@/shared/hooks/usePulse";
import { LinearGradient } from "expo-linear-gradient";
import { Animated, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Block = ({ style }: { style: object }) => {
  const opacity = usePulse();
  return <Animated.View style={[styles.block, style, { opacity }]} />;
};

export const DetailsFieldSkeleton = ({ isLast }: { isLast?: boolean }) => (
  <View style={[fieldStyles.row, isLast && { borderBottomWidth: 0 }]}>
    <Block style={fieldStyles.icon} />
    <View style={{ gap: 8, flex: 1 }}>
      <Block style={fieldStyles.label} />
      <Block style={fieldStyles.value} />
    </View>
  </View>
);

export const RequestDetailsBodySkeleton = () => {
  return (
    <View style={styles.group}>
      <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
        <Block style={styles.groupHeaderText} />
      </View>
      <View style={styles.body}>
        <View>
          <DetailsFieldSkeleton />
          <DetailsFieldSkeleton />
          <DetailsFieldSkeleton isLast />
        </View>
      </View>
    </View>
  )
}

const RequestDetailsSkeleton = () => {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
          <Block style={styles.backButton} />
        </View>
        <View style={{ gap: 8 }}>
          <Block style={styles.eyebrow} />
          <Block style={styles.title} />
          <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
            <Block style={styles.locationIcon} />
            <Block style={styles.locationText} />
          </View>
        </View>
      </LinearGradient>

      <View style={styles.content}>
        <View style={styles.group}>
          <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
            <Block style={styles.groupHeaderText} />
          </View>
          <View style={styles.body}>
            <View style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}>
              <Block style={styles.descriptionLine} />
              <Block style={styles.descriptionLineShort} />
            </View>
            <View>
              <DetailsFieldSkeleton />
              <DetailsFieldSkeleton isLast />
            </View>
          </View>
        </View>

        <RequestDetailsBodySkeleton />
      </View>

      <View
        style={[
          CUSTOM_STYLES.row,
          styles.footerContainer,
          { paddingBottom: insets.bottom || 24 },
        ]}
      >
        <Block style={[styles.footerButton, CUSTOM_STYLES.flex]} />
        <Block style={[styles.footerButton, CUSTOM_STYLES.flex]} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  block: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 4,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  eyebrow: {
    width: 100,
    height: 10,
  },
  title: {
    width: "80%",
    height: 20,
  },
  locationIcon: {
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  locationText: {
    width: "50%",
    height: 13,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    gap: 16,
  },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    justifyContent: "space-between",
  },
  groupHeaderText: {
    width: 100,
    height: 14,
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  descriptionLine: {
    width: "100%",
    height: 12,
  },
  descriptionLineShort: {
    width: "60%",
    height: 12,
  },
  footerContainer: {
    paddingTop: 10,
    paddingHorizontal: 20,
    gap: 12,
  },
  footerButton: {
    height: 48,
    borderRadius: 8,
  },
});

const fieldStyles = StyleSheet.create({
  row: {
    gap: 14,
    padding: 20,
    borderBottomWidth: 1,
    borderColor: "#0000000A",
    alignItems: "flex-start",
    flexDirection: "row",
  },
  icon: {
    width: 16,
    height: 16,
    borderRadius: 4,
  },
  label: {
    width: 60,
    height: 10,
  },
  value: {
    width: 120,
    height: 13,
  },
});

export default RequestDetailsSkeleton;
