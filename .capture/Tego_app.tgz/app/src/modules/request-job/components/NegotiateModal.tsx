import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Offer } from "@/modules/offers/types/offer.dto";
import { offerValidationSchema } from "@/modules/offers/utils/validation";
import {
  CustomButton,
  CustomText,
  Info,
  Input,
  Select,
  Textbox,
} from "@/shared/components";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { Formik } from "formik";
import { forwardRef, useCallback } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface NegotiateModalProps {
  title?: string;
  isOpen: boolean;
  closeModal: () => void;
  submitOffer: (offer: Offer) => void;
  loading: boolean;
}
const NegotiateModal = forwardRef<BottomSheetModal, NegotiateModalProps>(
  ({ isOpen, title, closeModal, submitOffer }, ref) => {
    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    const handleSubmitOffer = (offer: Offer) => {
      submitOffer?.(offer);
    };

    return (
      <>
        <View>
          {Platform.OS === "ios" ? (
            <Modal
              visible={isOpen}
              animationType="slide"
              presentationStyle="pageSheet"
              onRequestClose={closeModal}
              style={{ borderRadius: 50 }}
            >
              <Header closeModal={closeModal} title={title} />
              <View style={[styles.content]}>
                <Form onSuccess={handleSubmitOffer} />
              </View>
            </Modal>
          ) : (
            <BottomSheetModal
              ref={ref}
              enablePanDownToClose
              backdropComponent={renderBackdrop}
              backgroundStyle={styles.container}
              handleIndicatorStyle={{ height: 0 }}
              handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
              handleComponent={() => <></>}
              snapPoints={["95%"]}
            >
              <BottomSheetScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{
                  flex: 1,
                }}
              >
                <Header closeModal={closeModal} title={title} />
                <View style={[styles.content]}>
                  <Form onSuccess={handleSubmitOffer} />
                </View>
              </BottomSheetScrollView>
            </BottomSheetModal>
          )}
        </View>
      </>
    );
  },
);

const Form = ({ onSuccess }: { onSuccess: (offer: Offer) => void }) => {
  const insets = useSafeAreaInsets();

  const handleSubmit = (offer: Offer) => {
    onSuccess(offer);
  };
  return (
    <View style={styles.container}>
      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik<Offer>
            validateOnChange={false}
            initialValues={{
              price: "",
              timeline: "",
              proposal: "",
              availability: "FLEXIBLE",
            }}
            onSubmit={handleSubmit}
            validationSchema={offerValidationSchema}
          >
            {({ isSubmitting, handleSubmit, dirty }) => {
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <Input
                          name="price"
                          placeholder="New Price"
                          type="number-pad"
                        />
                        <Select
                          name="timeline"
                          placeholder="Timeline (optional)"
                          options={[
                            { label: "1 day", value: "1_day" },
                            { label: "3 days", value: "3_days" },
                            { label: "1 week", value: "1_week" },
                            { label: "1 Month", value: "1_month" },
                          ]}
                        />
                        <Textbox name="proposal" placeholder="Add a message" />
                        <Info
                          type="error"
                          text="This offer will be sent to the provider as a message. You can continue negotiating through the conversation thread."
                        />
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Send Counter Offer"
                      variant="primary"
                      disabled={!dirty || isSubmitting}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const Header = ({
  closeModal,
  title = "Negotiate Offer",
}: {
  closeModal: () => void;
  title?: string;
}) => (
  <View style={[styles.header]}>
    <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
      <CustomText weight="semibold" size="md" style={{ letterSpacing: -0.24 }}>
        {title}
      </CustomText>
      <Pressable onPress={closeModal} hitSlop={16}>
        <AntDesign name="close" color={PALETTE.black} size={16} />
      </Pressable>
    </View>
    <CustomText
      weight="medium"
      style={{
        fontSize: 13,
        lineHeight: 19,
        letterSpacing: -0.24,
        opacity: 0.5,
      }}
    >
      Suggest changes to the provider's offer before making a decision.
    </CustomText>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    padding: 20,
    gap: 10,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    flex: 1,
  },

  form: { gap: 16 },
  issue_typeButton: {
    height: 37,
    borderRadius: 38,
    paddingHorizontal: 7.67,
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
  },
  footerContainer: {
    paddingTop: 10,
  },
  footer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: PALETTE.white,
  },
});

NegotiateModal.displayName = "Report Issue Modal";

export default NegotiateModal;
