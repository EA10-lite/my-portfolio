import { PAYMENT_TYPE } from "@/modules/payment/utils/type";
import { create } from "zustand";
import { CreateJobRequest } from "../utils/type";

interface RequestJobStore {
  requestId: string | null;
  form: CreateJobRequest;
  paymentMethod: PAYMENT_TYPE;

  setFormData: (values: CreateJobRequest) => void;
  setFormField: (field: keyof CreateJobRequest, value: any) => void;
  setPaymentMethod: (type: PAYMENT_TYPE) => void;
  setRequestId: (id: string | null) => void;
  hydrateAddress: () => void;
  clearRequest: () => void;
}

const initialForm: CreateJobRequest = {
  title: "",
  service_category_id: "",
  date: "",
  description: "",
  images: [],
  is_budget_negotiable: false,
  start_price: 0,
  end_price: 0,
  address: "",
  country: "",
  state: "",
  area: "",
  urgency: "",
};

const initialState = {
  requestId: null,
  form: initialForm,
  paymentMethod: "bank" as PAYMENT_TYPE,
};

export const useRequestJob = create<RequestJobStore>((set) => ({
  ...initialState,

  setFormData: (form) => set({ form }),

  setFormField: (field, value) =>
    set((state) => ({
      form: {
        ...state.form,
        [field]: value,
      },
    })),

  setPaymentMethod: (paymentMethod) => set({ paymentMethod }),

  setRequestId: (requestId) => set({ requestId }),

  hydrateAddress: () => {
    set((state) => ({
      form: {
        ...state.form,
      },
    }));
  },

  clearRequest: () => set(initialState),
}));
