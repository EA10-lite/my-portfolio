import { JobOffer } from "@/modules/applications/utils/type";

export interface Offer {
  id: string;
  user: {
    id: string;
    rating: number;
    isVerified: boolean;
    name: string;
    avatar: string;
  };
  offer: number;
  message: string;
  date: string;
}

export interface CreateJobRequest {
  title: string;
  service_category_id: string;
  description: string;
  date: string;
  address: string;
  images: string[];
  start_price: number;
  end_price: number;
  is_budget_negotiable: boolean;
  country: string;
  state: string;
  longitude: number | null;
  latitude: number | null;
  area: string;
  urgency: string;
}

export interface UpdateJobRequest {
  description: string;
  start_price: number;
  end_price: number;
}

export type ActivityType = "REQUEST_SENT" | "PROVIDERS_ALERTED" | string;
export type RequestStatus =
  | "PENDING"
  | "ACCEPTED"
  | "CANCELLED"
  | "COMPLETED"
  | string;
export type RequestUrgency = "TODAY" | "TOMORROW" | "FLEXIBLE" | string;

export interface RequestActivity {
  activity_type: ActivityType;
  date_time: string;
  message: string;
}

export interface RequestUser {
  email: string;
  first_name: string;
  id: string;
  last_name: string;
  phone_number: string;
  profile_picture: string | null;
  user_type: string;
}

export interface JobRequestDetails {
  activities: RequestActivity[];
  title: string;
  address: string;
  area: string;
  country: string;
  created_at: string;
  date: string;
  description: string;
  end_price: number;
  id: string;
  images: string[];
  is_budget_negotiable: boolean;
  is_cancelled: boolean;
  job_activity_id: string;
  provider_id: string | null;
  service_category_id: string;
  start_price: number;
  state: string;
  status: RequestStatus;
  updated_at: string;
  urgency: RequestUrgency;
  user: RequestUser;
  offers: JobOffer[];
}
export interface JobRequest {
  id: string;
  user: RequestUser;
  service_category_id: string;
  service_category: {
    id: string;
    name: string;
  };
  title: string;
  description: string;
  date: string;
  address: string;
  state: string;
  country: string;
  area: string;
  images: string[];
  start_price: number;
  end_price: number;
  is_budget_negotiable: boolean;
  urgency: string;
  provider_id: string | null;
  status: "PENDING" | "COMPLETED" | "CANCELLED" | string;
  is_cancelled: boolean;
  job_activity_id: string;
  activities: RequestActivity[];
  created_at: string;
  updated_at: string;
}

export interface GetJobRequestsResponse {
  jobRequests: JobRequest[];
  total: number;
  page: number;
  totalPages: number;
}
