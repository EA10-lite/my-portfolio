import * as yup from "yup";

const MAX_IMAGE_SIZE_MB = 5;
const MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/jpg"];

const URGENCY_OPTIONS = ["TODAY", "TOMORROW", "FLEXIBLE"] as const;

export const requestJobSchema = yup.object().shape({
  title: yup
    .string()
    .required("Title is required")
    .trim()
    .min(3, "Title must be at least 3 characters")
    .max(100, "Title must not exceed 100 characters")
    .matches(/^[a-zA-Z0-9\s.,'-]+$/, "Title contains invalid characters")
    .test(
      "no-script",
      "Title contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),

  service_category_id: yup.string().required("Please select a category"),

  date: yup.string().required("Please select a date").trim(),

  address: yup
    .string()
    .required("Address is required")
    .trim()
    .min(10, "Please enter a valid address")
    .max(200, "Address is too long")
    .test(
      "no-script",
      "Address contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),

  description: yup
    .string()
    .trim()
    .max(500, "Description must not exceed 500 characters")
    .test(
      "no-script",
      "Description contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    )
    .required("Please describe what is wrong."),

  start_price: yup.string().trim(),
  is_budget_negotiable: yup.boolean(),

  urgency: yup
    .string()
    .required("Please select an urgency level")
    .oneOf(URGENCY_OPTIONS, "Please select a valid urgency level"),

  images: yup.array().when("service", {
    is: "other",
    then: (schema) =>
      schema
        .min(1, "Please upload at least one image")
        .max(9, "You can upload a maximum of 9 images")
        .required("Please upload at least one image"),
    otherwise: (schema) => schema.notRequired(),
  }),
});
