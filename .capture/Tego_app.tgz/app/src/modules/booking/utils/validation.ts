import * as yup from "yup";

const URGENCY_OPTIONS = ["TODAY", "TOMORROW", "FLEXIBLE"] as const;

const MAX_IMAGE_SIZE_MB = 5;
const MAX_IMAGE_SIZE_BYTES = MAX_IMAGE_SIZE_MB * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/jpg"];

export const bookingFormSchema = yup.object({
  title: yup
    .string()
    .required("Title is required")
    .trim()
    .min(3, "Title must be at least 3 characters")
    .max(100, "Title must not exceed 100 characters")
    .matches(/^[a-zA-Z0-9\s.,'-]+$/, "Title contains invalid characters")
    .test(
      "no-script",
      "Title contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),

  service_list_item_id: yup
    .string()
    .required("Please select a type of service"),

  date: yup.string().required("Please select a date").trim(),

  time: yup
    .string()
    .required("Please select a time")
    .matches(/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/, "Invalid time format"),

  urgency: yup
    .string()
    .required("Please select an urgency level")
    .oneOf(URGENCY_OPTIONS, "Please select a valid urgency level"),

  address: yup.object({
    address: yup
      .string()
      .required("Address is required")
      .trim()
      .min(10, "Please enter a valid address")
      .max(200, "Address is too long")
      .test(
        "no-script",
        "Address contains invalid characters",
        (value) => !/<|>|script/i.test(value ?? ""),
      ),

    state: yup.string().required("State is required").trim(),

    country: yup.string().required("Country is required").trim(),
  }),

  note: yup
    .string()
    .trim()
    .max(500, "Note must not exceed 500 characters")
    .test(
      "no-script",
      "Note contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),

  images: yup
    .array()
    .of(yup.string().required())
    .required()
    .default([])
    .when("service_list_item_id", {
      is: "other",
      then: (schema) =>
        schema
          .min(1, "Please upload at least one image")
          .max(9, "You can upload a maximum of 9 images"),
      otherwise: (schema) => schema.max(9, "You can upload a maximum of 9 images"),
    }),
});
