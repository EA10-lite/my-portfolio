import { api } from "@/shared/lib/api";
import {
  Booking,
  BOOKING_UPDATE_STATUS,
  DirectBooking,
  MyBookingResponse,
} from "../types/booking.dto";
import { BookingFilters } from "../hooks/useBooking";

export const bookingService = {
  create: async (data: Booking) => {
    const response = await api.post(`/service-booking`, data);
    return response.data;
  },
  getMyBookings: async (page: number, limit: number, filters?: BookingFilters) => {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
      ...(filters?.status && { status: filters.status }),
      ...(filters?.urgency && { urgency: filters.urgency }),
      ...(filters?.budget_min !== undefined && { budget_min: filters.budget_min.toString() }),
      ...(filters?.budget_max !== undefined && { budget_max: filters.budget_max.toString() }),
      ...(filters?.lat !== undefined && { lat: filters.lat.toString() }),
      ...(filters?.lng !== undefined && { lng: filters.lng.toString() }),
      ...(filters?.radius !== undefined && { radius: filters.radius.toString() }),
    });
    const response = await api.get<MyBookingResponse>(`/service-booking/my-bookings?${params}`);
    return response.data;
  },
  getBookingDetails: async (booking_id: string) => {
    const response = await api.get<DirectBooking>(
      `/service-booking/${booking_id}`,
    );
    return response.data;
  },
  update: async (booking_id: string, status: BOOKING_UPDATE_STATUS) => {
    const response = await api.patch(`/service-booking/${booking_id}/status`, {
      status,
    });
    return response.data;
  },
  accept: async (booking_id: string) => {
    const response = await api.patch(`/service-booking/${booking_id}/accept`);
    return response.data;
  },
  reject: async (booking_id: string) => {
    const response = await api.patch(`/service-booking/${booking_id}/reject`);
    return response.data;
  },
  cancel: async (booking_id: string) => {
    const response = await api.patch(`/service-booking/${booking_id}/cancel`);
    return response.data;
  },
};
