import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import { create } from "zustand";

// stores/bookingStore.ts

export interface ProviderStat {
  id: string;
  name: string;
  profile_picture: string;
  availability_status: AvailabilityStatus;
  location: string;
  rating: number | null;
  jobs_done: number | null;
  repeat_clients: number | null;
  is_verified: boolean;
  services: {
    id: string;
    service_name: string;
  }[];
}

export type FormValues = {
  title: string;
  date: string;
  time: string;
  note: string;
  address: {
    address: string;
    state: string;
    country: string;
  };
  urgency: string;
  service_list_item_id: string;
  images: string[];
};
interface BookingState {
  provider: ProviderStat | null;
  form: FormValues;

  setProvider: (data: ProviderStat) => void;
  setFormData: (values: FormValues) => void;
  clearBooking: () => void;
}

const initialState = {
  provider: null,
  form: {
    title: "",
    date: "",
    time: "",
    address: {
      address: "",
      state: "",
      country: "Nigeria",
    },
    note: "",
    urgency: "",
    service_list_item_id: "",
    images: [],
  },
};

export const useBookingStore = create<BookingState>((set) => ({
  ...initialState,

  setProvider: (data: ProviderStat) => set({ provider: data }),
  setFormData: (value: FormValues) => set({ form: value }),
  clearBooking: () => set(initialState),

  hydrateAddress: () => {
    set((state) => ({
      form: {
        ...state.form,
      },
    }));
  },
}));
