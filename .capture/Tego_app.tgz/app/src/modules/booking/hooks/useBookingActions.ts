// hooks/useAvailability.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { bookingService } from "../services/booking.service";
import { Booking, BOOKING_UPDATE_STATUS } from "../types/booking.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useBookingActions = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const invalidateBookings = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.booking.list });
  };

  const create = useMutation({
    mutationFn: (data: Booking) => bookingService.create(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      invalidateBookings();
    },
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Booking Failed", message);
    },
  });
  const update = useMutation({
    mutationFn: ({
      id,
      status,
    }: {
      id: string;
      status: BOOKING_UPDATE_STATUS;
    }) => bookingService.update(id, status),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateBookings,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });
  const cancel = useMutation({
    mutationFn: (id: string) => bookingService.cancel(id),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateBookings,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  const acceptBookingByProvider = useMutation({
    mutationFn: (id: string) => bookingService.accept(id),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateBookings,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  const rejectBookingByProvider = useMutation({
    mutationFn: (id: string) => bookingService.reject(id),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateBookings,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  return {
    create: create.mutate,
    update: update.mutate,
    cancel: cancel.mutate,
    acceptBookingByProvider: acceptBookingByProvider.mutate,
    rejectBookingByProvider: rejectBookingByProvider.mutate,
    errorMessage,
    isSubmitting:
      create.isPending ||
      update.isPending ||
      cancel.isPending ||
      acceptBookingByProvider.isPending,
  };
};
