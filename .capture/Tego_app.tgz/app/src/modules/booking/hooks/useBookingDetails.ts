import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { bookingService } from "../services/booking.service";

export const useBookingDetails = (requestId: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Single request details — only runs when requestId is provided
  const requestDetails = useQuery({
    queryKey: queryKeys.booking.detail(requestId),
    queryFn: () => bookingService.getBookingDetails(requestId!),
    enabled: !!requestId, // 👈 only fetch when requestId exists
    refetchOnWindowFocus: true,
  });

  return {
    requestDetails: requestDetails.data,
    isLoading: requestDetails.isLoading,
    errorMessage,
  };
};
