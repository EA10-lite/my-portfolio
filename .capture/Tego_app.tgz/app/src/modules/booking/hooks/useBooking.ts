import { useInfiniteQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { bookingService } from "../services/booking.service";

export type BookingStatus = "PENDING" | "CONFIRMED" | "COMPLETED" | "CANCELLED" | "";
export type BookingUrgency = "TODAY" | "TOMORROW" | "FLEXIBLE" | "";

export interface BookingFilters {
  status?: BookingStatus;
  urgency?: BookingUrgency;
  budget_min?: number;
  budget_max?: number;
  lat?: number;
  lng?: number;
  radius?: number;
  preference?: string;
}

const DEFAULT_FILTERS: BookingFilters = {
  status: "",
  urgency: "",
  budget_min: undefined,
  budget_max: undefined,
  lat: undefined,
  lng: undefined,
  radius: undefined,
  preference: ""
};

const hasActiveFilters = (filters: BookingFilters): boolean => {
  return (
    !!filters.status ||
    !!filters.urgency ||
    filters.budget_min !== undefined ||
    filters.budget_max !== undefined
  );
};

export const useBooking = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [filters, setFilters] = useState<BookingFilters>(DEFAULT_FILTERS);

  const bookings = useInfiniteQuery({
    // 👇 include filters in queryKey so it refetches when filters change
    queryKey: queryKeys.booking.listWith(filters),
    queryFn: ({ pageParam = 1 }) => {
      // Only pass filters to API if any are active
      const activeFilters = hasActiveFilters(filters) ? filters : undefined;
      return bookingService.getMyBookings(pageParam, 10, activeFilters);
    },
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
  });

  const applyFilters = (newFilters: BookingFilters) => {
    setFilters(newFilters);
  };

  const clearFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  return {
    bookings: bookings.data?.pages.flatMap((page) => page.bookings) ?? [],
    fetchNextPage: bookings.fetchNextPage,
    hasNextPage: bookings.hasNextPage,
    isFetchingNextPage: bookings.isFetchingNextPage,
    isLoading: bookings.isLoading,
    errorMessage,
    filters,
    applyFilters,
    clearFilters,
    isFiltered: hasActiveFilters(filters),
    refetch: bookings.refetch,
  };
};