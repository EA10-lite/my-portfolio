import { Pagination, URGENCY } from "@/constants/types";

export type BOOKING_UPDATE_STATUS =
  | "ACCEPTED"
  | "CANCELLED"
  | "IN_PROGRESS"
  | "COMPLETED";
export type BOOKING_STATUS =
  | "ACCEPTED"
  | "CANCELLED"
  | "PENDING"
  | "IN_NEGOTIATION"
  | "IN_PROGRESS"
  | "AWAITING_PROVIDER";

export interface Address {
  address: string;
  state: string;
  country: string;
}

export interface Booking {
  provider_id: string;
  service_list_item_id: string;
  date: string;
  time: string;
  address: Address;
  note: string;
  images: string[];
  urgency: string;
}

export interface DirectBooking {
  id: string;
  user: {
    id: string;
    first_name: string;
    last_name: string;
    user_type: string;
    profile_picture: string;
  };
  provider: {
    id: string;
    first_name: string;
    last_name: string;
    profile_picture: string;
    user_type: "SERVICE_PROVIDER";
  };
  service_category: {
    id: string;
    name: string;
  };
  service_list_item: {
    id: string;
    service_name: string;
    pricing_type: string;
    price: number;
  };
  price: number;
  quote_price: number;
  date: string;
  time: string;
  address: {
    state: string;
    address: string;
    country: string;
  };
  title: string;
  note: string;
  images: [];
  status: BOOKING_STATUS;
  urgency: URGENCY;
  created_at: string;
  updated_at: string;
}

export interface MyBookingResponse extends Pagination {
  bookings: DirectBooking[];
}
