import BoltIcon from "@/assets/images/app-icons/bolt.svg";
import { PALETTE } from "@/constants/colors";
import { router } from "expo-router";
import { StyleSheet, View } from "react-native";
import {
  CustomButton,
  CustomText,
  UserAvatarGroup,
} from "../../../shared/components";
import { CImg } from "@/shared/components";
import { CategoryDTO } from "../types/category.dto";

const Category = ({ item }: { item: CategoryDTO }) => {
  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <CImg uri={item.cover_image} width={648} style={styles.image} />
      </View>
      <View style={styles.body}>
        <View style={{ gap: 13, flex: 1 }}>
          <CustomText weight="semibold" size="md">
            {item.name}{" "}
          </CustomText>
          <View style={styles.row}>
            {item.category_services?.slice(0, 3).map((tag) => (
              <View style={styles.tag} key={tag.id}>
                <CustomText weight="medium" size="xs">
                  {tag.name}
                </CustomText>
              </View>
            ))}

            {item.category_services && item.category_services.length > 3 && (
              <View style={styles.tag}>
                <CustomText>+{item.category_services?.length - 3}</CustomText>
              </View>
            )}
          </View>
          <View style={[styles.row]}>
            <View style={styles.users}>
              <UserAvatarGroup users={[]} size="xs" />
              <View
                style={{ flexDirection: "row", alignItems: "center", gap: 4 }}
              >
                <View style={styles.dot} />
                <CustomText weight="medium" size="xs">
                  Available Today
                </CustomText>
              </View>
            </View>

            <View style={styles.separator} />

            <View style={styles.users}>
              <BoltIcon />
              <CustomText weight="medium" size="xs">
                Fast booking
              </CustomText>
            </View>
          </View>
        </View>

        <CustomButton
          title="Explore"
          style={styles.button}
          size="sm"
          variant="default"
          onPress={() => router.push(`/(customer)/category/${item.id}`)}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 10,
    backgroundColor: PALETTE.whiteLight,
    width: 324,
    overflow: "hidden",
  },
  header: {
    minHeight: 138,
    position: "relative",
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: "100%", // fills the header height only
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerContent: {
    padding: 12,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  body: {
    padding: 20,
    gap: 20,
    flex: 1,
  },
  row: {
    flexDirection: "row",
    gap: 9,
    flexWrap: "wrap",
    overflow: "hidden",
  },
  tag: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: PALETTE.white,
    borderRadius: 25,
    paddingVertical: 6,
    paddingHorizontal: 12,
    gap: 3,
  },
  users: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  separator: {
    width: 1,
    height: "100%",
    backgroundColor: PALETTE.black,
    opacity: 0.1,
  },
  dot: {
    backgroundColor: PALETTE.success,
    width: 6,
    height: 6,
    borderRadius: 10,
  },
  button: {
    width: 108,
  },
});

export default Category;
