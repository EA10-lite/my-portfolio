import { PALETTE } from "@/constants/colors";
import { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
    useAnimatedStyle,
    useSharedValue,
    withRepeat,
    withTiming,
} from "react-native-reanimated";

const SkeletonBox = ({
  width,
  height,
  borderRadius = 6,
  style,
}: {
  width?: number | string;
  height: number;
  borderRadius?: number;
  style?: any;
}) => {
  const opacity = useSharedValue(1);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.4, { duration: 800 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[
        { width, height, borderRadius, backgroundColor: PALETTE.grey01 },
        animatedStyle,
        style,
      ]}
    />
  );
};

const CategoryCardSkeleton = () => {
  return (
    <View style={styles.card}>
      {/* Image header */}
      <SkeletonBox width="100%" height={138} borderRadius={0} />

      <View style={styles.body}>
        <View style={{ gap: 13 }}>
          {/* Title */}
          <SkeletonBox width="50%" height={16} borderRadius={4} />

          {/* Tags row */}
          <View style={styles.row}>
            {[1, 2, 3].map((i) => (
              <SkeletonBox key={i} width={70} height={30} borderRadius={25} />
            ))}
          </View>

          {/* Users + fast booking row */}
          <View style={styles.row}>
            <View style={styles.users}>
              {/* Avatar group */}
              <View style={{ flexDirection: "row" }}>
                {[1, 2, 3].map((i) => (
                  <SkeletonBox
                    key={i}
                    width={24}
                    height={24}
                    borderRadius={12}
                    style={{ marginLeft: i === 1 ? 0 : -8 }}
                  />
                ))}
              </View>
              <SkeletonBox width={80} height={10} borderRadius={4} />
            </View>

            <View style={styles.separator} />

            <View style={styles.users}>
              <SkeletonBox width={16} height={16} borderRadius={4} />
              <SkeletonBox width={70} height={10} borderRadius={4} />
            </View>
          </View>
        </View>

        {/* Button */}
        <SkeletonBox width={108} height={36} borderRadius={6} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 10,
    backgroundColor: PALETTE.whiteLight,
    minWidth: 324,
    overflow: "hidden",
  },
  body: {
    padding: 20,
    gap: 20,
  },
  row: {
    flexDirection: "row",
    gap: 9,
    alignItems: "center",
  },
  users: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  separator: {
    width: 1,
    height: 20,
    backgroundColor: PALETTE.black,
    opacity: 0.1,
  },
});

export default CategoryCardSkeleton;
