import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CATEGORIES_TYPE } from "@/constants/types";
import { CustomText, UserAvatarGroup } from "@/shared/components";
import { Pressable, StyleSheet, View } from "react-native";
import { CategoryProviderDTO } from "../types/category.dto";
import { getCategoryIcon } from "@/shared/utils/categoryIcons";

interface SubCategoryProps {
  type: CATEGORIES_TYPE;
  handlePress: () => void;
  label: string;
  image: string;
  providers: CategoryProviderDTO[];
}
const SubCategory = ({
  label,
  providers,
  handlePress,
  image,
}: SubCategoryProps) => {
  return (
    <Pressable onPress={handlePress}>
      <View style={styles.card}>
        <View style={styles.content}>
          <View
            style={[
              CUSTOM_STYLES.icon,
              CUSTOM_STYLES.center,
              { backgroundColor: PALETTE.white },
            ]}
          >
            {getCategoryIcon(image)}
          </View>

          <View style={styles.body}>
            <CustomText size="sm" weight="bold">
              {label}
            </CustomText>
            <View style={{ gap: 4 }}>
              <UserAvatarGroup
                size="xs"
                users={providers.map((provider) => ({
                  url: provider.profile_picture,
                  name: `${provider.first_name} ${provider.last_name}`,
                }))}
                showRemaining={false}
              />
              {providers.length > 2 && (
                <CustomText weight="medium" size="xs" style={styles.text}>
                  +{providers.length} providers nearby
                </CustomText>
              )}
            </View>
          </View>
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 10,
    padding: 20,
    gap: 16,
  },
  content: {
    gap: 12,
  },
  body: { gap: 8 },
  text: {
    opacity: 0.5,
  },
});

export default SubCategory;
