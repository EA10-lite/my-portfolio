// hooks/useCategories.ts
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import {
    getMostBookgedCategories
} from "../services/categories";

export const useMostBookedCateogires = () => {
  const most_booked_categories = useQuery({
    queryKey: queryKeys.categories.mostBooked,
    queryFn: getMostBookgedCategories,
  });

  return {
    most_booked_categories: most_booked_categories.data,
    isLoading: most_booked_categories.isLoading,
  };
};
