// hooks/useCategories.ts
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import {
  getCategories
} from "../services/categories";
import { CategoryDTO } from "../types/category.dto";

export const useCategories = () => {
  const categories = useQuery({
    queryKey: queryKeys.categories.all,
    queryFn: getCategories,
  });

  return {
    categories: categories.data as CategoryDTO[] | undefined,
    isLoading: categories.isLoading,
  };
};
