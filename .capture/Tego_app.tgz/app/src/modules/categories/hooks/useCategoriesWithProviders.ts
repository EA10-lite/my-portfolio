// hooks/useCategories.ts
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { getCategoriesWithProviders } from "../services/categories";

export const useCategoriesWithProviders = () => {
  const categories_with_providers = useQuery({
    queryKey: queryKeys.categories.withProviders,
    queryFn: getCategoriesWithProviders,
  });

  return {
    categories_with_providers: categories_with_providers.data,
    isLoading: categories_with_providers.isLoading,
  };
};
