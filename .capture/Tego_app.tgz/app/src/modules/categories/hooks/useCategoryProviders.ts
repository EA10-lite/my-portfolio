// hooks/useCategories.ts
import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { getProvidersByCategory } from "../services/categories";

interface useCategoryProviderParams {
  category_id?: string;
  rating_min?: number;
  preference?: string[];
  latitude?: number;
  longitude?: number;
  distance_radius?: number;
}

export const useCategoryProviders = ({
  category_id,
  rating_min,
  preference,
  latitude,
  longitude,
  distance_radius,
}: useCategoryProviderParams = {}) => {
  const category_providers = useInfiniteQuery({
    queryKey: queryKeys.categories.providers({
      category_id,
      rating_min,
      preference,
      latitude,
      longitude,
      distance_radius,
    }),

    queryFn: ({ pageParam = 1 }) =>
      getProvidersByCategory({
        page: pageParam,
        limit: 10,
        category_id,
        rating_min,
        preference,
        latitude,
        longitude,
        distance_radius,
      }),

    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,

    initialPageParam: 1,
  });

  const providers = useMemo(() => {
    const pages = category_providers.data?.pages ?? [];
    const firstPage = pages[0];

    return {
      id: firstPage?.id,
      name: firstPage?.name,
      image: firstPage?.image,
      cover_image: firstPage?.cover_image,

      popular_near_you: pages.flatMap(
        (page) => page.providers.popular_near_you,
      ),

      top_rated: pages.flatMap((page) => page.providers.top_rated),

      all_providers: pages.flatMap((page) => page.providers.all_providers),
    };
  }, [category_providers.data]);

  return {
    category: {
      id: providers.id,
      name: providers.name,
      image: providers.image,
      cover_image: providers.cover_image,
    },
    providers: {
      popular_near_you: providers.popular_near_you,
      top_rated: providers.top_rated,
      all_providers: providers.all_providers,
    },
    isLoading: category_providers.isLoading,
    fetchNextPage: category_providers.fetchNextPage,
    hasNextPage: category_providers.hasNextPage,
    isFetchingNextPage: category_providers.isFetchingNextPage,
    refetch: category_providers.refetch,
  };
};

// GET /api/service-categories/:categoryId/providers?preference=available_now,top_providers
// available_now filters the list down to providers with availableStatus === 'available_to_work', then top_providers sorts the result by average rating. Although only top_providers affects ordering, you can even combine it with others (verified_only, near_me) — just make sure near_me is paired with lat + lng.
