import { PALETTE } from "@/constants/colors";
import { useEffect } from "react";
import { Dimensions, StyleSheet, View } from "react-native";
import Animated, {
    useAnimatedStyle,
    useSharedValue,
    withRepeat,
    withTiming,
} from "react-native-reanimated";

const width = Dimensions.get("window").width;
const GAP = 20;
const NUM_COLUMNS = 2;
const ITEM_WIDTH = (width - 40 - GAP * (NUM_COLUMNS - 1)) / NUM_COLUMNS;

const SkeletonBox = ({
  width: w,
  height: h,
  borderRadius = 6,
  style,
}: {
  width?: number | string;
  height: number;
  borderRadius?: number;
  style?: any;
}) => {
  const opacity = useSharedValue(1);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.4, { duration: 800 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      style={[
        {
          width: w,
          height: h,
          borderRadius,
          backgroundColor: PALETTE.grey01,
        },
        animatedStyle,
        style,
      ]}
    />
  );
};

const CategorySkeleton = () => {
  return (
    <View style={styles.card}>
      <View style={styles.content}>
        {/* Icon box */}
        <SkeletonBox width={37} height={37} borderRadius={80} />

        <View style={styles.body}>
          {/* Title */}
          <SkeletonBox width="60%" height={14} borderRadius={4} />

          <View style={{ gap: 4 }}>
            {/* Avatar group */}
            <View style={styles.avatarGroup}>
              {[1, 2, 3].map((i) => (
                <SkeletonBox
                  key={i}
                  width={24}
                  height={24}
                  borderRadius={12}
                  style={{ marginLeft: i === 1 ? 0 : -8 }}
                />
              ))}
            </View>
            {/* Providers text */}
            <SkeletonBox width="80%" height={10} borderRadius={4} />
          </View>
        </View>
      </View>
    </View>
  );
};

export const CategorySkeletonGrid = () => {
  return (
    <View style={styles.container}>
      <View style={styles.categories}>
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <View key={i} style={styles.item}>
            <CategorySkeleton />
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 17,
    paddingHorizontal: 20,
  },
  categories: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 20,
  },
  item: {
    width: ITEM_WIDTH,
  },
  card: {
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 10,
    padding: 20,
    gap: 16,
  },
  content: {
    gap: 12,
  },
  body: {
    gap: 8,
  },
  avatarGroup: {
    flexDirection: "row",
  },
});

export default CategorySkeleton;
