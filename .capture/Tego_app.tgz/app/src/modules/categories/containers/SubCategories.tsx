import { CATEGORIES_TYPE } from "@/constants/types";
import { router } from "expo-router";
import { Dimensions, StyleSheet, View } from "react-native";
import { SubCategory } from "../components";
import { CategoryWithProviders } from "../types/category.dto";

const width = Dimensions.get("window").width;
const GAP = 20;
const NUM_COLUMNS = 2;

interface CategoriesProps {
  data: CategoryWithProviders[];
  isBooking?: boolean;
}

const SubCategories = ({ data, isBooking = false }: CategoriesProps) => {
  return (
    <View style={styles.container}>
      <View style={styles.categories}>
        {data.map((category) => (
          <View style={styles.item} key={category.id}>
            <SubCategory
              label={category.name}
              image={category.image}
              providers={category.providers}
              type={category.name.toLowerCase() as CATEGORIES_TYPE}
              handlePress={() => {
                router.push(
                  isBooking
                    ? `/(customer)/booking/${category.id}`
                    : `/(customer)/category/${category.id}`,
                );
              }}
            />
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 17,
    paddingHorizontal: 20,
  },
  categories: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 20,
  },
  item: {
    width: (width - 40 - GAP * (NUM_COLUMNS - 1)) / NUM_COLUMNS,
    // 40 = paddingHorizontal * 2 from the container
  },
});

export default SubCategories;
