import { AvailabilityStatus } from "@/modules/auth/types/user.dto";

export interface AllCategories extends CategoryDTO {
  category_services: {
    id: string;
    name: string;
  }[];
}

export interface CategoriesWithProvidersResponse extends Pagination {
  categories: CategoryWithProviders[];
}

export interface MostBookedCategoriesResponse extends Pagination {
  categories: CategoryDTO[];
}

export interface CategoryProvidersResponse extends CategoryDTO, Pagination {
  providers: {
    popular_near_you: FullProvider[];
    top_rated: FullProvider[];
    all_providers: FullProvider[];
  };
}

export interface CategoryWithProviders extends CategoryDTO {
  providers: CategoryProviderDTO[];
}

export interface CategoryDTO {
  id: string;
  name: string;
  image: string;
  cover_image: string;
  created_at: string;
  updated_at: string;
  category_services?: {
    id: string;
    name: string;
  }[];
}

export interface CategoryProviderDTO {
  id: string;
  first_name: string;
  last_name: string;
  profile_picture: string;
}

export interface FullProvider {
  id: string;
  first_name: string;
  last_name: string;
  user_type: "SERVICE_PROVIDER";
  is_verified: boolean;
  available_status: AvailabilityStatus;
  profile_picture: string;
  profile_card: string;
  service_details: {
    id: string;
    service_name: string;
    pricing_type: "REQUEST_QUOTE" | "FIXED";
    price: number;
  }[];
  service_category: {
    id: string;
    name: string;
  };
  location_info: {
    state: string;
    city: string;
    area: string;
    longitude: null | number;
    latitude: null | number;
  };
  service_area: [];
  rating: null | number;
  repeatClients?: number;
  totalJobsDone?: number;
}

interface Pagination {
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}
