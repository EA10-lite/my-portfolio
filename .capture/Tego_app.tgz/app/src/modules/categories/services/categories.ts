import { api } from "@/shared/lib/api";
import {
  AllCategories,
  CategoriesWithProvidersResponse,
  CategoryProvidersResponse,
  MostBookedCategoriesResponse,
} from "../types/category.dto";

export const getCategories = async () => {
  const response = await api.get<AllCategories>("/service-categories");
  return response.data;
};

export const getCategoriesWithProviders = async () => {
  const response = await api.get<CategoriesWithProvidersResponse>(
    "/service-categories/with-providers",
  );
  return response.data;
};

export const getMostBookgedCategories = async () => {
  const response = await api.get<MostBookedCategoriesResponse>(
    "/service-categories/most-booked?page=1&limit=10",
  );
  return response.data;
};

interface GetProvidersParams {
  page?: number;
  limit?: number;
  category_id?: string;
  rating_min?: number;
  preference?: string[];
  latitude?: number;
  longitude?: number;
  distance_radius?: number;
}

export const getProvidersByCategory = async ({
  page = 1,
  limit = 10,
  category_id,
  rating_min,
  preference,
  latitude,
  longitude,
  distance_radius,
}: GetProvidersParams = {}) => {
  const params = new URLSearchParams({
    page: page.toString(),
    limit: limit.toString(),
  });

  if (rating_min !== undefined) {
    params.append("rating_min", rating_min.toString());
  }

  if (preference?.length) {
    params.append("preference", preference.join(","));
  }

  if (latitude !== undefined) {
    params.append("latitude", latitude.toString());
  }

  if (longitude !== undefined) {
    params.append("longitude", longitude.toString());
  }

  if (distance_radius !== undefined) {
    params.append("distance_radius", distance_radius.toString());
  }
  const url = `/service-categories/${category_id}/providers?${params.toString()}`
  const response = await api.get<CategoryProvidersResponse>(url);
  return response.data;
};
