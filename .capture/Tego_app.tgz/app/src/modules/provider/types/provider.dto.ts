import { AvailabilityStatus } from "@/modules/auth/types/user.dto";

export interface ServiceProviderResponse {
  services: ServiceProvider[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

export interface ServiceProvider {
  id: string;
  provider_id: string;
  provider: Provider;
  service_category_id: string;
  service_category: ServiceCategory;
  services_list: Service[];
  business_location: BusinessLocation;
  service_area: string[];
  status: "ACTIVE" | "INACTIVE";
  created_at: string;
  updated_at: string;
}

export interface Provider {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  gender: "MALE" | "FEMALE";
  user_type: "SERVICE_PROVIDER";
  phone_number: string;
  is_phone_verified: boolean;
  is_email_verified: boolean;
  profile_picture: string | null;
  picture_card: string | null;
  available_status: AvailabilityStatus;
  created_at: string;
  updated_at: string;
}

export interface ServiceCategory {
  id: string;
  name: string;
}

export interface Service {
  id: string;
  service_name: string;
  pricing_type: "FIXED" | "REQUEST_QUOTE";
  price: number;
}

export interface BusinessLocation {
  area: string;
  city: string;
  state: string;
  latitude: number | null;
  longitude: number | null;
}

export interface ServiceArea {
  // Populate this as the API evolves.
  [key: string]: unknown;
}
