import { CATEGORIES_TYPE } from "@/constants/types";

export interface ServiceProviderDTO {
  id: string | number;
  services: string[];
  stats: {
    totalJobsDone: number;
    repeatClients: number;
    rating: number;
    replyTime: string;
  };
  category: CATEGORIES_TYPE;
  availability: boolean;
  location: string;
  price: number;
  user: {
    firstName: string;
    lastName: string;
    address: string;
    isVerified?: boolean;
    avatar?: string;
  };
  clients?: {
    name: string;
    url?: string;
  }[];
}

export interface ProviderDTO {
  id: string;
  name: string;
  location: string;
  minAmount: number;
  rating: number;
  isVerified: boolean;
  isAvailable: boolean;
  category: string;
  imageUrl: string;
}
