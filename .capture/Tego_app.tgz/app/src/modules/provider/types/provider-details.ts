import { SUBSCRIPTION } from "@/constants/types";
import { AvailabilityStatus, GENDER } from "@/modules/auth/types/user.dto";
import { SUBSCRIPTION_STATUS } from "@/modules/subscription/types/subscription.dto";

export interface ProviderDetails {
  provider: {
    id: string;
    name: string;
    gender: GENDER;
    location: {
      state: string;
      city: string;
      country: string;
    };
    status: AvailabilityStatus;
    last_active: string;
    profile_picture: string;
    is_verified: string;
  };
  service_category: {
    id: string;
    name: string;
  };
  stats: {
    jobs_done: number;
    active_jobs: number;
    average_rating: number;
    repeat_client_percent: number;
    total_reviews: number;
  };
  subscription: {
    current_plan: SUBSCRIPTION;
    status: SUBSCRIPTION_STATUS;
    renewal_date: string;
    started_at: string;
  };
  verification: {
    identity_verified: boolean;
    nin_verified: boolean;
    bvn_verified: boolean;
    address_verified: boolean;
    business_verified: boolean;
    government_id: string;
  };
  services_offered: {
    id: string;
    name: string;
    pricing_type: "FIXED" | "REQUEST_QUOTE";
    price: number;
    category: string;
  }[];
  work_gallery: [];
  past_clients: Client[];
}

export interface Client {
  id: string;
  name: string;
  profile_picture: string;
}
