import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { SkeletonBox } from "@/shared/components";
import { StyleSheet, View } from "react-native";

const ProviderProfileSkeleton = () => {
  return (
    <View style={styles.skeletonContainer}>
      {/* Profile header */}
      <View style={styles.skeletonHeader}>
        <View style={styles.skeletonProfile}>
          <SkeletonBox width={56} height={56} borderRadius={28} />

          <View style={{ gap: 8 }}>
            <SkeletonBox width={140} height={14} borderRadius={4} />

            <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
              <SkeletonBox width={70} height={10} borderRadius={4} />
              <SkeletonBox width={80} height={10} borderRadius={4} />
            </View>
          </View>
        </View>
      </View>

      {/* Stats */}
      <View style={styles.skeletonStats}>
        {[1, 2, 3].map((item) => (
          <View key={item} style={styles.skeletonStat}>
            <SkeletonBox width={40} height={18} borderRadius={4} />
            <SkeletonBox width={60} height={10} borderRadius={4} />
          </View>
        ))}
      </View>

      {/* Dark section */}
      <View style={styles.skeletonDarkSection}>
        {/* Section header */}
        <View style={styles.skeletonDarkHeader}>
          <SkeletonBox width={105} height={14} borderRadius={4} />
          <SkeletonBox width={75} height={14} borderRadius={4} />
        </View>

        {/* Details */}
        <View style={styles.skeletonDetails}>
          {/* Category */}
          <View style={styles.skeletonRow}>
            <SkeletonBox width={60} height={11} borderRadius={4} />
            <SkeletonBox width={75} height={24} borderRadius={25} />
          </View>

          <View style={styles.skeletonDivider} />

          {/* Services */}
          <View style={styles.skeletonRow}>
            <SkeletonBox width={55} height={11} borderRadius={4} />

            <View style={styles.skeletonTags}>
              <SkeletonBox width={70} height={24} borderRadius={25} />
              <SkeletonBox width={80} height={24} borderRadius={25} />
            </View>
          </View>

          <View style={styles.skeletonDivider} />

          {/* Last active */}
          <View style={styles.skeletonRow}>
            <SkeletonBox width={70} height={11} borderRadius={4} />
            <SkeletonBox width={100} height={11} borderRadius={4} />
          </View>

          <View style={styles.skeletonDivider} />

          {/* Price */}
          <View style={styles.skeletonRow}>
            <SkeletonBox width={40} height={11} borderRadius={4} />
            <SkeletonBox width={80} height={12} borderRadius={4} />
          </View>

          <View style={styles.skeletonDivider} />

          {/* Reviews */}
          <View style={styles.skeletonRow}>
            <SkeletonBox width={55} height={11} borderRadius={4} />

            <View style={[CUSTOM_STYLES.row, { gap: 5 }]}>
              <View style={[CUSTOM_STYLES.row, { gap: 2 }]}>
                {[1, 2, 3, 4, 5].map((item) => (
                  <SkeletonBox
                    key={item}
                    width={12}
                    height={12}
                    borderRadius={3}
                  />
                ))}
              </View>

              <SkeletonBox width={35} height={11} borderRadius={4} />
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  skeletonContainer: {
    paddingBottom: 36,
    gap: 16,
  },

  skeletonHeader: {
    paddingHorizontal: 20,
    paddingTop: 67,
    paddingBottom: 24,
  },

  skeletonProfile: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },

  skeletonStats: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 20,
  },

  skeletonStat: {
    alignItems: "center",
    gap: 6,
  },

  skeletonDarkSection: {
    backgroundColor: PALETTE.black,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    marginTop: 4,
  },

  skeletonDarkHeader: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
  },

  skeletonDetails: {
    backgroundColor: PALETTE.white,
    padding: 20,
    borderTopRightRadius: 10,
    borderTopLeftRadius: 10,
    gap: 10,
  },

  skeletonRow: {
    minHeight: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  skeletonTags: {
    width: "50%",
    flexDirection: "row",
    justifyContent: "flex-end",
    flexWrap: "wrap",
    gap: 8,
  },

  skeletonDivider: {
    height: 1,
    backgroundColor: PALETTE.grey01,
    opacity: 0.5,
  },
});

export default ProviderProfileSkeleton;