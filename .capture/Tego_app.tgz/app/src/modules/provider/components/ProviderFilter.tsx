import FilterIcon from "@/assets/images/app-icons/filter.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useCategories } from "@/modules/categories/hooks/useCategories";
import { CustomButton, CustomText } from "@/shared/components";
import { useModalState } from "@/shared/hooks/useModalState";
import { getCategoryIcon } from "@/shared/utils/categoryIcons";
import AntDesign from "@expo/vector-icons/AntDesign";
import Octicons from "@expo/vector-icons/Octicons";
import {
  BottomSheetBackdrop,
  BottomSheetFooter,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { useCallback } from "react";
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useProviderFilterStore } from "../store/providerFilter";

const PREFERENCES = [
  {
    label: "Available now",
    description: "Show only artisans online today",
    value: "available_now",
  },
  {
    label: "Top Providers",
    description: "search for only top providers",
    value: "top",
  },
  {
    label: "Verified Only",
    description: "ID & skill verified professionals",
    value: "verified",
  },
  {
    label: "Near me (< 5km)",
    description: "Within your immediate area",
    value: "near",
  },
];

const ProviderFilter = () => {
  const insets = useSafeAreaInsets();
  const ref = useModalState();
  const { clearFilters, applyFilters } = useProviderFilterStore();
  const { categories } = useCategories();

  const handleApply = () => {
    applyFilters();
    ref.close();
  };

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.89}
        pressBehavior="none"
      />
    ),
    [],
  );

  const renderFooter = useCallback(
    (props: any) => (
      <BottomSheetFooter {...props} bottomInset={0}>
        <View
          style={[
            styles.footer,
            { paddingBottom: Math.max(insets.bottom, 34) },
          ]}
        >
          <CustomButton
            title="Reset"
            variant="secondary"
            onPress={clearFilters}
            style={styles.buttons}
          />
          <CustomButton
            title="Apply"
            variant="primary"
            onPress={handleApply}
            style={styles.buttons}
          />
        </View>
      </BottomSheetFooter>
    ),
    [],
  );

  return (
    <View>
      <Pressable
        onPress={ref.open}
        style={[styles.filterTrigger, CUSTOM_STYLES.center]}
      >
        <FilterIcon />
      </Pressable>

      {Platform.OS === "ios" ? (
        <Modal
          visible={ref.isOpen}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={ref.close}
        >
          <Pressable style={styles.overlay} onPress={ref.close} />
          <View style={[styles.content]}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={[{ flexGrow: 1 }]}
            >
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  Filter
                </CustomText>
                <Pressable onPress={ref.close} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <Content
                categories={
                  categories?.map((category) => ({
                    name: category.name,
                    image: category.image,
                    id: category.id,
                  })) ?? []
                }
              />
            </ScrollView>

            <View
              style={[
                styles.footer,
                { paddingBottom: Math.max(insets.bottom, 34) },
              ]}
            >
              <CustomButton
                title="Reset"
                variant="secondary"
                onPress={clearFilters}
                style={styles.buttons}
              />
              <CustomButton
                title="Apply"
                variant="primary"
                onPress={handleApply}
                style={styles.buttons}
              />
            </View>
          </View>
        </Modal>
      ) : (
        <BottomSheetModal
          ref={ref.ref}
          enablePanDownToClose
          backdropComponent={renderBackdrop}
          footerComponent={renderFooter}
          backgroundStyle={styles.container}
          handleIndicatorStyle={{ height: 0 }}
          handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
          handleComponent={() => <></>}
          snapPoints={["95%"]}
        >
          <BottomSheetScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{
              paddingBottom: insets.bottom + 90,
            }}
          >
            <View style={[styles.content]}>
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  Filter
                </CustomText>
                <Pressable onPress={ref.close} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <Content
                categories={
                  categories?.map((category) => ({
                    name: category.name,
                    image: category.image,
                    id: category.id,
                  })) ?? []
                }
              />
            </View>
          </BottomSheetScrollView>
        </BottomSheetModal>
      )}
    </View>
  );
};

interface Categories {
  name: string;
  id: string;
  image: string;
}

const Content = ({ categories }: { categories: Categories[] }) => {
  const { filters, setFilter } = useProviderFilterStore();
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.body}>
        <View style={styles.field}>
          <CustomText size="sm" weight="semibold">
            Category
          </CustomText>
          <View style={styles.categories}>
            {categories.map((item) => {
              const isActive = filters.category_id === item.id;
              return (
                <Pressable
                  key={item.id}
                  onPress={() => setFilter("category_id", item.id)}
                  style={styles.categoryContainer}
                >
                  <View
                    style={[
                      styles.category,
                      isActive ? styles.active : styles.inactive,
                    ]}
                  >
                    {getCategoryIcon(item.image, {
                      color: isActive ? PALETTE.white : PALETTE.primary,
                      size: 16,
                    })}
                    <CustomText
                      size="sm"
                      weight="medium"
                      style={{
                        textTransform: "capitalize",
                        color: isActive ? PALETTE.white : PALETTE.black,
                      }}
                    >
                      {item.name}
                    </CustomText>
                  </View>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={CUSTOM_STYLES.divider} />

        <View style={styles.field}>
          <CustomText size="sm" weight="semibold">
            Rating
          </CustomText>
          <View style={styles.ratings}>
            {Array.from({ length: 5 }).map((_, index) => {
              const value = index + 1;
              const isActive =
                filters.rating_min && filters.rating_min >= value;
              return (
                <Pressable
                  style={styles.rating}
                  key={index}
                  onPress={() => setFilter("rating_min", value)}
                >
                  <View
                    style={[
                      styles.rating,
                      CUSTOM_STYLES.center,
                      isActive ? styles.active : styles.inactive,
                    ]}
                  >
                    <Octicons
                      name="star-fill"
                      size={16}
                      color={isActive ? PALETTE.yellow : PALETTE.black40}
                    />
                  </View>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={CUSTOM_STYLES.divider} />

        <View style={styles.field}>
          <View style={styles.row}>
            <CustomText size="sm" weight="semibold">
              Preference{" "}
            </CustomText>
            <View style={styles.optional}>
              <CustomText size="xs" weight="medium">
                Select multiples
              </CustomText>
            </View>
          </View>

          <View style={styles.preferences}>
            {PREFERENCES.map((preference, index) => (
              <Pressable
                key={index}
                onPress={() => {
                  const currentPreferences = filters?.preference ?? [];

                  const isSelected = currentPreferences.includes(
                    preference.value,
                  );

                  setFilter(
                    "preference",
                    isSelected
                      ? currentPreferences.filter(
                          (value) => value !== preference.value,
                        )
                      : [...currentPreferences, preference.value],
                  );
                }}
              >
                <View key={index}>
                  <View style={styles.preference}>
                    <View style={{ gap: 6 }}>
                      <CustomText weight="semibold">
                        {preference.label}
                      </CustomText>
                      <CustomText
                        style={styles.description}
                        weight="medium"
                        size="xs"
                      >
                        {preference.description}
                      </CustomText>
                    </View>
                    <View style={[styles.outerRadioBox, CUSTOM_STYLES.center]}>
                      {filters?.preference?.includes(preference.value) && (
                        <View style={styles.innerRadioBox} />
                      )}
                    </View>
                  </View>
                  {index + 1 !== PREFERENCES.length && (
                    <View
                      style={[
                        CUSTOM_STYLES.divider,
                        {
                          marginVertical: 20,
                          backgroundColor: PALETTE.black,
                          opacity: 0.04,
                        },
                      ]}
                    />
                  )}
                </View>
              </Pressable>
            ))}
          </View>
        </View>
      </View>
    </View>
  );
};

ProviderFilter.displayName = "Provider Filter";

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  filterTrigger: {
    width: 50,
    height: 50,
    borderRadius: 80,
    backgroundColor: PALETTE.white,
  },
  content: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    borderRadius: 0,
    flex: 1,
    overflow: "hidden",
  },
  overlay: {},
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 20,
    flex: 1,
    marginTop: 20,
    paddingHorizontal: 20,
  },
  field: {
    gap: 20,
  },
  categories: {
    flexDirection: "row",
    flexWrap: "wrap",
    rowGap: 12,
    gap: 12,
  },
  categoryContainer: {
    width: "auto",
  },
  category: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 39,
  },
  ratings: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
  },
  rating: {
    flex: 1,
    height: 40,
    borderRadius: 56,
  },
  active: {
    backgroundColor: PALETTE.primary,
  },
  inactive: {
    backgroundColor: PALETTE.grey01,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  optional: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 50,
  },
  preferences: {
    backgroundColor: PALETTE.whiteLight,
    borderRadius: 6,
    paddingVertical: 10,
  },
  preference: {
    paddingHorizontal: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  description: {
    opacity: 0.6,
  },
  outerRadioBox: {
    width: 18,
    height: 18,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: PALETTE.black20,
  },
  innerRadioBox: {
    width: 12,
    height: 12,
    borderRadius: 28,
    backgroundColor: PALETTE.primary,
  },
  footer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: PALETTE.white,
  },
  buttons: {
    flex: 1,
    height: 50,
  },
});

export default ProviderFilter;
