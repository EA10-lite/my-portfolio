import { PALETTE } from "@/constants/colors";
import { CustomText } from "@/shared/components";
import { StyleSheet, View } from "react-native";

interface ProviderStatProps {
  jobsDone: number;
  rating: number;
  repeatClient: number;
}

const ProviderStat = ({
  jobsDone,
  rating,
  repeatClient,
}: ProviderStatProps) => {
  return (
    <View style={styles.statsRow}>
      <StatCard label="Jobs Done" value={`${jobsDone}+`} />
      <StatCard label="Rating" value={`${rating}`} />
      <StatCard label="Repeat Clients" value={`${repeatClient}%`} />
    </View>
  );
};

const StatCard = ({ label, value }: { label: string; value: string }) => (
  <View style={styles.statCard}>
    <CustomText size="md" weight="bold" style={styles.statValue}>
      {value}
    </CustomText>
    <CustomText size="xs" weight="regular" style={styles.statLabel}>
      {label}
    </CustomText>
  </View>
);

const styles = StyleSheet.create({
  statsRow: {
    flexDirection: "row",
    gap: 7,
    borderRadius: 10,
    overflow: "hidden",
  },
  statCard: {
    flex: 1,
    backgroundColor: PALETTE.grey01,
    height: 75,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    overflow: "hidden",
    paddingHorizontal: 8,
  },
  statValue: {
    textAlign: "center",
  },
  statLabel: {
    opacity: 0.6,
    textAlign: "center",
  },
});

export default ProviderStat;
