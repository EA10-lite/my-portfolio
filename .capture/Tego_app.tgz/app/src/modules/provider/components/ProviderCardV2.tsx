import VerifiedIcon from "@/assets/images/app-icons/verified.svg";
import { PALETTE } from "@/constants/colors";
import { CATEGORIES_TYPE } from "@/constants/types";
import { useBookingStore } from "@/modules/booking/store/booking.store";
import { FullProvider } from "@/modules/categories/types/category.dto";
import { getStatusColor } from "@/shared/utils/colors";
import { truncateName, truncateText } from "@/shared/utils/formatter";
import { categoryImageMap } from "@/shared/utils/getter";
import Ionicons from "@expo/vector-icons/Ionicons";
import Octicons from "@expo/vector-icons/Octicons";
import { StyleSheet, View } from "react-native";
import { CImg, CustomButton, CustomText } from "../../../shared/components";

interface ProviderProps {
  item: FullProvider;
  handleBookNow: () => void;
}

const ProviderCardV2 = ({ item, handleBookNow }: ProviderProps) => {
  const { setProvider } = useBookingStore();

  const bookNow = () => {
    setProvider({
      id: item.id,
      name: `${item.first_name} ${item.last_name}`,
      availability_status: item.available_status,
      rating: item.rating || 5,
      jobs_done: 0,
      location: item.location_info.area,
      profile_picture: item.profile_picture,
      repeat_clients: 98,
      is_verified: item.is_verified,
      services: item.service_details,
    });
    handleBookNow();
  };

  const getImage = (category: CATEGORIES_TYPE) => {
    return item.profile_card || categoryImageMap[category];
  };
  return (
    <>
      <View style={styles.card}>
        <View style={styles.header}>
          <CImg
            style={styles.image}
            uri={getImage(
              item.service_category.name.toLowerCase() as CATEGORIES_TYPE,
            )}
            width={768}
          />
        </View>
        <View style={styles.body}>
          <View style={styles.headerContent}>
            <View style={styles.row}>
              {item.available_status && (
                <View style={styles.tag}>
                  <View
                    style={[
                      styles.dot,
                      {
                        backgroundColor: getStatusColor(item.available_status),
                      },
                    ]}
                  />
                  <CustomText
                    weight="medium"
                    size="xs"
                    style={{ textTransform: "capitalize" }}
                  >
                    {item.available_status.toLowerCase() === "offline"
                      ? "Not Available"
                      : item.available_status.toLowerCase() ===
                            "available_to_work" ||
                          item.available_status.toLowerCase() === "online"
                        ? "Available"
                        : "Busy"}
                  </CustomText>
                </View>
              )}
              {item.service_details && (
                <View style={styles.tag}>
                  <CustomText weight="medium" size="xs">
                    {item.service_details[0]?.service_name}
                  </CustomText>
                </View>
              )}
            </View>

            {item.rating && (
              <View style={styles.tag}>
                <CustomText weight="medium" size="xs">
                  {item.rating}
                </CustomText>
                <Octicons name="star-fill" size={16} color={PALETTE.yellow} />
              </View>
            )}
          </View>

          <View style={styles.content}>
            <View style={{ gap: 12 }}>
              <CustomText weight="semibold" size="lg">
                {truncateName(`${item.first_name} ${item.last_name}`)}{" "}
                <VerifiedIcon width={16} height={16} />
              </CustomText>
              <View style={{ flexDirection: "row" }}>
                <View style={styles.tag}>
                  <Ionicons
                    name="location-sharp"
                    size={16}
                    color={PALETTE.black}
                  />
                  <CustomText weight="medium" size="xs">
                    {item.location_info.city
                      ? truncateText(item.location_info.city, 20)
                      : "Not set"}
                  </CustomText>
                </View>
              </View>
            </View>
            <CustomButton
              title="Book"
              style={styles.button}
              variant="default"
              onPress={bookNow}
              size="sm"
            />
          </View>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 10,
    backgroundColor: PALETTE.whiteLight,
    minWidth: 259,
    overflow: "hidden",
  },
  header: {
    minHeight: 184,
    position: "relative",
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: "100%", // fills the header height only
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  dot: {
    backgroundColor: PALETTE.success,
    width: 6,
    height: 6,
    borderRadius: 10,
  },
  body: {
    padding: 20,
    gap: 12,
  },
  content: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  row: {
    flexDirection: "row",
    gap: 4,
  },
  tag: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: PALETTE.white,
    borderRadius: 25,
    paddingVertical: 6,
    paddingHorizontal: 12,
    gap: 3,
  },
  button: {
    width: 108,
    paddingHorizontal: 20,
  },
});

export default ProviderCardV2;
