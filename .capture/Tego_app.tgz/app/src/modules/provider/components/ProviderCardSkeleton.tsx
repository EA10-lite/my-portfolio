import { PALETTE } from "@/constants/colors";
import { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
    useAnimatedStyle,
    useSharedValue,
    withRepeat,
    withTiming,
} from "react-native-reanimated";

const SkeletonBox = ({
  width,
  height,
  borderRadius = 6,
  style,
}: {
  width?: number | string;
  height: number;
  borderRadius?: number;
  style?: any;
}) => {
  const opacity = useSharedValue(1);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.4, { duration: 800 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[
        { width, height, borderRadius, backgroundColor: PALETTE.grey01 },
        animatedStyle,
        style,
      ]}
    />
  );
};

// Skeleton for ProviderCard
export const ProviderCardSkeleton = () => {
  return (
    <View style={styles.card}>
      {/* Image */}
      <SkeletonBox width="100%" height={138} borderRadius={0} />

      <View style={styles.body}>
        <View style={styles.headerContent}>
          {/* Tags row */}
          <View style={styles.row}>
            <SkeletonBox width={80} height={28} borderRadius={25} />
            <SkeletonBox width={70} height={28} borderRadius={25} />
          </View>
          {/* Rating */}
          <SkeletonBox width={50} height={28} borderRadius={25} />
        </View>

        <View style={{ gap: 10 }}>
          {/* Name */}
          <SkeletonBox width="60%" height={16} borderRadius={4} />
          {/* Location + price */}
          <View style={styles.row}>
            <SkeletonBox width={100} height={28} borderRadius={25} />
            <SkeletonBox width={80} height={28} borderRadius={25} />
          </View>
        </View>

        {/* Buttons */}
        <View style={styles.buttons}>
          <SkeletonBox width="48%" height={36} borderRadius={6} />
          <SkeletonBox width="48%" height={36} borderRadius={6} />
        </View>
      </View>
    </View>
  );
};

// Skeleton for ProviderCardV2
export const ProviderCardV2Skeleton = () => {
  return (
    <View style={stylesV2.card}>
      {/* Image */}
      <SkeletonBox width="100%" height={184} borderRadius={0} />

      <View style={stylesV2.body}>
        {/* Tags row + rating */}
        <View style={stylesV2.headerContent}>
          <View style={stylesV2.row}>
            <SkeletonBox width={80} height={28} borderRadius={25} />
            <SkeletonBox width={70} height={28} borderRadius={25} />
          </View>
          <SkeletonBox width={50} height={28} borderRadius={25} />
        </View>

        {/* Name + location + button */}
        <View style={stylesV2.content}>
          <View style={{ gap: 12 }}>
            <SkeletonBox width={120} height={18} borderRadius={4} />
            <SkeletonBox width={100} height={28} borderRadius={25} />
          </View>
          <SkeletonBox width={80} height={36} borderRadius={6} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 10,
    backgroundColor: PALETTE.whiteLight,
    width: 259,
    overflow: "hidden",
  },
  body: {
    padding: 20,
    gap: 20,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  row: {
    flexDirection: "row",
    gap: 4,
  },
  buttons: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
});

const stylesV2 = StyleSheet.create({
  card: {
    borderRadius: 10,
    backgroundColor: PALETTE.whiteLight,
    minWidth: 259,
    overflow: "hidden",
  },
  body: {
    padding: 20,
    gap: 12,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  content: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  row: {
    flexDirection: "row",
    gap: 4,
  },
});
