import VerifiedIcon from "@/assets/images/app-icons/verified.svg";
import { PALETTE } from "@/constants/colors";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import { CustomText, UserAvatar } from "@/shared/components";
import { getStatusColor } from "@/shared/utils/colors";
import Ionicons from "@expo/vector-icons/Ionicons";
import { StyleSheet, View } from "react-native";

interface ProviderHeaderProps {
  user: {
    avatar?: string;
    name: string;
    isVerified?: boolean;
  };
  availability?: AvailabilityStatus;
  location?: string;
}

const ProviderHeader = ({ provider }: { provider: ProviderHeaderProps }) => {
  return (
    <View style={styles.profileRow}>
      <UserAvatar
        url={provider?.user.avatar}
        name={provider?.user.name}
      />
      <View style={styles.profileInfo}>
        <CustomText weight="semibold" size="md">
          {provider.user.name}{" "}
          {provider?.user.isVerified && <VerifiedIcon width={16} height={16} />}
        </CustomText>
        <View style={styles.profileMeta}>
          {provider?.availability && (
            <View style={styles.inlineRow}>
              <View
                style={[
                  styles.availabilityDot,
                  { backgroundColor: getStatusColor(provider?.availability.toLowerCase())}
                ]}
              />
              <CustomText size="xs" weight="regular">
                {provider?.availability}
              </CustomText>
            </View>
          )}

          {provider?.location && (
            <View style={styles.inlineRow}>
              <Ionicons name="location-sharp" size={12} color={PALETTE.black} />
              <CustomText size="xs" weight="regular">
                {provider?.location}
              </CustomText>
            </View>
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  profileRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
  },
  profileInfo: {
    gap: 8,
  },
  profileMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  inlineRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  availabilityDot: {
    width: 6,
    height: 6,
    borderRadius: 10,
  },
  buttons: {},
  button: {
    flex: 1,
  },
});

export default ProviderHeader;
