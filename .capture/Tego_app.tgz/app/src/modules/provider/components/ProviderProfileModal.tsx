import BoltIcon from "@/assets/images/app-icons/bolt.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Arrow,
  CustomButton,
  CustomText,
  UserAvatarGroup,
} from "@/shared/components";
import { formatDateTime } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import Octicons from "@expo/vector-icons/Octicons";
import {
  BottomSheetBackdrop,
  BottomSheetFooter,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { forwardRef, useCallback, useMemo, useState } from "react";
import {
  Pressable,
  StyleSheet,
  TouchableOpacity,
  View,
  ViewStyle,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useProviderDetails } from "../hooks/useProvider";
import ProviderHeader from "./ProviderHeader";
import ProviderProfileSkeleton from "./ProviderProfileSkeleton";
import ProviderStat from "./ProviderStat";
import { useBookingStore } from "@/modules/booking/store/booking.store";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";

interface ProviderProfileModalProps {
  providerId: string;
  closeModal: () => void;
  snapPoints?: (string | number)[];
}

const ProviderProfileModal = forwardRef<
  BottomSheetModal,
  ProviderProfileModalProps
>(({ closeModal, providerId }, ref) => {
  const { bottom } = useSafeAreaInsets();
  const { setProvider } = useBookingStore();
  const snapPoints = useMemo(() => ["80%", "100%"], []);
  const [isSheetActive, setIsSheetActive] = useState(false);

  const { provider: profile, isLoading } = useProviderDetails(providerId, {
    enabled: isSheetActive && Boolean(providerId),
    staleTime: 2 * 60 * 1000,
  });
  const isProfileReady = Boolean(profile && profile.provider.id === providerId);
  const primaryCategory = profile?.services_offered?.[0]?.category;
  const handleSheetChange = useCallback((index: number) => {
    setIsSheetActive(index >= 0);
  }, []);
  const handleSheetDismiss = useCallback(() => {
    setIsSheetActive(false);
  }, []);

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.89}
        pressBehavior="close"
      />
    ),
    [],
  );

  const renderFooter = useCallback(
    (props: any) => (
      <BottomSheetFooter {...props}>
        <View
          style={[
            styles.actionRow,
            {
              paddingBottom: bottom,
            },
          ]}
        >
          <View style={styles.actionButton}>
            <CustomButton
              title="Send a message"
              variant="default"
              onPress={goToMessage}
              disabled={!isProfileReady || !profile}
            />
          </View>
          <View style={styles.actionButton}>
            <CustomButton
              title="Book Now"
              variant="primary"
              onPress={bookNow}
              disabled={!isProfileReady || !profile}
            />
          </View>
        </View>
      </BottomSheetFooter>
    ),
    [isProfileReady, profile],
  );

  const goToMessage = () => {
    (ref as React.RefObject<BottomSheetModal>)?.current?.dismiss();
    router.push({
      pathname: `/message/${profile?.provider.id}` as any,
      params: {
        receiverId: profile?.provider.id,
        name: profile?.provider.name,
        avatar: profile?.provider.profile_picture ?? "",
        isOnline: "false",
      },
    });
  };

  const handleBookNow = () => {
    router.push("/(customer)/booking/form");
  };

  const bookNow = () => {
    (ref as React.RefObject<BottomSheetModal>)?.current?.dismiss();
    setProvider({
      id: profile?.provider?.id ?? "",
      name: `${profile?.provider.name}`,
      availability_status: profile?.provider?.status as AvailabilityStatus,
      rating: profile?.stats?.average_rating || 0,
      jobs_done: profile?.stats?.jobs_done || 0,
      location: `${profile?.provider?.location.city} ${profile?.provider?.location.state}`,
      profile_picture: profile?.provider?.profile_picture ?? "",
      repeat_clients: profile?.stats?.repeat_client_percent || 0,
      is_verified: true,
      services: profile?.services_offered?.map((service)=> ({
        id: service.id,
        service_name: service.name
      })) || [],
    });
    handleBookNow();
  };

  return (
    <BottomSheetModal
      ref={ref}
      onDismiss={handleSheetDismiss}
      onChange={handleSheetChange}
      backdropComponent={renderBackdrop}
      footerComponent={renderFooter}
      snapPoints={snapPoints}
      backgroundStyle={styles.container}
      handleIndicatorStyle={{ height: 0 }}
      handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
      handleComponent={() => <></>}
    >
      {/* Sheet */}
      <BottomSheetScrollView
        style={styles.sheetWrapper}
        showsVerticalScrollIndicator={false}
      >
        {!isProfileReady ? (
          <ProviderProfileSkeleton />
        ) : (
          <View style={[styles.sheet]}>
            {/* Profile header */}
            <LinearGradient
              colors={[
                "rgba(51, 171, 247, 0.232)",
                "rgba(255, 255, 255, 0.255)",
              ]}
              locations={[0, 1]}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={styles.profileHeader}
            >
              {/* 👇 custom drag handle INSIDE gradient */}
              <View style={styles.dragWrapper}>
                <View style={styles.dragHandle} />
              </View>
              {/* Close button */}
              <Pressable
                style={[styles.closeButton, CUSTOM_STYLES.close]}
                onPress={() => (ref as React.RefObject<BottomSheetModal>)?.current?.dismiss()}
                hitSlop={12}
              >
                <AntDesign name="close" size={12} />
              </Pressable>

              <View style={styles.profileRow}>
                <ProviderHeader
                  provider={{
                    user: {
                      name: profile?.provider.name ?? "",
                      avatar: profile?.provider?.profile_picture,
                      isVerified: profile?.verification?.identity_verified,
                    },
                    location:
                      profile?.provider.location.city &&
                      `${profile?.provider?.location.city}, ${profile?.provider?.location.state}`,
                    availability: profile?.provider?.status,
                  }}
                />
              </View>
            </LinearGradient>

            {/* Stats */}
            <ProviderStat
              jobsDone={profile?.stats?.jobs_done ?? 0}
              rating={profile?.stats?.average_rating ?? 0}
              repeatClient={profile?.stats?.repeat_client_percent ?? 0}
            />

            {/* Dark section */}
            <View style={styles.darkSection}>
              <View style={styles.darkSectionHeader}>
                <View style={styles.inlineRow}>
                  <BoltIcon color={PALETTE.white} width={14} height={14} />
                  <CustomText
                    size="sm"
                    weight="medium"
                    style={styles.whiteText}
                  >
                    Book Instantly
                  </CustomText>
                </View>
                {profile?.past_clients && profile.past_clients.length > 9 && (
                  <View style={[styles.inlineRow, { gap: 8 }]}>
                    <UserAvatarGroup
                      users={profile?.past_clients ?? []}
                      size="xs"
                    />
                    <CustomText
                      size="sm"
                      weight="medium"
                      style={styles.whiteText}
                    >
                      Clients
                    </CustomText>
                  </View>
                )}
              </View>

              {/* Details */}
              <View style={styles.detailsSection}>
                <View style={styles.detailsGroup}>
                  {primaryCategory ? (
                    <View style={styles.detailGroup}>
                      <DetailRow label="Category">
                        <Tag label={primaryCategory} />
                      </DetailRow>
                    </View>
                  ) : null}
                  <View style={styles.detailDivider} />
                  <View style={styles.detailGroup}>
                    <DetailRow
                      label="Services"
                      style={{ alignItems: "flex-start" }}
                    >
                      <View style={styles.tagRow}>
                        {(profile?.services_offered ?? [])
                          .slice(0, 3)
                          .map((service, index) => (
                            <Tag key={index} label={service.name} />
                          ))}
                        {profile?.services_offered &&
                          profile?.services_offered?.length > 3 && (
                            <Tag
                              label={`+${profile.services_offered.length - 3} more`}
                            />
                          )}
                      </View>
                    </DetailRow>
                  </View>

                  <View style={styles.detailDivider} />
                  <FieldRow
                    label="Last Active"
                    value={
                      profile?.provider?.last_active
                        ? formatDateTime(profile?.provider.last_active)
                        : "N/A"
                    }
                  />
                  <View style={styles.detailDivider} />
                  <FieldRow
                    label="Price"
                    value={`From ₦${profile?.services_offered?.[0]?.price}`}
                  />
                  <View style={styles.detailDivider} />
                  <FieldRow
                    label="Reviews"
                    content={
                      <TouchableOpacity
                        onPress={() => {
                          (ref as React.RefObject<BottomSheetModal>)?.current?.dismiss();
                          router.push({
                            pathname:
                              `/(customer)/review/${profile?.provider?.id}` as any,
                            params: {
                              providerId: profile?.provider.id,
                              name: profile?.provider.name,
                              avatar: profile?.provider.profile_picture,
                              isVerified: `${profile?.verification.identity_verified}`,
                              location: profile?.provider.location.city,
                            },
                          });
                        }}
                        disabled={
                          !profile?.stats?.total_reviews ||
                          profile?.stats?.total_reviews === 0
                        }
                      >
                        <View style={[CUSTOM_STYLES.row, { gap: 5 }]}>
                          <View style={[CUSTOM_STYLES.row]}>
                            {Array.from({ length: 5 }).map((_, index) => (
                              <Octicons
                                key={index}
                                name={
                                  index <
                                  Math.round(
                                    profile?.stats?.average_rating ?? 0,
                                  )
                                    ? "star-fill"
                                    : "star"
                                }
                                size={12}
                                color={PALETTE.yellow}
                              />
                            ))}
                          </View>
                          <CustomText size="xs" weight="semibold">
                            {profile?.stats?.average_rating}{" "}
                            <CustomText
                              size="xs"
                              weight="semibold"
                              style={{ opacity: 0.3 }}
                            >
                              ({profile?.stats?.total_reviews})
                            </CustomText>
                          </CustomText>
                          {(profile?.stats?.total_reviews ?? 0) > 0 && (
                            <Arrow
                              direction="right"
                              size={20}
                              color={PALETTE.primary}
                            />
                          )}
                        </View>
                      </TouchableOpacity>
                    }
                  />
                </View>
              </View>
            </View>
          </View>
        )}
      </BottomSheetScrollView>
    </BottomSheetModal>
  );
});

const FieldRow = ({
  label,
  value,
  content,
}: {
  label: string;
  value?: string;
  content?: React.ReactNode;
}) => (
  <View style={[styles.inlineRow, styles.fieldRow]}>
    <CustomText size="xs" weight="medium">
      {label}
    </CustomText>
    {content
      ? content
      : Boolean(value) && (
          <CustomText size="xs" weight="semibold">
            {value}
          </CustomText>
        )}
  </View>
);

const DetailRow = ({
  label,
  children,
  style,
}: {
  label: string;
  style?: ViewStyle;
  children: React.ReactNode;
}) => (
  <View
    style={[
      styles.inlineRow,
      style && style,
      { justifyContent: "space-between" },
    ]}
  >
    <CustomText size="xs" weight="medium">
      {label}
    </CustomText>
    <View style={styles.detailValue}>{children}</View>
  </View>
);

const Tag = ({ label }: { label: string }) => (
  <View style={styles.tag}>
    <CustomText
      size="xs"
      weight="medium"
      style={{ textTransform: "capitalize" }}
    >
      {label}
    </CustomText>
  </View>
);

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  // ── Sheet ─────────────────────────────────────────
  sheetWrapper: {
    paddingTop: 0,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
    // justifyContent: "flex-end",
  },
  sheet: {
    paddingBottom: 36,
    gap: 16,
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 30,
    backgroundColor: PALETTE.white,
  },

  // ── Close button ──────────────────────────────────
  closeButton: {
    right: 20,
    top: 32,
  },

  // ── Profile header ────────────────────────────────
  profileHeader: {
    paddingHorizontal: 20,
    position: "relative",
  },
  profileRow: {
    paddingTop: 67,
    flexDirection: "row",
    alignItems: "center",
  },

  // ── Dark section ──────────────────────────────────
  darkSection: {
    backgroundColor: PALETTE.black,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    marginTop: 4,
  },
  darkSectionHeader: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  whiteText: {
    color: PALETTE.white,
  },

  // ── Details ───────────────────────────────────────
  detailsSection: {
    backgroundColor: PALETTE.white,
    padding: 20,
    borderTopRightRadius: 10,
    borderTopLeftRadius: 10,
    gap: 10,
  },
  detailsGroup: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 6,
  },
  detailGroup: {
    padding: 16,
  },
  detailDivider: {
    marginVertical: 6,
    opacity: 0.04,
    backgroundColor: PALETTE.black,
    height: 1,
  },
  detailValue: {
    width: "50%",
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    justifyContent: "flex-end",
  },
  fieldRow: {
    justifyContent: "space-between",
    padding: 16,
  },
  tagRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    justifyContent: "flex-end",
  },
  tag: {
    backgroundColor: PALETTE.grey01,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 25,
  },

  // ── Actions ───────────────────────────────────────
  actionRow: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 34, // safe area for iPhone
    backgroundColor: PALETTE.white,
  },
  actionButton: {
    flex: 1,
  },

  // ── Shared ────────────────────────────────────────
  inlineRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  availabilityDot: {
    backgroundColor: PALETTE.success,
    width: 6,
    height: 6,
    borderRadius: 10,
  },
});

ProviderProfileModal.displayName = "ProviderProfileModal";

export default ProviderProfileModal;
