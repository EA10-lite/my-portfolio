import { api } from "@/shared/lib/api";
import { ProviderDetails } from "../types/provider-details";
import { ServiceProviderResponse } from "../types/provider.dto";

interface GetProvidersParams {
  page?: number;
  limit?: number;
  category_id?: string;
  rating_min?: number;
  preference?: string[];
  latitude?: number;
  longitude?: number;
  distance_radius?: number;
}

export const providerService = {
  getProviders: async ({
    page = 1,
    limit = 10,
    category_id,
    rating_min,
    preference,
    latitude,
    longitude,
    distance_radius,
  }: GetProvidersParams = {}) => {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
    });

    if (category_id) {
      params.append("category_id", category_id);
    }

    if (rating_min !== undefined) {
      params.append("rating_min", rating_min.toString());
    }

    if (preference?.length) {
      params.append("preference", preference.join(","));
    }

    if (latitude !== undefined) {
      params.append("latitude", latitude.toString());
    }

    if (longitude !== undefined) {
      params.append("longitude", longitude.toString());
    }

    if (distance_radius !== undefined) {
      params.append("distance_radius", distance_radius.toString());
    }

    const response = await api.get<ServiceProviderResponse>(
      `/services?${params.toString()}`,
    );

    return response.data;
  },
  getProviderDetails: async (provider_id: string) => {
    const response = await api.get<ProviderDetails>(
      `/users/providers/${provider_id}`,
    );
    return response.data;
  },
};
