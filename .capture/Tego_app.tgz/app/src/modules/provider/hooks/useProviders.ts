import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo } from "react";

import { queryKeys } from "@/constants/queryKeys";
import { providerService } from "../service/provider.service";
import { ServiceProvider } from "../types/provider.dto";

interface UseProvidersParams {
  category_id?: string;
  rating_min?: number;
  preference?: string[];
  latitude?: number | null;
  longitude?: number | null;
  distance_radius?: number;
  enabled?: boolean;
}

export const resolveProvidersEnabled = ({
  enabled,
  preference,
  latitude,
  longitude,
}: {
  enabled?: boolean;
  preference?: string[];
  latitude?: number | null;
  longitude?: number | null;
}): boolean => {
  if (enabled !== undefined) return enabled;
  if (
    preference?.includes("near_me") &&
    (latitude == null || longitude == null)
  ) {
    return false;
  }
  return true;
};

export const useProviders = ({
  category_id,
  rating_min,
  preference,
  latitude,
  longitude,
  distance_radius,
  enabled,
}: UseProvidersParams = {}) => {
  const providers = useInfiniteQuery({
    enabled: resolveProvidersEnabled({
      enabled,
      preference,
      latitude,
      longitude,
    }),

    queryKey: queryKeys.providers.list({
      category_id,
      rating_min,
      preference,
      latitude,
      longitude,
      distance_radius,
    }),

    queryFn: ({ pageParam = 1 }) =>
      providerService.getProviders({
        page: pageParam,
        limit: 10,
        category_id,
        rating_min,
        preference,
        latitude: latitude ?? undefined,
        longitude: longitude ?? undefined,
        distance_radius,
      }),

    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages
        ? lastPage.page + 1
        : undefined,

    initialPageParam: 1,
  });

  const allProviders: ServiceProvider[] = useMemo(
    () => providers.data?.pages.flatMap((page) => page.services) ?? [],
    [providers.data],
  );

  return {
    providers: allProviders,
    fetchNextPage: providers.fetchNextPage,
    isLoading: providers.isLoading,
    hasNextPage: providers.hasNextPage,
    isFetchingNextPage: providers.isFetchingNextPage,
    refetch: providers.refetch,
  };
};