import { resolveProvidersEnabled } from "../useProviders";

describe("resolveProvidersEnabled", () => {
  it("respects an explicit enabled flag", () => {
    expect(
      resolveProvidersEnabled({ enabled: false, preference: ["top_providers"] }),
    ).toBe(false);
    expect(
      resolveProvidersEnabled({
        enabled: true,
        preference: ["near_me"],
        latitude: null,
        longitude: null,
      }),
    ).toBe(true);
  });

  it("disables near_me until coordinates resolve", () => {
    expect(
      resolveProvidersEnabled({ preference: ["near_me"] }),
    ).toBe(false);
    expect(
      resolveProvidersEnabled({
        preference: ["near_me"],
        latitude: null,
        longitude: 6.5,
      }),
    ).toBe(false);
    expect(
      resolveProvidersEnabled({
        preference: ["near_me"],
        latitude: 6.5,
        longitude: 3.4,
      }),
    ).toBe(true);
  });

  it("keeps other preferences enabled without coordinates", () => {
    expect(resolveProvidersEnabled({ preference: ["top_providers"] })).toBe(
      true,
    );
    expect(resolveProvidersEnabled({})).toBe(true);
  });
});
