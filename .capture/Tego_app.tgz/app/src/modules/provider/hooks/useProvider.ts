import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { providerService } from "../service/provider.service";

export const useProviderDetails = (
  providerId: string,
  options?: {
    enabled?: boolean;
    staleTime?: number;
  },
) => {
  const provider = useQuery({
    queryKey: queryKeys.providers.detail(providerId),
    queryFn: async () => {
      const data = await providerService.getProviderDetails(providerId);
      return data;
    },
    enabled: Boolean(providerId) && (options?.enabled ?? true),
    staleTime: options?.staleTime,
  });

  return {
    provider: provider.data,
    isLoading: provider.isLoading,
  };
};
