import { create } from "zustand";

export interface ProviderFilters {
  category_id?: string;
  rating_min?: number;
  preference?: string[];
  latitude?: number;
  longitude?: number;
  distance_radius?: number;
}

interface ProviderFilterStore {
  filters: ProviderFilters;
  appliedFilters: ProviderFilters;

  setFilter: <K extends keyof ProviderFilters>(
    key: K,
    value: ProviderFilters[K],
  ) => void;

  setFilters: (filters: ProviderFilters) => void;

  applyFilters: () => void;

  clearFilters: () => void;
}

export const useProviderPrefrenceFilterStore = create<ProviderFilterStore>((set) => ({
  // What the user is currently selecting
  filters: {},

  // What is actually being used by the API
  appliedFilters: {},

  setFilter: (key, value) =>
    set((state) => ({
      filters: {
        ...state.filters,
        [key]: value,
      },
    })),

  setFilters: (filters) => set({ filters }),

  applyFilters: () =>
    set((state) => ({
      appliedFilters: state.filters,
    })),

  clearFilters: () =>
    set({
      filters: {},
      appliedFilters: {},
    }),
}));