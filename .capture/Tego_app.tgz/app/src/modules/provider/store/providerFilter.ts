import { create } from "zustand";

export interface ProviderFilters {
  category_id?: string;
  rating_min?: number;
  preference?: string[];
  latitude?: number;
  longitude?: number;
  distance_radius?: number;
}

interface ProviderFilterStore {
  // What the user is currently selecting
  filters: ProviderFilters;

  // What is currently being used by the API
  appliedFilters: ProviderFilters;

  // Update a single draft filter
  setFilter: <K extends keyof ProviderFilters>(
    key: K,
    value: ProviderFilters[K],
  ) => void;

  // Replace all draft filters
  setFilters: (filters: ProviderFilters) => void;

  // Set initial/default filters when entering a screen
  initializeFilters: (filters: ProviderFilters) => void;

  // Apply draft filters to the API filters
  applyFilters: () => void;

  // Clear both draft and applied filters
  clearFilters: () => void;
}

export const useProviderFilterStore = create<ProviderFilterStore>((set) => ({
  // What the user is currently selecting
  filters: {},

  // What is actually being used by the API
  appliedFilters: {},

  setFilter: (key, value) =>
    set((state) => ({
      filters: {
        ...state.filters,
        [key]: value,
      },
    })),

  setFilters: (filters) =>
    set({
      filters,
    }),

  initializeFilters: (filters) =>
    set({
      filters,
      appliedFilters: filters,
    }),

  applyFilters: () =>
    set((state) => ({
      appliedFilters: state.filters,
    })),

  clearFilters: () =>
    set({
      filters: {},
      appliedFilters: {},
    }),
}));