import { FullProvider } from "@/modules/categories/types/category.dto";
import { ServiceProvider } from "../types/provider.dto";

export const normalizeProvider = (provider: ServiceProvider): FullProvider => ({
  id: provider.provider.id,
  first_name: provider.provider.first_name,
  last_name: provider.provider.last_name,
  user_type: provider.provider.user_type,
  is_verified:
    provider.provider.is_phone_verified && provider.provider.is_email_verified,
  available_status: provider.provider.available_status,
  profile_picture: provider.provider.profile_picture ?? "",
  profile_card: provider.provider.picture_card ?? "",
  service_details: provider.services_list.map((service) => ({
    id: service.id,
    service_name: service.service_name,
    pricing_type: service.pricing_type,
    price: service.price,
  })),
  service_category: provider.service_category,
  location_info: {
    state: provider.business_location.state,
    city: provider.business_location.city,
    area: provider.business_location.area,
    longitude: provider.business_location.longitude,
    latitude: provider.business_location.latitude,
  },
  service_area: [],
  rating: null, // API doesn't return this yet
});

export const normalizeProviders = (
  providers: ServiceProvider[],
): FullProvider[] => providers.map(normalizeProvider);
