import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { FullProvider } from "@/modules/categories/types/category.dto";
import { Arrow, CustomText } from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { router } from "expo-router";
import {
  Animated,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { ProviderCard, ProviderCardSkeleton } from "../components";

interface TopProvidersProps {
  title?: string;
  data: FullProvider[];
  isLoading: boolean;
  showLink?: boolean;
  handleBookNow: () => void;
  type?: "top_providers" | "near_me"
}

const TopProviders = ({
  title = "Top Providers",
  data,
  showLink = true,
  isLoading,
  handleBookNow,
  type="top_providers",
}: TopProvidersProps) => {
  const {
    rotate,
    setShowContent,
    contentHeight,
    setContentHeight,
    animatedHeight,
  } = useExpandableAnimation();

  const toggle = () => {
    setShowContent((prev) => !prev);
  };

  return (
    <View style={styles.container}>
      <View style={styles.heading}>
        {(<Pressable
          onPress={() => router.push(`/(customer)/providers?preference=${type}`)}
        >
          <View style={styles.headingText}>
            <CustomText size="sm" weight="semibold">
              {title}
            </CustomText>
            {showLink && <Arrow direction="right" size={18} color={PALETTE.black} />}
          </View>
        </Pressable>)}

        <Pressable
          onPress={toggle}
          style={[CUSTOM_STYLES.toggleButton, CUSTOM_STYLES.center]}
          hitSlop={12}
        >
          <Animated.View
            style={[
              CUSTOM_STYLES.toggleButton,
              CUSTOM_STYLES.center,
              {
                transform: [{ rotate }],
              },
            ]}
          >
            <Arrow direction={"bottom"} color={PALETTE.primary} size={18} />
          </Animated.View>
        </Pressable>
      </View>
      <Animated.View
        style={[
          {
            height: animatedHeight,
            overflow: "hidden",
          },
        ]}
      >
        <View
          onLayout={(event) => {
            const height = event.nativeEvent.layout.height;

            if (height > 0 && height !== contentHeight) {
              setContentHeight(height + 20);
            }
          }}
          style={{
            position: "absolute",
            width: "100%",
            marginTop: 17,
            paddingBottom: 20,
          }}
        >
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 20, paddingHorizontal: 20 }}
          >
            {isLoading
              ?  (
                <View style={[CUSTOM_STYLES.row, { gap: 20 }]}>
                  {Array.from({ length: 3 }).map((_, index) => (
                    <ProviderCardSkeleton key={index} />
                  ))}
                </View>
              ) : data &&
                data.map((provider) => (
                  <ProviderCard
                    key={provider.id}
                    item={provider}
                    handleBookNow={handleBookNow}
                  />
                ))}
          </ScrollView>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},
  heading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
  },
  headingText: { flexDirection: "row", alignItems: "center", gap: 2 },
});

export default TopProviders;
