import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { FullProvider } from "@/modules/categories/types/category.dto";
import { Arrow, CustomText } from "@/shared/components";
import { useState } from "react";
import { LayoutAnimation, Pressable, StyleSheet, View } from "react-native";
import { ProviderCardV2, ProviderCardV2Skeleton } from "../components";

interface TopProvidersProps {
  title?: string;
  data: FullProvider[];
  isLoading: boolean;
  handleBookNow: () => void;
}

const AllProviders = ({
  title = "All Providers",
  data,
  isLoading,
  handleBookNow,
}: TopProvidersProps) => {
  const [showContent, setShowContent] = useState<boolean>(true);

  const toggle = () => {
    LayoutAnimation.configureNext({
      duration: 300,
      update: { type: "easeInEaseOut" },
      delete: { type: "easeInEaseOut", property: "opacity" },
      create: { type: "easeInEaseOut", property: "opacity" },
    });
    setShowContent((prev) => !prev);
  };

  return (
    <View style={styles.container}>
      <View style={styles.heading}>
        <CustomText size="sm" weight="semibold">
          {title}
        </CustomText>

        <Pressable
          onPress={toggle}
          style={[CUSTOM_STYLES.toggleButton, CUSTOM_STYLES.center]}
          hitSlop={12}
        >
          <Arrow
            direction={showContent ? "top" : "bottom"}
            color={PALETTE.primary}
            size={18}
          />
        </Pressable>
      </View>

      {showContent && (
        <View style={{ gap: 20, paddingHorizontal: 20 }}>
          {isLoading
            ? [1, 2, 3].map((_, index) => (
                <ProviderCardV2Skeleton key={index} />
              ))
            : data &&
              data.map((provider) => (
                <ProviderCardV2
                  key={provider.id}
                  item={provider}
                  handleBookNow={handleBookNow}
                />
              ))}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 17,
  },
  heading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
  },
});

export default AllProviders;
