import { avatars } from "@/constants/avatars";
import { PALETTE } from "@/constants/colors";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useUIStore } from "@/shared/store/uiStore";
import { ProviderFilter } from "@/modules/provider/components";
import {
  CustomSearchInput,
  CustomText,
  Location,
  UserAvatar,
} from "@/shared/components";
import Octicons from "@expo/vector-icons/Octicons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { useEffect, useRef } from "react";
import { Animated, Platform, Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CUSTOM_STYLES } from "@/constants/styles";

interface HeaderProps {
  search: string;
  isFocused: boolean;
  setSearch: (text: string) => void;
  setIsFocused: (focused: boolean) => void;
  notificationCount: number;
}

const Header = ({
  search,
  isFocused,
  setSearch,
  setIsFocused,
  notificationCount,
}: HeaderProps) => {
  const { isLocationPopupOpen } = useUIStore();
  const { user } = useAuthStore();
  const insets = useSafeAreaInsets();
  const filterOpacity = useRef(new Animated.Value(1)).current;
  const filterWidth = useRef(new Animated.Value(1)).current;

  // filter hide/show animation when focused
  useEffect(() => {
    Animated.parallel([
      Animated.timing(filterOpacity, {
        toValue: isFocused ? 0 : 1,
        duration: 200,
        useNativeDriver: false,
      }),
      Animated.timing(filterWidth, {
        toValue: isFocused ? 0 : 1,
        duration: 200,
        useNativeDriver: false,
      }),
    ]).start();
  }, [isFocused]);

  const filterMaxWidth = filterWidth.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 60],
  });

  const goToNotification = () => {
    router.push("/(customer)/notifications");
  };

  return (
    <>
      <Location />
      <View
        style={[
          { backgroundColor: PALETTE.white },
          isLocationPopupOpen && styles.roundedCorners,
        ]}
      >
        <LinearGradient
          colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={[
            styles.container,
            isLocationPopupOpen && styles.roundedCorners,
            !isLocationPopupOpen && { paddingTop: insets.top },
            Platform.OS === "android" && { backgroundColor: PALETTE.white },
          ]}
        >
          <View style={[styles.row, styles.heading]}>
            <UserAvatar
              name={`${user?.firstName} ${user?.lastName}`}
              source={
                avatars.find((avatar) => avatar.id === user?.avatarId)?.url ??
                avatars[0].url
              }
              url={user?.profilePicture}
            />
            <Pressable onPress={goToNotification} style={styles.notificationButton}>
              <Octicons name="bell" size={20} color={PALETTE.black} />
              {notificationCount > 0 && (
                <View style={[styles.notificationCount, styles.count, CUSTOM_STYLES.center]}>
                  <CustomText size="sm" style={{ color: PALETTE.white}}>
                    {notificationCount > 9 ? "9+" : notificationCount}
                  </CustomText>
                </View>
              )}
            </Pressable>
          </View>

          <View style={styles.content}>
            <View style={styles.textContent}>
              <CustomText size="sm" weight="semibold" style={styles.title}>
                Hello {user?.firstName} 👋
              </CustomText>
              <CustomText size="xxl" weight="bold" style={styles.description}>
                Explore services near you with ease
              </CustomText>
            </View>
            {/* Search — always visible */}
            <View style={styles.searchBox}>
              <CustomSearchInput
                value={search}
                placeholder="Search for service providers"
                onChange={setSearch}
                isFocused={isFocused}
                setIsFocused={setIsFocused}
              />
              <Animated.View
                style={{
                  maxWidth: filterMaxWidth,
                  opacity: filterOpacity,
                  overflow: "hidden",
                }}
              >
                <ProviderFilter />
              </Animated.View>
            </View>
          </View>
        </LinearGradient>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  roundedCorners: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    // elevation: 1,
    zIndex: 1,
  },
  heading: {
    marginTop: 32,
  },
  content: {
    marginTop: 58,
    gap: 30,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  notificationButton: {
    width: 48,
    height: 48,
    borderRadius: 53,
    backgroundColor: PALETTE.white,
    alignItems: "center",
    justifyContent: "center",
    position: "relative"
  },
  notificationCount: {
    position: "absolute",
    top: -4,
    right: 0,
  },
  count: {
    backgroundColor: PALETTE.error,
    width: 20,
    height: 20,
    borderRadius: 40,
  },
  textContent: {
    gap: 8,
    width: 297,
  },
  title: {
    textTransform: "uppercase",
    opacity: 0.5,
  },
  description: {
    lineHeight: 37,
  },
  searchSection: {
    gap: 10,
    marginTop: 16,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
});

export default Header;
