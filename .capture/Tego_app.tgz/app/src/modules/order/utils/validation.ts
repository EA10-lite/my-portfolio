import * as yup from "yup";

export const reviewValidationSchema = yup.object({
  rating: yup
    .number()
    .typeError("Please select a rating")
    .required("Rating is required")
    .min(1, "Please select a rating")
    .max(5, "Rating cannot be more than 5")
    .integer("Rating must be a whole number"),

  exception: yup
    .string()
    .trim()
    .max(500, "Exception must not exceed 500 characters"),

  review_text: yup
    .string()
    .trim()
    .required("Please write a review")
    .min(10, "Review must be at least 10 characters")
    .max(1000, "Review must not exceed 1000 characters")
    .test(
      "not-only-spaces",
      "Review cannot contain only spaces",
      (value) => !!value?.trim()
    ),
});