// modules/order/utils/normalizeOrder.ts
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import { NormalizedOrderDetail } from "../types/order.dto";

export const normalizeRequest = (data: any): NormalizedOrderDetail => ({
  id: data.id,
  type: "Request",
  status: data.status?.toLowerCase() ?? "pending",
  title: data.title,
  location: `${data.address}, ${data.state}, ${data.country}`,
  activities: data.activities ?? [],
  offers: [],
  details: {
    budget:
      data.start_price && data.end_price
        ? `${formatCurrency(data.start_price)} - ${formatCurrency(data.end_price)}`
        : undefined,
    address: `${data.address}, ${data.state}`,
    images: data.images ?? [],
    note: data.description,
    date: data.date ? formatDateTime(data.date) : undefined,
    urgency: data.urgency,
    category: data.service_category?.name,
    provider: {
      ...data.provider,
      name: `${data.provider.first_name} ${data.provider.last_name}`
    },
    user: data.user,
  },
});

export const normalizeBooking = (data: any): NormalizedOrderDetail => ({
  id: data.id,
  type: "Booking",
  status: data.status?.toLowerCase() ?? "pending",
  title: data.service_list_item?.service_name ?? "Booking",
  location: `${data.address?.address}, ${data.address?.state}, ${data.address?.country}`,
  activities: data.activities ?? [],
  offers: [],
  details: {
    budget: data?.price
      ? formatCurrency(data.price)
      : data?.quote_price
        ? formatCurrency(data?.quote_price)
        : undefined,
    address: `${data.address?.address}, ${data.address?.state}`,
    images: data.images ?? [],
    note: data.note,
    date: data.date ? formatDateTime(data.date) : undefined,
    urgency: data.urgency,
    provider: {
      ...data.provider,
      name: `${data.provider.first_name} ${data.provider.last_name}`
    },
    user: data.user,
  }
});

export const normalizeOrderDetails = (data: any): NormalizedOrderDetail => {
  const source = data.book_service ?? data.job_request ?? data?.invite ?? {};
  const isBooking = !!data.book_service;
  const isInvite = !!data.invite;

  const address =
    isBooking
      ? `${source.address?.address ?? ""}, ${source.address?.state ?? ""}`
      : isInvite
        ? `${source.address.address}, ${source.address.state}`
        : `${source.address}, ${source.state}`;

  const budget =
    isBooking
      ? source.service_list_item?.price
        ? formatCurrency(source.service_list_item.price)
        : undefined
      : isInvite
        ? formatCurrency(source.price)
        : source.start_price && source.end_price
          ? `${formatCurrency(source.start_price)} - ${formatCurrency(source.end_price)}`
          : undefined;

  return {
    id: data.id,
    type: "Order",
    status: data.status?.toLowerCase() ?? "pending",
    cancellation_requested_by: data.cancellation_requested_by,
    cancellation_requested_by_user_id: data.cancellation_requested_by_user_id,
    title:
      source.title ??
      source.service_list_item?.service_name ??
      data?.title,
    location: isBooking || isInvite
      ? `${source.address?.address ?? ""}, ${source.address?.state ?? ""}, ${source.address?.country ?? ""}`
      : `${source.address ?? ""}, ${source.state ?? ""}, ${source.country ?? ""}`,
    activities: data.activities ?? [],
    offers: data.offer ? [data.offer] : [],
    details: {
      budget,
      address,
      images: source.images ?? [],
      note: source.note ?? source.description,
      date: source.date ? formatDateTime(source.date) : undefined,
      urgency: source.urgency,
      provider: data.provider,
      user: data.user,
    },
  };
};
