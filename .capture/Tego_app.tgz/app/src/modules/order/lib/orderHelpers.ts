// lib/orderHelpers.ts
import { Order } from "../types/order.dto";

export const getProcessedOrder = (order: Order) => {
  // The API may return service_list_item at the order level OR nested
  // inside job_request / book_service. Resolve once and reuse.
  const serviceListItem =
    order.service_list_item ||
    order.job_request?.service_list_item ||
    order.book_service?.service_list_item ||
    null;

  return {
    title:
      order.title ||
      order.job_request?.title ||
      order.book_service?.title ||
      "",
    address:
      order.book_service?.address.address ||
      order.job_request?.address ||
      order.invite?.address.address ||
      "",
    user: order.user,
    status: order.status,
    date:
      order.job_request?.date ||
      order.book_service?.date ||
      order.invite.date,
    images: order.job_request?.images || order.book_service?.images || [],
    start_price: order.job_request?.start_price,
    end_price: order.job_request?.end_price,
    budget:
      order.invite
        ? order.invite.price
        : order.offer?.offer
          ? order.offer.offer.price
          : serviceListItem?.pricing_type === "FIXED"
            ? serviceListItem.price
            : 0,
    service:
      order.job_request?.service_category.name
        ? order.job_request?.service_category.name
        : order?.invite?.service_category?.name
          ? order.invite.service_category.name : serviceListItem?.service_name
  };
};

// statuses considered "active" for tab filtering
const ACTIVE_STATUSES: Order["status"][] = ["PENDING", "IN_PROGRESS"];

export const matchesStatusTab = (status: Order["status"], tab: string) => {
  if (tab === "all") return true;
  if (tab === "active") return ACTIVE_STATUSES.includes(status);
  return status.toLowerCase() === tab.toLowerCase();
};
