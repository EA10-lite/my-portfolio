// lib/normalizeOrders.ts
import {
  BookingOrder,
  JobRequest,
  NormalizedOrder,
  Order,
} from "../types/order.dto";
const formatAddress = (address: {
  address: string;
  state: string;
  country: string;
}) => `${address.address}, ${address.state}, ${address.country}`;

export const normalizeOrder = (order: Order): NormalizedOrder => {
  const isJobBased = !!order.job_request;

  const title =
    isJobBased && order.job_request?.title
      ? order.job_request.title
      : order.book_service?.title
        ? order.book_service.title
        : order.invite
          ? order.invite.service_name
          : "Order";

  return {
    id: order.id,
    title,
    category: order.category.name ?? "",
    type: "Order",
    status: order.status,
    date:
      order.book_service?.date ?? order.job_request?.date ?? order.created_at,
    time: order.book_service?.time,
    location:
      order.book_service
        ? formatAddress(order.book_service.address)
        : order.job_request
          ? `${order.job_request.area}, ${order.job_request.state}, ${order.job_request.country}`
          : order.invite
            ? formatAddress(order.invite.address)
            : "—",
    createdAt: order.created_at,
    source: "order",
  };
};

export const normalizeBooking = (booking: BookingOrder): NormalizedOrder => ({
  id: booking.id,
  title: booking?.title || booking?.service_list_item?.service_name,
  category: booking?.service_list_item?.service_name,
  type: "Booking",
  status: booking.status,
  date: booking.date,
  time: booking.time,
  location: formatAddress(booking.address),
  createdAt: booking.created_at,
  source: "booking",
});

export const normalizeJobRequest = (job: JobRequest): NormalizedOrder => ({
  id: job.id,
  title: job.title || job.service_list_item?.service_name,
  category: job?.service_list_item?.service_name || job?.service_category?.name,
  type: "Request",
  status: job.status,
  date: job.date,
  location: `${job.area}, ${job.state}, ${job.country}`,
  createdAt: job.created_at,
  source: "job_request",
});
