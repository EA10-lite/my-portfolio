import { api } from "@/shared/lib/api";
import {
  MyOrdersResponse,
  ORDER_STATUS,
  OrderDetails,
  ProviderOrdersResponse,
} from "../types/order.dto";

export interface ReviewData {
  exception: string;
  rating: number;
  review_text: string;
}

export const orderService = {
  getMyOrders: async (
    page: number = 1,
    limit: number = 10,
    status?: string,
  ) => {
    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
    });
    if (status && status !== "all") params.append("status", status);

    const response = await api.get<MyOrdersResponse>(
      `/orders/my-orders?${params.toString()}`,
    );
    return response.data;
  },
  getProviderOrders: async (
    page: number = 1,
    limit: number = 10,
    status?: string,
  ) => {
    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
    });
    if (status && status !== "all") params.append("status", status);

    const response = await api.get<ProviderOrdersResponse>(
      `/orders/provider-orders?${params.toString()}`,
    );
    return response.data;
  },
  getOrderDetails: async (order_id: string) => {
    const response = await api.get<OrderDetails>(`/orders/${order_id}`);
    return response.data;
  },
  update: async (order_id: string, status: ORDER_STATUS) => {
    const response = await api.patch(`/orders/${order_id}/status`, {
      status,
    });
    return response.data;
  },
  rejectCancellation: async (order_id: string) => {
    const response = await api.post(`/orders/${order_id}/reject-cancellation`);
    return response.data;
  },
  createReview: async (order_id: string, data: ReviewData) => {
    const response = await api.post(`/orders/${order_id}/review`, data);
    return response.data;
  }
};
