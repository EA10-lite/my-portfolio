import { Pagination, URGENCY } from "@/constants/types";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import { ProviderStat } from "@/modules/booking/store/booking.store";

export type ORDER_STATUS =
  | "PENDING"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "COMPLETION_REQUESTED"
  | "CANCELLATION_REQUESTED"
  | "CANCELLED";

export type OFFER_STATUS = "PENDING" | "ACCEPTED" | "REJECTED" | "CANCELLED";

export type MESSAGE_DELIVERY_STATUS = "SENT" | "DELIVERED" | "READ";

interface User {
  id: string;
  first_name: string;
  last_name: string;
  user_type: "CUSTOMER" | "SERVICE_PROVIDER";
  profile_picture?: string;
  average_rating: null | number;
}

interface ProviderDetails {
  id: string;
  name: string;
  profile_picture: null,
  availability_status: AvailabilityStatus
  location: null,
  rating: number;
  jobs_done: number;
  repeat_clients:number;
  is_verified: boolean;
  services: {
    id: string;
    service_name: string;
  }[]
}

interface Service {
  id: string;
  service_name: string;
  pricing_type: "FIXED" | "REQUEST_QOUTE";
  price: number;
}

interface Address {
  state: string;
  address: string;
  country: string;
}

interface BookService {
  title: string;
  note: string;
  id: string;
  date: string;
  time: string;
  images: string[];
  service_category: ServiceCategory;
  service_list_item: Service;
  address: Address;
  urgency: URGENCY;
}

interface OfferDetails {
  price: number;
  proposal: string;
  timeline: string;
  availability: string;
}

export interface Offer {
  id: string;
  sender: User;
  receiver: User;
  content_type: "OFFER";
  message: string;
  media: string[];
  offer: OfferDetails;
  status: OFFER_STATUS;
  message_delivery_status: MESSAGE_DELIVERY_STATUS;
  created_at: string;
  updated_at: string;
}

interface ServiceCategory {
  id: string;
  name: string;
}

export interface JobRequest {
  id: string;
  user: User;
  provider: User | null;
  service_category_id: string;
  service_category: ServiceCategory;
  service_list_item: Service;
  title: string;
  description: string;
  date: string;
  address: string;
  state: string;
  country: string;
  area: string;
  start_price: number;
  end_price: number;
  is_budget_negotiable: boolean;
  urgency: URGENCY;
  status: ORDER_STATUS;
  is_cancelled: boolean;
  created_at: string;
  images: string[];
}

export interface BookingInvite  {
  message_id: string;
  service_list_item_id: string;
  service_name: string;
  pricing_type: "REQUEST_QUOTE" | "FIXED";
  price: number;
  service_category: ServiceCategory;
  date: string;
  time: string;
  address: {
    state: string;
    address: string;
    country: string;
  };
  note: string;
  urgency: URGENCY;
  status: string;
}

export interface Order {
  id: string;
  user: User;
  provider: User;
  category: {
    id: string;
    name: string;
  }
  title?: string;
  service_list_item?: Service;
  job_request: JobRequest | null;
  book_service: BookService | null;
  offer: Offer | null;
  status: ORDER_STATUS;
  invite: BookingInvite;
  created_at: string;
  updated_at: string;
}

export interface BookingOrder {
  id: string;
  user: User;
  provider: User;
  service_list_item: Service;
  urgency: URGENCY;
  title: string;
  date: string;
  time: string;
  status: ORDER_STATUS;
  address: Address;
  created_at: string;
  images: string[];
}

export interface MyOrdersResponse extends Pagination {
  orders: Order[];
  active_bookings: BookingOrder[];
  active_job_requests: JobRequest[];
}

export interface ProviderOrdersResponse extends Pagination {
  orders: Order[];
}

// types/order.dto.ts — add this
export type MERGED_ORDER_TYPE = "Booking" | "Request" | "Order";

export interface NormalizedOrder {
  id: string;
  title: string;
  category: string;
  type: MERGED_ORDER_TYPE;
  status: ORDER_STATUS;
  date: string;
  time?: string;
  location: string;
  createdAt: string;
  source: "order" | "booking" | "job_request" | "invite";
}

export interface OrderDetails {
  id: string;
  title: string;
  category: ServiceCategory;
  service_category_item: Service;
  user: User;
  provider: ProviderDetails,
  job_request: JobRequest,
  book_service: BookService,
  offer: Offer,
  invite: BookingInvite;
  status: string;
  created_at: string;
  updated_at: string;
  cancellation_requested_by: string;
  cancellation_requested_by_user_id: string;
}

// modules/order/types/order.dto.ts
export interface NormalizedOrderDetail {
  id: string;
  type: "Booking" | "Request" | "Order";
  status: string;
  cancellation_requested_by?: string;
  cancellation_requested_by_user_id?: string;
  title: string;
  location: string;
  activities: {
    message: string;
    date_time: string;
    activity_type: string;
  }[];
  offers: any[];
  details: {
    budget?: string;
    address: string;
    images: string[];
    note?: string;
    date?: string;
    urgency?: string;
    category?: string;
    provider?: ProviderStat;
    user?: User;
    timeline?: string;
  };
}
