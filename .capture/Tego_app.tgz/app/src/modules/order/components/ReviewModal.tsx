import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { ProviderHeader } from "@/modules/provider/components";
import {
  BottomSheetTextbox,
  CustomButton,
  CustomText,
} from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import AntDesign from "@expo/vector-icons/AntDesign";
import Octicons from "@expo/vector-icons/Octicons";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { Formik } from "formik";
import { forwardRef, useCallback, useMemo } from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FullWindowOverlay } from "react-native-screens";
import { ReviewData } from "../services/order.service";
import { reviewValidationSchema } from "../utils/validation";

interface ProviderProfileModalProps {
  closeModal: () => void;
  handleSubmit: (data: ReviewData) => void;
  loading: boolean;
  user: {
    name: string;
    avatar: string;
    is_verified: boolean;
    address: string;
  };
}

const ReviewModal = forwardRef<BottomSheetModal, ProviderProfileModalProps>(
  ({ closeModal, handleSubmit, loading, user }, ref) => {
    const { bottom } = useSafeAreaInsets();
    const { height: screenHeight } = useWindowDimensions();

    // Pixel-based snap is device-accurate; 92% fits all content on any screen
    const snapPoints = useMemo(() => [screenHeight * 0.92], [screenHeight]);

    const handleSheetChanges = useCallback(
      (index: number) => {
        if (index === -1) closeModal?.();
      },
      [closeModal],
    );

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="close"
        />
      ),
      [],
    );

    return (
      <BottomSheetModal
        ref={ref}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}
        keyboardBehavior="fillParent"
        keyboardBlurBehavior="restore"
        android_keyboardInputMode="adjustResize"
        containerComponent={(props) =>
          Platform.OS === "ios" ? (
            <FullWindowOverlay>{props.children}</FullWindowOverlay>
          ) : (
            <>{props.children}</>
          )
        }
        backgroundStyle={styles.container}
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/*
          BottomSheetScrollView is now the DIRECT child of the modal —
          no BottomSheetView wrapper. This is what enables scroll gestures
          to integrate with the sheet's pan gesture correctly.
          stickyHeaderIndices pins the header at index 0 so it never scrolls away.
        */}
        <BottomSheetScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          stickyHeaderIndices={[0]}
          contentContainerStyle={{ paddingBottom: Math.max(bottom, 20) }}
        >
          {/* ─── index 0: sticky header ─── */}
          {/*
            The outer View provides an opaque white background so content
            sliding under the sticky header doesn't bleed through the
            semi-transparent gradient.
          */}
          <View style={styles.stickyHeaderWrapper}>
            <LinearGradient
              colors={[
                "rgba(51, 171, 247, 0.232)",
                "rgba(255, 255, 255, 0.255)",
              ]}
              locations={[0, 1]}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={styles.header}
            >
              <View style={styles.dragWrapper}>
                <View style={styles.dragHandle} />
              </View>
              <Pressable
                style={[styles.closeButton, CUSTOM_STYLES.center]}
                onPress={closeModal}
                hitSlop={12}
              >
                <AntDesign name="close" size={12} />
              </Pressable>
              <View style={{ paddingTop: 47 }}>
                <ProviderHeader
                  provider={{
                    user: {
                      name: user.name,
                      avatar: user.avatar,
                      isVerified: user.is_verified,
                    },
                    location: user.address,
                  }}
                />
              </View>
            </LinearGradient>
          </View>

          {/* ─── index 1+: scrollable content ─── */}
          <Formik
            initialValues={{ rating: 0, exception: "", review_text: "" }}
            onSubmit={handleSubmit}
            validationSchema={reviewValidationSchema}
          >
            {({ setFieldValue, values, handleSubmit }) => (
              <>
                <View style={styles.body}>
                  <View style={{ gap: 18 }}>
                    <CustomText weight="semibold" style={styles.groupTitle}>
                      What stood out?
                    </CustomText>
                    <View
                      style={[CUSTOM_STYLES.row, { gap: 12, flexWrap: "wrap" }]}
                    >
                      {[
                        "Fast Work",
                        "Neat & Tidy",
                        "Good Value",
                        "On Time",
                        "Professional",
                        "Great Comms",
                      ].map((item, index) => (
                        <TouchableOpacity
                          key={index}
                          style={[
                            styles.reviewType,
                            values["exception"] === item && styles.active,
                          ]}
                          onPress={() => setFieldValue("exception", item)}
                          hitSlop={{ top: 6, bottom: 6 }}
                        >
                          <CustomText
                            size="xs"
                            weight="medium"
                            style={{
                              color:
                                values["exception"] === item
                                  ? PALETTE.primary
                                  : hexToRgba(PALETTE.black, 0.7),
                              textAlign: "center",
                            }}
                          >
                            {item}
                          </CustomText>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>

                  <View style={CUSTOM_STYLES.divider} />

                  <View style={{ gap: 18 }}>
                    <CustomText weight="semibold" style={styles.groupTitle}>
                      How would you rate this job?
                    </CustomText>
                    <View style={styles.ratings}>
                      {Array.from({ length: 5 }).map((_, index) => {
                        const value = index + 1;
                        const isActive =
                          values["rating"] !== null &&
                          values["rating"] >= value;
                        return (
                          <Pressable
                            style={styles.rating}
                            key={index}
                            onPress={() => setFieldValue("rating", value)}
                            hitSlop={{ top: 4, bottom: 4 }}
                          >
                            <View
                              style={[
                                styles.rating,
                                CUSTOM_STYLES.center,
                                isActive
                                  ? styles.activeRating
                                  : styles.inactiveRating,
                              ]}
                            >
                              <Octicons
                                name="star-fill"
                                size={12}
                                color={
                                  isActive ? PALETTE.yellow : PALETTE.black40
                                }
                              />
                            </View>
                          </Pressable>
                        );
                      })}
                    </View>
                  </View>

                  <View style={CUSTOM_STYLES.divider} />

                  <BottomSheetTextbox
                    name="review_text"
                    placeholder="Review (Optional)"
                  />
                </View>

                <View style={styles.actionRow}>
                  <CustomButton
                    title="Post Review"
                    variant="primary"
                    onPress={handleSubmit}
                    disabled={
                      loading ||
                      !values.rating ||
                      !values.exception ||
                      !values.review_text
                    }
                  />
                </View>
              </>
            )}
          </Formik>
        </BottomSheetScrollView>
      </BottomSheetModal>
    );
  },
);
const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  sheetWrapper: {
    flex: 1,
    overflow: "hidden",
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },
  stickyHeaderWrapper: {
    backgroundColor: PALETTE.white, // opaque backing for sticky header
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
  },

  header: {
    paddingHorizontal: 20,
  },

  providerHeader: {
    paddingTop: 47,
  },

  scrollView: {
    flex: 1,
  },

  scrollContent: {
    flexGrow: 1,
  },

  body: {
    padding: 20,
    gap: 20,
  },

  section: {
    gap: 18,
  },

  groupTitle: {
    fontSize: 13,
  },

  reviewTypes: {
    ...CUSTOM_STYLES.row,
    gap: 12,
    flexWrap: "wrap",
  },

  reviewType: {
    backgroundColor: PALETTE.grey01,
    paddingVertical: 7.67,
    paddingHorizontal: 20,
    borderRadius: 50,
  },

  active: {
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.primary, 0.7),
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
  },

  ratings: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 10,
  },

  rating: {
    flex: 1,
    height: 40,
    borderRadius: 56,
  },

  activeRating: {
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.primary, 0.3),
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
  },

  inactiveRating: {
    backgroundColor: PALETTE.grey01,
  },

  actionRow: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 2,
    backgroundColor: PALETTE.white,
  },

  closeButton: {
    width: 24,
    height: 24,
    borderRadius: 50,
    backgroundColor: PALETTE.white,
    position: "absolute",
    right: 20,
    top: 32,
    zIndex: 10,
  },
});

export default ReviewModal;
