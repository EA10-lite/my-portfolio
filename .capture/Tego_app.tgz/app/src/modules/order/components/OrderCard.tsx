import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Arrow,
  CustomButton,
  CustomText,
  DetailsField,
} from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { formatDateAndTime } from "@/shared/utils/formatter";
import { Animated, Pressable, StyleSheet, View } from "react-native";

interface OrderProps {
  order: {
    title: string;
    category: string;
    type: string;
    status: string;
    date: string;
    location: string;
  };
  onCancel?: () => void;
  viewDetails: () => void;

  // Controlled by Orders
  isOpen: boolean;
  onToggle: () => void;
}

const OrderCard = ({
  order,
  onCancel,
  viewDetails,
  isOpen,
  onToggle,
}: OrderProps) => {
  const {
    showContent,
    setContentHeight,
    contentHeight,
    rotate,
    animatedHeight,
  } = useExpandableAnimation({ initialState: false, isOpen });

  return (
    <View style={[CUSTOM_STYLES.card]}>
      <Pressable onPress={onToggle} style={[styles.header]}>
        <View style={{ gap: 8, flex: 1 }}>
          <CustomText size="sm" weight="semibold">
            {order.title}
          </CustomText>
          <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
            <View style={styles.tag}>
              <CustomText weight="semibold" style={styles.tagText}>
                {order.category}
              </CustomText>
            </View>
            <View style={styles.tag}>
              <CustomText weight="semibold" style={styles.tagText}>
                {order.type}
              </CustomText>
            </View>
          </View>
        </View>
        <Animated.View
          style={[
            CUSTOM_STYLES.toggleButton,
            CUSTOM_STYLES.center,
            { transform: [{ rotate }] },
          ]}
        >
          <Arrow direction="bottom" color={PALETTE.primary} size={20} />
        </Animated.View>
      </Pressable>

      <Animated.View
        style={[
          styles.body,
          {
            height: animatedHeight,
            overflow: "hidden",
            borderWidth: showContent ? 1 : 0,
          },
        ]}
      >
        <View
          onLayout={(event) => {
            const height = event.nativeEvent.layout.height;

            if (height > 0 && height !== contentHeight) {
              setContentHeight(height);
            }
          }}
          style={{
            position: "absolute",
            width: "100%",
          }}
        >
          <DetailsField type="status" label="Status" value={order.status} />
          <DetailsField
            type="date"
            label="Date & Time"
            value={formatDateAndTime(order.date)}
          />
          <DetailsField
            type="address"
            label="Location"
            value={order.location}
          />
          <View style={[styles.buttons, CUSTOM_STYLES.row]}>
            {order.status.toLowerCase() !== "completed" &&
              order.status.toLowerCase() !== "cancelled" &&
              order.status.toLowerCase() !== "cancellation_requested" && (
                <CustomButton
                  title="Cancel"
                  variant="secondary"
                  style={CUSTOM_STYLES.flex}
                  onPress={onCancel}
                />
              )}
            <CustomButton
              title="View details"
              style={CUSTOM_STYLES.flex}
              onPress={viewDetails}
            />
          </View>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  tag: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 3,
    paddingHorizontal: 10.77,
    paddingVertical: 4,
  },
  tagText: {
    textTransform: "uppercase",
    fontSize: 11,
    opacity: 0.5,
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
  },
  buttons: {
    padding: 20,
    gap: 12,
  },
});

export default OrderCard;
