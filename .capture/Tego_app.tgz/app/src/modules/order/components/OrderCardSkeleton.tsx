// components/OrderCardSkeleton.tsx
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useEffect, useRef } from "react";
import { Animated, StyleSheet, View } from "react-native";

const OrderCardSkeleton = () => {
  const opacity = useRef(new Animated.Value(0.4)).current;

  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 1,
          duration: 700,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 0.4,
          duration: 700,
          useNativeDriver: true,
        }),
      ]),
    );
    pulse.start();
    return () => pulse.stop();
  }, [opacity]);

  return (
    <View style={[CUSTOM_STYLES.card, styles.header]}>
      <View style={{ gap: 8, flex: 1 }}>
        <Animated.View style={[styles.block, styles.title, { opacity }]} />
        <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
          <Animated.View style={[styles.block, styles.tag, { opacity }]} />
          <Animated.View style={[styles.block, styles.tag, { opacity }]} />
        </View>
      </View>
      <Animated.View style={[styles.block, styles.toggle, { opacity }]} />
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  block: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 4,
  },
  title: {
    height: 14,
    width: "70%",
  },
  tag: {
    height: 20,
    width: 64,
    borderRadius: 3,
  },
  toggle: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
});

export default OrderCardSkeleton;
