import { PALETTE } from "@/constants/colors";
import { CustomText, DetailsField, ImagePreview } from "@/shared/components";
import { formatDateTime } from "@/shared/utils/formatter";
import { StyleSheet, View } from "react-native";

interface ItemProps {
  images?: string[];
  note?: string;
  date?: string;
  address?: string;
  budget?: string;
  timeline?: string;
  category?: string;
  provider?: string;
  urgency?: string;
}

interface OverviewProps {
  item: ItemProps;
  title: string;
}

const Overview = ({ title, item }: OverviewProps) => {
  return (
    <View style={styles.container}>
      <View style={[styles.header]}>
        <CustomText size="sm" weight="semibold">
          {title}
        </CustomText>
      </View>
      <View style={styles.body}>
        <View style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}>
          {item.note && (
            <CustomText style={{ opacity: 0.6 }} size="sm" weight="medium">
              {item.note}
            </CustomText>
          )}
          {item.images && <ImagePreview images={item.images} />}
        </View>
        <View style={styles.detailsField}>
          {item.category && (
            <DetailsField
              type="category"
              label="Category"
              value={item.category}
            />
          )}
          {item.timeline && (
            <DetailsField type="date" label="Timeline" value={item.timeline} />
          )}
          {item.date && (
            <DetailsField
              type="date"
              label="Date & Time"
              value={formatDateTime(item.date) ?? ""}
            />
          )}
          {item.urgency && (
            <DetailsField type="urgency" label="Urgency" value={item.urgency} />
          )}
          {item.address && (
            <DetailsField type="address" label="Address" value={item.address} />
          )}
          {item.budget && (
            <DetailsField
              type="budget"
              label="Budget"
              value={item.budget ?? ""}
            />
          )}
          <DetailsField
            type="user"
            label="Provider"
            value={item.provider ?? ""}
            isLast
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  header: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  detailsField: {},
});

export default Overview;
