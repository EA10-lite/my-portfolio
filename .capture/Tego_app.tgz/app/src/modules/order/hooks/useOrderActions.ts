// hooks/useOrder.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { orderService, ReviewData } from "../services/order.service";
import { ORDER_STATUS } from "../types/order.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useOrderActions = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const invalidateOrders = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.order.mine });
    queryClient.invalidateQueries({ queryKey: queryKeys.order.provider });
    queryClient.invalidateQueries({ queryKey: queryKeys.order.detailPrefix });
  };

  const update = useMutation({
    mutationFn: ({ id, status }: { id: string; status: ORDER_STATUS }) =>
      orderService.update(id, status),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOrders,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });
  const cancelOrder = useMutation({
    mutationFn: ({ id }: { id: string; }) =>
      orderService.update(id, "CANCELLATION_REQUESTED"),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOrders,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });
  const approveCancellation = useMutation({
    mutationFn: ({ id } : { id: string }) =>
      orderService.update(id, "CANCELLED"),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOrders,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });
  const rejectCancellation = useMutation({
    mutationFn: ({ id }: { id: string; }) =>
      orderService.rejectCancellation(id),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOrders,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  const review = useMutation({
    mutationFn: ({ id, data }: { id: string; data: ReviewData }) =>
      orderService.createReview(id, data),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateOrders,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  return {
    update: update.mutate,
    review: review.mutate,
    rejectCancellation: rejectCancellation.mutate,
    approveCancellation: approveCancellation.mutate,
    cancelOrder: cancelOrder.mutate,
    errorMessage,
    isSubmitting:
      update.isPending ||
      rejectCancellation.isPending ||
      cancelOrder.isPending ||
      approveCancellation.isPending,
    isReviewing: review.isPending,
  };
};
