// hooks/useProviderOrders.ts
import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { orderService } from "../services/order.service";
import { Order } from "../types/order.dto";

export const useProviderOrders = (status?: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const ordersQuery = useInfiniteQuery({
    queryKey: queryKeys.order.providerWith(status),
    queryFn: ({ pageParam = 1 }) =>
      orderService.getProviderOrders(pageParam, 10, status),
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  const orders: Order[] = useMemo(
    () => ordersQuery.data?.pages.flatMap((page) => page.orders) ?? [],
    [ordersQuery.data],
  );

  return {
    orders,
    fetchNextPage: ordersQuery.fetchNextPage,
    hasNextPage: ordersQuery.hasNextPage,
    isFetchingNextPage: ordersQuery.isFetchingNextPage,
    isLoading: ordersQuery.isLoading,
    errorMessage,
    refetch: ordersQuery.refetch,
  };
};
