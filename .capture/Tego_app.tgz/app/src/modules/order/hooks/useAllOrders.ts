// hooks/useOrder.ts
import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import {
    normalizeBooking,
    normalizeJobRequest,
    normalizeOrder,
} from "../lib/normalizeOrders";
import { orderService } from "../services/order.service";

export const useAllOrders = (status?: string) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const ordersQuery = useInfiniteQuery({
    queryKey: queryKeys.order.mineWith(status),
    queryFn: ({ pageParam = 1 }) =>
      orderService.getMyOrders(pageParam, 10, status),
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  const mergedOrders = useMemo(() => {
    const pages = ordersQuery.data?.pages;
    if (!pages?.length) return [];

    const orders = pages.flatMap((page) => page.orders.map(normalizeOrder));

    // active_bookings / active_job_requests aren't paginated,
    // so only take them from the first page to avoid duplicates
    const first = pages[0];
    const bookings = first.active_bookings.map(normalizeBooking);
    const jobRequests = first.active_job_requests.map(normalizeJobRequest);

    return [...bookings, ...jobRequests, ...orders].sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
  }, [ordersQuery.data]);

  return {
    orders: mergedOrders,
    fetchNextPage: ordersQuery.fetchNextPage,
    hasNextPage: ordersQuery.hasNextPage,
    isFetchingNextPage: ordersQuery.isFetchingNextPage,
    isLoading: ordersQuery.isLoading,
    errorMessage,
    refetch: ordersQuery.refetch,
  };
};
