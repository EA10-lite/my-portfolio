import { queryKeys } from "@/constants/queryKeys";
import { bookingService } from "@/modules/booking/services/booking.service";
import { requestService } from "@/modules/requests/services/request.service";
import { useQuery } from "@tanstack/react-query";
import {
  normalizeBooking,
  normalizeOrderDetails,
  normalizeRequest,
} from "../lib/normalizeOrder";
import { orderService } from "../services/order.service";
import { NormalizedOrderDetail } from "../types/order.dto";

export const useOrder = (
  orderId: string,
  type?: "Booking" | "Request" | "Order",
) => {
  const order_details = useQuery({
    queryKey: queryKeys.order.detail(orderId, type),
    queryFn: async () => {
      if (type === "Booking") {
        const data = await bookingService.getBookingDetails(orderId);
        return normalizeBooking(data);
      } else if (type === "Request") {
        const data = await requestService.getRequestById(orderId);
        return normalizeRequest(data);
      } else {
        const data = await orderService.getOrderDetails(orderId);
        return normalizeOrderDetails(data);
      }
    },
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
    enabled: !!orderId,
  });

  return {
    order: order_details.data as NormalizedOrderDetail | undefined,
    isLoading: order_details.isLoading,
  };
};
