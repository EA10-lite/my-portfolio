import * as yup from "yup";

const phoneNumberField = yup
  .string()
  .required("Phone number is required")
  .trim()
  .matches(/^\+?[0-9]{8,15}$/, "Enter a valid phone number"); // E.164 max is 15 digits

const passwordField = yup
  .string()
  .required("Password is required")
  .min(8, "Password must be at least 8 characters")
  .max(64, "Password is too long") // prevent DoS via bcrypt long password attack
  .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
  .matches(/[a-z]/, "Password must contain at least one lowercase letter")
  .matches(/\d/, "Password must contain at least one number")
  .matches(
    /[^A-Za-z0-9]/,
    "Password must contain at least one special character",
  )
  .test(
    "no-spaces",
    "Password must not contain spaces",
    (value) => !/\s/.test(value ?? ""),
  );

const nameField = (label: string) =>
  yup
    .string()
    .required(`${label} is required`)
    .trim()
    .min(2, `${label} must be at least 2 characters`)
    .max(50, `${label} is too long`)
    .matches(/^[a-zA-Z\s'-]+$/, `${label} contains invalid characters`)
    .test(
      "no-script",
      `${label} contains invalid characters`,
      (value) => !/<|>|&|script/i.test(value ?? ""), // 👈 block script injection attempts
    );

const passwordRegex =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&.#_\-])[A-Za-z\d@$!%*?&.#_\-]{8,64}$/;

export const changePasswordValidationSchema = yup.object().shape({
  old_password: yup
    .string()
    .required("Old password is required")
    .min(8, "Password must be at least 8 characters")
    .max(64, "Password is too long")
    .trim(),

  new_password: yup
    .string()
    .required("New password is required")
    .matches(
      passwordRegex,
      "Password must contain uppercase, lowercase, number, and special character",
    )
    .notOneOf(
      [yup.ref("oldPassword")],
      "New password must be different from old password",
    )
    .trim(),

  confirm_password: yup
    .string()
    .required("Please confirm your password")
    .oneOf([yup.ref("new_password")], "Passwords do not match")
    .trim(),
});

export const reportIssueValidation = yup.object().shape({
  issueType: yup.string(),
  title: yup.string(),
  description: yup.string(),
  // images: []
});

export const editPersonalInformationValidation = yup.object().shape({
  firstName: nameField("firstName"),
  lastName: nameField("lastName"),
  phoneNumber: phoneNumberField,
});

export const reportIssueSchema = yup.object({
  issue_type: yup
    .string()
    .oneOf(
      ["APP_ISSUE", "CUSTOMER_ISSUE", "SUBSCRIPTION"],
      "Invalid issue type",
    )
    .required("Please select an issue type"),

  title: yup
    .string()
    .trim()
    .min(3, "Title must be at least 3 characters")
    .max(100, "Title must be at most 100 characters")
    .required("Title is required"),

  issue_description: yup
    .string()
    .trim()
    .min(10, "Description must be at least 10 characters")
    .max(500, "Description must be at most 500 characters")
    .required("Description is required"),

  images: yup.array().of(yup.string()).optional(),
});


export const addressSchema = yup.object({
  address: yup
    .string()
    .trim()
    .required("Address is required")
    .min(5, "Address must be at least 5 characters")
    .max(255, "Address must not exceed 255 characters"),

  street_name: yup
    .string()
    .trim()
    .required("Street name is required")
    .min(2, "Street name must be at least 2 characters")
    .max(150, "Street name must not exceed 150 characters"),

  nearby_landmark: yup
    .string()
    .trim()
    .required("Nearby landmark is required")
    .min(2, "Nearby landmark must be at least 2 characters")
    .max(150, "Nearby landmark must not exceed 150 characters"),

  city: yup
    .string()
    .trim()
    .required("City is required")
    .min(2, "City must be at least 2 characters")
    .max(100, "City must not exceed 100 characters"),

  state: yup
    .string()
    .trim()
    .required("State is required")
    .min(2, "State must be at least 2 characters")
    .max(100, "State must not exceed 100 characters"),

  country: yup
    .string()
    .trim()
    .required("Country is required")
    .min(2, "Country must be at least 2 characters")
    .max(100, "Country must not exceed 100 characters"),

  longitude: yup
    .number()
    .typeError("Longitude must be a number")
    .required("Longitude is required")
    .min(-180, "Longitude must be between -180 and 180")
    .max(180, "Longitude must be between -180 and 180")
    .test(
      "finite",
      "Longitude must be a valid number",
      (value) => value !== undefined && Number.isFinite(value),
    ),

  latitude: yup
    .number()
    .typeError("Latitude must be a number")
    .required("Latitude is required")
    .min(-90, "Latitude must be between -90 and 90")
    .max(90, "Latitude must be between -90 and 90")
    .test(
      "finite",
      "Latitude must be a valid number",
      (value) => value !== undefined && Number.isFinite(value),
    ),
});
