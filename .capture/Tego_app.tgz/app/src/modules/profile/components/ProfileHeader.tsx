import { CustomText, GoBack } from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ProfileHeader = ({ title = "Profile" }: { title: string }) => {
  const insets = useSafeAreaInsets();
  return (
    <LinearGradient
      colors={["rgba(51, 171, 247, 0.232)", "rgba(255, 255, 255, 0.255)"]}
      locations={[0, 1]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={[styles.header, { paddingTop: insets.top + 32 }]}
    >
      <GoBack />
      <CustomText weight="bold" size="lg">
        {title}
      </CustomText>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingBottom: 10,
    gap: 34,
  },
});
export default ProfileHeader;
