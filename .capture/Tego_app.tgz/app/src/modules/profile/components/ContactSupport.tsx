import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Message } from "@/modules/message/services/message.service";
import {
  BottomSheetInput,
  BottomSheetTextbox,
  CustomButton,
  CustomText,
  Select,
} from "@/shared/components";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { Formik } from "formik";
import { forwardRef, useCallback } from "react";
import { Platform, Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FullWindowOverlay } from "react-native-screens";

interface SupportMessage {
  message: string;
  category: string;
  title: string;
}

interface ContactSupportProps {
  closeModal: () => void;
  onPress: (data: Message) => void;
  receiver_id: string;
  loading: boolean;
}

const SUPPORT_CATEGORIES = [
  { label: "Booking Issue", value: "BOOKING" },
  { label: "Payment Issue", value: "PAYMENT" },
  { label: "Provider Complaint", value: "PROVIDER_COMPLAINT" },
  { label: "Subscription", value: "SUBSCRIPTION" },
  { label: "Verification", value: "VERIFICATION" },
  { label: "Service Issue", value: "SERVICE" },
  { label: "Account Issue", value: "ACCOUNT" },
  { label: "Other", value: "OTHER" },
];

const ContactSupport = forwardRef<BottomSheetModal, ContactSupportProps>(
  ({ closeModal, onPress, loading, receiver_id }, ref) => {
    const insets = useSafeAreaInsets();
    const handleSheetChanges = useCallback(
      (index: number) => {
        // closed
        if (index === -1) {
          closeModal?.();
        }
      },
      [closeModal],
    );

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="close"
        />
      ),
      [],
    );

    const handleSubmit = (values: SupportMessage) => {
      onPress({
        receiver_id,
        ticket: {
          category: values.category,
          title: values.title,
        },
        message_type: "TEXT",
        message: values.message,
      });
    };

    const isButtonDisabled = (values: SupportMessage) => {
      return !values.title || !values.category || !values.message;
    };

    return (
      <BottomSheetModal
        ref={ref}
        enableDynamicSizing
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}
        keyboardBehavior="fillParent"
        keyboardBlurBehavior="restore"
        android_keyboardInputMode="adjustResize"
        containerComponent={(props) =>
          Platform.OS === "ios" ? (
            <FullWindowOverlay>{props.children}</FullWindowOverlay>
          ) : (
            <>{props.children}</>
          )
        }
        backgroundStyle={styles.container}
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/* Sheet */}
        <BottomSheetView style={styles.sheetWrapper}>
          {/* Sheet */}
          <View style={[styles.sheet]}>
            <LinearGradient
              colors={[
                "rgba(51, 171, 247, 0.232)",
                "rgba(255, 255, 255, 0.255)",
              ]}
              locations={[0, 1]}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={styles.header}
            >
              {/* 👇 custom drag handle INSIDE gradient */}
              <View style={styles.dragWrapper}>
                <View style={styles.dragHandle} />
              </View>

              {/* Close button */}
              <Pressable
                style={[styles.closeButton, CUSTOM_STYLES.center]}
                onPress={closeModal}
                hitSlop={12}
              >
                <AntDesign name="close" size={12} />
              </Pressable>

              <View style={styles.textContent}>
                <CustomText size="sm" weight="semibold">
                  Send Message
                </CustomText>
              </View>
            </LinearGradient>

            <View style={styles.body}>
              <Formik<SupportMessage>
                initialValues={{
                  title: "",
                  category: "",
                  message: "",
                }}
                onSubmit={handleSubmit}
              >
                {({ handleSubmit, values }) => {
                  const disabled = isButtonDisabled(values);
                  return (
                    <View style={styles.container}>
                      <View style={CUSTOM_STYLES.inputs}>
                        <BottomSheetInput name="title" placeholder="Title" />
                        <Select
                          name="category"
                          placeholder="Categories"
                          options={SUPPORT_CATEGORIES}
                        />
                        <BottomSheetTextbox
                          name="message"
                          placeholder="Describe your issue"
                        />
                      </View>
                      <View
                        style={{
                          marginTop: 24,
                          paddingBottom: insets.bottom,
                        }}
                      >
                        <CustomButton
                          onPress={handleSubmit}
                          disabled={disabled}
                          variant={!disabled ? "primary" : "secondary"}
                          loading={loading}
                          title="Send"
                        />
                      </View>
                    </View>
                  );
                }}
              </Formik>
            </View>
          </View>
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  // ── Sheet ─────────────────────────────────────────
  sheetWrapper: {
    flex: 1,
    paddingTop: 0,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
    // justifyContent: "flex-end",
  },
  sheet: {
    gap: 16,
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 2,
    backgroundColor: PALETTE.white,
  },

  // ── Close button ──────────────────────────────────
  closeButton: {
    width: 24,
    height: 24,
    borderRadius: 50,
    backgroundColor: PALETTE.white,
    position: "absolute",
    right: 20,
    top: 32,
    zIndex: 10,
  },

  header: {
    paddingHorizontal: 20,
  },
  textContent: {
    gap: 6,
    paddingTop: 47,
  },
  body: {
    paddingHorizontal: 20,
    gap: 16,
  },

  // ── Actions ───────────────────────────────────────
  actionRow: {
    paddingHorizontal: 20,
    gap: 16,
    flexDirection: "row",
  },
  actionButton: {
    flex: 1,
  },
});

export default ContactSupport;
