import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText } from "@/shared/components";
import { StyleSheet, View } from "react-native";

interface SectionProps {
  title: string;
  subtitle?: string;
  description?: string | string[];
  list?: string[];
  listTitle?: string;
  listFooterText?: string;
}

const Section = ({
  title,
  subtitle,
  description,
  list,
  listFooterText,
  listTitle,
}: SectionProps) => {
  return (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <CustomText weight="semibold" style={styles.sectionTitle}>
          {title}
        </CustomText>
      </View>
      <View style={styles.sectionBody}>
        {subtitle && (
          <CustomText
            weight="semibold"
            size="xs"
            style={styles.sectionSubtitle}
          >
            {subtitle}
          </CustomText>
        )}
        {description &&
          (Array.isArray(description) ? (
            <View style={{ gap: 8 }}>
              {description.map((item, index) => (
                <CustomText
                  key={index}
                  weight="medium"
                  size="xs"
                  style={styles.sectionDescription}
                >
                  {item}
                </CustomText>
              ))}
            </View>
          ) : (
            <CustomText
              weight="medium"
              size="xs"
              style={styles.sectionDescription}
            >
              {description}
            </CustomText>
          ))}
        {list && list?.length > 0 && (
          <View
            style={{
              marginTop: description ? 8 : 0,
            }}
          >
            {listTitle && (
              <CustomText
                size="xs"
                weight="medium"
                style={styles.sectionDescription}
              >
                {listTitle}
              </CustomText>
            )}
            {list.map((item, index) => (
              <List key={index} item={item} />
            ))}
          </View>
        )}
      </View>
    </View>
  );
};

const List = ({ item }: { item: string }) => (
  <View style={[CUSTOM_STYLES.row, styles.listItem]}>
    <CustomText>•</CustomText>

    <CustomText style={styles.sectionDescription} size="xs" weight="medium">
      {item}
    </CustomText>
  </View>
);

const styles = StyleSheet.create({
  sections: {
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
  },
  section: {},
  sectionHeader: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 13,
  },
  sectionSubtitle: {
    lineHeight: 21,
    letterSpacing: -0.24,
  },
  sectionBody: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: PALETTE.white,
    gap: 4,
  },
  sectionDescription: {
    opacity: 0.7,
    lineHeight: 21,
    letterSpacing: -0.24,
  },
  listItem: { gap: 4, alignItems: "flex-start" },
});

export default Section;
