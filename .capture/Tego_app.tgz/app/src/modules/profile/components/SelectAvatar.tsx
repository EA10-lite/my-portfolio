import { avatars } from "@/constants/avatars";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { CustomText } from "@/shared/components";
import useFilePicker from "@/shared/hooks/useFilePicker";
import { uploadToCloudinary } from "@/shared/lib/cloudinary";
import AntDesign from "@expo/vector-icons/AntDesign";
import Ionicons from "@expo/vector-icons/Ionicons";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { forwardRef, useCallback } from "react";
import {
  Image,
  Pressable,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useProfileActions } from "../hooks/useProfileActions";

interface SelectAvatarProps {
  closeModal: () => void;
  onPress: () => void;
}

const SelectAvatar = forwardRef<BottomSheetModal, SelectAvatarProps>(
  ({ closeModal, onPress }, ref) => {
    const { bottom } = useSafeAreaInsets();
    const { uploadProfilePicture } = useProfileActions();
    const handleSheetChanges = useCallback(
      (index: number) => {
        // closed
        if (index === -1) {
          closeModal?.();
        }
      },
      [closeModal],
    );

    const { setUser, user } = useAuthStore();

    const handleSelect = (id: string) => {
      if (user) {
        setUser({
          ...user,
          avatarId: id,
          profilePicture: "",
        });
      }
    };

    const { pickImage } = useFilePicker({
      allowCrop: true,
      imagePickerOptions: {
        aspect: [1, 1],
        quality: 0.8,
      },
      onFilePicked: async (file) => {
        try {
          // 1. Update UI immediately with local URI
          if (user) {
            setUser({ ...user, profilePicture: file.uri });
          }

          // 2. Upload to cloudinary in background
          const { secure_url, public_id } = await uploadToCloudinary(file.uri, {
            folder: "tego/profile_pictures",
            publicIdToDelete: user?.avatarPublicId,
          });

          // 3. Send URL to backend
          uploadProfilePicture(secure_url, {
            onSuccess: (data) => {
              // 4. Update with real Cloudinary URL
              if (user) {
                setUser({ ...user, profilePicture: secure_url });
              }
              closeModal();
              onPress?.();
            },
            onError: (error) => {
              // Revert to previous picture on failure
              if (user) {
                setUser({ ...user, profilePicture: user.profilePicture });
              }
            },
          });
        } catch (error) {
          console.log("Upload error:", error);
          // Revert on cloudinary failure
          if (user) {
            setUser({ ...user, profilePicture: user.profilePicture });
          }
        }
      },
    });

    const chooseAvatar = () => pickImage();

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="close"
        />
      ),
      [],
    );

    return (
      <BottomSheetModal
        ref={ref}
        enableDynamicSizing
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}
        backgroundStyle={styles.container}
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/* Sheet */}
        <BottomSheetView style={styles.sheetWrapper}>
          {/* Sheet */}
          <View style={styles.sheetWrapper}>
            <View style={[styles.sheet, { paddingBottom: bottom }]}>
              <LinearGradient
                colors={[
                  "rgba(51, 171, 247, 0.232)",
                  "rgba(255, 255, 255, 0.255)",
                ]}
                locations={[0, 1]}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={styles.header}
              >
                {/* 👇 custom drag handle INSIDE gradient */}
                <View style={styles.dragWrapper}>
                  <View style={styles.dragHandle} />
                </View>

                <View
                  style={[
                    CUSTOM_STYLES.row,
                    { justifyContent: "space-between", paddingTop: 47 },
                  ]}
                >
                  <View style={styles.textContent}>
                    <CustomText size="md" weight="semibold">
                      Choose Avatar
                    </CustomText>
                  </View>
                  {/* Close button */}
                  <Pressable
                    style={[styles.closeButton, CUSTOM_STYLES.center]}
                    onPress={closeModal}
                    hitSlop={12}
                  >
                    <AntDesign name="close" size={12} />
                  </Pressable>
                </View>
              </LinearGradient>

              <View style={styles.body}>
                <View
                  style={[
                    CUSTOM_STYLES.row,
                    { justifyContent: "space-between", rowGap: 19 },
                  ]}
                >
                  {avatars.map((avatar, index) => (
                    <TouchableOpacity
                      key={index}
                      onPress={() => handleSelect(avatar.id)}
                      style={{ position: "relative" }}
                    >
                      <View
                        style={[
                          styles.avatar,
                          user?.avatarId === avatar.id && styles.activeAvatar,
                        ]}
                      >
                        <Image source={avatar.url} style={styles.image} />
                      </View>
                      {user?.avatarId === avatar.id && (
                        <View style={styles.selected}>
                          <Ionicons
                            name="checkmark-circle"
                            color={PALETTE.success}
                            size={21}
                          />
                        </View>
                      )}
                    </TouchableOpacity>
                  ))}
                  <TouchableOpacity
                    style={[CUSTOM_STYLES.center, styles.avatar, styles.select]}
                    onPress={chooseAvatar}
                  >
                    <AntDesign name="plus" size={24} color={PALETTE.primary} />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  // ── Sheet ─────────────────────────────────────────
  sheetWrapper: {
    flex: 1,
    paddingTop: 0,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
    // justifyContent: "flex-end",
  },
  sheet: {
    gap: 16,
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 2,
    backgroundColor: PALETTE.white,
  },

  // ── Close button ──────────────────────────────────
  closeButton: {
    width: 24,
    height: 24,
    borderRadius: 50,
    backgroundColor: PALETTE.white,
    zIndex: 10,
  },

  header: {
    paddingHorizontal: 20,
  },
  textContent: {
    gap: 6,
  },
  body: {
    paddingHorizontal: 20,
    marginTop: 24,
    gap: 16,
  },
  avatar: {
    width: 66,
    height: 66,
    borderRadius: 5000,
  },
  image: {
    width: "100%",
    height: "100%",
  },
  select: {
    backgroundColor: PALETTE.grey,
  },
  activeAvatar: {
    borderWidth: 1.32,
    borderColor: PALETTE.primary,
  },
  selected: {
    position: "absolute",
    top: 48.31,
    left: 42.38,
    zIndex: 10,
  },
});

export default SelectAvatar;
