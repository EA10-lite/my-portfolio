import { api } from "@/shared/lib/api";
import {
  AvailabilitySettings,
  BookingSettings,
  BookingSettingsResponse,
  BusinessLocationPayload,
  CreateServicePayload,
  GetBusinessLocation,
  GetCustomerBookingSettings,
  GetCustomerNotifications,
  GetDevices,
  GetServices,
  GetUserAddress,
  GetVerification,
  IssuePayload,
  LanguageSettings,
  NotificationSettings,
  ProviderNotificationSettings,
  ProviderVerification,
  UpdatePassword,
  UploadPictures,
  UserAddress,
  UserProfile
} from "../types/profile.dto";

export const settingsService = {
  profile: {
    getUserProfile: async () => {
      const response = await api.get(`/users/me`);
      return response.data;
    },
    getUserAddress: async () => {
      const response = await api.get<GetUserAddress>(
        `/users/user-details/address`,
      );
      return response.data;
    },
    updateUserProfile: async (data: UserProfile) => {
      const response = await api.patch(`/users/profile`, data);
      return response.data;
    },
    updateUserAddress: async (data: UserAddress) => {
      const response = await api.patch<GetUserAddress>(
        `/users/user-details/address`,
        data,
      );
      return response.data;
    },
    resetPassword: async (data: UpdatePassword) => {
      const response = await api.post(`/users/change-password`, data);
      return response.data;
    },
    uploadPictures: async (data: UploadPictures) => {
      const response = await api.patch(`/users/pictures`, data);
      return response.data;
    },
  },
  availability: {
    getAvailability: async () => {
      const response = await api.get(`/users/provider-settings/availability`);
      return response.data;
    },
    updateAvailability: async (data: AvailabilitySettings) => {
      const response = await api.patch(
        `/users/provider-settings/availability`,
        data,
      );
      return response.data;
    },
  },
  devices: {
    getDevices: async () => {
      const response = await api.get<GetDevices>(`/users/devices/`);
      return response.data;
    },
    flagDevice: async (deviceId: string) => {
      const response = await api.post(`/users/devices/${deviceId}/flag`, {
        reason: "Not my device",
      });
      return response.data;
    },
    unflagDevice: async (deviceId: string) => {
      const response = await api.post(`/users/devices/${deviceId}/unflag`);
      return response.data;
    },
    deleteDevice: async (deviceId: string) => {
      const response = await api.delete(`/users/devices/${deviceId}`);
      return response.data;
    },
  },
  location: {
    getBusinessLocation: async () => {
      const response = await api.get<GetBusinessLocation>(
        `/services/business-location`,
      );
      return response.data;
    },
    updateBusinessLocation: async (data: BusinessLocationPayload) => {
      const response = await api.patch(`/services/business-location`, {
        ...data,
        service_area: [data.service_area],
      });
      return response.data;
    },
  },
  notification: {
    getProviderNotification: async () => {
      const response = await api.get<ProviderNotificationSettings>(
        "/users/provider-settings/notifications",
      );
      return response.data;
    },
    getNotificationSettings: async () => {
      const response = await api.get<GetCustomerNotifications>(
        "/users/user-details/notifications",
      );
      return response.data;
    },
    getBookingSettings: async () => {
      const response = await api.get<GetCustomerBookingSettings>(
        "/users/user-details/bookings-settings",
      );
      return response.data;
    },
    updateProviderNotification: async (data: ProviderNotificationSettings) => {
      const response = await api.patch(
        "/users/provider-settings/notifications",
        data,
      );
      return response.data;
    },
    updateCustomerNotifications: async (data: NotificationSettings) => {
      const response = await api.patch(
        "/users/user-details/notifications",
        data,
      );
      return response.data;
    },
    updateBookingNotifications: async (data: BookingSettings) => {
      const response = await api.patch<BookingSettingsResponse>(
        "/users/user-details/bookings-settings",
        data,
      );
      return response.data;
    },
  },
  language: {
    getUserLanguage: async () => {
      const response = await api.get<LanguageSettings>(
        "/users/provider-settings/language",
      );
      return response.data;
    },
    updateUserLanguage: async (data: LanguageSettings) => {
      const response = await api.patch(
        "/users/provider-settings/language",
        data,
      );
      return response.data;
    },
  },
  services: {
    createService: async (data: CreateServicePayload) => {
      const response = await api.post("/services", data);
      return response.data;
    },
    getServices: async () => {
      const response = await api.get<GetServices>("/services/me");
      return response.data;
    },
    updateService: async (
      serviceId: string,
      data: {
        services_list: {
          id?: string;
          service_name: string;
          pricing_type: "FIXED" | "REQUEST_QUOTE";
          price: number;
        }[];
      },
    ) => {
      const items = {
        items: data.services_list,
      };
      console.log("ITEM: ", items);
      const response = await api.put(
        `/services/${serviceId}/service-items`,
        items,
      );
      return response.data;
    },
    getServiceCategories: async () => {
      const response = await api.get("/service-categories");
      return response.data;
    },
  },
  verification: {
    getVerification: async () => {
      const response = await api.get<GetVerification>(
        "/users/provider-verification",
      );
      return response.data;
    },
    updateVerification: async (data: ProviderVerification) => {
      const response = await api.patch(
        "/users/provider-verification/professional-document",
        data,
      );
      return response.data;
    },
  },
  supportSerice: {
    submitIssue: async (data: IssuePayload) => {
      const response = await api.post("/users/issues", data);
      return response.data;
    },
  },
};
