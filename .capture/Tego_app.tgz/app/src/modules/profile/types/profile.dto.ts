export interface UserProfile {
  first_name: string;
  last_name: string;
  phone_number: string;
  email: string;
}

export interface UserAddress {
  address: string;
  street_name: string;
  nearby_landmark: string;
  city: string;
  state: string;
  longitude: number;
  latitude: number;
  country: string;
}

export interface GetUserAddress {
  user_address: UserAddress;
}

export interface UploadPictures {
  profile_picture?: string;
  picture_card?: string;
}

export interface UpdatePassword {
  old_password: string;
  new_password: string;
}
export interface IssuePayload {
  issue_type: "APP_ISSUE" | "CUSTOMER_ISSUE" | "SUBSCRIPTION";
  title: string;
  issue_description: string;
  images: string[];
}

export interface AvailabilitySettings {
  available_status: "offline" | "busy" | "available_to_work";
  accept_instant_booking: boolean;
}

export interface BusinessLocationPayload {
  state: string;
  city: string;
  area: string;
  longitude: number;
  latitude: number;
  service_area: string;
}

export interface GetBusinessLocation {
  business_location: {
    area: string;
    city: string;
    latitude: null | number;
    longitude: null | number;
    state: "";
  };
  service_area: string[];
}

export interface ProviderNotificationSettings {
  bookings: {
    new_booking_request: boolean;
    booking_confirmations: boolean;
    booking_reminders: boolean;
  };
  job_posts: {
    nearby_services: boolean;
    new_categories: boolean;
  };
  review_n_ratings: {
    customers_review: boolean;
  };
  promotions_n_offers: {
    discount_n_special_deals: boolean;
  };
}

export interface LanguageSettings {
  language: "english_us" | "english_uk";
}

export interface GetServices {
  id: string;
  services_list: Service[];
  service_category?: {
    id: string;
    name: string;
  };
  service_category_id: string;
}
export interface Service {
  id: string;
  service_name: string;
  pricing_type: "FIXED" | "REQUEST_QUOTE";
  price: number;
}
export interface CategoryList {
  id: string;
  name: string;
  category_services: string[];
  created_at: string;
  updated_at: string;
}

export interface CreateServicePayload {
  service_category_id: string;
  services_list: Service[];
}

export interface ProviderVerification {
  nin: string;
  bvn: string;
  file_type: "pdf" | "image";
  file_url: string;
}

export interface GetDevice {
  device_id: string;
  device_ip: string;
  device_name: string;
  is_active: boolean;
  last_active_at: string;
  created_at: string;
  location: {
    country: string;
    state: string;
    area: string;
  };
}
export interface GetDevices {
  devices: GetDevice[];
}

export interface GetVerification {
  bvn: VerificationData;
  created_at: string;
  nin: VerificationData;
  professional_document: {
    file_type: "image" | "pdf";
    file_url: string;
  } | null;
  status: "PENDING" | "APPROVED" | "REJECTED"
  updated_at: string;
  submitted_at: string;
  reviewed_by: string;
  rejection_reason: string;
  user_id: string;
}

export interface VerificationData {
  is_verified: false;
  value: string;
  data: string;
  error: string;
  verified_at: string | null;
}
export interface BookingSettings {
  new_booking_request: boolean;
  booking_confirmations: boolean;
  booking_reminders: boolean;
  nearby_services: boolean;
  new_categories: boolean;
  service_started: boolean;
  booking_completed: boolean;
}

export interface BookingSettingsResponse {
  bookings_settings: BookingSettings;
}

export interface NotificationSettings {
  booking_updates: boolean;
  messages: boolean;
  promotions_n_offers: boolean;
}

export interface GetCustomerNotifications {
  notification_settings: NotificationSettings;
}

export interface GetCustomerBookingSettings {
  bookings_settings: BookingSettings;
}
