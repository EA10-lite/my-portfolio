// hooks/useProfile.ts
import { queryKeys } from "@/constants/queryKeys";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { settingsService } from "../services/settings.service";
import { UserProfile } from "../types/profile.dto";

export const useProfile = () => {
  const { setUser, user } = useAuthStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const query = useQuery({
    queryKey: queryKeys.profile.root,
    queryFn: settingsService.profile.getUserProfile,
    refetchInterval: 60_000,
    refetchOnWindowFocus: true,
  });

  // Sync auth store when profile data loads
  useEffect(() => {
    const data = query.data?.data ?? query.data;
    if (!data || !user) return;

    setUser({
      ...user,
      firstName: data.firstName ?? user.firstName,
      lastName: data.lastName ?? user.lastName,
      email: data.email ?? user.email,
      phoneNumber: data.phoneNumber ?? user.phoneNumber,
      profilePicture: data.profilePicture ?? user.profilePicture,
      pictureCard: data.pictureCard ?? user.pictureCard,
      userType: data.userType ?? user.userType,
      isEmailVerified: data.isEmailVerified ?? user.isEmailVerified,
      isPhoneVerified: data.isPhoneVerified ?? user.isPhoneVerified,
      provider_settings: data.provider_settings,
      is_onboarded: data.is_onboarded,
      onboarding_gaps: data.onboarding_gaps,
    });
  }, [query.data]);

  return {
    profile: query.data as UserProfile | undefined,
    isLoading: query.isLoading,
    errorMessage,
  };
};
