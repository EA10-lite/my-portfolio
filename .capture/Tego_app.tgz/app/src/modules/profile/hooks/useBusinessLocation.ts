// hooks/useBusinessLocation.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import {
  BusinessLocationPayload,
  GetBusinessLocation,
} from "../types/profile.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useBusinessLocation = () => {
  const { showToast } = useToastStore();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.profile.businessLocation,
    queryFn: settingsService.location.getBusinessLocation,
    refetchOnWindowFocus: true,
  });

  const update = useMutation({
    mutationFn: (data: BusinessLocationPayload) =>
      settingsService.location.updateBusinessLocation(data),
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.profile.businessLocation,
      }),
    onError: (error) => {
      showToast("Action Failed", "Failed to update business location")
    }
  });

  return {
    location: query.data as GetBusinessLocation | undefined,
    isLoading: query.isLoading,
    update: update.mutate,
    isUpdating: update.isPending,
  };
};
