// hooks/useProviderNotification.ts
import { queryKeys } from "@/constants/queryKeys";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import { BookingSettings, NotificationSettings } from "../types/profile.dto";

export const useNotificationSettings = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.notifications.customerSettings,
    queryFn: settingsService.notification.getNotificationSettings,
  });

  const bookingQuery = useQuery({
    queryKey: queryKeys.notifications.bookingSettings,
    queryFn: settingsService.notification.getBookingSettings,
  });

  const updateNotifications = useMutation({
    mutationFn: (data: NotificationSettings) =>
      settingsService.notification.updateCustomerNotifications(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      const currentUser = useAuthStore.getState().user;
      if (!currentUser || !currentUser.user_details) return;

      useAuthStore.getState().setUser({
        ...currentUser,
        user_details: {
          ...currentUser.user_details,
          notification_settings: data,
        },
      });

      queryClient.refetchQueries({
        queryKey: queryKeys.notifications.customerSettings,
      });
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  const updateBookingSettings = useMutation({
    mutationFn: (data: BookingSettings) =>
      settingsService.notification.updateBookingNotifications(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      const currentUser = useAuthStore.getState().user;
      if (!currentUser || !currentUser.user_details) return;

      useAuthStore.getState().setUser({
        ...currentUser,
        user_details: {
          ...currentUser.user_details,
          bookings_settings: data.bookings_settings, // 👈 with 's' to match API response
        },
      });

      queryClient.refetchQueries({
        queryKey: queryKeys.notifications.bookingSettings,
      });
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  return {
    notification: query.data?.notification_settings as
      | NotificationSettings
      | undefined,
    bookings: bookingQuery.data?.bookings_settings as
      | BookingSettings
      | undefined,
    isLoading: query.isLoading,
    errorMessage,
    updateNotifications: updateNotifications.mutate,
    updateBookingSettings: updateBookingSettings.mutate,
    isUpdating:
      updateNotifications.isPending || updateBookingSettings.isPending,
  };
};
