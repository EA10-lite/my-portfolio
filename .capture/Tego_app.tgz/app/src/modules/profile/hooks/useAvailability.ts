// hooks/useAvailability.ts
import { queryKeys } from "@/constants/queryKeys";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { settingsService } from "../services/settings.service";
import { AvailabilitySettings } from "../types/profile.dto";

export const useAvailability = () => {
  const { setUser, user } = useAuthStore();
  const ref = useRef<BottomSheetModal>(null);
  const openModal = () => ref.current?.present();
  const closeModal = () => ref.current?.dismiss();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.profile.availability,
    queryFn: settingsService.availability.getAvailability,
  });

  const update = useMutation({
    mutationFn: (data: AvailabilitySettings) =>
      settingsService.availability.updateAvailability(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.profile.availability });

      const currentUser = user;
      if (!currentUser) return;

      setUser({
        ...currentUser,
        provider_settings: {
          ...currentUser.provider_settings!,
          accept_instant_booking: data.accept_instant_booking,
          available_status: data.available_status,
        },
      });
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  return {
    availability: query.data as AvailabilitySettings | undefined,
    isLoading: query.isLoading,
    errorMessage,
    update: update.mutate,
    isUpdating: update.isPending,
    ref,
    openModal,
    closeModal,
  };
};
