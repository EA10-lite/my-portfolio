// hooks/useLanguage.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import { LanguageSettings } from "../types/profile.dto";

export const useLanguage = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.profile.language,
    queryFn: settingsService.language.getUserLanguage,
  });

  const update = useMutation({
    mutationFn: (data: LanguageSettings) =>
      settingsService.language.updateUserLanguage(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: () =>
      queryClient.refetchQueries({ queryKey: queryKeys.profile.language }),
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  return {
    language: query.data as LanguageSettings | undefined,
    isLoading: query.isLoading,
    errorMessage,
    update: update.mutate,
    isUpdating: update.isPending,
  };
};
