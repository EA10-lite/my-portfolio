// hooks/useResetPassword.ts
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import { UpdatePassword } from "../types/profile.dto";

export const useResetPassword = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const reset = useMutation({
    mutationFn: (data: UpdatePassword) =>
      settingsService.profile.resetPassword(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      console.log("Reset password response:", data);
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  return {
    errorMessage,
    reset: reset.mutate,
    isResetting: reset.isPending,
    isSuccess: reset.isSuccess,
  };
};
