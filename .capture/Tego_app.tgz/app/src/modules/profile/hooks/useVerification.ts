// hooks/useVerification.ts
import { queryKeys } from "@/constants/queryKeys";
import { uploadToCloudinary } from "@/shared/lib/cloudinary";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { settingsService } from "../services/settings.service";
import { GetVerification, ProviderVerification } from "../types/profile.dto";
import { useToastStore } from "@/shared/store/toastStore";

type VerificationPayload = {
  nin: string;
  bvn: string;
  uri: string;
  mimeType: string;
};

export const useVerification = () => {
  const { showToast } = useToastStore();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.profile.verification,
    queryFn: settingsService.verification.getVerification,
    refetchOnWindowFocus: true,
  });

  const update = useMutation({
    mutationFn: async ({ nin, bvn, uri, mimeType }: VerificationPayload) => {
      // 1. upload to cloudinary
      const { secure_url } = await uploadToCloudinary(uri, {
        folder: "tego/verification_docs",
      });

      // 2. determine file type from mimeType
      const file_type: ProviderVerification["file_type"] = mimeType.startsWith(
        "image/",
      )
        ? "image"
        : "pdf";

      // 3. send to backend
      return settingsService.verification.updateVerification({
        nin,
        bvn,
        file_type,
        file_url: secure_url,
      });
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.profile.verification });
    },
    onError: (error) => {
      const message = getErrorMessage(error);
      showToast("Action Failed", message);
    },
  });

  return {
    verification: query.data as GetVerification | undefined,
    isLoading: query.isLoading,
    update: update.mutate,
    isUpdating: update.isPending,
  };
};
