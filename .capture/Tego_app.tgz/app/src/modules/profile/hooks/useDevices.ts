// hooks/useDevices.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";

export const useDevices = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.profile.devices,
    queryFn: settingsService.devices.getDevices,
  });

  const remove = useMutation({
    mutationFn: (deviceId: string) =>
      settingsService.devices.deleteDevice(deviceId),
    onMutate: () => setErrorMessage(null),
    onSuccess: () => queryClient.refetchQueries({ queryKey: queryKeys.profile.devices }),
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  const flagDevice = useMutation({
    mutationFn: (deviceId: string) =>
      settingsService.devices.flagDevice(deviceId),
    onMutate: () => setErrorMessage(null),
    onSuccess: () => queryClient.refetchQueries({ queryKey: queryKeys.profile.devices }),
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  const unflagDevice = useMutation({
    mutationFn: (deviceId: string) =>
      settingsService.devices.unflagDevice(deviceId),
    onMutate: () => setErrorMessage(null),
    onSuccess: () => queryClient.refetchQueries({ queryKey: queryKeys.profile.devices }),
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  return {
    devices: query.data?.devices,
    isLoading: query.isLoading,
    errorMessage,
    remove: remove.mutate,
    flagDevice: flagDevice.mutate,
    unflagDevice: unflagDevice.mutate,
    isRemoving:
      remove.isPending,
    isFlagging:
      flagDevice.isPending ||
      unflagDevice.isPending,
  };
};
