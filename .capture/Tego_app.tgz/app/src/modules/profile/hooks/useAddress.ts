// hooks/useProfile.ts
import { queryKeys } from "@/constants/queryKeys";
import { useQuery } from "@tanstack/react-query";
import { settingsService } from "../services/settings.service";
import { UserAddress } from "../types/profile.dto";

export const useAddress = () => {
  const addressQuery = useQuery({
    queryKey: queryKeys.profile.address,
    queryFn: settingsService.profile.getUserAddress,
  });

  return {
    address: addressQuery.data?.user_address as UserAddress | undefined,
    isLoading: addressQuery.isLoading,
  };
};
