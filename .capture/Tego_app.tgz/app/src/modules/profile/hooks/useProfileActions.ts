// hooks/useProfile.ts
import { queryKeys } from "@/constants/queryKeys";
import { uploadToCloudinary } from "@/shared/lib/cloudinary";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import { UserAddress, UserProfile } from "../types/profile.dto";
import { useToastStore } from "@/shared/store/toastStore";
import { useAuthStore } from "@/modules/auth/stores/authStore";

export const useProfileActions = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const update = useMutation({
    mutationFn: (data: UserProfile) =>
      settingsService.profile.updateUserProfile(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.profile.root,
      }),
    onError: (error) => {
      const message  = getErrorMessage(error);
      setErrorMessage(message)
      showToast("Action Failed", message);
    }
  });

  const updateUserAddress = useMutation({
    mutationFn: (data: UserAddress) =>
      settingsService.profile.updateUserAddress(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      queryClient.invalidateQueries({
        queryKey: queryKeys.profile.root,
      });
      queryClient.invalidateQueries({
        queryKey: queryKeys.profile.address,
      });
    },
    onError: (error) => {
      const message  = getErrorMessage(error);
      setErrorMessage(message)
      showToast("Action Failed", message);
    }
  });

  const uploadProfilePicture = useMutation({
    mutationFn: async (input: string) => {
      // SelectAvatar uploads the local file to Cloudinary first and passes the
      // resulting secure_url here; uploading an already-remote URL twice just
      // duplicates the asset on the CDN. Upload once, or passthrough remote.
      const url = /^https?:\/\//i.test(input)
        ? input
        : (await uploadToCloudinary(input, {
            folder: "tego/profile_pictures",
          })).secure_url;
      // 2. send URLs to backend
      return settingsService.profile.uploadPictures({
        profile_picture: url,
      });
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: queryKeys.profile.root });
    },
    onError: (error) => {
      const message  = getErrorMessage(error);
      setErrorMessage(message)
      showToast("Action Failed", message);
    }
  });

  const uploadProfileCard = useMutation({
    mutationFn: async (uri: string) => {
      // 1. upload to cloudinary, get back URLs
      const url = await uploadToCloudinary(uri, {
        folder: "tego/profile_pictures",
      });
      // 2. send URLs to backend
      return settingsService.profile.uploadPictures({
        picture_card: url.secure_url,
      });
    },
    onMutate: () => setErrorMessage(null),
    onSuccess: (data) => {
      console.log("Upload pictures response:", data);
      queryClient.invalidateQueries({ queryKey: queryKeys.profile.root });
    },
    onError: (error) => {
      const message  = getErrorMessage(error);
      setErrorMessage(message)
      showToast("Action Failed", message);
    }
  });

  return {
    errorMessage,
    update: update.mutate,
    updateUserAddress: updateUserAddress.mutate,
    isUpdating:
      update.isPending ||
      updateUserAddress.isPending,
    uploadProfilePicture: uploadProfilePicture.mutate,
    uploadProfileCard: uploadProfileCard.mutate,
    isUploading:
      uploadProfilePicture.isPending ||
      uploadProfileCard.isPending ||
      updateUserAddress.isPending,
  };
};
