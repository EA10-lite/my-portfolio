// hooks/useProviderNotification.ts
import { queryKeys } from "@/constants/queryKeys";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { settingsService } from "../services/settings.service";
import { ProviderNotificationSettings } from "../types/profile.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useProviderNotification = () => {
  const { showToast } = useToastStore();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.notifications.provider,
    queryFn: settingsService.notification.getProviderNotification,
  });

  const update = useMutation({
    mutationFn: (data: ProviderNotificationSettings) => {
      return settingsService.notification.updateProviderNotification(data)
    },
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: queryKeys.notifications.provider,
      }),
    onError: (error) => {
      showToast("Action Failed", "Failed to update user notification");
    },
  });

  return {
    notification: query.data as ProviderNotificationSettings | undefined,
    isLoading: query.isLoading,
    update: update.mutate,
    isUpdating: update.isPending,
  };
};
