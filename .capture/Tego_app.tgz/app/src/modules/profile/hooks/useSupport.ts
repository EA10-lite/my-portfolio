// hooks/useSupportService.ts
import { uploadManyToCloudinary } from "@/shared/lib/cloudinary";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import { IssuePayload } from "../types/profile.dto";

export const useSupport = () => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const submit = useMutation({
    mutationFn: async ({
      images,
      title,
      issue_description,
      issue_type,
    }: IssuePayload) => {
      const uris = await uploadManyToCloudinary(images, {
        folder: "tego/issue_images",
      });

      return settingsService.supportSerice.submitIssue({
        title,
        issue_description,
        issue_type,
        images: uris.map((uri) => uri.secure_url),
      });
    },
    onMutate: () => setErrorMessage(null),
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  return {
    errorMessage,
    submit: submit.mutate,
    isSubmitting: submit.isPending,
    isSuccess: submit.isSuccess,
  };
};
