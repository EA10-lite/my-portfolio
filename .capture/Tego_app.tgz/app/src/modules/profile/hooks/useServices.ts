// hooks/useServices.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { settingsService } from "../services/settings.service";
import { CreateServicePayload, Service } from "../types/profile.dto";
import { useToastStore } from "@/shared/store/toastStore";

export const useServices = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: queryKeys.profile.services,
    queryFn: settingsService.services.getServices,
    refetchOnWindowFocus: true,
  });

  const create = useMutation({
    mutationFn: (data: CreateServicePayload) =>
      settingsService.services.createService(data),
    onMutate: () => setErrorMessage(null),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: queryKeys.profile.services }),
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(getErrorMessage(error));
      showToast("Action Failed", message);
    },
  });

  const update = useMutation({
    mutationFn: ({
      serviceId,
      data,
    }: {
      serviceId: string;
      data: { services_list: Service[] };
    }) => settingsService.services.updateService(serviceId, data),
    onMutate: () => setErrorMessage(null),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: queryKeys.profile.services }),
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(getErrorMessage(error));
      console.log(message);
      showToast("Action Failed", message);
    },
  });

  return {
    services: query.data,
    isLoading: query.isLoading,
    errorMessage,
    create: create.mutate,
    isCreating: create.isPending,
    update: update.mutate,
    isUpdating: update.isPending,
  };
};
