import VerifiedIcon from "@/assets/images/app-icons/verified.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, UserAvatar } from "@/shared/components";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { JobOffer } from "@/modules/applications/utils/type";

interface OffersCardProps {
  offer: JobOffer;
  tag?: string;
  handleViewOffer: (id: string) => void;
}

const ComparedOffer = ({ offer, tag, handleViewOffer }: OffersCardProps) => {
  return (
    <View style={styles.card}>
      <View style={[styles.header]}>
        <View style={CUSTOM_STYLES.row}>
          <View style={[styles.status, CUSTOM_STYLES.row]}>
            <View style={[styles.dot]} />
            <CustomText style={styles.statusText} weight="semibold">
              Top Rated
            </CustomText>
          </View>
        </View>
        <View style={[CUSTOM_STYLES.row, { gap: 10 }]}>
          <UserAvatar
            name={`${offer.sender.first_name} ${offer.sender.last_name}`}
            url={offer.sender.profile_picture ?? ""}
          />

          <View style={{ gap: 7 }}>
            <CustomText style={styles.profileName} weight="semibold">
              {`${offer.sender.first_name} ${offer.sender.last_name}`}
              {offer.sender.is_verified && <VerifiedIcon />}
            </CustomText>

            <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
              {offer.created_at && (
                <View style={[styles.rating, CUSTOM_STYLES.row]}>
                  <MaterialCommunityIcons
                    name="clock"
                    size={12}
                    color={PALETTE.black}
                  />
                  <CustomText size="xs" weight="regular">
                    {formatDateTime(offer.created_at)}
                  </CustomText>
                </View>
              )}
              {offer.sender.average_rating && (
                <View style={[styles.rating, CUSTOM_STYLES.row]}>
                  <CustomText size="xs" weight="medium">
                    {offer.sender.average_rating}
                  </CustomText>
                  <AntDesign name="star" size={12} color={PALETTE.yellow} />
                </View>
              )}
            </View>
          </View>
        </View>
      </View>
      <View style={styles.content}>
        <View style={styles.body}>
          <CustomText weight="medium" style={styles.message}>
            {offer.message}
          </CustomText>
        </View>
        <View style={[styles.footer, CUSTOM_STYLES.row]}>
          <CustomText weight="semibold" style={styles.offer}>
            {formatCurrency(offer.offer.price)}
          </CustomText>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleViewOffer(offer.id)}
          >
            <CustomText size="xs" weight="semibold">
              View Details
            </CustomText>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    gap: 24,
  },
  status: {
    paddingHorizontal: 11.67,
    paddingVertical: 8.17,
    borderRadius: 58.33,
    backgroundColor: PALETTE.black,
    gap: 3,
    width: "auto",
  },
  statusText: {
    fontSize: 8.67,
    textTransform: "uppercase",
    color: PALETTE.white,
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 50,
    backgroundColor: "#6155F5",
  },
  profileName: {
    fontSize: 13,
    letterSpacing: -0.29,
  },
  date: {},
  rating: {
    backgroundColor: PALETTE.white,
    borderRadius: 25,
    paddingHorizontal: 12.19,
    paddingVertical: 6.09,
    gap: 2.44,
  },
  content: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
  },
  body: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  message: {
    opacity: 0.5,
    fontSize: 13,
    lineHeight: 20,
    letterSpacing: -0.24,
  },
  footer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    justifyContent: "space-between",
  },
  offer: {
    fontSize: 13,
  },
  button: {
    gap: 4,
  },
});

export default ComparedOffer;
