import VerifiedIcon from "@/assets/images/app-icons/verified.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { JobOffer } from "@/modules/applications/utils/type";
import { CustomText, UserAvatar } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import {
  formatCurrency,
  truncateName,
} from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { router } from "expo-router";
import { StyleSheet, TouchableOpacity, View } from "react-native";

interface OffersCardProps {
  offer: JobOffer;
  jobId: string;
}

const OffersCard = ({ offer, jobId }: OffersCardProps) => {
  const handleViewOffer = (offer: JobOffer, offerId: string) => {
    router.push({
      pathname: `/(customer)/request-job/${jobId}/offers/${offerId}` as any,
      params: {
        providerId: offer.sender.id,
        firstName: offer.sender.first_name,
        lastName: offer.sender.last_name,
        rating: offer.sender.average_rating,
        availability: offer.offer.availability,
        profile_picture: offer.sender.profile_picture,
        date: offer.created_at,
        isVerfieid: `${offer.sender.is_verified}`,
        offer: offer.offer.price,
        note: offer.offer.proposal,
        jobId,
        receiverId: offer.sender.id,
      },
    });
  };
  return (
    <View style={styles.card}>
      <View style={[styles.header, CUSTOM_STYLES.row]}>
        <UserAvatar
          name={`${offer.sender.first_name} ${offer.sender.last_name}`}
          url={offer.sender.profile_picture ?? ""}
        />

        <View style={{ gap: 7 }}>
          <CustomText style={styles.profileName} weight="semibold">
            {truncateName(
              `${offer.sender.first_name} ${offer.sender.last_name}`,
            )}
            {offer.sender.is_verified && <VerifiedIcon />}
          </CustomText>

          <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
            {offer.offer.availability && (
              <View style={[styles.rating, CUSTOM_STYLES.row]}>
                <MaterialCommunityIcons
                  name="clock"
                  size={12}
                  color={PALETTE.black}
                />
                <CustomText size="xs" weight="regular">
                  {offer.offer.availability}
                </CustomText>
              </View>
            )}
            {offer.sender?.average_rating && (
              <View style={[styles.rating, CUSTOM_STYLES.row]}>
                <CustomText size="xs" weight="medium">
                  {offer.sender.average_rating}
                </CustomText>
                <AntDesign name="star" size={12} color={PALETTE.yellow} />
              </View>
            )}
          </View>
        </View>
      </View>
      <View style={styles.content}>
        <View style={styles.body}>
          <CustomText weight="medium" style={styles.message}>
            {offer.message}
          </CustomText>
        </View>
        <View style={[styles.footer, CUSTOM_STYLES.row]}>
          <View style={{ gap: 4 }}>
            <CustomText size="xs" weight="medium" style={{ opacity: 0.5 }}>
              Offer
            </CustomText>
            <CustomText weight="semibold" style={styles.offer}>
              {formatCurrency(offer.offer.price)}
            </CustomText>
          </View>

          <TouchableOpacity style={styles.button}>
            <CustomText
              size="xs"
              weight="semibold"
              style={{ color: PALETTE.white }}
              handlePress={() => handleViewOffer(offer, offer.id)}
            >
              View Details
            </CustomText>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    gap: 10,
  },
  profileName: {
    fontSize: 13,
    letterSpacing: -0.29,
  },
  date: {},
  rating: {
    backgroundColor: PALETTE.white,
    borderRadius: 25,
    paddingHorizontal: 12.19,
    paddingVertical: 6.09,
    gap: 2.44,
  },
  content: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderRadius: 6,
  },
  body: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: hexToRgba(PALETTE.black, 0.1),
  },
  message: {
    opacity: 0.5,
    fontSize: 13,
    lineHeight: 20,
    letterSpacing: -0.24,
  },
  footer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    justifyContent: "space-between",
  },
  offer: {
    fontSize: 13,
  },
  button: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: PALETTE.black,
    borderRadius: 50,
  },
});

export default OffersCard;
