import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, Input, Switch } from "@/shared/components";
import { FormikValues, useFormikContext } from "formik";
import { useEffect, useRef } from "react";
import {
  Animated,
  Pressable,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";

const PRICE_RANGES = [
  { label: "₦100k - ₦500k", start: 100000, end: 500000 },
  { label: "₦500k - ₦1M", start: 500000, end: 1000000 },
  { label: "₦1M - ₦1.5M", start: 1000000, end: 1500000 },
];

const BudgetSelector = ({
  scrollRef,
  isOptional,
  isOpenToOffers,
  disabled,
}: {
  scrollRef: React.RefObject<ScrollView | null>;
  isOptional?: boolean;
  isOpenToOffers?: boolean;
  disabled?: boolean;
}) => {
  const { values, setFieldValue } = useFormikContext<FormikValues>();

  const footerRef = useRef<View>(null);
  const filterOpacity = useRef(new Animated.Value(1)).current;
  const filterWidth = useRef(new Animated.Value(1)).current;
  const footerOpacity = useRef(new Animated.Value(0)).current;
  const footerHeight = useRef(new Animated.Value(0)).current;

  const hasBudget = !!values.start_price;

  const activeRangeIndex = PRICE_RANGES.findIndex(
    (r) =>
      r.start === Number(values.start_price) &&
      r.end === Number(values.end_price),
  );

  useEffect(() => {
    if (hasBudget) {
      Animated.parallel([
        Animated.timing(footerOpacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: false,
        }),
        Animated.timing(footerHeight, {
          toValue: 1,
          duration: 300,
          useNativeDriver: false,
        }),
      ]).start();

      setTimeout(() => {
        scrollRef.current?.scrollToEnd({ animated: true });
      }, 300);
    } else {
      Animated.parallel([
        Animated.timing(footerOpacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: false,
        }),
        Animated.timing(footerHeight, {
          toValue: 0,
          duration: 200,
          useNativeDriver: false,
        }),
      ]).start();
    }
  }, [hasBudget]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(filterOpacity, {
        toValue: hasBudget ? 1 : 0,
        duration: 200,
        useNativeDriver: false,
      }),
      Animated.timing(filterWidth, {
        toValue: hasBudget ? 1 : 0,
        duration: 200,
        useNativeDriver: false,
      }),
    ]).start();
  }, [hasBudget]);

  const footerAnimatedHeight = footerHeight.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 80],
  });

  const selectPresetRange = (range: (typeof PRICE_RANGES)[0]) => {
    setFieldValue("start_price", range.start.toString());
    setFieldValue("end_price", range.end.toString());
  };

  const clearBudget = () => {
    setFieldValue("start_price", "");
    setFieldValue("end_price", "");
  };

  const handleCustomInput = (text: string) => {
    setFieldValue("start_price", text);
    setFieldValue("end_price", text); // 👈 mirror into end_price
  };

  const displayBudget = () => {
    if (!values.start_price && !values.end_price) return "";
    if (
      values.start_price &&
      values.end_price &&
      values.start_price !== values.end_price
    ) {
      return `₦${Number(values.start_price).toLocaleString()} - ₦${Number(values.end_price).toLocaleString()}`;
    }
    return `₦${Number(values.start_price).toLocaleString()}`;
  };

  return (
    <View style={styles.container}>
      <View style={[styles.heading, CUSTOM_STYLES.row]}>
        <CustomText size="sm" weight="semibold">
          Budget
        </CustomText>
        {isOptional && (
          <View style={styles.optional}>
            <CustomText
              color="primary"
              weight="medium"
              style={styles.optionalText}
            >
              Optional
            </CustomText>
          </View>
        )}
      </View>

      <View style={styles.body}>
        {/* Preset range buttons */}
        <View style={[CUSTOM_STYLES.row, styles.budgets]}>
          {PRICE_RANGES.map((range, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.budget,
                CUSTOM_STYLES.center,
                activeRangeIndex === index && styles.activeBudget,
              ]}
              onPress={() => selectPresetRange(range)}
            >
              <CustomText style={styles.budgetText}>{range.label}</CustomText>
            </TouchableOpacity>
          ))}
        </View>

        {/* Single custom budget input — updates start_price, mirrors end_price */}
        <Input
          name="start_price"
          placeholder="Input Budget"
          type="numeric"
          style={{ height: 46 }}
          onChange={handleCustomInput}
          disabled={disabled}
        />

        {isOpenToOffers && (
          <View style={[styles.offers, CUSTOM_STYLES.row]}>
            <CustomText
              style={{ fontSize: 11, letterSpacing: -0.24 }}
              weight="medium"
            >
              Open to offers — let the other side propose
            </CustomText>
            <Switch name="is_budget_negotiable" />
          </View>
        )}
      </View>

      <Animated.View
        ref={footerRef}
        style={{
          overflow: "hidden",
          height: footerAnimatedHeight,
          opacity: footerOpacity,
        }}
      >
        <View style={styles.footer}>
          <View style={{ gap: 6 }}>
            <CustomText size="xs" style={styles.footerLabel}>
              Selected budget
            </CustomText>
            <CustomText
              style={{ color: PALETTE.white }}
              size="xs"
              weight="medium"
            >
              {displayBudget()}
            </CustomText>
          </View>
          <Pressable onPress={clearBudget}>
            <CustomText size="xs" style={{ color: PALETTE.white }}>
              Clear
            </CustomText>
          </Pressable>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  heading: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
  },
  optional: {
    borderWidth: 1.17,
    backgroundColor: PALETTE.white50,
    borderColor: PALETTE.primary10,
    borderRadius: 133.333,
    paddingHorizontal: 11.67,
    paddingVertical: 8.17,
  },
  optionalText: {
    fontSize: 10,
    textTransform: "uppercase",
  },
  body: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
    gap: 10,
  },
  budgets: {
    gap: 6.2,
    borderRadius: 6,
  },
  budget: {
    backgroundColor: PALETTE.grey,
    flex: 1,
    height: 40,
  },
  budgetText: {
    fontSize: 11,
    opacity: 0.5,
  },
  activeBudget: {
    borderWidth: 1,
    borderColor: PALETTE.primary,
    backgroundColor: PALETTE.white50,
    borderRadius: 3,
  },
  offers: {
    padding: 16,
    borderRadius: 6,
    backgroundColor: PALETTE.white50,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    justifyContent: "space-between",
  },
  footer: {
    backgroundColor: PALETTE.black,
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    borderBottomRightRadius: 6,
    borderBottomLeftRadius: 6,
    padding: 20,
  },
  footerLabel: {
    opacity: 0.4,
    color: PALETTE.white,
  },
});

export default BudgetSelector;
