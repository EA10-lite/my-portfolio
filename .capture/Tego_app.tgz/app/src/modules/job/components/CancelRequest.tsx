import Hexagon from "@/assets/images/app-icons/hexagon.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomButton, CustomText } from "@/shared/components";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { LinearGradient } from "expo-linear-gradient";
import { forwardRef, useCallback } from "react";
import { Platform, Pressable, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FullWindowOverlay } from "react-native-screens";

interface CancelSheetProps {
  title?: string;
  description?: string;
  onClose?: () => void;
  primaryAction?: () => void;
  secondaryAction?: () => void;
  secondaryButtonText?: string;
  secondaryButtonLoadingState?: boolean;
  primaryButtonText?: string;
  type?: "cancel" | "warning" | "success";
}

const CancelRequest = forwardRef<BottomSheetModal, CancelSheetProps>(
  (
    {
      title = "Cancel Request?",
      description = "Are you sure you want to cancel this request? You'll stop receiving offers from providers.",
      secondaryAction,
      primaryAction,
      onClose,
      secondaryButtonText,
      primaryButtonText,
      secondaryButtonLoadingState = false,
      type = "cancel",
    },
    ref,
  ) => {
    const { bottom } = useSafeAreaInsets();
    const handleClose = () => {
      if (typeof ref !== "function" && ref?.current) {
        ref.current.dismiss();
      }
      onClose?.();
    };

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    return (
      <BottomSheetModal
        ref={ref}
        enableDynamicSizing
        backdropComponent={renderBackdrop}
        containerComponent={(props) =>
          Platform.OS === "ios" ? (
            <FullWindowOverlay>{props.children}</FullWindowOverlay>
          ) : (
            <>{props.children}</>
          )
        }
        backgroundStyle={styles.container}
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/* BODY */}
        <BottomSheetView style={styles.body}>
          {/* HEADER */}
          <LinearGradient
            colors={["rgba(51, 171, 247, 0.232)", "rgba(255, 255, 255, 0)"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={styles.header}
          >
            {/* 👇 custom drag handle INSIDE gradient */}
            <View style={styles.dragWrapper}>
              <View style={styles.dragHandle} />
            </View>

            <View style={styles.hexagon}>
              <Hexagon width={100} height={100} />

              <View style={styles.hexagonCenter}>
                <AntDesign
                  name={
                    type === "success"
                      ? "check"
                      : type === "cancel"
                        ? "close"
                        : "warning"
                  }
                  color={PALETTE.primary}
                  size={20}
                />
              </View>
            </View>

            <Pressable
              onPress={handleClose}
              style={[styles.close, CUSTOM_STYLES.close]}
              hitSlop={12}
            >
              <AntDesign name="close" size={12} />
            </Pressable>
          </LinearGradient>

          <View style={styles.content}>
            <View style={styles.textContainer}>
              <CustomText weight="bold" size="lg" style={styles.title}>
                {title}
              </CustomText>

              <CustomText weight="medium" size="sm" style={styles.description}>
                {description}
              </CustomText>
            </View>

            <View
              style={[
                styles.buttons,
                CUSTOM_STYLES.row,
                { paddingBottom: bottom },
              ]}
            >
              <CustomButton
                title={
                  secondaryButtonText ? secondaryButtonText : "Yes, Cancel"
                }
                onPress={secondaryAction}
                variant={"secondary"}
                style={styles.button}
                loading={secondaryButtonLoadingState}
              />
              <CustomButton
                title={primaryButtonText ? primaryButtonText : "Keep Request"}
                onPress={primaryAction}
                variant={"primary"}
                style={styles.button}
              />
            </View>
          </View>
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

CancelRequest.displayName = "SuccessSheet";

export default CancelRequest;

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  header: {
    height: 207,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },

  center: {
    alignItems: "center",
    justifyContent: "center",
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 30,
    backgroundColor: PALETTE.white,
  },

  close: {
    right: 20,
    top: 32,
  },

  hexagon: {
    width: 81,
    height: 81,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },

  hexagonCenter: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
  },

  body: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
  },

  content: {
    paddingHorizontal: 20,
  },

  textContainer: {
    alignItems: "center",
    gap: 8,
    marginBottom: 48,
  },

  title: {
    textAlign: "center",
    textTransform: "capitalize",
  },

  description: {
    textAlign: "center",
    opacity: 0.7,
    maxWidth: 290,
    lineHeight: 21,
  },

  buttons: {
    gap: 16,
  },

  button: {
    flex: 1,
  },

  handle: {
    width: 40,
    height: 4,
    backgroundColor: "#000",
    opacity: 0.2,
  },
});
