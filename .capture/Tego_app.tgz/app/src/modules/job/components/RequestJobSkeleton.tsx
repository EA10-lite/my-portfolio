import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { LinearGradient } from "expo-linear-gradient";
import { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
    useAnimatedStyle,
    useSharedValue,
    withRepeat,
    withTiming,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SkeletonBox = ({
  width,
  height,
  borderRadius = 6,
  style,
}: {
  width?: number | string;
  height: number;
  borderRadius?: number;
  style?: any;
}) => {
  const opacity = useSharedValue(1);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.4, { duration: 800 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));

  return (
    <Animated.View
      style={[
        { width, height, borderRadius, backgroundColor: PALETTE.grey01 },
        animatedStyle,
        style,
      ]}
    />
  );
};

const RequestJobSkeleton = () => {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.401)"]}
        locations={[0, 1]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={[styles.header, { paddingTop: insets.top + 32 }]}
      >
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 32 }]}>
          {/* Close button */}
          <View style={{ alignItems: "flex-end", paddingRight: 20 }}>
            <SkeletonBox width={24} height={24} borderRadius={12} />
          </View>

          <View style={styles.headerContent}>
            <View style={styles.textContent}>
              {/* Status badge */}
              <SkeletonBox width={99} height={28} borderRadius={58} />

              {/* Title */}
              <View style={{ gap: 8 }}>
                <SkeletonBox width="70%" height={24} borderRadius={4} />
                <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                  <SkeletonBox width={14} height={14} borderRadius={7} />
                  <SkeletonBox width="50%" height={14} borderRadius={4} />
                </View>
              </View>
            </View>

            {/* Tabs */}
            <View style={styles.tabContainer}>
              {[80, 70, 70].map((w, i) => (
                <SkeletonBox key={i} width={w} height={32} borderRadius={100} />
              ))}
            </View>
          </View>
        </View>
      </LinearGradient>

      {/* Overview skeleton body */}
      <View style={styles.body}>
        {/* Overview card */}
        <View style={styles.overviewCard}>
          {/* Card header */}
          <View style={styles.cardHeader}>
            <SkeletonBox width={120} height={14} borderRadius={4} />
            <SkeletonBox width={20} height={20} borderRadius={4} />
          </View>

          {/* Card body */}
          <View style={styles.cardBody}>
            {/* Note/description lines */}
            <View style={{ gap: 8 }}>
              <SkeletonBox width="100%" height={12} borderRadius={4} />
              <SkeletonBox width="90%" height={12} borderRadius={4} />
              <SkeletonBox width="75%" height={12} borderRadius={4} />
            </View>

            {/* Images placeholder */}
            <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
              {[1, 2, 3].map((i) => (
                <SkeletonBox key={i} width={86} height={94} borderRadius={9} />
              ))}
            </View>
          </View>

          {/* Details fields */}
          <View style={styles.detailsFields}>
            {["Date & Time", "Address", "Budget"].map((label, index, arr) => (
              <View key={label}>
                <View style={styles.detailRow}>
                  <SkeletonBox width={80} height={12} borderRadius={4} />
                  <SkeletonBox width={140} height={12} borderRadius={4} />
                </View>
                {index !== arr.length - 1 && <View style={styles.divider} />}
              </View>
            ))}
          </View>
        </View>
      </View>

      {/* Footer button */}
      <View style={[styles.footer, { paddingBottom: insets.bottom || 24 }]}>
        <SkeletonBox width="100%" height={48} borderRadius={6} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    backgroundColor: "rgba(51, 171, 247, 0.1)",
    paddingBottom: 10,
    gap: 16,
  },
  headerContent: {
    paddingTop: 47,
    gap: 16,
  },
  textContent: {
    gap: 16,
    paddingHorizontal: 20,
  },
  tabContainer: {
    flexDirection: "row",
    gap: 11,
    paddingHorizontal: 20,
    marginTop: 32,
  },
  body: {
    paddingHorizontal: 20,
    paddingTop: 24,
    flex: 1,
  },
  overviewCard: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  cardHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardBody: {
    backgroundColor: PALETTE.white,
    padding: 20,
    gap: 16,
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  detailsFields: {
    backgroundColor: PALETTE.white,
  },
  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.grey01,
    marginHorizontal: 20,
  },
  footer: {
    paddingHorizontal: 20,
    paddingTop: 10,
  },
});

export default RequestJobSkeleton;
