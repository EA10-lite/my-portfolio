export interface Offer {
  id: string;
  user: {
    id: string;
    rating: number;
    isVerified: boolean;
    name: string;
    avatar: string;
  };
  offer: number;
  message: string;
  date: string;
}
