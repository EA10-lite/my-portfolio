import { router } from "expo-router";
import { StyleSheet, View } from "react-native";
import { ComparedOffer } from "../components";
import { JobOffer } from "@/modules/applications/utils/type";
interface OffersProps {
  offers: JobOffer[];
  jobId: string;
}

const ComparedOffers = ({ offers, jobId }: OffersProps) => {
  const handleViewOffer = (offerId: string) => {
    router.push(`/(customer)/request-job/${jobId}/offers/${offerId}`);
  };
  return (
    <View style={styles.container}>
      {offers.length > 0 &&
        offers.map((offer, index) => (
          <ComparedOffer
            key={index}
            offer={offer}
            handleViewOffer={handleViewOffer}
          />
        ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    gap: 16,
  },
});

export default ComparedOffers;
