import BellIcon from "@/assets/images/app-icons/bell.svg";
import LoadingIcon from "@/assets/images/app-icons/loading.svg";
import SendIcon from "@/assets/images/app-icons/send-outline.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { JobOffer } from "@/modules/applications/utils/type";
import {
  RequestActivity,
  RequestStatus,
} from "@/modules/request-job/utils/type";
import { CustomText, UserAvatarGroup } from "@/shared/components";
import { getStatusColor } from "@/shared/utils/colors";
import { hexToRgba } from "@/shared/utils/converter";
import { formatMessageDate, truncateName } from "@/shared/utils/formatter";
import Feather from "@expo/vector-icons/Feather";
import { LinearGradient } from "expo-linear-gradient";
import { Pressable, StyleSheet, View } from "react-native";

interface ActivityProps {
  activities: RequestActivity[];
  offers: JobOffer[];
  status?: RequestStatus;
  handleViewOffer: () => void;
  type: string;
}

const MAX_OFFER = 5;

const Activity = ({
  activities,
  offers,
  handleViewOffer,
  status,
  type,
}: ActivityProps) => {
  const getPlural = (count: number) => {
    return count > 1 ? "s" : "";
  };
  return (
    <View style={styles.trackerContainer}>
      <View style={{ gap: 4 }}>
        <View style={styles.row}>
          {/* Icon column */}
          <View style={styles.iconColumn}>
            <View style={[styles.iconContainer]}>
              <SendIcon color={PALETTE.primary} width={16} height={16} />
            </View>

            {/* Connector line */}

            <LinearGradient
              colors={["rgba(51, 171, 247, 1)", "rgba(51, 171, 247, 0)"]}
              locations={[0, 1]}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={styles.connector}
            />
          </View>

          {/* Label */}
          <View style={{ gap: 8 }}>
            <CustomText size="xs" weight="medium" style={styles.label}>
              {type} sent
            </CustomText>
            <CustomText size="xs" weight="medium">
              {activities[0].message}
            </CustomText>
            <CustomText size="xs" weight="medium" style={styles.label}>
              {formatMessageDate(activities[1].date_time)}
            </CustomText>
          </View>
        </View>
        {type === "Request" && (
          <View style={styles.row}>
            {/* Icon column */}
            <View style={styles.iconColumn}>
              <View style={[styles.iconContainer]}>
                <BellIcon color={PALETTE.primary} />
              </View>

              {/* Connector line */}

              <LinearGradient
                colors={["rgba(51, 171, 247, 1)", "rgba(51, 171, 247, 0)"]}
                locations={[0, 1]}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={styles.connector}
              />
            </View>

            {/* Label */}
            <View style={{ gap: 8 }}>
              <CustomText size="xs" weight="medium" style={styles.label}>
                Providers Alerted
              </CustomText>
              <CustomText size="xs" weight="medium">
                {activities[1].message}
              </CustomText>
              <CustomText size="xs" weight="medium" style={styles.label}>
                {formatMessageDate(activities[1].date_time)}
              </CustomText>
            </View>
          </View>
        )}
        {type === "Request" && offers && offers.length > 0 && (
          <View style={[styles.row, { alignItems: "center" }]}>
            {/* Icon column */}
            <View style={styles.iconColumn}>
              <View style={[styles.iconContainer]}>
                <LoadingIcon color={PALETTE.primary} />
              </View>

              {status && (
                <LinearGradient
                  colors={["rgba(51, 171, 247, 1)", "rgba(51, 171, 247, 0)"]}
                  locations={[0, 1]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={styles.connector}
                />
              )}
            </View>

            {/* Label */}
            <View style={{ gap: 8 }}>
              <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                <UserAvatarGroup
                  users={offers.map((offer) => ({
                    url: offer.sender.profile_picture ?? "",
                    name: truncateName(
                      `${offer.sender.first_name} ${offer.sender.last_name}`,
                    ),
                  }))}
                  showRemaining={false}
                  max={MAX_OFFER}
                  size="xs"
                />
                {offers.length > MAX_OFFER && (
                  <CustomText
                    size="xs"
                    weight="medium"
                    style={{ opacity: 0.5 }}
                  >
                    +{offers.length - MAX_OFFER} offer
                    {getPlural(offers.length - MAX_OFFER)} received
                  </CustomText>
                )}
              </View>
              <Pressable onPress={handleViewOffer}>
                <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                  <CustomText size="sm" weight="medium">
                    View offer{getPlural(offers.length)}
                  </CustomText>
                  <Feather name="arrow-right" size={18} color={PALETTE.black} />
                </View>
              </Pressable>
            </View>
          </View>
        )}
        {status && (
          <View style={styles.row}>
            {/* Icon column */}
            <View style={styles.iconColumn}>
              <View style={[styles.iconContainer]}>
                <LoadingIcon color={PALETTE.primary} />
              </View>
            </View>

            {/* Label */}
            <View style={{ gap: 8 }}>
              <CustomText size="xs" weight="medium" style={styles.label}>
                Status
              </CustomText>
              <View style={[CUSTOM_STYLES.row, { gap: 7 }]}>
                <View
                  style={[
                    CUSTOM_STYLES.dot,
                    {
                      backgroundColor: getStatusColor(status),
                    },
                  ]}
                />
                <CustomText
                  size="xs"
                  weight="medium"
                  style={{ textTransform: "capitalize" }}
                >
                  {offers.length <= 0 ? "Waiting for response" : status}
                </CustomText>
              </View>
            </View>
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  trackerContainer: {
    borderRadius: 6,
  },
  row: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 16,
  },
  iconColumn: {
    alignItems: "center",
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 80,
    backgroundColor: PALETTE.grey01,
    justifyContent: "center",
    alignItems: "center",
  },
  connector: {
    width: 2,
    height: 37,
    backgroundColor: hexToRgba(PALETTE.primary, 0.3),
    marginVertical: 2,
  },
  label: {
    opacity: 0.5,
    letterSpacing: -0.24,
  },
  labelPending: {
    opacity: 0.4,
  },
});

export default Activity;
