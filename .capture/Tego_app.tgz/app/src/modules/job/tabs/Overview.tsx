import PencilEditIcon from "@/assets/images/app-icons/pencil-edit.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, DetailsField, ImagePreview } from "@/shared/components";
import { formatDateTime } from "@/shared/utils/formatter";
import { Pressable, StyleSheet, View } from "react-native";

interface ItemProps {
  images: string[];
  note: string;
  date?: string;
  address: string;
  budget?: string;
  timeline?: string;
  category?: string;
}

interface OverviewProps {
  item: ItemProps;
  handleGoBack: () => void;
  title: string;
}

const Overview = ({ title, handleGoBack, item }: OverviewProps) => {
  return (
    <View style={styles.container}>
      <View style={[CUSTOM_STYLES.row, styles.header]}>
        <CustomText size="sm" weight="semibold">
          {title}
        </CustomText>

        <Pressable onPress={handleGoBack}>
          <PencilEditIcon />
        </Pressable>
      </View>
      <View style={styles.body}>
        <View style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}>
          <CustomText style={{ opacity: 0.6 }} size="sm" weight="medium">
            {item.note}
          </CustomText>
          <ImagePreview images={item.images} />
        </View>
        <View style={styles.detailsField}>
          {item.category && (
            <DetailsField
              type="category"
              label="Category"
              value={item.category}
            />
          )}
          {item.timeline ? (
            <DetailsField type="date" label="Timeline" value={item.timeline} />
          ) : (
            item.date && (
              <DetailsField
                type="date"
                label="Date & Time"
                value={item.date && formatDateTime(item.date)}
              />
            )
          )}
          <DetailsField
            type="address"
            label="Address"
            value={item.address}
            isLast={item.budget ? false : true}
          />
          {item.budget && (
            <DetailsField
              type="budget"
              label="Budget"
              value={item.budget ?? ""}
              isLast
            />
          )}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
  },
  header: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
  body: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  detailsField: {},
});

export default Overview;
