import { JobOffer } from "@/modules/applications/utils/type";
import { EmptyMessages } from "@/shared/components";
import { StyleSheet, View } from "react-native";
import { OffersCard } from "../components";
interface OffersProps {
  offers: JobOffer[];
  jobId: string;
}

const Offers = ({ offers, jobId }: OffersProps) => {
  return (
    <View style={styles.container}>
      {offers.length > 0 ? (
        offers.map((offer, index) => (
          <OffersCard key={index} offer={offer} jobId={jobId} />
        ))
      ) : (
        <EmptyMessages
          title="No Offers yet"
          description="Providers are reviewing your job. You'll be notified the moment an offer lands."
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    gap: 16,
  },
});

export default Offers;
