import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { LatestRequestCard } from "@/modules/requests/components";
import { Arrow, CustomText } from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { Animated, Pressable, StyleSheet, View } from "react-native";
import { RecentServiceBookings } from "../types/dashboard.dto";
import { router } from "expo-router";

interface LatestRequestProps {
  count: number;
  requests: RecentServiceBookings[];
}
const LatestRequest = ({ count, requests }: LatestRequestProps) => {
  const {
    showContent,
    setContentHeight,
    contentHeight,
    setShowContent,
    rotate,
    animatedHeight,
  } = useExpandableAnimation();
  return (
    <View style={styles.container}>
      <Pressable onPress={() => setShowContent(!showContent)}>
        <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.card, styles.heading]}>
          <View style={[CUSTOM_STYLES.row]}>
            <CustomText style={{ fontSize: 13 }} weight="semibold">
              Latest requests
            </CustomText>
          </View>

          <Animated.View
            style={[
              CUSTOM_STYLES.toggleButton,
              CUSTOM_STYLES.center,
              { transform: [{ rotate }] },
            ]}
          >
            <Arrow direction="bottom" color={PALETTE.primary} size={20} />
          </Animated.View>
        </View>
      </Pressable>
      <Animated.View
        style={[
          {
            height: animatedHeight,
            overflow: "hidden",
          },
        ]}
      >
        <View
          onLayout={(event) => {
            const height = event.nativeEvent.layout.height;

            if (height > 0 && height !== contentHeight) {
              setContentHeight(height);
            }
          }}
          style={{
            position: "absolute",
            width: "100%",
          }}
        >
          <View style={styles.content}>
            {requests.map((request, index) => (
              <LatestRequestCard
                key={index}
                request={request}
                handlePress={()=> {
                  router.push(`/(service-provider)/request/${request.id}`)
                }}
              />
            ))}
          </View>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 20,
    paddingHorizontal: 20,
  },
  heading: {
    padding: 16,
    justifyContent: "space-between",
  },
  content: {
    flexGrow: 1,
    gap: 20,
  },
});

export default LatestRequest;
