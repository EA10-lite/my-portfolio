import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Arrow, CustomText } from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { Animated, Pressable, StyleSheet, View } from "react-native";
import PerformanceCard from "../components/PerformanceCard";
import { DashboardPerformanceData } from "../types/dashboard.dto";

const Performance = ({
  average_rating,
  average_response_time,
  completion_percentage,
  message_response_rate,
}: DashboardPerformanceData) => {
  const {
    showContent,
    setContentHeight,
    contentHeight,
    setShowContent,
    rotate,
    animatedHeight,
  } = useExpandableAnimation();

  const metrics = [
    {
      icon: "rating" as const,
      title: "Rating",
      value: average_rating?.value ?? "0",
      percentageIncrease: average_rating?.change_percentage ?? 0,
    },
    {
      icon: "booking" as const,
      title: "Job Completion",
      value:
        completion_percentage?.value != null
          ? `${completion_percentage.value}%`
          : "0",
      percentageIncrease: completion_percentage?.change_percentage ?? 0,
    },
    {
      icon: "clock" as const,
      title: "Avg. response",
      value:
        average_response_time?.display != null
          ? `${average_response_time.display}min`
          : "0",
      percentageIncrease: average_response_time?.change_percentage ?? 0,
    },
    {
      icon: "clock" as const,
      title: "Response rate",
      value:
        message_response_rate?.value != null
          ? `${message_response_rate.value}%`
          : "0",
      percentageIncrease: message_response_rate?.change_percentage ?? 0,
    },
  ];

  return (
    <View style={[styles.container, { marginBottom: showContent ? 20 : 0 }]}>
      <Pressable onPress={() => setShowContent(!showContent)}>
        <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.card, styles.heading]}>
          <View style={[CUSTOM_STYLES.row]}>
            <CustomText style={{ fontSize: 13 }} weight="semibold">
              Performance
            </CustomText>
          </View>

          <Animated.View
            style={[
              CUSTOM_STYLES.toggleButton,
              CUSTOM_STYLES.center,
              { transform: [{ rotate }] },
            ]}
          >
            <Arrow direction="bottom" color={PALETTE.primary} size={20} />
          </Animated.View>
        </View>
      </Pressable>
      <Animated.View
        style={[
          {
            height: animatedHeight,
            overflow: "hidden",
          },
        ]}
      >
        <View
          onLayout={(event) => {
            const height = event.nativeEvent.layout.height;

            if (height > 0 && height !== contentHeight) {
              setContentHeight(height);
            }
          }}
          style={{
            position: "absolute",
            width: "100%",
          }}
        >
          <View style={styles.content}>
            {Array.from({ length: Math.ceil(metrics.length / 2) }).map(
              (_, rowIndex) => {
                const rowMetrics = metrics.slice(
                  rowIndex * 2,
                  rowIndex * 2 + 2,
                );

                return (
                  <View key={rowIndex} style={[CUSTOM_STYLES.row, styles.row]}>
                    {rowMetrics.map((metric, index) => (
                      <PerformanceCard
                        key={index}
                        title={metric.title}
                        value={metric.value}
                        percentageIncrease={metric.percentageIncrease}
                        icon={metric.icon as "rating" | "clock" | "booking"}
                      />
                    ))}
                  </View>
                );
              },
            )}
          </View>
        </View>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    gap: 20,
    paddingHorizontal: 20,
  },
  heading: {
    padding: 16,
    justifyContent: "space-between",
  },
  content: {
    flexGrow: 1,
    gap: 20,
  },
  row: {
    gap: 20,
  },
});

export default Performance;
