// hooks/useDevices.ts
import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants/queryKeys";
import { providerDashboard } from "../services/dashboard.service";

export const useDashboard = () => {
  const dashboard = useQuery({
    queryKey: queryKeys.dashboard.provider,
    queryFn: providerDashboard.getDashboard,
    refetchInterval: 10_000,
    refetchOnWindowFocus: true,
  });

  const subscription = useQuery({
    queryKey: queryKeys.dashboard.providerSubscriptionStatus,
    queryFn: providerDashboard.getSubscription,
  });

  return {
    dashboard: dashboard.data,
    subscription: subscription.data,
    isLoading: dashboard.isLoading || subscription.isLoading,
    refetch: dashboard.refetch,
  };
};
