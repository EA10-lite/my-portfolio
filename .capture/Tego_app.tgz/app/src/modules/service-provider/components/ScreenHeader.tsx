import { PALETTE } from "@/constants/colors";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { CustomSearchInput, CustomTab, CustomText } from "@/shared/components";
import { CustomTabs } from "@/shared/containers";

import { LinearGradient } from "expo-linear-gradient";
import { useEffect, useRef, useState } from "react";
import { Animated, StyleSheet, View } from "react-native";

interface HeaderProps {
  title?: string;
  search: string;
  placeholder?: string;
  setSearch: (text: string) => void;
  Filter?: React.ReactNode;
  TAB?: {
    label: string;
    value: string;
    count?: number;
  }[];
  activeTab?: string;
  setActiveTab?: (tab: string) => void;
}

const Header = ({
  title,
  search,
  placeholder,
  setSearch,
  Filter,
  TAB,
  activeTab,
  setActiveTab,
}: HeaderProps) => {
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const { user } = useAuthStore();

  const filterOpacity = useRef(new Animated.Value(1)).current;
  const filterWidth = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (isFocused) {
      // hide filter
      Animated.parallel([
        Animated.timing(filterOpacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: false,
        }),
        Animated.timing(filterWidth, {
          toValue: 0,
          duration: 200,
          useNativeDriver: false,
        }),
      ]).start();
    } else {
      // show filter
      Animated.parallel([
        Animated.timing(filterOpacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: false,
        }),
        Animated.timing(filterWidth, {
          toValue: 1,
          duration: 200,
          useNativeDriver: false,
        }),
      ]).start();
    }
  }, [isFocused]);

  const filterMaxWidth = filterWidth.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 60], // 60 = your filter button width
  });

  return (
    <LinearGradient
      colors={["rgba(51, 171, 247, 0.472)", "rgba(255, 255, 255, 0.4012)"]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={[styles.container, { paddingTop: 129 }]}
    >
      <View style={styles.content}>
        <View style={styles.textContent}>
          <CustomText size="sm" weight="semibold" style={styles.title}>
            Hello {user?.firstName} 👋
          </CustomText>
          <CustomText size="xxl" weight="bold" style={styles.description}>
            {title ?? "What do you need help with?"}
          </CustomText>
        </View>
        <View style={styles.searchBox}>
          <CustomSearchInput
            value={search}
            onChange={setSearch}
            isFocused={isFocused}
            setIsFocused={setIsFocused}
            placeholder={placeholder}
          />
          {Filter && (
            <Animated.View
              style={{
                maxWidth: filterMaxWidth,
                opacity: filterOpacity,
                overflow: "hidden",
              }}
            >
              {Filter}
            </Animated.View>
          )}
        </View>

        {/* 🔥 Tabs (always visible) */}
        {TAB && setActiveTab && (
          <CustomTabs
            tabs={TAB}
            activeTab={activeTab ?? ""}
            onTabChange={setActiveTab}
          />
        )}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingBottom: 20,
    backgroundColor: PALETTE.white,
  },
  heading: {
    marginTop: 32,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  content: {
    marginTop: 58,
    gap: 30,
  },
  textContent: { gap: 8, width: "90%", paddingHorizontal: 20 },
  title: {
    textTransform: "uppercase",
    opacity: 0.5,
  },
  description: {
    lineHeight: 37,
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 20,
  },
});

export default Header;
