import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import {
  CustomButton,
  CustomText,
  Sheet,
  UserAvatar,
} from "@/shared/components";
import { getStatusColor } from "@/shared/utils/colors";
import { hexToRgba } from "@/shared/utils/converter";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef, useEffect, useState } from "react";
import { Pressable, StyleSheet, View } from "react-native";
export interface Availability {
  label: string;
  value: AvailabilityStatus;
}

interface AvailabilityModalProps {
  handleSave: (
    status: AvailabilityStatus,
    acceptInstantBooking: boolean,
  ) => void;
  closeModal: () => void;
  availabilities: Availability[];
  selectedAvailability: Availability;
  instantBookingAccepted: boolean;
  isUpdating: boolean;
}

const AvailabilityModal = forwardRef<BottomSheetModal, AvailabilityModalProps>(
  (
    {
      handleSave,
      closeModal,
      availabilities,
      selectedAvailability,
      instantBookingAccepted,
      isUpdating,
    },
    ref,
  ) => {
    const { user } = useAuthStore();
    const [status, setStatus] = useState<Availability>(selectedAvailability);

    // 👇 Sync when selectedAvailability prop changes
    useEffect(() => {
      setStatus(selectedAvailability);
    }, [selectedAvailability.value]);
    const [acceptInstantBooking, setAcceptInstantBooking] = useState<boolean>(
      instantBookingAccepted,
    );

    const saveAvailability = () => {
      handleSave(status.value, acceptInstantBooking);
    };
    return (
      <Sheet ref={ref} onClose={closeModal}>
        <View style={styles.container}>
          <View style={{ gap: 22 }}>
            <CustomText weight="bold" size="sm">
              Availability Status
            </CustomText>

            <View style={styles.heading}>
              <View
                style={[
                  CUSTOM_STYLES.row,
                  { gap: 12, alignItems: "flex-start" },
                ]}
              >
                <View style={styles.imageBox}>
                  <UserAvatar
                    name={user?.firstName || ""}
                    url={user?.profilePicture}
                  />
                  <View
                    style={[
                      styles.dot,
                      styles.activeDot,
                      {
                        backgroundColor: getStatusColor(status.value),
                      },
                    ]}
                  />
                </View>
                <View style={{ gap: 4, flexShrink: 1 }}>
                  <CustomText style={styles.label} weight="semibold">
                    {status.label}
                  </CustomText>
                  <CustomText
                    style={styles.description}
                    weight="regular"
                    size="xs"
                  >
                    You are currently visible to customers and can receive
                    bookings
                  </CustomText>
                </View>
              </View>
            </View>

            <View style={styles.body}>
              <View style={styles.details}>
                <CustomText
                  weight="semibold"
                  size="xs"
                  style={styles.detailsTitle}
                >
                  Update Status
                </CustomText>

                <View style={styles.detailsField}>
                  {availabilities.map((availability, index) => (
                    <View key={index}>
                      <Pressable
                        style={[
                          CUSTOM_STYLES.row,
                          {
                            justifyContent: "space-between",
                            paddingVertical: 20,
                          },
                        ]}
                        onPress={() => setStatus(availability)}
                      >
                        <View style={[CUSTOM_STYLES.row, { gap: 6 }]}>
                          <View
                            style={[
                              styles.dot,
                              {
                                backgroundColor: getStatusColor(
                                  availability.value,
                                ),
                              },
                            ]}
                          />
                          <CustomText weight="medium" style={styles.statusText}>
                            {availability.value === "offline"
                              ? "Not Available"
                              : availability.value === "available_to_work"
                                ? "Available"
                                : availability.value}
                          </CustomText>
                        </View>

                        <View style={[styles.radioOuter, CUSTOM_STYLES.center]}>
                          {status.value === availability.value && (
                            <View style={styles.radioInner} />
                          )}
                        </View>
                      </Pressable>
                      {index !== availabilities.length - 1 && (
                        <View style={styles.divider} />
                      )}
                    </View>
                  ))}
                </View>

                <View style={styles.detailsField}>
                  <Pressable
                    style={[
                      CUSTOM_STYLES.row,
                      {
                        justifyContent: "space-between",
                        paddingVertical: 20,
                        alignItems: "flex-start",
                      },
                    ]}
                    onPress={() =>
                      setAcceptInstantBooking(!acceptInstantBooking)
                    }
                  >
                    <View style={{ gap: 6 }}>
                      <CustomText weight="semibold" style={styles.statusText}>
                        Accept Instant Booking
                      </CustomText>
                      <CustomText
                        weight="medium"
                        size="xs"
                        style={{ opacity: 0.4 }}
                      >
                        Customer can book you instantly without approval
                      </CustomText>
                    </View>

                    <View style={[styles.radioOuter, CUSTOM_STYLES.center]}>
                      {acceptInstantBooking && (
                        <View style={styles.radioInner} />
                      )}
                    </View>
                  </Pressable>
                </View>
              </View>
            </View>
          </View>
        </View>

        <View style={{ paddingBottom: 12 }}>
          <CustomButton
            title="Save"
            onPress={saveAvailability}
            loading={isUpdating}
          />
        </View>
      </Sheet>
    );
  },
);

AvailabilityModal.displayName = "Availability";

const styles = StyleSheet.create({
  container: {
    gap: 20,
    marginBottom: 24,
  },
  heading: {
    padding: 16,
    backgroundColor: PALETTE.black,
    borderRadius: 6,
  },
  label: {
    fontSize: 13,
    color: PALETTE.white,
    letterSpacing: -0.29,
  },
  description: {
    color: PALETTE.white,
    opacity: 0.4,
  },
  body: {
    gap: 12,
  },
  details: {
    gap: 15,
  },
  detailsTitle: {
    textTransform: "uppercase",
    letterSpacing: -0.24,
  },
  detailsField: {
    backgroundColor: PALETTE.grey01,
    paddingHorizontal: 20,
    borderRadius: 6,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 20,
  },
  activeDot: {
    borderWidth: 2,
    borderColor: PALETTE.white,
    position: "absolute",
    left: 30,
    bottom: 0,
  },
  statusText: {
    fontSize: 13,
    textTransform: "capitalize",
  },
  imageBox: {
    borderWidth: 1,
    borderColor: PALETTE.white,
    position: "relative",
    borderRadius: "50%",
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 20,
    backgroundColor: PALETTE.primary,
  },
  radioOuter: {
    width: 16,
    height: 16,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.black, 0.2),
  },
});

export default AvailabilityModal;
