import RocketIcon from "@/assets/images/app-icons/rocket.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomButton, CustomText } from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { StyleSheet, View } from "react-native";

const UpgradeCard = () => {
  return (
    <LinearGradient
      colors={[
        "rgba(51, 171, 247, 0.128)",
        "rgba(255, 255, 255, 0.1088)",
        "rgba(141, 141, 141, 0.08)",
      ]}
      locations={[0, 0.6458, 1]}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
      style={styles.card}
    >
      <View style={[styles.header, CUSTOM_STYLES.row, { gap: 11 }]}>
        <RocketIcon width={25} height={25} color={PALETTE.primary} />
        <View style={{ gap: 4 }}>
          <CustomText weight="semibold" style={styles.text}>
            Get Seen by More Customers
          </CustomText>
          <CustomText weight="medium" style={[styles.text, { opacity: 0.5 }]}>
            Upgrade to Pro for a better experience
          </CustomText>
        </View>
      </View>

      <View style={styles.body}>
        <CustomButton
          title="Upgrade to pro"
          onPress={() =>
            router.push("/(service-provider)/profile/subscription")
          }
        />
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 6,
    marginHorizontal: 20,
    overflow: "hidden",
  },
  header: {
    padding: 20,
  },
  body: {
    padding: 20,
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E74D",
    borderRadius: 6,
  },
  text: {
    fontSize: 13,
    letterSpacing: -0.24,
  },
});

export default UpgradeCard;
