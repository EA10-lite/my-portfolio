import CardIcon from "@/assets/images/app-icons/card.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomButton, CustomText, Info, Input } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { Formik } from "formik";
import { forwardRef, useCallback } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { SavedCardProps } from "../types/profile.dto";

interface AddCardModalProps {
  isOpen: boolean;
  closeModal: () => void;
  addCard: (card: SavedCardProps) => void;
}
const AddCardModal = forwardRef<BottomSheetModal, AddCardModalProps>(
  ({ isOpen, closeModal, addCard }, ref) => {
    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    return (
      <>
        <View>
          {Platform.OS === "ios" ? (
            <Modal
              visible={isOpen}
              animationType="slide"
              presentationStyle="pageSheet"
              onRequestClose={closeModal}
              style={{ borderRadius: 50 }}
            >
              <Header closeModal={closeModal} />
              <View style={[styles.content]}>
                <Form onSuccess={addCard} />
              </View>
            </Modal>
          ) : (
            <BottomSheetModal
              ref={ref}
              enablePanDownToClose
              backdropComponent={renderBackdrop}
              backgroundStyle={styles.container}
              handleIndicatorStyle={{ height: 0 }}
              handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
              handleComponent={() => <></>}
              snapPoints={["95%"]}
            >
              <BottomSheetScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{
                  flex: 1,
                }}
              >
                <Header closeModal={closeModal} />
                <View style={[styles.content]}>
                  <Form onSuccess={addCard} />
                </View>
              </BottomSheetScrollView>
            </BottomSheetModal>
          )}
        </View>
      </>
    );
  },
);

const Form = ({ onSuccess }: { onSuccess: (card: SavedCardProps) => void }) => {
  const insets = useSafeAreaInsets();

  const handleSubmit = (values: SavedCardProps) => {
    onSuccess(values);
  };

  return (
    <View style={styles.container}>
      <View style={CUSTOM_STYLES.flex}>
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
          style={styles.container}
        >
          <Formik<SavedCardProps>
            initialValues={{
              cardNumber: "",
              expiryDate: "",
              cvv: "",
              cardHolderName: "",
              defaultCard: false,
            }}
            onSubmit={handleSubmit}
          >
            {({ values, isSubmitting, handleSubmit, dirty, setFieldValue }) => {
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <Input
                          name="cardNumber"
                          placeholder="Enter card number"
                          type="numeric"
                        />
                        <Input
                          name="expiryDate"
                          placeholder="Expiry Date (MM/YY)"
                        />
                        <Input name="cvv" placeholder="CVV" />
                        <Info text="The 3 digit number at the back of your card. Its not your pin" />
                        <Input
                          name="cardHolderName"
                          placeholder="Card Holder Name"
                        />
                        <View style={styles.divider} />

                        <TouchableOpacity
                          onPress={() =>
                            setFieldValue("defaultCard", !values.defaultCard)
                          }
                        >
                          <View style={[styles.card, CUSTOM_STYLES.row]}>
                            <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                              <View
                                style={[
                                  CUSTOM_STYLES.icon,
                                  CUSTOM_STYLES.center,
                                ]}
                              >
                                <CardIcon color={PALETTE.primary} />
                              </View>
                              <View style={{ gap: 8 }}>
                                <CustomText
                                  weight="semibold"
                                  style={{ fontSize: 13 }}
                                >
                                  Save Card
                                </CustomText>
                                <View
                                  style={[
                                    CUSTOM_STYLES.row,
                                    { gap: 10, opacity: 0.6 },
                                  ]}
                                >
                                  <CustomText
                                    weight="medium"
                                    size="xs"
                                    style={{ opacity: 0.6 }}
                                  >
                                    Will be used for future renewal
                                  </CustomText>
                                </View>
                              </View>
                            </View>

                            <View
                              style={[styles.radioOuter, CUSTOM_STYLES.center]}
                            >
                              {values.defaultCard && (
                                <View style={styles.radioInner} />
                              )}
                            </View>
                          </View>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Add Card"
                      variant="primary"
                      disabled={isSubmitting}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </KeyboardAvoidingView>
      </View>
    </View>
  );
};

const Header = ({ closeModal }: { closeModal: () => void }) => (
  <View style={[CUSTOM_STYLES.row, styles.header]}>
    <CustomText weight="semibold" size="md" style={{ letterSpacing: -0.24 }}>
      Add Card
    </CustomText>
    <Pressable onPress={closeModal} hitSlop={16}>
      <AntDesign name="close" color={PALETTE.black} size={16} />
    </Pressable>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    flex: 1,
  },

  form: { gap: 16 },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
  },
  radioOuter: {
    width: 16,
    height: 16,
    borderRadius: 50,
    borderWidth: 0.78,
    borderColor: hexToRgba(PALETTE.black, 0.1),
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 20,
    backgroundColor: PALETTE.primary,
  },
  card: {
    padding: 20,
    backgroundColor: PALETTE.grey,
    borderRadius: 6,
    justifyContent: "space-between",
  },
  footerContainer: {
    paddingTop: 10,
  },
  footer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: PALETTE.white,
  },
});

AddCardModal.displayName = "Report Issue Modal";

export default AddCardModal;
