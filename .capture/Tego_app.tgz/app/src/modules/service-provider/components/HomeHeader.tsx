import BellIcon from "@/assets/images/app-icons/bell.svg";
import BookingIcon from "@/assets/images/app-icons/booking-alt.svg";
import CalendarIcon from "@/assets/images/app-icons/calender.svg";
import ListIcon from "@/assets/images/app-icons/list.svg";
import MessageIcon from "@/assets/images/app-icons/message-alt.svg";
import NotePlus from "@/assets/images/app-icons/note-plus.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import {
  Arrow,
  CustomText,
  SkeletonBox,
  UserAvatar,
  WarningText,
} from "@/shared/components";
import { LinearGradient } from "expo-linear-gradient";
import { Pressable, StyleSheet, View } from "react-native";

type TYPES = "calender" | "booking" | "request" | "order";

import { avatars } from "@/constants/avatars";
import { AVAILABILITIES } from "@/constants/values";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { AvailabilityStatus } from "@/modules/auth/types/user.dto";
import { useAvailability } from "@/modules/profile/hooks/useAvailability";
import { router } from "expo-router";
import { useMemo, useState } from "react";
import AvailabilityModal, { Availability } from "./AvailabilityModal";

const getIcon = (type: TYPES) => {
  const props = { width: 15, height: 15, color: PALETTE.primary };
  const iconMap: Record<TYPES, React.ReactNode> = {
    calender: <CalendarIcon {...props} />,
    booking: <BookingIcon {...props} />,
    order: <ListIcon {...props} />,
    request: <NotePlus {...props} />,
  };
  return iconMap[type] ?? null;
};

const HomeHeader = ({
  requestCount,
  orderCount,
  notificationCount = 0,
  messageCount = 0,
  loading,
}: {
  requestCount: number;
  orderCount: number;
  notificationCount?: number;
  messageCount?: number;
  loading: boolean;
}) => {
  const user = useAuthStore((state) => state.user);
  if (!user) return;
  const [selectedAvailability, setSelectedAvailability] =
    useState<Availability | null>(() => {
      return (
        AVAILABILITIES.find(
          (a) => a.value.toLowerCase() === user?.availableStatus?.toLowerCase(),
        ) ?? AVAILABILITIES[0]
      );
    });

  const { ref, openModal, closeModal } = useAvailability();

  const fields = useMemo(() => {
    return [
      {
        title: "New Requests",
        handlePress: () => router.push("/(service-provider)/(tabs)/requests"),
        type: "request",
        count: requestCount,
      },
      {
        title: "Browse Jobs",
        handlePress: () =>
          router.push("/(service-provider)/(tabs)/browse-jobs"),
        type: "booking",
      },
      {
        title: "Availability",
        handlePress: openModal,
        type: "calender",
      },
      {
        title: "My Orders",
        handlePress: () => router.push("/(service-provider)/(tabs)/orders"),
        type: "order",
        count: orderCount,
      },
    ];
  }, [requestCount, orderCount]);

  const { update, isUpdating } = useAvailability();

  const handleSave = (
    available_status: AvailabilityStatus,
    accept_instant_booking: boolean,
  ) => {
    update(
      { available_status, accept_instant_booking },
      {
        onSuccess: () => {
          closeModal();
          setSelectedAvailability(
            AVAILABILITIES.find(
              (availability) => availability.value === available_status,
            ) ?? AVAILABILITIES[0],
          );
          // do whatever Screen A needs
        },
      },
    );
  };
  return (
    <>
      <AvailabilityModal
        ref={ref}
        handleSave={handleSave}
        closeModal={closeModal}
        availabilities={AVAILABILITIES}
        selectedAvailability={selectedAvailability ?? AVAILABILITIES[0]}
        instantBookingAccepted={
          user?.provider_settings?.accept_instant_booking ?? false
        }
        isUpdating={isUpdating}
      />
      <View style={styles.container}>
        <WarningText message="Complete your profile to improve visibility and start receiving more requests." />
        <View
          style={[styles.roundedCorners, { backgroundColor: PALETTE.white }]}
        >
          <LinearGradient
            colors={[
              "rgba(51, 171, 247, 0.472)",
              "rgba(255, 255, 255, 0.4012)",
              "rgba(141, 141, 141, 0.295)",
            ]}
            locations={[0, 1, 1]} // -10.13% clamped to 0, 100.41% clamped to 1, 133.56% clamped to 1
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={[
              styles.header,
              styles.roundedCorners,
              { paddingTop: 31, gap: 48 },
            ]}
          >
            <View
              style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}
            >
              <View style={[CUSTOM_STYLES.row, { gap: 11 }]}>
                <UserAvatar
                  url={user?.profilePicture}
                  name={user?.firstName || "User"}
                  size="md"
                  source={
                    avatars.find((avatar) => avatar.id === user?.avatarId)
                      ?.url ?? avatars[0].url
                  }
                />
                <View style={{ gap: 6 }}>
                  <CustomText
                    size="xs"
                    weight="semibold"
                    style={styles.username}
                  >
                    Hello {user?.firstName} ☕️
                  </CustomText>

                  {user?.provider_settings?.available_status && (
                    <Pressable onPress={openModal}>
                      <View style={[CUSTOM_STYLES.row, styles.status]}>
                        <View
                          style={[
                            CUSTOM_STYLES.dot,
                            {
                              backgroundColor:
                                user?.provider_settings?.available_status.toLowerCase() ===
                                "offline"
                                  ? PALETTE.error
                                  : user?.provider_settings?.available_status.toLowerCase() ===
                                      "busy"
                                    ? PALETTE.yellow
                                    : PALETTE.success,
                            },
                            ,
                          ]}
                        />
                        <CustomText weight="medium" style={styles.statusText}>
                          {user?.provider_settings?.available_status.toLowerCase() ===
                          "available_to_work"
                            ? "Available"
                            : user?.provider_settings?.available_status}
                        </CustomText>
                        <Arrow direction="right" size={12} />
                      </View>
                    </Pressable>
                  )}
                </View>
              </View>
              <View style={[CUSTOM_STYLES.row, { gap: 11 }]}>
                <Pressable
                  onPress={() => router.push("/(service-provider)/message")}
                  style={[
                    styles.notification,
                    CUSTOM_STYLES.center,
                    { backgroundColor: PALETTE.white },
                  ]}
                >
                  <MessageIcon color={PALETTE.black} />
                  {messageCount > 0 && (
                    <View
                      style={[
                        styles.notificationCount,
                        styles.count,
                        CUSTOM_STYLES.center,
                      ]}
                    >
                      <CustomText size="sm" style={{ color: PALETTE.white }}>
                        {messageCount > 9 ? "9+" : messageCount}
                      </CustomText>
                    </View>
                  )}
                </Pressable>
                <Pressable
                  onPress={() =>
                    router.push("/(service-provider)/notification")
                  }
                  style={styles.notification}
                >
                  <BellIcon color={PALETTE.black} />
                  {notificationCount > 0 && (
                    <View
                      style={[
                        styles.notificationCount,
                        styles.count,
                        CUSTOM_STYLES.center,
                      ]}
                    >
                      <CustomText size="sm" style={{ color: PALETTE.white }}>
                        {notificationCount > 9 ? "9+" : notificationCount}
                      </CustomText>
                    </View>
                  )}
                </Pressable>
              </View>
            </View>
            <View style={styles.fields}>
              {Array.from({ length: Math.ceil(fields.length / 2) }).map(
                (_, rowIndex) => {
                  const rowMetrics = fields.slice(
                    rowIndex * 2,
                    rowIndex * 2 + 2,
                  );

                  return (
                    <View
                      key={rowIndex}
                      style={[CUSTOM_STYLES.row, { gap: 20 }]}
                    >
                      {loading
                        ? rowMetrics.map((field, index) => (
                            <FieldSkeleton key={index} />
                          ))
                        : rowMetrics.map((field, index) => (
                            <Field
                              key={index}
                              title={field.title}
                              handlePress={field.handlePress}
                              icon={field.type as TYPES}
                              count={field.count}
                            />
                          ))}
                    </View>
                  );
                },
              )}
            </View>
          </LinearGradient>
        </View>
      </View>
    </>
  );
};

interface FieldProps {
  title: string;
  handlePress: () => void;
  icon: TYPES;
  count?: number;
}

const Field = ({ title, handlePress, icon, count }: FieldProps) => {
  return (
    <Pressable onPress={handlePress} style={{ flex: 1 }}>
      <View style={styles.fieldCard}>
        <View style={styles.fieldBody}>
          <View
            style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}
          >
            <View style={[styles.iconBox, CUSTOM_STYLES.center]}>
              {getIcon(icon as TYPES)}
            </View>

            {count !== undefined && (
              <View style={[styles.count, CUSTOM_STYLES.center]}>
                <CustomText
                  weight="semibold"
                  style={{ color: PALETTE.white, fontSize: 10 }}
                >
                  {count}
                </CustomText>
              </View>
            )}
          </View>
          <View
            style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}
          >
            <CustomText
              weight="semibold"
              style={{ fontSize: 13, letterSpacing: -0.24 }}
            >
              {title}
            </CustomText>

            <Arrow direction="right" size={16} />
          </View>
        </View>
      </View>
    </Pressable>
  );
};

const FieldSkeleton = () => {
  return (
    <View style={[styles.fieldCard, CUSTOM_STYLES.flex]}>
      <SkeletonBox width={"100%"} height={68} borderRadius={8.47} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {},

  header: {
    gap: 15,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },

  fields: {
    flex: 1,
    gap: 20,
  },

  roundedCorners: {
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    zIndex: 99,
  },

  text: {
    opacity: 0.7,
    fontSize: 13,
    color: PALETTE.white,
    width: 500,
  },

  fieldCard: {
    backgroundColor: PALETTE.whiteLight,
    padding: 16,
    borderRadius: 8.47,
  },
  fieldBody: {
    gap: 24,
  },
  notification: {
    width: 48,
    height: 48,
    borderRadius: 53,
    backgroundColor: PALETTE.white,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  notificationCount: {
    position: "absolute",
    top: -4,
    right: 0,
  },
  iconBox: {
    width: 32,
    height: 32,
    borderRadius: 64,
    backgroundColor: PALETTE.white,
  },
  count: {
    backgroundColor: PALETTE.error,
    width: 20,
    height: 20,
    borderRadius: 40,
  },
  status: {
    backgroundColor: PALETTE.black,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 50,
    gap: 4,
    alignItems: "center",
    alignSelf: "flex-start",
  },
  statusText: {
    fontSize: 10,
    color: PALETTE.white,
    textTransform: "capitalize",
    letterSpacing: -0.19,
  },
  username: {
    textTransform: "uppercase",
    opacity: 0.5,
    letterSpacing: -0.024,
  },
});

export default HomeHeader;
