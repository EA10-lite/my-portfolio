import ImageAltIcon from "@/assets/images/app-icons/image-alt.svg";
import ImageIcon from "@/assets/images/app-icons/image.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Arrow, CustomText, Info, Sheet } from "@/shared/components";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";

interface AddPictureModalProps {
  onClose?: () => void;
  addProfilePicture: () => void;
  addProfileCard: () => void;
}

const AddPictureModal = forwardRef<BottomSheetModal, AddPictureModalProps>(
  ({ onClose, addProfilePicture, addProfileCard }, ref) => {
    return (
      <Sheet ref={ref} onClose={onClose} showOverlay={false}>
        {/* BODY */}
        <View style={styles.body}>
          {/* HEADER */}
          <CustomText weight="bold" style={{ letterSpacing: -0.24 }}>
            Add Photo
          </CustomText>

          <View style={styles.body}>
            <View style={styles.content}>
              <TouchableOpacity
                onPress={addProfilePicture}
                style={[CUSTOM_STYLES.row, styles.selector]}
              >
                <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                  <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
                    <ImageIcon width={16} height={16} color={PALETTE.primary} />
                  </View>
                  <CustomText size="sm" weight="semibold">
                    Profile Picture
                  </CustomText>
                </View>
                <Arrow direction="right" />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={addProfileCard}
                style={[CUSTOM_STYLES.row, styles.selector]}
              >
                <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
                  <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
                    <ImageAltIcon
                      width={16}
                      height={16}
                      color={PALETTE.primary}
                    />
                  </View>
                  <CustomText size="sm" weight="semibold">
                    Profile Card
                  </CustomText>
                </View>
                <Arrow direction="right" />
              </TouchableOpacity>

              <Info text="Use a clear, well-lit photo with a white or plain background" />
            </View>
          </View>
        </View>
      </Sheet>
    );
  },
);

AddPictureModal.displayName = "File Selector";

export default AddPictureModal;

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  body: {
    overflow: "hidden",
    paddingBottom: 26,
    gap: 12,
  },
  content: {
    gap: 12,
  },
  selector: {
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
    justifyContent: "space-between",
    padding: 20,
  },
});
