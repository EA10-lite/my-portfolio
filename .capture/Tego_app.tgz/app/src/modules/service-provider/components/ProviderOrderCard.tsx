import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useOrderActions } from "@/modules/order/hooks/useOrderActions";
import { getProcessedOrder } from "@/modules/order/lib/orderHelpers";
import { Order } from "@/modules/order/types/order.dto";
import {
  Arrow,
  CImg,
  CustomButton,
  CustomText,
  DetailsField,
  Status,
  UserAvatar,
} from "@/shared/components";
import { useExpandableAnimation } from "@/shared/hooks/useExpandableAnimation";
import { useToastStore } from "@/shared/store/toastStore";
import { hexToRgba } from "@/shared/utils/converter";
import {
  formatCurrency,
  formatDateTime,
  truncateText,
} from "@/shared/utils/formatter";
import Ionicons from "@expo/vector-icons/Ionicons";
import { router } from "expo-router";
import { Animated, Pressable, StyleSheet, View } from "react-native";

const ProviderOrderCard = ({
  order,
  isOpen,
  onToggle,
}: {
  order: Order;
  isOpen: boolean;
  onToggle: () => void;
}) => {
  const { showToast } = useToastStore();
  const {
    showContent,
    setContentHeight,
    contentHeight,
    setShowContent,
    rotate,
    animatedHeight,
    opacityAnim,
  } = useExpandableAnimation({ initialState: false, isOpen });

  const { update, isSubmitting } = useOrderActions();

  const processedOrder = getProcessedOrder(order);

  const handleToggle = () => {
    onToggle();
  };

  const viewDetails = () => {
    router.push(`/(service-provider)/order/${order.id}`);
  };

  // change order status to in progress.
  const startWork = () => {
    update(
      { id: order.id, status: "IN_PROGRESS" },
      {
        onSuccess: (data) => {
          showToast(
            "Work has started",
            "Customer will be notified that work has started on this job",
          );
        },
      },
    );
  };
  const sendMessage = () => {
    router.push({
      pathname: `/(service-provider)/message/${order.user.id}` as any,
      params: {
        receiverId: order.user.id,
        name: `${order.user.first_name} ${order.user.last_name}`,
        avatar: order.user.profile_picture ?? "",
        isOnline: order.user ? "true" : "false",
      },
    });
  };
  const cancelApplication = () => {};

  const getStatusText = () => {
    const status = processedOrder.status.toLowerCase();
    return status === "pending"
      ? "Awaiting Start"
      : status === "confirmed"
        ? "Confirmed Order"
        : status === "in_progress"
          ? "In Progress"
          : status;
  };


  const getPrice = (): string => {
    if (processedOrder.budget) {
      return formatCurrency(processedOrder.budget);
    }
    return "N/A";
  };
  return (
    <Pressable onPress={handleToggle}>
      <View style={[CUSTOM_STYLES.card]}>
        <View style={[CUSTOM_STYLES.cardHeader]}>
          <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
            <UserAvatar
              name={`${processedOrder.user.first_name} ${processedOrder.user.last_name}`}
              url={`${processedOrder.user.profile_picture}`}
              size="xs"
            />
            <CustomText
              weight="semibold"
              style={{ fontSize: 13, lineHeight: 16, flex: 1 }}
            >
              {processedOrder.title || processedOrder.service}
            </CustomText>

            <Animated.View
              style={[
                CUSTOM_STYLES.toggleButton,
                CUSTOM_STYLES.center,
                {
                  transform: [{ rotate }],
                  backgroundColor: showContent ? PALETTE.white : PALETTE.grey01,
                },
              ]}
            >
              <Arrow direction="bottom" color={PALETTE.primary} size={20} />
            </Animated.View>
          </View>
          <View style={[CUSTOM_STYLES.row, { gap: 8 }]}>
            <View style={[CUSTOM_STYLES.row, { gap: 4, opacity: 0.5 }]}>
              <Ionicons name="location-sharp" size={16} color={PALETTE.black} />
              <CustomText weight="medium" size="xs">
                {truncateText(processedOrder.address, 20)}
              </CustomText>
            </View>
            <View style={[CUSTOM_STYLES.dot, { backgroundColor: "#E3E3E3" }]} />
            <View style={[CUSTOM_STYLES.row, { gap: 4, opacity: 0.5 }]}>
              <Ionicons name="time" size={16} color={PALETTE.black} />
              <CustomText weight="semibold" size="xs">
                {formatDateTime(processedOrder.date)}
              </CustomText>
            </View>
          </View>
        </View>
        <View style={[CUSTOM_STYLES.cardContent]}>
          <View style={styles.body}>
            <View style={[CUSTOM_STYLES.row, { gap: 8, paddingHorizontal: 20 }]}>
              <View style={styles.tag}>
                <CustomText weight="semibold" style={styles.tagText}>
                  {processedOrder.service}
                </CustomText>
              </View>
              <View style={[CUSTOM_STYLES.dot, { backgroundColor: "#E3E3E3" }]} />
              {processedOrder?.images.length > 0 && (
                <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
                  <View style={[CUSTOM_STYLES.row]}>
                    {processedOrder?.images.map((image, index) => (
                      <View
                        style={{
                          marginLeft: index === 0 ? 0 : -8,
                          zIndex: index + 1,
                        }}
                        key={index}
                      >
                        <CImg uri={image} width={80} style={styles.image} />
                      </View>
                    ))}
                  </View>
                  <CustomText size="xs" weight="medium" style={{ opacity: 0.5 }}>
                    {processedOrder.images.length} images
                  </CustomText>
                </View>
              )}
            </View>
            <Animated.View
              style={[
                {
                  height: animatedHeight,
                  overflow: "hidden",
                },
              ]}
            >
              <View
                onLayout={(event) => {
                  const height = event.nativeEvent.layout.height;

                  if (height > 0 && height !== contentHeight) {
                    setContentHeight(height);
                  }
                }}
                style={{
                  position: "absolute",
                  width: "100%",
                }}
              >
                <DetailsField
                  type="status"
                  label="Status"
                  value={processedOrder.status}
                />
                <DetailsField
                  type="address"
                  label="Location"
                  value={processedOrder.address ?? ""}
                />
                <DetailsField
                  type="budget"
                  label="Agreed Amount"
                  value={getPrice()}
                />
                <DetailsField
                  type="urgency"
                  label="Start Date"
                  isLast={true}
                  value={
                    processedOrder.date
                      ? formatDateTime(processedOrder.date)
                      : "N/A"
                  }
                />

                <View style={styles.info}>
                  <CustomText weight="medium" style={styles.infoText}>
                    {
                    processedOrder.status.toLowerCase() === "confirmed"
                      ? "Customer selected you for the job, but work hasn't started"
                      : processedOrder.status.toLowerCase() === "pending"
                        ? "Work has not started yet."
                        : processedOrder.status.toLowerCase() === "in_progress"
                          ? "Work is currently ongoing"
                          : processedOrder.status.toLowerCase() === "completed"
                            ? "Order completed successfully."
                            : processedOrder.status.toLowerCase() ===
                                "cancelled" && "This order was cancelled."
                    }
                  </CustomText>
                </View>
              </View>
            </Animated.View>
          </View>
          {showContent ? (
            <Animated.View
              style={[CUSTOM_STYLES.cardFooter, { opacity: opacityAnim }]}
            >
              {(processedOrder.status.toLowerCase() === "completed" ||
                processedOrder.status.toLowerCase() === "cancelled") && (
                <CustomButton title={"View Details"} onPress={viewDetails} />
              )}
              {(processedOrder.status.toLowerCase() === "pending" ||
                processedOrder.status.toLowerCase() === "in_progress") && (
                <View style={[CUSTOM_STYLES.row, { gap: 12 }]}>
                  <CustomButton
                    title={
                      processedOrder.status.toLowerCase() === "pending"
                        ? "Cancel"
                        : "Send Message"
                    }
                    variant="default"
                    onPress={
                      processedOrder.status.toLowerCase() === "pending"
                        ? cancelApplication
                        : sendMessage
                    }
                    style={CUSTOM_STYLES.flex}
                  />
                  <CustomButton
                    title={
                      processedOrder.status.toLowerCase() === "pending"
                        ? "Start Work"
                        : "View Details"
                    }
                    onPress={
                      processedOrder.status.toLowerCase() === "pending"
                        ? startWork
                        : viewDetails
                    }
                    style={CUSTOM_STYLES.flex}
                    loading={isSubmitting}
                  />
                </View>
              )}
            </Animated.View>
          ) : (
            <View style={[CUSTOM_STYLES.row, CUSTOM_STYLES.cardFooter]}>
              <View style={{ gap: 4 }}>
                <CustomText weight="semibold" style={{ fontSize: 13 }}>
                  {getPrice()}
                </CustomText>
              </View>
              <Status
                label={getStatusText()}
                status={
                  processedOrder.status.toLowerCase() === "confirmed"
                    ? "pending"
                    : processedOrder.status
                }
                variant={"default"}
              />
            </View>
          )}
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  body: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: hexToRgba(PALETTE.black, 0.1),
  },
  tag: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 3,
    paddingHorizontal: 10.77,
    paddingVertical: 4,
  },
  tagText: {
    textTransform: "uppercase",
    fontSize: 11,
    opacity: 0.5,
  },
  image: {
    width: 20,
    height: 20,
    borderRadius: 40,
    backgroundColor: PALETTE.grey01,
    borderWidth: 1,
    borderColor: PALETTE.gray,
  },
  info: {
    padding: 16,
    backgroundColor: PALETTE.gray,
    borderRadius: 6,
    marginHorizontal: 20,
  },
  infoText: {
    opacity: 0.5,
    fontSize: 13,
    letterSpacing: -0.24,
  },
  button: {
    width: 108,
  },
});

export default ProviderOrderCard;
