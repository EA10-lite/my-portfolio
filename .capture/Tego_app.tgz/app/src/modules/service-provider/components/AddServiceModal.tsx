import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { Service } from "@/modules/profile/types/profile.dto";
import { CustomButton, CustomText, Input, Select } from "@/shared/components";
import { useToastStore } from "@/shared/store/toastStore";
import { hexToRgba } from "@/shared/utils/converter";
import { formatCurrency } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { Formik } from "formik";
import { forwardRef, useCallback, type ReactNode } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface ServiceData {
  name: string;
  pricing_type: "FIXED" | "REQUEST_QUOTE";
  price: number;
}

interface AddServiceModalProps {
  isOpen: boolean;
  closeModal: () => void;
  addService: (data: ServiceData) => void;
  services: Service[];
}
const AddServiceModal = forwardRef<BottomSheetModal, AddServiceModalProps>(
  ({ isOpen, closeModal, addService, services }, ref) => {
    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    const { showToast } = useToastStore();
    const handleAddService = (data: ServiceData) => {
      showToast("Price Added", "Service Price Successfully Added.");
      addService(data);
    };

    return (
      <>
        <View>
          {Platform.OS === "ios" ? (
            <Modal
              visible={isOpen}
              animationType="slide"
              presentationStyle="pageSheet"
              onRequestClose={closeModal}
              style={{ borderRadius: 50 }}
            >
              <Header closeModal={closeModal} />
              <View style={[styles.content]}>
                <Form onSuccess={handleAddService} services={services} />
              </View>
            </Modal>
          ) : (
            <BottomSheetModal
              ref={ref}
              enablePanDownToClose
              backdropComponent={renderBackdrop}
              backgroundStyle={styles.container}
              handleIndicatorStyle={{ height: 0 }}
              handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
              handleComponent={() => <></>}
              snapPoints={["95%"]}
              // Let the sheet own keyboard handling instead of nesting a
              // KeyboardAvoidingView inside it — having both react to the
              // same keyboard event is what caused the Android flicker.
              keyboardBehavior="interactive"
              keyboardBlurBehavior="restore"
              android_keyboardInputMode="adjustResize"
            >
              <BottomSheetScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={styles.sheetScrollContent}
              >
                <Header closeModal={closeModal} />
                <View style={[styles.content]}>
                  <Form onSuccess={handleAddService} services={services} />
                </View>
              </BottomSheetScrollView>
            </BottomSheetModal>
          )}
        </View>
      </>
    );
  },
);

const Form = ({
  onSuccess,
  services,
}: {
  onSuccess: (data: {
    name: string;
    pricing_type: "FIXED" | "REQUEST_QUOTE";
    price: number;
  }) => void;
  services: Service[];
}) => {
  const insets = useSafeAreaInsets();

  const handleSubmit = (values: {
    service: string;
    pricingType: string;
    price: string;
  }) => {
    onSuccess({
      name: values.service,
      pricing_type: values.pricingType === "fixed" ? "FIXED" : "REQUEST_QUOTE",
      price: values.pricingType === "fixed" ? Number(values.price) : 0,
    });
  };

  return (
    <View style={styles.container}>
      <View style={CUSTOM_STYLES.flex}>
        <FormKeyboardWrapper>
          <Formik
            validateOnChange={false}
            initialValues={{
              service: "",
              pricingType: "",
              price: "",
            }}
            onSubmit={handleSubmit}
          >
            {({ values, isSubmitting, handleSubmit, dirty, setFieldValue }) => {
              return (
                <>
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    onScrollBeginDrag={Keyboard.dismiss}
                  >
                    <View style={[CUSTOM_STYLES.flex]}>
                      <View style={[CUSTOM_STYLES.flex, styles.form]}>
                        <View style={{ gap: 20 }}>
                          <Select
                            name="service"
                            placeholder="Service"
                            options={services.map((service) => ({
                              label: service.service_name,
                              value: service.service_name,
                            }))}
                            onChange={(name) => {
                              setFieldValue("service", name);
                              const selected = services.find(
                                (s) => s.service_name === name,
                              );
                              if (selected) {
                                setFieldValue(
                                  "pricingType",
                                  selected.pricing_type === "FIXED"
                                    ? "fixed"
                                    : "quote",
                                );
                                setFieldValue(
                                  "price",
                                  selected.price ? String(selected.price) : "",
                                );
                              }
                            }}
                          />
                          {values.service && (
                            <View style={{ gap: 12 }}>
                              <CustomText
                                weight="medium"
                                style={{ fontSize: 13, letterSpacing: -0.24 }}
                              >
                                Selected Service
                              </CustomText>

                              <View
                                style={[
                                  CUSTOM_STYLES.row,
                                  { gap: 12, flexWrap: "wrap" },
                                ]}
                              >
                                <TouchableOpacity
                                  style={[
                                    styles.serviceButton,
                                    CUSTOM_STYLES.row,
                                  ]}
                                  onPress={() => setFieldValue("service", "")}
                                >
                                  <CustomText
                                    weight="medium"
                                    size="xs"
                                    style={styles.serviceText}
                                  >
                                    {values.service}
                                  </CustomText>
                                  <AntDesign
                                    name="close"
                                    color={PALETTE.primary}
                                    size={10}
                                  />
                                </TouchableOpacity>
                              </View>
                            </View>
                          )}
                        </View>
                        <View style={styles.divider} />

                        <View style={{ gap: 18 }}>
                          <CustomText
                            weight="medium"
                            style={{ fontSize: 13, letterSpacing: -0.24 }}
                          >
                            Pricing Type
                          </CustomText>
                          <View style={[CUSTOM_STYLES.row, { gap: 6.45 }]}>
                            {[
                              { label: "Fixed Price", value: "fixed" },
                              { label: "Request Quote", value: "quote" },
                            ].map((type, index) => (
                              <TouchableOpacity
                                key={index}
                                onPress={() =>
                                  setFieldValue("pricingType", type.value)
                                }
                                style={[
                                  CUSTOM_STYLES.row,
                                  styles.serviceButton,
                                  {
                                    backgroundColor:
                                      values.pricingType === type.value
                                        ? hexToRgba(PALETTE.primary, 0.07)
                                        : PALETTE.grey01,
                                    borderWidth:
                                      values.pricingType === type.value ? 1 : 0,
                                  },
                                ]}
                              >
                                <View
                                  style={[
                                    styles.radioOuter,
                                    CUSTOM_STYLES.center,
                                  ]}
                                >
                                  {values.pricingType === type.value && (
                                    <View style={styles.radioInner} />
                                  )}
                                </View>
                                <CustomText
                                  weight="medium"
                                  size="xs"
                                  style={{
                                    color:
                                      values.pricingType === type.value
                                        ? PALETTE.primary
                                        : hexToRgba(PALETTE.black, 0.7),
                                  }}
                                >
                                  {type.label}
                                </CustomText>
                              </TouchableOpacity>
                            ))}
                          </View>
                        </View>
                        {values.service && <View style={styles.divider} />}

                        {values.pricingType === "fixed" && (
                          <Input
                            name="price"
                            info="Enter the amount you charge for this service"
                            type="numeric"
                            placeholder="Enter fee"
                          />
                        )}
                        {values.pricingType === "fixed" && (
                          <View style={styles.divider} />
                        )}

                        {values.service && values.pricingType && (
                          <View style={[CUSTOM_STYLES.card]}>
                            <View
                              style={[
                                CUSTOM_STYLES.cardHeader,
                                { paddingVertical: 20 },
                              ]}
                            >
                              <CustomText size="xs" weight="medium">
                                Preview
                              </CustomText>
                            </View>
                            <View
                              style={[
                                CUSTOM_STYLES.cardContent,
                                CUSTOM_STYLES.row,
                                {
                                  justifyContent: "space-between",
                                  padding: 20,
                                },
                              ]}
                            >
                              <CustomText
                                weight="semibold"
                                style={{ fontSize: 13, letterSpacing: -0.24 }}
                              >
                                {values.service}
                              </CustomText>
                              <CustomText
                                weight="semibold"
                                style={{ fontSize: 13, letterSpacing: -0.24 }}
                              >
                                {values.price
                                  ? formatCurrency(parseInt(values.price))
                                  : values.pricingType === "quote" &&
                                    "Request Quote"}
                              </CustomText>
                            </View>
                          </View>
                        )}
                      </View>
                    </View>
                  </ScrollView>
                  <View
                    style={[
                      styles.footerContainer,
                      { paddingBottom: insets.bottom || 24 },
                    ]}
                  >
                    <CustomButton
                      title="Save Price"
                      variant="primary"
                      disabled={!dirty || isSubmitting}
                      onPress={handleSubmit}
                    />
                  </View>
                </>
              );
            }}
          </Formik>
        </FormKeyboardWrapper>
      </View>
    </View>
  );
};

// KeyboardAvoidingView is only needed on iOS — the native Modal has no
// keyboard handling of its own. On Android the form renders inside
// BottomSheetModal, which already handles the keyboard via
// keyboardBehavior/android_keyboardInputMode; a second keyboard handler
// on top of that is what produced the flicker on the price input.
const FormKeyboardWrapper = ({ children }: { children: ReactNode }) =>
  Platform.OS === "ios" ? (
    <KeyboardAvoidingView
      behavior="padding"
      keyboardVerticalOffset={60}
      style={styles.container}
    >
      {children}
    </KeyboardAvoidingView>
  ) : (
    <View style={styles.container}>{children}</View>
  );

const Header = ({ closeModal }: { closeModal: () => void }) => (
  <View style={[CUSTOM_STYLES.row, styles.header]}>
    <CustomText weight="semibold" size="md" style={{ letterSpacing: -0.24 }}>
      Add Service Price
    </CustomText>
    <Pressable onPress={closeModal} hitSlop={16}>
      <AntDesign name="close" color={PALETTE.black} size={16} />
    </Pressable>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    flex: 1,
  },

  sheetScrollContent: {
    flexGrow: 1,
  },
  form: { gap: 16 },
  serviceButton: {
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.primary, 0.3),
    backgroundColor: hexToRgba(PALETTE.primary, 0.07),
    borderRadius: 53,
    padding: 7.67,
    paddingHorizontal: 11.67,
    gap: 6.9,
    alignSelf: "flex-start",
    alignItems: "center",
  },
  serviceText: {
    color: PALETTE.primary,
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
  },
  radioOuter: {
    width: 12.45,
    height: 12.45,
    borderRadius: 50,
    borderWidth: 0.78,
    borderColor: hexToRgba(PALETTE.black, 0.1),
  },
  radioInner: {
    width: 7.78,
    height: 7.78,
    borderRadius: 16,
    backgroundColor: PALETTE.primary,
  },
  footerContainer: {
    paddingTop: 10,
  },
  footer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: PALETTE.white,
  },
});

AddServiceModal.displayName = "Report Issue Modal";

export default AddServiceModal;
