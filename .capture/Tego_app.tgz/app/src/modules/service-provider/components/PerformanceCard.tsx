import ChartDown from "@/assets/images/app-icons/chart-down.svg";
import ChartUp from "@/assets/images/app-icons/chart-up.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText } from "@/shared/components";
import { StyleSheet, View } from "react-native";

import BookingIcon from "@/assets/images/app-icons/booking-alt.svg";
import ClockIcon from "@/assets/images/app-icons/clock-alt.svg";
import StarIcon from "@/assets/images/app-icons/star.svg";

type TYPES = "clock" | "rating" | "booking";

interface PerformanceCardProps {
  icon: TYPES;
  title: string;
  value: number | string;
  percentageIncrease: number;
}

const getIcon = (type: TYPES) => {
  const props = { width: 14, height: 14, color: PALETTE.primary };
  const iconMap: Record<TYPES, React.ReactNode> = {
    clock: <ClockIcon {...props} />,
    rating: <StarIcon {...props} />,
    booking: <BookingIcon {...props} />,
  };
  return iconMap[type] ?? null;
};

const PerformanceCard = ({
  icon,
  title,
  value,
  percentageIncrease,
}: PerformanceCardProps) => {
  return (
    <View style={[CUSTOM_STYLES.card, styles.container]}>
      <View style={styles.body}>
        <View style={[styles.iconBox, CUSTOM_STYLES.center]}>
          {getIcon(icon as TYPES)}
        </View>
        <View style={{ gap: 3 }}>
          <CustomText weight="semibold" size="xs" style={{ opacity: 0.5 }}>
            {title}
          </CustomText>
          <View style={[CUSTOM_STYLES.row]}>
            <CustomText weight="semibold" size="xl">
              {value}
            </CustomText>
            <View
              style={[
                CUSTOM_STYLES.row,
                { paddingHorizontal: 8, paddingVertical: 4, gap: 4 },
              ]}
            >
              {percentageIncrease > 0 ? (
                <ChartUp color={PALETTE.success} />
              ) : (
                <ChartDown color={PALETTE.error} />
              )}
              <CustomText
                style={{
                  color:
                    percentageIncrease > 0 ? PALETTE.success : PALETTE.error,
                  letterSpacing: -0.19,
                }}
                weight="semibold"
                size="xs"
              >
                {`${percentageIncrease > 0 ? "+" : ""}`}
                {percentageIncrease}
              </CustomText>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    borderRadius: 8.47,
    flex: 1,
  },
  body: { gap: 16 },
  iconBox: {
    width: 32,
    height: 32,
    borderRadius: 64,
    backgroundColor: PALETTE.white,
  },
});

export default PerformanceCard;
