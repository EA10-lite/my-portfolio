import PasswordIcon from "@/assets/images/app-icons/password.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useSupport } from "@/modules/profile/hooks/useSupport";
import { IssuePayload } from "@/modules/profile/types/profile.dto";
import {
  CustomButton,
  CustomText,
  ImagePicker,
  Input,
  SuccessSheet,
  Textbox,
} from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { Formik } from "formik";
import { forwardRef, useCallback, useRef } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ISSUE_TYPE = [
  { label: "App Issue", value: "APP_ISSUE" },
  { label: "Customer Issue", value: "CUSTOMER_ISSUE" },
  { label: "Subscription", value: "SUBSCRIPTION" },
];

interface ReportIssueProps {
  isOpen: boolean;
  closeModal: () => void;
}
const ReportIssue = forwardRef<BottomSheetModal, ReportIssueProps>(
  ({ isOpen, closeModal }, ref) => {
    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="none"
        />
      ),
      [],
    );

    const modalRef = useRef<BottomSheetModal>(null);
    const openSuccessModal = () => modalRef.current?.present();
    const closeSuccessModal = () => {
      modalRef.current?.dismiss();
      closeModal();
    };

    return (
      <>
        <SuccessSheet
          ref={modalRef}
          title="Report Submitted"
          description="Your report has  been submitted successfully."
          onContinue={closeSuccessModal}
          Icon={<PasswordIcon color={PALETTE.primary} />}
          maxWidth={242}
          buttonText="Done"
        />
        <View>
          {Platform.OS === "ios" ? (
            <Modal
              visible={isOpen}
              animationType="slide"
              presentationStyle="pageSheet"
              onRequestClose={closeModal}
              style={{ borderRadius: 50 }}
            >
              <Header closeModal={closeModal} />
              <View style={[styles.content]}>
                <Form handleSuccess={openSuccessModal} />
              </View>
            </Modal>
          ) : (
            <BottomSheetModal
              ref={ref}
              enablePanDownToClose
              backdropComponent={renderBackdrop}
              backgroundStyle={styles.container}
              handleIndicatorStyle={{ height: 0 }}
              handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
              handleComponent={() => <></>}
              snapPoints={["95%"]}
              // Let the sheet own keyboard handling instead of nesting a
              // KeyboardAvoidingView inside it — having both react to the
              // same keyboard event is what caused the Android flicker.
              keyboardBehavior="interactive"
              keyboardBlurBehavior="restore"
              android_keyboardInputMode="adjustResize"
            >
              <BottomSheetScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={styles.sheetScrollContent}
              >
                <Header closeModal={closeModal} />
                <View style={[styles.content]}>
                  <Form handleSuccess={openSuccessModal} />
                </View>
              </BottomSheetScrollView>
            </BottomSheetModal>
          )}
        </View>
      </>
    );
  },
);

const Form = ({ handleSuccess }: { handleSuccess: () => void }) => {
  const insets = useSafeAreaInsets();
  const { submit, isSubmitting: isMutating, errorMessage } = useSupport();

  const handleSubmit = (values: IssuePayload) => {
    submit(values, {
      onSuccess: (data) => {
        handleSuccess();
      },
    });
  };

  return (
    <View style={styles.container}>
      <View style={CUSTOM_STYLES.flex}>
        <Formik<IssuePayload>
          initialValues={{
            issue_type: "APP_ISSUE",
            title: "",
            issue_description: "",
            images: [],
          }}
          onSubmit={handleSubmit}
        >
          {({ values, handleSubmit, dirty, setFieldValue }) => {
            const formBody = (
              <>
                <ScrollView
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  onScrollBeginDrag={Keyboard.dismiss}
                >
                  <View style={[CUSTOM_STYLES.flex]}>
                    <View style={[CUSTOM_STYLES.flex, styles.form]}>
                      <View style={[{ gap: 16 }]}>
                        <CustomText
                          weight="semibold"
                          style={{
                            fontSize: 13,
                            letterSpacing: -0.24,
                          }}
                        >
                          Select Issue Type
                        </CustomText>

                        <View
                          style={[
                            CUSTOM_STYLES.row,
                            {
                              justifyContent: "space-between",
                              gap: 16,
                              flexWrap: "wrap",
                            },
                          ]}
                        >
                          {ISSUE_TYPE.map((issue, index) => (
                            <TouchableOpacity
                              key={index}
                              onPress={() =>
                                setFieldValue("issue_type", issue.value)
                              }
                              style={[
                                styles.issue_typeButton,
                                {
                                  backgroundColor:
                                    values.issue_type === issue.value
                                      ? hexToRgba(PALETTE.primary, 0.07)
                                      : PALETTE.grey01,
                                  borderWidth:
                                    values.issue_type === issue.value ? 1 : 0,
                                  borderColor:
                                    values.issue_type === issue.value
                                      ? PALETTE.primary
                                      : "transparent",
                                },
                              ]}
                            >
                              <CustomText
                                weight="medium"
                                size="xs"
                                style={{
                                  color:
                                    values.issue_type === issue.value
                                      ? PALETTE.primary
                                      : PALETTE.black,
                                  opacity:
                                    values.issue_type === issue.value ? 1 : 0.7,
                                }}
                              >
                                {issue.label}
                              </CustomText>
                            </TouchableOpacity>
                          ))}
                        </View>
                      </View>
                      <View style={styles.divider} />
                      <Input name="title" placeholder="Title" />
                      <Textbox
                        name="issue_description"
                        placeholder="Describe the issue"
                      />
                      {/* error message */}
                      {errorMessage && (
                        <CustomText size="xs" style={{ color: PALETTE.error }}>
                          {errorMessage}
                        </CustomText>
                      )}
                      <View style={styles.divider} />
                      <ImagePicker
                        name="images"
                        label="Upload Image"
                        maxImages={3}
                      />
                    </View>
                  </View>
                </ScrollView>
                <View
                  style={[
                    styles.footerContainer,
                    { paddingBottom: insets.bottom || 24 },
                  ]}
                >
                  <CustomButton
                    title="Submit Report"
                    variant="primary"
                    disabled={!dirty}
                    onPress={handleSubmit}
                    loading={isMutating}
                  />
                </View>
              </>
            );

            // KeyboardAvoidingView is only needed on iOS here — the native
            // Modal has no keyboard handling of its own. On Android this
            // content renders inside BottomSheetModal, which already
            // handles the keyboard via keyboardBehavior/
            // android_keyboardInputMode above; adding a second keyboard
            // handler on top of that is what produced the flicker.
            if (Platform.OS === "ios") {
              return (
                <KeyboardAvoidingView
                  behavior="padding"
                  keyboardVerticalOffset={60}
                  style={styles.container}
                >
                  {formBody}
                </KeyboardAvoidingView>
              );
            }

            return formBody;
          }}
        </Formik>
      </View>
    </View>
  );
};

const Header = ({ closeModal }: { closeModal: () => void }) => (
  <View style={[CUSTOM_STYLES.row, styles.header]}>
    <CustomText weight="semibold" size="md" style={{ letterSpacing: -0.24 }}>
      Report Issue
    </CustomText>
    <Pressable onPress={closeModal} hitSlop={16}>
      <AntDesign name="close" color={PALETTE.black} size={16} />
    </Pressable>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: PALETTE.white,
  },
  header: {
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  body: {
    gap: 24,
    marginTop: 10,
    paddingBottom: 24,
  },
  content: {
    marginTop: 24,
    paddingHorizontal: 20,
    flex: 1,
  },
  // Removed `flex: 1` here on purpose: forcing the scroll content to
  // stretch to fill height while the sheet is simultaneously animating
  // its own height (in response to the keyboard) compounds the reflow
  // that caused the flicker. Let content size itself naturally.
  sheetScrollContent: {
    flexGrow: 1,
  },
  form: { gap: 16 },
  issue_typeButton: {
    height: 37,
    borderRadius: 38,
    paddingHorizontal: 7.67,
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  divider: {
    height: 1,
    backgroundColor: PALETTE.black,
    opacity: 0.04,
  },
  footerContainer: {
    paddingTop: 10,
  },
  footer: {
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: PALETTE.white,
  },
});

ReportIssue.displayName = "Report Issue Modal";

export default ReportIssue;
