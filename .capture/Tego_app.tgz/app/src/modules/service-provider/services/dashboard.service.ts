import { api } from "@/shared/lib/api";
import { DashboardData, SubscriptionData } from "../types/dashboard.dto";

export const providerDashboard = {
  getDashboard: async () => {
    const response = await api.get<DashboardData>("/provider-dashboard");
    return response.data;
  },
  getSubscription: async () => {
    const response = await api.get<SubscriptionData>(
      "/subscriptions/my-subscription",
    );
    return response.data;
  },
};
