import { SUBSCRIPTION, URGENCY } from "@/constants/types";
import { UserType } from "@/modules/applications/utils/type";
import { Service } from "@/modules/profile/types/profile.dto";

export interface DashboardPerformanceData {
  average_rating?: {
    change_percentage: null | number;
    trend: null | number;
    value: null | number;
  };
  average_response_time?: {
    change_percentage: null | number;
    display: null | number;
    trend: null | number;
    value_seconds: null | number;
  };
  completion_percentage?: {
    change_percentage: null | number;
    trend: null | number;
    value: null | number;
  };
  message_response_rate?: {
    change_percentage: null | number;
    trend: null | number;
    value: null | number;
  };
}

export interface MatchingJobRequest {
  address: string;
  area: string;
  country: string;
  created_at: string;
  customer: {
    first_name: string;
    last_name: string;
    id: string;
    profile_picture: null | string;
  };
  date: string;
  description: string;
  end_price: number;
  id: string;
  service_category: {
    id: string;
    name: string;
  };
  start_price: number;
  state: string;
  urgency: URGENCY;
}

export interface UserBrief {
  id: string;
  first_name: string;
  last_name: string;
  user_type: UserType;
  profile_picture: string;
  average_rating: number;
}

export interface RecentServiceBookings {
  id: string;
  user: UserBrief;
  provider: UserBrief;
  service_list_item: Service;
  category: {
    id: string;
    name: string;
  };
  date: string;
  time: string;
  address: {
    state: string;
    address: string;
    country: string;
  };
  note: string;
  images: string[];
  urgency: string;
  created_at: string;
  updated_at: string;
  status: string;
}

export interface DashboardData extends DashboardPerformanceData {
  matching_job_requests: MatchingJobRequest[];
  recent_service_bookings: RecentServiceBookings[];
  order_count: number;
  direct_booking_count: number;
}

export interface SubscriptionData {
  amount: number;
  created_at: string;
  currency: "NGN";
  expires_at: null | string;
  id: string;
  payment_provider: null;
  payment_reference: null;
  plan: SUBSCRIPTION;
  started_at: string;
  status: "ACTIVE" | "INACTIVE" | "EXPIRED";
  updated_at: string;
  user_id: string;
}
