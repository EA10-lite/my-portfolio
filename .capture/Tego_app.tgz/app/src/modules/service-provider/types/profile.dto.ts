export interface SavedCardProps {
  cardNumber: string;
  cardHolderName: string;
  expiryDate: string;
  cvv: string;
  defaultCard: boolean;
}
