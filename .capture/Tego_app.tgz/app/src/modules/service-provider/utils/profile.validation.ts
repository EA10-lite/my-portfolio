import { nameField, phoneNumberField } from "@/modules/auth/utils/validation";
import * as yup from "yup";

export const personalInfoValidation = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .trim()
    .lowercase()
    .email("Enter a valid email address")
    .max(254, "Email is too long") // 👈 RFC 5321 max email length
    .test(
      "no-script",
      "Email contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),
  first_name: nameField("First name"),
  last_name: nameField("Last name"),
  phone_number: phoneNumberField,
});

export const saveCardValidation = yup.object().shape({
  cardNumber: yup.string().required(),
  cardHolderName: yup.string().required(),
  expiryDate: yup.string().required(),
  cvv: yup.string().min(3).max(3).required(),
  defaultCard: yup.boolean(),
});

export const reportIssueValidation = yup.object().shape({
  issueType: yup.string().required(),
  title: yup.string().required(),
  description: yup
    .string()
    .trim()
    .max(500, "Description must not exceed 500 characters")
    .test(
      "no-script",
      "Description contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),
  images: yup
    .array()
    .min(1, "Please upload at least one image")
    .max(9, "You can upload a maximum of 9 images")
    .required("Please upload at least one image"),
});

import * as Yup from "yup";

const SUPPORTED_IMAGE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/jpg",
  "image/webp",
];
const SUPPORTED_DOC_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

export const identityVerificationSchema = Yup.object({
  nin: Yup.string()
    .required("NIN is required")
    .matches(/^\d+$/, "NIN must contain only numbers")
    .length(11, "NIN must be exactly 11 digits"),

  bvn: Yup.string()
    .required("BVN is required")
    .matches(/^\d+$/, "BVN must contain only numbers")
    .length(11, "BVN must be exactly 11 digits"),

  personal_document: Yup.object({
    name: Yup.string().required(),
    size: Yup.number()
      .required()
      .max(MAX_FILE_SIZE, "File must be smaller than 5MB"),
    uri: Yup.string().required(),
    mimeType: Yup.string()
      .required("File type is required")
      .test(
        "supported-type",
        "Only JPEG, PNG, WEBP, PDF, or Word documents are allowed",
        (value) =>
          [...SUPPORTED_IMAGE_TYPES, ...SUPPORTED_DOC_TYPES].includes(
            value ?? "",
          ),
      ),
  })
    .nullable()
    .required("Please upload a document"),
});
