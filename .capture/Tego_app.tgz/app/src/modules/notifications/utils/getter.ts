// utils/getter.ts

import { NotificationItem } from "../types/notification.dto";

export const groupNotificationsByDate = (
  notifications: NotificationItem[],
): Record<string, NotificationItem[]> => {
  const grouped: Record<string, NotificationItem[]> = {};
  const now = new Date();

  notifications.forEach((notif) => {
    const diffDays = Math.floor(
      (now.getTime() - new Date(notif.created_at).getTime()) /
        (1000 * 60 * 60 * 24),
    );

    const label =
      diffDays === 0
        ? "Today"
        : diffDays === 1
          ? "Yesterday"
          : diffDays <= 3
            ? `${diffDays} days ago`
            : diffDays <= 7
              ? "This Week"
              : diffDays <= 14
                ? "Last Week"
                : diffDays <= 30
                  ? "This Month"
                  : "Older";

    (grouped[label] ??= []).push(notif);
  });

  return grouped;
};
