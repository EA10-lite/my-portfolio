export type NotificationTAG =
  | "bookings"
  | "payments"
  | "update"
  | "message"
  | "general"
  | "password"
  | "device"
  | "profile"
  | "subscription"
  | "verification"
  | "orders"
  | "applications"
  | "requests"
  | "review";
export type Status = "completed" | "cancelled" | "confirmed";
export type RequestStatus =
  | "submitted"
  | "offers"
  | "offer"
  | "created"
  | "closed"
  | "reminder";
export type ApplicationStatus =
  | "cancelled"
  | "declined"
  | "accepted"
  | "sent"
  | "submitted";
export type SubscriptionStatus =
  | "activated"
  | "renewed"
  | "expired"
  | "upgrade"
  | "pending";
export type OrderStatus =
  | "created"
  | "progress"
  | "cancelled"
  | "completed"
  | "confirmed"
  | "cancelled"
  | "updated";

export type BookingStatus = "confirmed" | "cancelled" | "completed";

export type VerificationStatus = "approved" | "failed";

export type NotificationStatus =
  | Status
  | SubscriptionStatus
  | VerificationStatus
  | ApplicationStatus
  | RequestStatus
  | OrderStatus;

export interface ApplicationDetails {
  title: string;
  customer: string;
  date: string;
}
export interface DeviceDetails {
  device_name: string;
  location: {
    state: string;
    country: string;
  };
  date: string;
}
export interface OrderDetails {
  title: string;
  customer: string;
  date: string;
  location: string;
  timeline: string;
  status?: OrderStatus; // 👈 optional
}

export interface ReviewDetails {
  title?: string; // 👈 optional
  customer: string;
  date: string;
  comment: string;
  rating: string;
  service: string;
}

export interface RequestDetails {
  status?: RequestStatus; // 👈 optional
  description?: string; // 👈 optional
  title: string;
  date: string;
  budget?: string; // 👈 optional
  customer: string;
  address?: string; // 👈 optional
  location?: string;
  timeline?: string; // 👈 optional
}

export interface BookingDetails {
  location: string;
  date: string;
  service: string;
  status: BookingStatus;
}

export interface NotificationItem {
  title: string;
  message: string;
  createdAt: string;
  isRead?: boolean;
  tag: NotificationTAG;
  status?: NotificationStatus;
  from?: {
    name: string;
    id: string;
    avatar: string;
  };
  booking?: BookingDetails;
  device?: DeviceDetails;
  order?: OrderDetails;
  review?: ReviewDetails;
  application?: ApplicationDetails;
  request?: RequestDetails;
}
