import { Pagination, URGENCY } from "@/constants/types";
import { UserType } from "@/modules/applications/utils/type";
import { BOOKING_STATUS } from "@/modules/booking/types/booking.dto";
import { OFFER_STATUS, ORDER_STATUS } from "@/modules/order/types/order.dto";

export type NOTIFICATION_TYPE =
    "ORDER"
    | "JOB_REQUEST"
    | "SERVICE_BOOKING"
    | "MESSAGE"
    | "REVIEW"
    | "TICKET"
    | "SUBSCRIPTION"
    | "SYSTEM"

export interface UnreadCount {
    unread_count: number;
}

export interface Notifications extends Pagination {
    notifications: NotificationItem[];
    type_counts: {
        type: NOTIFICATION_TYPE;
        unread_count: number;
    }[];
}

interface BaseNotification {
    id: string;
    type: NOTIFICATION_TYPE;
    title: string;
    body: string;
    is_read: boolean;
    read_at: string;
    reference_type: string;
    reference_id: string;
    sent_to: UserType;
    created_at: string;
}

export type NotificationItem =
    | (BaseNotification & {
            type: "SERVICE_BOOKING";
            metadata: ServiceBookingMetaData;
        })
    | (BaseNotification & {
            type: "ORDER";
            metadata: OrderMetaData;
        })
    | (BaseNotification & {
            type: "JOB_REQUEST";
            metadata: JobRequestMetaData;
        })
    | (BaseNotification & {
            type: "SUBSCRIPTION",
            metadata: SubscriptionMetaData
        })
    | (BaseNotification & {
        type: "SYSTEM",
        metadata: SystemMetaData
    })
    | (BaseNotification & {
            type: "SYSTEM",
            metadata: SystemMetaData
        })
    | (BaseNotification & {
            type: "REVIEW",
            metadata: ReviewMetaData
        })


export type SERVICE_BOOKING_TYPE =
    "new"
    | "accepted"
    | "status_changed"
    | "cancelled"
    | "rejected"
    | "new"
    | "new_offer"
    | "offer_accepted"
    | "offer_declined"
    | "offer_expiring"
    | "invite_received"
    | "invite_declined"
    | "invite_accepted"
    | "service_approved"
export interface ServiceBookingMetaData {
    bookingId: string;
    customerId: string;
    customerName: string;
    senderName: string;
    senderId: string;
    profilePicture: string;
    location: string;
    address: {
        address: string;
        state: string;
        country: string;
    }
    date: string;
    price: number;
    serviceName: string;
    providerId: string;
    messageId: string;
    status: BOOKING_STATUS;
    time: string;
    urgency: URGENCY;
    type: SERVICE_BOOKING_TYPE;
}


export type ORDER_TYPE =
    "new"
    | "cancelled"
    | "cancellation_requested"
    | "completed"
    | "completion_requested"
    | "in_progress"
    | "invite_accepted"
export interface OrderMetaData {
    orderId: string;
    status: ORDER_STATUS;
    type: ORDER_TYPE;
    serviceName: string;
    amount: number;
    currency: "NGN",
    customerName: string;
    profilePicture: string;
    customerId: string;
    providerId: string;
    title: string;
}

export type JOB_REQUEST_TYPE =
    "new_job_request"
    | "job_request_cancelled"
    | "job_request_expired"
    | "job_request_expiry_warning"
    | "new_offer"
    | "offer_accepted"
    | "offer_declined"
    | "offer_expiring"
    | "offer_expired"
    | "request_closing"
    | "request_closed"
export interface JobRequestMetaData {
    offerId: string;
    jobRequestId: string;
    orderId: string;
    status: OFFER_STATUS;
    type: JOB_REQUEST_TYPE;
    senderName: string;
    senderId: string;
    receiverName: string;
    receiverId: string;
    message: string;
    title: string;
    profilePicture: string;
}



export type SUBSCRIPTION_TYPE =
    "subscription_failed"
    | "subscription_renewed"
    | "subscription_activated"
    | "subscription_expiring"
    | "subscription_expired"
export interface SubscriptionMetaData {
    subscriptionId: string;
    userId: string;
    planCode: string,
    amount: number;
    currency: string,
    status: string,
    provider: string;
    type: SUBSCRIPTION_TYPE;
    expiresAt: string;
}



export type SYSTEM_TYPE =
    "provider_registered"
    | "verification_submitted"
    | "password_updated"
    | "profile_incomplete"
    | "verification_approved"
    | "verification_failed"
    | "identity_approved"
    | "login_detected"
    | "campaign"
export interface SystemMetaData extends DeviceMetadata {
    userId: string;
    userType: "SERVICE_PROVIDER",
    name: string,
    email: string,
    phoneNumber: string,
    type: SYSTEM_TYPE;
    status: string;
}

export interface DeviceMetadata {
    deviceId: string;
    deviceIp: string;
    deviceName: string;
    location: {
        country: string;
        latitude: 6.602428,
        longitude: 3.5324147,
        state: string;
    };
    loggedInAt: string;
}


export type REVIEW_TYPE = "review_submitted"
export interface ReviewMetaData {
    reviewId: string;
    orderId: string;
    rating: number;
    reviewText: string;
    customerName: string;
    customerId: string;
    providerId: string;
    type: REVIEW_TYPE;
}