import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { RequestDetailsBodySkeleton } from "@/modules/request-job/components/RequestDetailsSkeleton";
import { useJobRequestDetails } from "@/modules/request-job/hooks/useJobRequestDetails";
import { JobRequestDetails } from "@/modules/request-job/utils/type";
import {
  CustomButton,
  CustomText,
  DetailsField,
  ImagePreview,
} from "@/shared/components";
import { formatCurrency, formatDateTime } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { router } from "expo-router";
import { forwardRef, useCallback } from "react";
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface RequestDetailsModalProps {
  title: string;
  message: string;
  requestId: string;
  closeModal: () => void;
  isOpen: boolean;
}

const RequestDetailsModal = forwardRef<
  BottomSheetModal,
  RequestDetailsModalProps
>(({ title, message, closeModal, isOpen, requestId }, ref) => {
  const insets = useSafeAreaInsets();
  const { requestDetails, isLoading } = useJobRequestDetails(requestId);

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.89}
        pressBehavior="none"
      />
    ),
    [],
  );

  return (
    <View>
      {Platform.OS === "ios" ? (
        <Modal
          visible={isOpen}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={closeModal}
        >
          <Pressable onPress={closeModal} />
          <View style={[styles.content]}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={[{
                flexGrow: 1,
                paddingBottom: insets.bottom
              }]}
            >
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  {title}
                </CustomText>
                <Pressable onPress={closeModal} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <CustomText
                weight="medium"
                size="sm"
                style={{
                  paddingHorizontal: 20,
                  opacity: 0.5,
                  marginBottom: 12,
                }}
              >
                {message}
              </CustomText>
              {isLoading ? (
                <View style={{ paddingHorizontal: 20 }}>
                  <RequestDetailsBodySkeleton />
                </View>
              ) : (
                requestDetails && (
                  <RequestContent
                    request={requestDetails}
                    closeModal={closeModal}
                  />
                )
              )}
            </ScrollView>
          </View>
        </Modal>
      ) : (
        <BottomSheetModal
          ref={ref}
          enablePanDownToClose
          backdropComponent={renderBackdrop}
          backgroundStyle={styles.container}
          handleIndicatorStyle={{ height: 0 }}
          handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
          handleComponent={() => <></>}
          snapPoints={["95%"]}
        >
          <BottomSheetScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{
              paddingBottom: insets.bottom,
              flex: 1,
            }}
          >
            <View style={[styles.content]}>
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  {title}
                </CustomText>
                <Pressable onPress={closeModal} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <CustomText
                weight="medium"
                size="sm"
                style={{
                  paddingHorizontal: 20,
                  opacity: 0.5,
                  marginBottom: 12,
                }}
              >
                {message}
              </CustomText>
              {isLoading ? (
                <View style={{ paddingHorizontal: 20 }}>
                  <RequestDetailsBodySkeleton />
                </View>
              ) : (
                requestDetails && (
                  <RequestContent
                    request={requestDetails}
                    closeModal={closeModal}
                  />
                )
              )}
            </View>
          </BottomSheetScrollView>
        </BottomSheetModal>
      )}
    </View>
  );
});

interface RequestContentProps {
  request: JobRequestDetails;
  closeModal: () => void;
}
const RequestContent = ({ request, closeModal }: RequestContentProps) => {
  const viewRequest = () => {
    closeModal();
    router.push(`/(service-provider)/jobs/${request.id}?type=REQUEST`);
  };
  return (
    <View style={styles.details}>
      <View style={[CUSTOM_STYLES.flex]}>
        <View style={styles.group}>
          <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
            <CustomText size="sm" weight="semibold">
              Request Details
            </CustomText>
          </View>
          <View style={styles.groupBody}>
            <View style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}>
              <CustomText style={{ opacity: 0.6 }} size="sm" weight="medium">
                {request.description}
              </CustomText>
              <ImagePreview images={request.images ?? []} />
            </View>
            <View>
              <DetailsField
                type="date"
                label="Date & Time"
                value={formatDateTime(request.date)}
              />
              <DetailsField
                type="user-alt"
                label="Customer"
                value={`${request.user.first_name} ${request.user.last_name}`}
              />
              <DetailsField
                type="address"
                label="Address"
                value={request.address}
              />
              <DetailsField
                type="budget"
                label="Budget"
                value={`${formatCurrency(request.start_price)} - ${request.end_price}`}
                isLast
              />
            </View>
          </View>
        </View>
      </View>
      <CustomButton title="View Request" onPress={viewRequest} />
    </View>
  );
};

RequestDetailsModal.displayName = "Request Modal";

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  content: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    borderRadius: 0,
    flex: 1,
    overflow: "hidden",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  details: {
    paddingHorizontal: 20,
    flex: 1,
  },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
    marginTop: 12,
  },
  groupBody: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
});

export default RequestDetailsModal;
