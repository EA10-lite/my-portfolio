import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useAuthStore } from "@/modules/auth/stores/authStore";
import { useDevices } from "@/modules/profile/hooks/useDevices";
import {
  CustomButton,
  CustomText,
  DetailsField,
  Sheet,
} from "@/shared/components";
import { formatCurrency, formatDateAndTime, formatDateTime } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { router } from "expo-router";
import { forwardRef } from "react";
import { Pressable, StyleSheet, View } from "react-native";
import {
  NotificationItem,
  OrderMetaData,
  ReviewMetaData,
  ServiceBookingMetaData,
} from "../types/notification.dto";
import BookingDetailsModal from "./BookingDetails";
import RequestDetailsModal from "./RequestDetails";

interface NotificationModalProps {
  notification: NotificationItem | null;
  onClose: () => void;
  isOpen: boolean;
}

const NotificationModal = forwardRef<BottomSheetModal, NotificationModalProps>(
  ({ notification, onClose, isOpen }, ref) => {
    const { user } = useAuthStore();
    if (!notification) return null;
    const { title, body, metadata, type, created_at } = notification;
    const handleClose = () => {
      onClose();
    };

    const status = metadata?.type?.toLowerCase();

    const handleViewBooking = (id: string) => {
      onClose();
      if (user?.userType === "SERVICE_PROVIDER") {
        router.push(`/(service-provider)/request/${id}`);
      } else {
        router.push(`/(customer)/order/${id}?type=Booking`);
      }
    };

    const handleJobRequestActions = () => {
      if (type === "JOB_REQUEST" && user?.userType === "CUSTOMER") {
        if (
          metadata.type === "request_closing" ||
          metadata.type === "new_job_request"
        ) {
          onClose();
        } else {
          onClose();
          router.push(`/(customer)/request-job/${metadata.jobRequestId}`);
        }
      } else if (
        type === "JOB_REQUEST" &&
        user?.userType === "SERVICE_PROVIDER"
      ) {
        if (metadata.type === "new_offer") {
          onClose();
          router.push({
            pathname:
              `/(service-provider)/message/${metadata.jobRequestId}/offer` as any,
            params: {
              receiverId: metadata.senderId,
              name: metadata.senderName,
              avatar: "",
              isOnline: "false",
            },
          });
        }
        onClose();
      }
    };

    const handleServiceBookingActions = () => {
      if (type === "SERVICE_BOOKING" && user?.userType === "CUSTOMER") {
        if (
          metadata.type === "new_offer" ||
          metadata.type === "new"
        ) {
          onClose();
          router.push("/(customer)/(tabs)/message?type=offers")
        } else {
          onClose();
        }
      } else if (
        type === "SERVICE_BOOKING" &&
        user?.userType === "SERVICE_PROVIDER"
      ) {
        if (metadata.type === "new_offer") {
          onClose();
          router.push("/(service-provider)/message?type=offers")
        }
        onClose();
      }
    }

    const handleOrderAction = () => {
      onClose();
      if (type === "ORDER" && user?.userType == "CUSTOMER") {
        router.push(`/(customer)/order/${metadata.orderId}?type=Order`);
      } else if (type === "ORDER" && user?.userType === "SERVICE_PROVIDER") {
        router.push(`/(service-provider)/order/${metadata.orderId}`);
      }
    };

    const handleViewApplication = (id: string) => {
      onClose();
      if (user?.userType === "SERVICE_PROVIDER") {
        router.push(`/(service-provider)/order/${id}`);
      } else {
        router.push(`/(customer)/order/${id}`);
      }
    };

    if (
      type === "JOB_REQUEST" &&
      metadata.type === "new_job_request" &&
      user?.userType === "SERVICE_PROVIDER"
    )
      return (
        <RequestDetailsModal
          ref={ref}
          closeModal={handleClose}
          requestId={metadata.jobRequestId}
          title={title}
          message={body}
          isOpen={isOpen}
        />
      );
    if (
      type === "SERVICE_BOOKING" &&
      (metadata.type === "new" || metadata.type === "cancelled") &&
      user?.userType === "SERVICE_PROVIDER"
    )
      return (
        <BookingDetailsModal
          ref={ref}
          closeModal={handleClose}
          bookingId={metadata.bookingId}
          title={title}
          message={body}
          isOpen={isOpen}
        />
      );
    return (
      <Sheet ref={ref} onClose={onClose} showClose={false}>
        <Header title={title} onClose={handleClose} />

        {type === "JOB_REQUEST" &&
          (metadata.type === "new_offer" ||
            metadata.type === "new_job_request" ||
            metadata.type === "job_request_cancelled" ||
            metadata.type === "job_request_expired" ||
            metadata.type === "job_request_expiry_warning" ||
            metadata.type === "request_closing" ||
            metadata.type === "request_closed" ||
            metadata.type === "offer_expired" ||
            metadata.type === "offer_expiring") && (
            <StatusContent
              message={body}
              handlePress={handleJobRequestActions}
              buttonText={
                metadata.type === "new_job_request"
                  ? "Got it"
                  : metadata.type === "new_offer"
                    ? "View offer"
                    : "Close"
              }
            />
          )}
        {type === "SERVICE_BOOKING" &&
          (
            metadata.type === "new_offer" ||
            metadata.type === "new" ||
            metadata.type === "offer_accepted" ||
            metadata.type === "offer_declined"
          ) && (
            <StatusContent
              message={body}
              handlePress={handleServiceBookingActions}
              buttonText={
                (
                  metadata.type === "new" ||
                  metadata.type === "new_offer"
                )
                  ? "View offer"
                  : "Close"
              }
            />
          )}

        {type === "JOB_REQUEST" &&
          (metadata.type === "offer_accepted" ||
            metadata.type === "offer_declined") && (
            <ApplicationContent
              message={metadata.message}
              customer={metadata.senderName}
              date={created_at}
              title={metadata.title}
              type={metadata.type}
              handlePress={() => handleViewApplication(metadata.orderId)}
            />
          )}

        {type === "SERVICE_BOOKING" &&
          (
            metadata.type === "invite_received" ||
            metadata.type === "invite_accepted" ||
            metadata.type === "accepted" ||
            metadata.type === "rejected"
          ) && (
            <BookingContent
              message={body}
              booking={metadata}
              closeModal={() => {
                handleViewBooking(metadata.bookingId);
              }}
            />
          )}

        {type === "SERVICE_BOOKING" &&
          (
            metadata.type === "service_approved" ||
            metadata.type === "invite_declined"
          ) &&
          (
            <StatusContent
              message={body}
              closeModal={handleClose}
              buttonText={
                (
                  metadata.type === "service_approved" ||
                  metadata.type === "invite_declined"
                )
                  ? "Got it"
                  : status === "offer"
                    ? "Review Quote"
                    : metadata.type === "new_offer"
                      ? "View offer"
                      : "Close"
              }
            />
        )}

        {type === "ORDER" &&
        (metadata.type === "completion_requested" ||
        metadata.type === "cancellation_requested" ||
          metadata.type === "new") ? (
          <OrderContent
            message={body}
            order={metadata}
            date={created_at}
            handlePress={handleOrderAction}
          />
        ) : (
          type === "ORDER" && (
            <StatusContent message={body} closeModal={handleClose} />
          )
        )}

        {type === "REVIEW" && (
          <ReviewContent
            message={body}
            review={metadata}
            closeModal={handleClose}
          />
        )}

        {type === "SYSTEM" && metadata.type !== "login_detected" && (
          <StatusContent message={body} closeModal={handleClose} />
        )}
        {type === "SUBSCRIPTION" && (
          <StatusContent message={body} closeModal={handleClose} />
        )}
        {type === "SYSTEM" && metadata.type === "login_detected" && (
          <DeviceContent
            message={body}
            device={{
              deviceId: metadata?.deviceIp,
              deviceName: metadata?.deviceName,
              location: metadata.location,
              loggedInAt: metadata.loggedInAt,
            }}
          />
        )}
      </Sheet>
    );
  },
);

const Header = ({ title, onClose }: { title: string; onClose: () => void }) => (
  <View style={[CUSTOM_STYLES.row, { justifyContent: "space-between" }]}>
    <CustomText weight="semibold" size="sm" style={{ letterSpacing: -0.24 }}>
      {title}
    </CustomText>

    <Pressable onPress={onClose} style={styles.close} hitSlop={12}>
      <AntDesign name="close" size={12} color={PALETTE.black} />
    </Pressable>
  </View>
);

const StatusContent = ({
  message,
  buttonText,
  closeModal,
  handlePress,
}: {
  message: string;
  buttonText?: string;
  closeModal?: () => void;
  handlePress?: () => void;
}) => (
  <>
    <View style={styles.body}>
      <CustomText weight="medium" style={styles.bodyText}>
        {message}
      </CustomText>
    </View>

    <View style={{ marginTop: 40 }}>
      <CustomButton
        title={buttonText ?? "Got it"}
        onPress={() => {
          handlePress?.();
          closeModal?.();
        }}
      />
    </View>
  </>
);

interface OrderContentProps {
  order: OrderMetaData;
  message: string;
  date: string;
  handlePress: () => void;
}
// Order status - new, confirmed, progress, cancelled
const OrderContent = ({
  message,
  order,
  date,
  handlePress,
}: OrderContentProps) => {
  return (
    <>
      <View style={styles.body}>
        <CustomText weight="medium" style={styles.bodyText}>
          {message}
        </CustomText>

        <View style={styles.details}>
          <DetailsField
            type="note"
            label="Service"
            value={order?.serviceName ?? ""}
          />
          <DetailsField
            type="user-alt"
            label="Customer"
            value={order?.customerName ?? ""}
          />
          <DetailsField
            type="date"
            label="Date"
            value={formatDateAndTime(date)}
          />
          <DetailsField
            type="status"
            label="Status"
            value={order?.status.replaceAll("_", " ") ?? ""}
            isLast
          />
        </View>
      </View>

      <View style={{ marginTop: 40 }}>
        <CustomButton title="View Order" onPress={handlePress} />
      </View>
    </>
  );
};

// application status - cancelled, submitted, declined
interface ApplicationContentProps {
  message: string;
  title: string;
  customer: string;
  date: string;
  type: string;
  handlePress: () => void;
}
const ApplicationContent = ({
  message,
  title,
  customer,
  date,
  type,
  handlePress,
}: ApplicationContentProps) => {
  return (
    <>
      <View style={styles.body}>
        <CustomText weight="medium" style={styles.bodyText}>
          {message}
        </CustomText>

        <View style={styles.details}>
          <DetailsField type="note" label="Title" value={title ?? ""} />
          <DetailsField
            type="date"
            label="Date"
            value={formatDateAndTime(date)}
          />
          <DetailsField
            type="user-alt"
            label="Customer"
            value={customer ?? ""}
            isLast
          />
        </View>
      </View>

      <View style={{ marginTop: 40 }}>
        <CustomButton
          title={type === "offer_accepted" ? "View Order" : "Close"}
          onPress={handlePress}
        />
      </View>
    </>
  );
};

interface DetailsContentProps {
  device: {
    deviceId: string;
    deviceName: string;
    location: {
      country: string;
      state: string;
    };
    loggedInAt: string;
  };
  message: string;
}
const DeviceContent = ({ message, device }: DetailsContentProps) => {
  const { flagDevice, isFlagging } = useDevices();

  const handleFlag = () => {
    flagDevice(device.deviceId);
  };
  return (
    <>
      <View style={styles.body}>
        <CustomText weight="medium" style={styles.bodyText}>
          {message}
        </CustomText>

        <View style={styles.details}>
          <DetailsField
            type="note"
            label="Device"
            value={device?.deviceName ?? ""}
          />
          <DetailsField
            type="address"
            label="Location"
            value={`${device?.location.state}, ${device?.location.country}`}
          />
          <DetailsField
            type="date"
            label="Date"
            value={formatDateTime(device.loggedInAt)}
            isLast
          />
        </View>
      </View>

      <View style={{ marginTop: 40 }}>
        <CustomButton
          title="This wasn't me"
          onPress={handleFlag}
          loading={isFlagging}
        />
      </View>
    </>
  );
};

interface ReviewContentProps {
  review: ReviewMetaData;
  message: string;
  closeModal: () => void;
}
const ReviewContent = ({ message, review, closeModal }: ReviewContentProps) => {
  return (
    <>
      <View style={styles.body}>
        <CustomText weight="medium" style={styles.bodyText}>
          {message}
        </CustomText>

        <View style={styles.details}>
          <DetailsField
            type="user-alt"
            label="Customer"
            value={review?.customerName ?? ""}
          />
          <DetailsField
            type="star-alt"
            label="Rating"
            value={review?.rating?.toString()}
          />
          <DetailsField
            type="note"
            label="Review"
            value={review?.reviewText ?? ""}
            isLast
          />
        </View>
      </View>

      <View style={{ marginTop: 40 }}>
        <CustomButton title="Done" onPress={closeModal} />
      </View>
    </>
  );
};

interface BookingContentProps {
  message: string;
  booking: ServiceBookingMetaData;
  closeModal: () => void;
}

const BookingContent = ({
  message,
  booking,
  closeModal,
}: BookingContentProps) => (
  <>
    <View style={styles.body}>
      <CustomText weight="medium" style={styles.bodyText}>
        {message}
      </CustomText>
      <View style={styles.details}>
        <DetailsField
          type="note"
          label="Title"
          value={booking.serviceName ?? "N/A"}
        />
        <DetailsField
          type="date"
          label="Date"
          value={booking.date ? formatDateAndTime(booking.date) : "N/A"}
        />
        {booking.price && (
          <DetailsField
            type="budget"
            label="Price"
            value={formatCurrency(booking.price)}
          />
        )}
        {booking?.address?.address && (
          <DetailsField
            type="location"
            label="Address"
            value={booking?.address?.address}
          />
        )}
      </View>
      {!booking.type.includes("invite") && (
        <View style={{ marginTop: 40 }}>
          <CustomButton title="View Booking" onPress={closeModal} />
        </View>
      )}
    </View>
  </>
);

const styles = StyleSheet.create({
  close: {
    width: 24,
    height: 24,
    borderRadius: 999,
    backgroundColor: PALETTE.grey01,
    alignItems: "center",
    justifyContent: "center",
  },
  body: {
    marginTop: 12,
  },
  bodyText: {
    fontSize: 13,
    opacity: 0.5,
    letterSpacing: -0.24,
  },
  details: { backgroundColor: PALETTE.grey, marginTop: 20, borderRadius: 6 },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
    marginTop: 12,
  },
  groupBody: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
});

export default NotificationModal;
