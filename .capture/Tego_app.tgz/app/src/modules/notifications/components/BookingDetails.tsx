import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { useBookingDetails } from "@/modules/booking/hooks/useBookingDetails";
import { DirectBooking } from "@/modules/booking/types/booking.dto";
import { RequestDetailsBodySkeleton } from "@/modules/request-job/components/RequestDetailsSkeleton";
import {
  CustomButton,
  CustomText,
  DetailsField,
  ImagePreview,
} from "@/shared/components";
import { formatCurrency, formatDate } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetScrollView,
} from "@gorhom/bottom-sheet";
import { router } from "expo-router";
import { forwardRef, useCallback } from "react";
import {
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface BookingDetailsModalProps {
  title: string;
  message: string;
  bookingId: string;
  closeModal: () => void;
  isOpen: boolean;
}

const BookingDetailsModal = forwardRef<
  BottomSheetModal,
  BookingDetailsModalProps
>(({ title, message, closeModal, isOpen, bookingId }, ref) => {
  const insets = useSafeAreaInsets();
  const { requestDetails: bookingDetails, isLoading } =
    useBookingDetails(bookingId);

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
        opacity={0.89}
        pressBehavior="none"
      />
    ),
    [],
  );

  return (
    <View>
      {Platform.OS === "ios" ? (
        <Modal
          visible={isOpen}
          animationType="slide"
          presentationStyle="pageSheet"
          onRequestClose={closeModal}
        >
          <Pressable onPress={closeModal} />
          <View style={[styles.content]}>
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={[{
                flexGrow: 1,
                paddingBottom: insets.bottom
              }]}
            >
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  {title}
                </CustomText>
                <Pressable onPress={closeModal} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <CustomText
                weight="medium"
                size="sm"
                style={{
                  paddingHorizontal: 20,
                  opacity: 0.5,
                  marginBottom: 12,
                }}
              >
                {message}
              </CustomText>
              {isLoading ? (
                <View style={{ paddingHorizontal: 20 }}>
                  <RequestDetailsBodySkeleton />
                </View>
              ) : (
                bookingDetails && (
                  <BookingContent
                    booking={bookingDetails}
                    closeModal={closeModal}
                  />
                )
              )}
            </ScrollView>
          </View>
        </Modal>
      ) : (
        <BottomSheetModal
          ref={ref}
          enablePanDownToClose
          backdropComponent={renderBackdrop}
          backgroundStyle={styles.container}
          handleIndicatorStyle={{ height: 0 }}
          handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
          handleComponent={() => <></>}
          snapPoints={["95%"]}
        >
          <BottomSheetScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{
              flex: 1,
              paddingBottom: insets.bottom
            }}
          >
            <View style={[styles.content]}>
              <View style={styles.header}>
                <CustomText weight="semibold" size="md">
                  {title}
                </CustomText>
                <Pressable onPress={closeModal} hitSlop={16}>
                  <AntDesign name="close" color={PALETTE.black} size={16} />
                </Pressable>
              </View>
              <CustomText
                weight="medium"
                size="sm"
                style={{
                  paddingHorizontal: 20,
                  opacity: 0.5,
                  marginBottom: 12,
                }}
              >
                {message}
              </CustomText>
              {isLoading ? (
                <View style={{ paddingHorizontal: 20 }}>
                  <RequestDetailsBodySkeleton />
                </View>
              ) : (
                bookingDetails && (
                  <BookingContent
                    booking={bookingDetails}
                    closeModal={closeModal}
                  />
                )
              )}
            </View>
          </BottomSheetScrollView>
        </BottomSheetModal>
      )}
    </View>
  );
});

interface BookingContentProps {
  booking: DirectBooking;
  closeModal: () => void;
}
const BookingContent = ({ booking, closeModal }: BookingContentProps) => {
  const viewBooking = () => {
    closeModal();
    router.push(`/(service-provider)/request/${booking.id}`);
  };
  const hasPrice = booking.service_list_item.pricing_type === "FIXED";
  return (
    <View style={styles.details}>
      <View style={[CUSTOM_STYLES.flex]}>
        <View style={styles.group}>
          <View style={[CUSTOM_STYLES.row, styles.groupHeader]}>
            <CustomText size="sm" weight="semibold">
              Booking Details
            </CustomText>
          </View>
          <View style={styles.groupBody}>
            <View style={{ gap: 16, paddingHorizontal: 20, paddingTop: 20 }}>
              {booking.note && (
                <CustomText style={{ opacity: 0.6 }} size="sm" weight="medium">
                  {booking.note}
                </CustomText>
              )}
              <ImagePreview images={booking.images} />
            </View>
            <View>
              <DetailsField
                type="date"
                label="Date"
                value={formatDate(booking.date)}
              />
              <DetailsField type="time" label="Time" value={booking.time} />
              <DetailsField
                type="user-alt"
                label="Customer"
                value={`${booking.user.first_name} ${booking.user.last_name}`}
              />
              <DetailsField
                type="address"
                label="Address"
                value={booking.address.address}
              />
              <DetailsField
                type="budget"
                label="Budget"
                value={
                  hasPrice
                    ? formatCurrency(booking.price)
                    : "N/A"
                }
                isLast
              />
            </View>
          </View>
        </View>
      </View>
      <CustomButton title="View Booking" onPress={viewBooking} />
    </View>
  );
};

BookingDetailsModal.displayName = "Booking Modal";

const styles = StyleSheet.create({
  container: {
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  content: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    borderRadius: 0,
    flex: 1,
    overflow: "hidden",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    height: 57,
    paddingHorizontal: 20,
  },
  details: {
    paddingHorizontal: 20,
    flex: 1,
  },
  group: {
    borderRadius: 6,
    backgroundColor: PALETTE.grey,
    overflow: "hidden",
    marginTop: 12,
  },
  groupBody: {
    backgroundColor: PALETTE.white,
    borderWidth: 1,
    borderColor: "#E8E7E766",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
  },
  groupHeader: {
    backgroundColor: PALETTE.grey01,
    padding: 20,
    gap: 5,
    justifyContent: "space-between",
  },
  buttons: {
    flex: 1,
    flexDirection: "row",
  },
});

export default BookingDetailsModal;
