import BookingIcon from "@/assets/images/app-icons/booking-alt.svg";
import CheckIcon from "@/assets/images/app-icons/check-circle.svg";
import CloseIcon from "@/assets/images/app-icons/close.svg";
import CompassIcon from "@/assets/images/app-icons/compass.svg";
import CrownIcon from "@/assets/images/app-icons/crown.svg";
import QuoteIcon from "@/assets/images/app-icons/file-send.svg";
import RequestIcon from "@/assets/images/app-icons/file.svg";
import MegaphoneIcon from "@/assets/images/app-icons/megaphone.svg";
import PasswordIcon from "@/assets/images/app-icons/password-alt.svg";
import PhoneIcon from "@/assets/images/app-icons/phone-alt.svg";
import ProfileIcon from "@/assets/images/app-icons/profile-setting.svg";
import RenewIcon from "@/assets/images/app-icons/reshare-alt.svg";
import ReshareIcon from "@/assets/images/app-icons/reshare.svg";
import RocketIcon from "@/assets/images/app-icons/rocket.svg";
import VerifiedIcon from "@/assets/images/app-icons/secure.svg";
import VerificationFailedIcon from "@/assets/images/app-icons/secured-alt.svg";
import SendIcon from "@/assets/images/app-icons/send-alt.svg";
import StarIcon from "@/assets/images/app-icons/star.svg";
import ReminderIcon from "@/assets/images/app-icons/timer.svg";
import WarningIcon from "@/assets/images/app-icons/warning.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomText, UserAvatar } from "@/shared/components";
import { formatDate } from "@/shared/utils/formatter";

import { StyleSheet, TouchableOpacity, View } from "react-native";
import { NotificationItem } from "../types/notification.dto";
import { useAuthStore } from "@/modules/auth/stores/authStore";

interface NotificationProps {
  handlePress?: () => void;
  notification: NotificationItem;
}

type ICON_TYPES =
  | "verification_successful"
  | "verification_failed"
  | "login"
  | "password_change"
  | "profile"
  | "quote"
  | "send"
  | "reshare"
  | "cancelled"
  | "accepted"
  | "activated"
  | "expired"
  | "renewed"
  | "reminder"
  | "upgrade"
  | "tracker"
  | "update"
  | "review"
  | "request"
  | "booking";

const getIcon = (
  type: ICON_TYPES,
  size?: { width: number; height: number },
) => {
  const props = {
    width: size?.width || 16,
    height: size?.height || 16,
    color: PALETTE.primary,
  };
  const iconMap: Record<ICON_TYPES, React.ReactNode> = {
    profile: <ProfileIcon {...props} />,
    accepted: <CheckIcon {...props} />,
    cancelled: <CloseIcon {...props} />,
    verification_successful: <VerifiedIcon {...props} />,
    verification_failed: <VerificationFailedIcon {...props} />,
    login: <PhoneIcon {...props} />,
    password_change: <PasswordIcon {...props} />,
    quote: <QuoteIcon {...props} />,
    send: <SendIcon {...props} />,
    reshare: <ReshareIcon {...props} />,
    activated: <CrownIcon {...props} />,
    renewed: <RenewIcon {...props} />,
    expired: <WarningIcon {...props} />,
    reminder: <ReminderIcon {...props} />,
    tracker: <CompassIcon {...props} />,
    upgrade: <RocketIcon {...props} />,
    update: <MegaphoneIcon {...props} />,
    booking: <BookingIcon {...props} />,
    request: <RequestIcon {...props} />,
    review: <StarIcon {...props} />,
  };
  return iconMap[type] ?? null;
};

const Notification = ({
  notification,
  handlePress,
}: NotificationProps) => {
  const {
    title,
    body,
    created_at,
    is_read,
    type,
    metadata,
  } = notification;
  const getIconType = (): ICON_TYPES => {
    const { user } = useAuthStore();
    if (type === "REVIEW") return "review";
    if (type === "SYSTEM") {
      const status = metadata.type;
      if (status === "password_updated") return "password_change";
      if (status === "login_detected") return "login";
      if (status === "profile_incomplete") return "profile";
      if (status === "verification_failed") return "verification_failed";
      if (status === "verification_approved") return "verification_successful";
      if (status === "verification_submitted") return "verification_successful";
      if (status === "identity_approved") return "verification_successful";
    }
    if (type === "SERVICE_BOOKING" && metadata.type !== "service_approved") {
      const status = metadata.type;
      if (status === "new") return "booking";
      if (status === "new_offer") return "booking";
      else if (status === "accepted") return "booking";
      else if (status === "rejected") return "booking";
      else if (status === "invite_received") return "booking";
      else if (status === "invite_accepted") return "accepted";
      else if (status === "offer_accepted") return "accepted";
      else if (status === "offer_declined") return "cancelled";
      else if (status === "invite_declined") return "expired";
    }
    if (type === "SUBSCRIPTION") {
      const status = metadata.type;
      if (status === "subscription_renewed") return "renewed";
      else if (status === "subscription_expired") return "expired";
      else if (status === "subscription_activated") return "activated";
      else if (status === "subscription_expiring") return "tracker";
    }
    if (type === "JOB_REQUEST") {
      const status = metadata.type
      if (status === "new_job_request" && user?.userType === "CUSTOMER") return "send";
      else if (status === "new_job_request") return "request";
      else if (status === "new_offer") return "quote";
      else if (status === "job_request_cancelled") return "cancelled";
      else if (status === "offer_accepted") return "accepted";
      else if (status === "offer_declined") return "cancelled";
      else if (status === "offer_expiring") return "reminder";
      else if (status === "offer_expired") return "expired";
      else if (status === "request_closing") return "reminder";
      else if (status === "job_request_expiry_warning") return "reminder";
      else if (status === "request_closed") return "expired";
      else if (status === "job_request_expired") return "expired";
    }
    if (type === "ORDER") {
      const status = metadata.type.toLowerCase();
      if (status === "new") return "booking";
      else if (status === "in_progress") return "tracker";
      else if (status === "invite_accepted") return "accepted";
      else if (status === "cancelled") return "cancelled";
      else if (status === "cancellation_requested") return "cancelled";
      else if (status === "completed") return "accepted";
      else if (status === "completion_requested") return "accepted";
    }
    if(type === "SERVICE_BOOKING" && metadata.type === "service_approved") return "booking"
    return "update";
  };

  const hasCustomerName =
    (type === "SERVICE_BOOKING" && metadata.type !== "service_approved") ||
    type === "REVIEW" ||
    (type === "ORDER" && metadata.customerName)

  const hasProfilePicture =
    (type === "SERVICE_BOOKING" && metadata.type !== "service_approved") ||
    type == "JOB_REQUEST" ||
    (type === "ORDER" && metadata.profilePicture)



  return (
    <TouchableOpacity onPress={handlePress}>
      <View style={styles.card}>
        {hasCustomerName ? (
        // {metadata.customerName && type !== "update" ? (
          <View
            style={[styles.image, CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}
          >
            <UserAvatar
              url={hasProfilePicture ?  metadata?.profilePicture : ""}
              name={metadata?.customerName || ""} size="sm"
            />
            <View style={[styles.type, CUSTOM_STYLES.center, { opacity: 40 }]}>
              {getIcon(getIconType(), { width: 12, height: 12 })}
            </View>
          </View>
        ) : (
          <View style={[CUSTOM_STYLES.icon, CUSTOM_STYLES.center]}>
            {getIcon(getIconType())}
          </View>
        )}
        <View style={styles.row}>
          <View style={styles.left}>
            <CustomText weight="semibold" size="xs">
              {title}
            </CustomText>
            <CustomText weight="medium" size="xs" style={styles.date}>
              {formatDate(created_at)}
            </CustomText>
          </View>
          <View style={styles.right}>
            <CustomText
              weight="medium"
              size="xs"
              style={styles.message}
              numberOfLines={1}
            >
              {body}
            </CustomText>
            {!is_read && <View style={styles.dot} />}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: PALETTE.grey01,
    paddingHorizontal: 20,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  image: {
    borderWidth: 2.04,
    borderColor: PALETTE.white,
    position: "relative",
  },
  type: {
    width: 26,
    height: 26,
    borderRadius: 52,
    position: "absolute",
    backgroundColor: PALETTE.white,
    top: 20,
    left: 20,
  },
  success: {
    color: PALETTE.success,
  },
  active: {
    color: PALETTE.primary,
  },
  inactive: {
    color: PALETTE.black,
    opacity: 0.4,
  },
  row: {
    gap: 8,
    flex: 1,
  },
  right: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  left: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  date: {
    opacity: 0.5,
  },
  message: {
    opacity: 0.6,
    maxWidth: "57%",
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 10,
    backgroundColor: PALETTE.primary,
  },
});

export default Notification;
