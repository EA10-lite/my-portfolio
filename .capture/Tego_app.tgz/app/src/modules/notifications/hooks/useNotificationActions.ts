// hooks/useOrder.ts
import { queryKeys } from "@/constants/queryKeys";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { notificationService } from "../services/notification.service";
import { useToastStore } from "@/shared/store/toastStore";

export const useNotificationActions = () => {
  const { showToast } = useToastStore();
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const invalidateNotifications = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.notifications.list });
    queryClient.invalidateQueries({ queryKey: queryKeys.notifications.count });
  };

  const markNotificationAsRead = useMutation({
    mutationFn: (id: string) =>
      notificationService.markNotificationAsRead(id),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateNotifications,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });
  const markAllNotificationAsRead = useMutation({
    mutationFn: () =>
      notificationService.markAllNotificationsAsRead(),
    onMutate: () => setErrorMessage(null),
    onSuccess: invalidateNotifications,
    onError: (error) => {
      const message = getErrorMessage(error);
      setErrorMessage(message);
      showToast("Action Failed", message);
    },
  });

  return {
    markNotification: markNotificationAsRead.mutate,
    markAllNotifications: markAllNotificationAsRead.mutate,
    errorMessage,
    isSubmitting: markAllNotificationAsRead.isPending,
  };
};
