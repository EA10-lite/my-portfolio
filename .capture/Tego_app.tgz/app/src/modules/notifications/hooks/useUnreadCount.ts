import { queryKeys } from "@/constants/queryKeys";
import { useQuery } from "@tanstack/react-query";
import { notificationService } from "../services/notification.service";

export const useUnreadCount = () => {
  const unreadCount = useQuery({
    queryKey: queryKeys.notifications.count,
    queryFn: () => notificationService.getUnreadNotificationCount(),
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });

  return {
    count: unreadCount.data?.unread_count ?? 0,
  };
};
