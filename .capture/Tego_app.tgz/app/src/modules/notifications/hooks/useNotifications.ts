// hooks/useOrder.ts
import { useInfiniteQuery } from "@tanstack/react-query";
import { useState } from "react";
import { queryKeys } from "@/constants/queryKeys";
import { notificationService } from "../services/notification.service";
import { NOTIFICATION_TYPE } from "../types/notification.dto";

export const useNotifications = (type?: NOTIFICATION_TYPE) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const notifications = useInfiniteQuery({
    queryKey: queryKeys.notifications.listWith(type),
    queryFn: ({ pageParam = 1 }) =>
      notificationService.getNotifications(pageParam, 10, type),
    getNextPageParam: (lastPage) =>
      lastPage.page < lastPage.total_pages ? lastPage.page + 1 : undefined,
    initialPageParam: 1,
  });

  const data =
    notifications?.data?.pages.flatMap((page) => page.notifications) ?? [];

  const count =
    notifications?.data?.pages.flatMap((page) => page.type_counts) ?? [];

  return {
    notifications: data,
    count,
    fetchNextPage: notifications.fetchNextPage,
    hasNextPage: notifications.hasNextPage,
    isFetchingNextPage: notifications.isFetchingNextPage,
    isLoading: notifications.isLoading,
    errorMessage,
    refetch: notifications.refetch,
  };
};
