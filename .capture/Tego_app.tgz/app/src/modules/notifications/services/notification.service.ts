import { api } from "@/shared/lib/api";
import { NOTIFICATION_TYPE, Notifications, UnreadCount } from "../types/notification.dto";

export const notificationService = {
  getNotifications: async (
    page: number = 1,
    limit: number = 10,
    type?: NOTIFICATION_TYPE,
  ) => {
    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
      ...(type && { type: String(type) }),
    });
    const response = await api.get<Notifications>(
      `/users/notifications?${params.toString()}`
    );
    return response.data;
  },
  getUnreadNotificationCount: async () => {
    const response = await api.get<UnreadCount>("/users/notifications/unread-count");
    return response.data;
  },
  markNotificationAsRead: async (notificationId: string) => {
    const response = await api.patch(`/users/notifications/${notificationId}/read`);
    return response.data;
  },
  markAllNotificationsAsRead: async () => {
    const response = await api.patch("/users/notifications/read-all");
    return response.data;
  },
};
