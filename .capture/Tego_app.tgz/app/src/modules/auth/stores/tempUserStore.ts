import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

interface AuthState {
  username: string | null;
  setUserName: (name: string) => void;
  clearUserName: () => void;
}

export const useTempUserStore = create<AuthState>()(
  persist(
    (set) => ({
      username: null,
      setUserName: (name: string) => set({ username: name }),
      clearUserName: () => set({ username: null }),
    }),
    {
      name: "temp-tego-username", // storage key
      storage: createJSONStorage(() => AsyncStorage),
    },
  ),
);
