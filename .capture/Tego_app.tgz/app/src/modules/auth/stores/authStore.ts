import { socketService } from "@/modules/message/services/socket.service";
import { tokenStorage } from "@/shared/lib/tokenStorage";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { UserDTO } from "../types/user.dto";

interface AuthState {
  user: UserDTO | null;
  isLoggedIn: boolean;
  setUser: (userData: UserDTO) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoggedIn: false,
      setUser: (userData: UserDTO) => set({ user: userData, isLoggedIn: true }),
      logout: async () => {
        // On logout:
        socketService.disconnect();
        await tokenStorage.clearAll();
        set({ user: null, isLoggedIn: false });
      },
    }),
    {
      name: "tego-auth", // storage key
      storage: createJSONStorage(() => AsyncStorage),
    },
  ),
);
