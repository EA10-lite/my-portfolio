export type RouteHref = "/(customer)/(tabs)" | "/(service-provider)/(tabs)";

export type SplashAction =
  | { type: "idle" }
  | { type: "route"; href: RouteHref }
  | { type: "show-buttons" };

/**
 * Pure splash decision logic, tested deterministically.
 *
 * - Before the persisted auth store has rehydrated, `isLoggedIn`/`user` are
 *   unreliable (`false`/`null`), so we must wait — never route or show buttons.
 * - Once hydrated: a logged-in customer/provider is routed straight to their
 *   tabs; everyone else sees the sign-in buttons.
 */
export const resolveSplashAction = (
  hydrated: boolean,
  isLoggedIn: boolean,
  userType: string | undefined,
): SplashAction => {
  if (!hydrated) {
    return { type: "idle" };
  }

  if (isLoggedIn && userType === "CUSTOMER") {
    return { type: "route", href: "/(customer)/(tabs)" };
  }

  if (isLoggedIn && userType === "SERVICE_PROVIDER") {
    return { type: "route", href: "/(service-provider)/(tabs)" };
  }

  return { type: "show-buttons" };
};