import { resolveSplashAction } from "../lib/splashRouting";

describe("resolveSplashAction", () => {
  it("idles until the persisted auth store has rehydrated", () => {
    expect(resolveSplashAction(false, true, "CUSTOMER")).toEqual({
      type: "idle",
    });
    expect(resolveSplashAction(false, false, undefined)).toEqual({
      type: "idle",
    });
  });

  it("routes a hydrated customer to the customer tabs", () => {
    expect(resolveSplashAction(true, true, "CUSTOMER")).toEqual({
      type: "route",
      href: "/(customer)/(tabs)",
    });
  });

  it("routes a hydrated service provider to the provider tabs", () => {
    expect(resolveSplashAction(true, true, "SERVICE_PROVIDER")).toEqual({
      type: "route",
      href: "/(service-provider)/(tabs)",
    });
  });

  it("shows the sign-in buttons for logged-out or incomplete hydrated users", () => {
    expect(resolveSplashAction(true, false, undefined)).toEqual({
      type: "show-buttons",
    });
    expect(resolveSplashAction(true, false, "CUSTOMER")).toEqual({
      type: "show-buttons",
    });
  });

  it("never routes while logged in but missing a user type", () => {
    expect(resolveSplashAction(true, true, undefined)).toEqual({
      type: "show-buttons",
    });
  });
});