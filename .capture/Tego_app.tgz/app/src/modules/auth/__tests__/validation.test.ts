import {
  signInSchema,
  signupSchema,
  verifyPhoneNumberSchema,
} from "../utils/validation";

// Locks the signin/signup validation behavior in place while the screens are
// migrated to ScreenShell — the migration must not change what is accepted.
describe("auth validation schemas", () => {
  describe("signInSchema", () => {
    it("accepts a valid phone + password", async () => {
      await expect(
        signInSchema.validate({
          phoneNumber: "+2348012345678",
          password: "secret123",
        }),
      ).resolves.toBeTruthy();
    });

    it("rejects a missing phone number", async () => {
      await expect(
        signInSchema.validate({ password: "secret123" }),
      ).rejects.toThrow("Phone number is required");
    });

    it("rejects an invalid phone format", async () => {
      await expect(
        signInSchema.validate({
          phoneNumber: "not-a-phone",
          password: "secret123",
        }),
      ).rejects.toThrow("Enter a valid phone number");
    });

    it("rejects a password shorter than 8 characters", async () => {
      await expect(
        signInSchema.validate({ phoneNumber: "08012345678", password: "short" }),
      ).rejects.toThrow("Password must be at least 8 characters");
    });
  });

  describe("signupSchema (email step)", () => {
    it("accepts a valid email", async () => {
      await expect(
        signupSchema.validate({ email: "ada@example.com" }),
      ).resolves.toBeTruthy();
    });

    it("rejects an invalid email", async () => {
      await expect(
        signupSchema.validate({ email: "nope" }),
      ).rejects.toThrow("Enter a valid email address");
    });

    it("rejects an empty email", async () => {
      await expect(signupSchema.validate({})).rejects.toThrow(
        "Email is required",
      );
    });
  });

  describe("verifyPhoneNumberSchema", () => {
    it("accepts exactly six digits", async () => {
      await expect(
        verifyPhoneNumberSchema.validate({ code: "123456" }),
      ).resolves.toBeTruthy();
    });

    it("rejects codes other than six digits", async () => {
      await expect(
        verifyPhoneNumberSchema.validate({ code: "12345" }),
      ).rejects.toThrow("Code must be 6 digits");
    });

    it("rejects non-numeric codes", async () => {
      await expect(
        verifyPhoneNumberSchema.validate({ code: "12abcd" }),
      ).rejects.toThrow("Code must contain only numbers");
    });
  });
});