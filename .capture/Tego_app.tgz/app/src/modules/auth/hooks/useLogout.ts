// modules/auth/hooks/useLogout.ts
import { tokenStorage } from "@/shared/lib/tokenStorage";
import { router } from "expo-router";
import { useAuthStore } from "../stores/authStore";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { authService } from "../services/auth.service";
import { useToastStore } from "@/shared/store/toastStore";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";

export const useLogout = () => {
  const { logout: clearUser } = useAuthStore();
  const queryClient = useQueryClient();
  const { showToast } = useToastStore();

  const logout = useMutation({
    mutationFn: async () => {
      await authService.logout();
    },
    onSuccess: async () => {
      await tokenStorage.clearAll();
      queryClient.clear();

      clearUser();
      router.replace("/(public)/signin")
    },
    onError: (error: any) => {
      const message = getErrorMessage(error) ?? "Something went wrong";
      showToast("Delete Failed", message);
    },
  });

  return {
    logout: logout.mutate,
    isLoading: logout.isPending,
  };
};
