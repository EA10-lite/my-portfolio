// modules/auth/hooks/useAuthGuard.ts
import { router, useSegments } from "expo-router";
import { useEffect } from "react";
import { useAuthStore } from "../stores/authStore";

export const useAuthGuardOld = () => {
  const segments = useSegments();
  const { isLoggedIn, user } = useAuthStore();

  useEffect(() => {
    // Only check on route changes, not on initial load
    if (!isLoggedIn || !user) {
      // if somehow not authenticated but in app routes, redirect to splash
      if (
        segments[0] === "(customer)" ||
        segments[0] === "(service-provider)"
      ) {
        router.replace("/splash");
      }
      return;
    }

    // User is logged in — enforce role-based access
    const currentSegment = segments[0];

    if (
      user.userType === "CUSTOMER" &&
      currentSegment === "(service-provider)"
    ) {
      // customer trying to access service-provider routes
      router.replace("/(customer)/(tabs)");
    } else if (
      user.userType === "SERVICE_PROVIDER" &&
      currentSegment === "(customer)"
    ) {
      // service provider trying to access customer routes
      router.replace("/(service-provider)/(tabs)");
    }
  }, [segments, isLoggedIn, user?.userType]);
};

export const useAuthGuard = () => {
  const segments = useSegments();

  const {
    isLoggedIn,
    user,
  } = useAuthStore();

  useEffect(() => {
    if (!segments.length) return;

    const currentSegment = segments[0];

    // Not authenticated
    if (!isLoggedIn || !user) {
      if (
        currentSegment === "(customer)" ||
        currentSegment === "(service-provider)"
      ) {
        router.replace("/splash");
      }

      return;
    }

    // CUSTOMER
    if (user.userType === "CUSTOMER") {
      if (currentSegment === "(service-provider)") {
        router.replace("/(customer)/(tabs)");
      }

      return;
    }

    // SERVICE PROVIDER
    if (user.userType === "SERVICE_PROVIDER") {
      if (currentSegment === "(customer)") {
        router.replace("/(service-provider)/(tabs)");
      }

      return;
    }
  }, [
    segments,
    isLoggedIn,
    user?.userType,
  ]);
};