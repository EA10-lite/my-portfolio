import { usePushNotifications } from "@/context/PushNotificationProvider";
import { socketService } from "@/modules/message/services/socket.service";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { tokenStorage } from "@/shared/lib/tokenStorage";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { authService } from "../services/auth.service";
import { useAuthStore } from "../stores/authStore";
import { useTempUserStore } from "../stores/tempUserStore";
import {
  ACCOUNT_TYPE,
  CompleteKYC,
  CompleteRegistration,
  ProviderRegistration,
} from "../types/user.dto";
import { getDevicePayload } from "../utils/getDeviceInfo";
import { useToastStore } from "@/shared/store/toastStore";

export type SignupStep =
  | "email"
  | "verify"
  | "password"
  | "details"
  | "kyc"
  | "success";

export const useSignup = (type: ACCOUNT_TYPE = "CUSTOMER") => {
  const { setUser } = useAuthStore();
  const { showToast } = useToastStore();
  const { setUserName } = useTempUserStore();
  const { expoPushToken } = usePushNotifications();
  const [step, setStep] = useState<SignupStep>("email");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [registerToken, setRegisterToken] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [otp, setOTP] = useState<string | null>(null);

  const clearError = () => setErrorMessage(null);

  // ── Step 1: Send OTP (CUSTOMER & SERVICE PROVIDER) ────────────────────────────────
  const sendOTP = useMutation({
    mutationFn: (email: string) =>
      type === "SERVICE_PROVIDER"
        ? authService.signupProvider.sendOTP(email)
        : authService.signup.sendOTP(email),
    onMutate: clearError,
    onSuccess: (data, email) => {
      setEmail(email);
      setOTP(data.otp);
      setStep("verify");
    },
    onError: (error) => {
      const message = getErrorMessage(error)
      setErrorMessage(message)
      showToast("Action Failed", message);
    },
  });

  // ── Step 2: Verify OTP (CUSTOMER & SERVICE PROVIDER) ──────────────────────────────
  const verifyOTP = useMutation({
    mutationFn: (payload: { email: string; code: string }) =>
      type === "SERVICE_PROVIDER"
        ? authService.signupProvider.verifyOTP(payload)
        : authService.signup.verifyOTP(payload),
    onMutate: clearError,
    onSuccess: (data) => {
      setRegisterToken(data.registrationToken);
      if (type === "CUSTOMER") {
        setStep("password");
      } else {
        setStep("details");
      }
    },
    onError: (error) => {
      const message = getErrorMessage(error)
      setErrorMessage(message)
      showToast("Action Failed", message);
    },
  });

  // ── Step 3: Create Password (CUSTOMER) ─────────────────────────
  const createPassword = useMutation({
    mutationFn: async (password: string) => {
      const devicePayload = await getDevicePayload(); // 👈 fetch fresh
      return authService.signup.createPassword(
        { password, ...devicePayload },
        registerToken!,
      );
    },
    onMutate: clearError,
    onSuccess: (data) => {
      setRegisterToken(data.registrationToken);
      setStep("details");
    },
    onError: (error) => {
      const message = getErrorMessage(error)
      setErrorMessage(message)
      showToast("Action Failed", message);
    },
  });

  // ── Step 4: Submit Details (CUSTOMER) ─────────────────────────
  const completeRegistration = useMutation({
    mutationFn: (payload: CompleteRegistration) =>
      authService.signup.complete(
        {
          ...payload,
          ...(expoPushToken && {
            push_token: {
              token: expoPushToken,
              type: "EXPO",
            },
          }),
        },
        registerToken!,
      ),
    onMutate: clearError,
    onSuccess: (data) => {
      setEmail(null);
      setRegisterToken(null);
      // After successful signup:
      setUser(data.user);
      setUserName(`${data.user.firstName} ${data.user.lastName}`);
      setStep("success");
      tokenStorage.set(data.accessToken);
      tokenStorage.setRefreshToken(data.refreshToken);
      socketService.connect();
    },
    onError: (error) => {
      const message = getErrorMessage(error)
      setErrorMessage(message)
      showToast("Action Failed", message);
    },
  });

  // ── Step 3: Submit Details (SERVICE PROVIDER) ─────────────────────────
  const completeProviderRegistration = useMutation({
    mutationFn: async (payload: ProviderRegistration) => {
      const devicePayload = await getDevicePayload(); // 👈 fetch fresh
      return authService.signupProvider.complete(
        {
          ...payload,
          ...devicePayload,
          ...(expoPushToken && {
            push_token: {
              token: expoPushToken,
              type: "EXPO",
            },
          }),
        },
        registerToken!,
      );
    },
    onMutate: clearError,
    onSuccess: async (data) => {
      setEmail(null);
      setRegisterToken(data.accessToken);
      tokenStorage.set(data.accessToken);
      tokenStorage.setRefreshToken(data.refreshToken);
      // After successful signup:
      socketService.connect();

      setStep("kyc");
      setUser(data.user);
      setUserName(`${data.user.firstName} ${data.user.lastName}`);
    },
    onError: (error) => {
      const message = getErrorMessage(error)
      setErrorMessage(message)
      showToast("Action Failed", message);
    },
  });

  // ── Step 4: Submit KYC (SERVICE PROVIDER) ─────────────────────────
  const completeKYC = useMutation({
    mutationFn: (payload: CompleteKYC) =>
      authService.signupProvider.submitKYC(payload, registerToken!),
    onMutate: clearError,
    onSuccess: () => {
      setEmail(null);
      setRegisterToken(null);
      setStep("success");
    },
    onError: (error) => {
      const message = getErrorMessage(error)
      setErrorMessage(message)
      showToast("Action Failed", message);
    },
  });

  const isPending =
    sendOTP.isPending ||
    verifyOTP.isPending ||
    createPassword.isPending ||
    completeRegistration.isPending ||
    completeProviderRegistration.isPending ||
    completeKYC.isPending;

  const resetStep = () => {
    setStep("email");
  };

  return {
    step,
    errorMessage,
    isPending,
    resetStep,
    sendOTP: sendOTP.mutate,
    verifyOTP: verifyOTP.mutate,
    createPassword: createPassword.mutate,
    completeRegistration: completeRegistration.mutate,
    completeProviderRegistration: completeProviderRegistration.mutate,
    completeKYC: completeKYC.mutate,
    otp,
    email,
  };
};
