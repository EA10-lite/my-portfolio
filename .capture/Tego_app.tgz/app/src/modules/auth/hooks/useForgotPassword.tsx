import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { authService } from "../services/auth.service";

type ForgotPasswordStep = "email" | "verify" | "password" | "success";

export const useForgotPassword = () => {
  const [step, setStep] = useState<ForgotPasswordStep>("email");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [resetToken, setResetToken] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  const clearError = () => setErrorMessage(null);

  // ── Step 1: Send OTP ────────────────────────────────
  const sendOTP = useMutation({
    mutationFn: (email: string) =>
      authService.resetPassword.requestOTP(email),
    onMutate: clearError,
    onSuccess: (data, email) => {
      setEmail(email);
      setStep("verify");
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  // ── Step 2: Verify OTP ──────────────────────────────
  const verifyOTP = useMutation({
    mutationFn: (payload: { email: string; code: string }) =>
      authService.resetPassword.verifyOTP(payload),
    onMutate: clearError,
    onSuccess: (data) => {
      setResetToken(data.resetToken);
      setStep("password");
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  // ── Step 3: Create Password ─────────────────────────
  const createPassword = useMutation({
    mutationFn: (newPassword: string) =>
      authService.resetPassword.createPassword(newPassword, resetToken!),
    onMutate: clearError,
    onSuccess: (data) => {
      console.log("CREATE PASSWORD SUCCESS:", data);
      setEmail(null);
      setResetToken(null);
      setStep("success");
    },
    onError: (error) => setErrorMessage(getErrorMessage(error)),
  });

  const isPending =
    sendOTP.isPending || verifyOTP.isPending || createPassword.isPending;

  const resetStep = () => {
    setStep("email");
  };

  return {
    step,
    errorMessage,
    isPending,
    resetStep,
    sendOTP: sendOTP.mutate,
    verifyOTP: verifyOTP.mutate,
    createPassword: createPassword.mutate,
  };
};
