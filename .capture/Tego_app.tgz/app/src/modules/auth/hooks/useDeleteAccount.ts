import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { tokenStorage } from "@/shared/lib/tokenStorage";
import { useMutation } from "@tanstack/react-query";
import { useAuthStore } from "../stores/authStore";
import { useTempUserStore } from "../stores/tempUserStore";
import { authService } from "../services/auth.service";
import { useToastStore } from "@/shared/store/toastStore";


export const useDeleteAccount = () => {
  const { logout } = useAuthStore();
  const { clearUserName } = useTempUserStore();
  const { showToast } = useToastStore();

  const deleteAccount = useMutation({
    mutationFn: async () => {
        await authService.deleteAccount();
    },
    onSuccess: async () => {
      tokenStorage.clearAll()
      clearUserName(); // delete-account clears everything, incl. remembered name
      logout();
    },
    onError: (error: any) => {
      const message = getErrorMessage(error) ?? "Something went wrong";
      showToast("Delete Failed", message);
    },
  });

  return {
    deleteAccount: deleteAccount.mutate,
    isDeleting: deleteAccount.isPending,
  };
};
