import { socketService } from "@/modules/message/services/socket.service";
import { getErrorMessage } from "@/shared/lib/getErrorMessage";
import { tokenStorage } from "@/shared/lib/tokenStorage";
import { useMutation } from "@tanstack/react-query";
import { router } from "expo-router";
import { useState } from "react";

import { usePushNotifications } from "@/context/PushNotificationProvider";
import { authService } from "../services/auth.service";
import { useAuthStore } from "../stores/authStore";
import { useTempUserStore } from "../stores/tempUserStore";
import { getDevicePayload } from "../utils/getDeviceInfo";

export type LoginPayload = {
  email: string;
  password: string;
};

export const useSignin = () => {
  const { setUser } = useAuthStore();
  const { setUserName } = useTempUserStore();
  const { expoPushToken } = usePushNotifications();

  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: async ({ email, password }: LoginPayload) => {
      const { device_ip, device_name, location } = await getDevicePayload();

      return authService.login({
        email,
        password,
        device_ip,
        device_name,
        location,
        ...(expoPushToken && {
          push_token: {
            token: expoPushToken,
            type: "EXPO",
          },
        }),
      });
    },

    onMutate: () => {
      setErrorMessage(null);
    },

    onSuccess: async (data) => {
      /**
       * 1. Save authentication tokens FIRST.
       */
      await tokenStorage.set(data.accessToken);
      await tokenStorage.setRefreshToken(data.refreshToken);

      /**
       * 2. Update authenticated user.
       *
       * This is important because PushNotificationProvider
       * is watching the auth store.
       */
      setUser({
        ...data.user,
        user_details: data.user_details,
      });

      /**
       * 3. Persist user's name.
       */
      setUserName(`${data.user.firstName} ${data.user.lastName}`);

      /**
       * 4. Connect socket after authentication.
       */
      socketService.connect();

      /**
       * 5. Navigate based on user type.
       *
       * Push token registration is NOT handled here.
       *
       * Once setUser() updates the auth store, the
       * PushNotificationProvider will detect the authenticated
       * user and automatically register the Expo token.
       */
      switch (data.user.userType) {
        case "CUSTOMER":
          router.replace("/(customer)/(tabs)");
          break;

        case "SERVICE_PROVIDER":
          router.replace("/(service-provider)/(tabs)");
          break;

        default:
          break;
      }
    },

    onError: (error: any) => {
      const message = getErrorMessage(error) ?? "Something went wrong";

      setErrorMessage(message);
    },
  });

  return {
    ...mutation,
    errorMessage,
  };
};
