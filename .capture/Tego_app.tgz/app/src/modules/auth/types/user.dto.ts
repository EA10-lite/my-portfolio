export type GENDER = "MALE" | "FEMALE";
export type ACCOUNT_TYPE = "CUSTOMER" | "SERVICE_PROVIDER";

export type AvailabilityStatus = "offline" | "busy" | "available_to_work";

export interface UserDTO {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  gender: GENDER;
  userType: ACCOUNT_TYPE;
  profilePicture?: string;
  pictureCard?: string;
  availableStatus?: AvailabilityStatus;
  is_onboarded: boolean;
  onboarding_gaps: string[];
  provider_settings?: {
    accept_instant_booking: boolean;
    available_status: AvailabilityStatus;
    created_at: string;
    language: "english_uk" | "english_us";
    updated_at: string;
    user_id: string;
  };
  user_details?: {
    notification_settings: {
      booking_updates: boolean;
      promotions_n_offers: boolean;
      messages: boolean;
    };
    user_address: {
      address: string;
      street_name: string;
      nearby_landmark: string;
      city: string;
      state: string;
      longitude: null | number;
      latitude: null | number;
      country: string;
    };
    bookings_settings: {
      new_booking_request: boolean;
      booking_confirmations: boolean;
      booking_reminders: boolean;
      nearby_services: boolean;
      new_categories: boolean;
      service_started: boolean;
      booking_completed: boolean;
    };
  };
  avatarId?: string;
  avatarPublicId?: string;
  phoneNumber: string;
  isPhoneVerified: boolean;
  isEmailVerified: boolean;
  createdAt: string;
  updatedAt: string;
  isVerified?: boolean;
  address?: string;
  nin?: string;
  bvn?: string;
}

export interface DeviceInfo {
  device_ip: string;
  device_name: string;
  location: {
    longitude: number;
    latitude: number;
    state: string;
    country: string;
  };
}

export interface Push {
  push_token?: {
    token: string;
    type: "EXPO";
  };
}

export interface SendTokenPayload {
  push_token: {
    token: string;
    type: "EXPO";
  };
  device_ip: string;
  device_name: string;
}

export interface SignInPayload extends DeviceInfo, Push {
  email: string;
  password: string;
}

export interface VerifyOTP {
  email: string;
  code: string;
}

export interface CreatePassword extends DeviceInfo {
  password: string;
}

export interface CompleteRegistration extends Push {
  firstName: string;
  lastName: string;
  gender: GENDER;
  userType: ACCOUNT_TYPE;
  phoneNumber: string;
}

export interface ProviderRegistration extends Push {
  firstName: string;
  lastName: string;
  confirmPassword: string;
  password: string;
  userType: ACCOUNT_TYPE;
  phoneNumber: string;
  gender: GENDER;
}

export interface CompleteProviderRegistration
  extends DeviceInfo, ProviderRegistration {}

export interface CompleteKYC {
  nin: string;
  bvn: string;
}

// RESPONSESES

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  user: UserDTO;
  user_details?: UserDTO["user_details"];
}

export interface RegistrationToken {
  registrationToken: string;
}

export interface RefreshToken {
  refreshToken: string;
}

export interface CompleteRegistrationResponse {
  accessToken: string;
  refreshToken: string;
  user: UserDTO;
}

// RESET PASSWORD
export interface ResetToken {
  resetToken: string;
}

export interface ResetPassword {
  message: string;
}
