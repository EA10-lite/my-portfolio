import Contact from "@/assets/images/app-icons/contact.svg";
import Password from "@/assets/images/app-icons/password.svg";
import Mail from "@/assets/images/app-icons/mail.svg";
import Profile from "@/assets/images/app-icons/profile.svg";
import { PALETTE } from "@/constants/colors";
import { SPACING } from "@/constants/spacing";
import { CustomText } from "@/shared/components";
import { hexToRgba } from "@/shared/utils/converter";
import Feather from "@expo/vector-icons/Feather";
import Ionicons from "@expo/vector-icons/Ionicons";
import { LinearGradient } from "expo-linear-gradient";
import { StyleSheet, View } from "react-native";
import { ACCOUNT_TYPE } from "../types/user.dto";

interface VerificationProps {
  currentStep: "email" | "password" | "details" | "kyc";
  type: ACCOUNT_TYPE;
}

const customerSteps = [
  { label: "Verify Email Address", value: "email", Icon: Mail },
  { label: "Create Password", value: "password", Icon: Password },
  { label: "Personal Details", value: "details", Icon: Profile },
];

const providerSteps = [
  { label: "Verify Email Address", value: "email", Icon: Mail },
  { label: "Set up Profile", value: "details", Icon: Profile },
  { label: "Verify Identity", value: "kyc", Icon: Contact },
];

const customerStepOrder = ["email", "password", "details"];
const providerStepOrder = ["email", "details", "kyc"];

const SignupVerificationSteps = ({
  currentStep = "email",
  type,
}: VerificationProps) => {
  const currentStepIndex =
    type === "CUSTOMER"
      ? customerStepOrder.indexOf(currentStep)
      : providerStepOrder.indexOf(currentStep);

  const steps = {
    CUSTOMER: customerSteps,
    SERVICE_PROVIDER: providerSteps,
  };

  return (
    <View style={styles.trackerContainer}>
      {steps[type].map((item, index) => {
        const isPast = index < currentStepIndex;
        const isCurrent = index === currentStepIndex;
        const isLast = index === steps[type].length - 1;

        return (
          <View key={item.value}>
            <View style={styles.row}>
              {/* Icon column */}
              <View style={styles.iconColumn}>
                <View
                  style={[
                    styles.iconContainer,
                    isPast && styles.iconContainerPast,
                    isCurrent && styles.iconContainerCurrent,
                  ]}
                >
                  {isPast ? (
                    <Ionicons
                      name="checkmark-circle"
                      size={20}
                      color={PALETTE.success}
                    />
                  ) : isCurrent ? (
                    <item.Icon width={18} height={18} color={PALETTE.primary} />
                  ) : (
                    <Feather name="loader" size={20} color={PALETTE.primary} />
                  )}
                </View>

                {/* Connector line */}
                {!isLast && (
                  <LinearGradient
                    colors={["rgba(51, 171, 247, 1)", "rgba(51, 171, 247, 0)"]}
                    locations={[0, 1]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 0, y: 1 }}
                    style={styles.connector}
                  />
                )}
              </View>

              {/* Label */}
              <CustomText size="sm" weight="medium" style={styles.label}>
                {item.label}
              </CustomText>
            </View>
          </View>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  trackerContainer: {
    padding: SPACING.lg,
    backgroundColor: PALETTE.white50,
    borderWidth: 1,
    borderColor: hexToRgba(PALETTE.primary, 0.1),
    borderRadius: 6,
  },
  row: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 16,
  },
  iconColumn: {
    alignItems: "center",
  },
  iconContainer: {
    width: 24,
    height: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  iconContainerPast: {},
  iconContainerCurrent: {},
  connector: {
    width: 2,
    height: 26,
    backgroundColor: hexToRgba(PALETTE.primary, 0.3),
    marginVertical: 2,
  },
  label: {
    marginTop: 2, // vertically aligns label with icon center
    color: PALETTE.black,
  },
  labelPending: {
    opacity: 0.4,
  },
});

export default SignupVerificationSteps;
