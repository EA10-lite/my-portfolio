import SuccessIconFrame from "@/assets/images/app-icons/success-frame.svg";
import { PALETTE } from "@/constants/colors";
import { CustomButton, CustomText } from "@/shared/components";
import AntDesign from "@expo/vector-icons/AntDesign";
import { ImageBackground } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useEffect, useRef } from "react";
import {
  Animated,
  Easing,
  Modal,
  Pressable,
  StyleSheet,
  View,
} from "react-native";

interface SuccessModalProps {
  visible: boolean;
  title: string;
  description: string;
  type?: string;
  onContinue: () => void;
  buttonText?: string;
  variant?: "default" | "primary";
  closeModal?: () => void;
}

const SuccessModal = ({
  visible,
  title,
  description,
  type = "signup",
  onContinue,
  buttonText = "Continue",
  variant = "default",
  closeModal,
}: SuccessModalProps) => {
  const slideAnim = useRef(new Animated.Value(300)).current;
  const backdropAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(backdropAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 400,
          easing: Easing.out(Easing.back(1.2)),
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(backdropAnim, {
          toValue: 0,
          duration: 250,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 300,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible]);

  const getCloseIconModal = () => {
    return closeModal ? (
      <Pressable
        hitSlop={12}
        onPress={closeModal}
        style={[styles.close, styles.center]}
      >
        <AntDesign name="close" size={12} />
      </Pressable>
    ) : null;
  };

  return (
    <Modal visible={visible} transparent animationType="none">
      <Animated.View style={[styles.backdrop, { opacity: backdropAnim }]}>
        <Pressable style={StyleSheet.absoluteFill} />
      </Animated.View>

      <View style={styles.bottomWrapper}>
        <Animated.View
          style={[styles.container, { transform: [{ translateY: slideAnim }] }]}
        >
          <LinearGradient
            colors={[
              "rgba(51, 171, 247, 0.232)",
              "rgba(255, 255, 255, 0)", // fade to fully transparent instead
            ]}
            locations={[0, 1]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={[styles.header, styles.center]}
          >
            {type === "signup" ? (
              <ImageBackground
                source={require("../../../../assets/images/app-images/confetti.png")}
                style={[StyleSheet.absoluteFill, styles.center]}
              >
                <SuccessIconFrame />
                {getCloseIconModal()}
              </ImageBackground>
            ) : (
              <>
                <SuccessIconFrame />
                {getCloseIconModal()}
              </>
            )}
          </LinearGradient>

          <View style={styles.body}>
            <View style={styles.textContainer}>
              <CustomText weight="bold" size="lg" style={styles.title}>
                {title}
              </CustomText>
              <CustomText weight="medium" size="sm" style={styles.description}>
                {description}
              </CustomText>
            </View>

            <CustomButton
              title={buttonText}
              onPress={onContinue}
              variant={variant}
              style={styles.button}
            />
          </View>
        </Animated.View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.45)",
  },
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 24, // top radius instead of bottom
    borderTopRightRadius: 24,
    paddingBottom: 36,
    gap: 16,
    overflow: "hidden",
  },
  header: {
    width: "100%",
    height: 207,
    position: "relative",
  },
  center: {
    alignItems: "center",
    justifyContent: "center",
  },
  close: {
    width: 24,
    height: 24,
    borderRadius: 50,
    backgroundColor: PALETTE.white,
    position: "absolute",
    right: 20,
    top: 32,
  },
  body: {
    paddingHorizontal: 20,
  },
  textContainer: {
    alignItems: "center",
    marginTop: 24,
    gap: 8,
  },
  title: {
    textAlign: "center",
  },
  description: {
    textAlign: "center",
    opacity: 0.7,
    maxWidth: 280,
    lineHeight: 21,
  },
  button: {
    width: "100%",
    marginTop: 48,
  },
  bottomWrapper: {
    flex: 1,
    justifyContent: "flex-end", // pushes modal to bottom
  },
});

export default SuccessModal;
