import { PALETTE } from "@/constants/colors";
import { CustomText } from "@/shared/components";
import { Pressable, StyleSheet, View } from "react-native";
import { SvgProps } from "react-native-svg";

interface AccountTypeOptionProps {
  title: string;
  description: string;
  Icon: React.FC<SvgProps>;
  isSelected?: boolean;
  onPress: () => void;
  loading?: boolean;
}

const AccountTypeOption = ({
  title,
  description,
  Icon,
  isSelected,
  onPress,
}: AccountTypeOptionProps) => {
  return (
    <Pressable onPress={onPress}>
      <View
        style={[
          styles.container,
          {
            borderColor: isSelected ? PALETTE.borderPrimary30 : PALETTE.white50,
            backgroundColor: isSelected ? PALETTE.white50 : PALETTE.whiteLight,
          },
        ]}
      >
        <View style={styles.topContent}>
          <View style={styles.iconContainer}>
            <Icon />
          </View>
          <View
            style={[
              styles.outerContainer,
              { borderColor: isSelected ? PALETTE.primary : PALETTE.black },
            ]}
          >
            {isSelected && <View style={styles.innerContainer} />}
          </View>
        </View>
        <CustomText weight="bold" size="sm" style={{ marginBottom: 4 }}>
          {title}
        </CustomText>
        <CustomText size="sm" style={{ lineHeight: 19 }}>
          {description}
        </CustomText>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    borderRadius: 6,
    borderWidth: 1,
  },
  topContent: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    justifyContent: "space-between",
  },
  outerContainer: {
    width: 16,
    height: 16,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 1000,
  },
  innerContainer: {
    width: 10,
    height: 10,
    borderRadius: 297,
    backgroundColor: PALETTE.primary,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 1000,
    backgroundColor: PALETTE.primaryLight,
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
    marginBottom: 6,
  },
});

export default AccountTypeOption;
