import * as yup from "yup";

// ── Reusable field validators ────────────────────────
export const phoneNumberField = yup
  .string()
  .required("Phone number is required")
  .trim()
  .matches(/^\+?[0-9]{8,15}$/, "Enter a valid phone number"); // E.164 max is 15 digits

const passwordField = yup
  .string()
  .required("Password is required")
  .min(8, "Password must be at least 8 characters")
  .max(64, "Password is too long") // prevent DoS via bcrypt long password attack
  .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
  .matches(/[a-z]/, "Password must contain at least one lowercase letter")
  .matches(/\d/, "Password must contain at least one number")
  .matches(
    /[^A-Za-z0-9]/,
    "Password must contain at least one special character",
  )
  .test(
    "no-spaces",
    "Password must not contain spaces",
    (value) => !/\s/.test(value ?? ""),
  );

export const nameField = (label: string) =>
  yup
    .string()
    .required(`${label} is required`)
    .trim()
    .min(2, `${label} must be at least 2 characters`)
    .max(50, `${label} is too long`)
    .matches(/^[a-zA-Z\s'-]+$/, `${label} contains invalid characters`)
    .test(
      "no-script",
      `${label} contains invalid characters`,
      (value) => !/<|>|&|script/i.test(value ?? ""), // 👈 block script injection attempts
    );

// ── Schemas ──────────────────────────────────────────
export const signInSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .trim()
    .lowercase()
    .email("Enter a valid email address")
    .max(254, "Email is too long") // 👈 RFC 5321 max email length
    .test(
      "no-script",
      "Email contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),
  password: yup
    .string()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters")
    .max(64, "Password is too long"),
  // 👆 no complexity rules on signin — only on signup
});

export const signupSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .trim()
    .lowercase()
    .email("Enter a valid email address")
    .max(254, "Email is too long") // 👈 RFC 5321 max email length
    .test(
      "no-script",
      "Email contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),
});

export const verifyPhoneNumberSchema = yup.object().shape({
  code: yup
    .string()
    .required("Verification code is required")
    .length(6, "Code must be 6 digits")
    .matches(/^\d{6}$/, "Code must contain only numbers"), // 👈 stricter — exactly 6 digits only
});

export const createPasswordSchema = yup.object().shape({
  password: passwordField,
  confirmPassword: yup
    .string()
    .required("Please confirm your password")
    .oneOf([yup.ref("password")], "Passwords do not match"),
});

export const setupProfileSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .trim()
    .lowercase()
    .email("Enter a valid email address")
    .max(254, "Email is too long") // 👈 RFC 5321 max email length
    .test(
      "no-script",
      "Email contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),
  firstName: nameField("First name"),
  lastName: nameField("Last name"),
  gender: yup
    .string()
    .required("Gender is required")
    .oneOf(["MALE", "FEMALE"], "Please select a valid gender"),
});

export const setupProviderProfileSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .trim()
    .lowercase()
    .email("Enter a valid email address")
    .max(254, "Email is too long") // 👈 RFC 5321 max email length
    .test(
      "no-script",
      "Email contains invalid characters",
      (value) => !/<|>|script/i.test(value ?? ""),
    ),
  firstName: nameField("First name"),
  lastName: nameField("Last name"),
  password: passwordField,
  confirmPassword: yup
    .string()
    .required("Please confirm your password")
    .oneOf([yup.ref("password")], "Passwords do not match"),
});

export const kycSchema = yup.object().shape({
  nin: yup
    .string()
    .trim()
    .required("NIN is required")
    .matches(/^\d{11}$/, "NIN must be exactly 11 digits"),

  bvn: yup
    .string()
    .trim()
    .required("BVN is required")
    .matches(/^\d{11}$/, "BVN must be exactly 11 digits"),
});

export const forgotPasswordSchema = yup.object().shape({
  phoneNumber: phoneNumberField,
});

export const resetPasswordSchema = yup.object().shape({
  password: passwordField,
  confirmPassword: yup
    .string()
    .required("Please confirm your password")
    .oneOf([yup.ref("password")], "Passwords do not match"),
});
