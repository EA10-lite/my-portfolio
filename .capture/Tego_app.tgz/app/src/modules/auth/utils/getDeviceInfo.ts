import * as Device from "expo-device";
import * as Location from "expo-location";
import * as Network from "expo-network"; // 👈 more reliable than ipify

export const getDevicePayload = async () => {
  let device_ip = "";
  let device_name =
    Device.modelName ??
    Device.designName ??  // 👈 use designName as fallback instead of deprecated deviceName
    "Unknown Device";

  let location = {
    latitude: 0,
    longitude: 0,
    country: "",
    state: "",
  };

  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === "granted") {
      const currentLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      const { latitude, longitude } = currentLocation.coords;
      const [place] = await Location.reverseGeocodeAsync({ latitude, longitude });
      location = {
        latitude,
        longitude,
        country: place?.country ?? "",
        state: place?.region ?? "",
      };
    }
  } catch (e) {
    console.log("[device] location error:", e);
  }

  try {
    // Option 1 — expo-network (no external API call needed)
    const ip = await Network.getIpAddressAsync();
    device_ip = ip ?? "";
  } catch {
    try {
      // Option 2 — fallback to ipify
      const response = await fetch("https://api.ipify.org?format=json");
      const ipData = await response.json();
      device_ip = ipData.ip ?? "";
    } catch (e) {
      console.log("[device] IP fetch error:", e);
    }
  }

  return { device_ip, device_name, location };
};