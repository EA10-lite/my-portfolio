// src/modules/auth/services/refreshToken.service.ts

import axios from "axios";
import { LoginResponse, RefreshToken } from "../types/user.dto";

export const refreshTokenRequest = async (data: RefreshToken) => {
  const response = await axios.post<LoginResponse>(
    `${process.env.EXPO_PUBLIC_BASE_URL}/users/refresh`,
    data,
  );

  return response.data;
};
