import { api } from "@/shared/lib/api";
import {
  CompleteKYC,
  CompleteProviderRegistration,
  CompleteRegistration,
  CompleteRegistrationResponse,
  CreatePassword,
  LoginResponse,
  RegistrationToken,
  ResetPassword,
  ResetToken,
  SignInPayload,
  SendTokenPayload,
  VerifyOTP,
} from "../types/user.dto";

export const authService = {
  login: async (data: SignInPayload) => {
    const response = await api.post<LoginResponse>("/users/login", data);
    return response.data;
  },

  signup: {
    sendOTP: async (email: string) => {
      const { data } = await api.post("/users/register/request-otp", {
        email,
      });
      return data;
    },
    verifyOTP: async (payload: VerifyOTP) => {
      const { data } = await api.post("/users/register/verify-otp", payload);
      return data;
    },
    createPassword: async (data: CreatePassword, registerToken: string) => {
      const response = await api.post("/users/register/set-password", data, {
        headers: {
          Authorization: `Bearer ${registerToken}`, // 👈 pass as Bearer
        },
      });
      return response.data;
    },
    complete: async (payload: CompleteRegistration, registerToken: string) => {
      const { data } = await api.post<CompleteRegistrationResponse>(
        "/users/register/complete",
        payload,
        {
          headers: {
            Authorization: `Bearer ${registerToken}`,
          },
        },
      );
      return data;
    },
  },

  signupProvider: {
    sendOTP: async (email: string) => {
      const { data } = await api.post("/auth/register/provider/request-otp", {
        email,
      });
      return data;
    },
    verifyOTP: async (payload: VerifyOTP) => {
      const { data } = await api.post<RegistrationToken>(
        "/auth/register/provider/verify-otp",
        payload,
      );
      return data;
    },
    complete: async (
      payload: CompleteProviderRegistration,
      registerToken: string,
    ) => {
      const { data } = await api.post<CompleteRegistrationResponse>(
        "/auth/register/provider/setup-profile",
        payload,
        {
          headers: {
            Authorization: `Bearer ${registerToken}`,
          },
        },
      );
      return data;
    },
    submitKYC: async (payload: CompleteKYC, registerToken: string) => {
      const { data } = await api.post<CompleteRegistrationResponse>(
        "/users/provider-verification",
        payload,
        {
          headers: {
            Authorization: `Bearer ${registerToken}`,
          },
        },
      );
      return data;
    },
  },

  resetPassword: {
    requestOTP: async (email: string) => {
      const response = await api.post("/users/reset-password/request-otp", {
        email,
      });
      return response.data;
    },
    verifyOTP: async (data: VerifyOTP) => {
      const response = await api.post<ResetToken>(
        "/users/reset-password/verify-otp",
        data,
      );
      return response.data;
    },
    createPassword: async (newPassword: string, resetToken: string) => {
      const response = await api.post<ResetPassword>(
        "/users/reset-password/confirm",
        { newPassword },
        {
          headers: {
            Authorization: `Bearer ${resetToken}`, // 👈 pass as Bearer
          },
        },
      );
      return response.data;
    },
  },

  deleteAccount: async () => {
    const response = await api.delete("/users/me");
    return response.data;
  },

  sendToken: async (data: SendTokenPayload) => {
    const response = await api.post("/users/devices/push-token", data);
    return response.data;
  },

  logout: async () => {
    const response = await api.post("/users/logout",);
    return response.data;
  }
};
