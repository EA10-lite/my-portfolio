export { default as CompletePayment } from "./CompletePayment";
