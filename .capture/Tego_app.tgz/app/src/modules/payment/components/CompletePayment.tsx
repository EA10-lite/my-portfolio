import CopyIcon from "@/assets/images/app-icons/copy.svg";
import TimerIcon from "@/assets/images/app-icons/timer.svg";
import { PALETTE } from "@/constants/colors";
import { CUSTOM_STYLES } from "@/constants/styles";
import { CustomButton, CustomText } from "@/shared/components";
import { formatCurrency } from "@/shared/utils/formatter";
import AntDesign from "@expo/vector-icons/AntDesign";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import * as Clipboard from "expo-clipboard";
import { LinearGradient } from "expo-linear-gradient";
import { forwardRef, useCallback } from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { FullWindowOverlay } from "react-native-screens";

interface ProviderProfileModalProps {
  closeModal: () => void;
  onPress: () => void;
  countdown: string;
  isExpired: boolean;
}

const copyToClipboard = async (text: string) => {
  await Clipboard.setStringAsync(text);
};

const CompletePayment = forwardRef<BottomSheetModal, ProviderProfileModalProps>(
  ({ closeModal, countdown, isExpired, onPress }, ref) => {
    const handleSheetChanges = useCallback(
      (index: number) => {
        // closed
        if (index === -1) {
          closeModal?.();
        }
      },
      [closeModal],
    );

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.89}
          pressBehavior="close"
        />
      ),
      [],
    );

    return (
      <BottomSheetModal
        ref={ref}
        enableDynamicSizing
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}
        containerComponent={(props) =>
          Platform.OS === "ios" ? (
            <FullWindowOverlay>{props.children}</FullWindowOverlay>
          ) : (
            <>{props.children}</>
          )
        }
        backgroundStyle={styles.container}
        handleIndicatorStyle={{ height: 0 }}
        handleStyle={{ padding: 0, margin: 0, overflow: "hidden" }}
        handleComponent={() => <></>}
      >
        {/* Sheet */}
        <BottomSheetView style={styles.sheetWrapper}>
          {/* Sheet */}
          <View style={styles.sheetWrapper}>
            <View style={[styles.sheet]}>
              <LinearGradient
                colors={[
                  "rgba(51, 171, 247, 0.232)",
                  "rgba(255, 255, 255, 0.255)",
                ]}
                locations={[0, 1]}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={styles.header}
              >
                {/* 👇 custom drag handle INSIDE gradient */}
                <View style={styles.dragWrapper}>
                  <View style={styles.dragHandle} />
                </View>

                {/* Close button */}
                <Pressable
                  style={[styles.closeButton, CUSTOM_STYLES.center]}
                  onPress={closeModal}
                  hitSlop={12}
                >
                  <AntDesign name="close" size={12} />
                </Pressable>

                <View style={styles.textContent}>
                  <CustomText size="sm" weight="semibold">
                    Transfer Details
                  </CustomText>
                  <CustomText
                    weight="medium"
                    style={{ opacity: 0.5, fontSize: 13 }}
                  >
                    Make a transfer to the account details below to complete
                    your payment.
                  </CustomText>
                </View>
              </LinearGradient>

              <View style={styles.body}>
                <View style={styles.fields}>
                  <Field label="Bank Name" value="United Bank For Africa" />
                  <View style={styles.detailDivider} />
                  <Field label="Account Number" value="2021150994" isCopy />
                  <View style={styles.detailDivider} />
                  <Field label="Amount" value={formatCurrency(50000)} isCopy />
                  <View style={styles.detailDivider} />
                  <Field label="Account Name" value="Emmanuel Anyigor" />
                </View>
                <View style={[styles.timer, CUSTOM_STYLES.row]}>
                  <View
                    style={[
                      CUSTOM_STYLES.icon,
                      CUSTOM_STYLES.center,
                      { backgroundColor: PALETTE.white },
                    ]}
                  >
                    <TimerIcon color={PALETTE.primary} />
                  </View>
                  {!isExpired ? (
                    <CustomText
                      size="xs"
                      weight="semibold"
                      style={styles.timerText}
                    >
                      Complete Transfer in{" "}
                      <CustomText color="error" size="xs" weight="semibold">
                        {countdown}
                      </CustomText>{" "}
                      to complete Ciroma's Booking
                    </CustomText>
                  ) : (
                    <CustomText
                      size="xs"
                      weight="semibold"
                      style={styles.timerText}
                    >
                      Webhook session expired, Please close the modal to try
                      again.
                    </CustomText>
                  )}
                </View>

                <View style={styles.statsRow}>
                  <StatCard label="1" value="Transfer exact amount" />
                  <StatCard label="2" value='Tap "Payment  done" below' />
                  <StatCard label="3" value="Booking gets confirmed" />
                </View>
              </View>

              {/* Actions */}
              <View style={styles.actionRow}>
                <View style={styles.actionButton}>
                  <CustomButton
                    title="Payment Done"
                    variant={isExpired ? "secondary" : "primary"}
                    disabled={isExpired}
                    onPress={onPress}
                  />
                </View>
              </View>
            </View>
          </View>
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

interface DataFields {
  label: string;
  value: string;
}

const StatCard = ({ label, value }: DataFields) => (
  <View style={styles.statCard}>
    <CustomText
      size="md"
      weight="bold"
      color="primary"
      style={styles.statValue}
    >
      {label}
    </CustomText>
    <CustomText size="xs" weight="regular" style={styles.statLabel}>
      {value}
    </CustomText>
  </View>
);

interface FieldProps extends DataFields {
  isCopy?: boolean;
}
const Field = ({ label, value, isCopy }: FieldProps) => {
  return (
    <View style={[styles.field, CUSTOM_STYLES.row]}>
      <CustomText weight="medium" style={{ fontSize: 13, opacity: 0.5 }}>
        {label}
      </CustomText>
      <View style={[CUSTOM_STYLES.row, { gap: 4 }]}>
        <CustomText weight="semibold" style={{ fontSize: 13 }}>
          {value}
        </CustomText>
        <TouchableOpacity onPress={() => copyToClipboard(value)}>
          {isCopy && (
            <CopyIcon width={20} height={20} color={PALETTE.primary} />
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: PALETTE.white,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
  },

  // ── Sheet ─────────────────────────────────────────
  sheetWrapper: {
    flex: 1,
    paddingTop: 0,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    overflow: "hidden",
    // justifyContent: "flex-end",
  },
  sheet: {
    paddingBottom: 36,
    gap: 16,
  },

  dragWrapper: {
    position: "absolute",
    top: 18,
    alignSelf: "center",
    zIndex: 10,
  },

  dragHandle: {
    width: 37,
    height: 4,
    borderRadius: 2,
    backgroundColor: PALETTE.white,
  },

  // ── Close button ──────────────────────────────────
  closeButton: {
    width: 24,
    height: 24,
    borderRadius: 50,
    backgroundColor: PALETTE.white,
    position: "absolute",
    right: 20,
    top: 32,
    zIndex: 10,
  },

  header: {
    paddingHorizontal: 20,
  },
  textContent: {
    gap: 6,
    paddingTop: 47,
  },
  body: {
    paddingHorizontal: 20,
    gap: 16,
  },

  // ── Actions ───────────────────────────────────────
  actionRow: {
    paddingHorizontal: 20,
    gap: 16,
    flexDirection: "row",
  },
  actionButton: {
    flex: 1,
  },

  // Field
  fields: {
    backgroundColor: PALETTE.grey01,
    borderRadius: 6,
  },
  field: {
    justifyContent: "space-between",
    padding: 16,
  },
  detailDivider: {
    opacity: 0.04,
    backgroundColor: PALETTE.black,
    height: 1,
  },

  // TIMER
  timer: {
    borderRadius: 6,
    borderWidth: 1,
    borderColor: PALETTE.primary14,
    padding: 20,
    backgroundColor: "#F5FBFF",
    gap: 13,
  },
  timerText: {
    letterSpacing: -0.0024,
    flexShrink: 1,
    lineHeight: 18,
  },

  // ── Stats ─────────────────────────────────────────
  statsRow: {
    flexDirection: "row",
    gap: 7,
    borderRadius: 10,
    overflow: "hidden",
  },
  statCard: {
    flex: 1,
    backgroundColor: PALETTE.grey01,
    minHeight: 75,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    overflow: "hidden",
    padding: 18,
  },
  statValue: {
    textAlign: "center",
  },
  statLabel: {
    opacity: 0.6,
    textAlign: "center",
  },
});

export default CompletePayment;
