import { create } from "zustand";

export type PAYMENT_TYPE = "card" | "bank";

interface BookingState {
  paymentMethod: PAYMENT_TYPE;
  setPaymentMethod: (type: PAYMENT_TYPE) => void;
}

const initialState = {
  paymentMethod: "bank" as PAYMENT_TYPE,
};

export const usePaymentStore = create<BookingState>((set) => ({
  ...initialState,
  setPaymentMethod: (paymentMethod: PAYMENT_TYPE) => set({ paymentMethod }),
}));
