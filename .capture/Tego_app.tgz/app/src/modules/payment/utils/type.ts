export type PAYMENT_TYPE = "card" | "bank";
