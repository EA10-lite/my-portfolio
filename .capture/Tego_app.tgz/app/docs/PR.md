# Pull Request Guide

## When a PR is created

- **One PR per priority level** — a single PR covering all the issues under that
  priority (e.g. all three Priority 1 issues in one PR). Do not open one PR per
  issue commit.
- The PR is opened only after **every issue under that priority has been
  implemented, tested, and manually verified** by the developer.
- Target branch: **`api-integration`**. Feature branches are created off
  `open-code-optimisation` (kept in sync with `api-integration`) so the PR diff
  stays clean.

## What every PR description must contain

Use this structure, section by section:

1. **What was fixed**
   A concise, plain-language list of the changes. Reference files/screens only
   where it helps navigation. Do not paste code dumps.

2. **Why**
   The problem being solved — ideally one line of impact: e.g. "every scroll
   frame wrote the offset into a zustand store, re-rendering the whole tree
   (an N-frame per second re-render)."

3. **How the fix works** (only when non-obvious)
   Short explanation of the mechanism (state machine, thresholds, event-driven
   hydration, etc.) so a reviewer can reason about edge cases.

4. **How to test**
   Step-by-step manual verification, in the order a QA person would follow.
   Include both roles (customer / service provider) where relevant, and call
   out platform-specific behavior (e.g. iOS-only status bar).

5. **Observability**
   Anything a reviewer or QA can use to confirm the fix beyond eyeballing it:
   - log lines / dev tools to watch,
   - before/after performance numbers (e.g. "time-to-interactive 1.7s → 0.4s"),
   - which test files cover the logic and the `npm test` result,
   - known limitations (e.g. platform-specific behavior that cannot be verified).

6. **Out of scope / notes**
   Pre-existing issues deliberately left alone, and anything a reviewer should
   ignore (e.g. unrelated dirty files in the working tree).

## Example skeleton

```md
## What was fixed
...

## Why
...

## How it works
...

## How to test
1. ...
2. ...

## Observability
- `npm test` — N passing.
- Time-to-interactive: before X ms → after Y ms.

## Notes
- Pre-existing issue A left untouched (see docs/PERFORMANCE.md).
```

## Defintition of done before opening a PR

- [ ] All priority issues implemented on their branches.
- [ ] `npm test` green.
- [ ] `npx tsc --noEmit` shows no new errors (pre-existing unrelated errors only).
- [ ] Manual verification completed and confirmed.
- [ ] PR description follows this template.