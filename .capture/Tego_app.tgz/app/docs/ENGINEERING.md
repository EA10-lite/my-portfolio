# Engineering Guidelines

## Running tests

```bash
npm test          # jest (jest-expo preset)
npx tsc --noEmit  # TypeScript typecheck
```

There is no ESLint config in the repo; `npm run lint` (`expo lint`) will prompt to
generate one. Do not add one without a ticket.

## Testing rules

- Tests live in `**/__tests__/**/*.test.ts(x)` — this is the only glob Jest matches
  (`package.json` → `jest.testMatch`). A test file outside that layout is not run.
- Tests must live inside `src/`. Jest-expo transpiles files under `src/`; files
  imported from outside the project (e.g. `/tmp`) fail to transpile.
- Prefer **pure, exported decision logic** over rendering hooks in tests. Extract
  the state machine / thresholds from a hook into a pure function
  (e.g. `resolveScrollState` in `src/shared/hooks/useHideTabBarOnScroll.ts`) and
  unit test it deterministically. Keep React store/hook wiring thin.
- Do not write per-frame store updates in tests or wait on RNTL `renderHook`
  with React 19 — it is unreliable. Assert on store state via
  `useXYZStore.getState()`.

## State management (zustand)

- **Always subscribe with a selector**: `useStore((s) => s.someField)`. Calling
  `useStore()` with no selector subscribes to the *entire* store and re-renders
  the component on *any* field change.
- Prefer multiple narrow stores (or narrow fields) over one large object that
  changes frequently.
- zustand notifies subscribers on every `set()`, even when the value is
  unchanged. **Guard writes against the current value**
  (`if (getState().x !== next) setX(next)`) to avoid publishing no-op updates.

## Scroll / gesture handlers

- Scroll handlers fire ~60x/sec during a pan. Never write to a store inside
  `onScroll` unless the value genuinely changed (see rule above); instead flip a
  boolean at a threshold so the store publishes at most once per transition.
- Do not wrap a `ScrollView` (or `KeyboardAwareScrollView`) in a `Pressable`
  for tap-to-dismiss; it blocks the scroll responder. Prefer
  `keyboardDismissMode="on-drag"` on the scroll view.

## Touch targets

- Interactive controls must be ~48×48dp of touchable area (iOS + Android guidance).
  Compute a `hitSlop` from the control's **actual drawn size**, not a guess:
  `symmetricHitSlop(size, target)` in `src/shared/utils/touchTarget.ts`
  (`target` defaults to 48). It returns `Math.ceil((target - size) / 2)` and `0`
  when the control already meets the target — never add unnecessary slop.
- `hitSlop` never changes the drawn layout, so a stopgap fix is a plain
  `hitSlop` on the pressable. Controls already ≥ target (e.g. `CustomButton`
  with `size="md"`, ~50px) carry **no** hitSlop.
- Split the padding when a symmetric bump would collide with an adjacent control
  (an icon beside a thumbnail/44px button). Pass an asymmetric
  `{ top, bottom, left, right }` instead of a single number and keep the
  collision side small. `effectiveTouchSize({width, height}, hitSlop)`
  (`touchTarget.ts`) proves the effective rect — import it in tests.
- Prefer fewer, larger tap areas over many small ones. If a 48×48 box would
  steal from a label row, expand the row's containers (padding) instead of
  piling hidden slop.
- Don't blind-apply values; verify with a component test that asserts the
  `hitSlop` prop on the rendered pressable (see `__tests__/CustomButton.test.tsx`).

## ScreenShell / keyboard handling

- Screens with inputs render through `ScreenShell` (`src/shared/containers/`):
  it uses a `KeyboardAwareScrollView` internally with `enableOnAndroid`,
  `keyboardDismissMode="on-drag"`, `keyboardShouldPersistTaps="handled"`,
  `extraScrollHeight` (default 20) and `extraHeight` (default 100), so tapping
  out of a focused input dismisses the keyboard and the submit control sits
  above it. Direct, per-screen `KeyboardAwareScrollView` usage is an exception,
  not the norm — reuse the shell.
- Pass the screen's primary CTA through the `footer` prop: it renders the button
  below the scrollable area (safe-area aware) so it doesn't scroll under the
  keyboard or the home indicator.
- `scroll={false}` renders a plain, non-scrolling view (no keyboard behavior) —
  for screens that manage their own layout.
- Bottom-sheet components and gesture-driven modals interact with
  `react-native-gesture-handler`/reanimated and are not wrapped in a scroll
  view; keep the `KeyboardAwareScrollView` off them and let them manage
  `keyboardShouldPersistTaps` themselves.

## Images

- **Never render a remote Cloudinary URL with a raw `react-native` `<Image>`** when
  its display size is known. Use `<CImg uri={...} width={...} />`
  (`src/shared/components/general/CImg.tsx`): it applies a sized
  `w_,f_auto,q_auto` transform via `transformImageUrl` (`cloudinary.ts`) and
  renders through `expo-image` for disk caching.
- `width` is in display px; pass the largest size the image will show at
  (~4× the container for crispness on 3x screens; the chat lightbox caps at 1280).
- `transformImageUrl` passes through local/non-Cloudinary URIs untouched — safe
  to call on any `uri` string.
- Uploads are bound client-side: `prepareImageForUpload` resizes to ≤1600px and
  compresses to JPEG inside the Cloudinary upload functions. Do not bypass it
  (e.g. don't build your own upload helper with raw `quality: 1`).
- Batch uploads run **sequentially**, not `Promise.all` — keeps memory flat on
  ≤3-image uploads. Keep it that way.
- Picker defaults are `quality: 0.8` (`useFilePicker`); lower it per call site
  only, never raise it.
- **Never re-upload an already-remote URL.** Many flows first upload a local
  file to Cloudinary and then pass the resulting `secure_url` to a mutation that
  uploads again. Central rule: local `file://` URIs get uploaded; anything
  matching `^https?://` is treated as already-remote and passed through.
  - One-shot uploads: `uploadProfilePicture` in `useProfileActions.ts` accepts
    either a local URI (uploads) or a remote URL (passes through).
  - Batch edits (request-job create/update): use `uploadManyKeepingRemote`
    (`cloudinary.ts`) — it uploads only local URIs and keeps remote URLs,
    preserving order. Its `uploadSingle` parameter is injectable for tests.

## Form performance

- Shared shared-form controls (`_components/forms/*`) render through Formik
  `<FastField>` + an inner component so a keystroke in one field re-renders only
  that field's subtree — not the whole form. Do **not** go back to
  `useFormikContext` subscriptions in shared fields.
- Because Formik's default `FastField` compare only diffs the field slice and the
  prop-key count, use the `fastFieldShouldUpdate` helper
  (`src/shared/components/forms/fastField.ts`) on any shared field whose props can
  be derived from a sibling field (`disabled`, `options`, `value`, etc.) — it
  adds a `react-fast-compare` diff of the field's own props so those stay in sync
  without re-subscribing the whole form.
- Prefer `validateOnChange={false}` on heavy/large forms: it defers full-tree Yup
  validation to blur + submit. Safe only because no submit gate in the app relies
  on mid-typing `isValid` (they bind `disabled` to `dirty`/`isSubmitting`).

## Shared style

- Path alias: `@/` → `src/` (`tsconfig.json` + jest `moduleNameMapper`).
- Style constants come from `src/constants/values.ts` (`PALETTE`, `CUSTOM_STYLES`,
  `POPUP_HEIGHT`, etc.) — no magic numbers repeated across files.