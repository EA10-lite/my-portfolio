# Performance Audit

Audit of the Tego app (Expo SDK 55 / RN 0.83 / React 19.2, React Compiler enabled,
Expo Router, TanStack Query v5, zustand, Reanimated 4). Issues are prioritized;
work is done strictly one issue at a time. Check off items as they land.

PRs: one PR per priority level, targeted at `api-integration` (see `docs/PR.md`).
P1 work branches are chained so the final PR carries a single linear history.

## Priority 1

### 1.1 ✅ Whole tree re-renders on every scroll frame (DONE — branch `perf/scroll-per-frame-renders`)

**Problem.** `useHideTabBarOnScroll.ts` wrote `currentOffset` into the zustand
store on every scroll event (~60/sec). The root layout and both tab layouts
subscribed to the *whole* store with no selector, so every frame caused the full
app tree (including both tab navigators) to re-render.

**Fix.** Replaced `scrollY` with a boolean `isBelowPopup` (default `true`, flips
at `POPUP_HEIGHT = 70`). Because zustand uses `Object.is` equality, the store now
publishes only on a threshold crossing, not per frame. Both `hidden` and
`isBelowPopup` writes are additionally guarded via `getState()` comparisons.
Tab layouts select `(s) => s.hidden` and use a `useCallback`-cached `renderTabBar`.

The decision logic is a pure exported function `resolveScrollState()` so it is
unit-tested without React (see `docs/ENGINEERING.md`).

**Verify.**
- Scroll all 12 tabs on both roles; tab bar hides scrolling down, re-appears on
  scroll up.
- Status bar flips to `light-content` once the scroll passes the popup height
  (iOS only — Android's status bar is unconditional).
- Watch for jank/janky tab transitions while holding a scroll.

### 1.2 ✅ Cold start: ~500ms + ~1200ms of artificial sleeps (DONE — `eee6659` on branch `perf/cold-start-delays`)

**Problem.** Two fake sleeps held the app before it was usable:
- `src/app/_layout.tsx` hid the native splash after a hard-coded **500ms**
  "simulate loading" `setTimeout` (on top of real font loading).
- `src/app/(public)/splash.tsx` hard-coded a **1200ms** hold before routing. The
  hold existed because `useAuthStore` is a zustand `persist` store: on cold
  launch `isLoggedIn`/`user` read `false`/`null` until AsyncStorage rehydrates,
  so the timer was a crude "wait for hydration" hack.

**Fix.**
- `_layout.tsx` now destructures `const [fontsLoaded, fontError] = useAppFonts()`
  (previously the tuple was truthy-testable as a whole, so the font gate never
  actually held rendering) and hides the native splash **event-driven** on
  `fontsReady` — no artificial delay.
- `splash.tsx` routes on **hydration**, not time: `useAuthStore.persist.hasHydrated()`
  or `onFinishHydration()`. Logged-in users go straight to their tabs; logged-out
  users get the sign-in buttons after a 400ms brand beat.
- Routing decision extracted to pure `resolveSplashAction()` in
  `src/modules/auth/lib/splashRouting.ts` (unit-tested).

**Expected impact.** Logged-in cold start ≈ 1.7s → < ~0.4s (font load +
AsyncStorage hydration). New users see login ~800ms sooner.

**Verify.**
- Cold-launch while logged in (both roles): app lands on the correct tabs in
  under half a second, no white flash.
- Cold-launch while logged out: logo, then buttons fade in after a brief beat.
- Kill/relaunch repeatedly; routing must stay correct (no wrong-role redirect).

### 1.3 ✅ Full-resolution images, no Cloudinary transforms (IMPLEMENTED — awaiting manual verification, branch `perf/image-pipeline`)

**Problem.**
- No Cloudinary width transforms anywhere: only `ImagePreview` injected
  `f_auto,q_auto` (no sizing), so avatars (≤64px circles, ~25 call sites), chat
  gallery (86×94 boxes), card covers and 20px stacks all downloaded full-res
  originals.
- Every remote image rendered through `react-native` `Image` (no disk cache /
  downscaled decode). `expo-image` was only used for 2 local PNGs.
- Uploads unbounded: `useFilePicker` default `quality: 1` (chat, provider
  profile, verification), a dead `expo-image-manipulator` resize path, and
  `uploadMany*` ran `Promise.all` in parallel.

**Fix.**
- `transformImageUrl(url, width?)` in `cloudinary.ts` injects
  `w_<px>,f_auto,q_auto` after `/upload/`; non-Cloudinary URIs pass through.
- New `CImg` component (expo-image wrapper, `memory-disk` cache,
  `contentFit="cover"`, fade transition). Render sites swapped to sized URLs:
  `UserAvatar` (4× container), `ImagePreview` grid (500px), `ChatMessage`
  gallery (240px), chat lightbox (1280px caps), category/provider card covers
  (648/768px), 20px avatar stacks (80px), form picker previews (400px).
- Uploads: client resize to ≤1600px + JPEG q0.8 (`prepareImageForUpload`, skips
  PDFs) inside both upload functions; batches now sequential (flat memory).
- Picker default `quality` 1 → 0.8 (`useFilePicker`).

**Expected impact.** 10–60× fewer bytes per remote image on avatars/cards/thumbs;
bounded upload payloads; expo-image disk cache speeds up chats/lists on revisit.

**Verify.**
- Browse home (category/provider cards), a job/order detail, applications list,
  and a chat with images on both roles — all images crisp, no full-res jank,
  placeholders transition in.
- Send 3 chat images: upload runs one at a time with per-file progress.
- Upload a profile card / avatar: toast completes quickly, image looks right.
- Lightbox a chat image and download it — full-res file saved to gallery.

## Priority 2

### 2.1 ✅ Home mount: duplicate location chains + coordinate-less "near me" query (IMPLEMENTED — awaiting manual verification, branch `perf/p2-home-fetch`)

**Problem.** Home mount cost ~8 backend/device round-trips, several redundant:
- A **duplicate location chain**: the root layout already called
  `locationStore.getCurrentLocation()` (High accuracy + permission prompt +
  reverse-geocode + ipify), but home's `useDeviceInfo` (`useLocation.ts`) fired
  a separate, accuracy-locked chain including a 2nd permission prompt — and the
  nearest fetch (below) depended on it.
- The **"near me"** `useProviders` fired a coordinate-less query first, then
  re-fired once `useDeviceInfo` resolved coords (a query-key change ⇒ network
  churn + duplicate results).
- `locationStore` fetched and reverse-geocoded coords but **discarded them**,
  so home could only get position from the redundant chain.

**Fix.**
- `locationStore` now persists `latitude`/`longitude` alongside `address`
  (`src/shared/store/locationStore.ts`).
- Home reads coords from the store instead of `useDeviceInfo` — one location
  chain total; `useDeviceInfo` untouched (still used by 7 other screens).
- `useProviders` gains `enabled` + a pure exported decision helper
  `resolveProvidersEnabled()`: a `near_me` preference with no coords yet is
  **disabled** until coords arrive, so it never fires coordinate-less. Other
  preferences default to enabled.
- Near-me is excluded from home's aggregate `isLoading` gate, so the disabled
  near-me fetch can't hold the whole screen on skeletons until location resolves.

**Expected impact.** Removes 1 permission prompt, 1 GPS lock, 1 reverse-geocode
and 1 ipify fetch on home mount; the "near me" query no longer fires twice with
a throwaway coordinate-less request.

**Verify.**
- Cold-launch home (customer): single location permission prompt (root layout),
  no second `useDeviceInfo` prompt; home renders content immediately even if
  location is still resolving.
- "Popular Near You" pops in once coords land (no flicker, no double fetch in
  devtools).
- Deny location: home still shows the rest of the content with no hanging loader.
- `useDeviceInfo` still works on the other 7 screens (business-location, invite,
  request-job, edit-address, booking form, RequestFilter).

### 2.2 ✅ Chat: every socket event refetched the whole conversation list (IMPLEMENTED — awaiting manual verification, branch `perf/p2`)

**Problem.** Three hot paths invalidated `["conversations"]`, forcing a full
`GET /messages/contacts` refetch on every event even though the cache was
already updated synchronously:
- `useChatRoom`'s `message:new` listener called `invalidateQueries` per incoming
  message (`useConversations`'s own listener already rewrote the cache via
  `setQueryData`).
- Both send acks (text + image) invalidated the whole list again.
- `staleTime: 0` meant every invalidation = network request, and the list screen
  re-renders the entire `.map()`-based conversation list on each cache change.

**Fix.** Extracted the cache update into a pure helper
`updateConversationPreview(prev, raw, { incrementUnread })`
(`src/modules/message/utils/conversation.ts`):
- Incoming messages keep updating `["conversations"]` via `setQueryData` (single
  source of truth, unread +1 behaviour unchanged).
- Send acks now write the sender's own last-message straight into the cache
  (no unread bump, no network) instead of invalidating.
- Leaving a chat room still invalidates once on blur
  (`useFocusEffect`), so returning to the list always syncs.

**Expected impact.** Zero `GET /messages/contacts` calls from live messaging —
only one fetch on entering/leaving the chat list. Incoming messages during a
long chat session no longer ping the API per message.

**Verify.** Two devices (customer + provider):
- Send several messages: watch the network tab — every send/recv updates the
  list with no `/contacts` requests while inside any chat.
- Back out to the message list: exactly one refetch shows the newest
  conversation order, unread badges, and image 📷 previews.
- Leave the app open in a chat while the other side sends 5+ messages: no
  network chatter, badge/preview still correct when you return.

### 2.3 ✅ Forms: whole-form re-render + full Yup validation on every keystroke (IMPLEMENTED — branch `perf/p2`)

**Problem.** Two per-keystroke costs on every Formik screen:
- Every shared field subscribed to the whole form via `useFormikContext`, so
  typing in one field re-rendered every field's native subtree.
- `validateOnChange` (Formik default) ran a full-tree Yup validation on each
  change.

**Fix 1 — field-granularity.** All 13 shared form controls
(`Input`, `Textbox`, `BottomSheetInput`, `BottomSheetTextbox`, `EditableInput`,
`Select`, `OTPInput`, `Checkbox`, `Switch`, `TimePicker`, `DatePicker`,
`ImagePicker`, `AddressInput`) now render through Formik `<FastField>` into an
inner component. Only the active field's subtree re-renders per keystroke;
`Field`-subscription (`useFormikContext`) is gone from the shared forms dir.

- Formik's stock `FastField` compare only diffs the field slice and prop-key
  count, so props derived from sibling fields (`disabled`, `options`, `value`)
  would go stale. `src/shared/components/forms/fastField.ts` adds
  `fastFieldShouldUpdate` — the field slice plus a `react-fast-compare` diff of
  the field's own props — so cross-field dependent controls stay in sync
  without re-subscribing. `AddressInput` additionally tracks its non-nested
  `stateFieldName` slice.

**Fix 2 — validation cadence.** `validateOnChange={false}` on the 16 heaviest
forms (signup, forgotpassword, booking, request-job create/edit, customer +
provider profile, edit-address, business-location, identity-verification,
service-offered, offer send/apply, NegotiateModal, AddServiceModal). Validation
now runs on blur (Formik default) and on submit; no submit gate in the app
relies on mid-typing `isValid` (all bind `disabled` to `dirty`/`isSubmitting`),
so submit behavior is unchanged.

**Expected impact.** A keystroke now renders one field subtree (not the whole
form) and skips the full Yup tree entirely, deferring validation to blur +
submit.

**Verify.**
- Type quickly in any large form (signup, request-job) — cursor stays smooth
  and only the active field redraws (React DevTools highlight is a quick way
  to see this).
- service-offered: pick a category, then "Select services" — it must enable and
  list that category's services (stale-`disabled`/`options` case).
- business-location / edit-address: picking a state enables the city dropdown.
- Submit an empty required field on a changed form: the same errors appear as
  before, just after blur/submit instead of live.

- **Home screen:** ❌ reverted (`9a319b4`) — the top-level-`FlatList` restructure
  broke layout/search/scroll on device; home still uses the `ScrollView` +
  `.map()` structure (revisit with a lighter-touch approach).
- **Chat:** ✅ socket events no longer refetch the conversation list (2.2).
- **Forms:** ✅ field-granularity + `validateOnChange={false}` (2.3).
- **Location:** ✅ `useDeviceInfo` no longer fires its own permission + GPS +
  reverse-geocode + ipify chain — it now reads `locationStore`, the single chain
  kicked off once from the root layout (extended with device name + IP + richer
  address) (2.5).
- **Avatar double-upload:** ✅ `uploadProfilePicture` now uploads only local
  URIs and passes already-remote `secure_url`s straight to the backend (2.4).
- **Request edit re-upload:** ✅ `uploadManyKeepingRemote` uploads only local
  file URIs and leaves existing remote Cloudinary images untouched (request-job
  create + update) (2.4).
- **Message inbox:** ✅ both inbox screens virtualized — `Animated.ScrollView` +
  `.map()` → `FlatList` for chats and offers (2.6).

## Priority 3

- ✅ Unbounded AsyncStorage query persister → bounded (`maxAge: 1 hr`) +
  per-user / private queries excluded via `shouldDehydrateQuery` filter.
- ✅ `refetchOnWindowFocus` set to `false`.
- ✅ Dead `[""]` query invalidation removed; replaced with proper
  `messages.list` / `messages.offers` invalidation in `useInvitation`.
- ✅ Cache-key collisions fixed — all query keys centralized in
  `src/constants/queryKeys.ts`; `["all-job-requests"]` (never matched) now
  correctly invalidates `jobRequests.all`; `[JOB_REQUEST_KEYS]` removed from
  `request-job/utils/type.ts`.
- `NetworkToast` polls native every 5s, root-mounted.
- axios: `SecureStore` read per request + non-deduped 401 refresh.
- Startup bundle: eager `CheckoutWebView`, `lucide-react-native` root import,
  and socket.io.
- Whole-store zustand subscriptions without selectors (see ENGINEERING.md).
- Booking images are never uploaded to Cloudinary — `booking/preview.tsx` posts
  raw local `file://` URIs straight to `/service-booking` (`BOOKING_IMAGES`
  folder constant unused).
- Over-fetched API endpoints; no-op store writes; `useApplications` missing its
  status param.

## Notes

- Pre-existing unrelated TS errors to leave alone: `src/app/(customer)/providers.tsx:42`,
  `src/app/(service-provider)/(tabs)/orders.tsx:50`, `src/trash/`,
  `src/app/(service-provider)/booking/quote.tsx`.
- Pre-existing `package.json` quirk: a bogus `"undefined": "@gorhom/bottom-sheet^5"`
  dependency entry — npm tolerates it; do not fold a fix into an unrelated PR.