KOPA XCLUSIVE Comprehensive Onboarding Terms & Conditions

Effective Date: [Insert Date] Last Updated: [Insert Date]

INTRODUCTION

Welcome to Kopa Xclusive. Kopa Xclusive is a fintech-enabled lifestyle platform designed to provide essential services and deferred payment solutions for National Youth Service Corps (NYSC) members while enabling verified vendors to deliver goods and services efficiently.

These Terms and Conditions govern the onboarding, access, and use of the Kopa Xclusive platform by both Corps Members (Users) and Vendors.

By registering or using the Kopa Xclusive platform, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.

1. DEFINITIONS

For the purpose of this agreement:

Platform: Refers to the Kopa Xclusive mobile application, website, and related systems.

User / Corps Member: A registered NYSC corps member who accesses services or credit through the platform.

Vendor / Service Provider: A registered business or individual authorized to provide goods or services on the platform.

Allottee Account: The verified bank account linked to a corps member for payments, credit verification, and direct debit authorization.

Deferred Payment / Credit: Financial accommodation or service access granted to a user with repayment scheduled at a later date.

Direct Debit Mandate: Authorization granted by a user permitting Kopa Xclusive to automatically debit repayment obligations from a linked bank account through an approved payment gateway.

Verification Services: Processes used to confirm identity and account authenticity including BVN verification, OTP confirmation, bank validation, document verification, and biometric confirmation.

2. ELIGIBILITY

2.1 Corps Members

To register as a Corps Member on Kopa Xclusive, the individual must:

• Be an officially registered NYSC corps member • Be at least 18 years of age • Possess a valid call‑up letter or NYSC identification • Have a valid Nigerian bank account • Have a valid Bank Verification Number (BVN) • Provide accurate personal and identification information

Kopa Xclusive reserves the right to reject or suspend accounts where eligibility requirements are not satisfied.

2.2 Vendors

To register as a Vendor, the applicant must:

• Be a legally operating business or individual within Nigeria • Provide business verification documentation where applicable (e.g., CAC registration, trade license, or other regulatory approvals) • Provide a valid Nigerian bank account for settlement • Agree to comply with applicable Nigerian laws including financial, tax, and consumer protection regulations

Kopa Xclusive may conduct background verification before approving a vendor account.

3. REGISTRATION AND ACCOUNT VERIFICATION

3.1 Corps Member Verification

To ensure platform security and compliance with financial regulations, Kopa Xclusive conducts multi‑layer identity verification which may include:

• BVN verification • Bank account validation • Upload of call‑up letter • Government-issued identification • Selfie and biometric match • Phone and email OTP authentication • Optional verification through NYSC/state records

Users agree that Kopa Xclusive may perform identity, fraud prevention, and creditworthiness checks in accordance with applicable regulatory standards.

3.2 Vendor Verification

Vendors are required to provide:

• Business identification or registration documentation • Accurate product or service listings • Bank account information for settlements • Contact details and operational address

Kopa Xclusive reserves the right to approve, decline, suspend, or terminate vendor access based on verification results.


4. DIRECT DEBIT MANDATE AND REPAYMENT AUTHORIZATION
By registering and linking a bank account to the Kopa Xclusive platform, Corps Members grant an irrevocable authorization permitting Kopa Xclusive, through its approved payment processors, to debit the registered bank account for the purpose of recovering:

• Deferred payment balances • Credit repayments • Applicable service charges • Outstanding obligations owed to the platform

Debits may be initiated through approved payment gateways or banking infrastructure in accordance with applicable financial regulations.

Users acknowledge that:

• Adequate funds must be maintained in the linked bank account • Failed debit attempts may result in restricted access • Persistent repayment failures may lead to account suspension • Outstanding balances remain legally payable

5. PLATFORM SERVICES


5.1 Services for Corps Members

Kopa Xclusive provides access to lifestyle and essential services which may include but are not limited to:

• Food and meal services • Transportation services • Airtime and utility services • Gas and essential supply purchases

These services may be offered through a deferred payment structure subject to credit eligibility and platform policies.

5.2 Services for Vendors

Vendors are authorized to list and provide approved goods or services to corps members through the platform.

Vendors must ensure:

• Accurate service descriptions • Timely service delivery • Compliance with consumer protection laws • Ethical and fair business practices

6. PAYMENTS AND SETTLEMENT



6.1 Vendor Settlement

Upon successful confirmation of a transaction, vendor payments may be processed instantly or according to settlement timelines defined by Kopa Xclusive.

6.2 Transaction Processing

All financial transactions are processed using secure and compliant payment infrastructure.

Kopa Xclusive employs encryption and financial safeguards consistent with Nigerian fintech best practices.

7. DATA PRIVACY AND PROTECTION
Kopa Xclusive collects, stores, and processes personal and financial information solely for the purpose of providing platform services.

Data processing activities may include:

• Identity verification • Fraud detection • Credit risk assessment • Transaction processing • Service improvement

All personal data is handled in accordance with the Nigerian Data Protection Regulation (NDPR) and applicable privacy laws.

Kopa Xclusive does not sell personal data to third parties.

8. ACCOUNT SECURITY
Users are responsible for safeguarding their login credentials and account access.

Kopa Xclusive shall not be liable for losses arising from unauthorized access caused by negligence in protecting login credentials.

Users must notify Kopa Xclusive immediately upon discovering any unauthorized activity.

9. PROHIBITED ACTIVITIES
Users and vendors are prohibited from engaging in activities that may compromise platform integrity including:

• Fraudulent transactions • Misrepresentation of identity • Manipulation of credit systems • Unauthorized access to platform infrastructure • Abuse of vendor or user privileges

Violation of these provisions may result in immediate suspension or termination.

10. LIMITATION OF LIABILITY
Kopa Xclusive operates as a technology platform facilitating transactions between users and vendors.

The platform shall not be liable for:

• Quality or delivery of vendor services • Vendor misrepresentation • Indirect or consequential losses arising from platform usage

To the fullest extent permitted by Nigerian law, liability shall be limited to the value of the transaction involved.

11. ACCOUNT SUSPENSION OR TERMINATION

Kopa Xclusive reserves the right to suspend or terminate accounts where:

• Fraudulent activity is detected • Terms and conditions are violated • Regulatory obligations require enforcement • Repeated repayment failures occur

Termination does not eliminate outstanding repayment obligations.

12. AMENDMENTS
Kopa Xclusive may update these Terms and Conditions from time to time in order to:

• Reflect regulatory changes • Improve service delivery • Introduce new platform features

Continued use of the platform constitutes acceptance of the revised terms.

13. GOVERNING LAW
These Terms and Conditions shall be governed and interpreted in accordance with the laws of the Federal Republic of Nigeria.


USER CONSENT

By selecting the acceptance checkbox during registration, you confirm that:

• You have read and understood these Terms and Conditions • You agree to comply with all platform policies • You authorize the Direct Debit Mandate for repayment obligations

[ ] I agree to the Kopa Xclusive Terms and Conditions including Direct Debit Authorization and Data Privacy Policy.


-
