import type { ReactNode } from "react";
import { Text } from "../../components";
import { cn } from "../../lib/utils";

interface EmptyStateProps {
  title: string;
  description: string;
  icon?: ReactNode;
  action?: ReactNode;
  className?: string;
}

export function EmptyState({ title, description, icon, action, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex min-h-[300px] w-full flex-col items-center justify-center space-y-4 rounded-lg border border-dashed p-8 text-center animate-in fade-in-50 duration-500 bg-white/50",
        className
      )}
    >
      {icon && (
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 text-primary">
          {icon}
        </div>
      )}
      <div className="space-y-1">
        <Text title={title} type="h4" className="text-lg font-semibold text-foreground" />
        <Text title={description} type="p" className="text-sm text-muted-foreground max-w-md mx-auto" />
      </div>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
