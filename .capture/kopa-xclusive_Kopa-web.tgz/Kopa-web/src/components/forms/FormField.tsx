import { type FormikValues, useFormikContext } from "formik";
import {
    Field,
    FieldError,
    FieldLabel,
} from "../ui/field"
import FormInput from "./FormInput";

interface FormFieldProps {
    label: string;
    name: string;
    type?: string;
    placeholder?: string;
    isMandatory?: boolean;
    isOptional?: boolean;
    className?: string;
    disabled?: boolean;
    /** Hard cap on characters — e.g. an 11-digit phone or a 6-digit PIN. */
    maxLength?: number;
    /** Hints the on-screen keyboard; "numeric" for phone/PIN fields. */
    inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
}

const FormField = ({
    label,
    name,
    type = "text",
    placeholder,
    isMandatory = false,
    isOptional = false,
    disabled,
    className,
    maxLength,
    inputMode,
}: FormFieldProps) => {
    const { values, handleChange, errors, touched } = useFormikContext<FormikValues>();

    const hasError = Boolean(touched[name] && errors[name]);

    return (
        <div className="form-group">
            <Field className="gap-1" data-invalid={hasError || undefined}>
                <FieldLabel className="text-black text-sm font-medium">
                    {label} {" "}
                    {isMandatory && <span className="text-primary">*</span>}
                    {isOptional && (
                        <span className="text-primary rounded-full px-2 bg-[#FFFFFF05] text-xs inline py-1">Optional</span>
                    )}
                </FieldLabel>
                <FormInput
                    name={name}
                    type={type}
                    placeholder={placeholder}
                    value={values[name]}
                    handleChange={handleChange}
                    styles={className}
                    disabled={disabled}
                    maxLength={maxLength}
                    inputMode={inputMode}
                    aria-invalid={hasError || undefined}
                />

                <FieldError
                    errors={hasError ? [{ message: errors[name] as string }] : []}
                />
            </Field>
        </div>
    )
}

export default FormField;