import { AlertTriangle, Info } from "lucide-react";

/**
 * Marks a screen whose data or actions have no backend behind them.
 *
 * "readonly" explains why a real record has no actions. "mock" is for a
 * screen showing placeholder rows — none do today; keep it so a future
 * unfinished screen can never pass invented data off as real.
 */
const NotBackedBanner = ({
    variant = "mock",
    title,
    children,
}: {
    /** "mock" — the rows are fixtures. "readonly" — rows are real, actions aren't available. */
    variant?: "mock" | "readonly";
    title: string;
    children: React.ReactNode;
}) => {
    const isMock = variant === "mock";
    const Icon = isMock ? AlertTriangle : Info;

    return (
        <div
            role="status"
            className={
                isMock
                    ? "bg-amber-50 border border-amber-200 text-amber-900 text-sm rounded-sm p-4 space-y-1"
                    : "bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-sm p-4 space-y-1"
            }
        >
            <p className="font-medium flex items-center gap-2">
                <Icon className="size-4 shrink-0" />
                {title}
            </p>
            <div className="text-[13px] leading-relaxed">{children}</div>
        </div>
    );
};

export default NotBackedBanner;
