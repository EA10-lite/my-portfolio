import { cn } from "../../lib/utils";
import { PERIODS } from "../../utils/periods";
import type { PeriodRange } from "../../hooks/usePeriodRange";
import DateRangeFilter from "./DateRangeFilter";

/** Preset buttons plus a custom from/to, driven by usePeriodRange. */
const PeriodBar = ({ range, className }: { range: PeriodRange; className?: string }) => (
    <div className={cn("flex flex-wrap items-center gap-3", className)}>
        <div role="group" aria-label="Period" className="flex flex-wrap rounded-md border border-primary/15 bg-white p-0.5 text-xs">
            {PERIODS.map((p) => {
                const active = !range.isCustom && range.period === p.key;
                return (
                    <button
                        key={p.key}
                        type="button"
                        aria-pressed={active}
                        onClick={() => range.setPeriod(p.key)}
                        className={cn(
                            "px-3 py-1 rounded-[5px] transition-colors",
                            active ? "bg-primary text-white" : "text-black/60 hover:text-black",
                        )}
                    >
                        {p.label}
                    </button>
                );
            })}
        </div>
        <span className="text-xs text-black/40">or</span>
        <DateRangeFilter
            from={range.customFrom}
            to={range.customTo}
            setFrom={(v) => range.setCustom(v, range.customTo)}
            setTo={(v) => range.setCustom(range.customFrom, v)}
            clear={() => range.setCustom("", "")}
            isActive={range.isCustom}
        />
    </div>
);

export default PeriodBar;
