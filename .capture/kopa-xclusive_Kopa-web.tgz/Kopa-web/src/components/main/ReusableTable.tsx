"use client"

import * as React from "react"
import {
    type ColumnDef,
    type ColumnFiltersState,
    type PaginationState,
    type OnChangeFn,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    useReactTable,
} from "@tanstack/react-table"
import { Search, ChevronLeft, ChevronRight } from "lucide-react"

import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "../ui/table"
import { Input } from "../ui/input"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "../ui/select"
import { Button } from "../ui/button"
import { Skeleton } from "../ui/skeleton"

interface FilterOption {
    label: string
    value: string
}

interface FilterConfig {
    /** Column id for local filtering, or the query-param name in server mode. */
    columnKey: string
    title: string
    options: FilterOption[]
}

/**
 * Server-side search. When given, the input is controlled by the page (which
 * sends it to the API) and the table does no local text filtering — local
 * filtering would only ever see the current page of results.
 */
interface ServerSearch {
    value: string
    onChange: (value: string) => void
    placeholder?: string
}

interface ReusableTableProps<TData, TValue> {
    columns: ColumnDef<TData, TValue>[]
    data: TData[]
    /** Local search over these column ids (client-side data only). */
    searchKeys?: string[]
    search?: ServerSearch
    filters?: FilterConfig[]
    /** Server mode for filters: current values + change handler. */
    filterValues?: Record<string, string>
    onFilterChange?: (key: string, value: string) => void
    showHeader?: boolean
    manualPagination?: boolean
    pageCount?: number
    rowCount?: number
    pagination?: PaginationState
    onPaginationChange?: OnChangeFn<PaginationState>
    isLoading?: boolean
    emptyMessage?: string
}

/** "awaiting review" → "Awaiting review" (keeps acronyms like KYC intact). */
const sentenceCase = (text: string) => text.charAt(0).toUpperCase() + text.slice(1)

/** Page buttons to show: first, last, and the neighbours of the current page. */
function pageWindow(current: number, count: number): (number | "gap")[] {
    if (count <= 7) return Array.from({ length: count }, (_, i) => i)
    const wanted = [0, count - 1, current - 1, current, current + 1]
        .filter((p) => p >= 0 && p < count)
    const pages = Array.from(new Set(wanted)).sort((a, b) => a - b)
    const out: (number | "gap")[] = []
    pages.forEach((p, i) => {
        if (i > 0 && p - pages[i - 1] > 1) out.push("gap")
        out.push(p)
    })
    return out
}

export function ReusableTable<TData, TValue>({
    columns,
    data,
    searchKeys,
    search,
    filters = [],
    filterValues,
    onFilterChange,
    showHeader = true,
    manualPagination = false,
    pageCount,
    rowCount,
    pagination,
    onPaginationChange,
    isLoading = false,
    emptyMessage = "No results.",
}: ReusableTableProps<TData, TValue>) {
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
    const [globalFilter, setGlobalFilter] = React.useState("")
    const [localPagination, setLocalPagination] = React.useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    })

    const serverFilters = Boolean(onFilterChange)

    const table = useReactTable({
        data,
        columns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: onPaginationChange || setLocalPagination,
        manualPagination,
        pageCount,
        rowCount,
        globalFilterFn: (row, _columnId, filterValue) => {
            if (!searchKeys || searchKeys.length === 0) return true;
            const searchValue = String(filterValue).toLowerCase();
            return searchKeys.some((key) => {
                const value = row.getValue(key);
                return String(value ?? "").toLowerCase().includes(searchValue);
            });
        },
        state: {
            columnFilters,
            globalFilter,
            pagination: pagination || localPagination,
        },
    })

    const showSearch = Boolean(search) || Boolean(searchKeys && searchKeys.length > 0)

    const { pageIndex, pageSize } = table.getState().pagination
    const rowsOnPage = table.getRowModel().rows.length
    const totalRows = manualPagination
        ? (rowCount ?? data.length)
        : table.getFilteredRowModel().rows.length
    const start = rowsOnPage === 0 ? 0 : pageIndex * pageSize + 1
    const end = rowsOnPage === 0 ? 0 : pageIndex * pageSize + rowsOnPage

    return (
        <div className="reusable-table">
            <div className="space-y-4 w-full border-[0.5px] border-primary/8 bg-secondary-foreground rounded-md">
                {(showSearch || filters.length > 0) && (
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 py-4 px-6">
                        {showSearch ? (
                            <div className="relative w-full sm:max-w-sm">
                                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-black/50" />
                                <Input
                                    placeholder={search?.placeholder ?? "Search"}
                                    value={search ? search.value : (globalFilter ?? "")}
                                    onChange={(event) =>
                                        search
                                            ? search.onChange(event.target.value)
                                            : setGlobalFilter(event.target.value)
                                    }
                                    className="pl-9 border-[0.5px] border-primary/8 text-black placeholder:text-black/50 rounded-lg focus:outline-none focus-visible:ring-primary focus-visible:ring-[1px] transition-all"
                                />
                            </div>
                        ) : <div />}

                        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto sm:justify-end">
                            {filters.map((filter) => {
                                const value = serverFilters
                                    ? (filterValues?.[filter.columnKey] || "all")
                                    : ((table.getColumn(filter.columnKey)?.getFilterValue() as string) || "all")
                                return (
                                    <Select
                                        key={filter.columnKey}
                                        value={value}
                                        onValueChange={(next) => {
                                            const v = !next || next === "all" ? "" : String(next)
                                            if (serverFilters) onFilterChange?.(filter.columnKey, v)
                                            else table.getColumn(filter.columnKey)?.setFilterValue(v)
                                        }}
                                    >
                                        <SelectTrigger className="flex-1 min-w-[140px] sm:flex-none sm:min-w-[170px] border-[0.5px] border-primary/8 text-black rounded-lg">
                                            <SelectValue placeholder={filter.title}>
                                                {value === "all"
                                                    ? filter.title
                                                    : sentenceCase(filter.options.find((o) => o.value === value)?.label ?? value)}
                                            </SelectValue>
                                        </SelectTrigger>
                                        <SelectContent className="bg-white border-primary/10 text-black">
                                            <SelectItem value="all">All</SelectItem>
                                            {filter.options.map((option) => (
                                                <SelectItem key={option.value} value={option.value} className="capitalize">
                                                    {option.label}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                )
                            })}
                        </div>
                    </div>
                )}

                <div className="rounded-md border-none">
                    <Table>
                        {showHeader && (
                            <TableHeader className="bg-primary/4 hover:bg-primary/4 [&_tr]:border-b-secondary-foreground">
                                {table.getHeaderGroups().map((headerGroup) => (
                                    <TableRow key={headerGroup.id} className="hover:bg-primary/4 border-none">
                                        {headerGroup.headers.map((header) => (
                                            <TableHead
                                                key={header.id}
                                                className="text-primary font-medium first:pl-6 last:pr-6 last:text-right"
                                            >
                                                {header.isPlaceholder
                                                    ? null
                                                    : flexRender(header.column.columnDef.header, header.getContext())}
                                            </TableHead>
                                        ))}
                                    </TableRow>
                                ))}
                            </TableHeader>
                        )}
                        <TableBody className="[&_tr:last-child]:border-0 text-black">
                            {isLoading ? (
                                Array.from({ length: 10 }).map((_, index) => (
                                    <TableRow key={index} className="border-b border-primary/10 hover:bg-transparent">
                                        {columns.map((_, colIndex) => (
                                            <TableCell key={colIndex} className="py-4 first:pl-6">
                                                <Skeleton className="h-4 w-full bg-primary/10" />
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map((row) => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && "selected"}
                                        className="border-b border-primary/10 hover:bg-primary/2"
                                    >
                                        {row.getVisibleCells().map((cell) => (
                                            <TableCell key={cell.id} className="py-4 first:pl-6 last:pr-6">
                                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={columns.length} className="h-24 text-center text-black/50">
                                        {emptyMessage}
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
            </div>

            {/* Pagination */}
            <div className="flex flex-wrap items-center justify-between gap-3 px-2 py-4">
                <div className="text-sm text-black">
                    {totalRows === 0
                        ? "No records"
                        : `Showing ${start.toLocaleString()}–${end.toLocaleString()} of ${totalRows.toLocaleString()}`}
                </div>

                <div className="flex items-center space-x-2">
                    <Button
                        variant="ghost"
                        className="h-8 w-8 p-0 text-primary hover:bg-secondary-foreground hover:text-[#34D399]"
                        onClick={() => table.previousPage()}
                        disabled={!table.getCanPreviousPage()}
                        aria-label="Previous page"
                    >
                        <ChevronLeft className="h-4 w-4" />
                    </Button>

                    <div className="flex items-center gap-1">
                        {pageWindow(pageIndex, table.getPageCount()).map((page, i) =>
                            page === "gap" ? (
                                <span key={`gap-${i}`} className="w-6 text-center text-black/40">…</span>
                            ) : (
                                <Button
                                    key={page}
                                    variant="ghost"
                                    onClick={() => table.setPageIndex(page)}
                                    className={`h-8 min-w-8 px-2 rounded-full ${pageIndex === page
                                        ? "bg-primary text-secondary hover:bg-primary/90"
                                        : "text-black hover:bg-secondary-foreground hover:text-[#34D399]"
                                        }`}
                                >
                                    {page + 1}
                                </Button>
                            ),
                        )}
                    </div>

                    <Button
                        variant="ghost"
                        className="h-8 w-8 p-0 text-primary hover:bg-secondary-foreground hover:text-[#34D399]"
                        onClick={() => table.nextPage()}
                        disabled={!table.getCanNextPage()}
                        aria-label="Next page"
                    >
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>

                <div className="flex items-center space-x-2">
                    <p className="text-sm font-medium text-black">Per page</p>
                    <Select
                        value={`${pageSize}`}
                        onValueChange={(value) => {
                            table.setPageSize(Number(value))
                            table.setPageIndex(0)
                        }}
                    >
                        <SelectTrigger className="h-8 w-[70px] bg-white border-none text-black">
                            <SelectValue placeholder={pageSize} />
                        </SelectTrigger>
                        <SelectContent side="top" className="bg-white border-none text-black">
                            {[10, 20, 30, 40, 50].map((size) => (
                                <SelectItem key={size} value={`${size}`}>
                                    {size}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
        </div>
    )
}

export default ReusableTable;
