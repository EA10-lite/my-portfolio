import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { CalendarDays, X } from "lucide-react";
import type { DateRangeState } from "../../utils/dateRange";

/**
 * Presentational half of the date-range filter. The hook and the predicate
 * live in utils/dateRange.ts — see that file for why filtering happens
 * client-side.
 */
const DateRangeFilter = ({
    from,
    to,
    setFrom,
    setTo,
    clear,
    isActive,
}: DateRangeState) => (
    <div className="flex flex-wrap items-center gap-2">
        <CalendarDays className="size-4 text-black/40" />
        <Input
            type="date"
            aria-label="From date"
            value={from}
            max={to || undefined}
            onChange={(e) => setFrom(e.target.value)}
            className="h-9 w-[140px] sm:w-[150px] bg-white text-black"
        />
        <span className="text-black/40 text-sm">to</span>
        <Input
            type="date"
            aria-label="To date"
            value={to}
            min={from || undefined}
            onChange={(e) => setTo(e.target.value)}
            className="h-9 w-[140px] sm:w-[150px] bg-white text-black"
        />
        {isActive && (
            <Button
                variant="ghost"
                size="sm"
                onClick={clear}
                aria-label="Clear date filter"
                className="h-9 px-2"
            >
                <X className="size-4" />
            </Button>
        )}
    </div>
);

export default DateRangeFilter;
