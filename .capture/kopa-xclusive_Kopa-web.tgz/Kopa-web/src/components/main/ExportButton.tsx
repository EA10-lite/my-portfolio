import { useState } from "react";
import { toast } from "sonner";
import { PiExport } from "react-icons/pi";
import { Button } from "../ui/button";
import { downloadCsv, type CsvColumn } from "../../utils/csv";
import { getApiErrorMessage } from "../../utils/apiError";

const PAGE_SIZE = 100;
/** Hard stop so a runaway export can't hammer the API (100 × 100 = 10,000 rows). */
const MAX_PAGES = 100;

export interface PageResult<T> {
    rows: T[];
    totalPages?: number;
    total?: number;
}

/**
 * Exports every row matching the page's current filters — not just the page
 * on screen. It walks the API page by page (100 rows each) with the same
 * filters the table is using, then downloads one CSV.
 *
 * `fetchPage` must apply the page's current filters; `filter` optionally
 * narrows rows client-side for filters the API can't apply.
 */
function ExportButton<T>({
    filename,
    columns,
    fetchPage,
    filter,
    label = "Export",
    disabled,
}: {
    filename: string;
    columns: CsvColumn<T>[];
    fetchPage: (page: number, limit: number) => Promise<PageResult<T>>;
    filter?: (row: T) => boolean;
    label?: string;
    disabled?: boolean;
}) {
    const [progress, setProgress] = useState<string | null>(null);

    const run = async () => {
        try {
            setProgress("Exporting…");
            const all: T[] = [];
            let page = 1;
            let totalPages = 1;
            do {
                const res = await fetchPage(page, PAGE_SIZE);
                all.push(...res.rows);
                totalPages = res.totalPages ?? (res.total ? Math.ceil(res.total / PAGE_SIZE) : 1);
                if (totalPages > 1) setProgress(`Exporting ${Math.min(page, totalPages)}/${totalPages}…`);
                if (res.rows.length < PAGE_SIZE) break;
                page += 1;
            } while (page <= totalPages && page <= MAX_PAGES);

            const rows = filter ? all.filter(filter) : all;
            if (rows.length === 0) {
                toast.info("Nothing to export for these filters.");
                return;
            }
            downloadCsv(filename, rows, columns);
            toast.success(
                page > MAX_PAGES
                    ? `Exported the first ${rows.length.toLocaleString()} rows (export limit reached).`
                    : `Exported ${rows.length.toLocaleString()} row${rows.length === 1 ? "" : "s"}.`,
            );
        } catch (e) {
            toast.error(getApiErrorMessage(e, "Export failed. Try again."));
        } finally {
            setProgress(null);
        }
    };

    return (
        <Button
            variant="default"
            className="rounded-sm px-4"
            onClick={run}
            disabled={disabled || progress !== null}
        >
            <PiExport className="mr-2" />
            {progress ?? label}
        </Button>
    );
}

export default ExportButton;
