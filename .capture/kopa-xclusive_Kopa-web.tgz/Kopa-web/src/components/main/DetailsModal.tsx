import type { PropsWithChildren } from "react";
import { Eye, X } from "lucide-react";
import { Button } from "../ui/button"
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "../ui/sheet"

type DetailsModalProps = PropsWithChildren<{
  title: string;
  buttonType?: "ghost" | "default" | "destructive",
  buttonTitle?: string;
  ActionButton?: React.ReactNode;
  TriggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}>

const DetailsModal = ({
  title,
  buttonType = "default",
  buttonTitle = "Close",
  ActionButton,
  TriggerButton,
  children,
  open,
  onOpenChange
}: DetailsModalProps) => {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      {/* Opened from outside (e.g. a row-actions menu) → no trigger of its own.
          `render` avoids nesting the caller's <button> inside the trigger's. */}
      {TriggerButton ? (
        <SheetTrigger render={TriggerButton as React.ReactElement} />
      ) : open === undefined ? (
        <SheetTrigger
          render={
            <Button className="bg-white text-primary rounded-xs w-full justify-start p-1.5">
              <Eye className="text-primary" />
              <span>View</span>
            </Button>
          }
        />
      ) : null}
      <SheetContent className="min-w-[404px] bg-secondary border-[0.5px] border-primary/8 rounded-xl h-fit max-h-[90vh] overflow-auto mr-10 mt-[5vh] p-0 [&>button.absolute]:hidden">
        <SheetHeader className="border-b border-primary/10 text-white flex flex-row items-center justify-between">
          <SheetTitle className="text-black">{title}</SheetTitle>

          <SheetClose className="rounded-full text-primary bg-primary/8 size-6 flex items-center justify-center">
            <X className="size-4" />
          </SheetClose>
        </SheetHeader>

        {children}

        <SheetFooter>
          {ActionButton ? (
            ActionButton
          ) : (
            <SheetClose
              render={
                <Button className="rounded-full w-full h-12" variant={buttonType}>
                  <span>{buttonTitle}</span>
                </Button>
              }
            />
          )}
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}

export default DetailsModal;