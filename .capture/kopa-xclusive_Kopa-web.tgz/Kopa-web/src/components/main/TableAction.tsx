
import { MoreVertical } from "lucide-react";

import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from "../ui/dropdown-menu"
import { Button } from "../ui/button";


interface TableActionProps {
    View?: React.ReactNode;
    Edit?: React.ReactNode;
    Delete?: React.ReactNode;
}
const TableAction = ({
    View,
    Edit,
    Delete,
}: TableActionProps) => {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger>
                <Button variant="ghost" className="h-8 w-8 p-0 text-primary/50 hover:text-primary hover:bg-transparent">
                    <MoreVertical className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-[206px] bg-white border-[0.5px] border-grey rounded-sm text-black shadow-sm p-3" align="end">
                {View && (
                    <div className="p-0">
                        {View}
                    </div>
                )}
                {Edit && (
                    <div className="hover:bg-transparent p-0 bg-transparent">
                        {Edit}
                    </div>
                )}
                {Delete && (
                    <div className="hover:bg-transparent p-0 bg-transparent">
                        {Delete}
                    </div>
                )}
            </DropdownMenuContent>
        </DropdownMenu>
    )
}

export default TableAction;