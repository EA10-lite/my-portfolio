import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MoreVertical } from "lucide-react";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { buttonVariants } from "../ui/button";
import { cn } from "../../lib/utils";

export interface DialogControlProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

export interface RowAction {
    key: string;
    label: string;
    icon?: ReactNode;
    /** Navigate to a route. */
    to?: string;
    /** Run something immediately. */
    onSelect?: () => void;
    /** Open a modal. It is rendered outside the menu, so it survives the menu closing. */
    dialog?: (props: DialogControlProps) => ReactNode;
    /** Leave the action out for this row (e.g. "Approve" on an approved item). */
    hidden?: boolean;
    disabled?: boolean;
    /** Styled red and grouped at the bottom of the menu. */
    destructive?: boolean;
}

/**
 * Per-row actions for a table.
 *
 * One available action renders as a plain button — no point hiding a single
 * choice behind a menu. Two or more collapse into a ⋮ menu, with destructive
 * actions separated at the bottom.
 */
const RowActions = ({ actions, label = "Row actions" }: { actions: RowAction[]; label?: string }) => {
    const [openKey, setOpenKey] = useState<string | null>(null);
    const navigate = useNavigate();

    const visible = actions.filter((a) => !a.hidden);
    if (visible.length === 0) return null;

    const run = (action: RowAction) => {
        if (action.disabled) return;
        if (action.to) navigate(action.to);
        else if (action.dialog) setOpenKey(action.key);
        else action.onSelect?.();
    };

    const active = visible.find((a) => a.key === openKey);
    const dialog = active?.dialog?.({
        open: true,
        onOpenChange: (next) => {
            if (!next) setOpenKey(null);
        },
    });

    if (visible.length === 1) {
        const action = visible[0];
        const className = cn(
            buttonVariants({ variant: "outline", size: "sm" }),
            "gap-1.5 bg-white",
            action.destructive
                ? "text-destructive border-destructive/30 hover:bg-destructive/5 hover:text-destructive"
                : "text-primary border-primary/20 hover:bg-primary/5 hover:text-primary",
        );

        return (
            <div className="flex justify-end">
                {action.to && !action.disabled ? (
                    <Link to={action.to} className={className}>
                        {action.icon}
                        {action.label}
                    </Link>
                ) : (
                    <button
                        type="button"
                        className={className}
                        disabled={action.disabled}
                        onClick={() => run(action)}
                    >
                        {action.icon}
                        {action.label}
                    </button>
                )}
                {dialog}
            </div>
        );
    }

    const regular = visible.filter((a) => !a.destructive);
    const destructive = visible.filter((a) => a.destructive);

    const renderItem = (action: RowAction) => (
        <DropdownMenuItem
            key={action.key}
            disabled={action.disabled}
            variant={action.destructive ? "destructive" : "default"}
            onClick={() => run(action)}
            className={cn(
                "gap-2 px-2 py-2 cursor-pointer",
                !action.destructive && "text-black focus:bg-primary/5 focus:text-primary",
            )}
        >
            {action.icon}
            <span>{action.label}</span>
        </DropdownMenuItem>
    );

    return (
        <div className="flex justify-end">
            <DropdownMenu>
                <DropdownMenuTrigger
                    aria-label={label}
                    className={cn(
                        buttonVariants({ variant: "ghost", size: "icon-sm" }),
                        "text-primary/60 hover:text-primary hover:bg-primary/5",
                    )}
                >
                    <MoreVertical className="size-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent
                    align="end"
                    className="w-52 bg-white text-black border-[0.5px] border-primary/10 rounded-md p-1 shadow-sm"
                >
                    {regular.map(renderItem)}
                    {regular.length > 0 && destructive.length > 0 && <DropdownMenuSeparator />}
                    {destructive.map(renderItem)}
                </DropdownMenuContent>
            </DropdownMenu>
            {dialog}
        </div>
    );
};

export default RowActions;
