import type { PropsWithChildren } from "react";
import { X } from "lucide-react";
import { Button } from "../ui/button"
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "../ui/sheet"
import { FaEdit } from "react-icons/fa";
import { cn } from "../../lib/utils";

type DetailsModalProps = PropsWithChildren<{
  title: string;
  ActionButton: React.ReactNode;
  TriggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}>

const FormModal = ({
  title,
  ActionButton,
  TriggerButton,
  children,
  open,
  onOpenChange
}: DetailsModalProps) => {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetTrigger
        render={
          TriggerButton ? (
            (TriggerButton as React.ReactElement)
          ) : (
            <Button
              className={cn(
                "hover:bg-[#143C2B] text-primary rounded-xs w-full justify-start p-1.5",
                "bg-secondary-muted hover:bg-secondary-muted"
              )}
            >
              <FaEdit className="text-primary" />
              <span>Edit</span>
            </Button>
          )
        }
      />
      <SheetContent className="min-w-[404px] bg-secondary border-[0.5px] border-primary/8 rounded-xl h-fit max-h-[90vh] overflow-auto inset-y-auto top-1/2 -translate-y-1/2 right-2 p-0 [&>button.absolute]:hidden">
        <SheetHeader className="border-b border-primary/10 text-white flex flex-row items-center justify-between">
          <SheetTitle className="text-white">{title}</SheetTitle>

          <SheetClose className="rounded-full text-primary bg-primary/8 size-6 flex items-center justify-center">
            <X className="size-4" />
          </SheetClose>
        </SheetHeader>

        {children}

        <SheetFooter>
          {ActionButton}
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}

export default FormModal;