import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { findCorperByEmail } from "../services/corpers.service";

/**
 * Opens a corps member's profile from a record that only knows their user
 * (e.g. a loan request), by resolving the corper profile through their email.
 */
export function useOpenCorperProfile() {
  const navigate = useNavigate();
  return useCallback(
    async (email?: string) => {
      if (!email) {
        toast.error("This record has no email to look the member up by.");
        return;
      }
      try {
        const corper = await findCorperByEmail(email);
        if (!corper) {
          toast.error("No corps member profile found for this user.");
          return;
        }
        navigate(`/corpers/${corper._id}`);
      } catch {
        toast.error("Could not open the member's profile.");
      }
    },
    [navigate],
  );
}
