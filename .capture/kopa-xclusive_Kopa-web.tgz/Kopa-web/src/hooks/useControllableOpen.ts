import { useCallback, useState } from "react";

/**
 * Lets a modal work both ways: with its own trigger button (uncontrolled), or
 * opened from outside — e.g. a row-actions menu item — via `open` +
 * `onOpenChange`. Opening from a menu matters because a dialog rendered
 * *inside* the menu popup unmounts the moment the menu closes.
 */
export function useControllableOpen(
  open?: boolean,
  onOpenChange?: (open: boolean) => void,
) {
  const [inner, setInner] = useState(false);
  const isControlled = open !== undefined;
  const value = isControlled ? open : inner;

  const setValue = useCallback(
    (next: boolean) => {
      if (!isControlled) setInner(next);
      onOpenChange?.(next);
    },
    [isControlled, onOpenChange],
  );

  return [value, setValue] as const;
}
