import { useQuery } from "@tanstack/react-query";
import { getSettings, type PlatformSettings } from "../services/settings.service";

/** Used until the API answers (and if it can't) — matches the backend defaults. */
export const FALLBACK_SETTINGS: PlatformSettings = {
    defaultCreditLimit: 20_000,
    maxCreditLimit: 50_000,
    creditLimitPresets: [10_000, 20_000, 30_000, 50_000],
    supportEmail: "",
    supportPhone: "",
    termsUrl: "",
    privacyUrl: "",
};

/** Platform settings, cached for a few minutes; never blocks a form from rendering. */
export function useSettings() {
    const query = useQuery({
        queryKey: ["platform-settings"],
        queryFn: getSettings,
        staleTime: 5 * 60_000,
        retry: false,
    });
    return { settings: query.data ?? FALLBACK_SETTINGS, query };
}
