import { useSearchParams } from "react-router-dom";
import { dayEndIso, dayStartIso } from "../utils/dateRange";
import { PERIODS, periodRange, type PeriodKey } from "../utils/periods";

export interface PeriodRange {
    /** Preset in use; ignored while a custom range is set. */
    period: PeriodKey;
    isCustom: boolean;
    /** Raw custom inputs (empty when a preset is in use). */
    customFrom: string;
    customTo: string;
    /** Effective YYYY-MM-DD bounds — for links into filtered pages. Empty = open-ended. */
    from: string;
    to: string;
    /** Effective ISO bounds the API takes. */
    startDate: string;
    endDate: string;
    /** Human label, e.g. "This month" or "2026-09-01 → 2026-09-30". */
    label: string;
    setPeriod: (key: PeriodKey) => void;
    setCustom: (from: string, to: string) => void;
}

/**
 * Period state kept in the URL so a filtered view can be shared or bookmarked:
 *   ?period=month|30d|90d|year|all   or   ?from=YYYY-MM-DD&to=YYYY-MM-DD
 * A custom range wins over a preset.
 */
export function usePeriodRange(defaultPeriod: PeriodKey = "month"): PeriodRange {
    const [searchParams, setSearchParams] = useSearchParams();
    const customFrom = searchParams.get("from") ?? "";
    const customTo = searchParams.get("to") ?? "";
    const isCustom = Boolean(customFrom || customTo);
    const raw = searchParams.get("period") as PeriodKey | null;
    const period = raw && PERIODS.some((p) => p.key === raw) ? raw : defaultPeriod;

    const preset = periodRange(period);
    const from = isCustom ? customFrom : preset.from;
    const to = isCustom ? customTo : preset.to;

    return {
        period,
        isCustom,
        customFrom,
        customTo,
        from,
        to,
        startDate: dayStartIso(from),
        endDate: dayEndIso(to),
        label: isCustom
            ? `${from || "start"} → ${to || "today"}`
            : PERIODS.find((p) => p.key === period)?.label ?? "",
        setPeriod: (key) => setSearchParams({ period: key }, { replace: true }),
        setCustom: (f, t) => {
            if (!f && !t) return setSearchParams({}, { replace: true });
            setSearchParams({ ...(f ? { from: f } : {}), ...(t ? { to: t } : {}) }, { replace: true });
        },
    };
}

/** `&from=…&to=…` for links into pages that read the same params ("" when open-ended). */
export const rangeQueryString = (r: Pick<PeriodRange, "from" | "to">) =>
    r.from || r.to ? `&from=${r.from}&to=${r.to}` : "";
