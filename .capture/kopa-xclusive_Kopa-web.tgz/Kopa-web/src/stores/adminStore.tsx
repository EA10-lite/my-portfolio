import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { setAuthToken, removeAuthToken, COOKIE_NAMES } from '../utils/cookies'
import type { AuthUser } from '../services/auth.service'

interface adminState {
  admin: AuthUser | null
  isAuthenticated: boolean
  login: (data: { user: AuthUser; accessToken: string; refreshToken?: string }) => void
  setAdmin: (user: AuthUser) => void
  logout: () => void
}

export const useAdminStore = create<adminState>()(
  persist(
    (set) => ({
      admin: null,
      isAuthenticated: false,
      login: ({ user, accessToken, refreshToken }) => {
        setAuthToken(accessToken, COOKIE_NAMES.ACCESS_TOKEN);
        // Storing the refresh token is what makes silent renewal possible —
        // without it every expired access token is a forced logout.
        if (refreshToken) setAuthToken(refreshToken, COOKIE_NAMES.REFRESH_TOKEN);
        set({ admin: user, isAuthenticated: true });
      },
      setAdmin: (user) => set({ admin: user }),
      logout: () => {
        removeAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
        removeAuthToken(COOKIE_NAMES.REFRESH_TOKEN);
        set({ admin: null, isAuthenticated: false });
      },
    }),
    {
      name: 'kopa-admin',
      storage: createJSONStorage(() => sessionStorage)
    }
  )
)

/** Only these roles may use the dashboard. */
export const isAdminRole = (role?: string) =>
  role === 'admin' || role === 'super_admin';

export const isSuperAdmin = (role?: string) => role === 'super_admin';
