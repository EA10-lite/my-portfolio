/**
 * Chart colours, validated with the dataviz palette checker (lightness band,
 * chroma, colour-blind separation, normal-vision floor all PASS on the light
 * surface). Colour follows the entity — a transaction type is always the same
 * colour on every chart — and several of these sit below 3:1 contrast, so
 * every chart that uses them also shows labelled values (legend or table).
 */
export const TYPE_COLORS: Record<string, string> = {
    disbursement: "#2a78d6",
    vendor_payment: "#eb6834",
    repayment: "#1baf7a",
    refund: "#eda100",
    payout: "#e87ba4",
    // Airtime/data/TV/power bought on credit. Validated as the 6th slot.
    bill_payment: "#7b61d1",
};

/** Single-series magnitude charts use the brand green. */
export const SERIES_COLOR = "#008751";

/** Status colours — reserved for state, always shown with a text label. */
export const STATUS_COLORS = {
    good: "#008751",
    info: "#2a78d6",
    neutral: "#8a8f98",
    warning: "#d97706",
    critical: "#dc2626",
};
