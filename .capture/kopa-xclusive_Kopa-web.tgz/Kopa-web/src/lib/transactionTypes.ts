import type { TransactionType } from "../pages/transactions/page";

export const TYPE_LABELS: Record<TransactionType, string> = {
  disbursement: "Disbursement",
  vendor_payment: "Vendor Payment",
  bill_payment: "Bill Payment",
  repayment: "Repayment",
  refund: "Refund",
  payout: "Vendor Payout",
};
