import type { QueryClient } from "@tanstack/react-query";

/**
 * Query-key groups that must refresh together after a mutation. Keeping them
 * here stops a modal from invalidating a key nobody uses (which is how KPI
 * cards went stale before) and keeps the sidebar badges and dashboard in sync.
 */
const GROUPS = {
    corpers: [
        "corpers",
        "corper",
        "corpers-stats",
        "admin-corpers",
        "admin-corpers-count",
        "recentCorpers",
        "dashboardStats",
        "dashboard-oldest-reviews",
        "sidebar-pending",
    ],
    loans: ["admin-loans", "admin-loans-count", "sidebar-pending", "dashboardStats", "corper"],
    vendors: [
        "admin-vendors",
        "admin-vendors-stats",
        "admin-vendors-count",
        "dashboardStats",
        "dashboard-oldest-reviews",
        "sidebar-pending",
    ],
    products: ["admin-products", "admin-products-count"],
    // Rejecting a payout returns the money to the vendor's balance.
    withdrawals: [
        "admin-withdrawals",
        "admin-withdrawals-count",
        "sidebar-pending",
        "admin-vendors",
        "admin-vendors-stats",
    ],
    admins: ["admin-users", "admin-users-count"],
} as const;

export function invalidateGroup(qc: QueryClient, group: keyof typeof GROUPS) {
    GROUPS[group].forEach((key) => qc.invalidateQueries({ queryKey: [key] }));
}
