import { BrowserRouter, Routes, Route, Navigate, useParams } from "react-router-dom";
import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import {
  ProtectedRoute,
  PublicRoute,
} from "./layouts";
import "./App.css";
import LoginPage from "./pages/auth/login/page";
import AppLayout from "./layouts/AppLayout";
import Dashboard from "./pages/dashboard/page";
import Vendors from "./pages/vendors/page";
import ProductsPage from "./pages/products/page";
import CorpsMembers from "./pages/corps-members/page";
import Settings from "./pages/settings/page";
import Transactions from "./pages/transactions/page";
import Verification from "./pages/verification/page";
import CorpMemberDetails from "./pages/corps-members/[id]/page";
import ReportsPage from "./pages/reports/page";
import DisputesPage from "./pages/disputes/page";
import OrdersPage from "./pages/orders/page";
import BillsPage from "./pages/bills/page";
import SupportPage from "./pages/support/page";
import RiskPage from "./pages/risk/page";
import AuditLogsPage from "./pages/audit-logs/page";
import NotificationsPage from "./pages/notifications/page";
import AdminUsersPage from "./pages/admin-users/page";
import LoansPage from "./pages/loans/page";
import WithdrawalsPage from "./pages/withdrawals/page";
import BanksPage from "./pages/banks/page";
import { Toaster } from "sonner";

// Created once at module load. Inside App() it would be rebuilt (and the
// whole cache dropped) on any re-render of the root.
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

const LegacyCorperRedirect = () => {
  const { id } = useParams();
  return <Navigate to={`/corpers/${id}`} replace />;
};

function App() {

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route
            path="/auth/login"
            element={
              <PublicRoute>
                <LoginPage />
              </PublicRoute>
            }
          />
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <AppLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/" element={<Dashboard />} />
            <Route path="vendors" element={<Vendors />} />
            <Route path="products" element={<ProductsPage />} />
            <Route path="corpers" element={<CorpsMembers />} />
            <Route path="corpers/:id" element={<CorpMemberDetails />} />
            {/* Old URLs, kept so existing links and bookmarks still land. */}
            <Route path="corps-members" element={<Navigate to="/corpers" replace />} />
            <Route path="corps-members/:id" element={<LegacyCorperRedirect />} />
            <Route path="loans" element={<LoansPage />} />
            <Route path="withdrawals" element={<WithdrawalsPage />} />
            <Route path="banks" element={<BanksPage />} />
            <Route path="transactions" element={<Transactions />} />
            <Route path="verification" element={<Verification />} />
            <Route path="notifications" element={<NotificationsPage />} />
            <Route path="reports" element={<ReportsPage />} />
            <Route path="disputes" element={<DisputesPage />} />
            <Route path="orders" element={<OrdersPage />} />
            <Route path="bills" element={<BillsPage />} />
            <Route path="support" element={<SupportPage />} />
            <Route path="risk" element={<RiskPage />} />
            <Route path="audit-logs" element={<AuditLogsPage />} />
            <Route path="settings" element={<Settings />} />
            <Route path="admin-users" element={<AdminUsersPage />} />
          </Route>
        </Routes>
        <Toaster />
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
