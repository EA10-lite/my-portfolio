import {
  Activity,
  Banknote,
  Landmark,
  Wallet,
  AlertTriangle,
  Bell,
  ClipboardList,
  CreditCard,
  Package,
  LayoutDashboard,
  LogOut,
  Settings,
  ShieldCheck,
  Store,
      Users,
  UserCog,
  LifeBuoy,
  Scale,
  ShoppingBag,
  Zap,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "../components/ui/sidebar"

import { Link, useLocation } from "react-router-dom";
import { cn } from "../lib/utils";
import { useQueries } from "@tanstack/react-query";
import { useAdminStore, isSuperAdmin } from "../stores/adminStore";
import { logoutService } from "../services/auth.service";
import { COOKIE_NAMES, getAuthToken } from "../utils/cookies";
import { getLoans } from "../services/loans.service";
import { getWithdrawals } from "../services/withdrawals.service";
import { getCorpers } from "../services/corpers.service";
import { getTicketStats } from "../services/support.service";
import { getDisputeStats } from "../services/disputes.service";
import { getBillReviews } from "../services/bills.service";
import { getOrders } from "../services/orders.service";
import { getVendorsService } from "../services/vendors.service";


// Menu items.
const items = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Corp Members",
    url: "/corpers",
    icon: Users,
  },
  {
    title: "Credit Requests",
    url: "/loans",
    icon: Banknote,
  },
  {
    title: "Transactions",
    url: "/transactions",
    icon: CreditCard,
  },
  {
    title: "Reports",
    url: "/reports",
    icon: Activity,
  },
  {
    title: "Vendors",
    url: "/vendors",
    icon: Store ,
  },
  {
    title: "Orders",
    url: "/orders",
    icon: ShoppingBag,
  },
  {
    title: "Bill Payments",
    url: "/bills",
    icon: Zap,
  },
  {
    title: "Products",
    url: "/products",
    icon: Package,
  },
  {
    title: "Payouts",
    url: "/withdrawals",
    icon: Wallet,
  },
    {
    title: "Admin Users",
    url: "/admin-users",
    icon: UserCog,
    superAdminOnly: true,
  },
  {
    title: "Verification",
    url: "/verification",
    icon: ShieldCheck,
  },
  {
    title: "Risk",
    url: "/risk",
    icon: AlertTriangle,
  },
  {
    title: "Disputes",
    url: "/disputes",
    icon: Scale,
  },
  {
    title: "Audit Logs",
    url: "/audit-logs",
    icon: ClipboardList,
  },
    {
    title: "Support",
    url: "/support",
    icon: LifeBuoy,
  },
  {
    title: "Notifications",
    url: "/notifications",
    icon: Bell,
  },
  {
    title: "Banks",
    url: "/banks",
    icon: Landmark,
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
  },
];

/** Queues whose pending count an admin should see without opening the page. */
const PENDING_BADGES: Record<string, () => Promise<number>> = {
  "/loans": async () => (await getLoans({ status: "pending", page: 1, limit: 1 })).meta?.total ?? 0,
      // Every payout waiting on an admin: approval, the Paystack OTP, or a reconcile.
  "/withdrawals": async () => {
    const results = await Promise.all([
      getWithdrawals({ status: "pending", page: 1, limit: 1 }),
      getWithdrawals({ status: "otp_pending", page: 1, limit: 1 }),
      getWithdrawals({ requiresReconciliation: true, page: 1, limit: 1 }),
    ]);
    return results.reduce((sum, r) => sum + (r.meta?.total ?? 0), 0);
  },
    // Support tickets waiting on Kopa (new or the user replied).
  "/support": async () => (await getTicketStats())?.open ?? 0,
  // Disputes nobody has picked up yet.
  "/disputes": async () => (await getDisputeStats())?.open ?? 0,
  // Orders frozen by a dispute.
  "/orders": async () => (await getOrders({ status: "disputed", page: 1, limit: 1 }))?.meta?.total ?? 0,
  // Bill purchases VTpass reversed after delivery.
  "/bills": async () => (await getBillReviews({ page: 1, limit: 1 }))?.meta?.total ?? 0,
  // KYC + KYB submissions still waiting for a decision.
  "/verification": async () => {
    const [c, v] = await Promise.all([
      getCorpers({ kycStatus: "submitted", page: 1, limit: 1 }),
      getVendorsService({ kybStatus: "submitted", page: 1, limit: 1 }),
    ]);
    return (c?.data?.meta?.total ?? 0) + (v?.data?.meta?.total ?? 0);
  },
};

const AppSidebar = () => {
  const { pathname } = useLocation();
  // Nested pages (e.g. /corpers/:id) keep their parent item highlighted.
  const isActive = (url: string) =>
    url === "/" ? pathname === "/" : pathname === url || pathname.startsWith(`${url}/`);
  const { logout, admin } = useAdminStore();
  // Revoke this session's refresh token on the server before clearing local
  // state; otherwise the token stays valid until it expires.
  const handleLogout = async () => {
    await logoutService(getAuthToken(COOKIE_NAMES.REFRESH_TOKEN));
    logout();
  };
  const visibleItems = items.filter(
    (item) => !("superAdminOnly" in item && item.superAdminOnly) || isSuperAdmin(admin?.role),
  );

  // One cheap limit:1 request each, just to read back meta.total. Refreshed on
  // a slow interval so an admin sitting on the dashboard sees new work arrive.
  const badges = useQueries({
    queries: Object.entries(PENDING_BADGES).map(([url, fetcher]) => ({
      queryKey: ["sidebar-pending", url],
      queryFn: fetcher,
      retry: false,
      refetchInterval: 60_000,
    })),
  });
  const badgeFor = (url: string) => {
    const index = Object.keys(PENDING_BADGES).indexOf(url);
    return index === -1 ? 0 : (badges[index]?.data ?? 0);
  };

  return (
    <Sidebar className="border-primary/10 m-0 border-r-[0.5px] bg-primary w-64">
      <SidebarContent className="bg-primary">
        <SidebarGroupLabel className="h-auto px-5 pt-7 pb-6">
          {/* The logo is green on green otherwise — the white tile gives it an edge. */}
          <Link to="/" className="flex items-center gap-3 rounded-md focus-visible:outline-2 focus-visible:outline-white/70">
            <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm">
              <img src="/images/kopa-logo.png" className="h-10 w-auto" alt="" />
            </span>
            <span className="flex flex-col leading-tight">
              <span className="text-base font-semibold text-white">Kopa Xclusive</span>
              <span className="text-xs font-normal text-white/70">Admin</span>
            </span>
          </Link>
        </SidebarGroupLabel>
        <SidebarGroupContent className="px-4 flex-1">
          <SidebarMenu className="space-y-4">
            {visibleItems.map((item) => (
              <SidebarMenuItem
                key={item.title}
                className=""
              >
                <SidebarMenuButton
                  className={
                    cn(
                      "py-5 px-4 rounded-xs transition-colors rounded-md",
                      isActive(item.url)
                        ? "text-primary bg-white border-[0.5px] border-primary/10 hover:bg-white hover:text-primary"
                        : "text-white hover:bg-white hover:text-primary"
                    )
                  }
                >
                  <Link to={item.url} className="flex items-center gap-2 w-full">
                    <item.icon />
                    <span className="flex-1">{item.title}</span>
                    {badgeFor(item.url) > 0 && (
                      <span
                        className={cn(
                          "min-w-5 px-1.5 py-0.5 rounded-full text-[11px] font-semibold text-center",
                          isActive(item.url)
                            ? "bg-primary text-white"
                            : "bg-white text-primary",
                        )}
                        aria-label={`${badgeFor(item.url)} awaiting action`}
                      >
                        {badgeFor(item.url) > 99 ? "99+" : badgeFor(item.url)}
                      </span>
                    )}
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroupContent>

        <SidebarFooter className="px-4">
          <SidebarMenuButton
            className="px-4 py-5 text-white hover:bg-transparent hover:text-primary active:bg-transparent"
            onClick={handleLogout}
          >
            <LogOut />
            <span className="text-white">Logout</span>
          </SidebarMenuButton>
        </SidebarFooter>
      </SidebarContent>
    </Sidebar>
  )
}


export default AppSidebar;
