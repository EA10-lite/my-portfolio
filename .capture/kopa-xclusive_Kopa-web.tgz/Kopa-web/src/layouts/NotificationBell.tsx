import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, CheckCheck } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "../components/ui/popover";
import { cn } from "../lib/utils";
import { formatTime } from "../utils/formatter";
import {
    getMyNotifications,
    linkFor,
    markAllNotificationsRead,
    markNotificationRead,
    type MyNotification,
} from "../services/notifications.service";

/**
 * The admin's own alerts: new KYC/KYB, credit requests, payout requests,
 * disputes, tickets and bill reversals. Clicking one marks it read and opens
 * the queue it belongs to.
 */
const NotificationBell = () => {
    const [open, setOpen] = useState(false);
    const navigate = useNavigate();
    const qc = useQueryClient();
    const q = useQuery({
        queryKey: ["my-notifications"],
        queryFn: () => getMyNotifications({ page: 1, limit: 15 }),
        refetchInterval: 60_000,
        retry: false,
    });
    const items = q.data?.data ?? [];
    const unread = q.data?.unread ?? 0;

    const refresh = () => qc.invalidateQueries({ queryKey: ["my-notifications"] });
    const readOne = useMutation({ mutationFn: markNotificationRead, onSuccess: refresh });
    const readAll = useMutation({ mutationFn: markAllNotificationsRead, onSuccess: refresh });

    const openItem = (n: MyNotification) => {
        if (!n.read) readOne.mutate(n._id);
        const to = linkFor(n);
        if (to) {
            setOpen(false);
            navigate(to);
        }
    };

    return (
        <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger
                aria-label={unread ? `Notifications, ${unread} unread` : "Notifications"}
                className="relative flex size-10 items-center justify-center rounded-full text-black/70 hover:bg-primary/5 hover:text-black focus-visible:outline-2 focus-visible:outline-primary"
            >
                <Bell className="size-5" />
                {unread > 0 && (
                    <span className="absolute top-1 right-1 min-w-4 h-4 px-1 rounded-full bg-red-600 text-[10px] leading-4 font-semibold text-white text-center tabular-nums">
                        {unread > 99 ? "99+" : unread}
                    </span>
                )}
            </PopoverTrigger>
            <PopoverContent align="end" className="w-[min(22rem,calc(100vw-2rem))] p-0 gap-0 bg-white text-black">
                <div className="flex items-center justify-between px-3 py-2.5 border-b border-primary/10">
                    <p className="text-sm font-medium">Notifications</p>
                    <button
                        type="button"
                        disabled={unread === 0 || readAll.isPending}
                        onClick={() => readAll.mutate()}
                        className="flex items-center gap-1 text-xs text-primary disabled:text-black/30"
                    >
                        <CheckCheck className="size-3.5" /> Mark all read
                    </button>
                </div>
                <div className="max-h-[60vh] overflow-y-auto">
                    {q.isLoading ? (
                        <p className="p-4 text-sm text-black/50">Loading…</p>
                    ) : q.isError ? (
                        <p className="p-4 text-sm text-red-700">Couldn't load notifications.</p>
                    ) : items.length === 0 ? (
                        <p className="p-4 text-sm text-black/50">
                            You're all caught up. New KYC, credit requests, payouts, disputes and tickets will show up here.
                        </p>
                    ) : (
                        items.map((n) => (
                            <button
                                key={n._id}
                                type="button"
                                onClick={() => openItem(n)}
                                className={cn(
                                    "w-full text-left px-3 py-2.5 border-b border-primary/5 last:border-none hover:bg-primary/3 flex gap-2.5",
                                    !n.read && "bg-primary/[0.04]",
                                )}
                            >
                                <span
                                    className={cn("mt-1.5 size-2 shrink-0 rounded-full", n.read ? "bg-transparent" : "bg-primary")}
                                    aria-hidden
                                />
                                <span className="min-w-0">
                                    <span className={cn("block text-sm", !n.read && "font-medium")}>{n.title}</span>
                                    <span className="block text-xs text-black/60 line-clamp-2">{n.body}</span>
                                    <span className="block text-[11px] text-black/40 mt-0.5">{formatTime(n.createdAt)}</span>
                                </span>
                            </button>
                        ))
                    )}
                </div>
            </PopoverContent>
        </Popover>
    );
};

export default NotificationBell;
