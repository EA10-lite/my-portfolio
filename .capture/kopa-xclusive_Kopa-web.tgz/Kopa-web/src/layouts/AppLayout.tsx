import { Outlet } from "react-router-dom";
import { SidebarInset, SidebarProvider, SidebarTrigger } from "../components/ui/sidebar";
import Navbar from "./Navbar";
import AppSidebar from "./Sidebar";
import { cn } from "../lib/utils";

/**
 * Top-level layout responsible for synchronising the sidebar and navbar.
 * Uses shadcn/ui SidebarProvider for state management.
 */
const LayoutContent = () => {

  return (
    <SidebarInset
      className={cn(
        "min-w-0 border-l border-primary/10 border-none transition-[padding-left] duration-200"
      )}
    >
      <header className="flex h-16 shrink-0 items-center border-b border-primary/10 px-4 bg-secondary">
        <SidebarTrigger className="-ml-1 text-primary" />
        <div className="h-4 w-px bg-primary mx-2" />
        <Navbar />
      </header>
      <div className="flex min-w-0 flex-1 flex-col gap-4 p-4 bg-secondary text-white">
        <Outlet />
      </div>
    </SidebarInset>
  );
};

const AppLayout = () => {
  return (
    <SidebarProvider className="bg-secondary">
      <AppSidebar />
      <LayoutContent />
    </SidebarProvider>
  );
};

export default AppLayout;