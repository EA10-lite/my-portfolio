import { Navigate } from 'react-router-dom'
import { COOKIE_NAMES, getAuthToken } from '../utils/cookies'

interface PublicRouteProps {
  children: React.ReactNode
}

/**
 * Mirrors ProtectedRoute: the token is the source of truth, not the persisted
 * `isAuthenticated` flag. Otherwise a stale flag with no cookie would bounce
 * the admin away from the login page they need.
 */
const PublicRoute = ({ children }: PublicRouteProps) => {
  const hasToken = Boolean(getAuthToken(COOKIE_NAMES.ACCESS_TOKEN))

  return hasToken ? <Navigate to="/" replace /> : <>{children}</>
}

export default PublicRoute
