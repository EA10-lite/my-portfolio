import NotificationBell from "./NotificationBell";
import { Text } from "../components";
import { Avatar, AvatarFallback } from "../components/ui/avatar";
import { useLocation } from "react-router-dom";
import { useAdminStore } from "../stores/adminStore";

const TITLES: [string, string][] = [
  ["/corpers/", "Corps member profile"],
  ["/corpers", "Corp Members"],
  ["/loans", "Credit Requests"],
  ["/transactions", "Transactions"],
  ["/reports", "Reports"],
  ["/vendors", "Vendors"],
  ["/products", "Products"],
  ["/withdrawals", "Payouts"],
  ["/admin-users", "Admin Users"],
  ["/verification", "Verification"],
  ["/risk", "Risk & Collections"],
  ["/disputes", "Disputes"],
  ["/orders", "Orders"],
  ["/bills", "Bill Payments"],
  ["/audit-logs", "Audit Logs"],
    ["/notifications", "Notifications"],
  ["/support", "Support"],
  ["/banks", "Banks"],
  ["/settings", "Settings"],
];

const titleFor = (pathname: string) =>
  TITLES.find(([prefix]) => pathname.startsWith(prefix))?.[1] ?? "Dashboard";

const ROLE_LABELS: Record<string, string> = { super_admin: "Super Admin", admin: "Admin" };


const Navbar = () => {
  const { admin } = useAdminStore();
  const { pathname } = useLocation();

  const getInitials = (name: string) => {
    return name.split(" ").map((word) => word.charAt(0)).join("");
  }
  return (
    <div className="navbar w-full">
      <div className="flex items-center justify-between w-full">
        <Text
          title={titleFor(pathname)}
          type="h4"
          className="font-medium text-lg text-black"
        />

        <div className="flex items-center gap-2">
          <NotificationBell />
          <Avatar className="size-10">
            <AvatarFallback className="bg-primary/5 text-primary">
              {getInitials(admin?.fullName || "")}
            </AvatarFallback>
          </Avatar>
          <div className="hidden sm:block">
            <Text
              title={admin?.fullName || "EA"}
              type="h4"
              className="font-medium text-black"
            />
            <Text
              title={ROLE_LABELS[admin?.role ?? ""] ?? "Admin"}
              type="p"
              className="text-grey text-xs"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default Navbar;