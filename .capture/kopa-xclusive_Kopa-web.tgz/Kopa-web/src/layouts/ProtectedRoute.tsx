import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { useAdminStore, isAdminRole } from '../stores/adminStore'
import { COOKIE_NAMES, getAuthToken } from '../utils/cookies'
import { getMe } from '../services/auth.service'

interface ProtectedRouteProps {
  children: React.ReactNode
}

/**
 * Auth state lives in two places that can drift apart: `isAuthenticated` in
 * sessionStorage, and the tokens in cookies. Either can outlive the other —
 * a cleared cookie, an expired session, or a second tab where sessionStorage
 * is empty but the cookie is still valid.
 *
 * So the route trusts the *token*, and reconciles the store against it:
 *   - flagged authenticated but no token  → stale flag, sign out
 *   - token but no store                  → rehydrate from GET /auth/me
 *   - neither                             → login
 */
const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { isAuthenticated, admin, setAdmin, logout } = useAdminStore()
  const hasToken = Boolean(getAuthToken(COOKIE_NAMES.ACCESS_TOKEN))

  // A token with no cached admin means this tab has to fetch the profile
  // before it can render. Derived, so the effect never has to setState
  // synchronously just to describe the current situation.
  const needsRehydrate = hasToken && !admin
  const [rehydrateSettled, setRehydrateSettled] = useState(false)

  useEffect(() => {
    // Stale flag with no token — nothing can succeed, so clear it. This writes
    // to an external store, not local state.
    if (isAuthenticated && !hasToken) {
      logout()
      return
    }

    if (!needsRehydrate) return

    let cancelled = false
    getMe()
      .then((user) => {
        if (cancelled) return
        // A corper or vendor token must not unlock the dashboard.
        if (!isAdminRole(user?.role)) {
          logout()
          return
        }
        setAdmin(user)
      })
      .catch(() => {
        // Invalid or expired token — the interceptor will have cleared it.
        if (!cancelled) logout()
      })
      .finally(() => {
        if (!cancelled) setRehydrateSettled(true)
      })

    return () => {
      cancelled = true
    }
  }, [isAuthenticated, hasToken, needsRehydrate, logout, setAdmin])

  const rehydrating = needsRehydrate && !rehydrateSettled

  if (rehydrating) {
    return (
      <div className="flex min-h-screen items-center justify-center text-sm text-black/50">
        Restoring your session…
      </div>
    )
  }

  if (!hasToken) return <Navigate to="/auth/login" replace />

  return <>{children}</>
}

export default ProtectedRoute
