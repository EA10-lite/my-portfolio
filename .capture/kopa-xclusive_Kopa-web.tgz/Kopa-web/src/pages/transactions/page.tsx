import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import DateRangeFilter from "../../components/main/DateRangeFilter";
import { dayEndIso, dayStartIso } from "../../utils/dateRange";
import { formatCurrency, formatDateString } from "../../utils/formatter";
import { Badge } from "../../components/ui/badge";
import { getTransactions, getTransactionStats } from "../../services/api.service";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import { Copy, Eye, FileText, ArrowDownToLine, ArrowRightLeft, RefreshCw, Scale, User, X } from "lucide-react";
import LogDisputeModal from "../disputes/_components/LogDisputeModal";
import { cn } from "../../lib/utils";
import TransactionDetailsModal from "./_components/TransactionDetailsModal";

import { TYPE_LABELS } from "../../lib/transactionTypes";

export type TransactionType = "disbursement" | "vendor_payment" | "bill_payment" | "repayment" | "refund" | "payout";

export interface AdminTransactionRef {
  _id: string;
  fullName?: string;
  businessName?: string;
  email?: string;
}

export interface AdminTransaction {
  _id: string;
  reference: string;
  type: TransactionType;
  amount: number;
  user?: AdminTransactionRef | null;
  corper?: AdminTransactionRef | null;
  vendor?: AdminTransactionRef | null;
  idempotencyKey?: string;
  meta?: Record<string, unknown>;
  createdAt: string;
}

const typeBadgeVariant = (type: TransactionType) => {
  if (type === "disbursement") return "purple" as const;
  if (type === "vendor_payment") return "default" as const;
  if (type === "repayment") return "pending" as const;
  if (type === "payout") return "new" as const;
  if (type === "bill_payment") return "outline" as const;
  return "secondary" as const;
};

const copyReference = async (reference: string) => {
  try {
    await navigator.clipboard.writeText(reference);
    toast.success("Reference copied");
  } catch {
    toast.error("Could not copy to the clipboard");
  }
};

interface TypeBucket { count?: number; amount?: number }

/**
 * The money-movement ledger. Every filter here — type, member, reference
 * search and the date range — is applied by the API across the full
 * history, and the KPI cards follow the date range.
 *
 * URL params (so other pages and the Reports drill-down can link in):
 *   ?type=…  ?userId=…&name=…  ?from=YYYY-MM-DD  ?to=YYYY-MM-DD
 */
const Transactions = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const userId = searchParams.get("userId") ?? "";
  const memberName = searchParams.get("name") ?? "";
  const type = searchParams.get("type") ?? "";
  const from = searchParams.get("from") ?? "";
  const to = searchParams.get("to") ?? "";

  const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 20 });
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search.trim());

  const setParams = (updates: Record<string, string>) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  const range = { startDate: dayStartIso(from), endDate: dayEndIso(to) };
  const filters = { type, userId, search: debouncedSearch, ...range };

  const transactionsQuery = useQuery({
    queryKey: ["admin-transactions", pagination.pageIndex, pagination.pageSize, filters],
    queryFn: () => getTransactions({ page: pagination.pageIndex + 1, limit: pagination.pageSize, ...filters }),
    retry: false,
  });

  const statsQuery = useQuery({
    queryKey: ["admin-transactions-stats", range],
    queryFn: () => getTransactionStats(range),
    retry: false,
  });

  const raw = (
    transactionsQuery.data as {
      data?: { data?: AdminTransaction[]; meta?: { total?: number; totalPages?: number } };
    }
  )?.data;
  const rows: AdminTransaction[] = raw?.data ?? [];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

  const stats = (
    statsQuery.data as {
      data?: {
        totalCount?: number;
        totalAmount?: number;
        disbursement?: TypeBucket;
        vendorPayment?: TypeBucket;
        repayment?: TypeBucket;
        payout?: TypeBucket;
      };
    }
  )?.data;

  const columns: ColumnDef<AdminTransaction>[] = useMemo(
    () => [
      {
        accessorKey: "reference",
        header: "Reference",
        cell: ({ row }) => <span className="text-black font-medium font-mono text-xs">{row.original.reference}</span>,
      },
      {
        accessorKey: "type",
        header: "Type",
        cell: ({ row }) => {
          const t = row.original.type;
          return (
            <Badge className="font-normal" variant={typeBadgeVariant(t)}>
              {TYPE_LABELS[t] ?? t}
            </Badge>
          );
        },
      },
      {
        id: "corper",
        header: "Corps Member",
        cell: ({ row }) => {
          const name = row.original.corper?.fullName || row.original.user?.fullName;
          return name ? <span className="text-black">{name}</span> : <span className="text-black/40 text-xs">—</span>;
        },
      },
      {
        id: "vendor",
        header: "Vendor",
        cell: ({ row }) =>
          row.original.vendor?.businessName ? (
            <span className="text-black">{row.original.vendor.businessName}</span>
          ) : (
            <span className="text-black/40 text-xs">—</span>
          ),
      },
      {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ row }) => <span className="text-black font-semibold">{formatCurrency(row.original.amount ?? 0)}</span>,
      },
      {
        accessorKey: "createdAt",
        header: "Date",
        cell: ({ row }) => <span className="text-black text-sm">{formatDateString(row.original.createdAt)}</span>,
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const t = row.original;
          return (
            <RowActions
              actions={[
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  dialog: (p) => <TransactionDetailsModal transaction={t} {...p} />,
                },
                {
                  key: "member",
                  label: "View member",
                  icon: <User className="size-4" />,
                  hidden: !t.corper?._id,
                  to: `/corpers/${t.corper?._id}`,
                },
                {
                  key: "copy",
                  label: "Copy reference",
                  icon: <Copy className="size-4" />,
                  hidden: !t.reference,
                  onSelect: () => copyReference(t.reference),
                },
                {
                  key: "dispute",
                  label: "Log dispute",
                  icon: <Scale className="size-4" />,
                  hidden: !t.reference || (t.type !== "vendor_payment" && t.type !== "bill_payment"),
                  dialog: (p) => <LogDisputeModal initialCode={t.reference} open={p.open} onOpenChange={p.onOpenChange} />,
                },
              ]}
            />
          );
        },
      },
    ],
    [],
  );

  const kpis = [
    { label: from || to ? "Transactions in range" : "Total transactions", value: (stats?.totalCount ?? 0).toLocaleString(), icon: <FileText className="size-4" />, tone: "bg-blue-50 border-blue-100 text-blue-600" },
    { label: "Disbursements", value: formatCurrency(stats?.disbursement?.amount ?? 0), icon: <ArrowDownToLine className="size-4" />, tone: "bg-violet-50 border-violet-100 text-violet-600" },
    { label: "Vendor payments", value: formatCurrency(stats?.vendorPayment?.amount ?? 0), icon: <ArrowRightLeft className="size-4" />, tone: "bg-emerald-50 border-emerald-100 text-emerald-600" },
    { label: "Repayments collected", value: formatCurrency(stats?.repayment?.amount ?? 0), icon: <RefreshCw className="size-4" />, tone: "bg-orange-50 border-orange-100 text-orange-600" },
  ];

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <Text title="Transactions" type="h4" className="text-lg text-black" />
            <p className="text-sm text-black/60 mt-1">
              The money-movement ledger — every disbursement, vendor payment, bill payment, repayment and payout.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <DateRangeFilter
              from={from}
              to={to}
              setFrom={(v) => setParams({ from: v })}
              setTo={(v) => setParams({ to: v })}
              clear={() => setParams({ from: "", to: "" })}
              isActive={Boolean(from || to)}
            />
            <ExportButton
              filename="transactions"
              disabled={total === 0}
              fetchPage={async (page, limit) => {
                const res = await getTransactions({ ...filters, page, limit });
                return { rows: res?.data?.data ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
              }}
              columns={[
                { header: "Reference", value: (t: AdminTransaction) => t.reference },
                { header: "Type", value: (t: AdminTransaction) => TYPE_LABELS[t.type] ?? t.type },
                { header: "Amount", value: (t: AdminTransaction) => t.amount },
                { header: "Corps Member", value: (t: AdminTransaction) => t.corper?.fullName ?? t.user?.fullName },
                { header: "Vendor", value: (t: AdminTransaction) => t.vendor?.businessName },
                { header: "Date", value: (t: AdminTransaction) => t.createdAt },
              ]}
            />
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {userId && (
          <div className="flex items-center justify-between gap-3 bg-primary/5 border border-primary/15 text-sm text-black rounded-sm px-4 py-3">
            <span>
              Showing transactions for <strong>{memberName || "one member"}</strong>
            </span>
            <button
              type="button"
              onClick={() => setParams({ userId: "", name: "" })}
              className="inline-flex items-center gap-1 text-black/60 hover:text-black"
            >
              <X className="size-4" /> Show everyone
            </button>
          </div>
        )}
        {transactionsQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load transactions from the server. Check your connection and try again.
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpis.map((k) => (
            <div key={k.label} className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3">
              <div className={cn("w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]", k.tone)}>{k.icon}</div>
              <Text title={k.value} type="h2" className="text-2xl font-medium text-black" />
              <Text title={k.label} type="h4" className="text-black" />
            </div>
          ))}
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          search={{
            value: search,
            onChange: (v) => {
              setSearch(v);
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            },
            placeholder: "Search by reference",
          }}
          filters={[
            {
              columnKey: "type",
              title: "Type",
              options: (Object.keys(TYPE_LABELS) as TransactionType[]).map((t) => ({ label: TYPE_LABELS[t], value: t })),
            },
          ]}
          filterValues={{ type }}
          onFilterChange={(key, value) => setParams({ [key]: value })}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={transactionsQuery.isLoading}
          rowCount={total}
          emptyMessage={
            type || userId || from || to || debouncedSearch ? "No transactions match these filters." : "No transactions yet."
          }
        />
      </div>
    </div>
  );
};

export default Transactions;
