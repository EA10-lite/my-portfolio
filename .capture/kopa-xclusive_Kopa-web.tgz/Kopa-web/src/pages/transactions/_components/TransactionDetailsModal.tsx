import { DetailsModal, ModalFieldItem } from "../../../components";
import NotBackedBanner from "../../../components/main/NotBackedBanner";
import { type AdminTransaction } from "../page";
import { TYPE_LABELS } from "../../../lib/transactionTypes";
import { formatDateString } from "../../../utils/formatter";



const TransactionDetailsModal = ({
  transaction,
  triggerButton,
  open,
  onOpenChange,
}: {
  transaction: AdminTransaction;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  return (
    <DetailsModal title="Transaction Details" TriggerButton={triggerButton} open={open} onOpenChange={onOpenChange}>
      <div className="p-4 space-y-3">
        <NotBackedBanner variant="readonly" title="Read-only record">
          The ledger is immutable by design — every financial operation writes a permanent row, and the API exposes no endpoint to amend or reverse one. Corrections are made by recording a new transaction.
        </NotBackedBanner>
        <ModalFieldItem label="Reference" value={transaction.reference} />
        <ModalFieldItem label="Type" value={TYPE_LABELS[transaction.type]} />
        <ModalFieldItem label="Amount" value={`₦${transaction.amount.toLocaleString()}`} />
        <ModalFieldItem
          label="Corps Member"
          value={transaction.corper?.fullName || transaction.user?.fullName || "N/A"}
        />
        <ModalFieldItem label="Vendor" value={transaction.vendor?.businessName || "N/A"} />
        <ModalFieldItem label="Idempotency Key" value={transaction.idempotencyKey || "N/A"} />
        <ModalFieldItem label="Recorded At" value={formatDateString(transaction.createdAt)} />
      </div>
    </DetailsModal>
  );
};

export default TransactionDetailsModal;
