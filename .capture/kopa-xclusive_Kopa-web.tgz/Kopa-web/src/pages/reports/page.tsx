import { useMemo } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useQueries, useQuery } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, Cell, LabelList, XAxis, YAxis } from "recharts";
import { ExportButton, Text } from "../../components";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "../../components/ui/chart";
import { Skeleton } from "../../components/ui/skeleton";
import { EmptyState } from "../../components/ui/empty-state";
import DateRangeFilter from "../../components/main/DateRangeFilter";
import { PiExport } from "react-icons/pi";
import { cn } from "../../lib/utils";
import { SERIES_COLOR, STATUS_COLORS, TYPE_COLORS } from "../../lib/chartColors";
import { formatCompactNaira, formatCurrency } from "../../utils/formatter";
import { downloadCsv } from "../../utils/csv";
import { dayEndIso, dayStartIso, toDayString } from "../../utils/dateRange";
import { PERIODS, periodRange, type PeriodKey } from "../../utils/periods";
import {
  getRiskSummary,
  getTransactionMonthlyVolume,
  getTransactionStats,
  getTransactions,
} from "../../services/api.service";
import { getLoans } from "../../services/loans.service";
import { type AdminTransaction, type TransactionType } from "../transactions/page";
import { TYPE_LABELS } from "../../lib/transactionTypes";

interface MonthlyVolumeRow { month: string; amount: number; count: number }
interface Bucket { count?: number; amount?: number }
interface TxnStats {
  totalCount?: number;
  totalAmount?: number;
  disbursement?: Bucket;
  vendorPayment?: Bucket;
  repayment?: Bucket;
  refund?: Bucket;
  payout?: Bucket;
  billPayment?: Bucket;
}
interface RiskSummary {
  outstandingAmount: number;
  collectedAmount: number;
  scheduled: Bucket;
  processing: Bucket;
  overdue: Bucket;
  defaulted: Bucket;
  debited: Bucket;
}

const TYPE_ROWS: { type: TransactionType; statsKey: keyof TxnStats }[] = [
  { type: "disbursement", statsKey: "disbursement" },
  { type: "vendor_payment", statsKey: "vendorPayment" },
  { type: "repayment", statsKey: "repayment" },
  { type: "refund", statsKey: "refund" },
  { type: "payout", statsKey: "payout" },
  { type: "bill_payment", statsKey: "billPayment" },
];

const volumeConfig = { amount: { label: "Volume", color: SERIES_COLOR } } satisfies ChartConfig;
const genericConfig = { value: { label: "Value" } } satisfies ChartConfig;

/** Month index i of n (oldest first) → that calendar month's YYYY-MM-DD bounds. */
const monthBounds = (i: number, n: number) => {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - (n - 1 - i), 1);
  const end = new Date(start.getFullYear(), start.getMonth() + 1, 0);
  return { from: toDayString(start), to: toDayString(end) };
};

/**
 * Reports & Analytics. Every figure is aggregated by the API; the period
 * (preset or custom range) drives the ledger figures, and every bar is a
 * drill-down into the filtered list behind it.
 *
 * URL: ?period=month|30d|90d|year|all  or  ?from=YYYY-MM-DD&to=YYYY-MM-DD
 */
const ReportsPage = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const customFrom = searchParams.get("from") ?? "";
  const customTo = searchParams.get("to") ?? "";
  const isCustom = Boolean(customFrom || customTo);
  const period = (searchParams.get("period") as PeriodKey) || "month";

  const preset = periodRange(period);
  const from = isCustom ? customFrom : preset.from;
  const to = isCustom ? customTo : preset.to;
  const range = { startDate: dayStartIso(from), endDate: dayEndIso(to) };
  const rangeQuery = from || to ? `&from=${from}&to=${to}` : "";
  const periodLabel = isCustom
    ? `${from || "start"} → ${to || "today"}`
    : PERIODS.find((p) => p.key === period)?.label ?? "";

  const setPeriod = (key: PeriodKey) => setSearchParams({ period: key }, { replace: true });
  const setCustom = (f: string, t: string) => {
    if (!f && !t) return setSearchParams({}, { replace: true });
    setSearchParams({ ...(f ? { from: f } : {}), ...(t ? { to: t } : {}) }, { replace: true });
  };

  const statsQuery = useQuery({
    queryKey: ["admin-transactions-stats", range],
    queryFn: () => getTransactionStats(range),
    retry: false,
  });
  const volumeQuery = useQuery({
    queryKey: ["admin-transactions-monthly-volume", 12],
    queryFn: () => getTransactionMonthlyVolume(12),
    retry: false,
  });
  const riskQuery = useQuery({
    queryKey: ["admin-risk-summary"],
    queryFn: () => getRiskSummary(),
    retry: false,
  });
  const loanCounts = useQueries({
    queries: (["pending", "approved", "declined"] as const).map((s) => ({
      queryKey: ["admin-loans-count", s, ""],
      queryFn: () => getLoans({ status: s, page: 1, limit: 1 }),
      retry: false,
    })),
  });

  const stats = (statsQuery.data as { data?: TxnStats })?.data;
  const volume: MonthlyVolumeRow[] = (volumeQuery.data as { data?: MonthlyVolumeRow[] })?.data ?? [];
  const risk = (riskQuery.data as { data?: RiskSummary })?.data;

  const typeRows = useMemo(() => {
    const total = stats?.totalAmount ?? 0;
    return TYPE_ROWS.map(({ type, statsKey }) => {
      const b = (stats?.[statsKey] as Bucket | undefined) ?? {};
      return {
        type,
        label: TYPE_LABELS[type],
        value: b.amount ?? 0,
        count: b.count ?? 0,
        share: total > 0 ? Math.round(((b.amount ?? 0) / total) * 100) : 0,
        fill: TYPE_COLORS[type],
      };
    });
  }, [stats]);

  const loanRows = [
    { key: "pending", label: "Awaiting decision", value: loanCounts[0].data?.meta?.total ?? 0, fill: STATUS_COLORS.warning },
    { key: "approved", label: "Approved", value: loanCounts[1].data?.meta?.total ?? 0, fill: STATUS_COLORS.good },
    { key: "declined", label: "Declined", value: loanCounts[2].data?.meta?.total ?? 0, fill: STATUS_COLORS.critical },
  ];

  const collectionRows = risk
    ? [
        { key: "debited", label: "Collected", value: risk.debited?.amount ?? 0, count: risk.debited?.count ?? 0, fill: STATUS_COLORS.good },
        { key: "scheduled", label: "Scheduled", value: risk.scheduled?.amount ?? 0, count: risk.scheduled?.count ?? 0, fill: STATUS_COLORS.neutral },
        { key: "processing", label: "Processing", value: risk.processing?.amount ?? 0, count: risk.processing?.count ?? 0, fill: STATUS_COLORS.info },
        { key: "overdue", label: "Overdue", value: risk.overdue?.amount ?? 0, count: risk.overdue?.count ?? 0, fill: STATUS_COLORS.warning },
        { key: "failed", label: "Failed", value: risk.defaulted?.amount ?? 0, count: risk.defaulted?.count ?? 0, fill: STATUS_COLORS.critical },
      ]
    : [];

  const disbursed = stats?.disbursement?.amount ?? 0;
  const repaid = stats?.repayment?.amount ?? 0;

  const exportSummary = () =>
    downloadCsv(`report-summary-${from || "all"}-${to || "now"}`, [
      ...typeRows.map((r) => ({ section: `By type (${periodLabel})`, item: r.label, count: r.count, amount: r.value })),
      ...volume.map((v) => ({ section: "Monthly volume (12 months)", item: v.month, count: v.count, amount: v.amount })),
      ...loanRows.map((l) => ({ section: "Credit requests (all time)", item: l.label, count: l.value, amount: "" })),
      ...collectionRows.map((c) => ({ section: "Collections (current)", item: c.label, count: c.count, amount: c.value })),
    ], [
      { header: "Section", value: (r) => r.section },
      { header: "Item", value: (r) => r.item },
      { header: "Count", value: (r) => r.count },
      { header: "Amount (NGN)", value: (r) => r.amount },
    ]);

  const anyError = statsQuery.isError || volumeQuery.isError || riskQuery.isError;

  return (
    <div className="w-full space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <Text title="Reports & Analytics" type="h4" className="text-lg text-black" />
          <p className="text-sm text-black/60 mt-1">Click any bar to open the records behind it.</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" className="rounded-sm px-4 bg-white text-black" onClick={exportSummary} disabled={!stats}>
            <PiExport className="mr-2" /> Summary CSV
          </Button>
          <ExportButton
            label="Ledger CSV"
            filename={`ledger-${from || "all"}-${to || "now"}`}
            disabled={(stats?.totalCount ?? 0) === 0}
            fetchPage={async (page, limit) => {
              const res = await getTransactions({ ...range, page, limit });
              return { rows: res?.data?.data ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
            }}
            columns={[
              { header: "Reference", value: (t: AdminTransaction) => t.reference },
              { header: "Type", value: (t: AdminTransaction) => TYPE_LABELS[t.type] ?? t.type },
              { header: "Amount", value: (t: AdminTransaction) => t.amount },
              { header: "Corps Member", value: (t: AdminTransaction) => t.corper?.fullName ?? t.user?.fullName },
              { header: "Vendor", value: (t: AdminTransaction) => t.vendor?.businessName },
              { header: "Date", value: (t: AdminTransaction) => t.createdAt },
            ]}
          />
        </div>
      </div>

      {/* Filters: one row above the charts */}
      <div className="flex flex-wrap items-center gap-3 bg-white border-[0.5px] border-primary/10 rounded-sm p-3">
        <div role="group" aria-label="Period" className="flex flex-wrap rounded-md border border-primary/15 p-0.5 text-xs">
          {PERIODS.map((p) => (
            <button
              key={p.key}
              type="button"
              aria-pressed={!isCustom && period === p.key}
              onClick={() => setPeriod(p.key)}
              className={cn(
                "px-3 py-1 rounded-[5px] transition-colors",
                !isCustom && period === p.key ? "bg-primary text-white" : "text-black/60 hover:text-black",
              )}
            >
              {p.label}
            </button>
          ))}
        </div>
        <span className="text-xs text-black/40">or</span>
        <DateRangeFilter
          from={customFrom}
          to={customTo}
          setFrom={(v) => setCustom(v, customTo)}
          setTo={(v) => setCustom(customFrom, v)}
          clear={() => setCustom("", "")}
          isActive={isCustom}
        />
      </div>

      {anyError && (
        <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
          Some report data could not be loaded. Check your connection and try again.
        </div>
      )}

      <section aria-label={`Figures for ${periodLabel}`} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Money moved", value: formatCurrency(stats?.totalAmount ?? 0), hint: `${(stats?.totalCount ?? 0).toLocaleString()} transactions` },
          { label: "Disbursed (credit)", value: formatCurrency(disbursed), hint: `${(stats?.disbursement?.count ?? 0).toLocaleString()} approvals` },
          { label: "Repaid", value: formatCurrency(repaid), hint: `${(stats?.repayment?.count ?? 0).toLocaleString()} debits collected` },
          {
            label: "Repaid vs disbursed",
            value: disbursed > 0 ? `${Math.round((repaid / disbursed) * 100)}%` : "—",
            hint: "Repayments as a share of credit issued in the period",
          },
        ].map((k) =>
          statsQuery.isLoading ? (
            <Skeleton key={k.label} className="h-[104px] rounded-sm" />
          ) : (
            <div key={k.label} className="bg-white border-[0.5px] border-primary/8 rounded-sm p-4 space-y-1">
              <p className="text-sm text-black/60">{k.label}</p>
              <p className="text-2xl font-semibold text-black">{k.value}</p>
              <p className="text-xs text-black/40">{k.hint} · {periodLabel}</p>
            </div>
          ),
        )}
      </section>

      <ChartCard title="Monthly volume" subtitle="Last 12 months · click a month to see its transactions" loading={volumeQuery.isLoading}>
        {volume.some((v) => v.amount > 0) ? (
          <ChartContainer config={volumeConfig} className="h-[260px] w-full">
            <BarChart data={volume} margin={{ left: 4, right: 4, top: 8 }}>
              <CartesianGrid vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
              <YAxis tickLine={false} axisLine={false} width={56} tickFormatter={(v: number) => formatCompactNaira(v)} />
              <ChartTooltip
                cursor={{ fill: "rgba(0,135,81,0.06)" }}
                content={<ChartTooltipContent formatter={(v) => formatCurrency(Number(v))} />}
              />
              <Bar
                dataKey="amount"
                fill={SERIES_COLOR}
                radius={[4, 4, 0, 0]}
                maxBarSize={40}
                cursor="pointer"
                onClick={(_, i) => {
                  const b = monthBounds(i, volume.length);
                  navigate(`/transactions?from=${b.from}&to=${b.to}`);
                }}
              />
            </BarChart>
          </ChartContainer>
        ) : (
          <EmptyState title="No volume yet" description="Transactions appear here once money starts moving." />
        )}
      </ChartCard>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="Money moved by type" subtitle={periodLabel} loading={statsQuery.isLoading}>
          {typeRows.some((r) => r.value > 0) ? (
            <div className="space-y-4">
              <HBar
                rows={typeRows}
                format={formatCompactNaira}
                onSelect={(r) => navigate(`/transactions?type=${r.type}${rangeQuery}`)}
              />
              {/* Table view — the exact figures behind the bars */}
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-xs text-black/50 border-b border-primary/10">
                    <th className="py-2 font-medium">Type</th>
                    <th className="py-2 font-medium text-right">Count</th>
                    <th className="py-2 font-medium text-right">Amount</th>
                    <th className="py-2 font-medium text-right">Share</th>
                  </tr>
                </thead>
                <tbody>
                  {typeRows.map((r) => (
                    <tr key={r.type} className="border-b border-primary/5 last:border-none">
                      <td className="py-2">
                        <Link to={`/transactions?type=${r.type}${rangeQuery}`} className="inline-flex items-center gap-2 hover:underline">
                          <span className="size-2.5 rounded-full" style={{ background: r.fill }} />
                          {r.label}
                        </Link>
                      </td>
                      <td className="py-2 text-right">{r.count.toLocaleString()}</td>
                      <td className="py-2 text-right font-medium">{formatCurrency(r.value)}</td>
                      <td className="py-2 text-right text-black/60">{r.share}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState title="Nothing in this period" description="Try a longer period." />
          )}
        </ChartCard>

        <div className="space-y-6">
          <ChartCard title="Credit requests" subtitle="All time · click to open the queue" loading={loanCounts.some((q) => q.isLoading)}>
            <HBar
              rows={loanRows}
              format={(v) => v.toLocaleString()}
              onSelect={(r) => navigate(`/loans?status=${r.key}`)}
            />
          </ChartCard>

          <ChartCard title="Collections" subtitle="Current position · click to open in Risk" loading={riskQuery.isLoading}>
            {collectionRows.some((r) => r.value > 0) ? (
              <HBar
                rows={collectionRows}
                format={formatCompactNaira}
                detail={(r) => `${(r as { count?: number }).count ?? 0} debits`}
                onSelect={(r) => navigate(r.key === "debited" ? "/risk?riskStatus=debited" : `/risk?riskStatus=${r.key}`)}
              />
            ) : (
              <EmptyState title="No collections yet" description="Monthly debits appear once purchases are paid out." />
            )}
          </ChartCard>
        </div>
      </div>
    </div>
  );
};

type HBarRow = { key?: string; type?: string; label: string; value: number; fill: string };

/**
 * Horizontal bars for comparing a few labelled magnitudes. Each bar is
 * clickable (drill-down), directly labelled with its value, and coloured by
 * its entity — so colour is never the only way to tell them apart.
 */
function HBar<T extends HBarRow>({
  rows,
  format,
  onSelect,
  detail,
}: {
  rows: T[];
  format: (v: number) => string;
  onSelect: (row: T) => void;
  detail?: (row: T) => string;
}) {
  return (
    <ChartContainer config={genericConfig} className="w-full" style={{ height: rows.length * 40 + 8 }}>
      <BarChart data={rows} layout="vertical" margin={{ left: 0, right: 64, top: 4, bottom: 4 }} barCategoryGap={8}>
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="label" tickLine={false} axisLine={false} width={128} tick={{ fill: "#52514e", fontSize: 12 }} />
        <ChartTooltip
          cursor={{ fill: "rgba(0,0,0,0.03)" }}
          content={
            <ChartTooltipContent
              hideLabel
              formatter={(value, _name, item) => (
                <span className="flex w-full justify-between gap-4">
                  <span>{(item.payload as T).label}</span>
                  <span className="font-semibold">
                    {format(Number(value))}
                    {detail ? ` · ${detail(item.payload as T)}` : ""}
                  </span>
                </span>
              )}
            />
          }
        />
        <Bar dataKey="value" radius={[0, 4, 4, 0]} maxBarSize={24} cursor="pointer" onClick={(d) => onSelect(d.payload as T)}>
          {rows.map((r) => (
            <Cell key={r.key ?? r.type ?? r.label} fill={r.fill} />
          ))}
          <LabelList dataKey="value" position="right" formatter={(v: number) => format(v)} className="fill-black text-xs" />
        </Bar>
      </BarChart>
    </ChartContainer>
  );
}

const ChartCard = ({
  title,
  subtitle,
  loading,
  children,
}: {
  title: string;
  subtitle?: string;
  loading: boolean;
  children: React.ReactNode;
}) => (
  <Card className="border-[0.5px] border-primary/8 bg-white p-4 rounded-sm text-black gap-4 shadow-none">
    <CardHeader className="p-0 space-y-0.5">
      <CardTitle className="text-base font-medium">{title}</CardTitle>
      {subtitle && <p className="text-xs text-black/50">{subtitle}</p>}
    </CardHeader>
    <CardContent className="p-0">{loading ? <Skeleton className="h-[200px] w-full" /> : children}</CardContent>
  </Card>
);

export default ReportsPage;
