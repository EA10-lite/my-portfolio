import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { Alert, AlertDescription } from "../../../components/ui/alert";
import { AlertCircle, AlertTriangle } from "lucide-react";
import { approveLoan, declineLoan, getLoans, type LoanRow } from "../../../services/loans.service";
import { findCorperByEmail } from "../../../services/corpers.service";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { invalidateGroup } from "../../../lib/invalidate";

const DECLINE_REASONS = [
  "Amount exceeds your available credit limit",
  "You have an outstanding balance to clear first",
  "Your KYC details need to be updated",
  "Unable to verify your repayment account",
];

/**
 * Approving a loan credits the corper's availableCredit inside a Mongo
 * transaction on the backend, so it is not reversible from the dashboard —
 * hence the explicit confirmation rather than a one-click action.
 *
 * `initialMode="declining"` opens straight on the decline form (used by the
 * row menu's "Decline" item).
 */
const LoanDecisionModal = ({
  loan,
  triggerButton,
  open: openProp,
  onOpenChange,
  initialMode = "idle",
}: {
  loan: LoanRow;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  initialMode?: "idle" | "declining";
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [reason, setReason] = useState("");
  const [mode, setMode] = useState<"idle" | "declining">(initialMode);
  const qc = useQueryClient();

  const isPending = loan.status === "pending";
  const email = loan.user?.email;
  const userId = loan.user?._id;

  // Credit context for the decision: the member's ceiling, what they can
  // spend now, and any other requests still waiting.
  const corperQuery = useQuery({
    queryKey: ["corper-by-email", email],
    queryFn: () => findCorperByEmail(String(email)),
    enabled: open && isPending && Boolean(email),
    retry: false,
  });
  const otherPendingQuery = useQuery({
    queryKey: ["admin-loans", "pending-for-user", userId],
    queryFn: () => getLoans({ userId, status: "pending", page: 1, limit: 1 }),
    enabled: open && isPending && Boolean(userId),
    retry: false,
  });
  const corper = corperQuery.data;
  const otherPending = Math.max(0, (otherPendingQuery.data?.meta?.total ?? 1) - 1);
  const overLimit = corper?.maxLoanAmount !== undefined && loan.amount > corper.maxLoanAmount;

  const reset = () => {
    setReason("");
    setMode(initialMode);
  };

  const close = () => {
    setOpen(false);
    reset();
  };

  const approveMut = useMutation({
    mutationFn: () => approveLoan(loan._id),
    onSuccess: () => {
      toast.success(`${formatCurrency(loan.amount)} approved for ${loan.user?.fullName ?? "corper"}`);
      invalidateGroup(qc, "loans");
      invalidateGroup(qc, "corpers");
      close();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not approve this loan request.")),
  });

  const declineMut = useMutation({
    mutationFn: () => declineLoan(loan._id, reason.trim()),
    onSuccess: () => {
      toast.success("Loan request declined");
      invalidateGroup(qc, "loans");
      close();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not decline this loan request.")),
  });

  const busy = approveMut.isPending || declineMut.isPending;

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {!isPending
              ? "Credit request"
              : mode === "declining"
                ? "Decline credit request"
                : "Review credit request"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-md border border-primary/10 bg-secondary-foreground p-4 space-y-2 text-sm">
            <Row label="Corps member" value={loan.user?.fullName ?? "—"} />
            <Row label="Email" value={loan.user?.email ?? "—"} />
            <Row label="Amount requested" value={formatCurrency(loan.amount ?? 0)} />
            <Row label="Requested" value={loan.createdAt ? formatDateString(loan.createdAt) : "—"} />
            <Row label="Status" value={loan.status} capitalize />
            {loan.approvedAt && <Row label="Approved" value={formatDateString(loan.approvedAt)} />}
            {loan.declinedAt && <Row label="Declined" value={formatDateString(loan.declinedAt)} />}
            {loan.declineReason && <Row label="Decline reason" value={loan.declineReason} />}
          </div>

          {isPending && (
            <div className="rounded-md border border-primary/10 p-4 space-y-2 text-sm">
              <p className="text-xs font-medium text-black/60">Member's credit</p>
              {corperQuery.isLoading ? (
                <p className="text-xs text-black/40">Loading…</p>
              ) : corper ? (
                <>
                  <Row label="Credit limit" value={formatCurrency(corper.maxLoanAmount ?? 0)} />
                  <Row label="Available to spend" value={formatCurrency(corper.availableCredit ?? 0)} />
                  <Row
                    label="Other pending requests"
                    value={otherPendingQuery.isLoading ? "…" : String(otherPending)}
                  />
                </>
              ) : (
                <p className="text-xs text-black/40">Could not load this member's credit profile.</p>
              )}
            </div>
          )}

          {isPending && overLimit && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                This request is above the member's {formatCurrency(corper?.maxLoanAmount ?? 0)} limit.
                The server will refuse to approve it — decline it, or raise their limit first.
              </AlertDescription>
            </Alert>
          )}

          {!isPending && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This request has already been {loan.status}. No further action is possible.
              </AlertDescription>
            </Alert>
          )}

          {isPending && mode === "declining" && (
            <div className="space-y-2">
              <label htmlFor="decline-reason" className="text-sm font-medium text-black">
                Reason for declining <span className="text-primary">*</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {DECLINE_REASONS.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setReason(r)}
                    className={`text-xs px-2 py-1 rounded border text-left ${
                      reason === r
                        ? "bg-primary/10 border-primary/40 text-primary"
                        : "bg-white border-primary/15 text-black/70 hover:bg-primary/5"
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
              <Textarea
                id="decline-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Pick a reason above or write your own. The corps member sees this."
                rows={3}
              />
            </div>
          )}

          {isPending && mode === "idle" && (
            <p className="text-sm text-black/60">
              Approving adds {formatCurrency(loan.amount ?? 0)} to this corps member's available
              credit immediately and records a disbursement. This cannot be undone from the
              dashboard.
            </p>
          )}
        </div>

        <DialogFooter className="gap-2">
          {!isPending ? (
            <Button variant="outline" onClick={close}>
              Close
            </Button>
          ) : mode === "declining" ? (
            <>
              <Button
                variant="outline"
                onClick={() => (initialMode === "declining" ? close() : setMode("idle"))}
                disabled={busy}
              >
                {initialMode === "declining" ? "Cancel" : "Back"}
              </Button>
              <Button
                variant="destructive"
                onClick={() => declineMut.mutate()}
                disabled={busy || reason.trim().length === 0}
              >
                {declineMut.isPending ? "Declining…" : "Confirm decline"}
              </Button>
            </>
          ) : (
            <>
              <Button variant="destructive" onClick={() => setMode("declining")} disabled={busy}>
                Decline
              </Button>
              <Button onClick={() => approveMut.mutate()} disabled={busy || overLimit}>
                {approveMut.isPending ? "Approving…" : `Approve ${formatCurrency(loan.amount ?? 0)}`}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const Row = ({ label, value, capitalize }: { label: string; value: string; capitalize?: boolean }) => (
  <div className="flex items-start justify-between gap-4">
    <span className="text-black/50">{label}</span>
    <span className={`text-black font-medium text-right ${capitalize ? "capitalize" : ""}`}>{value}</span>
  </div>
);

export default LoanDecisionModal;
