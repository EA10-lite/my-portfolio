import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useQueries, useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import {
  Banknote,
  Bell,
  CheckCircle2,
  Clock4,
  Eye,
  User,
  X,
  XCircle,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { formatCurrency, formatDateString } from "../../utils/formatter";
import type { CsvColumn } from "../../utils/csv";
import { getLoans, type LoanRow } from "../../services/loans.service";
import { useOpenCorperProfile } from "../../hooks/useOpenCorperProfile";
import LoanDecisionModal from "./_components/LoanDecisionModal";
import SendNotificationModal from "../notifications/_components/SendNotificationModal";

const kpiStyles = {
  total: "bg-sky-50 border-sky-100 text-sky-600",
  pending: "bg-amber-50 border-amber-100 text-amber-600",
  approved: "bg-emerald-50 border-emerald-100 text-emerald-600",
  declined: "bg-red-50 border-red-100 text-red-600",
};

const STATUS_FILTER_OPTIONS = [
  { label: "pending", value: "pending" },
  { label: "approved", value: "approved" },
  { label: "declined", value: "declined" },
];

/**
 * Credit requests from corps members. Without this screen a loan request stays
 * `pending` forever — the backend exposes POST /loans/admin/approve and
 * /decline but nothing in the dashboard was calling them.
 *
 * `?userId=…&name=…` scopes the page to one member (linked from their row on
 * Corp Members and from their profile). `?status=pending` pre-filters.
 */
const LoansPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const userId = searchParams.get("userId") ?? "";
  const memberName = searchParams.get("name") ?? "";
  const status = searchParams.get("status") ?? "";

  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });
  const openProfile = useOpenCorperProfile();

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  const clearMember = () => {
    const next = new URLSearchParams(searchParams);
    next.delete("userId");
    next.delete("name");
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  // Status goes to the API — the old dropdown only filtered the 20 rows
  // already on screen, so pending requests on later pages were invisible.
  const query = useQuery({
    queryKey: ["admin-loans", pagination.pageIndex, pagination.pageSize, status, userId],
    queryFn: () =>
      getLoans({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        status,
        userId,
      }),
    retry: false,
  });

  const rows: LoanRow[] = query.data?.loans ?? [];
  const total = query.data?.meta?.total ?? 0;
  const totalPages = query.data?.meta?.totalPages ?? 1;

  // Per-status totals across every page (scoped to the member when one is
  // selected). Each is a limit:1 request that only reads back meta.total.
  const countQueries = useQueries({
    queries: (["", "pending", "approved", "declined"] as const).map((s) => ({
      queryKey: ["admin-loans-count", s || "all", userId],
      queryFn: () => getLoans({ status: s, userId, page: 1, limit: 1 }),
      retry: false,
    })),
  });
  const countFor = (i: number) => countQueries[i].data?.meta?.total ?? 0;

  const exportColumns: CsvColumn<LoanRow>[] = [
      { header: "Corps Member", value: (r) => r.user?.fullName },
      { header: "Email", value: (r) => r.user?.email },
      { header: "Amount", value: (r) => r.amount },
      { header: "Status", value: (r) => r.status },
      { header: "Requested", value: (r) => r.createdAt },
      { header: "Decided", value: (r) => r.approvedAt ?? r.declinedAt },
      { header: "Decline Reason", value: (r) => r.declineReason },
  ];

  const columns: ColumnDef<LoanRow>[] = useMemo(
    () => [
      {
        id: "corper",
        header: "Corps Member",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black font-medium">{row.original.user?.fullName ?? "—"}</span>
            <span className="text-xs text-black/50">{row.original.user?.email ?? ""}</span>
          </div>
        ),
      },
      {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ row }) => (
          <span className="text-black font-medium">{formatCurrency(row.original.amount ?? 0)}</span>
        ),
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
          const s = row.original.status;
          const variant = s === "approved" ? "default" : s === "declined" ? "destructive" : "pending";
          return (
            <Badge className="font-normal capitalize" variant={variant}>
              {s}
            </Badge>
          );
        },
      },
      {
        accessorKey: "createdAt",
        header: "Requested",
        cell: ({ row }) => (
          <span className="text-black text-sm">
            {row.original.createdAt ? formatDateString(row.original.createdAt) : "—"}
          </span>
        ),
      },
      {
        id: "decided",
        header: "Decided",
        cell: ({ row }) => {
          const l = row.original;
          const when = l.approvedAt ?? l.declinedAt;
          return (
            <div className="flex flex-col">
              <span className="text-black text-sm">{when ? formatDateString(when) : "—"}</span>
              {l.declineReason && (
                <span className="text-xs text-black/50 line-clamp-1 max-w-56" title={l.declineReason}>
                  {l.declineReason}
                </span>
              )}
            </div>
          );
        },
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const loan = row.original;
          const pending = loan.status === "pending";
          return (
            <RowActions
              actions={[
                {
                  key: "approve",
                  label: "Review & approve",
                  icon: <CheckCircle2 className="size-4" />,
                  hidden: !pending,
                  dialog: (p) => <LoanDecisionModal loan={loan} {...p} />,
                },
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  hidden: pending,
                  dialog: (p) => <LoanDecisionModal loan={loan} {...p} />,
                },
                {
                  key: "member",
                  label: "View member",
                  icon: <User className="size-4" />,
                  hidden: !loan.user?.email,
                  onSelect: () => openProfile(loan.user?.email),
                },
                {
                  key: "notify",
                  label: "Send notification",
                  icon: <Bell className="size-4" />,
                  hidden: !loan.user?._id,
                  dialog: (p) => (
                    <SendNotificationModal
                      recipient={{
                        userId: String(loan.user?._id),
                        label: `${loan.user?.fullName ?? "Corps member"} — ${loan.user?.email ?? ""}`,
                      }}
                      {...p}
                    />
                  ),
                },
                {
                  key: "decline",
                  label: "Decline",
                  icon: <XCircle className="size-4" />,
                  destructive: true,
                  hidden: !pending,
                  dialog: (p) => <LoanDecisionModal loan={loan} initialMode="declining" {...p} />,
                },
              ]}
            />
          );
        },
      },
    ],
    [openProfile],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between">
          <Text title="Credit Requests" type="h4" className="text-lg text-black" />
          <ExportButton
            filename="loan-requests"
            columns={exportColumns}
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getLoans({ page, limit, status, userId });
              return { rows: res.loans, totalPages: res.meta?.totalPages, total: res.meta?.total };
            }}
          />
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {userId && (
          <div className="flex items-center justify-between gap-3 bg-primary/5 border border-primary/15 text-sm text-black rounded-sm px-4 py-3">
            <span>
              Showing requests for <strong>{memberName || "one corps member"}</strong>
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => openProfile(rows[0]?.user?.email)}
                disabled={!rows[0]?.user?.email}
                className="text-primary font-medium hover:underline disabled:opacity-40"
              >
                View profile
              </button>
              <button
                type="button"
                onClick={clearMember}
                className="inline-flex items-center gap-1 text-black/60 hover:text-black"
              >
                <X className="size-4" /> Show everyone
              </button>
            </div>
          </div>
        )}

        {query.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load credit requests from the server. Check your connection
            and try again.
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total Requests"
            value={countFor(0).toLocaleString()}
            icon={<Banknote className="size-4" />}
            className={kpiStyles.total}
            active={!status}
            onClick={() => setParam("status", "")}
          />
          <PageMetric
            label="Awaiting Decision"
            value={countFor(1).toLocaleString()}
            icon={<Clock4 className="size-4" />}
            className={kpiStyles.pending}
            active={status === "pending"}
            onClick={() => setParam("status", "pending")}
          />
          <PageMetric
            label="Approved"
            value={countFor(2).toLocaleString()}
            icon={<CheckCircle2 className="size-4" />}
            className={kpiStyles.approved}
            active={status === "approved"}
            onClick={() => setParam("status", "approved")}
          />
          <PageMetric
            label="Declined"
            value={countFor(3).toLocaleString()}
            icon={<XCircle className="size-4" />}
            className={kpiStyles.declined}
            active={status === "declined"}
            onClick={() => setParam("status", "declined")}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          filters={[{ columnKey: "status", title: "Status", options: STATUS_FILTER_OPTIONS }]}
          filterValues={{ status }}
          onFilterChange={setParam}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={query.isLoading}
          rowCount={total}
          emptyMessage={
            status === "pending" ? "No credit requests waiting for a decision." : "No credit requests found."
          }
        />
        <p className="text-xs text-black/40">
          The API has no search on credit requests. To find one person's requests, open them from{" "}
          <Link to="/corpers" className="text-primary hover:underline">
            Corp Members
          </Link>
          .
        </p>
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
  active,
  onClick,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
  active?: boolean;
  onClick?: () => void;
}) => (
  <button
    type="button"
    onClick={onClick}
    aria-pressed={active}
    className={cn(
      "flex flex-col gap-2 rounded-sm border-[0.5px] p-4 text-left transition-shadow",
      className,
      active && "ring-2 ring-primary/40",
    )}
  >
    <div className="flex items-center gap-2 text-sm">
      {icon}
      <span>{label}</span>
    </div>
    <span className="text-2xl font-semibold text-black">{value}</span>
  </button>
);

export default LoansPage;
