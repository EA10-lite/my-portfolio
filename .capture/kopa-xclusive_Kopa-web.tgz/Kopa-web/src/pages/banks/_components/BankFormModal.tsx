import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import {
  createBank,
  updateBank,
  type Bank,
  type BankPayload,
} from "../../../services/banks.service";
import { useControllableOpen } from "../../../hooks/useControllableOpen";

const EMPTY: BankPayload = {
  name: "",
  code: "",
  longcode: "",
  country: "Nigeria",
  currency: "NGN",
  type: "nuban",
  payWithBank: true,
  supportsTransfer: true,
  availableForDirectDebit: true,
};

/**
 * Create/edit a bank. CreateBankDto requires every field; UpdateBankDto is a
 * PartialType of it, so editing can send only what changed — but sending the
 * whole object is simpler and equally valid.
 */
const BankFormModal = ({
  bank,
  triggerButton,
  open: openProp,
  onOpenChange,
}: {
  bank?: Bank;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const isEdit = Boolean(bank);
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [form, setForm] = useState<BankPayload>(EMPTY);
  const qc = useQueryClient();

  // Seeded when the dialog opens rather than in an effect — opening is an
  // event, so there is no cascading render to worry about.
  const seed = (): BankPayload =>
    bank
      ? {
          name: bank.name,
          code: bank.code,
          longcode: bank.longcode ?? "",
          country: bank.country,
          currency: bank.currency,
          type: bank.type,
          payWithBank: bank.payWithBank,
          supportsTransfer: bank.supportsTransfer,
          availableForDirectDebit: bank.availableForDirectDebit,
        }
      : EMPTY;

  const set = <K extends keyof BankPayload>(key: K, value: BankPayload[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const mut = useMutation({
    mutationFn: () =>
      isEdit ? updateBank(bank!._id, form) : createBank(form),
    onSuccess: () => {
      toast.success(isEdit ? `${form.name} updated` : `${form.name} added`);
      qc.invalidateQueries({ queryKey: ["banks"] });
      setOpen(false);
    },
    onError: (e: unknown) => {
      const err = e as { response?: { data?: { message?: string } } };
      toast.error(err.response?.data?.message ?? "Could not save this bank.");
    },
  });

  // Every field on CreateBankDto is @IsNotEmpty, so block submit until the
  // text fields are filled rather than letting the server 400.
  const valid =
    form.name.trim() &&
    form.code.trim() &&
    form.longcode.trim() &&
    form.country.trim() &&
    form.currency.trim() &&
    form.type.trim();

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (v) setForm(seed());
        setOpen(v);
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit bank" : "Add bank"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
          <Text label="Bank name" value={form.name} onChange={(v) => set("name", v)} placeholder="Access Bank" />
          <Text label="Code" value={form.code} onChange={(v) => set("code", v)} placeholder="044" />
          <Text label="Long code" value={form.longcode} onChange={(v) => set("longcode", v)} placeholder="000001" />
          <Text label="Country" value={form.country} onChange={(v) => set("country", v)} />
          <Text label="Currency" value={form.currency} onChange={(v) => set("currency", v)} />
          <Text label="Type" value={form.type} onChange={(v) => set("type", v)} placeholder="nuban" />

          <div className="space-y-2 pt-2">
            <Check
              label="Available for direct debit"
              hint="Corps members can only link a repayment mandate to banks with this enabled."
              checked={form.availableForDirectDebit}
              onChange={(v) => set("availableForDirectDebit", v)}
            />
            <Check
              label="Supports transfer"
              hint="Required for vendor payouts to this bank."
              checked={form.supportsTransfer}
              onChange={(v) => set("supportsTransfer", v)}
            />
            <Check
              label="Pay with bank"
              checked={form.payWithBank}
              onChange={(v) => set("payWithBank", v)}
            />
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={mut.isPending}>
            Cancel
          </Button>
          <Button onClick={() => mut.mutate()} disabled={!valid || mut.isPending}>
            {mut.isPending ? "Saving…" : isEdit ? "Save changes" : "Add bank"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const Text = ({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) => (
  <div className="space-y-1.5">
    <Label>{label}</Label>
    <Input value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
  </div>
);

const Check = ({
  label,
  hint,
  checked,
  onChange,
}: {
  label: string;
  hint?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) => (
  <label className="flex items-start gap-3 cursor-pointer">
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
      className="mt-1 size-4 accent-primary"
    />
    <span>
      <span className="text-sm text-black">{label}</span>
      {hint && <span className="block text-xs text-black/50">{hint}</span>}
    </span>
  </label>
);

export default BankFormModal;
