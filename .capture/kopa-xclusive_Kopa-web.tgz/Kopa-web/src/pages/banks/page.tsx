import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { toast } from "sonner";
import { ConfirmDialog, ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { PiExport } from "react-icons/pi";
import {
  Landmark,
  Pencil,
  Plus,
  Repeat,
  ShieldCheck,
  Trash2,
  TriangleAlert,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { downloadCsv } from "../../utils/csv";
import { getBanks, deleteBank, type Bank } from "../../services/banks.service";
import { useAdminStore, isSuperAdmin } from "../../stores/adminStore";
import BankFormModal from "./_components/BankFormModal";
import { getApiErrorMessage } from "../../utils/apiError";

const kpiStyles = {
  total: "bg-sky-50 border-sky-100 text-sky-600",
  debit: "bg-emerald-50 border-emerald-100 text-emerald-600",
  transfer: "bg-indigo-50 border-indigo-100 text-indigo-600",
};

/**
 * The bank list drives the mobile KYC bank picker and direct-debit mandate
 * setup. If it is empty, corper and vendor onboarding cannot be completed at
 * all — which is why an empty list is called out loudly rather than shown as a
 * neutral "no data" state.
 */
const BanksPage = () => {
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });

  const admin = useAdminStore((s) => s.admin);
  const canManage = isSuperAdmin(admin?.role);
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["banks"],
    queryFn: getBanks,
    retry: false,
  });

  const rows: Bank[] = useMemo(() => query.data ?? [], [query.data]);

  const counts = useMemo(
    () => ({
      total: rows.length,
      debit: rows.filter((b) => b.availableForDirectDebit).length,
      transfer: rows.filter((b) => b.supportsTransfer).length,
    }),
    [rows],
  );

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteBank(id),
    onSuccess: () => {
      toast.success("Bank removed");
      qc.invalidateQueries({ queryKey: ["banks"] });
    },
        onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Could not remove this bank.")),
  });

  const handleExport = () =>
    downloadCsv("banks", rows, [
      { header: "Name", value: (b) => b.name },
      { header: "Code", value: (b) => b.code },
      { header: "Long Code", value: (b) => b.longcode },
      { header: "Country", value: (b) => b.country },
      { header: "Currency", value: (b) => b.currency },
      { header: "Type", value: (b) => b.type },
      { header: "Direct Debit", value: (b) => b.availableForDirectDebit },
      { header: "Supports Transfer", value: (b) => b.supportsTransfer },
    ]);

  const columns: ColumnDef<Bank>[] = [
    {
      accessorKey: "name",
      header: "Bank",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-gray-100 flex items-center justify-center">
            <Landmark className="size-4 text-gray-400" />
          </div>
          <span className="text-black font-medium">{row.getValue("name")}</span>
        </div>
      ),
    },
    {
      accessorKey: "code",
      header: "Code",
      cell: ({ row }) => <span className="text-black">{row.getValue("code")}</span>,
    },
    {
      accessorKey: "type",
      header: "Type",
      cell: ({ row }) => (
        <span className="text-black capitalize">{row.getValue("type")}</span>
      ),
    },
    {
      id: "capabilities",
      header: "Capabilities",
      cell: ({ row }) => {
        const b = row.original;
        return (
          <div className="flex flex-wrap gap-1">
            {b.availableForDirectDebit && (
              <Badge variant="default" className="font-normal">Direct debit</Badge>
            )}
            {b.supportsTransfer && (
              <Badge variant="pending" className="font-normal">Transfer</Badge>
            )}
            {!b.availableForDirectDebit && !b.supportsTransfer && (
              <span className="text-black/40 text-sm">—</span>
            )}
          </div>
        );
      },
    },
        // Editing and removing banks is super-admin only; other admins get a
    // read-only list instead of a column of "Super admin only" labels.
    ...(canManage
      ? [
          {
            id: "actions",
            header: "Action",
            cell: ({ row }) => {
              const bank = row.original;
              return (
                <RowActions
                  actions={[
                    {
                      key: "edit",
                      label: "Edit",
                      icon: <Pencil className="size-4" />,
                      dialog: (p) => <BankFormModal bank={bank} {...p} />,
                    },
                    {
                      key: "remove",
                      label: "Remove",
                      icon: <Trash2 className="size-4" />,
                      destructive: true,
                      dialog: (p) => (
                        <ConfirmDialog
                          {...p}
                          title={`Remove ${bank.name}?`}
                          description="Corps members and vendors who already linked this bank keep their records, but nobody can select it again during onboarding."
                          confirmLabel="Remove bank"
                          destructive
                          busy={deleteMut.isPending}
                          onConfirm={() =>
                            deleteMut.mutate(bank._id, { onSuccess: () => p.onOpenChange(false) })
                          }
                        />
                      ),
                    },
                  ]}
                />
              );
            },
          } satisfies ColumnDef<Bank>,
        ]
      : []),
  ];

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between">
          <Text title="Banks" type="h4" className="text-lg text-black" />
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              className="rounded-sm px-4"
              onClick={handleExport}
              disabled={rows.length === 0}
            >
              <PiExport className="mr-2" /> Export
            </Button>
            {canManage && (
              <BankFormModal
                triggerButton={
                  <Button variant="default" className="rounded-sm px-4">
                    <Plus className="mr-2 size-4" /> Add bank
                  </Button>
                }
              />
            )}
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {query.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load banks from the server. Check your connection and try
            again.
          </div>
        )}

        {!query.isLoading && !query.isError && rows.length === 0 && (
          <div className="bg-amber-50 border border-amber-200 text-amber-800 text-sm rounded-sm p-4 space-y-1">
            <p className="font-medium flex items-center gap-2">
              <TriangleAlert className="size-4" /> No banks configured
            </p>
            <p>
              Corps members and vendors cannot complete KYC until at least one
              bank exists — the mobile bank picker reads this list. Add banks
              here, or run the backend seeder at{" "}
              <code className="px-1 bg-amber-100 rounded">seeder/banks</code>.
            </p>
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-3 gap-4">
          <PageMetric
            label="Total Banks"
            value={counts.total.toLocaleString()}
            icon={<Landmark className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="Direct Debit Enabled"
            value={counts.debit.toLocaleString()}
            icon={<ShieldCheck className="size-4" />}
            className={kpiStyles.debit}
          />
          <PageMetric
            label="Supports Transfer"
            value={counts.transfer.toLocaleString()}
            icon={<Repeat className="size-4" />}
            className={kpiStyles.transfer}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          searchKeys={["name", "code"]}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={query.isLoading}
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
}) => (
  <div className={cn("flex flex-col gap-2 rounded-sm border-[0.5px] p-4", className)}>
    <div className="flex items-center gap-2 text-sm">
      {icon}
      <span>{label}</span>
    </div>
    <span className="text-2xl font-semibold text-black">{value}</span>
  </div>
);

export default BanksPage;
