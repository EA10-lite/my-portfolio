import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQueries, useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import SendNotificationModal from "../notifications/_components/SendNotificationModal";
import VendorDetailsModal from "../vendors/_components/VendorDetailsModal";
import type { CsvColumn } from "../../utils/csv";
import { Badge } from "../../components/ui/badge";
import { cn } from "../../lib/utils";
import { formatDateString } from "../../utils/formatter";
import { getCorpers } from "../../services/corpers.service";
import { getVendorsService } from "../../services/vendors.service";
import {
  ShieldCheck,
  ShieldQuestion,
  ShieldX,
  Shield,
    Gavel,
  Bell,
  Eye,
} from "lucide-react";
import CorperReviewModal from "./_components/CorperReviewModal";
import VendorReviewModal from "./_components/VendorReviewModal";

export interface AdminUserRef {
  _id: string;
  fullName: string;
  email: string;
  phone?: string;
  status: string;
}

export interface AdminBankRef {
  _id: string;
  name: string;
  code: string;
}

export interface AdminCorper {
  _id: string;
  user: AdminUserRef;
  fullName: string;
  stateCode: string;
  ppaNumber: string;
  bank?: AdminBankRef;
  kycDocumentType: string;
  kycDocumentUrl: string;
  profileImage: string;
  kycStatus: "submitted" | "verified" | "rejected";
  kycStatusNote?: string;
  maxLoanAmount: number;
  availableCredit: number;
  submittedAt: string;
}

export interface AdminVendor {
  _id: string;
  owner: AdminUserRef;
  businessName: string;
  businessPhone: string;
  vendorCategory: string;
  address: string;
  bank?: AdminBankRef;
  kybDocumentType: string;
  kybDocumentUrl: string;
  profileImage: string;
  kybStatus: "submitted" | "verified" | "rejected";
  kybStatusNote?: string;
  kopaAccountNumber?: string;
  kopaBalance: number;
  /** Order money held until delivery is confirmed; not withdrawable. */
  escrowBalance?: number;
  submittedAt: string;
}

const kpiStyles = {
  pending: "bg-yellow-50 border-yellow-100 text-yellow-600",
  verified: "bg-green-50 border-green-100 text-green-600",
  rejected: "bg-red-50 border-red-100 text-red-600",
  total: "bg-blue-50 border-blue-100 text-blue-600",
};

const statusBadgeVariant = (status: string) => {
  if (status === "verified") return "default" as const;
  if (status === "rejected") return "destructive" as const;
  return "pending" as const;
};

const STATUS_FILTER_OPTIONS = [
  { label: "awaiting review", value: "submitted" },
  { label: "verified", value: "verified" },
  { label: "rejected", value: "rejected" },
];

const VerificationPage = () => {
  // `?entity=vendor` opens the vendor tab (linked from the dashboard).
  const [searchParams] = useSearchParams();
  const [entity, setEntity] = useState<"corper" | "vendor">(
    searchParams.get("entity") === "vendor" ? "vendor" : "corper",
  );
    const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });
  // This page is a review queue, so it opens on what still needs a decision.
  const [reviewStatus, setReviewStatus] = useState("submitted");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search.trim());
  const resetToFirstPage = () => setPagination((p) => ({ ...p, pageIndex: 0 }));

  const corpersQuery = useQuery({
    queryKey: ["admin-corpers", pagination.pageIndex, pagination.pageSize, reviewStatus, debouncedSearch],
    queryFn: () =>
      getCorpers({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        kycStatus: reviewStatus,
        search: debouncedSearch,
      }),
    enabled: entity === "corper",
    retry: false,
  });

  const vendorsQuery = useQuery({
    queryKey: ["admin-vendors", pagination.pageIndex, pagination.pageSize, reviewStatus, debouncedSearch],
    queryFn: () =>
      getVendorsService({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        kybStatus: reviewStatus,
        search: debouncedSearch,
      }),
    enabled: entity === "vendor",
    retry: false,
  });

  const corperCountQueries = useQueries({
    queries: (["submitted", "verified", "rejected"] as const).map((status) => ({
      queryKey: ["admin-corpers-count", status],
      // KYC state is `kycStatus`; `status` is the account status and
      // rejects "submitted"/"verified", which left these cards at 0.
      queryFn: () => getCorpers({ kycStatus: status, page: 1, limit: 1 }),
      retry: false,
    })),
  });
  const vendorCountQueries = useQueries({
    queries: (["submitted", "verified", "rejected"] as const).map((status) => ({
      queryKey: ["admin-vendors-count", status],
      queryFn: () => getVendorsService({ kybStatus: status, page: 1, limit: 1 }),
      retry: false,
    })),
  });

  const countFor = (queries: typeof corperCountQueries, index: number) =>
    (queries[index].data as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0;

  const isCorper = entity === "corper";
  const activeQuery = isCorper ? corpersQuery : vendorsQuery;
  const activeCounts = isCorper ? corperCountQueries : vendorCountQueries;

  const corperRaw = (corpersQuery.data as { data?: { corpers?: AdminCorper[]; meta?: { total?: number; totalPages?: number } } })?.data;
  const vendorRaw = (vendorsQuery.data as { data?: { vendors?: AdminVendor[]; meta?: { total?: number; totalPages?: number } } })?.data;

  const corperRows: AdminCorper[] = corperRaw?.corpers ?? [];
  const vendorRows: AdminVendor[] = vendorRaw?.vendors ?? [];

  // The tab decides which dataset is exported — the two have different shapes.
  const corperExportColumns: CsvColumn<AdminCorper>[] = [
          { header: "Full Name", value: (r) => r.fullName },
          { header: "Email", value: (r) => r.user?.email },
          { header: "Phone", value: (r) => r.user?.phone },
          { header: "State Code", value: (r) => r.stateCode },
          { header: "KYC Status", value: (r) => r.kycStatus },
          { header: "Submitted", value: (r) => r.submittedAt },
        ];
  const vendorExportColumns: CsvColumn<AdminVendor>[] = [
          { header: "Business Name", value: (r) => r.businessName },
          { header: "Owner Email", value: (r) => r.owner?.email },
          { header: "Phone", value: (r) => r.businessPhone },
          { header: "Category", value: (r) => r.vendorCategory },
          { header: "KYB Status", value: (r) => r.kybStatus },
          { header: "Submitted", value: (r) => r.submittedAt },
        ];

  const total = (isCorper ? corperRaw?.meta?.total : vendorRaw?.meta?.total) ?? 0;
  const totalPages = (isCorper ? corperRaw?.meta?.totalPages : vendorRaw?.meta?.totalPages) ?? 1;

  const counts = {
    submitted: countFor(activeCounts, 0),
    verified: countFor(activeCounts, 1),
    rejected: countFor(activeCounts, 2),
  };

  const corperColumns: ColumnDef<AdminCorper>[] = useMemo(
    () => [
      {
        id: "name",
        header: "Corps Member",
        cell: ({ row }) => (
          <div>
            <span className="text-black font-medium block">{row.original.fullName}</span>
            <span className="text-black/50 text-xs">{row.original.user?.email}</span>
          </div>
        ),
      },
      {
        accessorKey: "stateCode",
        header: "State Code",
        cell: ({ row }) => <span className="text-black">{row.getValue("stateCode")}</span>,
      },
      {
        accessorKey: "kycStatus",
        header: "KYC Status",
        cell: ({ row }) => {
          const status = row.getValue("kycStatus") as string;
          return (
            <Badge className="font-normal capitalize" variant={statusBadgeVariant(status)}>
              {status}
            </Badge>
          );
        },
      },
      {
        accessorKey: "maxLoanAmount",
        header: "Loan Limit",
        cell: ({ row }) => (
          <span className="text-black">₦{(row.getValue("maxLoanAmount") as number).toLocaleString()}</span>
        ),
      },
      {
        accessorKey: "submittedAt",
        header: "Submitted",
        cell: ({ row }) => (
          <span className="text-black">{formatDateString(row.getValue("submittedAt"))}</span>
        ),
      },
      {
        id: "actions",
        header: "Action",
                cell: ({ row }) => {
          const c = row.original;
          return (
            <RowActions
              actions={[
                {
                  key: "review",
                  label: "Review KYC",
                  icon: <Gavel className="size-4" />,
                  hidden: c.kycStatus !== "submitted",
                  dialog: (p) => <CorperReviewModal corper={c} {...p} />,
                },
                {
                  key: "view",
                  label: "View profile",
                  icon: <Eye className="size-4" />,
                  to: `/corpers/${c._id}`,
                },
                {
                  key: "notify",
                  label: "Send notification",
                  icon: <Bell className="size-4" />,
                  hidden: !c.user?._id,
                  dialog: (p) => (
                    <SendNotificationModal
                      recipient={{ userId: c.user._id, label: `${c.fullName} — ${c.user.email ?? ""}` }}
                      {...p}
                    />
                  ),
                },
              ]}
            />
          );
        },
      },
    ],
    [],
  );

  const vendorColumns: ColumnDef<AdminVendor>[] = useMemo(
    () => [
      {
        id: "name",
        header: "Vendor",
        cell: ({ row }) => (
          <div>
            <span className="text-black font-medium block">{row.original.businessName}</span>
            <span className="text-black/50 text-xs">{row.original.owner?.email}</span>
          </div>
        ),
      },
      {
        accessorKey: "vendorCategory",
        header: "Category",
        cell: ({ row }) => (
          <span className="text-black capitalize">{row.getValue("vendorCategory")}</span>
        ),
      },
      {
        accessorKey: "kybStatus",
        header: "KYB Status",
        cell: ({ row }) => {
          const status = row.getValue("kybStatus") as string;
          return (
            <Badge className="font-normal capitalize" variant={statusBadgeVariant(status)}>
              {status}
            </Badge>
          );
        },
      },
      {
        accessorKey: "kopaAccountNumber",
        header: "Kopa Account",
        cell: ({ row }) => (
          <span className="text-black">{row.getValue("kopaAccountNumber") ?? "Not yet issued"}</span>
        ),
      },
      {
        accessorKey: "submittedAt",
        header: "Submitted",
        cell: ({ row }) => (
          <span className="text-black">{formatDateString(row.getValue("submittedAt"))}</span>
        ),
      },
      {
        id: "actions",
        header: "Action",
                cell: ({ row }) => {
          const v = row.original;
          return (
            <RowActions
              actions={[
                {
                  key: "review",
                  label: "Review KYB",
                  icon: <Gavel className="size-4" />,
                  hidden: v.kybStatus !== "submitted",
                  dialog: (p) => <VendorReviewModal vendor={v} {...p} />,
                },
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  dialog: (p) => <VendorDetailsModal vendor={v} {...p} />,
                },
                {
                  key: "notify",
                  label: "Send notification",
                  icon: <Bell className="size-4" />,
                  hidden: !v.owner?._id,
                  dialog: (p) => (
                    <SendNotificationModal
                      recipient={{ userId: v.owner._id, label: `${v.businessName} — ${v.owner.email ?? ""}` }}
                      {...p}
                    />
                  ),
                },
              ]}
            />
          );
        },
      },
    ],
    [],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <Text title="Verification" type="h4" className="text-lg text-black" />
          {isCorper ? (
            <ExportButton
              key="corper-export"
              filename="verification-corps-members"
              columns={corperExportColumns}
              disabled={total === 0}
              fetchPage={async (page, limit) => {
                const res = await getCorpers({ page, limit, kycStatus: reviewStatus, search: debouncedSearch });
                return { rows: res?.data?.corpers ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
              }}
            />
          ) : (
            <ExportButton
              key="vendor-export"
              filename="verification-vendors"
              columns={vendorExportColumns}
              disabled={total === 0}
              fetchPage={async (page, limit) => {
                const res = await getVendorsService({ page, limit, kybStatus: reviewStatus, search: debouncedSearch });
                return { rows: res?.data?.vendors ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
              }}
            />
          )}
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {activeQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load {isCorper ? "corps members" : "vendors"} from the server. Check your
            connection and try again.
          </div>
        )}

        <div className="flex gap-2 border-[0.5px] border-primary/8 bg-white rounded-sm p-1 w-fit">
          <button
            onClick={() => {
              setEntity("corper");
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            }}
            className={cn(
              "px-4 py-1.5 rounded-sm text-sm font-medium transition-colors",
              isCorper ? "bg-primary text-white" : "text-black/60 hover:text-black",
            )}
          >
            Corps Members
          </button>
          <button
            onClick={() => {
              setEntity("vendor");
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            }}
            className={cn(
              "px-4 py-1.5 rounded-sm text-sm font-medium transition-colors",
              !isCorper ? "bg-primary text-white" : "text-black/60 hover:text-black",
            )}
          >
            Vendors
          </button>
        </div>

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total"
            value={(counts.submitted + counts.verified + counts.rejected).toLocaleString()}
            active={!reviewStatus}
            onClick={() => { setReviewStatus(""); resetToFirstPage(); }}
            icon={<Shield className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="Pending Review"
            value={counts.submitted.toLocaleString()}
            active={reviewStatus === "submitted"}
            onClick={() => { setReviewStatus("submitted"); resetToFirstPage(); }}
            icon={<ShieldQuestion className="size-4" />}
            className={kpiStyles.pending}
          />
          <PageMetric
            label="Verified"
            value={counts.verified.toLocaleString()}
            active={reviewStatus === "verified"}
            onClick={() => { setReviewStatus("verified"); resetToFirstPage(); }}
            icon={<ShieldCheck className="size-4" />}
            className={kpiStyles.verified}
          />
          <PageMetric
            label="Rejected"
            value={counts.rejected.toLocaleString()}
            active={reviewStatus === "rejected"}
            onClick={() => { setReviewStatus("rejected"); resetToFirstPage(); }}
            icon={<ShieldX className="size-4" />}
            className={kpiStyles.rejected}
          />
        </div>

        {isCorper ? (
          <ReusableTable
            data={corperRows}
            columns={corperColumns}
            search={{
              value: search,
              onChange: (v) => {
                setSearch(v);
                resetToFirstPage();
              },
              placeholder: "Search name, email, phone or state code",
            }}
            manualPagination={true}
            pageCount={totalPages}
            pagination={pagination}
            onPaginationChange={setPagination}
            isLoading={corpersQuery.isLoading}
            rowCount={total}
            filters={[{ columnKey: "kycStatus", title: "Status", options: STATUS_FILTER_OPTIONS }]}
            filterValues={{ kycStatus: reviewStatus }}
            onFilterChange={(_, v) => {
              setReviewStatus(v);
              resetToFirstPage();
            }}
            emptyMessage={reviewStatus === "submitted" && !debouncedSearch ? "Nothing waiting for review." : "No results."}
          />
        ) : (
          <ReusableTable
            data={vendorRows}
            columns={vendorColumns}
            search={{
              value: search,
              onChange: (v) => {
                setSearch(v);
                resetToFirstPage();
              },
              placeholder: "Search business, phone or owner",
            }}
            manualPagination={true}
            pageCount={totalPages}
            pagination={pagination}
            onPaginationChange={setPagination}
            isLoading={vendorsQuery.isLoading}
            rowCount={total}
            filters={[{ columnKey: "kybStatus", title: "Status", options: STATUS_FILTER_OPTIONS }]}
            filterValues={{ kybStatus: reviewStatus }}
            onFilterChange={(_, v) => {
              setReviewStatus(v);
              resetToFirstPage();
            }}
            emptyMessage={reviewStatus === "submitted" && !debouncedSearch ? "Nothing waiting for review." : "No results."}
          />
        )}
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
  active,
  onClick,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
  active?: boolean;
  onClick?: () => void;
}) => (
  <button
    type="button"
    onClick={onClick}
    aria-pressed={active}
    className={cn(
      "w-full text-left border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3 hover:border-primary/30 transition-colors",
      active && "ring-2 ring-primary/40",
    )}
  >
    <div
      className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]",
        className,
      )}
    >
      {icon}
    </div>
    <Text title={value} type="h2" className="text-2xl font-medium text-black" />
    <Text title={label} type="h4" className="text-black" />
  </button>
);

export default VerificationPage;
