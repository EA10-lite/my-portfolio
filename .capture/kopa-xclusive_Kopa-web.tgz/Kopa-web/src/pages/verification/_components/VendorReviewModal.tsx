import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { Badge } from "../../../components/ui/badge";
import { formatDateString } from "../../../utils/formatter";
import {
  setVendorApprovalStatus,
  verifyVendorIdentity,
  type VendorVerificationResult,
  type FieldVerification,
} from "../../../services/admin.service";
import type { AdminVendor } from "../page";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { getApiErrorMessage } from "../../../utils/apiError";
import { invalidateGroup } from "../../../lib/invalidate";

const matchBadgeVariant = (level: FieldVerification["matchLevel"]) => {
  if (level === "high") return "default" as const;
  if (level === "medium") return "pending" as const;
  if (level === "low") return "destructive" as const;
  return "secondary" as const;
};

const FieldVerificationRow = ({
  label,
  field,
}: {
  label: string;
  field: FieldVerification & { bankName?: string };
}) => (
  <div className="border border-primary/8 rounded-sm p-3 space-y-1.5">
    <div className="flex items-center justify-between">
      <span className="text-xs font-medium text-black/70">{label}</span>
      <Badge className="font-normal capitalize" variant={matchBadgeVariant(field.matchLevel)}>
        {field.matchLevel === "unverified" ? "Could not verify" : `${field.matchLevel} match`}
      </Badge>
    </div>
    <div className="text-xs text-black/50">
      Submitted: <span className="text-black">{field.submittedValue}</span>
    </div>
    {field.apiName && (
      <div className="text-xs text-black/50">
        On record: <span className="text-black">{field.apiName}{field.bankName ? ` (${field.bankName})` : ""}</span>
      </div>
    )}
    {field.matchScore !== null && (
      <div className="text-xs text-black/50">
        Name similarity: <span className="text-black">{field.matchScore}%</span>
      </div>
    )}
    {field.error && <div className="text-xs text-destructive">{field.error}</div>}
  </div>
);

const VendorReviewModal = ({
  vendor,
  triggerButton,
  open: openProp,
  onOpenChange,
}: {
  vendor: AdminVendor;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [reason, setReason] = useState(vendor.kybStatusNote ?? "");
  const [mode, setMode] = useState<"idle" | "rejecting">("idle");
  const qc = useQueryClient();

  const verifyMut = useMutation({
    mutationFn: () => verifyVendorIdentity(vendor.owner._id),
    onError: (e: unknown) =>
      toast.error(getApiErrorMessage(e, "Identity verification failed")),
  });

  const result = (verifyMut.data as { data?: VendorVerificationResult })?.data;

  const reset = () => {
    setReason(vendor.kybStatusNote ?? "");
    setMode("idle");
    verifyMut.reset();
  };

  const approveMut = useMutation({
    mutationFn: () =>
      setVendorApprovalStatus(vendor.owner._id, {
        action: "approve",
        reason: reason || "KYB verified",
      }),
    onSuccess: () => {
      toast.success(`${vendor.businessName} approved`);
      invalidateGroup(qc, "vendors");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Approve failed")),
  });

  const rejectMut = useMutation({
    mutationFn: () => setVendorApprovalStatus(vendor.owner._id, { action: "reject", reason }),
    onSuccess: () => {
      toast.success(`${vendor.businessName} rejected`);
      invalidateGroup(qc, "vendors");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Reject failed")),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-[520px] bg-secondary border border-primary/10 rounded-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Review vendor KYB</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="flex items-center gap-3">
            {vendor.profileImage && (
              <img
                src={vendor.profileImage}
                alt={vendor.businessName}
                className="w-12 h-12 rounded-full object-cover border border-primary/10"
              />
            )}
            <div>
              <p className="text-sm font-medium text-black">{vendor.businessName}</p>
              <p className="text-xs text-black/50">
                {vendor.owner.email} · {vendor.businessPhone}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-black/50 block">Category</span>
              <span className="text-black font-medium capitalize">{vendor.vendorCategory}</span>
            </div>
            <div>
              <span className="text-black/50 block">Address</span>
              <span className="text-black font-medium">{vendor.address}</span>
            </div>
            <div>
              <span className="text-black/50 block">Bank</span>
              <span className="text-black font-medium">{vendor.bank?.name ?? "-"}</span>
            </div>
            <div>
              <span className="text-black/50 block">Submitted</span>
              <span className="text-black font-medium">{formatDateString(vendor.submittedAt)}</span>
            </div>
          </div>

          <a
            href={vendor.kybDocumentUrl}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-primary underline block"
          >
            View submitted CAC document
          </a>

          <div className="border-t border-primary/10 pt-3 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-black/70">Identity verification</p>
              <Button
                type="button"
                variant="outline"
                className="h-7 px-3 text-xs"
                onClick={() => verifyMut.mutate()}
                disabled={verifyMut.isPending}
              >
                {verifyMut.isPending ? "Checking..." : result ? "Re-check" : "Run check"}
              </Button>
            </div>

            {result ? (
              <div className="space-y-2">
                <FieldVerificationRow label="CAC number" field={result.cacNumber} />
                <FieldVerificationRow label="Bank account" field={result.bankAccount} />
              </div>
            ) : (
              <p className="text-xs text-black/40">
                Run the check to decrypt and cross-reference the CAC number and bank account
                against CreditChek before approving.
              </p>
            )}
          </div>

          <div className="border-t border-primary/10 pt-3 space-y-3">
            <p className="text-xs font-medium text-black/70">
              Current status: <span className="capitalize">{vendor.kybStatus}</span>
            </p>

            {mode !== "idle" && (
              <div className="space-y-1">
                <label className="text-xs font-medium text-black/70">
                  Reason (required, shown to the vendor)
                </label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. CAC number does not match uploaded certificate"
                  rows={3}
                />
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="gap-2">
          {mode === "idle" ? (
            <>
              <Button
                variant="destructive"
                onClick={() => setMode("rejecting")}
                disabled={vendor.kybStatus === "rejected"}
              >
                Reject
              </Button>
              <Button
                onClick={() => approveMut.mutate()}
                disabled={approveMut.isPending || vendor.kybStatus === "verified"}
              >
                {approveMut.isPending ? "Approving..." : "Approve"}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setMode("idle")}>
                Back
              </Button>
              <Button
                variant="destructive"
                onClick={() => rejectMut.mutate()}
                disabled={rejectMut.isPending || !reason.trim()}
              >
                {rejectMut.isPending ? "Rejecting..." : "Confirm rejection"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default VendorReviewModal;
