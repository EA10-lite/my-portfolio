import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { Input } from "../../../components/ui/input";
import { Badge } from "../../../components/ui/badge";
import { formatDateString } from "../../../utils/formatter";
import {
  setCorperApprovalStatus,
  verifyCorperIdentity,
  type CorperVerificationResult,
  type FieldVerification,
} from "../../../services/admin.service";
import type { AdminCorper } from "../page";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { getApiErrorMessage } from "../../../utils/apiError";
import { invalidateGroup } from "../../../lib/invalidate";
import { useSettings } from "../../../hooks/useSettings";

const matchBadgeVariant = (level: FieldVerification["matchLevel"]) => {
  if (level === "high") return "default" as const;
  if (level === "medium") return "pending" as const;
  if (level === "low") return "destructive" as const;
  return "secondary" as const;
};

const FieldVerificationRow = ({
  label,
  field,
}: {
  label: string;
  field: FieldVerification & { bankName?: string };
}) => (
  <div className="border border-primary/8 rounded-sm p-3 space-y-1.5">
    <div className="flex items-center justify-between">
      <span className="text-xs font-medium text-black/70">{label}</span>
      <Badge className="font-normal capitalize" variant={matchBadgeVariant(field.matchLevel)}>
        {field.matchLevel === "unverified" ? "Could not verify" : `${field.matchLevel} match`}
      </Badge>
    </div>
    <div className="text-xs text-black/50">
      Submitted: <span className="text-black">{field.submittedValue}</span>
    </div>
    {field.apiName && (
      <div className="text-xs text-black/50">
        On record: <span className="text-black">{field.apiName}{field.bankName ? ` (${field.bankName})` : ""}</span>
      </div>
    )}
    {field.matchScore !== null && (
      <div className="text-xs text-black/50">
        Name similarity: <span className="text-black">{field.matchScore}%</span>
      </div>
    )}
    {field.error && <div className="text-xs text-destructive">{field.error}</div>}
  </div>
);

const CorperReviewModal = ({
  corper,
  triggerButton,
  open: openProp,
  onOpenChange,
}: {
  corper: AdminCorper;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [reason, setReason] = useState(corper.kycStatusNote ?? "");
    const { settings } = useSettings();
  const [amount, setAmount] = useState(String(corper.maxLoanAmount || settings.defaultCreditLimit));
  const overMax = Number(amount) > settings.maxCreditLimit;
  const [mode, setMode] = useState<"idle" | "rejecting">("idle");
  const qc = useQueryClient();

  const verifyMut = useMutation({
    mutationFn: () => verifyCorperIdentity(corper.user._id),
    onError: (e: unknown) =>
      toast.error(getApiErrorMessage(e, "Identity verification failed")),
  });

  const result = (verifyMut.data as { data?: CorperVerificationResult })?.data;

  const reset = () => {
    setReason(corper.kycStatusNote ?? "");
        setAmount(String(corper.maxLoanAmount || settings.defaultCreditLimit));
    setMode("idle");
    verifyMut.reset();
  };

  const approveMut = useMutation({
    mutationFn: () =>
      setCorperApprovalStatus(corper.user._id, {
        action: "approve",
        amount: Number(amount),
        reason: reason || "KYC verified",
      }),
    onSuccess: () => {
      toast.success(`${corper.fullName} approved with ₦${Number(amount).toLocaleString()} limit`);
      invalidateGroup(qc, "corpers");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Approve failed")),
  });

  const rejectMut = useMutation({
    mutationFn: () => setCorperApprovalStatus(corper.user._id, { action: "reject", reason }),
    onSuccess: () => {
      toast.success(`${corper.fullName} rejected`);
      invalidateGroup(qc, "corpers");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Reject failed")),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-[520px] bg-secondary border border-primary/10 rounded-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Review corps member KYC</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="flex items-center gap-3">
            {corper.profileImage && (
              <img
                src={corper.profileImage}
                alt={corper.fullName}
                className="w-12 h-12 rounded-full object-cover border border-primary/10"
              />
            )}
            <div>
              <p className="text-sm font-medium text-black">{corper.fullName}</p>
              <p className="text-xs text-black/50">
                {corper.user.email} · {corper.user.phone ?? "no phone on file"}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-black/50 block">State code</span>
              <span className="text-black font-medium">{corper.stateCode}</span>
            </div>
            <div>
              <span className="text-black/50 block">PPA number</span>
              <span className="text-black font-medium">{corper.ppaNumber}</span>
            </div>
            <div>
              <span className="text-black/50 block">Bank</span>
              <span className="text-black font-medium">{corper.bank?.name ?? "-"}</span>
            </div>
            <div>
              <span className="text-black/50 block">Submitted</span>
              <span className="text-black font-medium">{formatDateString(corper.submittedAt)}</span>
            </div>
          </div>

          <a
            href={corper.kycDocumentUrl}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-primary underline block"
          >
            View submitted {corper.kycDocumentType.split("_").join(" ")} document
          </a>

          <div className="border-t border-primary/10 pt-3 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-medium text-black/70">Identity verification</p>
              <Button
                type="button"
                variant="outline"
                className="h-7 px-3 text-xs"
                onClick={() => verifyMut.mutate()}
                disabled={verifyMut.isPending}
              >
                {verifyMut.isPending ? "Checking..." : result ? "Re-check" : "Run check"}
              </Button>
            </div>

            {result ? (
              <div className="space-y-2">
                <FieldVerificationRow label="BVN" field={result.bvn} />
                <FieldVerificationRow label="NIN" field={result.nin} />
                <FieldVerificationRow label="Bank account" field={result.bankAccount} />
                <div className="border border-primary/8 rounded-sm p-3 space-y-1 text-xs">
                  <span className="font-medium text-black/70">Call-up letter number</span>
                  <p className="text-black">{result.callUpLetterNumber.decryptedValue}</p>
                  <p className="text-black/50">{result.callUpLetterNumber.note}</p>
                </div>
              </div>
            ) : (
              <p className="text-xs text-black/40">
                Run the check to decrypt and cross-reference BVN, NIN, and bank account against
                CreditChek before approving.
              </p>
            )}
          </div>

          <div className="border-t border-primary/10 pt-3 space-y-3">
            <p className="text-xs font-medium text-black/70">
              Current status: <span className="capitalize">{corper.kycStatus}</span>
            </p>

            {mode === "idle" ? null : (
              <div className="space-y-1">
                <label className="text-xs font-medium text-black/70">
                  Reason (required, shown to the corps member)
                </label>
                <Textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. NIN does not match submitted document"
                  rows={3}
                />
              </div>
            )}

            {mode === "idle" && corper.kycStatus !== "verified" && (
              <div className="space-y-1">
                <label className="text-xs font-medium text-black/70">
                  Max loan amount (₦, required to approve)
                </label>
                                <Input
                  type="number"
                  min={1}
                  max={settings.maxCreditLimit}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                {overMax && (
                  <p className="text-xs text-red-600">
                    Above the platform maximum of ₦{settings.maxCreditLimit.toLocaleString()}.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="gap-2">
          {mode === "idle" ? (
            <>
              <Button
                variant="destructive"
                onClick={() => setMode("rejecting")}
                disabled={corper.kycStatus === "rejected"}
              >
                Reject
              </Button>
              <Button
                onClick={() => approveMut.mutate()}
                disabled={
                  approveMut.isPending || corper.kycStatus === "verified" || !Number(amount) || overMax
                }
              >
                {approveMut.isPending ? "Approving..." : "Approve"}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setMode("idle")}>
                Back
              </Button>
              <Button
                variant="destructive"
                onClick={() => rejectMut.mutate()}
                disabled={rejectMut.isPending || !reason.trim()}
              >
                {rejectMut.isPending ? "Rejecting..." : "Confirm rejection"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CorperReviewModal;
