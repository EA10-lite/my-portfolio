import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { cn } from "../../../lib/utils";
import { resolveBillReview, RESOLUTION_LABELS, type BillResolution, type BillReview } from "../../../services/bills.service";
import { formatCurrency } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";

/**
 * Decide a reversed bill purchase. Cancelling the loan is only possible while
 * the repayment hasn't started; the server enforces the same rule.
 */
const ResolveBillDialog = ({
  review,
  open,
  onOpenChange,
}: {
  review: BillReview;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) => {
  const [resolution, setResolution] = useState<BillResolution | null>(null);
  const [note, setNote] = useState("");
  const qc = useQueryClient();
  const debit = review.payment?.monthlyDebitStatus;
  const canCancel = !debit || debit === "scheduled";

  const mut = useMutation({
    mutationFn: () => resolveBillReview(review.id, { resolution: resolution!, note: note.trim() }),
    onSuccess: () => {
      toast.success("Review resolved");
      qc.invalidateQueries({ queryKey: ["bill-reviews"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
      onOpenChange(false);
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not resolve this review.")),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg text-black">
        <DialogHeader>
          <DialogTitle>Resolve reversed purchase</DialogTitle>
          <DialogDescription>
            {review.user?.fullName ?? "A member"} got {review.category} worth {formatCurrency(review.amount)} ({review.reference}), then VTpass reversed
            it. {review.reviewReason}
          </DialogDescription>
        </DialogHeader>
        <div role="radiogroup" aria-label="Resolution" className="space-y-2">
          {(Object.keys(RESOLUTION_LABELS) as BillResolution[]).map((r) => {
            const disabled = r === "cancel_loan" && !canCancel;
            return (
              <button
                key={r}
                type="button"
                role="radio"
                aria-checked={resolution === r}
                disabled={disabled}
                onClick={() => setResolution(r)}
                className={cn(
                  "w-full rounded-md border p-3 text-left text-sm transition-colors",
                  resolution === r ? "border-primary bg-primary/5" : "border-primary/15 hover:border-primary/40",
                  disabled && "opacity-50 cursor-not-allowed hover:border-primary/15",
                )}
              >
                {RESOLUTION_LABELS[r]}
                {disabled && <span className="block text-xs text-black/60">Not possible: the repayment is already {debit}.</span>}
              </button>
            );
          })}
        </div>
        <div className="space-y-1">
          <label htmlFor="bill-note" className="text-xs text-black/60">
            Why (kept in the audit trail)
          </label>
          <Textarea id="bill-note" rows={3} maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button disabled={!resolution || !note.trim() || mut.isPending} onClick={() => mut.mutate()}>
            {mut.isPending ? "Saving…" : "Resolve"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ResolveBillDialog;
