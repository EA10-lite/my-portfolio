import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { AlertTriangle, CheckCircle2, ExternalLink, Gavel, Wallet } from "lucide-react";
import { ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import { cn } from "../../lib/utils";
import { useAdminStore, isSuperAdmin } from "../../stores/adminStore";
import { formatCurrency, formatDateString, formatTime } from "../../utils/formatter";
import { getApiErrorMessage } from "../../utils/apiError";
import { getBillReviews, getProviderBalance, RESOLUTION_LABELS, type BillReview } from "../../services/bills.service";
import ResolveBillDialog from "./_components/ResolveBillDialog";

/** Below this, warn: purchases start failing when the VTpass wallet runs dry. */
const LOW_BALANCE = 50_000;

/**
 * Airtime, data, TV, electricity and education bought on credit through
 * VTpass. Day-to-day purchases settle on their own; admins handle the rare
 * purchase VTpass reverses after it was delivered, and keep the VTpass
 * wallet funded.
 */
const BillsPage = () => {
  const admin = useAdminStore((s) => s.admin);
  const superAdmin = isSuperAdmin(admin?.role);
  const [includeResolved, setIncludeResolved] = useState(false);
  const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 20 });

  const balanceQuery = useQuery({ queryKey: ["vtpass-balance"], queryFn: getProviderBalance, retry: false, refetchInterval: 5 * 60_000 });
  const reviewsQuery = useQuery({
    queryKey: ["bill-reviews", pagination.pageIndex, pagination.pageSize, includeResolved],
    queryFn: () => getBillReviews({ page: pagination.pageIndex + 1, limit: pagination.pageSize, includeResolved }),
    retry: false,
  });

  const rows = reviewsQuery.data?.reviews ?? [];
  const total = reviewsQuery.data?.meta?.total ?? 0;
  const balance = balanceQuery.data?.balance;
  const low = typeof balance === "number" && balance < LOW_BALANCE;

  const columns: ColumnDef<BillReview>[] = useMemo(
    () => [
      {
        id: "purchase",
        header: "Purchase",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black capitalize">
              {row.original.category} <span className="text-black/50 normal-case">· {row.original.serviceID}</span>
            </span>
            <span className="text-xs text-black/50 font-mono">{row.original.reference}</span>
          </div>
        ),
      },
      { id: "member", header: "Member", cell: ({ row }) => <span className="text-black">{row.original.user?.fullName ?? "—"}</span> },
      {
        id: "amount",
        header: "Amount",
        cell: ({ row }) => <span className="text-black font-semibold tabular-nums">{formatCurrency(row.original.amount)}</span>,
      },
      {
        id: "flagged",
        header: "Reversed",
        cell: ({ row }) => (
          <div className="flex flex-col max-w-72">
            <span className="text-sm text-black">{row.original.reviewFlaggedAt ? formatTime(row.original.reviewFlaggedAt) : "—"}</span>
            <span className="text-xs text-black/50 truncate" title={row.original.reviewReason}>
              {row.original.reviewReason}
            </span>
          </div>
        ),
      },
      {
        id: "repayment",
        header: "Repayment",
        cell: ({ row }) => <span className="text-sm text-black capitalize">{row.original.payment?.monthlyDebitStatus ?? "—"}</span>,
      },
      {
        id: "review",
        header: "Review",
        cell: ({ row }) =>
          row.original.reviewStatus === "resolved" ? (
            <div className="flex flex-col">
              <Badge className="font-normal" variant="default">
                Resolved
              </Badge>
              <span className="text-xs text-black/50 mt-1">
                {row.original.reviewResolution ? RESOLUTION_LABELS[row.original.reviewResolution].split(" (")[0] : ""}
                {row.original.reviewResolvedAt ? ` · ${formatDateString(row.original.reviewResolvedAt)}` : ""}
              </span>
            </div>
          ) : (
            <Badge className="font-normal" variant="pending">
              Needs review
            </Badge>
          ),
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) =>
          row.original.reviewStatus === "needs_review" && superAdmin ? (
            <RowActions
              actions={[
                {
                  key: "resolve",
                  label: "Resolve",
                  icon: <Gavel className="size-4" />,
                  dialog: (d) => <ResolveBillDialog review={row.original} open={d.open} onOpenChange={d.onOpenChange} />,
                },
              ]}
            />
          ) : (
            <span className="text-xs text-black/40">{row.original.reviewStatus === "needs_review" ? "Super admin" : ""}</span>
          ),
      },
    ],
    [superAdmin],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <Text title="Bill payments" type="h4" className="text-lg text-black" />
            <p className="text-sm text-black/60 mt-1">Airtime, data, TV, electricity and education bought on credit through VTpass.</p>
          </div>
          <Link to="/transactions?type=bill_payment" className="text-primary text-sm flex items-center gap-1 hover:underline">
            All bill payments in the ledger <ExternalLink className="size-3.5" />
          </Link>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6 text-black">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            className={cn(
              "rounded-sm border-[0.5px] bg-white p-4 flex flex-col gap-1",
              low ? "border-amber-300 bg-amber-50/70" : "border-primary/10",
            )}
          >
            <span className="flex items-center gap-2 text-sm text-black/70">
              <Wallet className="size-4" /> VTpass wallet
            </span>
            {balanceQuery.isLoading ? (
              <span className="text-2xl font-semibold text-black/30">…</span>
            ) : balanceQuery.isError ? (
              <span className="text-sm text-red-700">{getApiErrorMessage(balanceQuery.error, "Could not reach VTpass.")}</span>
            ) : (
              <span className="text-2xl font-semibold tabular-nums">{formatCurrency(balance ?? 0)}</span>
            )}
            <span className={cn("text-xs flex items-center gap-1", low ? "text-amber-800" : "text-black/50")}>
              {low ? (
                <>
                  <AlertTriangle className="size-3.5" /> Running low. Top up on VTpass: purchases fail when it's empty.
                </>
              ) : (
                "Every purchase is paid from this wallet."
              )}
            </span>
          </div>
          <div className="rounded-sm border-[0.5px] border-primary/10 bg-white p-4 flex flex-col gap-1">
            <span className="flex items-center gap-2 text-sm text-black/70">
              <CheckCircle2 className="size-4" /> Reversed purchases
            </span>
            <span className="text-2xl font-semibold tabular-nums">{includeResolved ? "—" : total.toLocaleString()}</span>
            <span className="text-xs text-black/50">
              Delivered, then reversed by VTpass. The member already has the goods, so nothing is refunded automatically.
            </span>
          </div>
        </div>

        {reviewsQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            {getApiErrorMessage(reviewsQuery.error, "Could not load the review queue.")}
          </div>
        )}

        <label className="flex items-center gap-2 text-sm text-black/70 w-fit">
          <input
            type="checkbox"
            checked={includeResolved}
            onChange={(e) => {
              setIncludeResolved(e.target.checked);
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            }}
          />
          Show resolved reviews too
        </label>

        <ReusableTable
          data={rows}
          columns={columns}
          manualPagination={true}
          pageCount={reviewsQuery.data?.meta?.totalPages ?? 1}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={reviewsQuery.isLoading}
          rowCount={total}
          emptyMessage={includeResolved ? "No reversed purchases yet." : "Nothing to review. Every bill purchase settled normally."}
        />
      </div>
    </div>
  );
};

export default BillsPage;
