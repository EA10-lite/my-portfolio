import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { toast } from "sonner";
import { FileSearch, Filter, Scale, User, UserCheck, UserX, X } from "lucide-react";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { cn } from "../../lib/utils";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import { useOpenCorperProfile } from "../../hooks/useOpenCorperProfile";
import { useAdminStore } from "../../stores/adminStore";
import { formatCurrency, formatTime } from "../../utils/formatter";
import { getApiErrorMessage } from "../../utils/apiError";
import {
  getDisputes,
  getDisputeStats,
  PRIORITY_LABELS,
  REASON_LABELS,
  SOURCE_LABELS,
  STATUS_LABELS,
  updateDispute,
  type Dispute,
  type DisputePriority,
  type DisputeReason,
  type DisputeStatus,
} from "../../services/disputes.service";
import DisputeModal from "./_components/DisputeModal";
import LogDisputeModal from "./_components/LogDisputeModal";

const statusVariant = (s: DisputeStatus) =>
  s === "open" ? ("pending" as const) : s === "in_review" ? ("new" as const) : s === "resolved" ? ("default" as const) : ("secondary" as const);
const priorityTone: Record<DisputePriority, string> = {
  high: "text-red-700",
  medium: "text-amber-700",
  low: "text-black/50",
};

/**
 * Purchase disputes between corps members and vendors. Raised from the
 * corps member app, or logged here from a call. Record-only: deciding a
 * dispute never moves money — an agreed refund is settled off-platform and
 * noted on the dispute.
 *
 * URL: ?status= ?assignedTo=me|unassigned ?vendorId= ?userId=
 */
const DisputesPage = () => {
  const admin = useAdminStore((s) => s.admin);
  const qc = useQueryClient();
  const openProfile = useOpenCorperProfile();
  const [searchParams, setSearchParams] = useSearchParams();
  const status = searchParams.get("status") ?? "";
  const assignedTo = searchParams.get("assignedTo") ?? "";
  const vendorId = searchParams.get("vendorId") ?? "";
  const userId = searchParams.get("userId") ?? "";
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [search, setSearch] = useState(() => searchParams.get("search") ?? "");
  const debouncedSearch = useDebouncedValue(search.trim());
  const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 20 });

  const setParams = (updates: Record<string, string>) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  const query = { status, assignedTo, vendorId, userId, priority: filters.priority, reason: filters.reason, search: debouncedSearch };

  const listQuery = useQuery({
    queryKey: ["disputes", pagination.pageIndex, pagination.pageSize, query],
    queryFn: () => getDisputes({ ...query, page: pagination.pageIndex + 1, limit: pagination.pageSize }),
    retry: false,
  });
  const statsQuery = useQuery({ queryKey: ["dispute-stats"], queryFn: getDisputeStats, retry: false, refetchInterval: 60_000 });

  const rows = listQuery.data?.disputes ?? [];
  const total = listQuery.data?.meta?.total ?? 0;
  const totalPages = listQuery.data?.meta?.totalPages ?? 1;
  const stats = statsQuery.data;

  const quickUpdate = useMutation({
    mutationFn: ({ id, assignedTo }: { id: string; assignedTo: string | null }) => updateDispute(id, { assignedTo }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["disputes"] });
      qc.invalidateQueries({ queryKey: ["dispute-stats"] });
      toast.success("Dispute updated");
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update the dispute.")),
  });

  // Name of the vendor / member a deep link is scoped to, from the rows themselves.
  const scopeLabel =
    (vendorId && rows[0]?.vendor?.businessName) || (userId && rows[0]?.corperUser?.fullName) || (vendorId ? "this vendor" : userId ? "this member" : "");

  const columns: ColumnDef<Dispute>[] = useMemo(
    () => [
      {
        id: "dispute",
        header: "Dispute",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black font-medium">{REASON_LABELS[row.original.reason] ?? row.original.reason}</span>
            <span className="text-xs text-black/50 font-mono">
              {row.original.disputeNumber}
              {row.original.source === "admin" ? " · logged by admin" : ""}
            </span>
          </div>
        ),
      },
      {
        id: "purchase",
        header: "Purchase",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black font-semibold">{formatCurrency(row.original.amount)}</span>
            <span className="text-xs text-black/50 font-mono">{row.original.paymentCode}</span>
            {row.original.payment?.source && row.original.payment.source !== "vendor" && (
              <span className="text-[11px] text-black/60">{SOURCE_LABELS[row.original.payment.source]}</span>
            )}
          </div>
        ),
      },
      {
        id: "member",
        header: "Corps member",
        cell: ({ row }) => <span className="text-black">{row.original.corperUser?.fullName ?? "—"}</span>,
      },
      {
        id: "vendor",
        header: "Vendor",
        cell: ({ row }) => <span className="text-black">{row.original.vendor?.businessName ?? "—"}</span>,
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => (
          <Badge className="font-normal" variant={statusVariant(row.original.status)}>
            {STATUS_LABELS[row.original.status]}
          </Badge>
        ),
      },
      {
        accessorKey: "priority",
        header: "Priority",
        cell: ({ row }) => (
          <span className={cn("text-sm font-medium", priorityTone[row.original.priority])}>{PRIORITY_LABELS[row.original.priority]}</span>
        ),
      },
      {
        id: "assignee",
        header: "Assigned",
        cell: ({ row }) =>
          row.original.assignedTo?.fullName ? (
            <span className="text-black text-sm">{row.original.assignedTo._id === admin?._id ? "You" : row.original.assignedTo.fullName}</span>
          ) : (
            <span className="text-black/40 text-sm">Unassigned</span>
          ),
      },
      {
        id: "opened",
        header: "Opened",
        cell: ({ row }) => <span className="text-sm text-black">{formatTime(row.original.createdAt)}</span>,
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const d = row.original;
          const mine = d.assignedTo?._id === admin?._id;
          return (
            <RowActions
              actions={[
                {
                  key: "open",
                  label: d.status === "open" || d.status === "in_review" ? "Investigate & decide" : "View decision",
                  icon: <FileSearch className="size-4" />,
                  dialog: (p) => <DisputeModal disputeId={d._id} {...p} />,
                },
                {
                  key: "assign",
                  label: "Assign to me",
                  icon: <UserCheck className="size-4" />,
                  hidden: mine || !admin?._id || d.status === "resolved" || d.status === "rejected",
                  onSelect: () => quickUpdate.mutate({ id: d._id, assignedTo: admin?._id ?? null }),
                },
                {
                  key: "unassign",
                  label: "Unassign",
                  icon: <UserX className="size-4" />,
                  hidden: !d.assignedTo,
                  onSelect: () => quickUpdate.mutate({ id: d._id, assignedTo: null }),
                },
                {
                  key: "member",
                  label: "View member profile",
                  icon: <User className="size-4" />,
                  hidden: !d.corperUser?.email,
                  onSelect: () => openProfile(d.corperUser?.email),
                },
                {
                  key: "vendor",
                  label: "This vendor's disputes",
                  icon: <Filter className="size-4" />,
                  hidden: !d.vendor?._id || vendorId === d.vendor?._id,
                  onSelect: () => setParams({ vendorId: d.vendor?._id ?? "", userId: "" }),
                },
              ]}
            />
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [admin?._id, quickUpdate, vendorId, openProfile],
  );

  const QUEUES = [
    { key: "open", label: "New", value: stats?.open, params: { status: "open", assignedTo: "" } },
    { key: "in_review", label: "In review", value: stats?.inReview, params: { status: "in_review", assignedTo: "" } },
    { key: "unassigned", label: "Unassigned", value: stats?.unassigned, params: { status: "", assignedTo: "unassigned" } },
    { key: "mine", label: "Assigned to me", value: stats?.mine, params: { status: "", assignedTo: "me" } },
  ];

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <Text title="Disputes" type="h4" className="text-lg text-black" />
            <p className="text-sm text-black/60 mt-1">
              {stats && stats.amountInDispute > 0
                ? `${formatCurrency(stats.amountInDispute)} in purchases under dispute.`
                : "Purchase disputes between corps members and vendors."}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <LogDisputeModal />
            <ExportButton
              filename="disputes"
              disabled={total === 0}
              fetchPage={async (page, limit) => {
                const res = await getDisputes({ ...query, page, limit });
                return { rows: res?.disputes ?? [], totalPages: res?.meta?.totalPages, total: res?.meta?.total };
              }}
              columns={[
                { header: "Dispute", value: (d: Dispute) => d.disputeNumber },
                { header: "Payment code", value: (d: Dispute) => d.paymentCode },
                { header: "Amount", value: (d: Dispute) => d.amount },
                { header: "Reason", value: (d: Dispute) => REASON_LABELS[d.reason] ?? d.reason },
                { header: "Corps member", value: (d: Dispute) => d.corperUser?.fullName },
                { header: "Vendor", value: (d: Dispute) => d.vendor?.businessName },
                { header: "Status", value: (d: Dispute) => STATUS_LABELS[d.status] },
                { header: "Priority", value: (d: Dispute) => d.priority },
                { header: "Assigned to", value: (d: Dispute) => d.assignedTo?.fullName },
                { header: "Refund agreed", value: (d: Dispute) => d.refundAgreed ?? "" },
                { header: "Source", value: (d: Dispute) => d.source },
                { header: "Opened", value: (d: Dispute) => d.createdAt },
              ]}
            />
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6 text-black">
        <div className="flex items-start gap-2 bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-sm p-3">
          <Scale className="size-4 mt-0.5 shrink-0" />
          <p>
            Deciding a dispute notifies both sides. For an <b>order</b>, it also settles the money held in escrow: a refund goes back to
            the member's credit and the rest is paid to the vendor. For vendor payments and bill purchases the decision is recorded only; settle
            any refund with the vendor directly and note the amount.
          </p>
        </div>

        {listQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            {getApiErrorMessage(listQuery.error, "Could not load disputes.")}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {QUEUES.map((q) => {
            const active = q.params.status === status && q.params.assignedTo === assignedTo;
            return (
              <button
                key={q.key}
                type="button"
                aria-pressed={active}
                onClick={() => setParams(active ? { status: "", assignedTo: "" } : q.params)}
                className={cn(
                  "flex flex-col gap-2 rounded-sm border-[0.5px] border-primary/10 bg-white p-4 text-left transition-colors hover:border-primary/40",
                  (q.value ?? 0) > 0 && (q.key === "open" || q.key === "unassigned") && "border-amber-200 bg-amber-50/60",
                  active && "ring-2 ring-primary/40",
                )}
              >
                <span className="flex items-center gap-2 text-sm text-black/70">
                  <Scale className="size-4" /> {q.label}
                </span>
                <span className="text-2xl font-semibold text-black">{(q.value ?? 0).toLocaleString()}</span>
              </button>
            );
          })}
        </div>

        {(vendorId || userId) && (
          <div className="flex items-center gap-2 text-sm">
            <span className="text-black/60">Showing disputes for</span>
            <span className="font-medium">{scopeLabel}</span>
            <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => setParams({ vendorId: "", userId: "" })}>
              <X className="size-3.5" /> Clear
            </Button>
          </div>
        )}

        <ReusableTable
          data={rows}
          columns={columns}
          search={{
            value: search,
            onChange: (v) => {
              setSearch(v);
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            },
            placeholder: "Search dispute number or payment code",
          }}
          filters={[
            { columnKey: "status", title: "Status", options: (Object.keys(STATUS_LABELS) as DisputeStatus[]).map((s) => ({ label: STATUS_LABELS[s], value: s })) },
            { columnKey: "reason", title: "Reason", options: (Object.keys(REASON_LABELS) as DisputeReason[]).map((r) => ({ label: REASON_LABELS[r], value: r })) },
            { columnKey: "priority", title: "Priority", options: (Object.keys(PRIORITY_LABELS) as DisputePriority[]).map((p) => ({ label: PRIORITY_LABELS[p], value: p })) },
          ]}
          filterValues={{ status, ...filters }}
          onFilterChange={(key, value) => {
            if (key === "status") setParams({ status: value });
            else {
              setFilters((f) => ({ ...f, [key]: value }));
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            }
          }}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={listQuery.isLoading}
          rowCount={total}
          emptyMessage={
            status || assignedTo || vendorId || userId || debouncedSearch || filters.reason || filters.priority
              ? "No disputes match these filters."
              : "No disputes yet. Corps members raise them from the app, or log one here from a call."
          }
        />
      </div>
    </div>
  );
};

export default DisputesPage;
