import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AlertTriangle, CheckCircle2, Lock, Package, RotateCcw, Store, XCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Textarea } from "../../../components/ui/textarea";
import { Skeleton } from "../../../components/ui/skeleton";
import { Badge } from "../../../components/ui/badge";
import { cn } from "../../../lib/utils";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { useAdminStore, isSuperAdmin } from "../../../stores/adminStore";
import { getAdmins } from "../../../services/admin.service";
import type { PersonRef } from "../../../services/support.service";
import {
  addDisputeNote,
  getDispute,
  PRIORITY_LABELS,
  REASON_LABELS,
  SOURCE_LABELS,
  STATUS_LABELS,
  updateDispute,
  type DisputePriority,
  type DisputeStatus,
} from "../../../services/disputes.service";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";

const selectClass = "h-8 w-full rounded-md border border-input bg-white px-2 text-sm text-black";

type Outcome = "resolved" | "rejected";

/**
 * One dispute: both sides, the purchase, an internal investigation log and
 * the decision. Recording a decision notifies both parties; it never moves
 * money — an agreed refund is noted for the record only.
 */
const DisputeModal = ({
  disputeId,
  open: openProp,
  onOpenChange,
}: {
  disputeId: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const admin = useAdminStore((s) => s.admin);
  const superAdmin = isSuperAdmin(admin?.role);
  const qc = useQueryClient();
  const [note, setNote] = useState("");
  const [outcome, setOutcome] = useState<Outcome | null>(null);
  const [resolutionNote, setResolutionNote] = useState("");
  const [refund, setRefund] = useState("");
  // Order decisions move escrowed money, so they get an explicit confirm step.
  const [confirming, setConfirming] = useState(false);

  const q = useQuery({
    queryKey: ["dispute", disputeId],
    queryFn: () => getDispute(disputeId),
    enabled: open,
    retry: false,
  });
  const adminsQuery = useQuery({
    queryKey: ["admin-users", "assignees"],
    queryFn: () => getAdmins({ status: "approved", page: 1, limit: 100 }),
    enabled: open && superAdmin,
    retry: false,
  });
  const assignees: PersonRef[] = (adminsQuery.data as { data?: { data?: PersonRef[] } })?.data?.data ?? [];

  const d = q.data;
  const decided = d?.status === "resolved" || d?.status === "rejected";
  const assigneeId = d?.assignedTo && typeof d.assignedTo === "object" ? d.assignedTo._id : undefined;

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["dispute", disputeId] });
    qc.invalidateQueries({ queryKey: ["disputes"] });
    qc.invalidateQueries({ queryKey: ["dispute-stats"] });
    qc.invalidateQueries({ queryKey: ["sidebar-pending"] });
    qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
  };

  const noteMut = useMutation({
    mutationFn: () => addDisputeNote(disputeId, note.trim()),
    onSuccess: () => {
      setNote("");
      toast.success("Note added");
      refresh();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not add the note.")),
  });

  const updateMut = useMutation({
    mutationFn: (patch: Parameters<typeof updateDispute>[1]) => updateDispute(disputeId, patch),
    onSuccess: (_, patch) => {
      if (patch.status === "resolved" || patch.status === "rejected") {
        toast.success(
          escrowHeld ? "Decision recorded and the order's money settled" : "Decision recorded — both sides have been notified",
        );
        setConfirming(false);
        setOutcome(null);
        setResolutionNote("");
        setRefund("");
      } else if (patch.status === "in_review") {
        toast.success("Dispute reopened");
      } else {
        toast.success("Dispute updated");
      }
      refresh();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update the dispute.")),
  });

  const order = d?.order ?? null;
  const escrowHeld = order?.escrow === "held";
  const refundNum = refund ? Number(refund.replace(/\D/g, "")) : undefined;
  const ceiling = escrowHeld && order ? order.totalAmount : d?.amount ?? 0;
  const refundTooHigh = refundNum !== undefined && d ? refundNum > ceiling : false;
  const canDecide = outcome && resolutionNote.trim().length >= 5 && !refundTooHigh;
  // What the backend will do with the escrow (orders only). An empty refund
  // box on a member win means a FULL refund there.
  const toMember = escrowHeld && order ? (outcome === "resolved" ? Math.min(refundNum ?? order.totalAmount, order.totalAmount) : 0) : 0;
  const toVendor = escrowHeld && order ? order.totalAmount - toMember : 0;
  const submitDecision = () =>
    updateMut.mutate({
      status: outcome as DisputeStatus,
      resolutionNote: resolutionNote.trim(),
      ...(outcome === "resolved" && (refundNum || (escrowHeld && order)) ? { refundAgreed: escrowHeld ? toMember : refundNum } : {}),
    });
  const busy = noteMut.isPending || updateMut.isPending;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-4xl max-h-[92vh] overflow-hidden p-0 flex flex-col text-black">
        <DialogHeader className="px-5 pt-5">
          <DialogTitle className="pr-8 flex flex-wrap items-center gap-2">
            {d ? REASON_LABELS[d.reason] : "Dispute"}
            {d && (
              <Badge variant={d.status === "open" ? "pending" : d.status === "in_review" ? "new" : d.status === "resolved" ? "default" : "secondary"} className="font-normal">
                {STATUS_LABELS[d.status]}
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            {d ? `${d.disputeNumber} · opened ${formatDateString(d.createdAt)}${d.source === "admin" ? " · logged by an admin" : ""}` : "Loading…"}
          </DialogDescription>
        </DialogHeader>

        {q.isLoading ? (
          <div className="p-5">
            <Skeleton className="h-72 w-full" />
          </div>
        ) : q.isError || !d ? (
          <p className="p-5 text-sm text-red-700">{getApiErrorMessage(q.error, "Could not load this dispute.")}</p>
        ) : (
          <div className="grid md:grid-cols-[1fr_240px] min-h-0 flex-1 border-t border-primary/10 overflow-y-auto">
            <div className="p-5 space-y-5 min-w-0">
              {/* Both sides */}
              <section className="grid sm:grid-cols-2 gap-3">
                <div className="rounded-md border border-primary/10 bg-secondary-foreground p-3">
                  <p className="text-xs text-black/50 mb-1">{d.corperUser?.fullName ?? "Corps member"} says</p>
                  <p className="text-sm whitespace-pre-wrap">{d.description}</p>
                </div>
                <div className="rounded-md border border-primary/10 p-3">
                  <p className="text-xs text-black/50 mb-1 flex items-center gap-1">
                    <Store className="size-3" /> {d.vendor?.businessName ?? "Vendor"} says
                  </p>
                  {d.vendorResponse ? (
                    <>
                      <p className="text-sm whitespace-pre-wrap">{d.vendorResponse}</p>
                      {d.vendorRespondedAt && <p className="text-[11px] text-black/40 mt-1">{formatDateString(d.vendorRespondedAt)}</p>}
                    </>
                  ) : (
                    <p className="text-sm text-black/50">
                      No response yet. The vendor was notified and can answer from the vendor app
                      {d.vendorOwner?.phone ? `, or call them on ${d.vendorOwner.phone}` : ""}.
                    </p>
                  )}
                </div>
              </section>

              {/* Decision */}
              {decided ? (
                <section
                  className={cn(
                    "rounded-md border p-4 space-y-1",
                    d.status === "resolved" ? "border-emerald-200 bg-emerald-50/60" : "border-slate-200 bg-slate-50",
                  )}
                >
                  <p className="text-sm font-medium flex items-center gap-1.5">
                    {d.status === "resolved" ? <CheckCircle2 className="size-4 text-emerald-700" /> : <XCircle className="size-4 text-slate-600" />}
                    {d.status === "resolved" ? "Resolved in the corps member's favour" : "Decided in the vendor's favour"}
                  </p>
                  <p className="text-sm whitespace-pre-wrap">{d.resolutionNote}</p>
                  {order && order.escrow !== "held" ? (
                    <p className="text-sm">
                      Order {order.orderNumber}:{" "}
                      {order.refundedAmount > 0 ? (
                        <>
                          <span className="font-semibold">{formatCurrency(order.refundedAmount)}</span> returned to the member
                          {order.refundedAmount < order.totalAmount
                            ? `, ${formatCurrency(order.totalAmount - order.refundedAmount)} paid to the vendor`
                            : ""}
                        </>
                      ) : (
                        <>
                          <span className="font-semibold">{formatCurrency(order.totalAmount)}</span> paid to the vendor
                        </>
                      )}
                      .
                    </p>
                  ) : d.refundAgreed ? (
                    <p className="text-sm">
                      Refund agreed off-platform: <span className="font-semibold">{formatCurrency(d.refundAgreed)}</span>
                    </p>
                  ) : null}
                  <p className="text-xs text-black/50">
                    {d.decidedBy && typeof d.decidedBy === "object" ? d.decidedBy.fullName : "An admin"}
                    {d.decidedAt ? ` · ${formatDateString(d.decidedAt)}` : ""}
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2 gap-1.5"
                    disabled={busy}
                    onClick={() => updateMut.mutate({ status: "in_review" })}
                  >
                    <RotateCcw className="size-3.5" /> Reopen
                  </Button>
                </section>
              ) : (
                <section className="rounded-md border border-primary/15 p-4 space-y-3">
                  <p className="text-sm font-medium">Record a decision</p>
                  <div role="radiogroup" aria-label="Outcome" className="grid sm:grid-cols-2 gap-2">
                    {(
                      [
                        { value: "resolved", label: "Corps member is right", hint: "Resolve in their favour" },
                        { value: "rejected", label: "Vendor is right", hint: "Close the dispute" },
                      ] as const
                    ).map((o) => (
                      <button
                        key={o.value}
                        type="button"
                        role="radio"
                        aria-checked={outcome === o.value}
                        onClick={() => {
                          setOutcome(o.value);
                          setConfirming(false);
                        }}
                        className={cn(
                          "rounded-md border p-3 text-left text-sm transition-colors",
                          outcome === o.value ? "border-primary bg-primary/5" : "border-primary/15 hover:border-primary/40",
                        )}
                      >
                        <span className="font-medium block">{o.label}</span>
                        <span className="text-xs text-black/50">{o.hint}</span>
                      </button>
                    ))}
                  </div>
                  {outcome && (
                    <>
                      <div className="space-y-1">
                        <label htmlFor="d-resolution" className="text-xs text-black/60">
                          Resolution — both sides will see this
                        </label>
                        <Textarea
                          id="d-resolution"
                          rows={3}
                          maxLength={2000}
                          value={resolutionNote}
                          onChange={(e) => setResolutionNote(e.target.value)}
                          placeholder={
                            outcome === "resolved"
                              ? "e.g. Vendor confirmed the item was out of stock and agreed to refund in full."
                              : "e.g. Courier confirmed delivery on 4 Sept with the member's signature."
                          }
                        />
                      </div>
                      {outcome === "resolved" && (
                        <div className="space-y-1">
                          <label htmlFor="d-refund" className="text-xs text-black/60">
                            {escrowHeld
                              ? "Refund to the member (₦). Leave empty to refund the whole order"
                              : "Refund the vendor agreed to (optional, ₦) — recorded only, no money moves"}
                          </label>
                          <Input
                            id="d-refund"
                            inputMode="numeric"
                            value={refund ? Number(refund.replace(/\D/g, "") || 0).toLocaleString() : ""}
                            onChange={(e) => setRefund(e.target.value.replace(/\D/g, ""))}
                            placeholder={escrowHeld && order ? `Full refund: ${formatCurrency(order.totalAmount)}` : `Up to ${formatCurrency(d.amount)}`}
                            className="max-w-[220px] bg-white"
                          />
                          {refundTooHigh && <p className="text-xs text-red-700">Can't be more than {escrowHeld ? "the order" : "the purchase"} ({formatCurrency(ceiling)}).</p>}
                        </div>
                      )}
                      {escrowHeld && order && (
                        <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-sm space-y-1" role="status">
                          <p className="font-medium flex items-center gap-1.5">
                            <AlertTriangle className="size-4 text-amber-700" /> This decision moves money
                          </p>
                          <p>
                            {formatCurrency(order.totalAmount)} is held for order {order.orderNumber}. Recording this will:
                          </p>
                          <ul className="list-disc pl-5">
                            {toMember > 0 && (
                              <li>
                                return <b>{formatCurrency(toMember)}</b> to {d.corperUser?.fullName ?? "the member"}'s credit
                                {toMember >= order.totalAmount ? " and cancel the order" : ""}
                              </li>
                            )}
                            {toVendor > 0 && (
                              <li>
                                pay <b>{formatCurrency(toVendor)}</b> to {d.vendor?.businessName ?? "the vendor"}
                              </li>
                            )}
                          </ul>
                          <p className="text-xs text-black/60">This can't be undone from the dashboard. Reopening the dispute won't reverse it.</p>
                        </div>
                      )}
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => (confirming ? setConfirming(false) : setOutcome(null))}
                          disabled={busy}
                        >
                          {confirming ? "Back" : "Cancel"}
                        </Button>
                        {escrowHeld && !confirming ? (
                          <Button size="sm" disabled={!canDecide || busy} onClick={() => setConfirming(true)}>
                            Review and settle
                          </Button>
                        ) : (
                          <Button size="sm" disabled={!canDecide || busy} onClick={submitDecision}>
                            {updateMut.isPending ? "Saving…" : escrowHeld ? "Confirm and settle order" : "Record decision"}
                          </Button>
                        )}
                      </div>
                    </>
                  )}
                </section>
              )}

              {/* Internal investigation log */}
              <section className="space-y-2">
                <p className="text-sm font-medium flex items-center gap-1.5">
                  <Lock className="size-3.5" /> Investigation notes <span className="text-xs font-normal text-black/50">· admins only</span>
                </p>
                {(d.notes ?? []).length === 0 ? (
                  <p className="text-sm text-black/50">Nothing logged yet.</p>
                ) : (
                  <ul className="space-y-2">
                    {[...(d.notes ?? [])].reverse().map((n) => (
                      <li key={n._id} className="rounded-md bg-amber-50 border border-amber-200 px-3 py-2 text-sm">
                        <p className="text-[11px] text-black/50 mb-0.5">
                          {typeof n.author === "object" ? n.author?.fullName : "Admin"} · {formatDateString(n.createdAt)}
                        </p>
                        <p className="whitespace-pre-wrap">{n.body}</p>
                      </li>
                    ))}
                  </ul>
                )}
                <Textarea
                  aria-label="Add an investigation note"
                  rows={2}
                  maxLength={4000}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Called the vendor — says the order was dispatched on the 3rd, sending proof."
                  className="bg-amber-50/40"
                />
                <div className="flex justify-end">
                  <Button size="sm" variant="outline" disabled={busy || !note.trim()} onClick={() => noteMut.mutate()}>
                    {noteMut.isPending ? "Adding…" : "Add note"}
                  </Button>
                </div>
              </section>
            </div>

            {/* Side panel */}
            <aside className="border-t md:border-t-0 md:border-l border-primary/10 p-4 space-y-4 text-sm bg-secondary-foreground/40">
              <div>
                <p className="text-xs text-black/50">
                  {d.payment?.source ? SOURCE_LABELS[d.payment.source] : "Purchase"}
                </p>
                <p className="text-lg font-semibold">{formatCurrency(d.amount)}</p>
                <p className="text-xs font-mono text-black/60">{d.paymentCode}</p>
                {order ? (
                  <div className="mt-1.5 space-y-0.5">
                    <p className="text-xs text-black/70 flex items-center gap-1">
                      <Package className="size-3.5" /> {order.itemCount} item{order.itemCount === 1 ? "" : "s"} ·{" "}
                      <span className="capitalize">{(order.statusBeforeDispute ?? order.status).replace("_", " ")}</span>
                    </p>
                    <p className={cn("text-xs", order.escrow === "held" ? "text-amber-700 font-medium" : "text-black/60")}>
                      {order.escrow === "held"
                        ? `${formatCurrency(order.totalAmount)} held in escrow`
                        : order.escrow === "refunded"
                          ? "Refunded to the member"
                          : "Paid out to the vendor"}
                    </p>
                    {order.items.slice(0, 4).map((i) => (
                      <p key={i.name} className="text-xs text-black/60 truncate">
                        {i.quantity}× {i.name}
                      </p>
                    ))}
                  </div>
                ) : (
                  d.payment?.serviceType && <p className="text-xs text-black/60 capitalize">{d.payment.serviceType}</p>
                )}
                {d.payment?.paidAt && <p className="text-xs text-black/60">Paid {formatDateString(d.payment.paidAt)}</p>}
                {d.payment?.monthlyDebitStatus && (
                  <p className="text-xs text-black/60">Repayment: {d.payment.monthlyDebitStatus}</p>
                )}
              </div>
              <div>
                <p className="text-xs text-black/50">Corps member</p>
                <p className="font-medium">{d.corperUser?.fullName ?? "—"}</p>
                <p className="text-xs text-black/60">{d.corperUser?.phone ?? d.corperUser?.email}</p>
              </div>
              <div>
                <p className="text-xs text-black/50">Vendor</p>
                <p className="font-medium">{d.vendor?.businessName ?? "—"}</p>
                <p className="text-xs text-black/60">{d.vendorOwner?.phone ?? d.vendorOwner?.email}</p>
              </div>
              <div className="space-y-1">
                <label htmlFor="d-priority" className="text-xs text-black/50">Priority</label>
                <select
                  id="d-priority"
                  className={selectClass}
                  value={d.priority}
                  disabled={busy}
                  onChange={(e) => updateMut.mutate({ priority: e.target.value as DisputePriority })}
                >
                  {(Object.keys(PRIORITY_LABELS) as DisputePriority[]).map((p) => (
                    <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label htmlFor="d-assignee" className="text-xs text-black/50">Assigned to</label>
                {superAdmin ? (
                  <select
                    id="d-assignee"
                    className={selectClass}
                    value={assigneeId ?? ""}
                    disabled={busy}
                    onChange={(e) => updateMut.mutate({ assignedTo: e.target.value || null })}
                  >
                    <option value="">Unassigned</option>
                    {assignees.map((a) => (
                      <option key={a._id} value={a._id}>{a.fullName}</option>
                    ))}
                  </select>
                ) : (
                  <div className="space-y-1.5">
                    <p>{d.assignedTo && typeof d.assignedTo === "object" ? d.assignedTo.fullName : "Unassigned"}</p>
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full"
                      disabled={busy}
                      onClick={() => updateMut.mutate({ assignedTo: assigneeId === admin?._id ? null : admin?._id ?? null })}
                    >
                      {assigneeId === admin?._id ? "Unassign me" : "Assign to me"}
                    </Button>
                  </div>
                )}
              </div>
            </aside>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default DisputeModal;
