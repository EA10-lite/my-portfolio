import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Textarea } from "../../../components/ui/textarea";
import {
  logDispute,
  lookupPaymentForDispute,
  PRIORITY_LABELS,
  REASON_LABELS,
  SOURCE_LABELS,
  STATUS_LABELS,
  type DisputePriority,
  type DisputeReason,
  type PaymentLookup,
} from "../../../services/disputes.service";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";

const selectClass = "h-9 w-full rounded-md border border-input bg-white px-2 text-sm text-black";

/**
 * Log a dispute a corps member reported by phone, email or in person:
 * find the purchase, then record what they said. Opened from a Transactions
 * or Risk row it arrives with `initialCode` and looks the purchase up itself.
 */
const LogDisputeModal = ({
  initialCode,
  open: openProp,
  onOpenChange,
}: {
  initialCode?: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
} = {}) => {
  const controlled = openProp !== undefined;
  const [openState, setOpenState] = useState(false);
  const open = controlled ? Boolean(openProp) : openState;
  const setOpen = (o: boolean) => (controlled ? onOpenChange?.(o) : setOpenState(o));
  const [code, setCode] = useState(initialCode ?? "");
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [payment, setPayment] = useState<PaymentLookup | null>(null);
  const [reason, setReason] = useState<DisputeReason | "">("");
  const [priority, setPriority] = useState<DisputePriority>("medium");
  const [description, setDescription] = useState("");
  const qc = useQueryClient();

  const reset = () => {
    setCode(initialCode ?? "");
    setLookupError(null);
    setPayment(null);
    setReason("");
    setPriority("medium");
    setDescription("");
  };

  const lookup = useMutation({
    mutationFn: (value: string) => lookupPaymentForDispute(value.trim()),
    onSuccess: (p) => {
      setLookupError(null);
      setPayment(p);
    },
    onError: (e) => {
      setPayment(null);
      setLookupError(getApiErrorMessage(e, "No purchase found with that code."));
    },
  });

  // Opened from a row: look the purchase up straight away.
  useEffect(() => {
    if (open && initialCode) {
      lookup.mutate(initialCode);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialCode]);

  const create = useMutation({
    mutationFn: () =>
      logDispute({ paymentId: payment!._id, reason: reason as DisputeReason, description: description.trim(), priority }),
    onSuccess: (d) => {
      toast.success(`Dispute ${d?.disputeNumber ?? ""} logged — the vendor has been notified`);
      qc.invalidateQueries({ queryKey: ["disputes"] });
      qc.invalidateQueries({ queryKey: ["dispute-stats"] });
      qc.invalidateQueries({ queryKey: ["sidebar-pending"] });
      setOpen(false);
      reset();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not log the dispute.")),
  });

  const ready = payment?.canDispute && reason && description.trim().length >= 10;

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) reset();
      }}
    >
      {!controlled && (
        <DialogTrigger render={<Button variant="outline" className="gap-1.5 bg-white text-black" />}>
          <Plus className="size-4" /> Log dispute
        </DialogTrigger>
      )}
      <DialogContent className="sm:max-w-lg text-black">
        <DialogHeader>
          <DialogTitle>Log a dispute</DialogTitle>
          <DialogDescription>
            For a complaint that came in by phone, email or in person. Find the purchase first. Tip: you can also start from the row menu on
            Transactions or Risk, which fills this in for you.
          </DialogDescription>
        </DialogHeader>

        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (code.trim().length >= 3) lookup.mutate(code);
          }}
        >
          <Input
            aria-label="Payment code or transaction reference"
            placeholder="Payment code or transaction reference"
            value={code}
            onChange={(e) => {
              setCode(e.target.value);
              setPayment(null);
              setLookupError(null);
            }}
            className="bg-white font-mono"
          />
          <Button type="submit" variant="outline" disabled={code.trim().length < 3 || lookup.isPending} className="gap-1.5">
            <Search className="size-4" /> {lookup.isPending ? "Finding…" : "Find"}
          </Button>
        </form>
        {lookupError ? (
          <p className="text-xs text-red-700 -mt-2" role="alert">
            {lookupError}
          </p>
        ) : (
          !payment && (
            <p className="text-xs text-black/50 -mt-2">
              Accepts the payment code on the receipt (8 characters, e.g. 3F9A0C1B), an order number (ORD-…), a bill code (BILL-…) or the
              reference from the Transactions page.
            </p>
          )
        )}

        {payment && (
          <div className="rounded-md border border-primary/15 p-3 text-sm space-y-0.5">
            <div className="flex justify-between gap-2">
              <span className="font-mono text-black/60">{payment.paymentCode}</span>
              <span className="font-semibold">{formatCurrency(payment.amount)}</span>
            </div>
            <p>
              {payment.corperUser?.fullName ?? "Unknown member"} → {payment.vendor?.businessName ?? (payment.source === "bill" ? "Bill provider" : "Unknown vendor")}
            </p>
            <p className="text-xs text-black/50">
              {payment.source ? `${SOURCE_LABELS[payment.source]} · ` : ""}
              {payment.paidAt ? `Paid ${formatDateString(payment.paidAt)}` : `Status: ${payment.status}`}
            </p>
            {!payment.canDispute && (
              <p className="text-xs text-red-700 pt-1">
                {payment.activeDispute
                  ? `Already disputed: ${payment.activeDispute.disputeNumber} (${STATUS_LABELS[payment.activeDispute.status]}).`
                  : "Only paid purchases, or orders still awaiting delivery confirmation, can be disputed."}
              </p>
            )}
          </div>
        )}

        {payment?.canDispute && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label htmlFor="ld-reason" className="text-xs text-black/60">Reason</label>
                <select id="ld-reason" className={selectClass} value={reason} onChange={(e) => setReason(e.target.value as DisputeReason)}>
                  <option value="">Select…</option>
                  {(Object.keys(REASON_LABELS) as DisputeReason[]).map((r) => (
                    <option key={r} value={r}>{REASON_LABELS[r]}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label htmlFor="ld-priority" className="text-xs text-black/60">Priority</label>
                <select id="ld-priority" className={selectClass} value={priority} onChange={(e) => setPriority(e.target.value as DisputePriority)}>
                  {(Object.keys(PRIORITY_LABELS) as DisputePriority[]).map((p) => (
                    <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="space-y-1">
              <label htmlFor="ld-desc" className="text-xs text-black/60">What the member said</label>
              <Textarea
                id="ld-desc"
                rows={3}
                maxLength={2000}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="At least 10 characters — the vendor will see this."
              />
            </div>
          </div>
        )}

        {payment?.canDispute && !ready && (
          <p className="text-xs text-black/60 text-right" aria-live="polite">
            {!reason
              ? "Pick a reason to continue."
              : `Describe the problem: ${Math.max(0, 10 - description.trim().length)} more character${10 - description.trim().length === 1 ? "" : "s"} needed.`}
          </p>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button disabled={!ready || create.isPending} onClick={() => create.mutate()}>
            {create.isPending ? "Logging…" : "Log dispute"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default LogDisputeModal;
