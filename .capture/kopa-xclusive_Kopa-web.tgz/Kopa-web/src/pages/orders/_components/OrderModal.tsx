import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Scale } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog";
import { Badge } from "../../../components/ui/badge";
import { Skeleton } from "../../../components/ui/skeleton";
import { cn } from "../../../lib/utils";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { ESCROW_LABELS, getOrder, ORDER_STATUS_LABELS, orderStatusVariant } from "../../../services/orders.service";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";

const ACTOR: Record<string, string> = { corper: "Member", vendor: "Vendor", admin: "Admin", system: "Automatic" };

/** Read-only order view: items, delivery, escrow and the full timeline. */
const OrderModal = ({
  orderId,
  open: openProp,
  onOpenChange,
}: {
  orderId: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const q = useQuery({ queryKey: ["admin-order", orderId], queryFn: () => getOrder(orderId), enabled: open, retry: false });
  const o = q.data;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-3xl max-h-[92vh] overflow-y-auto text-black">
        <DialogHeader>
          <DialogTitle className="pr-8 flex flex-wrap items-center gap-2">
            {o ? `Order ${o.orderNumber}` : "Order"}
            {o && (
              <Badge className="font-normal" variant={orderStatusVariant(o.status)}>
                {ORDER_STATUS_LABELS[o.status]}
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>{o ? `Placed ${formatDateString(o.createdAt)}` : "Loading…"}</DialogDescription>
        </DialogHeader>

        {q.isLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : q.isError || !o ? (
          <p className="text-sm text-red-700">{getApiErrorMessage(q.error, "Could not load this order.")}</p>
        ) : (
          <div className="space-y-5 text-sm">
            <div
              className={cn(
                "rounded-md border p-3 flex flex-wrap items-center justify-between gap-2",
                o.escrow === "held" ? "border-amber-200 bg-amber-50" : "border-primary/10 bg-secondary-foreground",
              )}
            >
              <div>
                <p className="text-xs text-black/60">Money</p>
                <p className="font-semibold">
                  {formatCurrency(o.totalAmount)} · {ESCROW_LABELS[o.escrow]}
                </p>
                {(o.refundedAmount ?? 0) > 0 && (
                  <p className="text-xs text-black/60">{formatCurrency(o.refundedAmount ?? 0)} refunded to the member</p>
                )}
              </div>
              {o.status === "disputed" && (
                <Link to={`/disputes?search=${encodeURIComponent(o.orderNumber)}`} className="text-primary text-sm flex items-center gap-1 hover:underline">
                  <Scale className="size-4" /> Open the dispute
                </Link>
              )}
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-black/50">Member</p>
                <p className="font-medium">{o.corperUser?.fullName ?? "—"}</p>
                <p className="text-xs text-black/60">{o.corperUser?.phone ?? o.corperUser?.email}</p>
              </div>
              <div>
                <p className="text-xs text-black/50">Vendor</p>
                <p className="font-medium">{o.vendor?.businessName ?? "—"}</p>
                <p className="text-xs text-black/60">{o.vendor?.businessPhone}</p>
              </div>
              {o.delivery && (
                <div>
                  <p className="text-xs text-black/50">Deliver to</p>
                  <p>{o.delivery.recipientName} · {o.delivery.phone}</p>
                  <p className="text-xs text-black/60">
                    {o.delivery.address}
                    {o.delivery.state ? `, ${o.delivery.state}` : ""}
                  </p>
                  {o.delivery.note && <p className="text-xs text-black/60">Note: {o.delivery.note}</p>}
                </div>
              )}
              {o.tracking && (o.tracking.carrier || o.tracking.trackingNumber) && (
                <div>
                  <p className="text-xs text-black/50">Shipping</p>
                  <p>
                    {o.tracking.carrier ?? "Carrier"} {o.tracking.trackingNumber ? `· ${o.tracking.trackingNumber}` : ""}
                  </p>
                  {o.tracking.estimatedDelivery && (
                    <p className="text-xs text-black/60">Expected {formatDateString(o.tracking.estimatedDelivery)}</p>
                  )}
                </div>
              )}
            </div>

            <div className="overflow-x-auto rounded-md border border-primary/10">
              <table className="w-full text-sm">
                <thead className="bg-secondary-foreground text-xs text-black/60">
                  <tr>
                    <th className="text-left font-medium p-2">Item</th>
                    <th className="text-right font-medium p-2">Qty</th>
                    <th className="text-right font-medium p-2">Price</th>
                    <th className="text-right font-medium p-2">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {o.items.map((i, idx) => (
                    <tr key={`${i.product}-${idx}`} className="border-t border-primary/10">
                      <td className="p-2">
                        {i.name}
                        {i.options?.length ? (
                          <span className="block text-xs text-black/50">{i.options.map((x) => `${x.name}: ${x.value}`).join(" · ")}</span>
                        ) : null}
                      </td>
                      <td className="p-2 text-right tabular-nums">{i.quantity}</td>
                      <td className="p-2 text-right tabular-nums">{formatCurrency(i.unitPrice)}</td>
                      <td className="p-2 text-right tabular-nums font-medium">{formatCurrency(i.lineTotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {o.history?.length ? (
              <div>
                <p className="text-xs text-black/50 mb-2">Timeline</p>
                <ol className="space-y-2 border-l border-primary/20 pl-4">
                  {o.history.map((h, idx) => (
                    <li key={idx} className="relative">
                      <span className="absolute -left-[21px] top-1.5 size-2.5 rounded-full bg-primary" aria-hidden />
                      <p className="font-medium">{ORDER_STATUS_LABELS[h.status] ?? h.status}</p>
                      <p className="text-xs text-black/50">
                        {formatDateString(h.at)} · {ACTOR[h.by] ?? h.by}
                      </p>
                      {h.note && <p className="text-xs text-black/70">{h.note}</p>}
                    </li>
                  ))}
                </ol>
              </div>
            ) : null}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default OrderModal;
