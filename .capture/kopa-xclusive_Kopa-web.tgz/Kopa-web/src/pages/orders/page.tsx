import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQueries, useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Eye, Filter, Package, Scale, User, X } from "lucide-react";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { cn } from "../../lib/utils";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import { useOpenCorperProfile } from "../../hooks/useOpenCorperProfile";
import { formatCurrency, formatTime } from "../../utils/formatter";
import { getApiErrorMessage } from "../../utils/apiError";
import {
  ESCROW_LABELS,
  getOrders,
  ORDER_STATUS_LABELS,
  orderStatusVariant,
  type AdminOrder,
  type OrderStatus,
} from "../../services/orders.service";
import OrderModal from "./_components/OrderModal";

/** Queues an admin watches; each card filters the table. */
const QUEUES: { key: OrderStatus; label: string; hint: string }[] = [
  { key: "placed", label: "Waiting for vendor", hint: "Auto-cancelled and refunded if not shipped in 7 days" },
  { key: "shipped", label: "On the way", hint: "Shipped, not yet delivered" },
  { key: "delivered", label: "Awaiting confirmation", hint: "Vendor is paid automatically after 7 days" },
  { key: "disputed", label: "Disputed", hint: "Money frozen until the dispute is decided" },
];

/**
 * Marketplace orders. Read-only for admins: the member and vendor move an
 * order along in the apps, and the money sits in escrow until delivery is
 * confirmed. Problems are handled as disputes.
 *
 * URL: ?status= ?vendorId= ?userId=
 */
const OrdersPage = () => {
  const openProfile = useOpenCorperProfile();
  const [searchParams, setSearchParams] = useSearchParams();
  const status = searchParams.get("status") ?? "";
  const vendorId = searchParams.get("vendorId") ?? "";
  const userId = searchParams.get("userId") ?? "";
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search.trim());
  const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 20 });

  const setParams = (updates: Record<string, string>) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  const query = { status, vendorId, userId, search: debouncedSearch };
  const listQuery = useQuery({
    queryKey: ["admin-orders", pagination.pageIndex, pagination.pageSize, query],
    queryFn: () => getOrders({ ...query, page: pagination.pageIndex + 1, limit: pagination.pageSize }),
    retry: false,
  });
  const counts = useQueries({
    queries: QUEUES.map((q) => ({
      queryKey: ["admin-orders", "count", q.key],
      queryFn: () => getOrders({ status: q.key, page: 1, limit: 1 }),
      retry: false,
      refetchInterval: 60_000,
    })),
  });

  const rows = listQuery.data?.orders ?? [];
  const total = listQuery.data?.meta?.total ?? 0;
  const totalPages = listQuery.data?.meta?.totalPages ?? 1;
  const scopeLabel =
    (vendorId && rows[0]?.vendor?.businessName) || (userId && rows[0]?.corperUser?.fullName) || (vendorId ? "this vendor" : userId ? "this member" : "");

  const columns: ColumnDef<AdminOrder>[] = useMemo(
    () => [
      {
        id: "order",
        header: "Order",
        cell: ({ row }) => {
          const n = row.original.items?.reduce((s, i) => s + (i.quantity ?? 1), 0) ?? 0;
          return (
            <div className="flex flex-col max-w-64">
              <span className="text-black font-mono text-sm">{row.original.orderNumber}</span>
              <span className="text-xs text-black/50 truncate">
                {n} item{n === 1 ? "" : "s"}
                {row.original.items?.[0] ? ` · ${row.original.items[0].name}` : ""}
              </span>
            </div>
          );
        },
      },
      { id: "member", header: "Member", cell: ({ row }) => <span className="text-black">{row.original.corperUser?.fullName ?? "—"}</span> },
      { id: "vendor", header: "Vendor", cell: ({ row }) => <span className="text-black">{row.original.vendor?.businessName ?? "—"}</span> },
      {
        id: "amount",
        header: "Amount",
        cell: ({ row }) => <span className="text-black font-semibold tabular-nums">{formatCurrency(row.original.totalAmount)}</span>,
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => (
          <Badge className="font-normal" variant={orderStatusVariant(row.original.status)}>
            {ORDER_STATUS_LABELS[row.original.status] ?? row.original.status}
          </Badge>
        ),
      },
      {
        id: "escrow",
        header: "Money",
        cell: ({ row }) => (
          <span className={cn("text-sm", row.original.escrow === "held" ? "text-amber-700" : "text-black/60")}>
            {ESCROW_LABELS[row.original.escrow] ?? row.original.escrow}
          </span>
        ),
      },
      { id: "placed", header: "Placed", cell: ({ row }) => <span className="text-sm text-black">{formatTime(row.original.createdAt)}</span> },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const o = row.original;
          return (
            <RowActions
              actions={[
                { key: "view", label: "View order", icon: <Eye className="size-4" />, dialog: (p) => <OrderModal orderId={o._id} {...p} /> },
                {
                  key: "dispute",
                  label: "Open the dispute",
                  icon: <Scale className="size-4" />,
                  hidden: o.status !== "disputed",
                  to: `/disputes?search=${encodeURIComponent(o.orderNumber)}`,
                },
                {
                  key: "member",
                  label: "View member profile",
                  icon: <User className="size-4" />,
                  hidden: !o.corperUser?.email,
                  onSelect: () => openProfile(o.corperUser?.email),
                },
                {
                  key: "vendor",
                  label: "This vendor's orders",
                  icon: <Filter className="size-4" />,
                  hidden: !o.vendor?._id || vendorId === o.vendor?._id,
                  onSelect: () => setParams({ vendorId: o.vendor?._id ?? "", userId: "" }),
                },
              ]}
            />
          );
        },
      },
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [vendorId, openProfile],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <Text title="Orders" type="h4" className="text-lg text-black" />
            <p className="text-sm text-black/60 mt-1">
              Marketplace orders. The member's credit is held by Kopa until they confirm delivery, then paid to the vendor.
            </p>
          </div>
          <ExportButton
            filename="orders"
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getOrders({ ...query, page, limit });
              return { rows: res?.orders ?? [], totalPages: res?.meta?.totalPages, total: res?.meta?.total };
            }}
            columns={[
              { header: "Order", value: (o: AdminOrder) => o.orderNumber },
              { header: "Member", value: (o: AdminOrder) => o.corperUser?.fullName },
              { header: "Vendor", value: (o: AdminOrder) => o.vendor?.businessName },
              { header: "Items", value: (o: AdminOrder) => o.items?.map((i) => `${i.quantity}x ${i.name}`).join("; ") },
              { header: "Amount", value: (o: AdminOrder) => o.totalAmount },
              { header: "Status", value: (o: AdminOrder) => ORDER_STATUS_LABELS[o.status] ?? o.status },
              { header: "Money", value: (o: AdminOrder) => ESCROW_LABELS[o.escrow] ?? o.escrow },
              { header: "Refunded", value: (o: AdminOrder) => o.refundedAmount ?? 0 },
              { header: "Placed", value: (o: AdminOrder) => o.createdAt },
              { header: "Delivered", value: (o: AdminOrder) => o.deliveredAt ?? "" },
            ]}
          />
        </div>
      </div>

      <div className="page-body mt-6 space-y-6 text-black">
        {listQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            {getApiErrorMessage(listQuery.error, "Could not load orders.")}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {QUEUES.map((q, i) => {
            const active = status === q.key;
            const value = counts[i].data?.meta?.total ?? 0;
            return (
              <button
                key={q.key}
                type="button"
                aria-pressed={active}
                onClick={() => setParams({ status: active ? "" : q.key })}
                className={cn(
                  "flex flex-col gap-1.5 rounded-sm border-[0.5px] border-primary/10 bg-white p-4 text-left transition-colors hover:border-primary/40",
                  value > 0 && q.key === "disputed" && "border-amber-200 bg-amber-50/60",
                  active && "ring-2 ring-primary/40",
                )}
              >
                <span className="flex items-center gap-2 text-sm text-black/70">
                  <Package className="size-4" /> {q.label}
                </span>
                <span className="text-2xl font-semibold text-black tabular-nums">{value.toLocaleString()}</span>
                <span className="text-xs text-black/50">{q.hint}</span>
              </button>
            );
          })}
        </div>

        {(vendorId || userId) && (
          <div className="flex items-center gap-2 text-sm">
            <span className="text-black/60">Showing orders for</span>
            <span className="font-medium">{scopeLabel}</span>
            <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => setParams({ vendorId: "", userId: "" })}>
              <X className="size-3.5" /> Clear
            </Button>
          </div>
        )}

        <ReusableTable
          data={rows}
          columns={columns}
          search={{
            value: search,
            onChange: (v) => {
              setSearch(v);
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            },
            placeholder: "Search order number",
          }}
          filters={[
            {
              columnKey: "status",
              title: "Status",
              options: (Object.keys(ORDER_STATUS_LABELS) as OrderStatus[]).map((s) => ({ label: ORDER_STATUS_LABELS[s], value: s })),
            },
          ]}
          filterValues={{ status }}
          onFilterChange={(_, value) => setParams({ status: value })}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={listQuery.isLoading}
          rowCount={total}
          emptyMessage={status || vendorId || userId || debouncedSearch ? "No orders match these filters." : "No orders yet."}
        />
      </div>
    </div>
  );
};

export default OrdersPage;
