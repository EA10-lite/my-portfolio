import { BvnOnRecord, MemberMandates, type BvnProfile } from "./_MemberExtras";
import { useParams, Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft,
  ExternalLink,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  AlertCircle,
  Eye,
  CreditCard,
  Building2,
  Phone,
  Mail,
  FileText,
  User,
  Award,
  RefreshCw,
  Maximize2,
  X,
  Banknote,
  Bell,
} from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Badge } from "../../../components/ui/badge";
import { Input } from "../../../components/ui/input";
import { Textarea } from "../../../components/ui/textarea";
import { getCorper } from "../../../services/corpers.service";
import { getApiErrorMessage } from "../../../utils/apiError";
import { invalidateGroup } from "../../../lib/invalidate";
import SendNotificationModal from "../../notifications/_components/SendNotificationModal";
import {
  modifyCorperLoanLimit,
  setCorperApprovalStatus,
  verifyCorperIdentity,
  type CorperVerificationResult,
} from "../../../services/admin.service";
import { formatDateString } from "../../../utils/formatter";
import { useSettings } from "../../../hooks/useSettings";

interface AdminCorperFull {
  _id: string;
  id?: string;
  fullName: string;
  stateCode: string;
  ppaNumber: string;
  bank?: {
    _id?: string;
    name?: string;
    code?: string;
  };
  kycDocumentType: string;
  kycDocumentUrl: string;
  profileImage: string;
  kycStatus: "submitted" | "verified" | "rejected" | string;
  kycStatusNote?: string;
  maxLoanAmount: number;
  availableCredit: number;
  creditStatus?: string;
  submittedAt: string;
  dateOfBirth?: string;
  bvnProfile?: BvnProfile;
  user?: {
    _id: string;
    fullName?: string;
    email?: string;
    phone?: string;
    status?: string;
    createdAt?: string;
  };
}

const matchBadgeVariant = (level?: string) => {
  if (level === "high") return "default" as const;
  if (level === "medium") return "pending" as const;
  if (level === "low") return "destructive" as const;
  return "secondary" as const;
};

const CorpMemberDetails = () => {
  const { id } = useParams();
  const qc = useQueryClient();
    const { settings } = useSettings();
  const [amount, setAmount] = useState(String(settings.defaultCreditLimit));
  const [reason, setReason] = useState("KYC verified and approved");
  const [rejectReason, setRejectReason] = useState("");
  const [showRejectBox, setShowRejectBox] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // Fetch this one profile. The old approach pulled page 1 of the list and
  // searched it, so anyone past the first 20 members rendered an empty page.
  const corperQuery = useQuery({
    queryKey: ["corper", id],
    queryFn: () => getCorper(String(id)),
    enabled: Boolean(id),
    retry: false,
  });

  const corper = corperQuery.data as AdminCorperFull | undefined;

  const userId =
    typeof corper?.user === "string" ? (corper.user as string) : (corper?.user?._id ?? "");

  // Runs only when the admin asks: each run is a paid CreditChek lookup and
  // puts decrypted BVN/NIN/account numbers on screen.
  const verifyQuery = useQuery({
    queryKey: ["corper-verify", userId],
    queryFn: () => verifyCorperIdentity(userId),
    enabled: false,
    retry: false,
  });

  const verifyData = (verifyQuery.data as { data?: CorperVerificationResult })?.data;



  const approveMut = useMutation({
    mutationFn: () =>
      setCorperApprovalStatus(userId, { action: "approve", amount: Number(amount), reason }),
    onSuccess: () => {
      toast.success(`Corps member approved with ₦${Number(amount).toLocaleString()} credit limit`);
      invalidateGroup(qc, "corpers");
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Approve failed")),
  });

  const rejectMut = useMutation({
    // The rejection reason is its own field. It used to fall back to the
    // approval note ("KYC verified and approved") when left empty.
    mutationFn: () => setCorperApprovalStatus(userId, { action: "reject", reason: rejectReason.trim() }),
    onSuccess: () => {
      toast.success("Corps member profile rejected");
      setShowRejectBox(false);
      setRejectReason("");
      invalidateGroup(qc, "corpers");
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Reject failed")),
  });

  const limitMut = useMutation({
    mutationFn: () => modifyCorperLoanLimit(String(id ?? ""), { amount: Number(amount) }),
    onSuccess: () => {
      toast.success("Credit limit updated");
      invalidateGroup(qc, "corpers");
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Update failed")),
  });

  const isApproved = corper?.kycStatus === "verified" || corper?.user?.status === "approved";
  const isRejected = corper?.kycStatus === "rejected" || corper?.user?.status === "rejected";
  // The backend refuses any decision once the account is rejected or suspended.
  const isLocked = isRejected || corper?.user?.status === "suspended";
    const amountValid = Number(amount) >= 1 && Number(amount) <= settings.maxCreditLimit;

  if (corperQuery.isLoading) {
    return (
      <div className="w-full max-w-7xl mx-auto py-16 text-center text-sm text-neutral-500">
        Loading corps member…
      </div>
    );
  }

  if (corperQuery.isError || !corper) {
    return (
      <div className="w-full max-w-7xl mx-auto py-16 text-center space-y-3">
        <p className="text-sm text-neutral-700">
          {getApiErrorMessage(corperQuery.error, "This corps member could not be found.")}
        </p>
        <Link to="/corpers" className="text-sm text-primary font-medium hover:underline">
          Back to Corps Members
        </Link>
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 pb-16 text-neutral-900">
      {/* ── Breadcrumb & Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b pb-4">
        <div>
          <Link
            to="/corpers"
            className="inline-flex items-center gap-1.5 text-xs text-primary font-medium hover:underline mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Corps Members
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-neutral-900">
              {corper?.fullName || `Corps Member ${id?.slice(0, 8)}`}
            </h1>
            {corper?.stateCode && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                {corper.stateCode}
              </span>
            )}
            {isApproved ? (
              <Badge className="bg-emerald-600 text-white font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Approved / Verified
              </Badge>
            ) : isRejected ? (
              <Badge variant="destructive" className="flex items-center gap-1">
                <XCircle className="w-3 h-3" /> Rejected
              </Badge>
            ) : (
              <Badge className="bg-amber-500 text-white font-medium flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> Pending Review
              </Badge>
            )}
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Account ID: <span className="font-mono text-neutral-700">{userId}</span>
            {corper?.submittedAt && ` • Submitted: ${formatDateString(corper.submittedAt)}`}
          </p>
        </div>

        {/* Quick Decision Actions Header */}
        <div className="flex flex-wrap items-center gap-2">
          {userId && (
            <Link
              to={`/loans?userId=${userId}&name=${encodeURIComponent(corper.fullName ?? "")}`}
              className="inline-flex items-center text-xs h-9 px-3 font-medium rounded-lg border border-neutral-200 bg-white text-neutral-800 hover:bg-neutral-50"
            >
              <Banknote className="w-4 h-4 mr-1.5" />
              Credit requests
            </Link>
          )}
          {userId && (
            <SendNotificationModal
              recipient={{
                userId,
                label: `${corper.fullName} — ${corper.user?.email ?? corper.user?.phone ?? ""}`,
              }}
              triggerButton={
                <Button variant="outline" className="text-xs h-9 px-3 font-medium bg-white">
                  <Bell className="w-4 h-4 mr-1.5" />
                  Notify
                </Button>
              }
            />
          )}
          {!isApproved && !isLocked && (
            <Button
              onClick={() => approveMut.mutate()}
              disabled={approveMut.isPending || !amountValid}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs h-9 px-4 shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4 mr-1.5" />
              {approveMut.isPending ? "Approving..." : `Approve (₦${Number(amount).toLocaleString()})`}
            </Button>
          )}
          {!isLocked && (
            <Button
              variant="destructive"
              onClick={() => setShowRejectBox(!showRejectBox)}
              className="text-xs h-9 px-3 font-medium"
            >
              <XCircle className="w-4 h-4 mr-1.5" />
              Reject
            </Button>
          )}
        </div>
      </div>

      {/* Reject Reason Accordion / Drawer if toggled */}
      {showRejectBox && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold text-red-800">Specify Rejection Reason (shown to the corps member)</span>
            <button onClick={() => setShowRejectBox(false)} className="text-red-500 hover:text-red-700">
              <X className="w-4 h-4" />
            </button>
          </div>
          <Textarea
            value={rejectReason}
            onChange={(e) => setRejectReason(e.target.value)}
            placeholder="e.g. Document image is illegible or State Code mismatch"
            className="bg-white border-red-300 text-neutral-900 text-xs"
            rows={2}
          />
          <div className="flex justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowRejectBox(false)} className="text-xs">
              Cancel
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => rejectMut.mutate()}
              disabled={rejectMut.isPending || !rejectReason.trim()}
              className="text-xs"
            >
              {rejectMut.isPending ? "Rejecting..." : "Confirm Rejection"}
            </Button>
          </div>
        </div>
      )}

      {/* ── Top Overview Grid: Metrics & Live Credit ── */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm">
          <p className="text-xs font-medium text-neutral-500 mb-1">KYC Status</p>
          <p className="text-base font-bold capitalize text-neutral-900">{corper?.kycStatus ?? "submitted"}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm">
          <p className="text-xs font-medium text-neutral-500 mb-1">Approved Credit Limit</p>
          <p className="text-base font-bold text-emerald-700">₦{(corper?.maxLoanAmount ?? 0).toLocaleString()}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm">
          <p className="text-xs font-medium text-neutral-500 mb-1">Available Spend Balance</p>
          <p className="text-base font-bold text-emerald-600">₦{(corper?.availableCredit ?? 0).toLocaleString()}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm">
          <p className="text-xs font-medium text-neutral-500 mb-1">Credit Line Status</p>
          <p className="text-base font-bold capitalize text-neutral-900">{corper?.creditStatus ?? "pending"}</p>
        </div>
      </div>

      {/* ── 2-Column Split: Submitted KYC Artifacts & Verification Dossier ── */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Submitted Visual Proof & Identification ── */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Passport Photograph Card */}
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-emerald-600" />
                <h2 className="text-sm font-semibold text-neutral-900">Passport Photograph</h2>
              </div>
              {corper?.profileImage && (
                <a
                  href={corper.profileImage}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-emerald-700 hover:underline inline-flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3" /> Full size
                </a>
              )}
            </div>

            {corper?.profileImage ? (
              <div className="flex flex-col items-center justify-center p-3 bg-neutral-50 rounded-lg border border-dashed border-neutral-200">
                <img
                  src={corper.profileImage}
                  alt={corper.fullName}
                  onClick={() => setLightboxImage(corper.profileImage)}
                  className="w-40 h-40 object-cover rounded-xl border shadow-sm cursor-pointer hover:opacity-90 transition-opacity"
                />
                <button
                  type="button"
                  onClick={() => setLightboxImage(corper.profileImage)}
                  className="mt-2.5 text-xs text-neutral-600 hover:text-neutral-900 inline-flex items-center gap-1 font-medium"
                >
                  <Maximize2 className="w-3 h-3" /> Click to enlarge
                </button>
              </div>
            ) : (
              <div className="h-32 flex items-center justify-center bg-neutral-50 rounded-lg text-neutral-400 text-xs">
                No passport photo uploaded
              </div>
            )}
          </div>

          {/* KYC Identity Document (NIN/National ID Slip) */}
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                <h2 className="text-sm font-semibold text-neutral-900">Submitted KYC Document</h2>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-neutral-100 text-neutral-700 capitalize">
                {corper?.kycDocumentType?.replace(/_/g, " ") || "Identity Document"}
              </span>
            </div>

            {corper?.kycDocumentUrl ? (
              <div className="space-y-3">
                <div
                  onClick={() => setLightboxImage(corper.kycDocumentUrl)}
                  className="p-2 bg-neutral-50 rounded-lg border border-neutral-200 flex items-center justify-center overflow-hidden cursor-pointer hover:bg-neutral-100 transition-colors"
                >
                  <img
                    src={corper.kycDocumentUrl}
                    alt="KYC Document"
                    className="max-h-64 w-full object-contain rounded"
                  />
                </div>
                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={() => setLightboxImage(corper.kycDocumentUrl)}
                    className="text-xs text-neutral-700 hover:text-black inline-flex items-center gap-1 font-medium"
                  >
                    <Eye className="w-3.5 h-3.5" /> Preview document
                  </button>
                  <a
                    href={corper.kycDocumentUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-emerald-700 hover:underline inline-flex items-center gap-1 font-semibold"
                  >
                    <ExternalLink className="w-3.5 h-3.5" /> Open in new tab
                  </a>
                </div>
              </div>
            ) : (
              <div className="h-32 flex items-center justify-center bg-neutral-50 rounded-lg text-neutral-400 text-xs">
                No document URL uploaded
              </div>
            )}
          </div>

        </div>

        {/* Right Column (7 cols): Submitted Data Details & Verification Controls ── */}
        <div className="lg:col-span-7 space-y-6">

          {/* Corps Member Profile Details Grid */}
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm space-y-4">
            <h2 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" /> Corps Member Profile Details
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Full Name</span>
                <span className="text-neutral-900 font-semibold text-sm">{corper?.fullName || "-"}</span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">NYSC State Code</span>
                <span className="text-neutral-900 font-semibold text-sm font-mono text-emerald-800">
                  {corper?.stateCode || "-"}
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Primary Assignment (PPA)</span>
                <span className="text-neutral-900 font-semibold">{corper?.ppaNumber || "-"}</span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Call-Up Letter Number</span>
                <span className="text-neutral-900 font-semibold font-mono">
                  {verifyData?.callUpLetterNumber?.decryptedValue || "Available via verify check"}
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Verified Email</span>
                <span className="text-neutral-900 font-semibold flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-neutral-400" />
                  {corper?.user?.email || "-"}
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Phone Number</span>
                <span className="text-neutral-900 font-semibold flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-neutral-400" />
                  {corper?.user?.phone || "-"}
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Bank Name</span>
                <span className="text-neutral-900 font-semibold flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-neutral-400" />
                  {corper?.bank?.name || verifyData?.bankAccount?.bankName || "-"}
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
                <span className="text-neutral-500 block mb-0.5 font-medium">Bank Account Number</span>
                <span className="text-neutral-900 font-semibold font-mono text-sm flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-neutral-400" />
                  {verifyData?.bankAccount?.submittedValue || "Decrypted via verify check"}
                </span>
              </div>
            </div>
          </div>

          <BvnOnRecord profile={corper?.bvnProfile} dateOfBirth={corper?.dateOfBirth} />
          {userId && <MemberMandates userId={userId} />}

          {/* Automated KYC Verification Cross-Check (CreditChek / Live Bank Lookup) */}
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <h2 className="text-sm font-semibold text-neutral-900">Automated Identity Cross-Check</h2>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => verifyQuery.refetch()}
                disabled={verifyQuery.isFetching}
                className="text-xs h-8 px-2.5"
              >
                <RefreshCw className={`w-3 h-3 mr-1.5 ${verifyQuery.isFetching ? "animate-spin" : ""}`} />
                {verifyQuery.isFetching ? "Checking..." : verifyData ? "Re-run check" : "Run identity check"}
              </Button>
            </div>

            {verifyData ? (
              <div className="space-y-2.5 text-xs">
                {/* BVN Check */}
                <div className="p-3 rounded-lg border border-neutral-200 bg-neutral-50/50 flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-800">BVN (Bank Verification Number)</span>
                    <Badge variant={matchBadgeVariant(verifyData.bvn.matchLevel)} className="capitalize text-[10px]">
                      {verifyData.bvn.matchLevel}
                    </Badge>
                  </div>
                  <div className="text-neutral-600 font-mono text-xs">
                    Submitted: <span className="font-semibold text-neutral-900">{verifyData.bvn.submittedValue}</span>
                    {verifyData.bvn.apiName && (
                      <span className="ml-3 text-neutral-500">
                        Name on Record: <span className="font-medium text-neutral-900">{verifyData.bvn.apiName}</span>
                      </span>
                    )}
                  </div>
                  {verifyData.bvn.error && <p className="text-neutral-500 text-[11px] italic">{verifyData.bvn.error}</p>}
                </div>

                {/* NIN Check */}
                <div className="p-3 rounded-lg border border-neutral-200 bg-neutral-50/50 flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-800">NIN (National Identification Number)</span>
                    <Badge variant={matchBadgeVariant(verifyData.nin.matchLevel)} className="capitalize text-[10px]">
                      {verifyData.nin.matchLevel}
                    </Badge>
                  </div>
                  <div className="text-neutral-600 font-mono text-xs">
                    Submitted: <span className="font-semibold text-neutral-900">{verifyData.nin.submittedValue}</span>
                    {verifyData.nin.apiName && (
                      <span className="ml-3 text-neutral-500">
                        Name on Record: <span className="font-medium text-neutral-900">{verifyData.nin.apiName}</span>
                      </span>
                    )}
                  </div>
                  {verifyData.nin.error && <p className="text-neutral-500 text-[11px] italic">{verifyData.nin.error}</p>}
                </div>

                {/* Bank Account Check */}
                <div className="p-3 rounded-lg border border-neutral-200 bg-neutral-50/50 flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-800">Bank Account & Direct Debit Eligibility</span>
                    <Badge variant={matchBadgeVariant(verifyData.bankAccount.matchLevel)} className="capitalize text-[10px]">
                      {verifyData.bankAccount.matchLevel}
                    </Badge>
                  </div>
                  <div className="text-neutral-600 font-mono text-xs">
                    Account: <span className="font-semibold text-neutral-900">{verifyData.bankAccount.submittedValue}</span>
                    <span className="ml-2 font-medium text-neutral-800">({verifyData.bankAccount.bankName ?? corper?.bank?.name})</span>
                  </div>
                  {verifyData.bankAccount.apiName && (
                    <p className="text-neutral-600 text-xs">
                      Account Name on Record: <span className="font-medium text-neutral-900">{verifyData.bankAccount.apiName}</span>
                    </p>
                  )}
                </div>

                {/* Call-Up Letter Number */}
                <div className="p-3 rounded-lg border border-neutral-200 bg-neutral-50/50">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-neutral-800">Call-Up Letter Number</span>
                    <span className="font-mono text-emerald-900 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {verifyData.callUpLetterNumber.decryptedValue}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-500">
                    Compare this number against the uploaded KYC document on the left to confirm authenticity.
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-4 bg-neutral-50 rounded-lg text-center text-xs text-neutral-500">
                {verifyQuery.isFetching
                  ? "Running automated identity verification..."
                  : verifyQuery.isError
                    ? getApiErrorMessage(verifyQuery.error, "Identity check failed.")
                    : "Not run yet. The check is a paid CreditChek lookup and reveals the decrypted BVN, NIN and account number — run it when you're ready to review."}
              </div>
            )}
          </div>

          {/* ── Admin Decision Panel ── */}
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-sm space-y-4">
            <h2 className="text-sm font-semibold text-neutral-900">Admin Approval Decision</h2>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-neutral-700 block mb-1">
                  Credit Ceiling Limit (₦) <span className="text-red-500">*</span>
                </label>
                <div className="flex items-center gap-2">
                  <Input
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    inputMode="numeric"
                    className="w-48 font-mono text-sm bg-neutral-50 border-neutral-300 text-neutral-900"
                    placeholder={String(settings.defaultCreditLimit)}
                  />
                  {/* Presets */}
                  <div className="flex flex-wrap gap-1.5">
                    {settings.creditLimitPresets.map(String).map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setAmount(preset)}
                        className={`text-xs px-2.5 py-1 rounded border font-medium transition-colors ${
                          amount === preset
                            ? "bg-emerald-600 text-white border-emerald-600"
                            : "bg-white text-neutral-700 border-neutral-200 hover:bg-neutral-50"
                        }`}
                      >
                        ₦{Number(preset).toLocaleString()}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-[11px] text-neutral-500 mt-1">
                  {Number(amount) > settings.maxCreditLimit
                    ? `Above the platform maximum of ₦${settings.maxCreditLimit.toLocaleString()} (Settings → Platform).`
                    : "This amount becomes available for this corps member immediately to disburse loans or spend on services."}
                </p>
              </div>

              <div>
                <label className="text-xs font-semibold text-neutral-700 block mb-1">
                  Decision Note / Reason
                </label>
                <Input
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="bg-neutral-50 border-neutral-300 text-neutral-900 text-xs"
                  placeholder="e.g. KYC verified and state code confirmed"
                />
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                {!isApproved && !isLocked && (
                <Button
                  onClick={() => approveMut.mutate()}
                  disabled={approveMut.isPending || !amountValid}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs h-10 px-5 shadow"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  {approveMut.isPending ? "Approving Profile..." : `Approve & Issue ₦${Number(amount).toLocaleString()}`}
                </Button>
                )}

                {isApproved && (
                  <Button
                    variant="outline"
                    onClick={() => limitMut.mutate()}
                    disabled={limitMut.isPending || !amountValid || Number(amount) === corper.maxLoanAmount}
                    className="text-xs h-10 px-4"
                  >
                    {limitMut.isPending ? "Updating..." : "Update Credit Limit"}
                  </Button>
                )}

                {!isLocked && (
                <Button
                  variant="destructive"
                  onClick={() => setShowRejectBox(!showRejectBox)}
                  className="text-xs h-10 px-4"
                >
                  <XCircle className="w-4 h-4 mr-1.5" />
                  {isApproved ? "Reject / Suspend" : "Reject Application"}
                </Button>
                )}
                {isLocked && (
                  <p className="text-xs text-neutral-500">
                    This account is {corper.user?.status ?? "rejected"}. The API does not allow further
                    decisions on it.
                  </p>
                )}
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* ── Image Lightbox Modal ── */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] bg-white rounded-xl p-2 overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-3 right-3 z-10 p-2 bg-black/60 hover:bg-black/80 rounded-full text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <img
              src={lightboxImage}
              alt="Enlarged Document"
              className="max-h-[85vh] max-w-full object-contain rounded-lg"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default CorpMemberDetails;
