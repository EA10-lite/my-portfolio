import { useQuery } from "@tanstack/react-query";
import { Landmark, UserCheck } from "lucide-react";
import { Badge } from "../../../components/ui/badge";
import { getMemberMandates } from "../../../services/mandates.service";
import { formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";

export interface BvnProfile {
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;
  gender?: string;
  maritalStatus?: string;
  residentialAddress?: string;
  lgaOfResidence?: string;
  stateOfResidence?: string;
  nationality?: string;
  fetchedAt?: string;
}

const card = "bg-white rounded-xl border border-neutral-200 p-5 shadow-sm space-y-3";
const field = "p-3 bg-neutral-50 rounded-lg border border-neutral-100";

/** What CreditChek's BVN lookup returned: used for mandates and bureau reports. */
export const BvnOnRecord = ({ profile, dateOfBirth }: { profile?: BvnProfile; dateOfBirth?: string }) => {
  const rows: [string, string | undefined][] = [
    ["Name on BVN", [profile?.firstName, profile?.lastName].filter(Boolean).join(" ") || undefined],
    ["Date of birth", profile?.dateOfBirth || (dateOfBirth ? formatDateString(dateOfBirth).split(",")[0] : undefined)],
    ["Gender", profile?.gender],
    ["Address", profile?.residentialAddress],
    ["LGA / State", [profile?.lgaOfResidence, profile?.stateOfResidence].filter(Boolean).join(", ") || undefined],
    ["Nationality", profile?.nationality],
  ];
  return (
    <div className={card}>
      <h2 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
        <UserCheck className="w-4 h-4 text-emerald-600" /> Identity on record (BVN)
      </h2>
      {!profile && !dateOfBirth ? (
        <p className="text-xs text-neutral-500">Not fetched yet. It's pulled from CreditChek when the member sets up a direct debit.</p>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {rows.map(([label, value]) => (
              <div key={label} className={field}>
                <span className="text-neutral-500 block mb-0.5 font-medium">{label}</span>
                <span className="text-neutral-900 font-semibold">{value || "-"}</span>
              </div>
            ))}
          </div>
          {profile?.fetchedAt && <p className="text-[11px] text-neutral-500">Fetched {formatDateString(profile.fetchedAt)}</p>}
        </>
      )}
    </div>
  );
};

const statusVariant = (s: string) =>
  s === "active" ? ("default" as const) : s === "pending" || s === "initiated" ? ("pending" as const) : ("secondary" as const);

/** Direct-debit mandates: the only way repayments are collected. */
export const MemberMandates = ({ userId }: { userId: string }) => {
  const q = useQuery({
    queryKey: ["member-mandates", userId],
    queryFn: () => getMemberMandates(userId),
    enabled: Boolean(userId),
    retry: false,
  });
  const mandates = q.data ?? [];
  const active = mandates.some((m) => m.status === "active");
  return (
    <div className={card}>
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-semibold text-neutral-900 flex items-center gap-2">
          <Landmark className="w-4 h-4 text-emerald-600" /> Direct-debit mandates
        </h2>
        {!q.isLoading && !q.isError && (
          <span className={`text-xs ${active ? "text-emerald-700" : "text-amber-700"}`}>
            {active ? "Repayments can be collected" : "No active mandate: repayments can't be collected"}
          </span>
        )}
      </div>
      {q.isLoading ? (
        <p className="text-xs text-neutral-500">Loading…</p>
      ) : q.isError ? (
        <p className="text-xs text-red-700">{getApiErrorMessage(q.error, "Could not load mandates.")}</p>
      ) : mandates.length === 0 ? (
        <p className="text-xs text-neutral-500">The member hasn't set up a direct debit yet.</p>
      ) : (
        <ul className="divide-y divide-neutral-100 text-xs">
          {mandates.map((m) => (
            <li key={m._id} className="py-2.5 flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-sm font-medium text-neutral-900">
                  {m.bankName ?? "Bank"} · {m.accountNumber ? `••••${String(m.accountNumber).slice(-4)}` : "—"}
                </p>
                <p className="text-neutral-500">
                  {m.accountName ?? ""} {m.provider ? `· ${m.provider === "creditchek" ? "CreditChek" : "Paystack (old)"}` : ""} · created{" "}
                  {formatDateString(m.createdAt)}
                  {m.activatedAt ? ` · active since ${formatDateString(m.activatedAt)}` : ""}
                </p>
                {m.failureReason && <p className="text-red-700">{m.failureReason}</p>}
              </div>
              <Badge className="font-normal capitalize" variant={statusVariant(m.status)}>
                {m.status}
              </Badge>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
