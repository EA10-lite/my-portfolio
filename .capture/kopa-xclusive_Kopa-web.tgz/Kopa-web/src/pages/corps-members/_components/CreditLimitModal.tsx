import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { modifyCorperLoanLimit } from "../../../services/admin.service";
import { formatCurrency } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { invalidateGroup } from "../../../lib/invalidate";
import { useSettings } from "../../../hooks/useSettings";



/**
 * PUT /admin/corpers/:corperId/loan-limit/modify.
 *
 * The backend moves available credit by the same delta as the ceiling
 * (never below zero) and emails the corps member, so the preview below
 * mirrors that arithmetic before the admin commits.
 */
const CreditLimitModal = ({
  corper,
  triggerButton,
  open: openProp,
  onOpenChange,
}: {
  corper: { _id: string; fullName?: string; maxLoanAmount?: number; availableCredit?: number };
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
    const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  // Presets and the ceiling come from Settings → Platform.
  const { settings } = useSettings();
  const currentLimit = corper.maxLoanAmount ?? 0;
  const currentAvailable = corper.availableCredit ?? 0;
  const [amount, setAmount] = useState(String(currentLimit || ""));
  const qc = useQueryClient();

  const next = Number(amount);
  const overMax = next > settings.maxCreditLimit;
  const valid = Number.isFinite(next) && next >= 1 && next !== currentLimit && !overMax;
  const nextAvailable = Math.max(0, currentAvailable + (next - currentLimit));

  const mut = useMutation({
    mutationFn: () => modifyCorperLoanLimit(corper._id, { amount: next }),
    onSuccess: () => {
      toast.success(`Credit limit set to ${formatCurrency(next)} for ${corper.fullName ?? "corps member"}`);
      invalidateGroup(qc, "corpers");
      setOpen(false);
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update the credit limit.")),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) setAmount(String(currentLimit || ""));
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit credit limit</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 text-sm">
          <p className="text-black/60">{corper.fullName}</p>

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-md border border-primary/10 p-3">
              <p className="text-xs text-black/50">Current limit</p>
              <p className="font-semibold text-black">{formatCurrency(currentLimit)}</p>
            </div>
            <div className="rounded-md border border-primary/10 p-3">
              <p className="text-xs text-black/50">Available now</p>
              <p className="font-semibold text-black">{formatCurrency(currentAvailable)}</p>
            </div>
          </div>

          <div className="space-y-2">
            <label htmlFor="credit-limit" className="text-xs font-medium text-black/70">
              New limit (₦)
            </label>
            <Input
              id="credit-limit"
              inputMode="numeric"
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/\D/g, ""))}
              className="font-mono"
            />
            <div className="flex flex-wrap gap-1.5">
              {settings.creditLimitPresets.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setAmount(String(p))}
                  className={`text-xs px-2.5 py-1 rounded border ${
                    next === p
                      ? "bg-primary text-white border-primary"
                      : "bg-white text-black/70 border-primary/15 hover:bg-primary/5"
                  }`}
                >
                  {formatCurrency(p)}
                </button>
              ))}
            </div>
          </div>

                    {overMax && (
            <p className="text-xs text-red-600">
              Above the platform maximum of {formatCurrency(settings.maxCreditLimit)} (Settings → Platform).
            </p>
          )}

          {valid && (
            <p className="text-xs text-black/60 bg-primary/5 rounded-md p-3">
              Available credit will go from {formatCurrency(currentAvailable)} to{" "}
              <strong className="text-black">{formatCurrency(nextAvailable)}</strong>. The
              corps member is emailed about the change.
            </p>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={mut.isPending}>
            Cancel
          </Button>
          <Button onClick={() => mut.mutate()} disabled={!valid || mut.isPending}>
            {mut.isPending ? "Saving…" : "Save limit"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CreditLimitModal;
