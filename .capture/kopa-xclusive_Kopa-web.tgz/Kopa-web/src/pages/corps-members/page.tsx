import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ExportButton, RowActions, ReusableTable, Text } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { formatCurrency, formatDateString } from "../../utils/formatter";
import { Badge } from "../../components/ui/badge";
import { getCorpers, getCorperStats } from "../../services/corpers.service";
import type { AdminCorper } from "../verification/page";
import {
  ArrowRightLeft,
  Banknote,
  Bell,
  Clock,
  CreditCard,
  Eye,
  Gavel,
  SlidersHorizontal,
  UserCheck,
  Users,
} from "lucide-react";
import { cn } from "../../lib/utils";
import type { CsvColumn } from "../../utils/csv";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import CorperReviewModal from "../verification/_components/CorperReviewModal";
import SendNotificationModal from "../notifications/_components/SendNotificationModal";
import CreditLimitModal from "./_components/CreditLimitModal";

const kpiStyles = {
  total: "bg-indigo-50 border-indigo-100 text-indigo-600",
  active: "bg-emerald-50 border-emerald-100 text-emerald-600",
  credit: "bg-cyan-50 border-cyan-100 text-cyan-600",
  pending: "bg-amber-50 border-amber-100 text-amber-600",
};

const statusBadgeVariant = (status: string) => {
  if (status === "approved" || status === "verified") return "default" as const;
  if (status === "rejected" || status === "suspended") return "destructive" as const;
  return "pending" as const;
};

const STATUS_OPTIONS = ["pending", "approved", "rejected", "suspended"].map((s) => ({
  label: s,
  value: s,
}));
const KYC_OPTIONS = [
  { label: "awaiting review", value: "submitted" },
  { label: "verified", value: "verified" },
  { label: "rejected", value: "rejected" },
];

const CorpsMembers = () => {
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<Record<string, string>>({});
  const debouncedSearch = useDebouncedValue(search.trim());

  // Search and filters go to the API: filtering locally would only ever see
  // the 20 rows on the current page.
  const corpersQuery = useQuery({
    queryKey: ["corpers", pagination.pageIndex, pagination.pageSize, debouncedSearch, filters],
    queryFn: () =>
      getCorpers({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        search: debouncedSearch,
        status: filters.status,
        kycStatus: filters.kycStatus,
      }),
    retry: false,
  });

  const statsQuery = useQuery({
    queryKey: ["corpers-stats"],
    queryFn: () => getCorperStats(),
    retry: false,
  });

  const raw = (
    corpersQuery.data as {
      data?: { corpers?: AdminCorper[]; meta?: { total?: number; totalPages?: number } };
    }
  )?.data;
  const rows: AdminCorper[] = raw?.corpers ?? [];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

  const stats = (
    statsQuery.data as {
      data?: {
        total?: number;
        approved?: number;
        pending?: number;
        totalMaxLoanAmount?: number;
      };
    }
  )?.data;

  const resetToFirstPage = () => setPagination((p) => ({ ...p, pageIndex: 0 }));

  const columns: ColumnDef<AdminCorper>[] = useMemo(
    () => [
      {
        accessorKey: "fullName",
        header: "Name",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black font-medium">{row.original.fullName}</span>
            <span className="text-xs text-black/50">{row.original.user?.email}</span>
          </div>
        ),
      },
      {
        id: "phone",
        header: "Phone",
        cell: ({ row }) => <span className="text-black">{row.original.user?.phone || "—"}</span>,
      },
      {
        accessorKey: "stateCode",
        header: "State Code",
        cell: ({ row }) => <span className="text-black font-mono text-xs">{row.getValue("stateCode")}</span>,
      },
      {
        id: "status",
        header: "Account",
        accessorFn: (row) => row.user?.status ?? "pending",
        cell: ({ row }) => {
          const status = row.getValue("status") as string;
          return (
            <Badge className="font-normal capitalize" variant={statusBadgeVariant(status)}>
              {status}
            </Badge>
          );
        },
      },
      {
        accessorKey: "kycStatus",
        header: "KYC",
        cell: ({ row }) => {
          const kyc = row.original.kycStatus;
          return (
            <Badge className="font-normal capitalize" variant={statusBadgeVariant(kyc)}>
              {kyc === "submitted" ? "awaiting review" : kyc}
            </Badge>
          );
        },
      },
      {
        id: "credit",
        header: "Credit (available / limit)",
        cell: ({ row }) => (
          <span className="text-black">
            <span className="font-medium">{formatCurrency(row.original.availableCredit ?? 0)}</span>
            <span className="text-black/40"> / {formatCurrency(row.original.maxLoanAmount ?? 0)}</span>
          </span>
        ),
      },
      {
        accessorKey: "submittedAt",
        header: "Submitted",
        cell: ({ row }) => (
          <span className="text-black text-sm">{formatDateString(row.getValue("submittedAt"))}</span>
        ),
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const c = row.original;
          const userStatus = c.user?.status;
          const blocked = userStatus === "rejected" || userStatus === "suspended";
          return (
            <RowActions
              actions={[
                {
                  key: "view",
                  label: "View profile",
                  icon: <Eye className="size-4" />,
                  to: `/corpers/${c._id}`,
                },
                {
                  key: "review",
                  label: "Review KYC",
                  icon: <Gavel className="size-4" />,
                  hidden: c.kycStatus !== "submitted" || blocked,
                  dialog: (p) => <CorperReviewModal corper={c} {...p} />,
                },
                {
                  key: "limit",
                  label: "Edit credit limit",
                  icon: <SlidersHorizontal className="size-4" />,
                  hidden: c.kycStatus !== "verified" || blocked,
                  dialog: (p) => <CreditLimitModal corper={c} {...p} />,
                },
                {
                  key: "loans",
                  label: "Credit requests",
                  icon: <Banknote className="size-4" />,
                  hidden: !c.user?._id,
                  to: `/loans?userId=${c.user?._id}&name=${encodeURIComponent(c.fullName ?? "")}`,
                },
                {
                  key: "transactions",
                  label: "Transactions",
                  icon: <ArrowRightLeft className="size-4" />,
                  hidden: !c.user?._id,
                  to: `/transactions?userId=${c.user?._id}&name=${encodeURIComponent(c.fullName ?? "")}`,
                },
                {
                  key: "notify",
                  label: "Send notification",
                  icon: <Bell className="size-4" />,
                  hidden: !c.user?._id,
                  dialog: (p) => (
                    <SendNotificationModal
                      recipient={{
                        userId: c.user._id,
                        label: `${c.fullName} — ${c.user.email ?? c.user.phone ?? ""}`,
                      }}
                      {...p}
                    />
                  ),
                },
              ]}
            />
          );
        },
      },
    ],
    [],
  );

  const exportColumns: CsvColumn<AdminCorper>[] = [
      { header: "Full Name", value: (r) => r.fullName },
      { header: "Email", value: (r) => r.user?.email },
      { header: "Phone", value: (r) => r.user?.phone },
      { header: "Account Status", value: (r) => r.user?.status },
      { header: "KYC Status", value: (r) => r.kycStatus },
      { header: "State Code", value: (r) => r.stateCode },
      { header: "Credit Limit", value: (r) => r.maxLoanAmount },
      { header: "Available Credit", value: (r) => r.availableCredit },
      { header: "Submitted", value: (r) => r.submittedAt },
  ];

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between">
          <Text title="Corp Members" type="h4" className="text-lg text-black" />

          <ExportButton
            filename="corps-members"
            columns={exportColumns}
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getCorpers({ page, limit, search: debouncedSearch, status: filters.status, kycStatus: filters.kycStatus });
              return { rows: res?.data?.corpers ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
            }}
          />
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {corpersQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load corps members from the server. Check your connection and try again.
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total Members"
            value={(stats?.total ?? 0).toLocaleString()}
            icon={<Users className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="Approved Members"
            value={(stats?.approved ?? 0).toLocaleString()}
            icon={<UserCheck className="size-4" />}
            className={kpiStyles.active}
          />
          <PageMetric
            label="Total Credit Limit"
            value={formatCurrency(stats?.totalMaxLoanAmount ?? 0)}
            icon={<CreditCard className="size-4" />}
            className={kpiStyles.credit}
          />
          <PageMetric
            label="Pending Review"
            value={(stats?.pending ?? 0).toLocaleString()}
            icon={<Clock className="size-4" />}
            className={kpiStyles.pending}
            onClick={() => {
              setFilters({ status: "pending" });
              resetToFirstPage();
            }}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          search={{
            value: search,
            onChange: (v) => {
              setSearch(v);
              resetToFirstPage();
            },
            placeholder: "Search name, email, phone or state code",
          }}
          filters={[
            { columnKey: "status", title: "Account status", options: STATUS_OPTIONS },
            { columnKey: "kycStatus", title: "KYC status", options: KYC_OPTIONS },
          ]}
          filterValues={filters}
          onFilterChange={(key, value) => {
            setFilters((f) => ({ ...f, [key]: value }));
            resetToFirstPage();
          }}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={corpersQuery.isLoading}
          rowCount={total}
          emptyMessage={
            debouncedSearch || filters.status || filters.kycStatus
              ? "No corps members match these filters."
              : "No corps members yet."
          }
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
  onClick,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
  onClick?: () => void;
}) => {
  const body = (
    <>
      <div className={cn("w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]", className)}>
        {icon}
      </div>
      <Text title={value} type="h2" className="text-2xl font-medium text-black" />
      <Text title={label} type="h4" className="text-black" />
    </>
  );
  const base = "border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3 text-left";
  return onClick ? (
    <button type="button" onClick={onClick} className={cn(base, "w-full hover:border-primary/30 transition-colors")}>
      {body}
    </button>
  ) : (
    <div className={base}>{body}</div>
  );
};

export default CorpsMembers;
