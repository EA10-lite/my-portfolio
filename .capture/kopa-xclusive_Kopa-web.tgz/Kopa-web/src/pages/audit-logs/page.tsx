import { useMemo, useState } from "react";
import { useQueries, useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import type { CsvColumn } from "../../utils/csv";
import DateRangeFilter from "../../components/main/DateRangeFilter";
import { useDateRange } from "../../utils/dateRange";
import { Badge } from "../../components/ui/badge";
import { formatDateString } from "../../utils/formatter";
import { getAuditLogs } from "../../services/api.service";
import { ActivitySquare, UserCog, Users, Package, Eye, History, X } from "lucide-react";
import { cn } from "../../lib/utils";
import AuditLogDetailsModal from "./_components/AuditLogDetailsModal";

export interface AdminAuditLog {
  _id: string;
  action: "CREATE" | "UPDATE" | "DELETE";
    entity: "BANK" | "USER" | "LOAN" | "CORPER" | "PRODUCT" | "WITHDRAWAL";
  entityId: string;
  performedBy?: { _id: string; fullName: string; email: string };
  previousData?: unknown;
  newData?: unknown;
  description?: string;
  createdAt: string;
}

const kpiStyles = {
  total: "bg-slate-50 border-slate-100 text-slate-700",
  users: "bg-emerald-50 border-emerald-100 text-emerald-600",
  corpers: "bg-blue-50 border-blue-100 text-blue-600",
  products: "bg-amber-50 border-amber-100 text-amber-600",
};

const actionBadgeVariant = (action: string) => {
  if (action === "CREATE") return "default" as const;
  if (action === "DELETE") return "destructive" as const;
  return "pending" as const;
};

const ACTION_FILTER_OPTIONS = [
  { label: "create", value: "CREATE" },
  { label: "update", value: "UPDATE" },
  { label: "delete", value: "DELETE" },
];

// Mirrors AuditEntity in the backend's audit.schema.ts.
const ENTITY_FILTER_OPTIONS = [
  { label: "user", value: "USER" },
  { label: "corper", value: "CORPER" },
  { label: "credit request", value: "LOAN" },
  { label: "payment", value: "PAYMENT" },
  { label: "order", value: "ORDER" },
  { label: "bill purchase", value: "BILL_PURCHASE" },
  { label: "payout", value: "WITHDRAWAL" },
  { label: "dispute", value: "DISPUTE" },
  { label: "support ticket", value: "SUPPORT" },
  { label: "product", value: "PRODUCT" },
  { label: "bank", value: "BANK" },
  { label: "settings", value: "SETTINGS" },
  { label: "broadcast", value: "NOTIFICATION" },
];

/** Local calendar day → ISO bounds the API can compare against createdAt. */
const dayStart = (d: string) => (d ? new Date(`${d}T00:00:00`).toISOString() : "");
const dayEnd = (d: string) => (d ? new Date(`${d}T23:59:59.999`).toISOString() : "");

const AuditLogsPage = () => {
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });

    const range = useDateRange();
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [performer, setPerformer] = useState<{ id: string; name: string } | null>(null);
  const resetToFirstPage = () => setPagination((p) => ({ ...p, pageIndex: 0 }));

  // Every filter here — action, entity, admin and date range — is applied by
  // the API across the full history, not just the loaded page.
  const params = {
    action: filters.action,
    entity: filters.entity,
    performedBy: performer?.id,
    startDate: dayStart(range.from),
    endDate: dayEnd(range.to),
  };
  const cleanParams = Object.fromEntries(Object.entries(params).filter(([, v]) => v));

  const logsQuery = useQuery({
    queryKey: ["admin-audit-logs", pagination.pageIndex, pagination.pageSize, cleanParams],
    queryFn: () =>
      getAuditLogs({ page: pagination.pageIndex + 1, limit: pagination.pageSize, ...cleanParams }),
    retry: false,
  });

  const countQueries = useQueries({
    queries: (["USER", "CORPER", "PRODUCT"] as const).map((entity) => ({
      queryKey: ["admin-audit-logs-count", entity],
      queryFn: () => getAuditLogs({ entity, page: 1, limit: 1 }),
      retry: false,
    })),
  });
  const countFor = (index: number) =>
    (countQueries[index].data as { meta?: { total?: number } })?.meta?.total ?? 0;

    const raw = logsQuery.data as { data?: AdminAuditLog[]; meta?: { total?: number; totalPages?: number } };
  const allRows: AdminAuditLog[] = raw?.data ?? [];

    const rows: AdminAuditLog[] = allRows;

  const exportColumns: CsvColumn<AdminAuditLog>[] = [
      { header: "Action", value: (l) => l.action },
      { header: "Entity", value: (l) => l.entity },
      { header: "Entity ID", value: (l) => l.entityId },
      { header: "Performed By", value: (l) => l.performedBy?.fullName },
      { header: "Email", value: (l) => l.performedBy?.email },
      { header: "Description", value: (l) => l.description },
      { header: "Date", value: (l) => l.createdAt },
  ];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

  const columns: ColumnDef<AdminAuditLog>[] = useMemo(
    () => [
      {
        accessorKey: "createdAt",
        header: "Timestamp",
        cell: ({ row }) => (
          <span className="text-black">{formatDateString(row.getValue("createdAt"))}</span>
        ),
      },
      {
        id: "performedBy",
        header: "Performed By",
        cell: ({ row }) => (
          <div>
            <span className="text-black font-medium block">
              {row.original.performedBy?.fullName ?? "Unknown"}
            </span>
            <span className="text-black/50 text-xs">{row.original.performedBy?.email}</span>
          </div>
        ),
      },
      {
        accessorKey: "action",
        header: "Action",
        cell: ({ row }) => {
          const action = row.getValue("action") as string;
          return (
            <Badge className="font-normal capitalize" variant={actionBadgeVariant(action)}>
              {action.toLowerCase()}
            </Badge>
          );
        },
      },
      {
        accessorKey: "entity",
        header: "Entity",
        cell: ({ row }) => (
          <span className="text-xs capitalize text-slate-700">
            {(row.getValue("entity") as string).toLowerCase()}
          </span>
        ),
      },
      {
        accessorKey: "entityId",
        header: "Entity ID",
        cell: ({ row }) => (
          <span className="text-xs text-slate-800 font-mono">{row.getValue("entityId")}</span>
        ),
      },
      {
        accessorKey: "description",
        header: "Description",
        cell: ({ row }) => (
          <span className="text-xs text-slate-700 line-clamp-1">
            {(row.getValue("description") as string) || "-"}
          </span>
        ),
      },
      {
        id: "actions",
        header: "Action",
                cell: ({ row }) => {
          const log = row.original;
          return (
            <RowActions
              actions={[
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  dialog: (p) => <AuditLogDetailsModal log={log} {...p} />,
                },
                {
                  key: "performer",
                  label: "All actions by this admin",
                  icon: <History className="size-4" />,
                  hidden: !log.performedBy?._id || performer?.id === log.performedBy._id,
                  onSelect: () => {
                    setPerformer({
                      id: String(log.performedBy?._id),
                      name: log.performedBy?.fullName ?? "this admin",
                    });
                    resetToFirstPage();
                  },
                },
              ]}
            />
          );
        },
      },
    ],
    [performer],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <Text title="Audit Logs" type="h4" className="text-lg text-black" />
          <div className="flex items-center gap-2 flex-wrap">
            <DateRangeFilter
              {...range}
              setFrom={(v) => { range.setFrom(v); resetToFirstPage(); }}
              setTo={(v) => { range.setTo(v); resetToFirstPage(); }}
            />
            <ExportButton
            filename="audit-logs"
            columns={exportColumns}
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getAuditLogs({ page, limit, ...cleanParams });
              return { rows: res?.data ?? [], totalPages: res?.meta?.totalPages, total: res?.meta?.total };
            }}
          />
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {performer && (
          <div className="flex items-center justify-between gap-3 bg-primary/5 border border-primary/15 text-sm text-black rounded-sm px-4 py-3">
            <span>
              Showing actions by <strong>{performer.name}</strong>
            </span>
            <button
              type="button"
              onClick={() => { setPerformer(null); resetToFirstPage(); }}
              className="inline-flex items-center gap-1 text-black/60 hover:text-black"
            >
              <X className="size-4" /> Everyone
            </button>
          </div>
        )}
        {logsQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load audit logs from the server. Check your connection and try again.
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total Events"
            value={total.toLocaleString()}
            icon={<ActivitySquare className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="User Events"
            value={countFor(0).toLocaleString()}
            icon={<UserCog className="size-4" />}
            className={kpiStyles.users}
          />
          <PageMetric
            label="Corper Events"
            value={countFor(1).toLocaleString()}
            icon={<Users className="size-4" />}
            className={kpiStyles.corpers}
          />
          <PageMetric
            label="Product Events"
            value={countFor(2).toLocaleString()}
            icon={<Package className="size-4" />}
            className={kpiStyles.products}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
                    searchKeys={["entityId", "description"]}
          filterValues={filters}
          onFilterChange={(key, value) => {
            setFilters((f) => ({ ...f, [key]: value }));
            resetToFirstPage();
          }}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={logsQuery.isLoading}
          rowCount={total}
          filters={[
            { columnKey: "action", title: "Action", options: ACTION_FILTER_OPTIONS },
            { columnKey: "entity", title: "Entity", options: ENTITY_FILTER_OPTIONS },
          ]}
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
}) => (
  <div className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3">
    <div
      className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]",
        className,
      )}
    >
      {icon}
    </div>
    <Text title={value} type="h2" className="text-2xl font-medium text-black" />
    <Text title={label} type="h4" className="text-black" />
  </div>
);

export default AuditLogsPage;
