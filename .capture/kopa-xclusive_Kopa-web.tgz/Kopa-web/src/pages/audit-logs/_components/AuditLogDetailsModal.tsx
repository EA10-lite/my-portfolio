import { DetailsModal, ModalFieldItem } from "../../../components";
import { formatDateString } from "../../../utils/formatter";
import type { AdminAuditLog } from "../page";

const AuditLogDetailsModal = ({
  log,
  triggerButton,
  open,
  onOpenChange,
}: {
  log: AdminAuditLog;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const previousDataJson: string | null = log.previousData
    ? JSON.stringify(log.previousData, null, 2)
    : null;
  const newDataJson: string | null = log.newData
    ? JSON.stringify(log.newData, null, 2)
    : null;

  return (
    <DetailsModal title="Audit Log Details" TriggerButton={triggerButton} open={open} onOpenChange={onOpenChange}>
      <div className="p-4 space-y-3">
        <ModalFieldItem label="Performed By" value={log.performedBy?.fullName ?? "Unknown"} />
        <ModalFieldItem label="Performed By Email" value={log.performedBy?.email ?? "-"} />
        <ModalFieldItem label="Action" value={log.action} />
        <ModalFieldItem label="Entity" value={log.entity} />
        <ModalFieldItem label="Entity ID" value={log.entityId} />
        {log.description && <ModalFieldItem label="Description" value={log.description} />}
        <ModalFieldItem label="Timestamp" value={formatDateString(log.createdAt)} />
        {previousDataJson && (
          <ModalFieldItem
            label="Previous Data"
            content={
              <pre className="text-[11px] bg-black/5 rounded-md p-2 overflow-x-auto whitespace-pre-wrap break-all">
                {previousDataJson}
              </pre>
            }
          />
        )}
        {newDataJson && (
          <ModalFieldItem
            label="New Data"
            content={
              <pre className="text-[11px] bg-black/5 rounded-md p-2 overflow-x-auto whitespace-pre-wrap break-all">
                {newDataJson}
              </pre>
            }
          />
        )}
      </div>
    </DetailsModal>
  );
};

export default AuditLogDetailsModal;
