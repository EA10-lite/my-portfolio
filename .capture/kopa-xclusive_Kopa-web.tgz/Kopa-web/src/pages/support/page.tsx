import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { toast } from "sonner";
import { CheckCircle2, Inbox, MessageSquare, UserCheck, UserX, XCircle } from "lucide-react";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import { cn } from "../../lib/utils";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import { useAdminStore } from "../../stores/adminStore";
import { formatTime } from "../../utils/formatter";
import { getApiErrorMessage } from "../../utils/apiError";
import {
  CATEGORY_LABELS,
  getTicketStats,
  getTickets,
  PRIORITY_LABELS,
  STATUS_LABELS,
  updateTicket,
  type SupportTicket,
  type TicketPriority,
  type TicketStatus,
} from "../../services/support.service";
import TicketModal from "./_components/TicketModal";

const statusVariant = (s: TicketStatus) =>
  s === "open" ? ("pending" as const) : s === "pending" ? ("new" as const) : s === "resolved" ? ("default" as const) : ("secondary" as const);
const priorityTone: Record<TicketPriority, string> = {
  high: "text-red-700",
  medium: "text-amber-700",
  low: "text-black/50",
};

/**
 * Support inbox. Tickets are opened by corps members and vendors from the
 * apps. Every filter is applied by the API. URL: ?status= ?assignedTo=me|unassigned
 */
const SupportPage = () => {
  const admin = useAdminStore((s) => s.admin);
  const qc = useQueryClient();
  const [searchParams, setSearchParams] = useSearchParams();
  const status = searchParams.get("status") ?? "";
  const assignedTo = searchParams.get("assignedTo") ?? "";
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search.trim());
  const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 20 });

  const setParams = (updates: Record<string, string>) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  const query = { status, assignedTo, priority: filters.priority, category: filters.category, requesterRole: filters.requesterRole, search: debouncedSearch };

  const ticketsQuery = useQuery({
    queryKey: ["support-tickets", pagination.pageIndex, pagination.pageSize, query],
    queryFn: () => getTickets({ ...query, page: pagination.pageIndex + 1, limit: pagination.pageSize }),
    retry: false,
  });
  const statsQuery = useQuery({ queryKey: ["support-stats"], queryFn: getTicketStats, retry: false, refetchInterval: 60_000 });

  const rows = ticketsQuery.data?.tickets ?? [];
  const total = ticketsQuery.data?.meta?.total ?? 0;
  const totalPages = ticketsQuery.data?.meta?.totalPages ?? 1;
  const stats = statsQuery.data;

  const quickUpdate = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: { status?: TicketStatus; assignedTo?: string | null } }) => updateTicket(id, patch),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["support-tickets"] });
      qc.invalidateQueries({ queryKey: ["support-stats"] });
      qc.invalidateQueries({ queryKey: ["sidebar-pending"] });
      toast.success("Ticket updated");
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update the ticket.")),
  });

  const columns: ColumnDef<SupportTicket>[] = useMemo(
    () => [
      {
        id: "ticket",
        header: "Ticket",
        cell: ({ row }) => (
          <div className="flex flex-col max-w-72">
            <span className="text-black font-medium truncate">{row.original.subject}</span>
            <span className="text-xs text-black/50 font-mono">
              {row.original.ticketNumber} · {CATEGORY_LABELS[row.original.category] ?? row.original.category}
            </span>
          </div>
        ),
      },
      {
        id: "requester",
        header: "From",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black">{row.original.requester?.fullName ?? "—"}</span>
            <span className="text-xs text-black/50">{row.original.requesterRole === "corper" ? "Corps member" : "Vendor"}</span>
          </div>
        ),
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => (
          <Badge className="font-normal" variant={statusVariant(row.original.status)}>
            {STATUS_LABELS[row.original.status]}
          </Badge>
        ),
      },
      {
        accessorKey: "priority",
        header: "Priority",
        cell: ({ row }) => (
          <span className={cn("text-sm font-medium", priorityTone[row.original.priority])}>{PRIORITY_LABELS[row.original.priority]}</span>
        ),
      },
      {
        id: "assignee",
        header: "Assigned",
        cell: ({ row }) =>
          row.original.assignedTo?.fullName ? (
            <span className="text-black text-sm">{row.original.assignedTo._id === admin?._id ? "You" : row.original.assignedTo.fullName}</span>
          ) : (
            <span className="text-black/40 text-sm">Unassigned</span>
          ),
      },
      {
        id: "activity",
        header: "Last activity",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-sm text-black">{row.original.lastMessageAt ? formatTime(row.original.lastMessageAt) : "—"}</span>
            <span className="text-xs text-black/50">{row.original.lastMessageBy === "user" ? "from requester" : row.original.lastMessageBy === "admin" ? "from Kopa" : ""}</span>
          </div>
        ),
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const t = row.original;
          const mine = t.assignedTo?._id === admin?._id;
          const done = t.status === "resolved" || t.status === "closed";
          return (
            <RowActions
              actions={[
                {
                  key: "open",
                  label: "Open conversation",
                  icon: <MessageSquare className="size-4" />,
                  dialog: (p) => <TicketModal ticketId={t._id} {...p} />,
                },
                {
                  key: "assign",
                  label: "Assign to me",
                  icon: <UserCheck className="size-4" />,
                  hidden: mine || !admin?._id,
                  onSelect: () => quickUpdate.mutate({ id: t._id, patch: { assignedTo: admin?._id } }),
                },
                {
                  key: "unassign",
                  label: "Unassign",
                  icon: <UserX className="size-4" />,
                  hidden: !t.assignedTo,
                  onSelect: () => quickUpdate.mutate({ id: t._id, patch: { assignedTo: null } }),
                },
                {
                  key: "resolve",
                  label: "Mark resolved",
                  icon: <CheckCircle2 className="size-4" />,
                  hidden: done,
                  onSelect: () => quickUpdate.mutate({ id: t._id, patch: { status: "resolved" } }),
                },
                {
                  key: "close",
                  label: "Close ticket",
                  icon: <XCircle className="size-4" />,
                  destructive: true,
                  hidden: t.status === "closed",
                  onSelect: () => quickUpdate.mutate({ id: t._id, patch: { status: "closed" } }),
                },
              ]}
            />
          );
        },
      },
    ],
    [admin?._id, quickUpdate],
  );

  const QUEUES = [
    { key: "open", label: "Open", value: stats?.open, params: { status: "open", assignedTo: "" } },
    { key: "pending", label: "Waiting on user", value: stats?.pending, params: { status: "pending", assignedTo: "" } },
    { key: "unassigned", label: "Unassigned", value: stats?.unassigned, params: { status: "", assignedTo: "unassigned" } },
    { key: "mine", label: "Assigned to me", value: stats?.mine, params: { status: "", assignedTo: "me" } },
  ];

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <Text title="Support" type="h4" className="text-lg text-black" />
            <p className="text-sm text-black/60 mt-1">Tickets from corps members and vendors in the apps.</p>
          </div>
          <ExportButton
            filename="support-tickets"
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getTickets({ ...query, page, limit });
              return { rows: res?.tickets ?? [], totalPages: res?.meta?.totalPages, total: res?.meta?.total };
            }}
            columns={[
              { header: "Ticket", value: (t: SupportTicket) => t.ticketNumber },
              { header: "Subject", value: (t: SupportTicket) => t.subject },
              { header: "Category", value: (t: SupportTicket) => CATEGORY_LABELS[t.category] ?? t.category },
              { header: "From", value: (t: SupportTicket) => t.requester?.fullName },
              { header: "Requester type", value: (t: SupportTicket) => t.requesterRole },
              { header: "Status", value: (t: SupportTicket) => STATUS_LABELS[t.status] },
              { header: "Priority", value: (t: SupportTicket) => t.priority },
              { header: "Assigned to", value: (t: SupportTicket) => t.assignedTo?.fullName },
              { header: "Opened", value: (t: SupportTicket) => t.createdAt },
              { header: "Last activity", value: (t: SupportTicket) => t.lastMessageAt },
            ]}
          />
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {ticketsQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            {getApiErrorMessage(ticketsQuery.error, "Could not load support tickets.")}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {QUEUES.map((q) => {
            const active = q.params.status === status && q.params.assignedTo === assignedTo;
            return (
              <button
                key={q.key}
                type="button"
                aria-pressed={active}
                onClick={() => setParams(active ? { status: "", assignedTo: "" } : q.params)}
                className={cn(
                  "flex flex-col gap-2 rounded-sm border-[0.5px] border-primary/10 bg-white p-4 text-left transition-colors hover:border-primary/40",
                  (q.value ?? 0) > 0 && (q.key === "open" || q.key === "unassigned") && "border-amber-200 bg-amber-50/60",
                  active && "ring-2 ring-primary/40",
                )}
              >
                <span className="flex items-center gap-2 text-sm text-black/70">
                  <Inbox className="size-4" /> {q.label}
                </span>
                <span className="text-2xl font-semibold text-black">{(q.value ?? 0).toLocaleString()}</span>
              </button>
            );
          })}
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          search={{
            value: search,
            onChange: (v) => {
              setSearch(v);
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            },
            placeholder: "Search ticket number or subject",
          }}
          filters={[
            { columnKey: "status", title: "Status", options: (Object.keys(STATUS_LABELS) as TicketStatus[]).map((s) => ({ label: STATUS_LABELS[s], value: s })) },
            { columnKey: "priority", title: "Priority", options: (Object.keys(PRIORITY_LABELS) as TicketPriority[]).map((p) => ({ label: PRIORITY_LABELS[p], value: p })) },
            { columnKey: "requesterRole", title: "From", options: [{ label: "Corps members", value: "corper" }, { label: "Vendors", value: "vendor" }] },
          ]}
          filterValues={{ status, ...filters }}
          onFilterChange={(key, value) => {
            if (key === "status") setParams({ status: value });
            else {
              setFilters((f) => ({ ...f, [key]: value }));
              setPagination((p) => ({ ...p, pageIndex: 0 }));
            }
          }}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={ticketsQuery.isLoading}
          rowCount={total}
          emptyMessage={status || assignedTo || debouncedSearch ? "No tickets match these filters." : "No support tickets yet."}
        />
      </div>
    </div>
  );
};

export default SupportPage;
