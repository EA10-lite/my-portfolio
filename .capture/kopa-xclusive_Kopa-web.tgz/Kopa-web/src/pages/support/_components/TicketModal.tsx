import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Lock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { Skeleton } from "../../../components/ui/skeleton";
import { Badge } from "../../../components/ui/badge";
import { cn } from "../../../lib/utils";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { useAdminStore, isSuperAdmin } from "../../../stores/adminStore";
import { getAdmins } from "../../../services/admin.service";
import {
  CATEGORY_LABELS,
  getTicket,
  PRIORITY_LABELS,
  replyToTicket,
  STATUS_LABELS,
  updateTicket,
  type PersonRef,
  type TicketPriority,
  type TicketStatus,
} from "../../../services/support.service";
import { formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";

const selectClass = "h-8 w-full rounded-md border border-input bg-white px-2 text-sm";

/**
 * A ticket's conversation and controls. Replies notify the requester and
 * hand the ticket to them ("Waiting on user"); internal notes are visible to
 * admins only and change nothing.
 */
const TicketModal = ({
  ticketId,
  open: openProp,
  onOpenChange,
}: {
  ticketId: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const admin = useAdminStore((s) => s.admin);
  const superAdmin = isSuperAdmin(admin?.role);
  const [body, setBody] = useState("");
  const [internal, setInternal] = useState(false);
  const qc = useQueryClient();
  const threadEnd = useRef<HTMLDivElement>(null);

  const ticketQuery = useQuery({
    queryKey: ["support-ticket", ticketId],
    queryFn: () => getTicket(ticketId),
    enabled: open,
    retry: false,
  });
  // Only super admins can list admins; everyone else can assign to themselves.
  const adminsQuery = useQuery({
    queryKey: ["admin-users", "assignees"],
    queryFn: () => getAdmins({ status: "approved", page: 1, limit: 100 }),
    enabled: open && superAdmin,
    retry: false,
  });
  const assignees: PersonRef[] = (adminsQuery.data as { data?: { data?: PersonRef[] } })?.data?.data ?? [];

  const t = ticketQuery.data;
  useEffect(() => {
    threadEnd.current?.scrollIntoView({ block: "end" });
  }, [t?.messages?.length]);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["support-ticket", ticketId] });
    qc.invalidateQueries({ queryKey: ["support-tickets"] });
    qc.invalidateQueries({ queryKey: ["support-stats"] });
    qc.invalidateQueries({ queryKey: ["sidebar-pending"] });
  };

  const replyMut = useMutation({
    mutationFn: (status?: TicketStatus) => replyToTicket(ticketId, { body: body.trim(), internal, status }),
    onSuccess: (_, status) => {
      toast.success(internal ? "Internal note added" : status === "resolved" ? "Replied and resolved" : "Reply sent");
      setBody("");
      refresh();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not send.")),
  });

  const updateMut = useMutation({
    mutationFn: (patch: { status?: TicketStatus; priority?: TicketPriority; assignedTo?: string | null }) =>
      updateTicket(ticketId, patch),
    onSuccess: () => {
      toast.success("Ticket updated");
      refresh();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update the ticket.")),
  });

  const closed = t?.status === "closed";
  const assigneeId = typeof t?.assignedTo === "object" ? t?.assignedTo?._id : undefined;
  const busy = replyMut.isPending || updateMut.isPending;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-hidden p-0 flex flex-col">
        <DialogHeader className="px-5 pt-5">
          <DialogTitle className="pr-8">{t ? t.subject : "Ticket"}</DialogTitle>
          <DialogDescription>
            {t
              ? `${t.ticketNumber} · ${CATEGORY_LABELS[t.category] ?? t.category} · opened ${formatDateString(t.createdAt)}`
              : "Loading…"}
          </DialogDescription>
        </DialogHeader>

        {ticketQuery.isLoading ? (
          <div className="p-5">
            <Skeleton className="h-64 w-full" />
          </div>
        ) : ticketQuery.isError || !t ? (
          <p className="p-5 text-sm text-red-700">{getApiErrorMessage(ticketQuery.error, "Could not load this ticket.")}</p>
        ) : (
          <div className="grid md:grid-cols-[1fr_220px] min-h-0 flex-1 border-t border-primary/10">
            {/* Thread */}
            <div className="flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto p-5 space-y-3 max-h-[46vh]">
                {(t.messages ?? []).map((m) => {
                  const author = typeof m.author === "object" ? m.author?.fullName : undefined;
                  const fromUser = m.authorType === "user";
                  return (
                    <div key={m._id} className={cn("flex", fromUser ? "justify-start" : "justify-end")}>
                      <div
                        className={cn(
                          "max-w-[85%] rounded-lg px-3 py-2 text-sm",
                          m.internal
                            ? "bg-amber-50 border border-amber-200 text-amber-950"
                            : fromUser
                              ? "bg-secondary-foreground text-black"
                              : "bg-primary/10 text-black",
                        )}
                      >
                        <p className="text-[11px] text-black/50 mb-1 flex items-center gap-1">
                          {m.internal && <Lock className="size-3" />}
                          {m.internal ? "Internal note · " : ""}
                          {author ?? (fromUser ? t.requester?.fullName ?? "Requester" : "Admin")} ·{" "}
                          {formatDateString(m.createdAt)}
                        </p>
                        <p className="whitespace-pre-wrap">{m.body}</p>
                      </div>
                    </div>
                  );
                })}
                <div ref={threadEnd} />
              </div>

              {/* Composer */}
              <div className="border-t border-primary/10 p-4 space-y-2">
                {closed && !internal && (
                  <p className="text-xs text-black/50">This ticket is closed. Reopen it to reply, or add an internal note.</p>
                )}
                <Textarea
                  aria-label={internal ? "Internal note" : "Reply"}
                  rows={3}
                  maxLength={4000}
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder={internal ? "Only admins will see this." : `Reply to ${t.requester?.fullName ?? "the requester"}…`}
                  className={internal ? "bg-amber-50/50" : ""}
                />
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="flex items-center gap-2 text-xs text-black/70">
                    <input type="checkbox" checked={internal} onChange={(e) => setInternal(e.target.checked)} />
                    Internal note
                  </label>
                  <div className="flex gap-2">
                    {!internal && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={busy || closed || !body.trim()}
                        onClick={() => replyMut.mutate("resolved")}
                      >
                        Reply & resolve
                      </Button>
                    )}
                    <Button size="sm" disabled={busy || (closed && !internal) || !body.trim()} onClick={() => replyMut.mutate(undefined)}>
                      {replyMut.isPending ? "Sending…" : internal ? "Add note" : "Send reply"}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Side panel */}
            <aside className="border-t md:border-t-0 md:border-l border-primary/10 p-4 space-y-4 text-sm bg-secondary-foreground/40">
              <div>
                <p className="text-xs text-black/50">Requester</p>
                <p className="font-medium text-black">{t.requester?.fullName ?? "—"}</p>
                <p className="text-xs text-black/60">{t.requester?.email ?? t.requester?.phone}</p>
                <Badge variant="outline" className="mt-1 font-normal capitalize">
                  {t.requesterRole === "corper" ? "Corps member" : "Vendor"}
                </Badge>
              </div>
              <div className="space-y-1">
                <label htmlFor="t-status" className="text-xs text-black/50">Status</label>
                <select
                  id="t-status"
                  className={selectClass}
                  value={t.status}
                  disabled={busy}
                  onChange={(e) => updateMut.mutate({ status: e.target.value as TicketStatus })}
                >
                  {(Object.keys(STATUS_LABELS) as TicketStatus[]).map((s) => (
                    <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label htmlFor="t-priority" className="text-xs text-black/50">Priority</label>
                <select
                  id="t-priority"
                  className={selectClass}
                  value={t.priority}
                  disabled={busy}
                  onChange={(e) => updateMut.mutate({ priority: e.target.value as TicketPriority })}
                >
                  {(Object.keys(PRIORITY_LABELS) as TicketPriority[]).map((p) => (
                    <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <label htmlFor="t-assignee" className="text-xs text-black/50">Assigned to</label>
                {superAdmin ? (
                  <select
                    id="t-assignee"
                    className={selectClass}
                    value={assigneeId ?? ""}
                    disabled={busy}
                    onChange={(e) => updateMut.mutate({ assignedTo: e.target.value || null })}
                  >
                    <option value="">Unassigned</option>
                    {assignees.map((a) => (
                      <option key={a._id} value={a._id}>{a.fullName}</option>
                    ))}
                  </select>
                ) : (
                  <div className="space-y-1.5">
                    <p className="text-black">
                      {typeof t.assignedTo === "object" && t.assignedTo ? t.assignedTo.fullName : "Unassigned"}
                    </p>
                    {assigneeId !== admin?._id ? (
                      <Button size="sm" variant="outline" className="w-full" disabled={busy} onClick={() => updateMut.mutate({ assignedTo: admin?._id })}>
                        Assign to me
                      </Button>
                    ) : (
                      <Button size="sm" variant="outline" className="w-full" disabled={busy} onClick={() => updateMut.mutate({ assignedTo: null })}>
                        Unassign me
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </aside>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default TicketModal;
