import { useQuery } from "@tanstack/react-query"
import { Pie, PieChart, Cell } from "recharts"
import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "../../../components/ui/chart"
import { EmptyState } from "../../../components/ui/empty-state"
import { Skeleton } from "../../../components/ui/skeleton"
import { getTransactionStats } from "../../../services/api.service"
import { formatCompactNaira } from "../../../utils/formatter"
import { Link } from "react-router-dom"
import { TYPE_COLORS } from "../../../lib/chartColors"
import { rangeQueryString, type PeriodRange } from "../../../hooks/usePeriodRange"

// The real ledger has no free-text "category" field (that only exists on the
// mocked corper-transactions data elsewhere) -- the closest real equivalent
// is the transaction type breakdown from GET /transactions/stats.
const TYPE_META: { key: "disbursement" | "vendorPayment" | "repayment" | "refund" | "payout" | "billPayment"; type: string; label: string; color: string }[] = [
        { key: "disbursement", type: "disbursement", label: "Disbursement", color: TYPE_COLORS.disbursement },
    { key: "vendorPayment", type: "vendor_payment", label: "Vendor Payment", color: TYPE_COLORS.vendor_payment },
    { key: "repayment", type: "repayment", label: "Repayment", color: TYPE_COLORS.repayment },
    { key: "refund", type: "refund", label: "Refund", color: TYPE_COLORS.refund },
    { key: "payout", type: "payout", label: "Vendor Payout", color: TYPE_COLORS.payout },
    { key: "billPayment", type: "bill_payment", label: "Bill Payment", color: TYPE_COLORS.bill_payment },
];

const chartConfig = Object.fromEntries(
    TYPE_META.map((t) => [t.key, { label: t.label, color: t.color }]),
) satisfies ChartConfig;

/**
 * Money moved per transaction type within the dashboard's selected period.
 * Each legend entry links into Transactions filtered by that type and period.
 */
const CategoryDistributionChart = ({ range }: { range: PeriodRange }) => {
    const params = { startDate: range.startDate, endDate: range.endDate };
    const statsQuery = useQuery({
        queryKey: ["admin-transactions-stats", params],
        queryFn: () => getTransactionStats(params),
        retry: false,
    });

    const stats = (
        statsQuery.data as {
            data?: Record<string, { amount?: number } | number | undefined>;
        }
    )?.data;

    const chartData = TYPE_META.map((t) => {
        const bucket = stats?.[t.key] as { amount?: number } | undefined;
        return {
                        category: t.key,
            type: t.type,
            label: t.label,
            value: bucket?.amount ?? 0,
            fill: t.color,
        };
    }).filter((d) => d.value > 0);

    const hasData = chartData.length > 0;

    return (
        <Card className="min-w-0 border-[0.5px] border-primary/8 bg-white p-4 rounded-sm shadow-none">
            <CardHeader className="items-center pb-0 px-0">
                <CardTitle className="text-black">
                    Money moved by type
                    <span className="block text-xs font-normal text-black/50 mt-0.5">
                        {range.label}
                    </span>
                </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 pb-4">
                {statsQuery.isLoading ? (
                    <Skeleton className="h-[200px] w-full rounded-md" />
                ) : hasData ? (
                    <ChartContainer config={chartConfig} className="mx-auto aspect-square w-full max-w-[240px] min-h-[200px]">
                        <PieChart>
              <ChartTooltip content={<ChartTooltipContent hideLabel nameKey="label" />} />
                            <Pie data={chartData} dataKey="value" nameKey="label" innerRadius={50} stroke="#ffffff" strokeWidth={2}>
                                {chartData.map((entry) => (
                                    <Cell key={entry.category} fill={entry.fill} />
                                ))}
                            </Pie>
                        </PieChart>
                    </ChartContainer>
                ) : (
                    <EmptyState
                        title="No Data Available"
                        description={range.from || range.to ? "No money moved in this period." : "No money movements have been recorded yet."}
                        className="min-h-[200px] border-none"
                    />
                )}
            </CardContent>
            <CardFooter className="max-w-full mx-auto text-xs text-black flex items-center gap-4 justify-center flex-wrap pb-6">
                {chartData.map((d) => (
                    <Link
                        key={d.category}
                        to={`/transactions?type=${d.type}${rangeQueryString(range)}`}
                        className="flex items-center gap-2 leading-none text-sm hover:underline"
                    >
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: d.fill }} />
                        <span>{d.label}</span>
                        <span className="font-semibold">{formatCompactNaira(d.value)}</span>
                    </Link>
                ))}
            </CardFooter>
        </Card>
    )
}

export default CategoryDistributionChart;
