import { useQuery } from "@tanstack/react-query"
import { Pie, PieChart, Cell } from "recharts"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from "../../../components/ui/chart"
import { EmptyState } from "../../../components/ui/empty-state"
import { Skeleton } from "../../../components/ui/skeleton"
import { getCorperStats } from "../../../services/corpers.service"
import { STATUS_COLORS } from "../../../lib/chartColors"

const STATUS_META: { key: "pending" | "approved" | "rejected" | "suspended"; label: string; color: string }[] = [
    // Statuses use the reserved status colours, always beside a text label.
  { key: "approved", label: "Approved", color: STATUS_COLORS.good },
  { key: "pending", label: "Pending", color: STATUS_COLORS.warning },
  { key: "rejected", label: "Rejected", color: STATUS_COLORS.critical },
  { key: "suspended", label: "Suspended", color: STATUS_COLORS.neutral },
];

const chartConfig = Object.fromEntries(
  STATUS_META.map((s) => [s.key, { label: s.label, color: s.color }]),
) satisfies ChartConfig;

const MemberStatusChart = () => {
  const statsQuery = useQuery({
    queryKey: ["corpers-stats"],
    queryFn: () => getCorperStats(),
    retry: false,
  });

  const stats = (statsQuery.data as { data?: Record<string, number> })?.data;

  const chartData = STATUS_META.map((s) => ({
    status: s.key,
    label: s.label,
    value: stats?.[s.key] ?? 0,
    fill: s.color,
  })).filter((d) => d.value > 0);

  const hasData = chartData.length > 0;

  return (
    <Card className="border-[0.5px] border-primary/8 bg-white p-4 rounded-sm shadow-none">
      <CardHeader className="items-center pb-0 px-0">
        <CardTitle className="text-black">Corps members by status</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 pb-4">
        {statsQuery.isLoading ? (
          <Skeleton className="h-[200px] w-full rounded-md" />
        ) : hasData ? (
          <ChartContainer config={chartConfig} className="mx-auto min-h-[200px]">
            <PieChart>
              <ChartTooltip content={<ChartTooltipContent hideLabel nameKey="label" />} />
              <Pie data={chartData} dataKey="value" nameKey="label" innerRadius={50} stroke="#ffffff" strokeWidth={2}>
                {chartData.map((entry) => (
                  <Cell key={entry.status} fill={entry.fill} />
                ))}
              </Pie>
            </PieChart>
          </ChartContainer>
        ) : (
          <EmptyState
            title="No Data Available"
            description="No corps members have been onboarded yet."
            className="min-h-[200px] border-none"
          />
        )}
      </CardContent>
      <CardFooter className="flex items-center justify-center gap-6 text-base text-black pb-6 flex-wrap">
        {chartData.map((d) => (
          <div key={d.status} className="flex items-center gap-2 leading-none text-sm">
            <div className="w-2.5 h-2.5 rounded-full" style={{ background: d.fill }} />
            <span>{d.label}</span>
            <span className="font-semibold">{d.value.toLocaleString()}</span>
          </div>
        ))}
      </CardFooter>
    </Card>
  )
}

export default MemberStatusChart;
