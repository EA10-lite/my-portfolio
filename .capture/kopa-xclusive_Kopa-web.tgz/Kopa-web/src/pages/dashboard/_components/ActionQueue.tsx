import { Link } from "react-router-dom";
import { useQueries, useQuery } from "@tanstack/react-query";
import { ArrowRight, Banknote, CheckCircle2, ShieldQuestion, TriangleAlert, Wallet } from "lucide-react";
import { Skeleton } from "../../../components/ui/skeleton";
import { cn } from "../../../lib/utils";
import { getCorpers } from "../../../services/corpers.service";
import { getVendorsService } from "../../../services/vendors.service";
import { getLoans } from "../../../services/loans.service";
import { getWithdrawals } from "../../../services/withdrawals.service";
import { getRiskSummary } from "../../../services/api.service";
import { formatCompactNaira } from "../../../utils/formatter";

const total = (res: unknown) =>
    (res as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0;

/**
 * "Needs action" row — the four queues an admin works through. Each card is a
 * link into that queue, already filtered, so the dashboard is a starting
 * point rather than a read-only summary.
 */
const ActionQueue = () => {
    const [corperKyc, vendorKyb] = useQueries({
        queries: [
            {
                queryKey: ["admin-corpers-count", "submitted"],
                queryFn: () => getCorpers({ kycStatus: "submitted", page: 1, limit: 1 }),
                retry: false,
                refetchInterval: 60_000,
            },
            {
                queryKey: ["admin-vendors-count", "submitted"],
                queryFn: () => getVendorsService({ kybStatus: "submitted", page: 1, limit: 1 }),
                retry: false,
                refetchInterval: 60_000,
            },
        ],
    });

    const loansQuery = useQuery({
        queryKey: ["admin-loans-count", "pending", ""],
        queryFn: () => getLoans({ status: "pending", page: 1, limit: 1 }),
        retry: false,
        refetchInterval: 60_000,
    });

    // Up to 100 pending payouts, so the card can show the naira total waiting.
    const payoutsQuery = useQuery({
        queryKey: ["admin-withdrawals", "dashboard-pending"],
        queryFn: () => getWithdrawals({ status: "pending", page: 1, limit: 100 }),
        retry: false,
        refetchInterval: 60_000,
    });

    const riskQuery = useQuery({
        queryKey: ["admin-risk-summary"],
        queryFn: () => getRiskSummary(),
        retry: false,
        refetchInterval: 60_000,
    });

    const kycCorpers = total(corperKyc.data);
    const kybVendors = total(vendorKyb.data);
    const pendingLoans = loansQuery.data?.meta?.total ?? 0;
    const payouts = payoutsQuery.data?.withdrawals ?? [];
    const payoutCount = payoutsQuery.data?.meta?.total ?? payouts.length;
    const payoutSum = payouts.reduce((s, w) => s + (w.amount ?? 0), 0);
    const risk = (riskQuery.data as {
        data?: { overdue?: { count: number; amount: number }; defaulted?: { count: number; amount: number } };
    })?.data;
    const overdue = risk?.overdue ?? { count: 0, amount: 0 };
    const failed = risk?.defaulted ?? { count: 0, amount: 0 };

    return (
        <section aria-labelledby="needs-action" className="space-y-3">
            <h2 id="needs-action" className="text-sm font-medium text-black/60">
                Needs action
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <QueueCard
                    to={kycCorpers === 0 && kybVendors > 0 ? "/verification?entity=vendor" : "/verification"}
                    icon={<ShieldQuestion className="size-4" />}
                    label="KYC reviews"
                    count={kycCorpers + kybVendors}
                    detail={`${kycCorpers} corps member${kycCorpers === 1 ? "" : "s"} · ${kybVendors} vendor${kybVendors === 1 ? "" : "s"}`}
                    loading={corperKyc.isLoading || vendorKyb.isLoading}
                    error={corperKyc.isError && vendorKyb.isError}
                />
                <QueueCard
                    to="/loans?status=pending"
                    icon={<Banknote className="size-4" />}
                    label="Credit requests"
                    count={pendingLoans}
                    detail="awaiting approval"
                    loading={loansQuery.isLoading}
                    error={loansQuery.isError}
                />
                <QueueCard
                    to={payoutCount > 0 ? "/withdrawals?status=pending" : "/withdrawals"}
                    icon={<Wallet className="size-4" />}
                    label="Vendor payouts"
                    count={payoutCount}
                    detail={
                        payoutCount > payouts.length
                            ? `${formatCompactNaira(payoutSum)}+ waiting`
                            : `${formatCompactNaira(payoutSum)} waiting`
                    }
                    loading={payoutsQuery.isLoading}
                    error={payoutsQuery.isError}
                />
                <QueueCard
                    to="/risk?riskStatus=overdue"
                    icon={<TriangleAlert className="size-4" />}
                    label="Collections"
                    count={overdue.count + failed.count}
                    detail={`${formatCompactNaira(overdue.amount + failed.amount)} · ${overdue.count} overdue, ${failed.count} failed`}
                    loading={riskQuery.isLoading}
                    error={riskQuery.isError}
                    danger
                />
            </div>
        </section>
    );
};

const QueueCard = ({
    to,
    icon,
    label,
    count,
    detail,
    loading,
    error,
    danger,
}: {
    to: string;
    icon: React.ReactNode;
    label: string;
    count: number;
    detail: string;
    loading?: boolean;
    error?: boolean;
    danger?: boolean;
}) => {
    if (loading) return <Skeleton className="h-[118px] w-full rounded-sm" />;

    const clear = !error && count === 0;
    const tone = error
        ? "border-primary/10 bg-white"
        : clear
            ? "border-primary/10 bg-white"
            : danger
                ? "border-red-200 bg-red-50/60"
                : "border-amber-200 bg-amber-50/60";

    return (
        <Link
            to={to}
            className={cn(
                "group flex flex-col justify-between gap-3 rounded-sm border-[0.5px] p-4 transition-colors hover:border-primary/40",
                tone,
            )}
        >
            <div className="flex items-center justify-between text-sm text-black/70">
                <span className="flex items-center gap-2">
                    {icon}
                    {label}
                </span>
                <ArrowRight className="size-4 text-black/30 transition-transform group-hover:translate-x-0.5 group-hover:text-primary" />
            </div>
            {error ? (
                <p className="text-sm text-black/50">Couldn't load — open to check</p>
            ) : clear ? (
                <p className="flex items-center gap-2 text-sm font-medium text-primary">
                    <CheckCircle2 className="size-4" /> All clear
                </p>
            ) : (
                <div>
                    <p className="text-3xl font-semibold text-black leading-none">{count.toLocaleString()}</p>
                    <p className="mt-1.5 text-xs text-black/60">{detail}</p>
                </div>
            )}
        </Link>
    );
};

export default ActionQueue;
