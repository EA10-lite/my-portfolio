import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ChevronRight, Store, User } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/card";
import { EmptyState } from "../../../components/ui/empty-state";
import { Skeleton } from "../../../components/ui/skeleton";
import { cn } from "../../../lib/utils";
import { getCorpers } from "../../../services/corpers.service";
import { getVendorsService } from "../../../services/vendors.service";
import type { AdminCorper, AdminVendor } from "../../verification/page";
import CorperReviewModal from "../../verification/_components/CorperReviewModal";
import VendorReviewModal from "../../verification/_components/VendorReviewModal";

type Item =
    | { kind: "corper"; submittedAt: string; corper: AdminCorper }
    | { kind: "vendor"; submittedAt: string; vendor: AdminVendor };

const PAGE = 100;

/**
 * The API lists newest first, so the oldest submissions live on the last
 * page(s). Read the total, then fetch the last two pages and sort ascending.
 */
async function fetchOldest<T>(
    fetchPage: (page: number, limit: number) => Promise<unknown>,
    pick: (res: unknown) => T[],
): Promise<T[]> {
    const first = await fetchPage(1, 1);
    const total = (first as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0;
    if (total === 0) return [];
    const last = Math.ceil(total / PAGE);
    const pages = [last, last - 1].filter((p) => p >= 1);
    const results = await Promise.all(pages.map((p) => fetchPage(p, PAGE)));
    return results.flatMap(pick);
}

const daysWaiting = (iso: string) =>
    Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000));

const waitingLabel = (days: number) =>
    days === 0 ? "Submitted today" : `Waiting ${days} day${days === 1 ? "" : "s"}`;

/**
 * Replaces "Recent Verifications", which listed the newest sign-ups whatever
 * their status. This lists the submissions that have waited longest for a
 * KYC/KYB decision, with the review opening in place.
 */
const OldestPendingReviews = () => {
    const query = useQuery({
        queryKey: ["dashboard-oldest-reviews"],
        queryFn: async (): Promise<Item[]> => {
            const [corpers, vendors] = await Promise.all([
                fetchOldest(
                    (page, limit) => getCorpers({ kycStatus: "submitted", page, limit }),
                    (res) => ((res as { data?: { corpers?: AdminCorper[] } })?.data?.corpers ?? []),
                ),
                fetchOldest(
                    (page, limit) => getVendorsService({ kybStatus: "submitted", page, limit }),
                    (res) => ((res as { data?: { vendors?: AdminVendor[] } })?.data?.vendors ?? []),
                ),
            ]);
            const items: Item[] = [
                ...corpers.map((c) => ({ kind: "corper" as const, submittedAt: c.submittedAt, corper: c })),
                ...vendors.map((v) => ({ kind: "vendor" as const, submittedAt: v.submittedAt, vendor: v })),
            ];
            return items
                .sort((a, b) => new Date(a.submittedAt).getTime() - new Date(b.submittedAt).getTime())
                .slice(0, 5);
        },
        retry: false,
        refetchInterval: 60_000,
    });

    const items = query.data ?? [];

    return (
        <Card className="border-[0.5px] border-primary/8 bg-white p-0 rounded-sm gap-0 shadow-none">
            <CardHeader className="p-4 mb-0 flex flex-row items-center justify-between border-b-[0.5px] border-primary/8">
                <CardTitle className="text-black">Oldest pending reviews</CardTitle>
                <Link to="/verification" className="text-primary text-sm flex items-center gap-1 hover:underline">
                    <span>Review queue</span>
                    <ChevronRight className="size-4" />
                </Link>
            </CardHeader>

            <CardContent className="p-0 text-black">
                {query.isLoading ? (
                    <div className="p-4 space-y-3">
                        {[1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-full rounded-md" />)}
                    </div>
                ) : query.isError ? (
                    <p className="p-4 text-sm text-red-700">Could not load the review queue.</p>
                ) : items.length === 0 ? (
                    <EmptyState
                        title="Nothing waiting"
                        description="Every KYC and KYB submission has a decision."
                        className="min-h-[200px] border-none"
                    />
                ) : (
                    items.map((item) => {
                        const days = daysWaiting(item.submittedAt);
                        const name = item.kind === "corper" ? item.corper.fullName : item.vendor.businessName;
                        const sub =
                            item.kind === "corper"
                                ? `Corps member · ${item.corper.stateCode ?? ""}`
                                : `Vendor · ${item.vendor.vendorCategory ?? ""}`;
                        const reviewButton = (
                            <button
                                type="button"
                                className="text-xs font-medium text-primary border border-primary/20 rounded-md px-2.5 py-1 hover:bg-primary/5"
                            >
                                Review
                            </button>
                        );
                        return (
                            <div
                                key={`${item.kind}-${item.kind === "corper" ? item.corper._id : item.vendor._id}`}
                                className="px-4 py-3 border-b-[0.5px] border-primary/8 last:border-none flex items-center gap-3"
                            >
                                <div className="w-9 h-9 rounded-full bg-primary/5 text-primary flex items-center justify-center shrink-0">
                                    {item.kind === "corper" ? <User className="size-4" /> : <Store className="size-4" />}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium truncate">{name}</p>
                                    <p className="text-xs text-black/50 truncate capitalize">{sub}</p>
                                </div>
                                <span
                                    className={cn(
                                        "text-xs whitespace-nowrap",
                                        days >= 5 ? "text-red-600 font-medium" : days >= 2 ? "text-amber-600" : "text-black/50",
                                    )}
                                >
                                    {waitingLabel(days)}
                                </span>
                                {item.kind === "corper" ? (
                                    <CorperReviewModal corper={item.corper} triggerButton={reviewButton} />
                                ) : (
                                    <VendorReviewModal vendor={item.vendor} triggerButton={reviewButton} />
                                )}
                            </div>
                        );
                    })
                )}
            </CardContent>
        </Card>
    );
};

export default OldestPendingReviews;
