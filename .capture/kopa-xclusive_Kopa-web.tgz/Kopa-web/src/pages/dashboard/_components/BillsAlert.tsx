import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";
import { getBillReviews, getProviderBalance } from "../../../services/bills.service";
import { formatCurrency } from "../../../utils/formatter";

const LOW_BALANCE = 50_000;

/**
 * Shown only when bills need attention: the VTpass wallet is running low
 * (purchases start failing) or a delivered purchase was reversed.
 */
const BillsAlert = () => {
  const balance = useQuery({ queryKey: ["vtpass-balance"], queryFn: getProviderBalance, retry: false, refetchInterval: 5 * 60_000 });
  const reviews = useQuery({
    queryKey: ["bill-reviews", "count"],
    queryFn: () => getBillReviews({ page: 1, limit: 1 }),
    retry: false,
    refetchInterval: 5 * 60_000,
  });
  const amount = balance.data?.balance;
  const low = typeof amount === "number" && amount < LOW_BALANCE;
  const pending = reviews.data?.meta?.total ?? 0;
  if (!low && pending === 0) return null;

  return (
    <Link
      to="/bills"
      className="flex items-start gap-3 rounded-sm border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900 hover:border-amber-300"
    >
      <AlertTriangle className="size-4 mt-0.5 shrink-0" />
      <span>
        {low && (
          <>
            The VTpass wallet is down to <b>{formatCurrency(amount ?? 0)}</b>. Top it up, or airtime and bill purchases will start failing.{" "}
          </>
        )}
        {pending > 0 && (
          <>
            {pending} reversed bill purchase{pending === 1 ? " needs" : "s need"} a decision.
          </>
        )}
      </span>
    </Link>
  );
};

export default BillsAlert;
