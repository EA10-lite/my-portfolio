import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "../../../components/ui/skeleton";
import { getTransactionStats } from "../../../services/api.service";
import { formatCurrency } from "../../../utils/formatter";
import { rangeQueryString, type PeriodRange } from "../../../hooks/usePeriodRange";

interface Bucket { count?: number; amount?: number }
interface TxnStats {
    totalCount?: number;
    totalAmount?: number;
    disbursement?: Bucket;
    vendorPayment?: Bucket;
    repayment?: Bucket;
    payout?: Bucket;
}

const plural = (n: number, word: string) => `${n.toLocaleString()} ${word}${n === 1 ? "" : "s"}`;

/**
 * Ledger totals for the dashboard's selected period (GET /transactions/stats
 * with startDate/endDate). Shares its cache key with the type chart and with
 * Reports, so switching periods fetches once. Each card opens Transactions
 * filtered to the same type and dates.
 */
const PeriodSummary = ({ range }: { range: PeriodRange }) => {
    const params = { startDate: range.startDate, endDate: range.endDate };
    const query = useQuery({
        queryKey: ["admin-transactions-stats", params],
        queryFn: () => getTransactionStats(params),
        retry: false,
    });
    const s = (query.data as { data?: TxnStats })?.data;
    const q = rangeQueryString(range);

    const cards = [
        { label: "Money moved", bucket: { count: s?.totalCount, amount: s?.totalAmount }, unit: "transaction", to: `/transactions?${q.slice(1)}` },
        { label: "Credit issued", bucket: s?.disbursement, unit: "disbursement", to: `/transactions?type=disbursement${q}` },
        { label: "Repaid", bucket: s?.repayment, unit: "debit", to: `/transactions?type=repayment${q}` },
        { label: "Paid out to vendors", bucket: s?.payout, unit: "payout", to: `/transactions?type=payout${q}` },
    ];

    if (query.isError) {
        return (
            <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
                Could not load totals for this period.
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {cards.map((c) =>
                query.isLoading ? (
                    <Skeleton key={c.label} className="h-[96px] w-full rounded-sm" />
                ) : (
                    <Link
                        key={c.label}
                        to={c.to}
                        className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-1 hover:border-primary/30 transition-colors"
                    >
                        <p className="text-sm text-black/60">{c.label}</p>
                        <p className="text-2xl font-semibold text-black">{formatCurrency(c.bucket?.amount ?? 0)}</p>
                        <p className="text-xs text-black/40">{plural(c.bucket?.count ?? 0, c.unit)}</p>
                    </Link>
                ),
            )}
        </div>
    );
};

export default PeriodSummary;
