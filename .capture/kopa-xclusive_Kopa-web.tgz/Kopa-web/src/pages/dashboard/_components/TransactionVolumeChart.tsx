import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "../../../components/ui/chart"
import { EmptyState } from "../../../components/ui/empty-state"
import { Skeleton } from "../../../components/ui/skeleton"
import { cn } from "../../../lib/utils"
import { getTransactionMonthlyVolume } from "../../../services/api.service"
import { formatCompactNaira, formatCurrency } from "../../../utils/formatter"

const chartConfig = {
  amount: { label: "Volume", color: "#008751" },
  count: { label: "Transactions", color: "#008751" },
} satisfies ChartConfig

interface MonthlyVolumeRow {
  month: string;
  amount: number;
  count: number;
}

type Metric = "amount" | "count";

/**
 * Monthly ledger volume (GET /transactions/monthly-volume — the last 6
 * months, zero-filled). Bars rather than a smoothed line: each month is a
 * discrete total, and a monotone curve implied values between them.
 */
const TransactionVolumeChart = () => {
    const [metric, setMetric] = useState<Metric>("amount");
  const [months, setMonths] = useState<6 | 12>(6);
  const volumeQuery = useQuery({
    queryKey: ["admin-transactions-monthly-volume", months],
    queryFn: () => getTransactionMonthlyVolume(months),
    retry: false,
  });

  const rows: MonthlyVolumeRow[] = (volumeQuery.data as { data?: MonthlyVolumeRow[] })?.data ?? [];
  const hasData = rows.some((r) => r.amount > 0 || r.count > 0);
  const current = rows[rows.length - 1];
  const previous = rows[rows.length - 2];
  const change =
    current && previous && previous[metric] > 0
      ? Math.round(((current[metric] - previous[metric]) / previous[metric]) * 100)
      : null;

  return (
    <Card className="border-[0.5px] border-primary/8 bg-white p-4 rounded-sm text-black gap-4 shadow-none">
      <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-3 space-y-0 p-0">
        <div>
          <CardTitle className="text-base font-medium">Transaction volume · last {months} months</CardTitle>
          {current && (
            <p className="text-sm text-black/60 mt-1">
              This month:{" "}
              <strong className="text-black">
                {metric === "amount" ? formatCurrency(current.amount) : current.count.toLocaleString()}
              </strong>
              {change !== null && (
                <span className={cn("ml-2", change >= 0 ? "text-primary" : "text-red-600")}>
                  {change >= 0 ? "▲" : "▼"} {Math.abs(change)}% vs last month
                </span>
              )}
            </p>
          )}
        </div>
                <div className="flex flex-wrap items-center gap-2">
        <div role="group" aria-label="Months shown" className="flex rounded-md border border-primary/15 p-0.5 text-xs">
          {([6, 12] as const).map((m) => (
            <button
              key={m}
              type="button"
              aria-pressed={months === m}
              onClick={() => setMonths(m)}
              className={cn(
                "px-3 py-1 rounded-[5px] transition-colors",
                months === m ? "bg-primary text-white" : "text-black/60 hover:text-black",
              )}
            >
              {m}M
            </button>
          ))}
        </div>
        <div role="group" aria-label="Chart metric" className="flex rounded-md border border-primary/15 p-0.5 text-xs">
          {(["amount", "count"] as const).map((m) => (
            <button
              key={m}
              type="button"
              aria-pressed={metric === m}
              onClick={() => setMetric(m)}
              className={cn(
                "px-3 py-1 rounded-[5px] transition-colors",
                metric === m ? "bg-primary text-white" : "text-black/60 hover:text-black",
              )}
            >
                            {m === "amount" ? "Naira volume" : "Count"}
            </button>
          ))}
        </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {volumeQuery.isLoading ? (
          <Skeleton className="h-[240px] w-full rounded-md" />
        ) : volumeQuery.isError ? (
          <p className="text-sm text-red-700 py-8 text-center">Could not load transaction volume.</p>
        ) : hasData ? (
          <ChartContainer config={chartConfig} className="h-[240px] w-full">
            <BarChart data={rows} margin={{ left: 4, right: 4, top: 8 }}>
              <CartesianGrid vertical={false} />
              <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
              <YAxis
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                width={56}
                allowDecimals={false}
                tickFormatter={(v: number) => (metric === "amount" ? formatCompactNaira(v) : v.toLocaleString())}
              />
              <ChartTooltip
                cursor={{ fill: "rgba(0,135,81,0.06)" }}
                content={
                  <ChartTooltipContent
                    formatter={(value) =>
                      metric === "amount"
                        ? formatCurrency(Number(value))
                        : `${Number(value).toLocaleString()} transactions`
                    }
                  />
                }
              />
              <Bar dataKey={metric} fill="#008751" radius={[4, 4, 0, 0]} maxBarSize={48} />
            </BarChart>
          </ChartContainer>
        ) : (
          <EmptyState
            title="No transactions yet"
            description="Volume appears here once money starts moving on the platform."
            className="min-h-[200px] border-none"
          />
        )}
      </CardContent>
    </Card>
  )
}

export default TransactionVolumeChart;
