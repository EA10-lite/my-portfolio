import { useState } from "react"
import { Link } from "react-router-dom"
import { ArrowDownToLine, ArrowRightLeft, ChevronRight, RefreshCw, Zap } from "lucide-react"
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card"
import { EmptyState } from "../../../components/ui/empty-state"
import { Skeleton } from "../../../components/ui/skeleton"
import { useQuery } from "@tanstack/react-query"
import { getTransactions } from "../../../services/api.service"
import { formatCurrency, formatTime } from "../../../utils/formatter"
import { type AdminTransaction } from "../../transactions/page"
import { TYPE_LABELS } from "../../../lib/transactionTypes"
import TransactionDetailsModal from "../../transactions/_components/TransactionDetailsModal"
import { rangeQueryString, type PeriodRange } from "../../../hooks/usePeriodRange"



const typeIcon = (type: AdminTransaction["type"]) => {
    if (type === "disbursement") return <ArrowDownToLine className="size-4" />;
    if (type === "vendor_payment") return <ArrowRightLeft className="size-4" />;
    if (type === "bill_payment") return <Zap className="size-4" />;
    return <RefreshCw className="size-4" />;
};

const typeStyles = (type: AdminTransaction["type"]) => {
    if (type === "disbursement") return "border-[#A561FF]/20 bg-[#A561FF]/10 text-[#A561FF]";
    if (type === "vendor_payment") return "border-primary/20 bg-primary/10 text-primary";
    if (type === "bill_payment") return "border-[#7b61d1]/20 bg-[#7b61d1]/10 text-[#7b61d1]";
    return "border-pending/20 bg-pending/10 text-pending";
};

/** Latest five ledger entries inside the dashboard's selected period. */
const RecentTransactions = ({ range }: { range: PeriodRange }) => {
    const [selected, setSelected] = useState<AdminTransaction | null>(null);
    const { data: response, isLoading, isError } = useQuery({
        queryKey: ["recentTransactions", range.startDate, range.endDate],
        queryFn: () => getTransactions({ limit: 5, startDate: range.startDate, endDate: range.endDate }),
        refetchInterval: 60000,
    });

    const raw = (response as { data?: { data?: AdminTransaction[] } })?.data;
    const recentTransactions = raw?.data ?? [];

    return (
        <Card className="border-[0.5px] border-primary/8 bg-white p-0 rounded-sm gap-0 shadow-none">
            <CardHeader className="p-4 mb-0 flex flex-row items-center justify-between border-b-[0.5px] border-primary/8">
                <CardTitle className="text-black">
                    Latest transactions
                    <span className="block text-xs font-normal text-black/50 mt-0.5">{range.label}</span>
                </CardTitle>
                <Link to={`/transactions?${rangeQueryString(range).slice(1)}`} className="text-primary text-sm flex items-center gap-1 hover:underline">
                    <span>View all</span>
                    <ChevronRight className="size-4" />
                </Link>
            </CardHeader>

            <CardContent className="p-0 text-black">
                {isLoading ? (
                    <div className="p-4 space-y-3">
                        {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full rounded-md" />)}
                    </div>
                ) : isError ? (
                    <p className="p-4 text-sm text-red-700">Could not load recent transactions.</p>
                ) : recentTransactions.length === 0 ? (
                    <EmptyState
                        title={range.from || range.to ? "Nothing in this period" : "No transactions yet"}
                        description={range.from || range.to ? "Try a longer period." : "Disbursements, vendor payments, and repayments will appear here as they happen."}
                        className="min-h-[200px] border-none"
                    />
                ) : (
                    recentTransactions.map((txn) => {
                        const who = txn.corper?.fullName || txn.user?.fullName || txn.vendor?.businessName || "Unknown";
                        return (
                            <button
                                key={txn._id}
                                type="button"
                                onClick={() => setSelected(txn)}
                                className="w-full text-left flex items-center gap-3 px-4 py-3 border-b-[0.5px] border-primary/8 last:border-none hover:bg-primary/3 transition-colors"
                            >
                                <div className={`w-9 h-9 shrink-0 flex items-center justify-center rounded-full border-[0.5px] ${typeStyles(txn.type)}`}>
                                    {typeIcon(txn.type)}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium truncate">{who}</p>
                                    <p className="text-xs text-black/50">
                                        {TYPE_LABELS[txn.type]} · {formatTime(txn.createdAt)}
                                    </p>
                                </div>
                                <span className="text-sm font-semibold whitespace-nowrap">
                                    {formatCurrency(txn.amount || 0)}
                                </span>
                            </button>
                        );
                    })
                )}
            </CardContent>

            {selected && (
                <TransactionDetailsModal
                    transaction={selected}
                    open
                    onOpenChange={(open) => { if (!open) setSelected(null); }}
                />
            )}
        </Card>
    )
}

export default RecentTransactions;
