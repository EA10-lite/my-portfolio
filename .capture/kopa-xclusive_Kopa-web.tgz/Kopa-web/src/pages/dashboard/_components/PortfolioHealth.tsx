import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "../../../components/ui/skeleton";
import { getRiskSummary } from "../../../services/api.service";
import { formatCurrency } from "../../../utils/formatter";

interface RiskSummary {
    totalExposure: number;
    outstandingAmount: number;
    collectedAmount: number;
}

/**
 * Credit-book health from GET /payments/risk-summary (aggregated server-side
 * across every paid purchase). Collection rate = collected ÷ (collected +
 * still outstanding), i.e. how much of what has come due has come back.
 */
const PortfolioHealth = () => {
    const query = useQuery({
        queryKey: ["admin-risk-summary"],
        queryFn: () => getRiskSummary(),
        retry: false,
        refetchInterval: 60_000,
    });
    const s = (query.data as { data?: RiskSummary })?.data;

    const exposure = s?.totalExposure ?? 0;
    const outstanding = s?.outstandingAmount ?? 0;
    const collected = s?.collectedAmount ?? 0;
    const base = collected + outstanding;
    const rate = base > 0 ? Math.round((collected / base) * 100) : null;

    const cards = [
        { label: "Credit exposure", value: formatCurrency(exposure), hint: "Paid out to vendors on credit" },
        { label: "Outstanding", value: formatCurrency(outstanding), hint: "Still to be collected" },
        { label: "Collected", value: formatCurrency(collected), hint: "Recovered by monthly debit" },
        {
            label: "Collection rate",
            value: rate === null ? "—" : `${rate}%`,
            hint: rate === null ? "Nothing has come due yet" : "Collected ÷ (collected + outstanding)",
            tone: rate === null ? "" : rate >= 90 ? "text-primary" : rate >= 70 ? "text-amber-600" : "text-red-600",
        },
    ];

    return (
        <section aria-labelledby="portfolio" className="space-y-3">
            <h2 id="portfolio" className="text-sm font-medium text-black/60">
                Credit portfolio
            </h2>
            {query.isError ? (
                <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
                    Could not load the credit portfolio summary.
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {cards.map((c) =>
                        query.isLoading ? (
                            <Skeleton key={c.label} className="h-[96px] w-full rounded-sm" />
                        ) : (
                            <div key={c.label} className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-1">
                                <p className="text-sm text-black/60">{c.label}</p>
                                <p className={`text-2xl font-semibold text-black ${c.tone ?? ""}`}>{c.value}</p>
                                <p className="text-xs text-black/40">{c.hint}</p>
                            </div>
                        ),
                    )}
                </div>
            )}
        </section>
    );
};

export default PortfolioHealth;
