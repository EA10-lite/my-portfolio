
import { Link } from "react-router-dom";
import { useIsFetching, useQuery, useQueryClient } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { Text } from "../../components";
import { buttonVariants } from "../../components/ui/button";
import { cn } from "../../lib/utils";
import { useAdminStore } from "../../stores/adminStore";
import { getDashboardStats } from "../../services/api.service";
import ActionQueue from "./_components/ActionQueue";
import BillsAlert from "./_components/BillsAlert";
import PortfolioHealth from "./_components/PortfolioHealth";
import TransactionVolumeChart from "./_components/TransactionVolumeChart";
import OldestPendingReviews from "./_components/OldestPendingReviews";
import RecentTransactions from "./_components/RecentTransactions";
import MemberStatusChart from "./_components/MemberStatusChart";
import CategoryDistributionChart from "./_components/CategoryDistributionChart";
import PeriodSummary from "./_components/PeriodSummary";
import PeriodBar from "../../components/main/PeriodBar";
import { usePeriodRange } from "../../hooks/usePeriodRange";

const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
};

/**
 * Dashboard home, ordered by what an admin does with it:
 *   1. Needs action — the queues waiting on a decision, each a link in.
 *   2. Credit portfolio — is the money coming back?
 *   3. Activity — totals, money by type and latest transactions for the
 *      selected period (presets or custom dates, kept in the URL).
 *   4. Monthly trend, then the review queue and member mix (current state,
 *      so they don't follow the period).
 */
const Dashboard = () => {
    const { admin } = useAdminStore();
    const qc = useQueryClient();
        const fetching = useIsFetching();
    // ?period= / ?from=&to= — drives everything in the Activity section.
    const range = usePeriodRange("month");
    

    const { data: stats } = useQuery({
        queryKey: ["dashboardStats"],
        queryFn: getDashboardStats,
        refetchInterval: 60_000,
    });
    const totals = (stats as { data?: { totalCorpers?: number; totalVendors?: number } })?.data;

        // Newest data timestamp among the queries on screen. `useIsFetching`
    // re-renders this component whenever fetching starts or settles.
        const updatedAtMs = Math.max(
        0,
        ...qc
            .getQueryCache()
            .getAll()
            .filter((q) => q.getObserversCount() > 0)
            .map((q) => q.state.dataUpdatedAt),
    );

    const refresh = () => {
        qc.invalidateQueries({ type: "active" });
    };

    const firstName = admin?.fullName?.split(" ")[0] ?? "Admin";

    return (
        <div className="dashboard space-y-8">
            <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                    <Text
                        title={`${greeting()}, ${firstName}`}
                        type="h4"
                        className="text-lg text-black font-semibold"
                    />
                    <p className="text-sm text-black/60 mt-0.5">
                        {totals
                            ? `${(totals.totalCorpers ?? 0).toLocaleString()} corps members and ${(totals.totalVendors ?? 0).toLocaleString()} vendors on Kopa Xclusive.`
                            : "Here's what needs your attention."}
                    </p>
                </div>

                <div className="flex items-center gap-3">
                    <span className="text-xs text-black/50" aria-live="polite">
                        {fetching > 0
                            ? "Updating…"
                            : updatedAtMs > 0
                                ? `Updated ${new Date(updatedAtMs).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
                                : ""}
                    </span>
                    <button
                        type="button"
                        onClick={refresh}
                        disabled={fetching > 0}
                        className={cn(buttonVariants({ variant: "outline", size: "sm" }), "gap-1.5 bg-white text-black")}
                    >
                        <RefreshCw className={cn("size-3.5", fetching > 0 && "animate-spin")} />
                        Refresh
                    </button>
                    <Link to="/corpers" className={cn(buttonVariants({ variant: "default", size: "sm" }), "rounded-sm px-3")}>
                        View all members
                    </Link>
                </div>
            </div>

            <BillsAlert />
            <ActionQueue />
            <PortfolioHealth />

            <section aria-labelledby="activity" className="space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                    <h2 id="activity" className="text-sm font-medium text-black/60">
                        Activity · {range.label}
                    </h2>
                    <PeriodBar range={range} />
                </div>
                <PeriodSummary range={range} />
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <CategoryDistributionChart range={range} />
                    <RecentTransactions range={range} />
                </div>
            </section>

            <TransactionVolumeChart />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <OldestPendingReviews />
                <MemberStatusChart />
            </div>
        </div>
    );
};

export default Dashboard;
