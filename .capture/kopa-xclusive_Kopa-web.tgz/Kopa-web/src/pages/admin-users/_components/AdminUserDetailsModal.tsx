import { DetailsModal, ModalFieldItem } from "../../../components";
import { Badge } from "../../../components/ui/badge";
import { formatDateString } from "../../../utils/formatter";
import type { AdminUserRow } from "../page";

const statusBadgeVariant = (status: string) => {
  if (status === "approved") return "default" as const;
  if (status === "rejected" || status === "suspended") return "destructive" as const;
  return "pending" as const;
};

const AdminUserDetailsModal = ({
  admin,
  triggerButton,
  open,
  onOpenChange,
}: {
  admin: AdminUserRow;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  return (
    <DetailsModal title="Admin User Details" TriggerButton={triggerButton} open={open} onOpenChange={onOpenChange}>
      <div className="p-4 space-y-3">
        <ModalFieldItem label="Full Name" value={admin.fullName} />
        <ModalFieldItem label="Email" value={admin.email} />
        <ModalFieldItem label="Phone" value={admin.phone ?? "-"} />
        <ModalFieldItem label="Role" value={admin.role.replace("_", " ")} />
        <ModalFieldItem
          label="Status"
          content={
            <Badge className="font-normal capitalize w-fit" variant={statusBadgeVariant(admin.status)}>
              {admin.status}
            </Badge>
          }
        />
        <ModalFieldItem
          label="Department"
          value={admin.department ? admin.department.replace("_", " ") : "Not yet assigned"}
        />
        <ModalFieldItem label="Created At" value={formatDateString(admin.createdAt)} />
      </div>
    </DetailsModal>
  );
};

export default AdminUserDetailsModal;
