import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Textarea } from "../../../components/ui/textarea";
import {
  ADMIN_DEPARTMENTS,
  createAdminAccount,
  deactivateAdminAccount,
  updateAdminAccount,
  type AdminRoleValue,
} from "../../../services/admin.service";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { invalidateGroup } from "../../../lib/invalidate";
import { getApiErrorMessage } from "../../../utils/apiError";
import type { AdminUserRow } from "../page";

const selectClass =
  "h-9 w-full rounded-lg border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50";
const PHONE_RE = /^0[789]\d{9}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const RoleAndDepartment = ({
  role,
  department,
  onRole,
  onDepartment,
}: {
  role: AdminRoleValue;
  department: string;
  onRole: (r: AdminRoleValue) => void;
  onDepartment: (d: string) => void;
}) => (
  <div className="grid grid-cols-2 gap-3">
    <div className="space-y-1.5">
      <Label htmlFor="admin-role">Role</Label>
      <select id="admin-role" className={selectClass} value={role} onChange={(e) => onRole(e.target.value as AdminRoleValue)}>
        <option value="admin">Admin</option>
        <option value="super_admin">Super admin</option>
      </select>
    </div>
    <div className="space-y-1.5">
      <Label htmlFor="admin-dept">Department</Label>
      <select id="admin-dept" className={selectClass} value={department} onChange={(e) => onDepartment(e.target.value)}>
        <option value="">Select…</option>
        {ADMIN_DEPARTMENTS.map((d) => (
          <option key={d.value} value={d.value}>
            {d.label}
          </option>
        ))}
      </select>
    </div>
  </div>
);

/** POST /admin/accounts — the new admin sets their own PIN via "Forgot PIN". */
export const CreateAdminModal = ({ triggerButton }: { triggerButton: React.ReactNode }) => {
  const [open, setOpen] = useState(false);
  const empty = { fullName: "", phone: "", email: "", role: "admin" as AdminRoleValue, department: "" };
  const [form, setForm] = useState(empty);
  const qc = useQueryClient();

  const valid =
    form.fullName.trim().length >= 2 && PHONE_RE.test(form.phone) && EMAIL_RE.test(form.email.trim()) && Boolean(form.department);

  const mut = useMutation({
    mutationFn: () => createAdminAccount({ ...form, fullName: form.fullName.trim(), email: form.email.trim() }),
    onSuccess: () => {
      toast.success(`${form.fullName.trim()} added. They've been emailed how to set their PIN.`);
      invalidateGroup(qc, "admins");
      setOpen(false);
      setForm(empty);
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not create the admin.")),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) setForm(empty);
      }}
    >
      <DialogTrigger render={triggerButton as React.ReactElement} />
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add an admin</DialogTitle>
          <DialogDescription>
            They'll get an email telling them to open the dashboard and use <strong>Forgot PIN</strong> with this
            phone number — an SMS code proves it's theirs, and they choose their own PIN. Nobody else ever sees it.
          </DialogDescription>
        </DialogHeader>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (valid) mut.mutate();
          }}
        >
          <div className="space-y-1.5">
            <Label htmlFor="new-admin-name">Full name</Label>
            <Input id="new-admin-name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="new-admin-phone">Phone</Label>
              <Input
                id="new-admin-phone"
                inputMode="tel"
                placeholder="08012345678"
                maxLength={11}
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="new-admin-email">Email</Label>
              <Input id="new-admin-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
          </div>
          {form.phone.length === 11 && !PHONE_RE.test(form.phone) && (
            <p className="text-xs text-red-600">Use a Nigerian mobile number like 08012345678.</p>
          )}
          <RoleAndDepartment
            role={form.role}
            department={form.department}
            onRole={(role) => setForm({ ...form, role })}
            onDepartment={(department) => setForm({ ...form, department })}
          />
          {form.role === "super_admin" && (
            <p className="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded p-2">
              Super admins can add and deactivate other admins, change settings and manage banks.
            </p>
          )}
          <DialogFooter className="gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={mut.isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={!valid || mut.isPending}>
              {mut.isPending ? "Adding…" : "Add admin"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

/** PATCH /admin/accounts/:id — role and/or department. */
export const EditAdminModal = ({
  admin,
  open: openProp,
  onOpenChange,
}: {
  admin: AdminUserRow;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [role, setRole] = useState<AdminRoleValue>(admin.role);
  const [department, setDepartment] = useState(admin.department ?? "");
  const qc = useQueryClient();

  const changes = {
    ...(role !== admin.role ? { role } : {}),
    ...(department && department !== admin.department ? { department } : {}),
  };
  const dirty = Object.keys(changes).length > 0;

  const mut = useMutation({
    mutationFn: () => updateAdminAccount(admin._id, changes),
    onSuccess: () => {
      toast.success(`${admin.fullName} updated${changes.role ? " — they'll need to sign in again" : ""}`);
      invalidateGroup(qc, "admins");
      setOpen(false);
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update this admin.")),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit {admin.fullName}</DialogTitle>
          <DialogDescription>Changing the role signs them out of every device so the new access applies at once.</DialogDescription>
        </DialogHeader>
        <RoleAndDepartment role={role} department={department} onRole={setRole} onDepartment={setDepartment} />
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={mut.isPending}>
            Cancel
          </Button>
          <Button onClick={() => mut.mutate()} disabled={!dirty || mut.isPending}>
            {mut.isPending ? "Saving…" : "Save changes"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

/** POST /admin/accounts/:id/deactivate — needs a reason (recorded and emailed). */
export const DeactivateAdminModal = ({
  admin,
  open: openProp,
  onOpenChange,
}: {
  admin: AdminUserRow;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [reason, setReason] = useState("");
  const qc = useQueryClient();

  const mut = useMutation({
    mutationFn: () => deactivateAdminAccount(admin._id, reason.trim()),
    onSuccess: () => {
      toast.success(`${admin.fullName} deactivated and signed out everywhere`);
      invalidateGroup(qc, "admins");
      setOpen(false);
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not deactivate this admin.")),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Deactivate {admin.fullName}?</DialogTitle>
          <DialogDescription>
            They're signed out of every device immediately and can't sign in until reactivated. Their past actions
            stay in the audit log.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-1.5">
          <Label htmlFor="deactivate-reason">Reason (recorded and emailed to them)</Label>
          <Textarea id="deactivate-reason" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Left the company" />
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={mut.isPending}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={() => mut.mutate()} disabled={reason.trim().length < 2 || mut.isPending}>
            {mut.isPending ? "Deactivating…" : "Deactivate"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
