import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { setAdminApprovalStatus } from "../../../services/admin.service";
import type { AdminUserRow } from "../page";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { getApiErrorMessage } from "../../../utils/apiError";
import { invalidateGroup } from "../../../lib/invalidate";

// Matches backend ADMIN_DEPARTMENTS enum (admin/admin.schema.ts).
const DEPARTMENT_OPTIONS = [
  { label: "Corps Affairs", value: "corps_affairs" },
  { label: "Vendor Affairs", value: "vendor_affairs" },
  { label: "Payment Affairs", value: "payment_affairs" },
  { label: "Admin Affairs", value: "admin_affairs" },
];

const selectClassName =
  "h-8 w-full min-w-0 rounded-lg border border-input bg-transparent px-2.5 py-1 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50";

const AdminReviewModal = ({
  admin,
  triggerButton,
  open: openProp,
  onOpenChange,
}: {
  admin: AdminUserRow;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [reason, setReason] = useState("");
  const [department, setDepartment] = useState("");
  const [mode, setMode] = useState<"idle" | "rejecting">("idle");
  const qc = useQueryClient();

  const reset = () => {
    setReason("");
    setDepartment("");
    setMode("idle");
  };

  const approveMut = useMutation({
    mutationFn: () =>
      setAdminApprovalStatus(admin._id, {
        action: "approve",
        reason: reason || "Approved",
        admin_department: department,
      }),
    onSuccess: () => {
      toast.success(`${admin.fullName} approved as ${department.replace("_", " ")}`);
      invalidateGroup(qc, "admins");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Approve failed")),
  });

  const rejectMut = useMutation({
    mutationFn: () => setAdminApprovalStatus(admin._id, { action: "reject", reason }),
    onSuccess: () => {
      toast.success(`${admin.fullName} rejected`);
      invalidateGroup(qc, "admins");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Reject failed")),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-[425px] bg-secondary border border-primary/10 rounded-xl">
        <DialogHeader>
          <DialogTitle>Review admin</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 py-2">
          <p className="text-sm text-black/70">
            <span className="font-medium text-black">{admin.fullName}</span> — {admin.email}
          </p>
          <p className="text-xs text-black/50">
            Current status: <span className="capitalize font-medium">{admin.status}</span>
          </p>

          {mode === "idle" ? (
            <div className="space-y-1">
              <label className="text-xs font-medium text-black/70">
                Department (required to approve)
              </label>
              <select
                className={selectClassName}
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
              >
                <option value="">Select a department</option>
                {DEPARTMENT_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="space-y-1">
              <label className="text-xs font-medium text-black/70">
                Reason for rejection (required)
              </label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Role not authorized for this account"
                rows={3}
              />
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          {mode === "idle" ? (
            <>
              <Button
                variant="destructive"
                onClick={() => setMode("rejecting")}
                disabled={admin.status === "rejected"}
              >
                Reject
              </Button>
              <Button
                onClick={() => approveMut.mutate()}
                disabled={approveMut.isPending || admin.status === "approved" || !department}
              >
                {approveMut.isPending ? "Approving..." : "Approve"}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setMode("idle")}>
                Back
              </Button>
              <Button
                variant="destructive"
                onClick={() => rejectMut.mutate()}
                disabled={rejectMut.isPending || !reason.trim()}
              >
                {rejectMut.isPending ? "Rejecting..." : "Confirm rejection"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AdminReviewModal;
