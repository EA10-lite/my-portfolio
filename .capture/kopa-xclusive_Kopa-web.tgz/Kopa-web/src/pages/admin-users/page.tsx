import { useMemo, useState } from "react";
import { useMutation, useQueries, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ConfirmDialog, ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { Button } from "../../components/ui/button";
import type { CsvColumn } from "../../utils/csv";
import { Badge } from "../../components/ui/badge";
import { formatDateString } from "../../utils/formatter";
import { getAdmins, reactivateAdminAccount, resetAdminPin } from "../../services/admin.service";
import { getApiErrorMessage } from "../../utils/apiError";
import { invalidateGroup } from "../../lib/invalidate";
import { CreateAdminModal, DeactivateAdminModal, EditAdminModal } from "./_components/AdminAccountModals";
import { Users, UserCheck, ShieldCheck, ShieldQuestion, Eye, Bell, UserPlus, Pencil, KeyRound, UserX, UserCheck2 } from "lucide-react";
import SendNotificationModal from "../notifications/_components/SendNotificationModal";
import { useAdminStore, isSuperAdmin } from "../../stores/adminStore";
import { cn } from "../../lib/utils";
import AdminUserDetailsModal from "./_components/AdminUserDetailsModal";
import AdminReviewModal from "./_components/AdminReviewModal";

export interface AdminUserRow {
  _id: string;
  fullName: string;
  email: string;
  phone?: string;
  role: "admin" | "super_admin";
    status: "pending" | "approved" | "rejected" | "suspended";
  isActive?: boolean;
  department: string | null;
  createdAt: string;
}

const kpiStyles = {
  total: "bg-indigo-50 border-indigo-100 text-indigo-600",
  active: "bg-emerald-50 border-emerald-100 text-emerald-600",
  pending: "bg-yellow-50 border-yellow-100 text-yellow-600",
  super: "bg-amber-50 border-amber-100 text-amber-600",
};

const statusBadgeVariant = (status: string) => {
  if (status === "approved") return "default" as const;
  if (status === "rejected" || status === "suspended") return "destructive" as const;
  return "pending" as const;
};

const STATUS_FILTER_OPTIONS = [
  { label: "pending", value: "pending" },
  { label: "approved", value: "approved" },
  { label: "rejected", value: "rejected" },
  { label: "suspended", value: "suspended" },
];

const AdminUsersPage = () => {
  const admin = useAdminStore((s) => s.admin);
    const canManage = isSuperAdmin(admin?.role);
  const qc = useQueryClient();

  const resetPinMut = useMutation({
    mutationFn: (id: string) => resetAdminPin(id),
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not reset the PIN.")),
  });
  const reactivateMut = useMutation({
    mutationFn: (id: string) => reactivateAdminAccount(id),
    onSuccess: () => invalidateGroup(qc, "admins"),
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not reactivate this admin.")),
  });
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });
  const [status, setStatus] = useState("");

  // GET /admin is super-admin only; don't fire it for a regular admin.
  const adminsQuery = useQuery({
    queryKey: ["admin-users", pagination.pageIndex, pagination.pageSize, status],
    queryFn: () => getAdmins({ page: pagination.pageIndex + 1, limit: pagination.pageSize, status }),
    enabled: canManage,
    retry: false,
  });

  const countQueries = useQueries({
    queries: (["pending", "approved", "rejected"] as const).map((status) => ({
      queryKey: ["admin-users-count", status],
      queryFn: () => getAdmins({ status, page: 1, limit: 1 }),
      enabled: canManage,
      retry: false,
    })),
  });
  const superAdminCountQuery = useQuery({
    queryKey: ["admin-users-count", "super_admin"],
    queryFn: () => getAdmins({ role: "super_admin", page: 1, limit: 1 }),
    enabled: canManage,
    retry: false,
  });

  const countFor = (index: number) =>
    (countQueries[index].data as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0;

  const raw = (adminsQuery.data as { data?: { data?: AdminUserRow[]; meta?: { total?: number; totalPages?: number } } })?.data;
  const rows: AdminUserRow[] = raw?.data ?? [];

  const exportColumns: CsvColumn<AdminUserRow>[] = [
      { header: "Full Name", value: (r) => r.fullName },
      { header: "Email", value: (r) => r.email },
      { header: "Phone", value: (r) => r.phone },
      { header: "Role", value: (r) => r.role },
      { header: "Status", value: (r) => r.status },
      { header: "Department", value: (r) => r.department },
      { header: "Created", value: (r) => r.createdAt },
  ];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

  const counts = {
    pending: countFor(0),
    approved: countFor(1),
    superAdmins:
      (superAdminCountQuery.data as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0,
  };

  const columns: ColumnDef<AdminUserRow>[] = useMemo(
    () => [
      {
        accessorKey: "fullName",
        header: "Name",
        cell: ({ row }) => (
          <span className="text-black font-medium">{row.getValue("fullName")}</span>
        ),
      },
      {
        accessorKey: "email",
        header: "Email",
        cell: ({ row }) => <span className="text-black">{row.getValue("email")}</span>,
      },
      {
        accessorKey: "role",
        header: "Role",
        cell: ({ row }) => (
          <span className="text-black capitalize">{(row.getValue("role") as string).replace("_", " ")}</span>
        ),
      },
      {
        accessorKey: "department",
        header: "Department",
        cell: ({ row }) => {
          const dept = row.getValue("department") as string | null;
          return <span className="text-black capitalize">{dept ? dept.replace("_", " ") : "-"}</span>;
        },
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
          const status = row.getValue("status") as string;
          return (
            <Badge className="font-normal capitalize" variant={statusBadgeVariant(status)}>
              {status}
            </Badge>
          );
        },
      },
      {
        accessorKey: "createdAt",
        header: "Created Date",
        cell: ({ row }) => (
          <span className="text-black">{formatDateString(row.getValue("createdAt"))}</span>
        ),
      },
      {
        id: "actions",
        header: "Action",
                cell: ({ row }) => {
                    const a = row.original;
          const isSelf = a._id === admin?._id;
          return (
            <RowActions
              actions={[
                {
                  key: "review",
                  label: "Review & approve",
                  icon: <ShieldQuestion className="size-4" />,
                  hidden: a.status !== "pending",
                  dialog: (p) => <AdminReviewModal admin={a} {...p} />,
                },
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  dialog: (p) => <AdminUserDetailsModal admin={a} {...p} />,
                },
                                {
                  key: "edit",
                  label: "Edit role & department",
                  icon: <Pencil className="size-4" />,
                  hidden: isSelf || a.status !== "approved",
                  dialog: (p) => <EditAdminModal admin={a} {...p} />,
                },
                {
                  key: "notify",
                  label: "Send notification",
                  icon: <Bell className="size-4" />,
                  hidden: a.status !== "approved",
                  dialog: (p) => (
                    <SendNotificationModal
                      recipient={{ userId: a._id, label: `${a.fullName} — ${a.email}` }}
                      {...p}
                    />
                  ),
                },
                {
                  key: "reactivate",
                  label: "Reactivate",
                  icon: <UserCheck2 className="size-4" />,
                  hidden: a.status !== "suspended",
                  dialog: (p) => (
                    <ConfirmDialog
                      {...p}
                      title={`Reactivate ${a.fullName}?`}
                      description="They can sign in again with their existing PIN, with the same role and department as before."
                      confirmLabel="Reactivate"
                      busy={reactivateMut.isPending}
                      onConfirm={() =>
                        reactivateMut.mutate(a._id, {
                          onSuccess: () => {
                            toast.success(`${a.fullName} reactivated`);
                            p.onOpenChange(false);
                          },
                        })
                      }
                    />
                  ),
                },
                {
                  key: "reset-pin",
                  label: "Reset PIN",
                  icon: <KeyRound className="size-4" />,
                  destructive: true,
                  hidden: isSelf || a.status !== "approved",
                  dialog: (p) => (
                    <ConfirmDialog
                      {...p}
                      title={`Reset ${a.fullName}'s PIN?`}
                      description="Their current PIN stops working and they're signed out everywhere. They'll be emailed to set a new one with Forgot PIN on the login screen (SMS code to their phone)."
                      confirmLabel="Reset PIN"
                      destructive
                      busy={resetPinMut.isPending}
                      onConfirm={() =>
                        resetPinMut.mutate(a._id, {
                          onSuccess: () => {
                            toast.success(`${a.fullName}'s PIN was reset and they were signed out`);
                            p.onOpenChange(false);
                          },
                        })
                      }
                    />
                  ),
                },
                {
                  key: "deactivate",
                  label: "Deactivate",
                  icon: <UserX className="size-4" />,
                  destructive: true,
                  hidden: isSelf || a.status !== "approved",
                  dialog: (p) => <DeactivateAdminModal admin={a} {...p} />,
                },
              ]}
            />
          );
        },
      },
    ],
    [admin?._id, reactivateMut, resetPinMut],
  );

    if (!canManage) {
    return (
      <div className="w-full space-y-3">
        <Text title="Admin Users" type="h4" className="text-lg text-black" />
        <p className="text-sm text-black/60">
          Only a super admin can view and approve admin accounts.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <Text title="Admin Users" type="h4" className="text-lg text-black" />
          <div className="flex items-center gap-2">
            <CreateAdminModal
              triggerButton={
                <Button variant="outline" className="rounded-sm px-4 bg-white text-black">
                  <UserPlus className="size-4 mr-2" /> Add admin
                </Button>
              }
            />
            <ExportButton
            filename="admin-users"
            columns={exportColumns}
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getAdmins({ page, limit, status });
              return { rows: res?.data?.data ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
            }}
          />
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        
        {adminsQuery.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load admin users from the server. Check your connection and try again.
          </div>
        )}

                <p className="text-xs text-black/50">
          Add admins here, or approve people who signed up as admins. Nobody sets a PIN for
          someone else: new and reset accounts choose their own with Forgot PIN on the login
          screen. You can't deactivate, demote or reset yourself, or remove the last active
          super admin.
        </p>

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total Admins"
            value={total.toLocaleString()}
            icon={<Users className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="Approved"
            value={counts.approved.toLocaleString()}
            icon={<UserCheck className="size-4" />}
            className={kpiStyles.active}
          />
          <PageMetric
            label="Pending Approval"
            value={counts.pending.toLocaleString()}
            icon={<ShieldQuestion className="size-4" />}
            className={kpiStyles.pending}
          />
          <PageMetric
            label="Super Admins"
            value={counts.superAdmins.toLocaleString()}
            icon={<ShieldCheck className="size-4" />}
            className={kpiStyles.super}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          searchKeys={["fullName", "email"]}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={adminsQuery.isLoading}
          rowCount={total}
                    filters={[{ columnKey: "status", title: "Status", options: STATUS_FILTER_OPTIONS }]}
          filterValues={{ status }}
          onFilterChange={(_, v) => {
            setStatus(v);
            setPagination((p) => ({ ...p, pageIndex: 0 }));
          }}
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
}) => (
  <div className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3">
    <div
      className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]",
        className,
      )}
    >
      {icon}
    </div>
    <Text title={value} type="h2" className="text-2xl font-medium text-black" />
    <Text title={label} type="h4" className="text-black" />
  </div>
);

export default AdminUsersPage;
