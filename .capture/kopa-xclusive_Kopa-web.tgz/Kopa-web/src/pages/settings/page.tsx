import { useState } from "react";
import { Text } from "../../components";
import { cn } from "../../lib/utils";
import { useAdminStore, isSuperAdmin } from "../../stores/adminStore";
import ProfileTab from "./_components/ProfileTab";
import PlatformTab from "./_components/PlatformTab";
import IntegrationsTab from "./_components/IntegrationsTab";
import SecurityAndAccessTab from "./_components/SecurityAndAccessTab";

const TABS = [
  { id: "profile", label: "Profile" },
  { id: "platform", label: "Platform" },
  { id: "integrations", label: "Integrations", superAdminOnly: true },
  { id: "security", label: "Security & Access" },
] as const;

type TabId = (typeof TABS)[number]["id"];

const Settings = () => {
  const admin = useAdminStore((s) => s.admin);
  const tabs = TABS.filter((t) => !("superAdminOnly" in t) || isSuperAdmin(admin?.role));
  const [active, setActive] = useState<TabId>("profile");

  return (
    <div className="w-full">
      <div className="page-header">
        <Text title="Settings" type="h4" className="text-lg text-black" />
        <p className="text-sm text-black/60 mt-1">Your account, platform defaults, and how this server is connected.</p>
      </div>

      <div className="page-body mt-6 text-black">
        <div role="tablist" className="flex items-center gap-6 border-b border-primary/20 mb-6 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              role="tab"
              aria-selected={active === tab.id}
              onClick={() => setActive(tab.id)}
              className={cn(
                "pb-3 px-1 text-sm font-medium whitespace-nowrap transition-colors",
                active === tab.id ? "text-primary border-b-2 border-primary" : "text-black/60 hover:text-black",
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div role="tabpanel">
          {active === "profile" && <ProfileTab />}
          {active === "platform" && <PlatformTab />}
          {active === "integrations" && <IntegrationsTab />}
          {active === "security" && <SecurityAndAccessTab />}
        </div>
      </div>
    </div>
  );
};

export default Settings;
