import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Info, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Skeleton } from "../../../components/ui/skeleton";
import { useSettings } from "../../../hooks/useSettings";
import { updateSettings, type PlatformSettings } from "../../../services/settings.service";
import { useAdminStore, isSuperAdmin } from "../../../stores/adminStore";
import { getApiErrorMessage } from "../../../utils/apiError";
import { formatCurrency, formatDateString } from "../../../utils/formatter";

type Form = {
  defaultCreditLimit: string;
  maxCreditLimit: string;
  creditLimitPresets: number[];
  supportEmail: string;
  supportPhone: string;
  termsUrl: string;
  privacyUrl: string;
};

const toForm = (s: PlatformSettings): Form => ({
  defaultCreditLimit: String(s.defaultCreditLimit),
  maxCreditLimit: String(s.maxCreditLimit),
  creditLimitPresets: s.creditLimitPresets,
  supportEmail: s.supportEmail,
  supportPhone: s.supportPhone,
  termsUrl: s.termsUrl,
  privacyUrl: s.privacyUrl,
});

/**
 * Platform settings (GET/PATCH /settings). Every field has a real consumer:
 * the credit-limit values drive the approve and edit-limit forms across the
 * dashboard, and the contacts and legal links are served to the apps by
 * GET /settings/public. Super admins edit; other admins see read-only.
 */
const PlatformTab = () => {
  const admin = useAdminStore((s) => s.admin);
  const canEdit = isSuperAdmin(admin?.role);
  const { settings, query } = useSettings();
  const qc = useQueryClient();
  // `null` = untouched → show the saved values; editing creates a draft.
  const [draft, setDraft] = useState<Form | null>(null);
  const [presetInput, setPresetInput] = useState("");
  const form = draft ?? toForm(settings);
  const set = (patch: Partial<Form>) => setDraft({ ...form, ...patch });

  const def = Number(form.defaultCreditLimit);
  const max = Number(form.maxCreditLimit);
  const problems = [
    def > max && "The default credit limit is above the maximum.",
    form.creditLimitPresets.some((p) => p > max) && "A preset is above the maximum credit limit.",
    form.creditLimitPresets.length === 0 && "Add at least one preset.",
  ].filter(Boolean) as string[];

  const mut = useMutation({
    mutationFn: () =>
      updateSettings({
        defaultCreditLimit: def,
        maxCreditLimit: max,
        creditLimitPresets: form.creditLimitPresets,
        supportEmail: form.supportEmail.trim(),
        supportPhone: form.supportPhone.trim(),
        termsUrl: form.termsUrl.trim(),
        privacyUrl: form.privacyUrl.trim(),
      }),
    onSuccess: (saved) => {
      qc.setQueryData(["platform-settings"], saved);
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
      setDraft(null);
      toast.success("Platform settings saved");
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not save settings.")),
  });

  if (query.isLoading) return <Skeleton className="h-96 w-full rounded-sm" />;

  const addPreset = () => {
    const v = Number(presetInput.replace(/\D/g, ""));
    if (v >= 1000 && !form.creditLimitPresets.includes(v) && form.creditLimitPresets.length < 6) {
      set({ creditLimitPresets: [...form.creditLimitPresets, v].sort((a, b) => a - b) });
    }
    setPresetInput("");
  };

  const updatedBy = typeof settings.updatedBy === "object" ? settings.updatedBy?.fullName : undefined;

  return (
    <form
      className="space-y-6"
      onSubmit={(e) => {
        e.preventDefault();
        if (canEdit && draft && problems.length === 0) mut.mutate();
      }}
    >
      {query.isError && (
        <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
          Could not load saved settings — showing defaults. {getApiErrorMessage(query.error, "")}
        </div>
      )}
      {!canEdit && (
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 text-slate-700 text-sm rounded-sm p-3">
          <Info className="size-4" /> Only a super admin can change platform settings.
        </div>
      )}

      <fieldset disabled={!canEdit} className="p-6 bg-white border border-primary/20 rounded-sm space-y-5">
        <div>
          <h3 className="text-lg font-medium text-black">Credit limits</h3>
          <p className="text-sm text-black/60">Used by the approve and edit-limit forms across the dashboard.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="defaultCreditLimit">Default limit on approval (₦)</Label>
            <Input
              id="defaultCreditLimit"
              inputMode="numeric"
              value={form.defaultCreditLimit}
              onChange={(e) => set({ defaultCreditLimit: e.target.value.replace(/\D/g, "") })}
            />
            <p className="text-xs text-black/50">Pre-filled when approving a corps member's KYC.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="maxCreditLimit">Maximum limit (₦)</Label>
            <Input
              id="maxCreditLimit"
              inputMode="numeric"
              value={form.maxCreditLimit}
              onChange={(e) => set({ maxCreditLimit: e.target.value.replace(/\D/g, "") })}
            />
            <p className="text-xs text-black/50">The dashboard won't approve or set a limit above this.</p>
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="preset">Quick-pick presets</Label>
          <div className="flex flex-wrap items-center gap-2">
            {form.creditLimitPresets.map((p) => (
              <span key={p} className="inline-flex items-center gap-1 rounded-full border border-primary/20 bg-primary/5 px-2.5 py-1 text-xs text-black">
                {formatCurrency(p)}
                {canEdit && (
                  <button
                    type="button"
                    aria-label={`Remove ${formatCurrency(p)}`}
                    onClick={() => set({ creditLimitPresets: form.creditLimitPresets.filter((x) => x !== p) })}
                    className="text-black/40 hover:text-red-600"
                  >
                    <X className="size-3" />
                  </button>
                )}
              </span>
            ))}
            {canEdit && form.creditLimitPresets.length < 6 && (
              <div className="flex items-center gap-1">
                <Input
                  id="preset"
                  inputMode="numeric"
                  placeholder="e.g. 40000"
                  className="h-8 w-28"
                  value={presetInput}
                  onChange={(e) => setPresetInput(e.target.value.replace(/\D/g, ""))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addPreset();
                    }
                  }}
                />
                <Button type="button" variant="outline" size="sm" onClick={addPreset}>
                  Add
                </Button>
              </div>
            )}
          </div>
        </div>
      </fieldset>

      <fieldset disabled={!canEdit} className="p-6 bg-white border border-primary/20 rounded-sm space-y-5">
        <div>
          <h3 className="text-lg font-medium text-black">Support & legal</h3>
          <p className="text-sm text-black/60">
            Served to the corps member and vendor apps (GET /settings/public).
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="supportEmail">Support email</Label>
            <Input id="supportEmail" type="email" value={form.supportEmail} onChange={(e) => set({ supportEmail: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="supportPhone">Support phone</Label>
            <Input id="supportPhone" type="tel" placeholder="+234…" value={form.supportPhone} onChange={(e) => set({ supportPhone: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="termsUrl">Terms & conditions URL</Label>
            <Input id="termsUrl" type="url" placeholder="https://" value={form.termsUrl} onChange={(e) => set({ termsUrl: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="privacyUrl">Privacy policy URL</Label>
            <Input id="privacyUrl" type="url" placeholder="https://" value={form.privacyUrl} onChange={(e) => set({ privacyUrl: e.target.value })} />
          </div>
        </div>
      </fieldset>

      {canEdit && (
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-black/50">
            {settings.updatedAt
              ? `Last changed ${formatDateString(settings.updatedAt)}${updatedBy ? ` by ${updatedBy}` : ""}. Every change is recorded in Audit Logs.`
              : "Not saved yet — these are the defaults. Every change is recorded in Audit Logs."}
          </p>
          <div className="flex items-center gap-2">
            {problems.length > 0 && <span className="text-xs text-red-600">{problems[0]}</span>}
            <Button type="button" variant="outline" disabled={!draft || mut.isPending} onClick={() => setDraft(null)}>
              Discard
            </Button>
            <Button type="submit" disabled={!draft || problems.length > 0 || mut.isPending}>
              {mut.isPending ? "Saving…" : "Save settings"}
            </Button>
          </div>
        </div>
      )}
    </form>
  );
};

export default PlatformTab;
