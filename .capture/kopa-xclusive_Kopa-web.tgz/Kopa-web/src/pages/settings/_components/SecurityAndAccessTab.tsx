import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Text } from "../../../components";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Alert, AlertDescription } from "../../../components/ui/alert";
import { AlertCircle, Info, KeyRound, LogOut } from "lucide-react";
import { changePin, logoutAllDevices } from "../../../services/auth.service";
import { useAdminStore } from "../../../stores/adminStore";

/**
 * Security & Access.
 *
 * The backend authenticates with a 6-digit PIN, not a password, so this is a
 * PIN change rather than a password change. Session management is limited to
 * "sign out everywhere" (POST /auth/logout-all) — there is no endpoint that
 * lists active sessions, and no 2FA endpoint at all, so neither is faked here.
 */
const SecurityAndAccessTab = () => {
  const admin = useAdminStore((s) => s.admin);
  const logout = useAdminStore((s) => s.logout);

  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [newPinConfirm, setNewPinConfirm] = useState("");

  const digitsOnly = (v: string) => v.replace(/\D/g, "");

  const pinMut = useMutation({
    mutationFn: () => changePin(currentPin, newPin, newPinConfirm),
    onSuccess: () => {
      toast.success("PIN updated");
      setCurrentPin("");
      setNewPin("");
      setNewPinConfirm("");
    },
    onError: (e: unknown) => {
      const err = e as { response?: { data?: { message?: string } } };
      toast.error(err.response?.data?.message ?? "Could not change your PIN.");
    },
  });

  const logoutAllMut = useMutation({
    mutationFn: logoutAllDevices,
    onSuccess: () => {
      toast.success("Signed out of all devices");
      // This revokes the current session too, so send the admin to login.
      logout();
      window.location.href = "/auth/login";
    },
    onError: (e: unknown) => {
      const err = e as { response?: { data?: { message?: string } } };
      toast.error(err.response?.data?.message ?? "Could not sign out everywhere.");
    },
  });

  const pinValid =
    /^\d{6}$/.test(currentPin) &&
    /^\d{6}$/.test(newPin) &&
    newPin === newPinConfirm &&
    newPin !== currentPin;

  return (
    <div className="space-y-6">
      {/* Change PIN */}
      <section className="p-6 bg-white rounded-sm border-[0.5px] border-primary/20 space-y-4">
        <div className="flex items-start gap-3">
          <KeyRound className="size-5 text-primary mt-0.5" />
          <div>
            <Text title="Change PIN" type="h5" className="text-black font-semibold" />
            <p className="text-sm text-black/60">
              You sign in with your phone number and a 6-digit PIN. Changing it
              here takes effect immediately.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl">
          <div className="space-y-1.5">
            <Label htmlFor="current-pin">Current PIN</Label>
            <Input
              id="current-pin"
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={currentPin}
              onChange={(e) => setCurrentPin(digitsOnly(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new-pin">New PIN</Label>
            <Input
              id="new-pin"
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={newPin}
              onChange={(e) => setNewPin(digitsOnly(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="confirm-pin">Confirm new PIN</Label>
            <Input
              id="confirm-pin"
              type="password"
              inputMode="numeric"
              maxLength={6}
              value={newPinConfirm}
              onChange={(e) => setNewPinConfirm(digitsOnly(e.target.value))}
            />
          </div>
        </div>

        {newPinConfirm.length > 0 && newPin !== newPinConfirm && (
          <p className="text-xs text-red-600">PINs do not match.</p>
        )}
        {newPin.length === 6 && newPin === currentPin && (
          <p className="text-xs text-red-600">
            The new PIN must be different from your current one.
          </p>
        )}

        <Button onClick={() => pinMut.mutate()} disabled={!pinValid || pinMut.isPending}>
          {pinMut.isPending ? "Updating…" : "Update PIN"}
        </Button>
      </section>

      {/* Sessions */}
      <section className="p-6 bg-white rounded-sm border-[0.5px] border-primary/20 space-y-4">
        <div className="flex items-start gap-3">
          <LogOut className="size-5 text-primary mt-0.5" />
          <div>
            <Text title="Sessions" type="h5" className="text-black font-semibold" />
            <p className="text-sm text-black/60">
              Signed in as {admin?.fullName ?? admin?.phone ?? "this account"}.
              Signing out everywhere revokes every refresh token for your
              account, including this browser.
            </p>
          </div>
        </div>

        <Button
          variant="destructive"
          onClick={() => {
            if (
              window.confirm(
                "Sign out of all devices? You'll be returned to the login screen.",
              )
            ) {
              logoutAllMut.mutate();
            }
          }}
          disabled={logoutAllMut.isPending}
        >
          {logoutAllMut.isPending ? "Signing out…" : "Sign out of all devices"}
        </Button>

        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            The API has no endpoint that lists active sessions, so individual
            devices can't be shown or revoked one at a time yet.
          </AlertDescription>
        </Alert>
      </section>

      {/* 2FA — deliberately not faked */}
      <section className="p-6 bg-white rounded-sm border-[0.5px] border-primary/20 space-y-3">
        <Text
          title="Two-factor authentication"
          type="h5"
          className="text-black font-semibold"
        />
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Not available. The backend exposes no 2FA enrolment or verification
            endpoint, so there is nothing for a toggle here to call. Sign-in is
            protected by the PIN plus SMS OTP on new-device recovery.
          </AlertDescription>
        </Alert>
      </section>
    </div>
  );
};

export default SecurityAndAccessTab;
