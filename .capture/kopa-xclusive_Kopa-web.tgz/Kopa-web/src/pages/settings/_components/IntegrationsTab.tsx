import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, CircleDashed } from "lucide-react";
import { Skeleton } from "../../../components/ui/skeleton";
import { getIntegrations } from "../../../services/settings.service";
import { getApiErrorMessage } from "../../../utils/apiError";

/**
 * Read-only view of which providers this server is configured for
 * (GET /settings/integrations). Keys live in the server environment and
 * never reach the browser; this only says whether each one is set.
 */
const IntegrationsTab = () => {
  const query = useQuery({ queryKey: ["settings-integrations"], queryFn: getIntegrations, retry: false });

  if (query.isLoading) return <Skeleton className="h-72 w-full rounded-sm" />;
  if (query.isError || !query.data)
    return (
      <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
        {getApiErrorMessage(query.error, "Could not load integration status.")}
      </div>
    );

  const i = query.data;
  const rows = [
    {
      name: "Paystack",
      role: "Direct-debit mandates, monthly debits and vendor payouts",
      ok: i.paystack.configured,
      detail: i.paystack.configured ? (i.paystack.mode === "live" ? "Live mode" : i.paystack.mode === "test" ? "Test mode" : "Configured") : "Not configured",
      warn: i.environment === "production" && i.paystack.mode === "test",
    },
    { name: "CreditChek", role: "BVN, NIN and bank-account verification", ok: i.creditchek.configured },
    { name: i.email.provider, role: "Email (OTP, decisions, receipts)", ok: i.email.configured },
    { name: `SMS (${i.sms.provider})`, role: "SMS OTP and alerts", ok: i.sms.configured },
    { name: `Storage (${i.storage.provider})`, role: "KYC documents and product images", ok: i.storage.configured },
    { name: i.queue.provider, role: "Background jobs (emails, notifications)", ok: i.queue.configured },
  ];

  return (
    <div className="space-y-6">
      {i.defaultOtpEnabled && (
        <div className="flex items-start gap-2 bg-red-50 border border-red-200 text-red-800 text-sm rounded-sm p-4">
          <AlertTriangle className="size-4 mt-0.5 shrink-0" />
          <p>
            <strong>USE_DEFAULT_OTP is on.</strong> Every OTP check accepts the default code, so anyone with a
            phone number can sign in or recover a PIN. Turn it off before going live.
          </p>
        </div>
      )}
      <div className="bg-white border border-primary/20 rounded-sm divide-y divide-primary/10">
        {rows.map((r) => (
          <div key={r.name} className="flex items-center justify-between gap-4 p-4">
            <div>
              <p className="font-medium text-black text-sm">{r.name}</p>
              <p className="text-xs text-black/50">{r.role}</p>
            </div>
            <span
              className={`inline-flex items-center gap-1.5 text-xs font-medium ${
                r.warn ? "text-amber-700" : r.ok ? "text-primary" : "text-black/50"
              }`}
            >
              {r.warn ? <AlertTriangle className="size-4" /> : r.ok ? <CheckCircle2 className="size-4" /> : <CircleDashed className="size-4" />}
              {r.detail ?? (r.ok ? "Configured" : "Not configured")}
              {r.warn ? " — on a production server" : ""}
            </span>
          </div>
        ))}
      </div>
      <p className="text-xs text-black/50">
        Environment: <strong className="text-black">{i.environment}</strong>. Keys are set in the server's
        environment variables and never sent to the browser.
      </p>
    </div>
  );
};

export default IntegrationsTab;
