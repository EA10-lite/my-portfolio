import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { Avatar, AvatarFallback } from "../../../components/ui/avatar";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { useAdminStore } from "../../../stores/adminStore";
import { updateOwnProfile } from "../../../services/settings.service";
import { getApiErrorMessage } from "../../../utils/apiError";

const ROLE_LABELS: Record<string, string> = { super_admin: "Super Admin", admin: "Admin" };

/**
 * The signed-in admin's own account. Name is editable (PATCH /settings/profile);
 * phone is the login identity and email is verified at sign-up, so both are
 * shown read-only. PIN changes live under Security & Access.
 */
const ProfileTab = () => {
  const admin = useAdminStore((s) => s.admin);
  const setAdmin = useAdminStore((s) => s.setAdmin);
  const [fullName, setFullName] = useState(admin?.fullName ?? "");

  const initials = (admin?.fullName ?? "A")
    .split(" ")
    .map((w) => w.charAt(0))
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const mut = useMutation({
    mutationFn: () => updateOwnProfile(fullName.trim()),
    onSuccess: (res) => {
      if (admin) setAdmin({ ...admin, fullName: res?.fullName ?? fullName.trim() });
      toast.success("Profile updated");
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not update your profile.")),
  });

  const changed = fullName.trim() !== (admin?.fullName ?? "") && fullName.trim().length >= 2;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-5 p-6 bg-white border border-primary/20 rounded-sm">
        <Avatar className="w-16 h-16 border-2 border-primary/10">
          <AvatarFallback className="bg-primary/5 text-primary text-lg">{initials}</AvatarFallback>
        </Avatar>
        <div>
          <h2 className="text-xl font-semibold text-black">{admin?.fullName || "Admin"}</h2>
          <p className="text-sm text-black/60">
            {ROLE_LABELS[admin?.role ?? ""] ?? "Admin"}
            {admin?.status ? ` · ${admin.status}` : ""}
          </p>
        </div>
      </div>

      <form
        className="p-6 bg-white border border-primary/20 rounded-sm"
        onSubmit={(e) => {
          e.preventDefault();
          if (changed) mut.mutate();
        }}
      >
        <h3 className="text-lg font-medium text-black mb-4">Personal information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="fullName">Full name</Label>
            <Input id="fullName" value={fullName} maxLength={80} onChange={(e) => setFullName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email address</Label>
            <Input id="email" value={admin?.email ?? "—"} readOnly disabled />
            <p className="text-xs text-black/50">Verified at sign-up. Contact a super admin to change it.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone number</Label>
            <Input id="phone" value={admin?.phone ?? "—"} readOnly disabled />
            <p className="text-xs text-black/50">Your sign-in identity — it can't be changed here.</p>
          </div>
        </div>
        <div className="mt-6 flex justify-end">
          <Button type="submit" disabled={!changed || mut.isPending}>
            {mut.isPending ? "Saving…" : "Save changes"}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ProfileTab;
