import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQueries, useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import { Badge } from "../../components/ui/badge";
import {
  AlertTriangle,
  CheckCircle2,
  Clock4,
  Eye,
  KeyRound,
  Loader,
  RefreshCcw,
  Store,
  Wallet,
  X,
  XCircle,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { formatCurrency, formatDateString } from "../../utils/formatter";
import {
  getWithdrawals,
  STATUS_LABELS,
  type WithdrawalRow,
  type WithdrawalStatus,
} from "../../services/withdrawals.service";
import WithdrawalDecisionModal from "./_components/WithdrawalDecisionModal";

const STATUS_FILTER_OPTIONS = (Object.keys(STATUS_LABELS) as WithdrawalStatus[]).map((s) => ({
  label: STATUS_LABELS[s],
  value: s,
}));

const statusVariant = (s: WithdrawalStatus) => {
  if (s === "paid") return "default" as const;
  if (s === "rejected" || s === "failed" || s === "reversed") return "destructive" as const;
  if (s === "processing") return "new" as const;
  return "pending" as const;
};

/**
 * Vendor payouts. Money is reserved off the vendor's balance the moment they
 * request a payout, so every row here is money that is either waiting on an
 * admin, waiting on Paystack, or settled.
 *
 * URL params: ?status=…, ?flagged=1 (needs reconciliation),
 * ?vendorId=…&name=… (one vendor, linked from Vendors).
 */
const WithdrawalsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const status = searchParams.get("status") ?? "";
  const flagged = searchParams.get("flagged") === "1";
  const vendorId = searchParams.get("vendorId") ?? "";
  const vendorName = searchParams.get("name") ?? "";

  const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 20 });

  const setParams = (updates: Record<string, string>) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    setSearchParams(next, { replace: true });
    setPagination((p) => ({ ...p, pageIndex: 0 }));
  };

  const filters = {
    status,
    vendorId,
    ...(flagged ? { requiresReconciliation: true } : {}),
  };

  const query = useQuery({
    queryKey: ["admin-withdrawals", pagination.pageIndex, pagination.pageSize, filters],
    queryFn: () => getWithdrawals({ page: pagination.pageIndex + 1, limit: pagination.pageSize, ...filters }),
    retry: false,
  });

  const rows: WithdrawalRow[] = query.data?.withdrawals ?? [];
  const total = query.data?.meta?.total ?? 0;
  const totalPages = query.data?.meta?.totalPages ?? 1;

  // The four stages that need someone's attention, counted across all payouts.
  const QUEUES = [
    { key: "pending", label: "Awaiting approval", icon: <Clock4 className="size-4" />, params: { status: "pending" } },
    { key: "otp_pending", label: "Awaiting OTP", icon: <KeyRound className="size-4" />, params: { status: "otp_pending" } },
    { key: "processing", label: "With Paystack", icon: <Loader className="size-4" />, params: { status: "processing" } },
    { key: "flagged", label: "Needs reconciliation", icon: <AlertTriangle className="size-4" />, params: { requiresReconciliation: true } },
  ] as const;

  const countQueries = useQueries({
    queries: QUEUES.map((q) => ({
      queryKey: ["admin-withdrawals-count", q.key, vendorId],
      queryFn: () => getWithdrawals({ ...q.params, vendorId, page: 1, limit: 1 }),
      retry: false,
    })),
  });

  const columns: ColumnDef<WithdrawalRow>[] = useMemo(
    () => [
      {
        id: "vendor",
        header: "Vendor",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black font-medium">{row.original.vendor?.businessName ?? "—"}</span>
            <span className="text-xs text-black/50">{row.original.vendor?.kopaAccountNumber ?? ""}</span>
          </div>
        ),
      },
      {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ row }) => (
          <span className="text-black font-medium">{formatCurrency(row.original.amount ?? 0)}</span>
        ),
      },
      {
        id: "destination",
        header: "Destination",
        cell: ({ row }) => (
          <div className="flex flex-col">
            <span className="text-black">{row.original.accountName ?? row.original.bankName ?? "—"}</span>
            <span className="text-xs text-black/50">{row.original.maskedAccountNumber ?? ""}</span>
          </div>
        ),
      },
      {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
          const w = row.original;
          return (
            <div className="flex flex-wrap items-center gap-1.5">
              <Badge className="font-normal" variant={statusVariant(w.status)}>
                {STATUS_LABELS[w.status] ?? w.status}
              </Badge>
              {w.requiresReconciliation && (
                <Badge className="font-normal" variant="destructive">
                  Needs reconciliation
                </Badge>
              )}
            </div>
          );
        },
      },
      {
        accessorKey: "createdAt",
        header: "Requested",
        cell: ({ row }) => (
          <span className="text-black text-sm">
            {row.original.createdAt ? formatDateString(row.original.createdAt) : "—"}
          </span>
        ),
      },
      {
        id: "actions",
        header: "Action",
        cell: ({ row }) => {
          const w = row.original;
          const canReconcile = w.status === "processing" || Boolean(w.requiresReconciliation);
          return (
            <RowActions
              actions={[
                {
                  key: "approve",
                  label: "Review & approve",
                  icon: <CheckCircle2 className="size-4" />,
                  hidden: w.status !== "pending",
                  dialog: (p) => <WithdrawalDecisionModal withdrawal={w} {...p} />,
                },
                {
                  key: "otp",
                  label: "Enter OTP",
                  icon: <KeyRound className="size-4" />,
                  hidden: w.status !== "otp_pending",
                  dialog: (p) => <WithdrawalDecisionModal withdrawal={w} {...p} />,
                },
                {
                  key: "reconcile",
                  label: "Reconcile with Paystack",
                  icon: <RefreshCcw className="size-4" />,
                  hidden: !canReconcile,
                  dialog: (p) => <WithdrawalDecisionModal withdrawal={w} {...p} />,
                },
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  hidden: w.status === "pending" || w.status === "otp_pending" || canReconcile,
                  dialog: (p) => <WithdrawalDecisionModal withdrawal={w} {...p} />,
                },
                {
                  key: "vendor",
                  label: "This vendor's payouts",
                  icon: <Store className="size-4" />,
                  hidden: !w.vendor?._id || w.vendor._id === vendorId,
                  to: `/withdrawals?vendorId=${w.vendor?._id}&name=${encodeURIComponent(w.vendor?.businessName ?? "")}`,
                },
                {
                  key: "reject",
                  label: "Reject payout",
                  icon: <XCircle className="size-4" />,
                  destructive: true,
                  hidden: w.status !== "pending",
                  dialog: (p) => <WithdrawalDecisionModal withdrawal={w} initialMode="rejecting" {...p} />,
                },
              ]}
            />
          );
        },
      },
    ],
    [vendorId],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <Text title="Vendor Payouts" type="h4" className="text-lg text-black" />
          <ExportButton
            filename="vendor-payouts"
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getWithdrawals({ ...filters, page, limit });
              return { rows: res.withdrawals, totalPages: res.meta?.totalPages, total: res.meta?.total };
            }}
            columns={[
              { header: "Vendor", value: (r) => r.vendor?.businessName },
              { header: "Kopa Account", value: (r) => r.vendor?.kopaAccountNumber },
              { header: "Amount", value: (r) => r.amount },
              { header: "Account Name", value: (r) => r.accountName },
              { header: "Account Number", value: (r) => r.maskedAccountNumber },
              { header: "Status", value: (r) => STATUS_LABELS[r.status] ?? r.status },
              { header: "Needs Reconciliation", value: (r) => (r.requiresReconciliation ? "yes" : "") },
              { header: "Requested", value: (r) => r.createdAt },
              { header: "Paid", value: (r) => r.paidAt },
              { header: "Rejection / Failure Reason", value: (r) => r.rejectionReason ?? r.reason ?? r.failureReason },
              { header: "Paystack Reference", value: (r) => r.paystackReference },
            ]}
          />
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {vendorId && (
          <div className="flex items-center justify-between gap-3 bg-primary/5 border border-primary/15 text-sm text-black rounded-sm px-4 py-3">
            <span>
              Showing payouts for <strong>{vendorName || "one vendor"}</strong>
            </span>
            <button
              type="button"
              onClick={() => setParams({ vendorId: "", name: "" })}
              className="inline-flex items-center gap-1 text-black/60 hover:text-black"
            >
              <X className="size-4" /> All vendors
            </button>
          </div>
        )}

        {query.isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load payout requests. Check your connection and try again.
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {QUEUES.map((q, i) => {
            const count = countQueries[i].data?.meta?.total ?? 0;
            const active = q.key === "flagged" ? flagged : status === q.key && !flagged;
            const urgent = count > 0 && (q.key === "flagged" || q.key === "otp_pending");
            return (
              <button
                key={q.key}
                type="button"
                aria-pressed={active}
                onClick={() =>
                  q.key === "flagged"
                    ? setParams({ flagged: active ? "" : "1", status: "" })
                    : setParams({ status: active ? "" : q.key, flagged: "" })
                }
                className={cn(
                  "flex flex-col gap-2 rounded-sm border-[0.5px] p-4 text-left bg-white transition-colors hover:border-primary/40",
                  urgent ? (q.key === "flagged" ? "border-red-200 bg-red-50/60" : "border-amber-200 bg-amber-50/60") : "border-primary/10",
                  active && "ring-2 ring-primary/40",
                )}
              >
                <div className="flex items-center gap-2 text-sm text-black/70">
                  {q.icon}
                  <span>{q.label}</span>
                </div>
                <span className="text-2xl font-semibold text-black">{count.toLocaleString()}</span>
              </button>
            );
          })}
        </div>

        {flagged && (
          <div className="flex items-start gap-2 bg-red-50 border border-red-100 text-red-800 text-sm rounded-sm p-4">
            <Wallet className="size-4 mt-0.5 shrink-0" />
            <p>
              These payouts couldn't be confirmed either way, so the vendor's balance was deliberately not
              refunded. Reconcile each one to settle it from Paystack's record.
            </p>
          </div>
        )}

        <ReusableTable
          data={rows}
          columns={columns}
          filters={[{ columnKey: "status", title: "Status", options: STATUS_FILTER_OPTIONS }]}
          filterValues={{ status }}
          onFilterChange={(_, v) => setParams({ status: v, flagged: "" })}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={query.isLoading}
          rowCount={total}
          emptyMessage={
            flagged
              ? "Nothing needs reconciling."
              : status === "pending"
                ? "No payouts waiting for approval."
                : "No payout requests found."
          }
        />
      </div>
    </div>
  );
};

export default WithdrawalsPage;
