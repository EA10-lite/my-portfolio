import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Textarea } from "../../../components/ui/textarea";
import { Alert, AlertDescription } from "../../../components/ui/alert";
import { AlertCircle, AlertTriangle, KeyRound } from "lucide-react";
import {
  approveWithdrawal,
  finalizeWithdrawalOtp,
  MAX_OTP_ATTEMPTS,
  reconcileWithdrawal,
  rejectWithdrawal,
  resendWithdrawalOtp,
  STATUS_LABELS,
  type WithdrawalRow,
  type WithdrawalStatus,
} from "../../../services/withdrawals.service";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { getApiErrorMessage } from "../../../utils/apiError";
import { invalidateGroup } from "../../../lib/invalidate";

type Mode = "idle" | "rejecting" | "otp";

const REJECT_REASONS = [
  "Bank details could not be verified",
  "Amount does not match settled sales",
  "Account under review — please contact support",
];

/**
 * One modal for a payout's whole life:
 *
 *   pending      → Approve (hands it to Paystack) or Reject (refunds the vendor)
 *   approve      → if Paystack parks it for an OTP, we switch straight to the
 *                  OTP step — the OTP goes to the registered business owner,
 *                  who reads it to the admin
 *   otp_pending  → Submit OTP / resend it
 *   processing   → Reconcile with Paystack if no webhook has settled it
 *   flagged      → Reconcile (money may be in flight; the backend refuses to
 *                  refund on a guess)
 *
 * Approving never marks a payout paid — only Paystack's webhook (or a
 * reconcile against Paystack) does.
 */
const WithdrawalDecisionModal = ({
  withdrawal,
  triggerButton,
  open: openProp,
  onOpenChange,
  initialMode = "idle",
}: {
  withdrawal: WithdrawalRow;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  initialMode?: Mode;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  // Local copy so the modal can follow the payout through approve → OTP.
  const [status, setStatus] = useState<WithdrawalStatus>(withdrawal.status);
  const startMode: Mode = withdrawal.status === "otp_pending" ? "otp" : initialMode;
  const [mode, setMode] = useState<Mode>(startMode);
  const [reason, setReason] = useState("");
  const [otp, setOtp] = useState("");
  const [attempts, setAttempts] = useState(withdrawal.otpAttempts ?? 0);
  const qc = useQueryClient();

  const reset = () => {
    setReason("");
    setOtp("");
    setMode(startMode);
  };
  const close = () => {
    setOpen(false);
    reset();
  };
  const refresh = () => invalidateGroup(qc, "withdrawals");

  const approveMut = useMutation({
    mutationFn: () => approveWithdrawal(withdrawal._id),
    onSuccess: (res) => {
      refresh();
      if (res.requiresOtp) {
        setStatus("otp_pending");
        setAttempts(0);
        setMode("otp");
        toast.info(res.message ?? "Paystack sent an OTP to the business owner. Enter it to release the payout.");
        return;
      }
      toast.success(res.message ?? "Transfer initiated. It settles when Paystack confirms it.");
      close();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not approve this payout.")),
  });

  const otpMut = useMutation({
    mutationFn: () => finalizeWithdrawalOtp(withdrawal._id, otp.trim()),
    onSuccess: (res) => {
      toast.success(res.message ?? "OTP accepted. The payout settles when Paystack confirms it.");
      refresh();
      close();
    },
    onError: (e) => {
      setAttempts((a) => a + 1);
      setOtp("");
      toast.error(getApiErrorMessage(e, "Paystack rejected that OTP."));
      refresh();
    },
  });

  const resendMut = useMutation({
    mutationFn: () => resendWithdrawalOtp(withdrawal._id),
    onSuccess: (res) => {
      setAttempts(0);
      toast.success(res.message ?? "A new OTP has been sent to the business owner.");
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not resend the OTP.")),
  });

  const reconcileMut = useMutation({
    mutationFn: () => reconcileWithdrawal(withdrawal._id),
    onSuccess: (res) => {
      toast.success(
        res.status
          ? `Reconciled with Paystack — payout is now ${STATUS_LABELS[res.status as WithdrawalStatus]?.toLowerCase() ?? res.status}.`
          : "Reconciled with Paystack.",
      );
      refresh();
      close();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not reconcile this payout.")),
  });

  const rejectMut = useMutation({
    mutationFn: () => rejectWithdrawal(withdrawal._id, reason.trim()),
    onSuccess: () => {
      toast.success("Payout rejected — funds returned to the vendor's balance");
      refresh();
      close();
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not reject this payout.")),
  });

  const busy =
    approveMut.isPending || otpMut.isPending || resendMut.isPending || reconcileMut.isPending || rejectMut.isPending;
  const canReconcile =
    status === "processing" || status === "otp_pending" || Boolean(withdrawal.requiresReconciliation);
  const lockedOut = attempts >= MAX_OTP_ATTEMPTS;
  const terminal = ["paid", "rejected", "failed", "reversed"].includes(status);

  const title =
    mode === "otp"
      ? "Enter Paystack OTP"
      : mode === "rejecting"
        ? "Reject payout"
        : status === "pending"
          ? "Review payout request"
          : "Payout details";

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-md border border-primary/10 bg-secondary-foreground p-4 space-y-2 text-sm">
            <Row label="Vendor" value={withdrawal.vendor?.businessName ?? "—"} />
            <Row label="Amount" value={formatCurrency(withdrawal.amount ?? 0)} strong />
            <Row label="Account name" value={withdrawal.accountName ?? "—"} />
            <Row
              label="Account number"
              value={`${withdrawal.maskedAccountNumber ?? "—"}${withdrawal.bankName ? ` · ${withdrawal.bankName}` : ""}`}
            />
            <Row label="Status" value={STATUS_LABELS[status] ?? status} />
            {withdrawal.createdAt && <Row label="Requested" value={formatDateString(withdrawal.createdAt)} />}
            {withdrawal.transferInitiatedAt && (
              <Row label="Sent to Paystack" value={formatDateString(withdrawal.transferInitiatedAt)} />
            )}
            {withdrawal.paidAt && <Row label="Paid" value={formatDateString(withdrawal.paidAt)} />}
            {(withdrawal.rejectionReason ?? withdrawal.reason) && (
              <Row label="Rejection reason" value={String(withdrawal.rejectionReason ?? withdrawal.reason)} />
            )}
            {withdrawal.failureReason && <Row label="Failure reason" value={withdrawal.failureReason} />}
            {withdrawal.paystackReference && <Row label="Paystack ref" value={withdrawal.paystackReference} mono />}
          </div>

          {withdrawal.requiresReconciliation && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Paystack's response couldn't prove whether this transfer happened, so the vendor's
                balance was deliberately <strong>not</strong> refunded. Reconcile to settle it from
                Paystack's record.
                {withdrawal.reconciliationNote && <span className="block mt-1">{withdrawal.reconciliationNote}</span>}
              </AlertDescription>
            </Alert>
          )}

          {mode === "otp" && (
            <div className="space-y-3">
              <div className="flex gap-2 rounded-md bg-primary/5 p-3 text-sm text-black/70">
                <KeyRound className="size-4 mt-0.5 text-primary shrink-0" />
                <p>
                  Paystack sent a one-time code to the <strong>registered business owner's</strong> phone
                  and email — not to you. Get it from them and enter it to release this payout.
                </p>
              </div>
              <Input
                aria-label="Paystack OTP"
                inputMode="numeric"
                autoComplete="one-time-code"
                placeholder="Enter OTP"
                value={otp}
                maxLength={10}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                className="font-mono tracking-widest text-center text-lg h-11"
                disabled={lockedOut}
              />
              <div className="flex items-center justify-between text-xs">
                <span className={lockedOut ? "text-red-600" : "text-black/50"}>
                  {lockedOut
                    ? "Too many wrong attempts. Resend the OTP to try again."
                    : `${MAX_OTP_ATTEMPTS - attempts} attempt${MAX_OTP_ATTEMPTS - attempts === 1 ? "" : "s"} left`}
                </span>
                <button
                  type="button"
                  onClick={() => resendMut.mutate()}
                  disabled={busy}
                  className="text-primary font-medium hover:underline disabled:opacity-50"
                >
                  {resendMut.isPending ? "Resending…" : "Resend OTP"}
                </button>
              </div>
            </div>
          )}

          {mode === "rejecting" && (
            <div className="space-y-2">
              <label htmlFor="reject-reason" className="text-sm font-medium text-black">
                Reason for rejecting <span className="text-primary">*</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {REJECT_REASONS.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setReason(r)}
                    className={`text-xs px-2 py-1 rounded border ${
                      reason === r
                        ? "bg-primary/10 border-primary/40 text-primary"
                        : "bg-white border-primary/15 text-black/70 hover:bg-primary/5"
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
              <Textarea
                id="reject-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="The vendor sees this. Explain what they need to fix."
                rows={3}
              />
              <p className="text-xs text-black/50">
                Rejecting returns {formatCurrency(withdrawal.amount ?? 0)} to the vendor's available balance.
              </p>
            </div>
          )}

          {mode === "idle" && status === "pending" && (
            <p className="text-sm text-black/60">
              Approving hands a transfer of {formatCurrency(withdrawal.amount ?? 0)} to Paystack. If
              Paystack asks for an OTP, you'll be prompted for it next. The payout is only marked paid
              once Paystack confirms it.
            </p>
          )}

          {mode === "idle" && status === "processing" && !withdrawal.requiresReconciliation && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                With Paystack and waiting for confirmation. If it has been stuck for a while with no
                update, reconcile it to fetch the final result from Paystack.
              </AlertDescription>
            </Alert>
          )}

          {terminal && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This payout is {STATUS_LABELS[status].toLowerCase()}. No further action is possible.
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter className="gap-2">
          {mode === "otp" ? (
            <>
              {canReconcile && (
                <Button variant="outline" onClick={() => reconcileMut.mutate()} disabled={busy}>
                  {reconcileMut.isPending ? "Checking…" : "Check with Paystack"}
                </Button>
              )}
              <Button onClick={() => otpMut.mutate()} disabled={busy || lockedOut || otp.length < 4}>
                {otpMut.isPending ? "Releasing…" : "Release payout"}
              </Button>
            </>
          ) : mode === "rejecting" ? (
            <>
              <Button
                variant="outline"
                onClick={() => (initialMode === "rejecting" ? close() : setMode("idle"))}
                disabled={busy}
              >
                {initialMode === "rejecting" ? "Cancel" : "Back"}
              </Button>
              <Button
                variant="destructive"
                onClick={() => rejectMut.mutate()}
                disabled={busy || reason.trim().length === 0}
              >
                {rejectMut.isPending ? "Rejecting…" : "Confirm reject"}
              </Button>
            </>
          ) : status === "pending" ? (
            <>
              <Button variant="destructive" onClick={() => setMode("rejecting")} disabled={busy}>
                Reject
              </Button>
              <Button onClick={() => approveMut.mutate()} disabled={busy}>
                {approveMut.isPending ? "Sending to Paystack…" : `Approve ${formatCurrency(withdrawal.amount ?? 0)}`}
              </Button>
            </>
          ) : canReconcile ? (
            <>
              <Button variant="outline" onClick={close} disabled={busy}>
                Close
              </Button>
              <Button onClick={() => reconcileMut.mutate()} disabled={busy}>
                {reconcileMut.isPending ? "Checking with Paystack…" : "Reconcile with Paystack"}
              </Button>
            </>
          ) : (
            <Button variant="outline" onClick={close}>
              Close
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const Row = ({ label, value, strong, mono }: { label: string; value: string; strong?: boolean; mono?: boolean }) => (
  <div className="flex items-start justify-between gap-4">
    <span className="text-black/50">{label}</span>
    <span className={`text-black text-right ${strong ? "font-semibold" : "font-medium"} ${mono ? "font-mono text-xs" : ""}`}>
      {value}
    </span>
  </div>
);

export default WithdrawalDecisionModal;
