import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../../../../components/ui/dialog";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";
import { Label } from "../../../../components/ui/label";
import { Alert, AlertDescription } from "../../../../components/ui/alert";
import { AlertCircle } from "lucide-react";
import {
  startRecovery,
  completeRecovery,
} from "../../../../services/auth.service";
import { useAdminStore, isAdminRole } from "../../../../stores/adminStore";

const NGN_PHONE_REGEX = /^0[789]\d{9}$/;

/**
 * Admin PIN recovery. The backend has no email/password reset — the only
 * recovery path is POST /auth/recovery/start (SMS OTP) followed by
 * /auth/recovery/complete, which sets a new PIN and returns a live session.
 */
const RecoverPinModal = ({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) => {
  const [step, setStep] = useState<"phone" | "verify">("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [newPin, setNewPin] = useState("");
  const [newPinConfirm, setNewPinConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);

  const login = useAdminStore((s) => s.login);
  const navigate = useNavigate();

  const reset = () => {
    setStep("phone");
    setPhone("");
    setOtp("");
    setNewPin("");
    setNewPinConfirm("");
    setError(null);
  };

  const close = () => {
    reset();
    onClose();
  };

  const startMut = useMutation({
    mutationFn: () => startRecovery(phone.replace(/\s/g, "")),
    onSuccess: () => {
      toast.success("Verification code sent to your phone");
      setStep("verify");
      setError(null);
    },
    onError: (e: unknown) => {
      const err = e as { response?: { data?: { message?: string } } };
      setError(err.response?.data?.message ?? "Could not send a recovery code.");
    },
  });

  const completeMut = useMutation({
    mutationFn: () =>
      completeRecovery(phone.replace(/\s/g, ""), otp, newPin, newPinConfirm),
    onSuccess: (result) => {
      // Recovery returns a live session. Only let an admin through — a corper
      // resetting their PIN here must not land in the dashboard.
      if (!isAdminRole(result?.user?.role)) {
        setError("This account doesn't have dashboard access.");
        return;
      }
      login({
        user: result.user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
      });
      toast.success("PIN reset — you're signed in");
      close();
      navigate("/");
    },
    onError: (e: unknown) => {
      const err = e as { response?: { data?: { message?: string } } };
      setError(err.response?.data?.message ?? "Could not reset your PIN.");
    },
  });

  const phoneValid = NGN_PHONE_REGEX.test(phone.replace(/\s/g, ""));
  const verifyValid =
    /^\d{4,6}$/.test(otp) &&
    /^\d{6}$/.test(newPin) &&
    newPin === newPinConfirm;

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? undefined : close())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {step === "phone" ? "Reset your PIN" : "Enter verification code"}
          </DialogTitle>
        </DialogHeader>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {step === "phone" ? (
          <div className="space-y-4">
            <p className="text-sm text-black/60">
              We'll send a verification code by SMS to the phone number on your
              admin account.
            </p>
            <div className="space-y-2">
              <Label htmlFor="recovery-phone">Phone number</Label>
              <Input
                id="recovery-phone"
                inputMode="numeric"
                maxLength={11}
                placeholder="08012345678"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
              />
              {phone.length > 0 && !phoneValid && (
                <p className="text-xs text-red-600">
                  Enter a valid Nigerian phone number.
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-black/60">
              Enter the code sent to {phone} and choose a new 6-digit PIN.
            </p>
            <div className="space-y-2">
              <Label htmlFor="recovery-otp">Verification code</Label>
              <Input
                id="recovery-otp"
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="recovery-pin">New PIN</Label>
              <Input
                id="recovery-pin"
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ""))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="recovery-pin-confirm">Confirm new PIN</Label>
              <Input
                id="recovery-pin-confirm"
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={newPinConfirm}
                onChange={(e) =>
                  setNewPinConfirm(e.target.value.replace(/\D/g, ""))
                }
              />
              {newPinConfirm.length > 0 && newPin !== newPinConfirm && (
                <p className="text-xs text-red-600">PINs do not match.</p>
              )}
            </div>
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={close}>
            Cancel
          </Button>
          {step === "phone" ? (
            <Button
              onClick={() => startMut.mutate()}
              disabled={!phoneValid || startMut.isPending}
            >
              {startMut.isPending ? "Sending…" : "Send code"}
            </Button>
          ) : (
            <Button
              onClick={() => completeMut.mutate()}
              disabled={!verifyValid || completeMut.isPending}
            >
              {completeMut.isPending ? "Resetting…" : "Reset PIN"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RecoverPinModal;
