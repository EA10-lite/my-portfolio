import { Formik, Form } from "formik";
import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { FormField, Submit } from "../../../components/forms";
import { useAdminStore, isAdminRole } from "../../../stores/adminStore";
import { loginValidation } from "../../../utils/validation";
import { loginService } from "../../../services/auth.service";
import { toast } from "sonner";
import { Check, X, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "../../../components/ui/alert";
import RecoverPinModal from "./_components/RecoverPinModal";

type LoginValues = {
  phone: string;
  pin: string;
};

const initialValues: LoginValues = {
  phone: "",
  pin: "",
};

const LoginPage = () => {
  const login = useAdminStore((s) => s.login);
  const navigate = useNavigate();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
    const [showRecovery, setShowRecovery] = useState(false);
  // Set by the API client when a session can no longer be refreshed.
  const [searchParams] = useSearchParams();
  const sessionExpired = searchParams.get("session") === "expired";
  // Only same-app paths, so the param can't redirect off-site.
  const from = searchParams.get("from") ?? "";
  const returnTo = from.startsWith("/") && !from.startsWith("//") && !from.startsWith("/auth") ? from : "/";

  const handleSubmit = async (values: LoginValues) => {
    try {
      setErrorMsg(null);
      const result = await loginService({
        phone: values.phone.replace(/\s/g, ""),
        pin: values.pin,
      });

      const user = result?.user;

      if (!user || !result?.accessToken) {
        const msg = "Unexpected response from the server. Please try again.";
        setErrorMsg(msg);
        toast.error(msg, { icon: <X className="size-4 text-primary" /> });
        return;
      }

      // The same endpoint authenticates corpers and vendors, so the dashboard
      // has to reject non-admin roles itself.
      if (!isAdminRole(user.role)) {
        const msg = "This account doesn't have dashboard access.";
        setErrorMsg(msg);
        toast.error(msg, { icon: <X className="size-4 text-primary" /> });
        return;
      }

      login({
        user,
        accessToken: result.accessToken,
        refreshToken: result.refreshToken,
      });

      toast.success("Login successful", {
        icon: (
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 border-[0.5px] border-primary/10">
            <Check className="size-4 text-primary" />
          </div>
        ),
      });
            navigate(returnTo, { replace: true });
    } catch (error: unknown) {
      const err = error as {
        response?: { data?: { message?: string } };
        isNetworkError?: boolean;
        message?: string;
      };
      // A server that never answered is not a credentials problem — saying
      // "Invalid phone number or PIN" would send the admin hunting for a
      // typo that doesn't exist.
      const msg = err.isNetworkError
        ? (err.message ?? "Could not reach the server.")
        : err.response?.data?.message || "Invalid phone number or PIN";
      setErrorMsg(msg);
      toast.error(msg, { icon: <X className="size-4 text-primary" /> });
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-8 rounded-xl border border-border bg-card p-8 shadow-sm">
        <div className="space-y-1 text-center">
          <img src="/images/kopa-logo.png" alt="" className="mx-auto mb-3 h-20 w-auto" />
          <h1 className="text-2xl font-semibold text-foreground">
            Kopa Xclusive Admin
          </h1>
          <p className="text-sm text-black/60">
            Sign in with your phone number and PIN
          </p>
        </div>

                {sessionExpired && !errorMsg && (
          <Alert className="border-amber-200 bg-amber-50 text-amber-900">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Your session has expired</AlertTitle>
            <AlertDescription>Sign in again to pick up where you left off.</AlertDescription>
          </Alert>
        )}

        {errorMsg && (
          <Alert variant="destructive" className="animate-in fade-in slide-in-from-top-2 duration-300">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{errorMsg}</AlertDescription>
          </Alert>
        )}

        <Formik
          initialValues={initialValues}
          validationSchema={loginValidation}
          onSubmit={handleSubmit}
          // A server-side error describes the credentials that produced it, so
          // it must not outlive an edit to either field.
          validate={() => {
            setErrorMsg(null);
            return {};
          }}
        >
          {({ isSubmitting }) => (
            <Form className="space-y-4">
              <FormField
                label="Phone number"
                name="phone"
                type="tel"
                placeholder="08012345678"
                maxLength={11}
                inputMode="numeric"
                isMandatory
              />
              <FormField
                label="PIN"
                name="pin"
                type="password"
                placeholder="6-digit PIN"
                maxLength={6}
                inputMode="numeric"
                isMandatory
              />

              <div className="mt-4 flex items-center gap-3">
                <Submit title="Login" loading={isSubmitting} />
              </div>

              <button
                type="button"
                onClick={() => setShowRecovery(true)}
                className="w-full text-center text-sm text-primary hover:underline"
              >
                Forgot your PIN?
              </button>
            </Form>
          )}
        </Formik>
      </div>

      <RecoverPinModal open={showRecovery} onClose={() => setShowRecovery(false)} />
    </div>
  );
};

export default LoginPage;
