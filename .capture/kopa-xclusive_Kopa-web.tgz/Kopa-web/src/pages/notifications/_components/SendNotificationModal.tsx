import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Textarea } from "../../../components/ui/textarea";
import { sendNotification } from "../../../services/api.service";
import { getCorpers } from "../../../services/corpers.service";
import { getVendorsService } from "../../../services/vendors.service";
import { getAdmins } from "../../../services/admin.service";
import type { AdminCorper, AdminVendor } from "../../verification/page";
import type { AdminUserRow } from "../../admin-users/page";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { getApiErrorMessage } from "../../../utils/apiError";

type RecipientType = "corper" | "vendor" | "admin";

interface RecipientOption {
  userId: string;
  label: string;
}

const selectClassName =
  "h-9 w-full min-w-0 rounded-lg border border-input bg-transparent px-2.5 py-1 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50";

/**
 * Pass `recipient` to send to one known person (e.g. from a table row) — the
 * pickers are hidden and the message goes straight to that user id.
 */
const SendNotificationModal = ({
  triggerButton,
    recipient,
  defaultTitle = "",
  defaultBody = "",
  defaultType = "",
  open: openProp,
  onOpenChange,
}: {
  triggerButton?: React.ReactNode;
    recipient?: { userId: string; label: string };
  /** Prefill for templated messages, e.g. a repayment reminder. */
  defaultTitle?: string;
  defaultBody?: string;
  defaultType?: string;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [recipientType, setRecipientType] = useState<RecipientType>("corper");
  const [pickedUserId, setUserId] = useState("");
  const userId = recipient?.userId ?? pickedUserId;
  const [title, setTitle] = useState(defaultTitle);
  const [body, setBody] = useState(defaultBody);
  const [type, setType] = useState(defaultType);
  const qc = useQueryClient();

  const reset = () => {
    setRecipientType("corper");
    setUserId("");
        setTitle(defaultTitle);
    setBody(defaultBody);
    setType("");
  };

  // Fetch a working pool of possible recipients for the selected role. There is
  // no fuzzy/name search on these list endpoints (email is exact-match only),
  // so recipients are picked from this fetched set rather than searched.
  const corpersQuery = useQuery({
    queryKey: ["send-notification-corpers"],
    queryFn: () => getCorpers({ page: 1, limit: 100 }),
    enabled: open && !recipient && recipientType === "corper",
    retry: false,
  });
  const vendorsQuery = useQuery({
    queryKey: ["send-notification-vendors"],
    queryFn: () => getVendorsService({ page: 1, limit: 100 }),
    enabled: open && !recipient && recipientType === "vendor",
    retry: false,
  });
  const adminsQuery = useQuery({
    queryKey: ["send-notification-admins"],
    queryFn: () => getAdmins({ page: 1, limit: 100 }),
    enabled: open && !recipient && recipientType === "admin",
    retry: false,
  });

  const recipientOptions: RecipientOption[] = useMemo(() => {
    if (recipientType === "corper") {
      const corpers =
        (corpersQuery.data as { data?: { corpers?: AdminCorper[] } })?.data?.corpers ?? [];
      return corpers
        .filter((c) => c.user?._id)
        .map((c) => ({
          userId: c.user._id,
          label: `${c.fullName || c.user.fullName} — ${c.user.email}`,
        }));
    }
    if (recipientType === "vendor") {
      const vendors =
        (vendorsQuery.data as { data?: { vendors?: AdminVendor[] } })?.data?.vendors ?? [];
      return vendors
        .filter((v) => v.owner?._id)
        .map((v) => ({
          userId: v.owner._id,
          label: `${v.businessName} — ${v.owner.email}`,
        }));
    }
    const admins = (adminsQuery.data as { data?: { data?: AdminUserRow[] } })?.data?.data ?? [];
    return admins.map((a) => ({
      userId: a._id,
      label: `${a.fullName} — ${a.email}`,
    }));
  }, [recipientType, corpersQuery.data, vendorsQuery.data, adminsQuery.data]);

  const isLoadingRecipients =
    (recipientType === "corper" && corpersQuery.isLoading) ||
    (recipientType === "vendor" && vendorsQuery.isLoading) ||
    (recipientType === "admin" && adminsQuery.isLoading);

  const sendMut = useMutation({
    mutationFn: () => sendNotification({ userId, title, body, type: type || undefined }),
    onSuccess: () => {
      toast.success("Notification sent");
      qc.invalidateQueries({ queryKey: ["admin-notifications"] });
      qc.invalidateQueries({ queryKey: ["admin-notifications-count"] });
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Failed to send notification")),
  });

  const canSend = Boolean(userId && title.trim() && body.trim());

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-[460px] bg-secondary border border-primary/10 rounded-xl">
        <DialogHeader>
          <DialogTitle>Send notification</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 py-2">
          {recipient ? (
            <div className="rounded-md border border-primary/10 bg-white px-3 py-2 text-sm">
              <span className="text-black/50">To: </span>
              <span className="text-black font-medium">{recipient.label}</span>
            </div>
          ) : (
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-black/70">Recipient type</label>
              <select
                className={selectClassName}
                value={recipientType}
                onChange={(e) => {
                  setRecipientType(e.target.value as RecipientType);
                  setUserId("");
                }}
              >
                <option value="corper">Corps member</option>
                <option value="vendor">Vendor</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-black/70">Recipient</label>
              <select
                className={selectClassName}
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                disabled={isLoadingRecipients}
              >
                <option value="">
                  {isLoadingRecipients ? "Loading..." : "Select a recipient"}
                </option>
                {recipientOptions.map((opt) => (
                  <option key={opt.userId} value={opt.userId}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-medium text-black/70">Title (required)</label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Repayment due tomorrow" />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-black/70">Message (required)</label>
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} placeholder="Notification body" rows={3} />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-black/70">Type (optional)</label>
            <Input value={type} onChange={(e) => setType(e.target.value)} placeholder="e.g. payment, kyc, system" />
          </div>
        </div>

        <DialogFooter>
          <Button onClick={() => sendMut.mutate()} disabled={!canSend || sendMut.isPending}>
            {sendMut.isPending ? "Sending..." : "Send notification"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SendNotificationModal;
