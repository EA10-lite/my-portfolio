import { DetailsModal, ModalFieldItem } from "../../../components";
import type { AdminNotification } from "../page";
import { formatDateString } from "../../../utils/formatter";

const NotificationDetailsModal = ({
  notification,
  triggerButton,
  open,
  onOpenChange,
}: {
  notification: AdminNotification;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  return (
    <DetailsModal title="Notification Details" TriggerButton={triggerButton} open={open} onOpenChange={onOpenChange}>
      <div className="p-4 space-y-3">
        <ModalFieldItem label="Title" value={notification.title} />
        <ModalFieldItem label="Message" value={notification.body} />
        <ModalFieldItem
          label="Recipient"
          value={
            notification.recipient
              ? `${notification.recipient.fullName} (${notification.recipient.email})`
              : "Recipient not found"
          }
        />
        <ModalFieldItem label="Type" value={notification.type ? notification.type.replace(/_/g, " ") : "—"} />
        <ModalFieldItem label="Status" value={notification.read ? "Read" : "Unread"} />
        <ModalFieldItem label="Sent At" value={formatDateString(notification.createdAt)} />
      </div>
    </DetailsModal>
  );
};

export default NotificationDetailsModal;
