import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Megaphone } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Textarea } from "../../../components/ui/textarea";
import {
  AUDIENCE_LABELS,
  previewBroadcast,
  sendBroadcast,
  type BroadcastAudience,
} from "../../../services/notifications.service";
import { getApiErrorMessage } from "../../../utils/apiError";

const selectClass = "h-9 w-full rounded-md border border-input bg-white px-2 text-sm text-black";

/**
 * One message to a whole audience, in-app and as a push to their phones.
 * The count is shown before sending and the send is audited.
 */
const BroadcastModal = () => {
  const [open, setOpen] = useState(false);
  const [audience, setAudience] = useState<BroadcastAudience>("all_corpers");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const qc = useQueryClient();

  const preview = useQuery({
    queryKey: ["broadcast-preview", audience],
    queryFn: () => previewBroadcast(audience),
    enabled: open,
    retry: false,
  });
  const count = preview.data?.recipients;

  const send = useMutation({
    mutationFn: () => sendBroadcast({ audience, title: title.trim(), body: body.trim(), type: "announcement" }),
    onSuccess: (res) => {
      toast.success(`Sent to ${res?.recipients?.toLocaleString() ?? 0} people`);
      qc.invalidateQueries({ queryKey: ["admin-notifications"] });
      qc.invalidateQueries({ queryKey: ["admin-notifications-count"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
      setOpen(false);
      setTitle("");
      setBody("");
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not send the broadcast.")),
  });

  const ready = title.trim() && body.trim() && (count ?? 0) > 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger render={<Button variant="outline" className="rounded-sm px-4 bg-white text-black gap-2" />}>
        <Megaphone className="size-4" /> Broadcast
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg text-black">
        <DialogHeader>
          <DialogTitle>Broadcast a notification</DialogTitle>
          <DialogDescription>Goes to everyone in the audience, in the app and as a push to their phone.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <label htmlFor="bc-audience" className="text-xs text-black/60">
              Audience
            </label>
            <select
              id="bc-audience"
              className={selectClass}
              value={audience}
              onChange={(e) => setAudience(e.target.value as BroadcastAudience)}
            >
              {(Object.keys(AUDIENCE_LABELS) as BroadcastAudience[]).map((a) => (
                <option key={a} value={a}>
                  {AUDIENCE_LABELS[a]}
                </option>
              ))}
            </select>
            <p className="text-xs text-black/60" aria-live="polite">
              {preview.isLoading
                ? "Counting…"
                : preview.isError
                  ? getApiErrorMessage(preview.error, "Couldn't count this audience.")
                  : `${(count ?? 0).toLocaleString()} ${count === 1 ? "person" : "people"}`}
            </p>
          </div>
          <div className="space-y-1">
            <label htmlFor="bc-title" className="text-xs text-black/60">
              Title
            </label>
            <Input id="bc-title" maxLength={200} value={title} onChange={(e) => setTitle(e.target.value)} className="bg-white" />
          </div>
          <div className="space-y-1">
            <label htmlFor="bc-body" className="text-xs text-black/60">
              Message
            </label>
            <Textarea id="bc-body" rows={4} maxLength={2000} value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button disabled={!ready || send.isPending} onClick={() => send.mutate()}>
            {send.isPending ? "Sending…" : count ? `Send to ${count.toLocaleString()}` : "Send"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BroadcastModal;
