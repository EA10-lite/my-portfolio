import { useMemo, useState } from "react";
import { useQueries, useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ReusableTable, RowActions, Text } from "../../components";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { formatDateString } from "../../utils/formatter";
import { getAdminNotifications } from "../../services/api.service";
import { Eye, Bell, MailOpen, Mail, Send } from "lucide-react";
import { cn } from "../../lib/utils";
import NotificationDetailsModal from "./_components/NotificationDetailsModal";
import SendNotificationModal from "./_components/SendNotificationModal";
import BroadcastModal from "./_components/BroadcastModal";

export interface AdminNotificationRecipient {
  _id: string;
  fullName: string;
  email: string;
  role?: string;
}

export interface AdminNotification {
  _id: string;
  userId: string;
  title: string;
  body: string;
  read: boolean;
  type?: string;
  recipient: AdminNotificationRecipient | null;
  createdAt: string;
}

const kpiStyles = {
  total: "bg-blue-50 border-blue-100 text-blue-600",
  unread: "bg-yellow-50 border-yellow-100 text-yellow-600",
  read: "bg-green-50 border-green-100 text-green-600",
};

const NotificationsPage = () => {
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });

    // "read" | "unread" | "" — sent to the API as read=true/false so the
  // filter covers every notification, not just the loaded page.
  const [readFilter, setReadFilter] = useState("");

  const notificationsQuery = useQuery({
    queryKey: ["admin-notifications", pagination.pageIndex, pagination.pageSize, readFilter],
    queryFn: () =>
      getAdminNotifications({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        ...(readFilter ? { read: readFilter === "read" ? "true" : "false" } : {}),
      }),
    retry: false,
  });

  const countQueries = useQueries({
    queries: (["true", "false"] as const).map((read) => ({
      queryKey: ["admin-notifications-count", read],
      queryFn: () => getAdminNotifications({ read, page: 1, limit: 1 }),
      retry: false,
    })),
  });

  const countFor = (index: number) =>
    (countQueries[index].data as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0;

  const raw = (
    notificationsQuery.data as {
      data?: { data?: AdminNotification[]; unread?: number; meta?: { total?: number; totalPages?: number } };
    }
  )?.data;
  const rows: AdminNotification[] = raw?.data ?? [];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

    // Sum of the two unfiltered counts — `total` follows the read filter.
  const counts = {
    total: countFor(0) + countFor(1),
    read: countFor(0),
    unread: countFor(1),
  };

  const columns: ColumnDef<AdminNotification>[] = useMemo(
    () => [
      {
        accessorKey: "title",
        header: "Title",
        cell: ({ row }) => (
          <span className="text-black font-medium">{row.getValue("title")}</span>
        ),
      },
      {
        accessorKey: "body",
        header: "Message",
        cell: ({ row }) => (
          <span className="text-black/70 line-clamp-1 max-w-[240px]">{row.getValue("body")}</span>
        ),
      },
      {
        id: "recipient",
        header: "Recipient",
        cell: ({ row }) => {
          const recipient = row.original.recipient;
          return recipient ? (
            <div className="flex flex-col">
              <span className="text-black">{recipient.fullName}</span>
              <span className="text-black/50 text-xs">{recipient.email}</span>
            </div>
          ) : (
            <span className="text-black/40 text-xs italic">Recipient not found</span>
          );
        },
      },
      {
        accessorKey: "type",
        header: "Type",
        cell: ({ row }) => {
          const type = row.getValue("type") as string | undefined;
          return (
            <span className="text-black/70 capitalize">
              {type ? type.replace(/_/g, " ") : "—"}
            </span>
          );
        },
      },
      {
        id: "readStatus",
        header: "Status",
        // Derived string column ("read"/"unread") rather than filtering on the
        // raw boolean -- ReusableTable's client-side column filter compares
        // string filter values against the cell value, which never matches a
        // boolean (same pitfall fixed on the Risk & Collections page).
        accessorFn: (row) => (row.read ? "read" : "unread"),
        cell: ({ row }) => {
          const status = row.getValue("readStatus") as string;
          return (
            <Badge
              className="hover:bg-secondary-foreground/80 font-normal capitalize"
              variant={status === "read" ? "default" : "pending"}
            >
              {status}
            </Badge>
          );
        },
      },
      {
        accessorKey: "createdAt",
        header: "Date",
        cell: ({ row }) => (
          <span className="text-black">{formatDateString(row.getValue("createdAt"))}</span>
        ),
      },
      {
        id: "actions",
        header: "Action",
                cell: ({ row }) => {
          const n = row.original;
          const to = n.recipient?._id ?? n.userId;
          return (
            <RowActions
              actions={[
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  dialog: (p) => <NotificationDetailsModal notification={n} {...p} />,
                },
                {
                  key: "again",
                  label: "Send again",
                  icon: <Send className="size-4" />,
                  hidden: !to,
                  dialog: (p) => (
                    <SendNotificationModal
                      recipient={{
                        userId: String(to),
                        label: n.recipient
                          ? `${n.recipient.fullName} — ${n.recipient.email}`
                          : "Original recipient",
                      }}
                      defaultTitle={n.title}
                      defaultBody={n.body}
                      defaultType={n.type ?? ""}
                      {...p}
                    />
                  ),
                },
              ]}
            />
          );
        },
      },
    ],
    [],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <Text title="Notifications" type="h4" className="text-lg text-black" />
            <p className="text-sm text-black/60 mt-1">
              Every notification sent to admins, vendors, and corps members, and who received it.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <BroadcastModal />
            <SendNotificationModal
              triggerButton={
                <Button variant="default" className="rounded-sm px-4">
                  <Send className="size-4 mr-2" />
                  <span className="text-sm font-medium">New Notification</span>
                </Button>
              }
            />
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        <div className="metrics grid grid-cols-1 sm:grid-cols-3 gap-4">
          <PageMetric
            label="Total Notifications"
            value={counts.total.toString()}
            icon={<Bell className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="Unread"
            value={counts.unread.toString()}
            icon={<Mail className="size-4" />}
            className={kpiStyles.unread}
          />
          <PageMetric
            label="Read"
            value={counts.read.toString()}
            icon={<MailOpen className="size-4" />}
            className={kpiStyles.read}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          searchKeys={["title", "body"]}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={notificationsQuery.isLoading}
          rowCount={total}
          filters={[
            {
              columnKey: "readStatus",
              title: "Status",
                            options: [
                { label: "Read", value: "read" },
                { label: "Unread", value: "unread" },
              ],
            },
          ]}
          filterValues={{ readStatus: readFilter }}
          onFilterChange={(_, v) => {
            setReadFilter(v);
            setPagination((p) => ({ ...p, pageIndex: 0 }));
          }}
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
}) => (
  <div className="border-[0.5px] border-primary/20 bg-white rounded-sm p-4 space-y-3">
    <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", className)}>
      {icon}
    </div>
    <Text title={value} type="h2" className="text-2xl font-medium text-black" />
    <Text title={label} type="h4" className="text-black" />
  </div>
);

export default NotificationsPage;
