import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import type { CsvColumn } from "../../utils/csv";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { formatCurrency, formatDateString } from "../../utils/formatter";
import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import { useQueries, useQuery } from "@tanstack/react-query";
import { Badge } from "../../components/ui/badge";
import { Eye, Package, CheckCircle2, XCircle, Ban, RotateCcw, Store, X } from "lucide-react";
import { cn } from "../../lib/utils";
import { getAdminProducts } from "../../services/products.service";
import ProductDetailsModal from "./_components/ProductDetailsModal";
import ModerateProductModal from "./_components/ModerateProductModal";

export interface AdminProduct {
  _id: string;
  name: string;
  description?: string;
  price: number;
  category: string;
  images: string[];
  stock: number;
  status: "active" | "inactive" | "rejected";
  rejectionReason?: string;
  createdAt: string;
  vendor?: {
    _id: string;
    businessName: string;
    profileImage?: string;
    vendorCategory?: string;
    kybStatus?: string;
  };
}

const kpiStyles = {
  total: "bg-blue-50 border-blue-100 text-blue-600",
  active: "bg-green-50 border-green-100 text-green-600",
  inactive: "bg-gray-50 border-gray-100 text-gray-600",
  rejected: "bg-red-50 border-red-100 text-red-600",
};

const STATUS_FILTER_OPTIONS = [
  { label: "active", value: "active" },
  { label: "inactive", value: "inactive" },
  { label: "rejected", value: "rejected" },
];

/**
 * Products go live as soon as a vendor lists them; moderation here is after
 * the fact. `?vendorId=…&name=…` scopes the list to one vendor (linked from
 * the Vendors page) and `?status=` pre-filters.
 */
const ProductsPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const vendorId = searchParams.get("vendorId") ?? "";
  const vendorName = searchParams.get("name") ?? "";
  const status = searchParams.get("status") ?? "";

  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search.trim());
  const resetToFirstPage = () => setPagination((p) => ({ ...p, pageIndex: 0 }));

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value);
    else next.delete(key);
    if (key === "vendorId") next.delete("name");
    setSearchParams(next, { replace: true });
    resetToFirstPage();
  };

  const query = useQuery({
    queryKey: ["admin-products", pagination.pageIndex, pagination.pageSize, status, vendorId, debouncedSearch],
    queryFn: () =>
      getAdminProducts({
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        status,
        vendorId,
        search: debouncedSearch,
      }),
    retry: false,
  });

  const isError = query.isError;
  const raw = (query.data as { data?: { products?: AdminProduct[]; meta?: { total?: number; totalPages?: number } } })
    ?.data;
  const rows: AdminProduct[] = raw?.products ?? [];

  const exportColumns: CsvColumn<AdminProduct>[] = [
      { header: "Name", value: (r) => r.name },
      { header: "Vendor", value: (r) => r.vendor?.businessName },
      { header: "Category", value: (r) => r.category },
      { header: "Price", value: (r) => r.price },
      { header: "Stock", value: (r) => r.stock },
      { header: "Status", value: (r) => r.status },
      { header: "Created", value: (r) => r.createdAt },
  ];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

  // True counts across the whole catalog (not just the current page) —
  // each is a cheap limit:1 request that only reads back `meta.total`.
  const countQueries = useQueries({
    queries: (["active", "inactive", "rejected"] as const).map((status) => ({
      queryKey: ["admin-products-count", status, vendorId],
      queryFn: () => getAdminProducts({ status, vendorId, page: 1, limit: 1 }),
      retry: false,
    })),
  });
  const countFor = (index: number) =>
    (countQueries[index].data as { data?: { meta?: { total?: number } } })?.data?.meta?.total ?? 0;

  const counts = {
    total,
    active: countFor(0),
    inactive: countFor(1),
    rejected: countFor(2),
  };

  const columns: ColumnDef<AdminProduct>[] = useMemo(() => [
    {
      accessorKey: "name",
      header: "Product",
      cell: ({ row }) => {
        const p = row.original;
        return (
          <div className="flex items-center gap-2">
            {p.images?.[0] ? (
              <img src={p.images[0]} alt={p.name} className="w-8 h-8 rounded object-cover" />
            ) : (
              <div className="w-8 h-8 rounded bg-gray-100 flex items-center justify-center">
                <Package className="size-4 text-gray-400" />
              </div>
            )}
            <span className="text-black font-medium">{p.name}</span>
          </div>
        );
      },
    },
    {
      id: "vendor",
      header: "Vendor",
      cell: ({ row }) => (
        <span className="text-black">{row.original.vendor?.businessName ?? "-"}</span>
      ),
    },
    {
      accessorKey: "category",
      header: "Category",
      cell: ({ row }) => (
        <span className="text-black capitalize">{row.getValue("category")}</span>
      ),
    },
    {
      accessorKey: "price",
      header: "Price",
      cell: ({ row }) => (
        <span className="text-black">{formatCurrency(row.getValue("price"))}</span>
      ),
    },
    {
      accessorKey: "stock",
      header: "Stock",
      cell: ({ row }) => <span className="text-black">{row.getValue("stock")}</span>,
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        let badgeVariant: "default" | "pending" | "destructive" = "pending";
        if (status === "active") badgeVariant = "default";
        if (status === "rejected") badgeVariant = "destructive";
        return (
          <Badge className="font-normal capitalize" variant={badgeVariant}>
            {status}
          </Badge>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: "Created Date",
      cell: ({ row }) => (
        <span className="text-black">{formatDateString(row.getValue("createdAt"))}</span>
      ),
    },
    {
      id: "actions",
      header: "Action",
            cell: ({ row }) => {
        const p = row.original;
        return (
          <RowActions
            actions={[
              {
                key: "view",
                label: "View details",
                icon: <Eye className="size-4" />,
                dialog: (d) => <ProductDetailsModal product={p} {...d} />,
              },
              {
                key: "vendor",
                label: "More from this vendor",
                icon: <Store className="size-4" />,
                hidden: !p.vendor?._id || p.vendor._id === vendorId,
                to: `/products?vendorId=${p.vendor?._id}&name=${encodeURIComponent(p.vendor?.businessName ?? "")}`,
              },
              {
                key: "reinstate",
                label: "Reinstate listing",
                icon: <RotateCcw className="size-4" />,
                hidden: p.status !== "rejected",
                dialog: (d) => <ModerateProductModal product={p} intent="reinstate" {...d} />,
              },
              {
                key: "reject",
                label: "Reject listing",
                icon: <XCircle className="size-4" />,
                destructive: true,
                hidden: p.status === "rejected",
                dialog: (d) => <ModerateProductModal product={p} intent="reject" {...d} />,
              },
            ]}
          />
        );
      },
    },
  ], [vendorId]);

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <Text title="Products" type="h4" className="text-lg text-black" />
          <ExportButton
            filename="products"
            columns={exportColumns}
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getAdminProducts({ page, limit, status, vendorId, search: debouncedSearch });
              return { rows: res?.data?.products ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
            }}
          />
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
        {vendorId && (
          <div className="flex items-center justify-between gap-3 bg-primary/5 border border-primary/15 text-sm text-black rounded-sm px-4 py-3">
            <span>
              Showing products from <strong>{vendorName || "one vendor"}</strong>
            </span>
            <button
              type="button"
              onClick={() => setParam("vendorId", "")}
              className="inline-flex items-center gap-1 text-black/60 hover:text-black"
            >
              <X className="size-4" /> All vendors
            </button>
          </div>
        )}
        {isError && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load products from the server. Check your connection and try again.
          </div>
        )}

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total Products"
            value={counts.total.toLocaleString()}
            icon={<Package className="size-4" />}
            className={kpiStyles.total}
          />
          <PageMetric
            label="Active"
            value={counts.active.toLocaleString()}
            icon={<CheckCircle2 className="size-4" />}
            className={kpiStyles.active}
          />
          <PageMetric
            label="Hidden by vendor"
            value={counts.inactive.toLocaleString()}
            icon={<Ban className="size-4" />}
            className={kpiStyles.inactive}
          />
          <PageMetric
            label="Rejected"
            value={counts.rejected.toLocaleString()}
            icon={<XCircle className="size-4" />}
            className={kpiStyles.rejected}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          search={{
            value: search,
            onChange: (v) => {
              setSearch(v);
              resetToFirstPage();
            },
            placeholder: "Search product name or description",
          }}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={query.isLoading}
          rowCount={total}
          filters={[
            {
              columnKey: "status",
              title: "Status",
              options: STATUS_FILTER_OPTIONS,
            },
          ]}
          filterValues={{ status }}
          onFilterChange={setParam}
          emptyMessage={
            debouncedSearch || status || vendorId ? "No products match these filters." : "No products listed yet."
          }
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
}) => (
  <div className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3">
    <div
      className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]",
        className,
      )}
    >
      {icon}
    </div>
    <Text title={value} type="h2" className="text-2xl font-medium text-black" />
    <Text title={label} type="h4" className="text-black" />
  </div>
);

export default ProductsPage;
