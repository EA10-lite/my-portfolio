import { DetailsModal, ModalFieldItem } from "../../../components";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import type { AdminProduct } from "../page";

const ProductDetailsModal = ({
  product,
  triggerButton,
  open,
  onOpenChange,
}: {
  product: AdminProduct;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  return (
    <DetailsModal title="Product Details" TriggerButton={triggerButton} open={open} onOpenChange={onOpenChange}>
      <div className="p-4 space-y-3">
        {product.images?.[0] && (
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-40 object-cover rounded-md border border-primary/10"
          />
        )}
        <ModalFieldItem label="Product ID" value={product._id} />
        <ModalFieldItem label="Name" value={product.name} />
        <ModalFieldItem label="Description" value={product.description || "-"} />
        <ModalFieldItem label="Category" value={product.category} />
        <ModalFieldItem label="Price" value={formatCurrency(product.price)} />
        <ModalFieldItem label="Stock" value={String(product.stock)} />
        <ModalFieldItem label="Status" value={product.status} />
        {product.rejectionReason && (
          <ModalFieldItem label="Rejection Reason" value={product.rejectionReason} />
        )}
        <ModalFieldItem label="Vendor" value={product.vendor?.businessName || "-"} />
        <ModalFieldItem label="Vendor KYB" value={product.vendor?.kybStatus || "-"} />
        <ModalFieldItem label="Created At" value={formatDateString(product.createdAt)} />
      </div>
    </DetailsModal>
  );
};

export default ProductDetailsModal;
