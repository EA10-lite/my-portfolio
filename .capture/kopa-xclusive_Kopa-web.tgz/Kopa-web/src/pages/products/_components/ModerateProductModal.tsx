import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Textarea } from "../../../components/ui/textarea";
import { moderateProduct } from "../../../services/products.service";
import type { AdminProduct } from "../page";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { getApiErrorMessage } from "../../../utils/apiError";
import { invalidateGroup } from "../../../lib/invalidate";

const ModerateProductModal = ({
  product,
  triggerButton,
  open: openProp,
  intent,
  onOpenChange,
}: {
  product: AdminProduct;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** "reject" opens straight on the reason form; "reinstate" offers only re-listing. */
  intent?: "reject" | "reinstate";
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [reason, setReason] = useState("");
  const initialMode = intent === "reject" ? "rejecting" : "idle";
  const [mode, setMode] = useState<"idle" | "rejecting">(initialMode);
  const qc = useQueryClient();

  const reset = () => {
    setReason("");
    setMode(initialMode);
  };

  const approveMut = useMutation({
    mutationFn: () => moderateProduct(product._id, { action: "approve" }),
    onSuccess: () => {
      toast.success(`"${product.name}" is listed again`);
      invalidateGroup(qc, "products");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Approve failed")),
  });

  const rejectMut = useMutation({
    mutationFn: () => moderateProduct(product._id, { action: "reject", reason }),
    onSuccess: () => {
      toast.success(`"${product.name}" rejected`);
      invalidateGroup(qc, "products");
      setOpen(false);
      reset();
    },
    onError: (e: unknown) => toast.error(getApiErrorMessage(e, "Reject failed")),
  });

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      {triggerButton && <DialogTrigger render={triggerButton as React.ReactElement} />}
      <DialogContent className="sm:max-w-[425px] bg-secondary border border-primary/10 rounded-xl">
        <DialogHeader>
          <DialogTitle>
            {intent === "reinstate" ? "Reinstate listing" : intent === "reject" ? "Reject listing" : "Moderate product"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3 py-2">
          <p className="text-sm text-black/70">
            <span className="font-medium text-black">{product.name}</span> —{" "}
            {product.vendor?.businessName ?? "Unknown vendor"}
          </p>
          <p className="text-xs text-black/50">
            Current status: <span className="capitalize font-medium">{product.status}</span>
          </p>

          {product.rejectionReason && (
            <p className="text-xs text-black/50">
              Rejected because: <span className="text-black">{product.rejectionReason}</span>
            </p>
          )}

          {mode === "idle" && intent === "reinstate" && (
            <p className="text-sm text-black/60">
              Reinstating makes this product visible to corps members again and clears the
              rejection reason.
            </p>
          )}

          {mode === "rejecting" && (
            <div className="space-y-1">
              <label className="text-xs font-medium text-black/70">
                Reason for rejection (required, shown to the vendor)
              </label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. Product images are misleading / prohibited item"
                rows={3}
              />
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          {mode === "idle" ? (
            <>
              {intent !== "reinstate" && (
                <Button
                  variant="destructive"
                  onClick={() => setMode("rejecting")}
                  disabled={product.status === "rejected"}
                >
                  Reject
                </Button>
              )}
              {/* Only a rejected listing can be reinstated: approving an
                  "inactive" one would re-list something the vendor hid. */}
              <Button
                onClick={() => approveMut.mutate()}
                disabled={approveMut.isPending || product.status !== "rejected"}
              >
                {approveMut.isPending ? "Reinstating..." : "Reinstate listing"}
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={() => (intent === "reject" ? setOpen(false) : setMode("idle"))}
              >
                {intent === "reject" ? "Cancel" : "Back"}
              </Button>
              <Button
                variant="destructive"
                onClick={() => rejectMut.mutate()}
                disabled={rejectMut.isPending || !reason.trim()}
              >
                {rejectMut.isPending ? "Rejecting..." : "Confirm rejection"}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ModerateProductModal;
