import { DetailsModal, ModalFieldItem } from "../../../components";
import NotBackedBanner from "../../../components/main/NotBackedBanner";
import { Badge } from "../../../components/ui/badge";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import type { AdminPayment } from "../page";

const debitStatusVariant = (status: string) => {
  if (status === "debited") return "default" as const;
  if (status === "failed") return "destructive" as const;
  return "pending" as const;
};

const PaymentRiskDetailsModal = ({
  payment,
  triggerButton,
  open,
  onOpenChange,
}: {
  payment: AdminPayment;
  triggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  return (
    <DetailsModal title="Payment / Collections Detail" TriggerButton={triggerButton} open={open} onOpenChange={onOpenChange}>
      <div className="p-4 space-y-3">
        <NotBackedBanner variant="readonly" title="Read-only record">
          Use Log contact, Send repayment reminder or (for a failed debit) Retry debit from the row menu. Debits run automatically through the member's CreditChek mandate.
        </NotBackedBanner>
        <ModalFieldItem label="Payment Code" value={payment.paymentCode} />
        <ModalFieldItem label="Corps Member" value={payment.corper?.fullName ?? "-"} />
        <ModalFieldItem label="Vendor" value={payment.vendor?.businessName ?? "-"} />
        <ModalFieldItem label="Service Type" value={payment.serviceType} />
        <ModalFieldItem label="Amount" value={formatCurrency(payment.amount)} />
        <ModalFieldItem label="Payment Status" value={payment.status} />
        <ModalFieldItem
          label="Monthly Debit Status"
          content={
            <Badge className="font-normal capitalize w-fit" variant={debitStatusVariant(payment.monthlyDebitStatus)}>
              {payment.monthlyDebitStatus}
            </Badge>
          }
        />
        <ModalFieldItem label="Due Date" value={formatDateString(payment.monthlyDebitDueDate)} />
        {payment.monthlyDebitedAt && (
          <ModalFieldItem label="Debited At" value={formatDateString(payment.monthlyDebitedAt)} />
        )}
        {payment.monthlyDebitFailureReason && (
          <ModalFieldItem label="Failure Reason" value={payment.monthlyDebitFailureReason} />
        )}
        {typeof payment.availableCreditBeforeApproval === "number" && (
          <ModalFieldItem
            label="Available Credit Before"
            value={formatCurrency(payment.availableCreditBeforeApproval)}
          />
        )}
        {typeof payment.availableCreditAfterApproval === "number" && (
          <ModalFieldItem
            label="Available Credit After"
            value={formatCurrency(payment.availableCreditAfterApproval)}
          />
        )}
        {payment.receipt && (
          <ModalFieldItem
            label="Receipt Number"
            value={`${payment.receipt.receiptNumber} (${formatDateString(payment.receipt.issuedAt)})`}
          />
        )}
        <ModalFieldItem label="Created" value={formatDateString(payment.createdAt)} />
      </div>
    </DetailsModal>
  );
};

export default PaymentRiskDetailsModal;
