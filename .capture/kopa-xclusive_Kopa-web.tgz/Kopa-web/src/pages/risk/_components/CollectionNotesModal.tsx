import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import { Textarea } from "../../../components/ui/textarea";
import { Skeleton } from "../../../components/ui/skeleton";
import {
  addCollectionNote,
  getCollectionNotes,
  OUTCOME_LABELS,
  type CollectionOutcome,
} from "../../../services/collections.service";
import { useControllableOpen } from "../../../hooks/useControllableOpen";
import { formatCurrency, formatDateString } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";
import type { AdminPayment } from "../page";

/**
 * Collections contact log for one overdue / failed debit. Notes are
 * append-only and never change the payment or the debit — they're the
 * record of who chased what, and what the corps member said.
 */
const CollectionNotesModal = ({
  payment,
  open: openProp,
  onOpenChange,
}: {
  payment: AdminPayment;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const [open, setOpen] = useControllableOpen(openProp, onOpenChange);
  const [outcome, setOutcome] = useState<CollectionOutcome>("contacted");
  const [note, setNote] = useState("");
  const [promisedDate, setPromisedDate] = useState("");
  const qc = useQueryClient();

  const notesQuery = useQuery({
    queryKey: ["collection-notes", payment._id],
    queryFn: () => getCollectionNotes(payment._id),
    enabled: open,
    retry: false,
  });

  const mut = useMutation({
    mutationFn: () =>
      addCollectionNote({
        paymentId: payment._id,
        outcome,
        note: note.trim(),
        promisedDate: outcome === "promised_to_pay" && promisedDate ? promisedDate : undefined,
      }),
    onSuccess: () => {
      toast.success("Contact logged");
      setNote("");
      setPromisedDate("");
      qc.invalidateQueries({ queryKey: ["collection-notes", payment._id] });
      qc.invalidateQueries({ queryKey: ["collection-notes-latest"] });
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not save the note.")),
  });

  const notes = notesQuery.data ?? [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Collections log</DialogTitle>
          <DialogDescription>
            {payment.corper?.fullName ?? "Corps member"} · {formatCurrency(payment.amount ?? 0)}
            {payment.vendor?.businessName ? ` at ${payment.vendor.businessName}` : ""}
            {payment.monthlyDebitDueDate ? ` · due ${formatDateString(payment.monthlyDebitDueDate)}` : ""}
          </DialogDescription>
        </DialogHeader>

        <form
          className="space-y-3 rounded-md border border-primary/10 p-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (note.trim().length >= 2) mut.mutate();
          }}
        >
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="outcome">Outcome</Label>
              <select
                id="outcome"
                value={outcome}
                onChange={(e) => setOutcome(e.target.value as CollectionOutcome)}
                className="h-9 w-full rounded-lg border border-input bg-transparent px-2.5 text-sm"
              >
                {(Object.keys(OUTCOME_LABELS) as CollectionOutcome[]).map((o) => (
                  <option key={o} value={o}>
                    {OUTCOME_LABELS[o]}
                  </option>
                ))}
              </select>
            </div>
            {outcome === "promised_to_pay" && (
              <div className="space-y-1.5">
                <Label htmlFor="promised">Promised date</Label>
                <Input id="promised" type="date" value={promisedDate} onChange={(e) => setPromisedDate(e.target.value)} />
              </div>
            )}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="note">Note</Label>
            <Textarea
              id="note"
              rows={2}
              maxLength={1000}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Called at 2pm — salary lands on the 28th, will fund the account then."
            />
          </div>
          <div className="flex justify-end">
            <Button type="submit" size="sm" disabled={note.trim().length < 2 || mut.isPending}>
              {mut.isPending ? "Saving…" : "Log contact"}
            </Button>
          </div>
        </form>

        <div className="space-y-2">
          <p className="text-xs font-medium text-black/60">History</p>
          {notesQuery.isLoading ? (
            <Skeleton className="h-16 w-full" />
          ) : notesQuery.isError ? (
            <p className="text-sm text-red-700">{getApiErrorMessage(notesQuery.error, "Could not load notes.")}</p>
          ) : notes.length === 0 ? (
            <p className="text-sm text-black/50">No contact logged yet.</p>
          ) : (
            <ol className="space-y-2">
              {notes.map((n) => (
                <li key={n._id} className="rounded-md bg-secondary-foreground p-3 text-sm">
                  <div className="flex items-center justify-between gap-2 text-xs text-black/50">
                    <span className="font-medium text-black">{OUTCOME_LABELS[n.outcome] ?? n.outcome}</span>
                    <span>
                      {formatDateString(n.createdAt)}
                      {n.createdBy?.fullName ? ` · ${n.createdBy.fullName}` : ""}
                    </span>
                  </div>
                  <p className="mt-1 text-black/80 whitespace-pre-wrap">{n.note}</p>
                  {n.promisedDate && (
                    <p className="mt-1 text-xs text-primary">Promised by {formatDateString(n.promisedDate).split(",")[0]}</p>
                  )}
                </li>
              ))}
            </ol>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CollectionNotesModal;
