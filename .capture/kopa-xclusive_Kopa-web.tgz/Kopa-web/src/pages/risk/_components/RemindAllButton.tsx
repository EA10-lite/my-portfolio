import { useState } from "react";
import { toast } from "sonner";
import { BellRing } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { ConfirmDialog } from "../../../components";
import { getPayments, sendNotification } from "../../../services/api.service";
import { formatCurrency } from "../../../utils/formatter";
import { getApiErrorMessage } from "../../../utils/apiError";
import type { AdminPayment } from "../page";

const PAGE = 100;
const MAX_RECIPIENTS = 500;

/**
 * Sends one repayment reminder per corps member with an overdue or failed
 * debit — grouped, so someone with three overdue purchases gets one message
 * with the total, not three.
 */
const RemindAllButton = () => {
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  const collect = async () => {
    const all: AdminPayment[] = [];
    for (const riskStatus of ["overdue", "failed"]) {
      for (let page = 1; page <= 20; page++) {
        const res = await getPayments({ paymentStatus: "paid", riskStatus, page, limit: PAGE });
        const rows: AdminPayment[] = res?.data?.payments ?? [];
        all.push(...rows);
        if (rows.length < PAGE) break;
      }
    }
    const byUser = new Map<string, { name: string; total: number; count: number }>();
    for (const p of all) {
      if (!p.corperUser) continue;
      const cur = byUser.get(p.corperUser) ?? { name: p.corper?.fullName ?? "there", total: 0, count: 0 };
      cur.total += p.amount ?? 0;
      cur.count += 1;
      byUser.set(p.corperUser, cur);
    }
    return byUser;
  };

  const run = async () => {
    try {
      setStatus("Finding overdue debits…");
      const byUser = await collect();
      const recipients = Array.from(byUser.entries()).slice(0, MAX_RECIPIENTS);
      if (recipients.length === 0) {
        toast.info("Nobody has an overdue or failed debit right now.");
        return;
      }
      let sent = 0;
      let failed = 0;
      for (const [userId, r] of recipients) {
        setStatus(`Sending ${sent + failed + 1} of ${recipients.length}…`);
        try {
          await sendNotification({
            userId,
            type: "payment",
            title: "Repayment reminder",
            body: `Hi ${r.name.split(" ")[0]}, ${r.count === 1 ? "a repayment" : `${r.count} repayments`} totalling ${formatCurrency(r.total)} could not be collected. Please fund your linked account so the debit can go through.`,
          });
          sent++;
        } catch {
          failed++;
        }
      }
      if (failed) toast.warning(`Reminded ${sent} corps member${sent === 1 ? "" : "s"}; ${failed} failed to send.`);
      else toast.success(`Reminded ${sent} corps member${sent === 1 ? "" : "s"}.`);
      if (byUser.size > MAX_RECIPIENTS) toast.info(`Stopped at ${MAX_RECIPIENTS} recipients — run it again for the rest.`);
      setOpen(false);
    } catch (e) {
      toast.error(getApiErrorMessage(e, "Could not send reminders."));
    } finally {
      setStatus(null);
    }
  };

  return (
    <>
      <Button variant="outline" className="rounded-sm px-4 bg-white text-black" onClick={() => setOpen(true)}>
        <BellRing className="size-4 mr-2" /> Remind all overdue
      </Button>
      <ConfirmDialog
        open={open}
        onOpenChange={(v) => !status && setOpen(v)}
        title="Remind everyone with an overdue or failed debit?"
        description={
          status ??
          "Each corps member gets one in-app notification with the total they owe across all their overdue purchases."
        }
        confirmLabel="Send reminders"
        busy={status !== null}
        onConfirm={run}
      />
    </>
  );
};

export default RemindAllButton;
