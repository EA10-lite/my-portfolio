import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ConfirmDialog } from "../../../components";
import { retryDebit } from "../../../services/api.service";
import { getApiErrorMessage } from "../../../utils/apiError";
import { formatCurrency } from "../../../utils/formatter";
import type { AdminPayment } from "../page";

/**
 * Re-sends a FAILED monthly debit to the member's active mandate. The server
 * refuses anything not definitively failed, so a debit that might already
 * have been taken can't be charged twice.
 */
const RetryDebitDialog = ({
  payment,
  open,
  onOpenChange,
}: {
  payment: AdminPayment;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) => {
  const qc = useQueryClient();
  const mut = useMutation({
    mutationFn: () => retryDebit(payment._id),
    onSuccess: (res) => {
      const status = res?.monthlyDebitStatus;
      if (status === "debited") toast.success("Debit collected");
      else if (status === "processing") toast.success("Debit sent. CreditChek will confirm the outcome");
      else if (status === "failed") toast.error(`Debit failed again: ${res?.monthlyDebitFailureReason ?? "declined"}`);
      else toast.success("Debit retried");
      qc.invalidateQueries({ queryKey: ["admin-risk-payments"] });
      qc.invalidateQueries({ queryKey: ["admin-risk-summary"] });
      qc.invalidateQueries({ queryKey: ["admin-audit-logs"] });
      onOpenChange(false);
    },
    onError: (e) => toast.error(getApiErrorMessage(e, "Could not retry the debit.")),
  });

  return (
    <ConfirmDialog
      open={open}
      onOpenChange={onOpenChange}
      title={`Retry debit for ${payment.paymentCode}?`}
      description={
        <>
          This asks the member's bank to collect <b>{formatCurrency(payment.amount)}</b> now through their active direct-debit mandate.
          {payment.monthlyDebitFailureReason ? ` Last failure: ${payment.monthlyDebitFailureReason}.` : ""} Make sure the member has
          funded their account first.
        </>
      }
      confirmLabel="Retry debit"
      busy={mut.isPending}
      onConfirm={() => mut.mutate()}
    />
  );
};

export default RetryDebitDialog;
