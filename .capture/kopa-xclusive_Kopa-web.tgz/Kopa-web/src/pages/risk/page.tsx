import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { ExportButton, ReusableTable, RowActions, Text } from "../../components";
import SendNotificationModal from "../notifications/_components/SendNotificationModal";
import type { CsvColumn } from "../../utils/csv";
import { Badge } from "../../components/ui/badge";
import { cn } from "../../lib/utils";
import { formatCurrency, formatDateString } from "../../utils/formatter";
import { getPayments, getRiskSummary } from "../../services/api.service";
import { Activity, AlertTriangle, ArrowDownCircle, BellRing, Clock, Eye, NotebookPen, RotateCcw, Scale, User } from "lucide-react";
import PaymentRiskDetailsModal from "./_components/PaymentRiskDetailsModal";
import CollectionNotesModal from "./_components/CollectionNotesModal";
import RemindAllButton from "./_components/RemindAllButton";
import RetryDebitDialog from "./_components/RetryDebitDialog";
import LogDisputeModal from "../disputes/_components/LogDisputeModal";
import { getLatestCollectionNotes, OUTCOME_LABELS } from "../../services/collections.service";
import { formatTime } from "../../utils/formatter";
import NotBackedBanner from "../../components/main/NotBackedBanner";

export interface AdminPayment {
  _id: string;
  paymentCode: string;
  serviceType: string;
  /** vendor = paid a vendor; bill = airtime/data/TV/power; order = marketplace order. */
  source?: "vendor" | "bill" | "order";
  amount: number;
  status: string;
  monthlyDebitStatus: "scheduled" | "processing" | "debited" | "failed";
  monthlyDebitDueDate: string;
  monthlyDebitedAt?: string;
  monthlyDebitFailureReason?: string;
  availableCreditBeforeApproval?: number;
  availableCreditAfterApproval?: number;
  createdAt: string;
  receipt?: { receiptNumber: string; issuedAt: string };
    corper?: { _id: string; fullName: string; stateCode?: string };
  /** The corps member's user id (unpopulated) — used to notify them. */
  corperUser?: string;
  vendor?: { _id: string; businessName: string; vendorCategory?: string };
}

interface RiskSummary {
  totalExposure: number;
  outstandingAmount: number;
  collectedAmount: number;
  scheduled: { count: number; amount: number };
  processing: { count: number; amount: number };
  overdue: { count: number; amount: number };
  defaulted: { count: number; amount: number };
  debited: { count: number; amount: number };
}

const kpiStyles = {
  totalExposure: "bg-orange-50 border-orange-100 text-orange-600",
  outstanding: "bg-red-50 border-red-100 text-red-600",
  inMonitoring: "bg-sky-50 border-sky-100 text-sky-600",
  inDefault: "bg-rose-50 border-rose-100 text-rose-600",
};

const debitStatusVariant = (status: string) => {
  if (status === "debited") return "default" as const;
  if (status === "failed") return "destructive" as const;
  return "pending" as const;
};

const RISK_FILTER_OPTIONS = [
  { label: "scheduled", value: "scheduled" },
  { label: "processing", value: "processing" },
  { label: "overdue", value: "overdue" },
  { label: "debited", value: "debited" },
  { label: "failed", value: "failed" },
];

const RiskPage = () => {
  const [pagination, setPagination] = useState<PaginationState>({
    pageIndex: 0,
    pageSize: 20,
  });

  // Collections risk only exists once a payment has actually been paid to
  // the vendor — that's what schedules the monthly debit back from Kopa.
    // `?riskStatus=overdue` pre-filters (linked from the dashboard).
  const [searchParams] = useSearchParams();
  const [riskStatus, setRiskStatus] = useState(searchParams.get("riskStatus") ?? "");

  // The collection-status filter runs on the server (the API also resolves
  // the derived "overdue" bucket), so it covers every payment, not one page.
  const paymentsQuery = useQuery({
    queryKey: ["admin-risk-payments", pagination.pageIndex, pagination.pageSize, riskStatus],
    queryFn: () =>
      getPayments({
        paymentStatus: "paid",
        page: pagination.pageIndex + 1,
        limit: pagination.pageSize,
        ...(riskStatus ? { riskStatus } : {}),
      }),
    retry: false,
  });

  const summaryQuery = useQuery({
    queryKey: ["admin-risk-summary"],
    queryFn: () => getRiskSummary(),
    retry: false,
  });

    const raw = (paymentsQuery.data as { data?: { payments?: AdminPayment[]; meta?: { total?: number; totalPages?: number } } })?.data;
  const rows: AdminPayment[] = raw?.payments ?? [];

  // Latest collections note for each payment on this page ("Last contact").
  const pageIds = rows.map((r) => r._id);
  const notesQuery = useQuery({
    queryKey: ["collection-notes-latest", pageIds],
    queryFn: () => getLatestCollectionNotes(pageIds),
    enabled: pageIds.length > 0,
    retry: false,
  });
    const latestNote = useMemo(
    () => new Map((notesQuery.data ?? []).map((n) => [String(n.paymentId), n])),
    [notesQuery.data],
  );

  const exportColumns: CsvColumn<AdminPayment>[] = [
      { header: "Payment Code", value: (r) => r.paymentCode },
      { header: "Service", value: (r) => r.serviceType },
      { header: "Amount", value: (r) => r.amount },
      { header: "Status", value: (r) => r.status },
      { header: "Debit Status", value: (r) => r.monthlyDebitStatus },
      { header: "Due Date", value: (r) => r.monthlyDebitDueDate },
      { header: "Debited At", value: (r) => r.monthlyDebitedAt },
      { header: "Failure Reason", value: (r) => r.monthlyDebitFailureReason },
  ];
  const total = raw?.meta?.total ?? 0;
  const totalPages = raw?.meta?.totalPages ?? 1;

  const summary = (summaryQuery.data as { data?: RiskSummary })?.data;

  const columns: ColumnDef<AdminPayment>[] = useMemo(
    () => [
      {
        id: "corper",
        header: "Corps Member",
        cell: ({ row }) => <span className="text-black">{row.original.corper?.fullName ?? "-"}</span>,
      },
      {
        id: "vendor",
        header: "Vendor",
        cell: ({ row }) => {
          const p = row.original;
          if (p.source === "bill") {
            return <span className="text-black">Bill <span className="text-black/50 capitalize">· {p.serviceType}</span></span>;
          }
          return (
            <span className="text-black">
              {p.vendor?.businessName ?? "-"}
              {p.source === "order" && <span className="text-black/50"> · order</span>}
            </span>
          );
        },
      },
      {
        accessorKey: "amount",
        header: "Amount",
        cell: ({ row }) => (
          <span className="text-black font-medium">{formatCurrency(row.getValue("amount"))}</span>
        ),
      },
      {
        id: "riskBucket",
        header: "Collection Status",
        // Filtered on directly (rather than the raw monthlyDebitStatus)
        // so the "overdue" bucket — scheduled/processing past its due
        // date — is something the status filter can actually match,
        // since it isn't a real stored enum value.
        accessorFn: (p) => {
          const dueDate = new Date(p.monthlyDebitDueDate);
          const isPastDue =
            (p.monthlyDebitStatus === "scheduled" || p.monthlyDebitStatus === "processing") &&
            dueDate < new Date();
          return isPastDue ? "overdue" : p.monthlyDebitStatus;
        },
        cell: ({ row }) => {
          const bucket = row.getValue("riskBucket") as string;
          const status = row.original.monthlyDebitStatus;
          return (
            <div className="flex items-center gap-1.5">
              <Badge className="font-normal capitalize" variant={debitStatusVariant(status)}>
                {status}
              </Badge>
              {bucket === "overdue" && (
                <Badge className="font-normal" variant="destructive">
                  overdue
                </Badge>
              )}
            </div>
          );
        },
      },
      {
                id: "lastContact",
        header: "Last contact",
        cell: ({ row }) => {
          const n = latestNote.get(row.original._id);
          if (!n) return <span className="text-black/40 text-xs">—</span>;
          return (
            <div className="flex flex-col max-w-48">
              <span className="text-sm text-black">{OUTCOME_LABELS[n.outcome] ?? n.outcome}</span>
              <span className="text-xs text-black/50">
                {formatTime(n.createdAt)}
                {n.count > 1 ? ` · ${n.count} notes` : ""}
              </span>
            </div>
          );
        },
      },
      {
        accessorKey: "monthlyDebitDueDate",
        header: "Due Date",
        cell: ({ row }) => (
          <span className="text-black">{formatDateString(row.getValue("monthlyDebitDueDate"))}</span>
        ),
      },
      {
        id: "resolution",
        header: "Debited / Failure",
        cell: ({ row }) => {
          const p = row.original;
          if (p.monthlyDebitStatus === "debited" && p.monthlyDebitedAt) {
            return <span className="text-black">{formatDateString(p.monthlyDebitedAt)}</span>;
          }
          if (p.monthlyDebitStatus === "processing" && p.monthlyDebitFailureReason?.startsWith("Debit outcome unknown")) {
            return <span className="text-xs text-amber-700">Awaiting confirmation from CreditChek (checked hourly)</span>;
          }
          if (p.monthlyDebitFailureReason) {
            return <span className="text-xs text-destructive">{p.monthlyDebitFailureReason}</span>;
          }
          return <span className="text-black/40">-</span>;
        },
      },
      {
        id: "actions",
        header: "Action",
                cell: ({ row }) => {
          const p = row.original;
          const bucket = row.getValue("riskBucket") as string;
          const needsChasing = bucket === "overdue" || p.monthlyDebitStatus === "failed";
          const due = p.monthlyDebitDueDate ? formatDateString(p.monthlyDebitDueDate) : "the due date";
          return (
            <RowActions
              actions={[
                {
                  key: "view",
                  label: "View details",
                  icon: <Eye className="size-4" />,
                  dialog: (d) => <PaymentRiskDetailsModal payment={p} {...d} />,
                },
                {
                  key: "member",
                  label: "View member",
                  icon: <User className="size-4" />,
                  hidden: !p.corper?._id,
                  to: `/corpers/${p.corper?._id}`,
                },
                                {
                  key: "log",
                  label: "Log contact",
                  icon: <NotebookPen className="size-4" />,
                  hidden: p.monthlyDebitStatus === "debited",
                  dialog: (d) => <CollectionNotesModal payment={p} {...d} />,
                },
                {
                  key: "dispute",
                  label: "Log dispute",
                  icon: <Scale className="size-4" />,
                  hidden: !p.paymentCode,
                  dialog: (d) => <LogDisputeModal initialCode={p.paymentCode} open={d.open} onOpenChange={d.onOpenChange} />,
                },
                {
                  key: "retry",
                  label: "Retry debit",
                  icon: <RotateCcw className="size-4" />,
                  hidden: p.monthlyDebitStatus !== "failed",
                  dialog: (d) => <RetryDebitDialog payment={p} open={d.open} onOpenChange={d.onOpenChange} />,
                },
                {
                  key: "remind",
                  label: "Send repayment reminder",
                  icon: <BellRing className="size-4" />,
                  hidden: !needsChasing || !p.corperUser,
                  dialog: (d) => (
                    <SendNotificationModal
                      recipient={{
                        userId: String(p.corperUser),
                        label: p.corper?.fullName ?? "Corps member",
                      }}
                      defaultTitle="Repayment reminder"
                      defaultBody={`Hi ${p.corper?.fullName?.split(" ")[0] ?? "there"}, your repayment of ${formatCurrency(p.amount ?? 0)} for ${p.vendor?.businessName ?? "your purchase"} was due on ${due} and has not been collected. Please fund your linked account so the debit can go through.`}
                      defaultType="payment"
                      {...d}
                    />
                  ),
                },
              ]}
            />
          );
        },
      },
    ],
    [latestNote],
  );

  return (
    <div className="w-full">
      <div className="page-header">
        <div className="flex items-center justify-between flex-wrap gap-3">
                    <Text title="Risk & Collections" type="h4" className="text-lg text-black" />
          <div className="flex items-center gap-2 flex-wrap">
          <RemindAllButton />
          <ExportButton
            filename="risk-collections"
            columns={exportColumns}
            disabled={total === 0}
            fetchPage={async (page, limit) => {
              const res = await getPayments({ paymentStatus: "paid", page, limit, ...(riskStatus ? { riskStatus } : {}) });
                            return { rows: res?.data?.payments ?? [], totalPages: res?.data?.meta?.totalPages, total: res?.data?.meta?.total };
            }}
          />
          </div>
        </div>
      </div>

      <div className="page-body mt-6 space-y-6">
                <NotBackedBanner variant="readonly" title="What you can do here">
          Debits run automatically through each member's CreditChek direct-debit mandate. You can remind members (one at a time or
          everyone overdue), log every contact attempt, and retry a debit that failed. A debit still waiting for CreditChek's answer can't
          be retried: it settles on its own, so nobody is charged twice.
        </NotBackedBanner>
        {(paymentsQuery.isError || summaryQuery.isError) && (
          <div className="bg-red-50 border border-red-100 text-red-700 text-sm rounded-sm p-4">
            Could not load risk data from the server. Check your connection and try again.
          </div>
        )}

        <p className="text-xs text-black/40">
          Collections risk tracks the monthly debit Kopa collects from a corps member after a
          purchase has already been paid out to the vendor. Monthly debit processing runs
          automatically; this view is for monitoring, not manual intervention.
        </p>

        <div className="metrics grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <PageMetric
            label="Total Exposure"
            value={formatCurrency(summary?.totalExposure ?? 0)}
            icon={<Activity className="size-4" />}
            className={kpiStyles.totalExposure}
          />
          <PageMetric
            label="Outstanding Balance"
            value={formatCurrency(summary?.outstandingAmount ?? 0)}
            icon={<AlertTriangle className="size-4" />}
            className={kpiStyles.outstanding}
          />
          <PageMetric
            label="Overdue Accounts"
            value={(summary?.overdue.count ?? 0).toLocaleString()}
            icon={<Clock className="size-4" />}
            className={kpiStyles.inMonitoring}
          />
          <PageMetric
            label="Defaults (Failed)"
            value={(summary?.defaulted.count ?? 0).toLocaleString()}
            icon={<ArrowDownCircle className="size-4" />}
            className={kpiStyles.inDefault}
          />
        </div>

        <ReusableTable
          data={rows}
          columns={columns}
          searchKeys={["paymentCode"]}
          manualPagination={true}
          pageCount={totalPages}
          pagination={pagination}
          onPaginationChange={setPagination}
          isLoading={paymentsQuery.isLoading}
          rowCount={total}
          filters={[
            {
              columnKey: "riskBucket",
              title: "Collection Status",
                            options: RISK_FILTER_OPTIONS,
            },
          ]}
          filterValues={{ riskBucket: riskStatus }}
          onFilterChange={(_, v) => {
            setRiskStatus(v);
            setPagination((p) => ({ ...p, pageIndex: 0 }));
          }}
        />
      </div>
    </div>
  );
};

const PageMetric = ({
  label,
  value,
  icon,
  className,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  className: string;
}) => (
  <div className="border-[0.5px] border-primary/8 bg-white rounded-sm p-4 space-y-3">
    <div
      className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center border-[0.5px]",
        className,
      )}
    >
      {icon}
    </div>
    <Text title={value} type="h2" className="text-2xl font-medium text-black" />
    <Text title={label} type="h4" className="text-black" />
  </div>
);

export default RiskPage;
