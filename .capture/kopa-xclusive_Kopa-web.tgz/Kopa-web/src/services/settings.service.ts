import client from "./client.service";

export interface PlatformSettings {
    defaultCreditLimit: number;
    maxCreditLimit: number;
    creditLimitPresets: number[];
    supportEmail: string;
    supportPhone: string;
    termsUrl: string;
    privacyUrl: string;
    updatedAt?: string;
    updatedBy?: { fullName?: string; email?: string } | string;
}

export interface Integrations {
    environment: string;
    paystack: { configured: boolean; mode: "live" | "test" | null };
    creditchek: { configured: boolean };
    email: { configured: boolean; provider: string };
    sms: { configured: boolean; provider: string };
    storage: { configured: boolean; provider: string };
    queue: { configured: boolean; provider: string };
    defaultOtpEnabled: boolean;
}

const data = <T>(res: { data?: { data?: T } }) => res.data?.data as T;

/** GET /settings — any approved admin. */
export const getSettings = async () => data<PlatformSettings>(await client.get("/settings"));

/** PATCH /settings — super admin only; audited server-side. */
export const updateSettings = async (patch: Partial<PlatformSettings>) =>
    data<PlatformSettings>(await client.patch("/settings", patch));

/** GET /settings/integrations — super admin; booleans only, never keys. */
export const getIntegrations = async () => data<Integrations>(await client.get("/settings/integrations"));

/** PATCH /settings/profile — rename yourself. */
export const updateOwnProfile = async (fullName: string) =>
    data<{ _id: string; fullName: string }>(await client.patch("/settings/profile", { fullName }));
