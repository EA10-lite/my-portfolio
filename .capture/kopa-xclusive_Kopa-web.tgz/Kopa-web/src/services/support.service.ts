import client from "./client.service";

export type TicketStatus = "open" | "pending" | "resolved" | "closed";
export type TicketPriority = "low" | "medium" | "high";
export type TicketCategory = "account" | "kyc" | "loan" | "payment" | "payout" | "other";

export const STATUS_LABELS: Record<TicketStatus, string> = {
    open: "Open",
    pending: "Waiting on user",
    resolved: "Resolved",
    closed: "Closed",
};
export const PRIORITY_LABELS: Record<TicketPriority, string> = { low: "Low", medium: "Medium", high: "High" };
export const CATEGORY_LABELS: Record<TicketCategory, string> = {
    account: "Account",
    kyc: "KYC",
    loan: "Credit",
    payment: "Payment",
    payout: "Payout",
    other: "Other",
};

export interface PersonRef {
    _id: string;
    fullName?: string;
    email?: string;
    phone?: string;
    role?: string;
}

export interface TicketMessage {
    _id: string;
    author?: PersonRef | string;
    authorType: "user" | "admin";
    body: string;
    internal: boolean;
    createdAt: string;
}

export interface SupportTicket {
    _id: string;
    ticketNumber: string;
    subject: string;
    category: TicketCategory;
    status: TicketStatus;
    priority: TicketPriority;
    requester?: PersonRef;
    requesterRole: "corper" | "vendor";
    assignedTo?: PersonRef | null;
    messages?: TicketMessage[];
    lastMessageAt?: string;
    lastMessageBy?: "user" | "admin";
    resolvedAt?: string;
    createdAt: string;
}

export interface TicketStats {
    open: number;
    pending: number;
    resolved: number;
    closed: number;
    unassigned: number;
    mine: number;
}

const clean = (p?: Record<string, unknown>) =>
    p ? Object.fromEntries(Object.entries(p).filter(([, v]) => v !== undefined && v !== null && v !== "")) : undefined;
const data = <T>(res: { data?: { data?: T } }) => res.data?.data as T;

/** GET /support/tickets — status, priority, category, assignedTo (me|unassigned|id), requesterRole, search. */
export const getTickets = async (params?: Record<string, unknown>) =>
    data<{ tickets: SupportTicket[]; meta?: { total?: number; totalPages?: number } }>(
        await client.get("/support/tickets", { params: clean(params) }),
    );

export const getTicketStats = async () => data<TicketStats>(await client.get("/support/tickets/stats"));

export const getTicket = async (id: string) => data<SupportTicket>(await client.get(`/support/tickets/${id}`));

/** Reply (notifies the requester) or `internal: true` for a team-only note. */
export const replyToTicket = async (id: string, body: { body: string; internal?: boolean; status?: TicketStatus }) =>
    data<SupportTicket>(await client.post(`/support/tickets/${id}/messages`, body));

/** Change status / priority / assignee. `assignedTo: null` unassigns. */
export const updateTicket = async (
    id: string,
    patch: { status?: TicketStatus; priority?: TicketPriority; assignedTo?: string | null },
) => data<SupportTicket>(await client.patch(`/support/tickets/${id}`, patch));
