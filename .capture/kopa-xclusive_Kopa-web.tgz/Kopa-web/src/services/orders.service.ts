import client from "./client.service";

export type OrderStatus = "placed" | "accepted" | "shipped" | "delivered" | "completed" | "cancelled" | "disputed";
export type EscrowState = "held" | "released" | "refunded";

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
    placed: "Waiting for vendor",
    accepted: "Preparing",
    shipped: "On the way",
    delivered: "Delivered",
    completed: "Completed",
    cancelled: "Cancelled",
    disputed: "Disputed",
};

export const ESCROW_LABELS: Record<EscrowState, string> = {
    held: "Held by Kopa",
    released: "Paid to vendor",
    refunded: "Refunded to member",
};

export const orderStatusVariant = (s: OrderStatus) =>
  s === "completed"
    ? ("default" as const)
    : s === "cancelled"
      ? ("secondary" as const)
      : s === "disputed"
        ? ("destructive" as const)
        : s === "placed"
          ? ("pending" as const)
          : ("new" as const);

export interface OrderItem {
    product: string;
    name: string;
    image?: string;
    unitPrice: number;
    quantity: number;
    options?: { name: string; value: string }[];
    lineTotal: number;
}

export interface OrderHistoryEntry {
    status: OrderStatus;
    at: string;
    by: "corper" | "vendor" | "admin" | "system";
    note?: string;
}

export interface AdminOrder {
    _id: string;
    orderNumber: string;
    status: OrderStatus;
    statusBeforeDispute?: OrderStatus;
    escrow: EscrowState;
    totalAmount: number;
    refundedAmount?: number;
    items: OrderItem[];
    delivery?: { recipientName: string; phone: string; address: string; state?: string; note?: string };
    tracking?: { carrier?: string; trackingNumber?: string; note?: string; estimatedDelivery?: string };
    history?: OrderHistoryEntry[];
    corperUser?: { _id: string; fullName?: string; phone?: string; email?: string };
    vendor?: { _id: string; businessName?: string; businessPhone?: string };
    paymentId?: string;
    acceptedAt?: string;
    shippedAt?: string;
    deliveredAt?: string;
    completedAt?: string;
    cancelledAt?: string;
    createdAt: string;
}

const clean = (p?: Record<string, unknown>) =>
    p ? Object.fromEntries(Object.entries(p).filter(([, v]) => v !== undefined && v !== null && v !== "")) : undefined;
const data = <T>(res: { data?: { data?: T } }) => res.data?.data as T;

/** GET /orders — status, vendorId, userId, search (order number). */
export const getOrders = async (params?: Record<string, unknown>) =>
    data<{ orders: AdminOrder[]; meta?: { total?: number; totalPages?: number } }>(
        await client.get("/orders", { params: clean(params) }),
    );

export const getOrder = async (id: string) => data<AdminOrder>(await client.get(`/orders/${id}`));
