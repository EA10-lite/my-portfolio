import client from "./client.service";

export interface MyNotification {
    _id: string;
    title: string;
    body: string;
    type?: string;
    read: boolean;
    data?: { entity?: string; id?: string; [k: string]: unknown };
    createdAt: string;
}

export type BroadcastAudience = "all_corpers" | "all_vendors" | "all_users" | "overdue_corpers";

export const AUDIENCE_LABELS: Record<BroadcastAudience, string> = {
    all_corpers: "All approved corps members",
    all_vendors: "All approved vendors",
    all_users: "All approved corps members and vendors",
    overdue_corpers: "Corps members with an overdue or failed repayment",
};

const data = <T>(res: { data?: { data?: T } }) => res.data?.data as T;

/** GET /notifications/me — the signed-in admin's own feed (alerts about new work). */
export const getMyNotifications = async (params?: { page?: number; limit?: number; unread?: boolean }) =>
    data<{ data: MyNotification[]; unread: number; meta?: { total?: number } }>(
        await client.get("/notifications/me", { params }),
    );

export const markNotificationRead = async (id: string) => (await client.patch(`/notifications/me/${id}/read`)).data;

export const markAllNotificationsRead = async () => (await client.post("/notifications/me/read-all")).data;

/** POST /notifications/broadcast/preview — how many people an audience reaches. */
export const previewBroadcast = async (audience: BroadcastAudience) =>
    data<{ audience: BroadcastAudience; recipients: number }>(await client.post("/notifications/broadcast/preview", { audience }));

/** POST /notifications/broadcast — in-app + push to a whole audience (audited). */
export const sendBroadcast = async (body: { audience: BroadcastAudience; title: string; body: string; type?: string }) =>
    data<{ audience: BroadcastAudience; recipients: number }>(await client.post("/notifications/broadcast", body));

/** Where an admin alert should take you. */
export const linkFor = (n: MyNotification): string | null => {
    switch (n.data?.entity) {
        case "loan":
            return "/loans?status=pending";
        case "corper":
            return "/verification";
        case "vendor":
            return "/verification?entity=vendor";
        case "withdrawal":
            return "/withdrawals?status=pending";
        case "dispute":
            return "/disputes";
        case "ticket":
            return "/support";
        case "bill":
            return "/bills";
        case "order":
            return "/orders";
        default:
            return null;
    }
};
