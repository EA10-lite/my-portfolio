import client from "./client.service";
import type { PersonRef } from "./support.service";

export type DisputeStatus = "open" | "in_review" | "resolved" | "rejected";
export type DisputePriority = "low" | "medium" | "high";
export type DisputeReason = "not_delivered" | "wrong_item" | "damaged" | "overcharged" | "not_authorised" | "other";

export const STATUS_LABELS: Record<DisputeStatus, string> = {
    open: "Open",
    in_review: "In review",
    resolved: "Resolved for member",
    rejected: "Decided for vendor",
};
export const PRIORITY_LABELS: Record<DisputePriority, string> = { high: "High", medium: "Medium", low: "Low" };
export const REASON_LABELS: Record<DisputeReason, string> = {
    not_delivered: "Not delivered",
    wrong_item: "Wrong item",
    damaged: "Damaged or faulty",
    overcharged: "Overcharged",
    not_authorised: "Didn't authorise it",
    other: "Other",
};

export type PaymentSource = "vendor" | "bill" | "order";

export const SOURCE_LABELS: Record<PaymentSource, string> = {
    vendor: "Vendor payment",
    bill: "Bill purchase",
    order: "Order",
};

export interface OrderSummary {
    _id: string;
    orderNumber: string;
    status: string;
    statusBeforeDispute?: string;
    /** held = money still with Kopa; released = paid to vendor; refunded = back to member. */
    escrow: "held" | "released" | "refunded";
    totalAmount: number;
    refundedAmount: number;
    itemCount: number;
    items: { name: string; quantity: number; lineTotal: number }[];
    deliveredAt?: string;
}

export interface DisputeNote {
    _id: string;
    author?: PersonRef | string;
    body: string;
    createdAt: string;
}

export interface Dispute {
    _id: string;
    disputeNumber: string;
    paymentCode: string;
    amount: number;
    reason: DisputeReason;
    description: string;
    source: "corper" | "admin";
    status: DisputeStatus;
    priority: DisputePriority;
    corperUser?: PersonRef;
    vendor?: { _id: string; businessName?: string; kopaAccountNumber?: string };
    vendorOwner?: PersonRef;
    payment?: {
        _id: string;
        paymentCode: string;
        amount: number;
        source?: PaymentSource;
        status?: string;
        serviceType?: string;
        paidAt?: string;
        monthlyDebitStatus?: string;
        monthlyDebitDueDate?: string;
        receipt?: { receiptNumber?: string };
    };
    assignedTo?: PersonRef | null;
    vendorResponse?: string;
    vendorRespondedAt?: string;
    notes?: DisputeNote[];
    resolutionNote?: string;
    refundAgreed?: number;
    decidedBy?: PersonRef;
    decidedAt?: string;
    /** Present for order disputes: deciding one settles this escrow. */
    order?: OrderSummary | null;
    createdAt: string;
    updatedAt?: string;
}

export interface DisputeStats {
    open: number;
    inReview: number;
    resolved: number;
    rejected: number;
    amountInDispute: number;
    unassigned: number;
    mine: number;
}

export interface PaymentLookup {
    _id: string;
    paymentCode: string;
    amount: number;
    serviceType?: string;
    status: string;
    source?: PaymentSource;
    paidAt?: string;
    corperUser?: PersonRef;
    vendor?: { businessName?: string };
    canDispute: boolean;
    activeDispute?: { _id: string; disputeNumber: string; status: DisputeStatus } | null;
}

const clean = (p?: Record<string, unknown>) =>
    p ? Object.fromEntries(Object.entries(p).filter(([, v]) => v !== undefined && v !== null && v !== "")) : undefined;
const data = <T>(res: { data?: { data?: T } }) => res.data?.data as T;

/** GET /disputes — status, priority, reason, assignedTo (me|unassigned|id), vendorId, userId, search. */
export const getDisputes = async (params?: Record<string, unknown>) =>
    data<{ disputes: Dispute[]; meta?: { total?: number; totalPages?: number } }>(
        await client.get("/disputes", { params: clean(params) }),
    );

export const getDisputeStats = async () => data<DisputeStats>(await client.get("/disputes/stats"));

export const getDispute = async (id: string) => data<Dispute>(await client.get(`/disputes/${id}`));

export const addDisputeNote = async (id: string, body: string) =>
    data<Dispute>(await client.post(`/disputes/${id}/notes`, { body }));

/** Status (resolve/reject need resolutionNote), priority, assignee, refundAgreed. Record-only — never moves money. */
export const updateDispute = async (
    id: string,
    patch: {
        status?: DisputeStatus;
        priority?: DisputePriority;
        assignedTo?: string | null;
        resolutionNote?: string;
        refundAgreed?: number;
    },
) => data<Dispute>(await client.patch(`/disputes/${id}`, patch));

export const lookupPaymentForDispute = async (code: string) =>
    data<PaymentLookup>(await client.get("/disputes/lookup-payment", { params: { code } }));

/** POST /disputes — log a dispute reported by phone, email or in person. */
export const logDispute = async (body: {
    paymentId: string;
    reason: DisputeReason;
    description: string;
    priority?: DisputePriority;
}) => data<Dispute>(await client.post("/disputes", body));
