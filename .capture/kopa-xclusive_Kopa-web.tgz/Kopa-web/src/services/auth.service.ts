import client from "./client.service";

/**
 * The backend authenticates every user — admins included — with phone + 6-digit
 * PIN (auth/dto/auth.dto.ts → LoginDto). There is no email/password login.
 */
export type LoginData = {
    phone: string;
    pin: string;
};

export interface AuthUser {
    _id: string;
    fullName?: string;
    email?: string;
    phone: string;
    role: "corper" | "vendor" | "admin" | "super_admin";
    status?: string;
    isActive?: boolean;
}

export interface LoginResult {
    user: AuthUser;
    accessToken: string;
    refreshToken: string;
}

/** POST /auth/login → { success, data: { user, accessToken, refreshToken } } */
export const loginService = async (data: LoginData): Promise<LoginResult> => {
    const response = await client.post("/auth/login", data);
    return response.data?.data ?? response.data;
};

/** GET /auth/me — used on boot to confirm a persisted session is still valid. */
export const getMe = async (): Promise<AuthUser> => {
    const response = await client.get("/auth/me");
    const payload = response.data?.data ?? response.data;
    return payload?.user ?? payload;
};

/**
 * Admin account recovery. The backend has no email/password reset — recovery is
 * phone + SMS OTP + a new PIN, the same flow corpers and vendors use.
 */
export const startRecovery = async (phone: string) => {
    const response = await client.post("/auth/recovery/start", { phone });
    return response.data?.data ?? response.data;
};

export const completeRecovery = async (
    phone: string,
    otp: string,
    newPin: string,
    newPinConfirm: string,
): Promise<LoginResult> => {
    const response = await client.post("/auth/recovery/complete", {
        phone,
        otp,
        newPin,
        newPinConfirm,
    });
    return response.data?.data ?? response.data;
};

/** PUT /auth/pin — change PIN while signed in. */
export const changePin = async (
    currentPin: string,
    newPin: string,
    newPinConfirm: string,
) => {
    const response = await client.put("/auth/pin", {
        currentPin,
        newPin,
        newPinConfirm,
    });
    return response.data;
};

/** POST /auth/logout — revokes this session's refresh token server-side. */
export const logoutService = async (refreshToken?: string) => {
    if (!refreshToken) return;
    try {
        await client.post("/auth/logout", { refreshToken });
    } catch {
        // Best-effort: local tokens are cleared regardless.
    }
};

/** POST /auth/logout-all — revokes every session for this user. */
export const logoutAllDevices = async () => {
    const response = await client.post("/auth/logout-all");
    return response.data;
};
