import client from "./client.service";

/**
 * WithdrawalStatus — kopa-backend/src/withdrawals/withdrawal.schema.ts
 *
 *   pending      reserved off the vendor's balance, awaiting an admin decision
 *   otp_pending  transfer created at Paystack but parked until the OTP Paystack
 *                sent the registered business owner is submitted
 *   processing   accepted by Paystack; only the webhook (or a reconcile) settles it
 *   paid         money left the account — terminal
 *   rejected     admin declined, balance refunded — terminal
 *   failed       transfer did not happen, balance refunded — terminal
 *   reversed     paid then reversed by the bank, balance refunded — terminal
 */
export type WithdrawalStatus =
    | "pending"
    | "otp_pending"
    | "processing"
    | "paid"
    | "rejected"
    | "failed"
    | "reversed";

export interface WithdrawalRow {
    _id: string;
    amount: number;
    status: WithdrawalStatus;
    bankCode?: string;
    bankName?: string;
    accountName?: string;
    maskedAccountNumber?: string;
    rejectionReason?: string;
    /** Older API responses used `reason`. */
    reason?: string;
    failureReason?: string;
    otpAttempts?: number;
    /** Money may be in flight and couldn't be proven either way — needs a reconcile. */
    requiresReconciliation?: boolean;
    reconciliationNote?: string;
    paystackReference?: string;
    transferInitiatedAt?: string;
    decidedAt?: string;
    paidAt?: string;
    refundedAt?: string;
    createdAt?: string;
    processedAt?: string;
    vendor?: {
        _id?: string;
        businessName?: string;
        profileImage?: string;
        kopaAccountNumber?: string;
    };
}

export interface WithdrawalsResponse {
    withdrawals: WithdrawalRow[];
    meta?: {
        total?: number;
        page?: number;
        limit?: number;
        totalPages?: number;
    };
}

/** Max wrong-OTP submissions before the backend locks the payout (MAX_OTP_ATTEMPTS). */
export const MAX_OTP_ATTEMPTS = 5;

/**
 * GET /withdrawals — admin list. Filters: status, vendorId, vendorOwnerId,
 * requiresReconciliation (true = the "money in limbo" queue).
 */
export const getWithdrawals = async (
    params?: Record<string, unknown>,
): Promise<WithdrawalsResponse> => {
    const cleaned = params
        ? Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""))
        : undefined;
    const response = await client.get("/withdrawals", { params: cleaned });
    const payload = response.data?.data ?? response.data;
    if (Array.isArray(payload)) return { withdrawals: payload };
    return {
        withdrawals: payload?.withdrawals ?? payload?.data ?? [],
        meta: payload?.meta,
    };
};

export interface WithdrawalActionResult extends Partial<WithdrawalRow> {
    requiresOtp?: boolean;
    message?: string;
}

const unwrap = (data: unknown): WithdrawalActionResult => {
    const d = data as { data?: WithdrawalActionResult; message?: string };
    return { ...(d?.data ?? {}), message: d?.data?.message ?? d?.message };
};

/**
 * PUT /withdrawals/:id/approve — hands the payout to Paystack. It does NOT
 * mark it paid. If `requiresOtp` comes back true, Paystack has parked the
 * transfer until the OTP it sent the business owner is submitted.
 */
export const approveWithdrawal = async (id: string) =>
    unwrap((await client.put(`/withdrawals/${id}/approve`)).data);

/** PUT /withdrawals/:id/finalize-otp — release a parked transfer. */
export const finalizeWithdrawalOtp = async (id: string, otp: string) =>
    unwrap((await client.put(`/withdrawals/${id}/finalize-otp`, { otp })).data);

/** PUT /withdrawals/:id/resend-otp — Paystack re-sends the OTP; attempts reset. */
export const resendWithdrawalOtp = async (id: string) =>
    unwrap((await client.put(`/withdrawals/${id}/resend-otp`)).data);

/**
 * PUT /withdrawals/:id/reconcile — asks Paystack what really happened to a
 * stuck transfer (processing with no webhook, or flagged for reconciliation)
 * and settles it from that answer.
 */
export const reconcileWithdrawal = async (id: string) =>
    unwrap((await client.put(`/withdrawals/${id}/reconcile`)).data);

/** PUT /withdrawals/:id/reject — only while pending; refunds the vendor. */
export const rejectWithdrawal = async (id: string, reason: string) =>
    unwrap((await client.put(`/withdrawals/${id}/reject`, { reason })).data);

export const STATUS_LABELS: Record<WithdrawalStatus, string> = {
    pending: "Awaiting approval",
    otp_pending: "Awaiting OTP",
    processing: "Processing",
    paid: "Paid",
    rejected: "Rejected",
    failed: "Failed",
    reversed: "Reversed",
};
