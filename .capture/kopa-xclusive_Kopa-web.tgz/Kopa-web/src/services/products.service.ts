import client from "./client.service";

// GET /products/admin/all — every vendor, every status, filterable.
// Matches kopa-backend/src/products/products.controller.ts `allForAdmin`.
export const getAdminProducts = async (params?: Record<string, unknown>) => {
  // Accepts status, category, vendorId and search (text index over name and
  // description). Empty values are dropped — enums are validated strictly.
  const cleaned = params
    ? Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""))
    : undefined;
  const response = await client.get("/products/admin/all", { params: cleaned });
  return response.data;
};

// PUT /products/:id/moderate — { action: "approve" | "reject", reason? }
// `reason` is required by the backend when action === "reject".
export const moderateProduct = async (
  productId: string,
  data: { action: "approve" | "reject"; reason?: string },
) => {
  const response = await client.put(`/products/${productId}/moderate`, data);
  return response.data;
};
