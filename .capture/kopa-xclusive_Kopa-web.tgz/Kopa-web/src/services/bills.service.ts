import client from "./client.service";

export type BillResolution = "write_off" | "cancel_loan";

export const RESOLUTION_LABELS: Record<BillResolution, string> = {
    write_off: "Write off (Kopa absorbs it, member still repays)",
    cancel_loan: "Cancel the loan (restore credit, cancel repayment)",
};

export interface BillReview {
    id: string;
    reference: string;
    category: string;
    serviceID: string;
    variationCode?: string;
    billersCode?: string;
    phone?: string;
    customerName?: string;
    amount: number;
    status: string;
    message?: string;
    createdAt: string;
    deliveredAt?: string;
    user?: { _id: string; fullName?: string; email?: string; phone?: string };
    payment?: { _id: string; monthlyDebitStatus?: string; monthlyDebitDueDate?: string; status?: string };
    reviewStatus: "needs_review" | "resolved";
    reviewReason?: string;
    reviewFlaggedAt?: string;
    reviewResolution?: BillResolution;
    reviewNote?: string;
    reviewResolvedAt?: string;
}

const data = <T>(res: { data?: { data?: T } }) => res.data?.data as T;

/** GET /bills/admin/review — reversed-after-delivery purchases. */
export const getBillReviews = async (params: { page?: number; limit?: number; includeResolved?: boolean }) =>
    data<{ reviews: BillReview[]; meta?: { total?: number; totalPages?: number } }>(
        await client.get("/bills/admin/review", { params }),
    );

/** POST /bills/admin/:id/resolve — super admin only. */
export const resolveBillReview = async (id: string, body: { resolution: BillResolution; note: string }) =>
    data<BillReview>(await client.post(`/bills/admin/${id}/resolve`, body));

/** GET /bills/admin/provider-balance — the VTpass wallet purchases are paid from. */
export const getProviderBalance = async () =>
    data<{ balance: number; currency: string }>(await client.get("/bills/admin/provider-balance"));
