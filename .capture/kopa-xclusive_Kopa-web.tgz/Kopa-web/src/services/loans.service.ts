import client from "./client.service";

/** LoanStatus — kopa-backend/src/loans/loans.schema.ts */
export type LoanStatus = "pending" | "approved" | "declined";

export interface LoanRow {
    _id: string;
    amount: number;
    status: LoanStatus;
    currency?: string;
    loanType?: string;
    requestMonth?: number;
    requestYear?: number;
    approvedAt?: string;
    declinedAt?: string;
    declineReason?: string;
    createdAt?: string;
    user?: {
        _id?: string;
        fullName?: string;
        email?: string;
        phone?: string;
    };
}

export interface LoansResponse {
    loans: LoanRow[];
    meta?: {
        total?: number;
        page?: number;
        limit?: number;
        totalPages?: number;
    };
}

/** GET /loans — admin list, paginated, filterable by status/corperId/userId. */
export const getLoans = async (params?: Record<string, unknown>): Promise<LoansResponse> => {
    // Drop empty values — the backend validates `status` as a strict enum.
    const cleaned = params
        ? Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""))
        : undefined;
    const response = await client.get("/loans", { params: cleaned });
    const payload = response.data?.data ?? response.data;
    // The admin list returns { loans, meta } (the corper-facing one returns
    // { corper, loans, meta }); guard for a bare array too.
    if (Array.isArray(payload)) return { loans: payload };
    return { loans: payload?.loans ?? payload?.data ?? [], meta: payload?.meta };
};

/** POST /loans/admin/approve — credits the corper's availableCredit atomically. */
export const approveLoan = async (loanId: string) => {
    const response = await client.post("/loans/admin/approve", { loanId });
    return response.data;
};

/** POST /loans/admin/decline — requires a reason (DeclineLoanDto). */
export const declineLoan = async (loanId: string, reason: string) => {
    const response = await client.post("/loans/admin/decline", { loanId, reason });
    return response.data;
};
