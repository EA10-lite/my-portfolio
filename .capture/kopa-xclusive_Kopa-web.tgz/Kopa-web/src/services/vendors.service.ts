import client from "./client.service";

// GET /vendors — page, limit, `search` (business name, phone, owner),
// `kybStatus` (submitted | verified | rejected) and exact `email`. Empty values
// are dropped because the backend validates enums strictly.
export const getVendorsService = async (params?: Record<string, unknown>) => {
  const cleaned = params
    ? Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""))
    : undefined;
  const response = await client.get("/vendors", { params: cleaned });
  return response.data;
};

export const getCorpers = async (params?: Record<string, unknown>) => {
  const response = await client.get("/corpers", { params });
  return response.data;
};

// Matches backend: GET /vendors/stats ([SUPER_ADMIN, ADMIN])
// Vendor counts by KYB status + total accumulated Kopa balance, aggregated
// across ALL vendors (not just the current page).
export const getVendorStats = async () => {
  const response = await client.get("/vendors/stats");
  return response.data;
};
