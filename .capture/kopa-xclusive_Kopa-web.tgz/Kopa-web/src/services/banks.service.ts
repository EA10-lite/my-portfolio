import client from "./client.service";

/** Bank — kopa-backend/src/banks/bank.schema.ts */
export interface Bank {
    _id: string;
    name: string;
    code: string;
    longcode: string;
    country: string;
    currency: string;
    type: string;
    payWithBank: boolean;
    supportsTransfer: boolean;
    availableForDirectDebit: boolean;
    isActive?: boolean;
    createdAt?: string;
    updatedAt?: string;
}

/** Everything CreateBankDto requires. UpdateBankDto is a PartialType of it. */
export type BankPayload = Omit<Bank, "_id" | "isActive" | "createdAt" | "updatedAt">;

/**
 * GET /banks — this is the list the mobile KYC bank picker and the direct-debit
 * mandate setup both read. If it's empty, corper and vendor onboarding cannot
 * complete, which is why this screen exists.
 */
export const getBanks = async (): Promise<Bank[]> => {
    const response = await client.get("/banks");
    const payload = response.data?.data ?? response.data;
    if (Array.isArray(payload)) return payload;
    return payload?.banks ?? payload?.data ?? [];
};

/** POST /banks — super admin only. */
export const createBank = async (payload: BankPayload) => {
    const response = await client.post("/banks", payload);
    return response.data;
};

/** PATCH /banks/:id — super admin only; partial update. */
export const updateBank = async (id: string, payload: Partial<BankPayload>) => {
    const response = await client.patch(`/banks/${id}`, payload);
    return response.data;
};

/** DELETE /banks/:id — super admin only. */
export const deleteBank = async (id: string) => {
    const response = await client.delete(`/banks/${id}`);
    return response.data;
};
