import client from "./client.service";

export interface AdminMandate {
    _id: string;
    status: string;
    provider?: "creditchek" | "paystack";
    type?: string;
    bankName?: string;
    bankCode?: string;
    accountName?: string;
    accountNumber?: string;
    providerStatus?: string;
    activatedAt?: string;
    failureReason?: string;
    createdAt: string;
}

/** GET /mandates/admin/user/:userId — a member's direct-debit mandates, newest first. */
export const getMemberMandates = async (userId: string) =>
    ((await client.get(`/mandates/admin/user/${userId}`)).data?.data ?? []) as AdminMandate[];
