import client from "./client.service";

export const getDashboardStats = async () => {
  const response = await client.get("/dashboard/stats");
  return response.data;
};

export const getLoans = async (params?: Record<string, unknown>) => {
  const response = await client.get("/loans", { params });
  return response.data;
};

export const approveLoan = async (loanId: string) => {
  const response = await client.post("/loans/admin/approve", { loanId });
  return response.data;
};

export const declineLoan = async (loanId: string, reason: string) => {
  const response = await client.post("/loans/admin/decline", { loanId, reason });
  return response.data;
};

export const getPayments = async (params?: Record<string, unknown>) => {
  const response = await client.get("/payments", { params });
  return response.data;
};

// Matches backend: GET /payments/risk-summary ([ADMIN, SUPER_ADMIN])
// Aggregates collections risk across ALL paid payments (not just the
// current page) — use this for KPI totals instead of summing a page.
// POST /payments/:id/retry-debit — admin retry of a FAILED monthly debit
// (CreditChek mandates only). Debits still "processing" are refused because
// money may already have moved.
export const retryDebit = async (paymentId: string) => {
  const response = await client.post(`/payments/${paymentId}/retry-debit`);
  return response.data?.data as {
    paymentId: string;
    monthlyDebitStatus?: string;
    monthlyDebitFailureReason?: string;
  };
};

export const getRiskSummary = async () => {
  const response = await client.get("/payments/risk-summary");
  return response.data;
};

const clean = (params?: Record<string, unknown>) =>
  params
    ? Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""))
    : undefined;

// GET /transactions — page, limit, type, userId, search (reference),
// startDate / endDate (ISO, inclusive).
export const getTransactions = async (params?: Record<string, unknown>) => {
  const response = await client.get("/transactions", { params: clean(params) });
  return response.data;
};

// Matches backend: GET /transactions/stats ([ADMIN, SUPER_ADMIN])
// Ledger totals + per-type counts/amounts, aggregated across every
// transaction ever recorded (not just the current page).
export const getTransactionStats = async (range?: { startDate?: string; endDate?: string }) => {
  const response = await client.get("/transactions/stats", { params: clean(range) });
  return response.data;
};

// Matches backend: GET /transactions/monthly-volume ([ADMIN, SUPER_ADMIN])
// Last 6 months of ledger volume, zero-filled for months with no activity.
export const getTransactionMonthlyVolume = async (months?: number) => {
  const response = await client.get("/transactions/monthly-volume", { params: clean({ months }) });
  return response.data;
};

// Matches backend: GET /notifications ([ADMIN, SUPER_ADMIN]) -- every
// notification ever sent, across all recipients, with each row's recipient
// resolved server-side. Distinct from GET /notifications/me (a user's own feed).
export const getAdminNotifications = async (params?: Record<string, unknown>) => {
  const response = await client.get("/notifications", { params });
  return response.data;
};

export const sendNotification = async (data: {
  userId: string;
  title: string;
  body: string;
  type?: string;
}) => {
  const response = await client.post("/notifications/send", data);
  return response.data;
};

export const resolveVendor = async (idOrPhone: string) => {
  const response = await client.get(`/vendors/resolve/${encodeURIComponent(idOrPhone)}`);
  return response.data;
};

export const getAuditLogs = async (params?: Record<string, unknown>) => {
  const response = await client.get("/audit", { params });
  return response.data;
};
