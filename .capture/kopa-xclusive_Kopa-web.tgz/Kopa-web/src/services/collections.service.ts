import client from "./client.service";

export type CollectionOutcome = "contacted" | "no_answer" | "promised_to_pay" | "disputed" | "other";

export const OUTCOME_LABELS: Record<CollectionOutcome, string> = {
    contacted: "Reached them",
    no_answer: "No answer",
    promised_to_pay: "Promised to pay",
    disputed: "Disputes the debt",
    other: "Other",
};

export interface CollectionNote {
    _id: string;
    outcome: CollectionOutcome;
    note: string;
    promisedDate?: string;
    createdAt: string;
    createdBy?: { fullName?: string; email?: string };
}

export interface LatestCollectionNote {
    paymentId: string;
    count: number;
    outcome: CollectionOutcome;
    note: string;
    promisedDate?: string;
    createdAt: string;
}

const data = <T>(res: { data?: { data?: T } }) => (res.data?.data ?? []) as T;

/** POST /collections/notes — append-only contact log; never changes money state. */
export const addCollectionNote = async (body: {
    paymentId: string;
    outcome: CollectionOutcome;
    note: string;
    promisedDate?: string;
}) => data<CollectionNote>(await client.post("/collections/notes", body));

export const getCollectionNotes = async (paymentId: string) =>
    data<CollectionNote[]>(await client.get("/collections/notes", { params: { paymentId } }));

export const getLatestCollectionNotes = async (paymentIds: string[]) =>
    paymentIds.length === 0
        ? []
        : data<LatestCollectionNote[]>(
              await client.get("/collections/notes", { params: { paymentIds: paymentIds.join(",") } }),
          );
