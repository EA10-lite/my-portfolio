import axios, { AxiosError, type InternalAxiosRequestConfig } from "axios";
import {
    COOKIE_NAMES,
    getAuthToken,
    removeAuthToken,
    setAuthToken,
} from "../utils/cookies";
// Safe to import statically: adminStore pulls only a *type* from auth.service,
// which is erased at build time, so there is no runtime cycle back to here.
import { useAdminStore } from "../stores/adminStore";

const rawUrl = (import.meta.env.VITE_API_URL || "http://localhost:8000/api/v1").trim().replace(/\/+$/, "");
const baseURL = rawUrl.endsWith("/api/v1") ? rawUrl : `${rawUrl}/api/v1`;

const client = axios.create({
    baseURL,
    headers: {
        "Content-Type": "application/json",
    },
    // Without this axios waits forever, so an unresponsive API leaves the UI
    // spinning with no way to tell the user anything. 45s is generous enough
    // for a Render free-tier cold start (~50s worst case is rare) while still
    // failing in bounded time.
    timeout: 45_000,
});

client.interceptors.request.use(
    (config) => {
        const token = getAuthToken();
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => Promise.reject(error)
);

// ── Silent token refresh ────────────────────────────────────────────────────
// A 401 used to log the admin straight out. The backend issues a refresh token
// at login and rotates it via POST /auth/refresh (the refresh token goes in the
// Authorization header, not the body), so an expired access token should be
// renewed transparently and the original request replayed.

type QueueEntry = {
    resolve: (token: string) => void;
    reject: (error: unknown) => void;
};

let isRefreshing = false;
let failedQueue: QueueEntry[] = [];

const processQueue = (error: unknown, token?: string) => {
    failedQueue.forEach((entry) => (error ? entry.reject(error) : entry.resolve(token!)));
    failedQueue = [];
};

/**
 * Clears local session and sends the admin back to login, saying why, and
 * remembering where they were so they land back on it after signing in.
 */
const forceLogout = () => {
    removeAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
    removeAuthToken(COOKIE_NAMES.REFRESH_TOKEN);
    useAdminStore.getState().logout();
    if (window.location.pathname !== "/auth/login") {
        const from = window.location.pathname + window.location.search;
        window.location.href = `/auth/login?session=expired&from=${encodeURIComponent(from)}`;
    }
};

client.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
        const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
        const url = originalRequest?.url ?? "";

        // Never intercept the auth endpoints themselves — a 401 from /auth/login
        // is "wrong PIN", not "expired session", and retrying /auth/refresh
        // would loop.
        const isAuthRoute =
            url.includes("/auth/login") ||
            url.includes("/auth/refresh") ||
            url.includes("/auth/recovery");

        // No response at all — timeout, server down, DNS, CORS. Rewrite the
        // opaque "timeout of 45000ms exceeded" into something actionable, so
        // callers surface a real explanation instead of a generic failure.
        if (!error.response) {
            const unreachable = new Error(
                error.code === "ECONNABORTED"
                    ? "The server took too long to respond. It may be starting up — try again in a moment."
                    : "Could not reach the server. Check your connection and that the API is running.",
            );
            return Promise.reject(Object.assign(unreachable, { isNetworkError: true }));
        }

        if (error.response?.status !== 401 || isAuthRoute || originalRequest?._retry) {
            return Promise.reject(error);
        }

        const refreshToken = getAuthToken(COOKIE_NAMES.REFRESH_TOKEN);
        if (!refreshToken) {
            forceLogout();
            return Promise.reject(error);
        }

        if (isRefreshing) {
            // Queue everything that 401s while a refresh is already in flight,
            // then replay them with the new token.
            return new Promise<string>((resolve, reject) => {
                failedQueue.push({ resolve, reject });
            }).then((token) => {
                originalRequest.headers.Authorization = `Bearer ${token}`;
                return client(originalRequest);
            });
        }

        originalRequest._retry = true;
        isRefreshing = true;

        try {
            // The backend's RefreshJwtGuard reads the refresh token from the
            // Authorization header and the body is ignored.
            const { data } = await axios.post(
                `${baseURL}/auth/refresh`,
                {},
                { headers: { Authorization: `Bearer ${refreshToken}` } }
            );

            const payload = data?.data ?? data;
            const newAccess: string = payload.accessToken;
            const newRefresh: string | undefined = payload.refreshToken;

            if (!newAccess) throw new Error("refresh_returned_no_token");

            setAuthToken(newAccess, COOKIE_NAMES.ACCESS_TOKEN);
            if (newRefresh) setAuthToken(newRefresh, COOKIE_NAMES.REFRESH_TOKEN);

            client.defaults.headers.common.Authorization = `Bearer ${newAccess}`;
            processQueue(null, newAccess);

            originalRequest.headers.Authorization = `Bearer ${newAccess}`;
            return client(originalRequest);
        } catch (refreshError) {
            // Refresh token itself is expired or revoked — this is a real logout.
            processQueue(refreshError);
            forceLogout();
            return Promise.reject(refreshError);
        } finally {
            isRefreshing = false;
        }
    }
);

export default client;
