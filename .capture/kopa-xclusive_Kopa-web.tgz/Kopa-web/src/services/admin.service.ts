import client from "./client.service";

export type DecisionAction = "approve" | "reject";

export type MatchLevel = "high" | "medium" | "low" | "unverified";

export interface FieldVerification {
  submittedValue: string;
  apiName: string | null;
  matchScore: number | null;
  matchLevel: MatchLevel;
  error?: string;
}

export interface CorperVerificationResult {
  submittedFullName: string;
  bvn: FieldVerification;
  nin: FieldVerification;
  bankAccount: FieldVerification & { bankName?: string };
  callUpLetterNumber: { decryptedValue: string; note: string };
}

export interface VendorVerificationResult {
  submittedBusinessName: string;
  bankAccount: FieldVerification & { bankName?: string };
  cacNumber: FieldVerification;
}

// Matches backend: PUT /admin/users/:id/corper-status
// `amount` sets the corper's maxLoanAmount ceiling and is required by the
// backend when action is "approve" (no default is applied).
export const setCorperApprovalStatus = async (
  userId: string,
  data: { action: DecisionAction; amount?: number; reason: string },
) => {
  const response = await client.put(`/admin/users/${userId}/corper-status`, data);
  return response.data;
};

// Matches backend: PUT /admin/users/:id/vendor-status
export const setVendorApprovalStatus = async (
  userId: string,
  data: { action: DecisionAction; reason: string },
) => {
  const response = await client.put(`/admin/users/${userId}/vendor-status`, data);
  return response.data;
};

// Matches backend: PUT /admin/status/:userId ([SUPER_ADMIN] approve/reject an admin)
export const setAdminApprovalStatus = async (
  userId: string,
  data: { action: DecisionAction; reason: string; admin_department?: string },
) => {
  const response = await client.put(`/admin/status/${userId}`, data);
  return response.data;
};

// Matches backend: GET /admin/users/:userId/corper-verify
// Decrypts BVN/NIN/bank account/call-up letter number and runs live
// CreditChek verification checks for admin KYC review.
export const verifyCorperIdentity = async (userId: string) => {
  const response = await client.get(`/admin/users/${userId}/corper-verify`);
  return response.data;
};

// Matches backend: GET /admin/users/:userId/vendor-verify
// Decrypts CAC number/bank account and runs live CreditChek verification
// checks for admin KYB review.
export const verifyVendorIdentity = async (userId: string) => {
  const response = await client.get(`/admin/users/${userId}/vendor-verify`);
  return response.data;
};

export const modifyCorperLoanLimit = async (
  corperId: string,
  data: { amount: number },
) => {
  const response = await client.put(`/admin/corpers/${corperId}/loan-limit/modify`, data);
  return response.data;
};

// Matches backend: GET /admin ([SUPER_ADMIN] fetch all admins)
export const getAdmins = async (params?: Record<string, unknown>) => {
  const cleaned = params
    ? Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""))
    : undefined;
  const response = await client.get("/admin", { params: cleaned });
  return response.data;
};

// Legacy exports kept for existing imports (deprecated, use setCorperApprovalStatus).
export const approveCorper = async (id: string, amount?: number, reason = "Approved") => {
  return setCorperApprovalStatus(id, { action: "approve", amount, reason });
};

export const rejectCorper = async (id: string, reason = "Rejected") => {
  return setCorperApprovalStatus(id, { action: "reject", reason });
};

// ── Admin account management ([SUPER_ADMIN], /admin/accounts) ───────────────
// PINs are never set by another person: a new or reset account gets an
// unusable PIN and its owner sets their own via "Forgot PIN" (SMS OTP).

export const ADMIN_DEPARTMENTS = [
  { label: "Corps Affairs", value: "corps_affairs" },
  { label: "Vendor Affairs", value: "vendor_affairs" },
  { label: "Payment Affairs", value: "payment_affairs" },
  { label: "Admin Affairs", value: "admin_affairs" },
] as const;

export type AdminRoleValue = "admin" | "super_admin";

export const createAdminAccount = async (data: {
  fullName: string;
  phone: string;
  email: string;
  role: AdminRoleValue;
  department: string;
}) => (await client.post("/admin/accounts", data)).data;

export const updateAdminAccount = async (
  userId: string,
  data: { role?: AdminRoleValue; department?: string },
) => (await client.patch(`/admin/accounts/${userId}`, data)).data;

export const deactivateAdminAccount = async (userId: string, reason: string) =>
  (await client.post(`/admin/accounts/${userId}/deactivate`, { reason })).data;

export const reactivateAdminAccount = async (userId: string) =>
  (await client.post(`/admin/accounts/${userId}/reactivate`)).data;

export const resetAdminPin = async (userId: string) =>
  (await client.post(`/admin/accounts/${userId}/reset-pin`)).data;
