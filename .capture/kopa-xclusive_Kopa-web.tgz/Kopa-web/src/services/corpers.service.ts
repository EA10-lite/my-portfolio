import client from "./client.service";

/**
 * GET /corpers — admin list. Accepts page, limit, `search` (partial match on
 * name, email, phone, state code, PPA), `status` (the linked user's account
 * status: pending | approved | rejected | suspended) and `kycStatus`
 * (submitted | verified | rejected). Empty values are dropped because the
 * backend validates enums strictly.
 */
export const getCorpers = async (params?: Record<string, unknown>) => {
  const response = await client.get("/corpers", { params: clean(params) });
  return response.data;
};

// Matches backend: GET /corpers/stats ([SUPER_ADMIN, ADMIN])
// Corps member counts by approval status + credit-line totals, aggregated
// across ALL corpers (not just the current page).
export const getCorperStats = async () => {
  const response = await client.get("/corpers/stats");
  return response.data;
};

// Matches backend: GET /corpers/:id ([SUPER_ADMIN, ADMIN]) — one profile by
// corper document id, with the linked user populated.
//
// KNOWN BACKEND DEFECT: corpers.service.ts findOneForAdmin() spreads the
// Mongoose document without .toObject(), so the payload arrives wrapped as
// { $__, $isNew, _doc: {...} }. Unwrap _doc so this works before and after
// the one-line backend fix.
export const getCorper = async (id: string) => {
  const response = await client.get(`/corpers/${id}`);
  const payload = response.data?.data ?? response.data;
  return payload?._doc ?? payload;
};

function clean(params?: Record<string, unknown>) {
  if (!params) return undefined;
  return Object.fromEntries(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== ""),
  );
}

/**
 * Finds a corper profile from its owner's email. Loans, notifications and
 * other records reference the *user*, while the profile page is keyed by the
 * corper document id — this bridges the two. `email` is an exact match.
 */
export const findCorperByEmail = async (email: string) => {
  const res = await getCorpers({ email, page: 1, limit: 1 });
  const corpers = res?.data?.corpers ?? res?.corpers ?? [];
  return (corpers[0] ?? null) as
    | { _id: string; fullName?: string; maxLoanAmount?: number; availableCredit?: number; kycStatus?: string }
    | null;
};
