/**
 * Pulls the most useful message out of a failed request. The backend returns
 * `{ message }`, where class-validator failures make `message` an array.
 * Network failures are already rewritten into a readable Error by the axios
 * interceptor.
 */
export function getApiErrorMessage(error: unknown, fallback: string): string {
    const err = error as { response?: { data?: { message?: string | string[] } }; message?: string };
    const message = err?.response?.data?.message;
    if (Array.isArray(message) && message.length > 0) return message.join(". ");
    if (typeof message === "string" && message.trim()) return message;
    if (!err?.response && err?.message) return err.message;
    return fallback;
}
