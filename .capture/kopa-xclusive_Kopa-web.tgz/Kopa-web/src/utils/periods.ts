import { dayEndIso, dayStartIso, toDayString } from "./dateRange";

export type PeriodKey = "month" | "30d" | "90d" | "year" | "all";

export const PERIODS: { key: PeriodKey; label: string }[] = [
    { key: "month", label: "This month" },
    { key: "30d", label: "Last 30 days" },
    { key: "90d", label: "Last 90 days" },
    { key: "year", label: "This year" },
    { key: "all", label: "All time" },
];

/**
 * A named period → the YYYY-MM-DD bounds (for links into filtered pages)
 * and the ISO bounds the API takes. "all" has no bounds.
 */
export function periodRange(key: PeriodKey) {
    const now = new Date();
    let start: Date | null = null;
    if (key === "month") start = new Date(now.getFullYear(), now.getMonth(), 1);
    if (key === "30d") start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29);
    if (key === "90d") start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 89);
    if (key === "year") start = new Date(now.getFullYear(), 0, 1);
    const from = start ? toDayString(start) : "";
    const to = start ? toDayString(now) : "";
    return { from, to, startDate: dayStartIso(from), endDate: dayEndIso(to) };
}
