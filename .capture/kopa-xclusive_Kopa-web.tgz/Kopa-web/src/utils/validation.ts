import * as Yup from "yup";

// The backend authenticates admins the same way it authenticates everyone
// else: Nigerian phone number + 6-digit PIN (auth/dto/auth.dto.ts).
const NGN_PHONE_REGEX = /^0[789]\d{9}$/;

export const loginValidation = Yup.object().shape({
  phone: Yup.string()
    .matches(NGN_PHONE_REGEX, "Enter a valid Nigerian phone number (e.g. 08012345678)")
    .required("Phone number is required"),
  pin: Yup.string()
    .matches(/^\d{6}$/, "PIN must be exactly 6 digits")
    .required("PIN is required"),
});

export const recoveryStartValidation = Yup.object().shape({
  phone: Yup.string()
    .matches(NGN_PHONE_REGEX, "Enter a valid Nigerian phone number (e.g. 08012345678)")
    .required("Phone number is required"),
});

export const recoveryCompleteValidation = Yup.object().shape({
  otp: Yup.string()
    .matches(/^\d{4,6}$/, "Enter the code sent to your phone")
    .required("Verification code is required"),
  newPin: Yup.string()
    .matches(/^\d{6}$/, "PIN must be exactly 6 digits")
    .required("New PIN is required"),
  newPinConfirm: Yup.string()
    .oneOf([Yup.ref("newPin")], "PINs do not match")
    .required("Confirm your new PIN"),
});

export const changePinValidation = Yup.object().shape({
  currentPin: Yup.string()
    .matches(/^\d{6}$/, "PIN must be exactly 6 digits")
    .required("Current PIN is required"),
  newPin: Yup.string()
    .matches(/^\d{6}$/, "PIN must be exactly 6 digits")
    .required("New PIN is required"),
  newPinConfirm: Yup.string()
    .oneOf([Yup.ref("newPin")], "PINs do not match")
    .required("Confirm your new PIN"),
});

