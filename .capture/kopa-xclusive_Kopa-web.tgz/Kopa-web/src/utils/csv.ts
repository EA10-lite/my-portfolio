/**
 * Shared CSV export. Every table's "Export" button routes through here so the
 * escaping and download mechanics live in one place instead of being copied
 * into each page.
 */

export type CsvColumn<T> = {
    header: string;
    /** Value for one row. Return anything printable; nullish becomes "". */
    value: (row: T) => string | number | boolean | null | undefined;
};

/** RFC 4180 escaping: wrap in quotes, double any embedded quote. */
function escapeCell(value: unknown): string {
    const text = value === null || value === undefined ? "" : String(value);
    return `"${text.replace(/"/g, '""')}"`;
}

export function toCsv<T>(rows: T[], columns: CsvColumn<T>[]): string {
    const header = columns.map((c) => escapeCell(c.header)).join(",");
    const body = rows.map((row) =>
        columns.map((c) => escapeCell(c.value(row))).join(","),
    );
    return [header, ...body].join("\n");
}

/**
 * Builds the CSV and triggers a download.
 *
 * `filename` gets a date stamp so repeated exports don't overwrite each other
 * in the browser's downloads folder. A BOM is prepended so Excel opens UTF-8
 * (₦ and accented names) correctly instead of mojibake.
 */
export function downloadCsv<T>(
    filename: string,
    rows: T[],
    columns: CsvColumn<T>[],
): void {
    const stamp = new Date().toISOString().slice(0, 10);
    const csv = toCsv(rows, columns);
    const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${filename}-${stamp}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}
