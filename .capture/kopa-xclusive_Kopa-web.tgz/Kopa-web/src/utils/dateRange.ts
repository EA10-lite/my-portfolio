import { useCallback, useMemo, useState } from "react";

/**
 * Date-range filtering helpers.
 *
 * Every list DTO on the backend extends PaginationDto and accepts only `page`
 * and `limit` — there are no date parameters, and the global ValidationPipe
 * runs with `forbidNonWhitelisted`, so sending `startDate` would be a 400
 * rather than being ignored. Filtering is therefore done in the browser over
 * the rows already fetched, and screens using it say so.
 *
 * Kept separate from the component so the module exports only hooks/utilities
 * (react-refresh requires a component file to export components only).
 */

export interface DateRangeState {
    from: string;
    to: string;
    setFrom: (v: string) => void;
    setTo: (v: string) => void;
    clear: () => void;
    isActive: boolean;
}

export function useDateRange(): DateRangeState {
    const [from, setFrom] = useState("");
    const [to, setTo] = useState("");

    const clear = useCallback(() => {
        setFrom("");
        setTo("");
    }, []);

    return useMemo(
        () => ({ from, to, setFrom, setTo, clear, isActive: Boolean(from || to) }),
        [from, to, clear],
    );
}

/**
 * True when `value` falls inside [from, to]. Empty bounds are open-ended, and
 * an unparseable or missing date is excluded only when a bound is actually set
 * — otherwise rows without timestamps would silently vanish.
 */
export function withinRange(
    value: string | undefined,
    from: string,
    to: string,
): boolean {
    if (!from && !to) return true;
    if (!value) return false;

    const time = new Date(value).getTime();
    if (Number.isNaN(time)) return false;

    if (from) {
        const start = new Date(`${from}T00:00:00`).getTime();
        if (!Number.isNaN(start) && time < start) return false;
    }
    if (to) {
        // Inclusive of the whole end day.
        const end = new Date(`${to}T23:59:59.999`).getTime();
        if (!Number.isNaN(end) && time > end) return false;
    }
    return true;
}


/** Local calendar day ("YYYY-MM-DD") → ISO start/end bounds for the API. */
export const dayStartIso = (d: string) => (d ? new Date(`${d}T00:00:00`).toISOString() : "");
export const dayEndIso = (d: string) => (d ? new Date(`${d}T23:59:59.999`).toISOString() : "");

/** "YYYY-MM-DD" for a Date, in local time. */
export const toDayString = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
