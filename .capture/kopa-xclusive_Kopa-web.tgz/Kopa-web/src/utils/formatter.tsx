export const formatDateString = (date: string | Date) => {
    const d = typeof date === "string" ? new Date(date) : date;
  
    if (isNaN(d.getTime())) {
      return "N/A";
    }
  
    const day = d.getDate();
    const month = d.toLocaleString("en-US", { month: "long" });
    const year = d.getFullYear();
  
    const getOrdinal = (n: number) => {
      if (n > 3 && n < 21) return "th";
      switch (n % 10) {
        case 1: return "st";
        case 2: return "nd";
        case 3: return "rd";
        default: return "th";
      }
    };
  
    let hours = d.getHours();
    const minutes = d.getMinutes().toString().padStart(2, "0");
    const ampm = hours >= 12 ? "pm" : "am";
  
    hours = hours % 12 || 12;
    const formattedHours = hours.toString().padStart(2, "0");
    return `${day}${getOrdinal(day)} ${month} ${year}, ${formattedHours}:${minutes}${ampm}`;
  };
  
  
  export const formatTime = (date: string | Date) => {
    const d = typeof date === "string" ? new Date(date) : date;
  
    if (isNaN(d.getTime())) {
      return "N/A";
    }
  
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - d.getTime()) / 1000);
  
    if (diffInSeconds < 60) {
      return "just now";
    }
  
    const minutes = Math.floor(diffInSeconds / 60);
    if (minutes < 60) {
      return `${minutes} min${minutes > 1 ? "s" : ""} ago`;
    }
  
    const hours = Math.floor(minutes / 60);
    if (hours < 24) {
      return `${hours} hour${hours > 1 ? "s" : ""} ago`;
    }
  
    const days = Math.floor(hours / 24);
    if (days < 7) {
      return `${days} day${days > 1 ? "s" : ""} ago`;
    }
  
    const weeks = Math.floor(days / 7);
    if (weeks < 4) {
      return `${weeks} week${weeks > 1 ? "s" : ""} ago`;
    }
  
    const months = Math.floor(days / 30);
    if (months < 12) {
      return `${months} month${months > 1 ? "s" : ""} ago`;
    }
  
    const years = Math.floor(days / 365);
    return `${years} year${years > 1 ? "s" : ""} ago`;
  };
  
  
  
  
  
  /**
   * Formats a number with "k" suffix for thousands
   * Examples:
   * - 2500 => "2.5k"
   * - 19874 => "19.8k"
   * - 500 => "500" (numbers less than 1000 are returned as-is)
   */
  export const formatNumber = (value: number) => {
    if (value >= 1000) {
        const thousands = value / 1000;
        // Round to 1 decimal place, but remove trailing zero if it's a whole number
        const rounded = Math.round(thousands * 10) / 10;
        return rounded % 1 === 0 ? `${rounded}k` : `${rounded.toFixed(1)}k`;
    }
    return value.toString();
  }
  
  export const formatCurrency = (amount: number): string => {
    return `₦${amount.toLocaleString('en-NG')}`;
  };
  
  export const formatFileSize = (size: number): string => {
    if (size < 1024) {
        return `${size} B`;
    }
    if (size < 1024 * 1024) {
        return `${(size / 1024).toFixed(2)} KB`;
    }
    return `${(size / 1024 / 1024).toFixed(2)} MB`;
  };
  /** ₦1.2M / ₦850k / ₦900 — for chart axes and tight KPI cards. */
  export const formatCompactNaira = (amount: number): string => {
    const abs = Math.abs(amount);
    if (abs >= 1_000_000_000) return `₦${(amount / 1_000_000_000).toFixed(1).replace(/\.0$/, "")}B`;
    if (abs >= 1_000_000) return `₦${(amount / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
    if (abs >= 1_000) return `₦${(amount / 1_000).toFixed(0)}k`;
    return `₦${amount.toLocaleString("en-NG")}`;
  };
