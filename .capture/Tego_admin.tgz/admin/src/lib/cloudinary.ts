// shared/lib/cloudinary.ts

const CLOUDINARY_CLOUD_NAME = import.meta.env.VITE_API_CLOUDINARY_CLOUD_NAME;
const CLOUDINARY_UPLOAD_PRESET = import.meta.env.VITE_API_CLOUDINARY_UPLOAD_PRESET;

export const CLOUDINARY_FOLDERS = {
  CATEGORIES: "tego/categories",
  ADMIN_PROFILE_PICTURE: "tego/admin_profile_picture",
} as const;

export type CloudinaryFolder =
  (typeof CLOUDINARY_FOLDERS)[keyof typeof CLOUDINARY_FOLDERS];

export type CloudinaryResponse = {
  secure_url: string;
  public_id: string;
  format: string;
  bytes: number;
};

type UploadOptions = {
  folder?: CloudinaryFolder;
  publicIdToDelete?: string;
};

export const uploadFileToCloudinary = async (
  file: File,
  options: UploadOptions = {},
): Promise<CloudinaryResponse> => {
  const uploadUrl = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;

  const formData = new FormData();

  formData.append("file", file);
  formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET!);
  formData.append("folder", options.folder ?? "tego/others");

  const response = await fetch(uploadUrl, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    const error = await response.text();
    console.error("[Cloudinary] upload failed:", error);
    throw new Error("Image upload failed");
  }

  return response.json() as Promise<CloudinaryResponse>;
};

