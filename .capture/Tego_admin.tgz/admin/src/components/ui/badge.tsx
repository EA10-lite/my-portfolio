import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "../../lib/utils"

const badgeVariants = cva(
  "inline-flex items-center justify-center rounded-full border px-[16.67px] w-fit whitespace-nowrap shrink-0 [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden text-[8.67px] font-[700] h-[23px] pointer-events-none",
  {
    variants: {
      variant: {
        default:
          "border-transparent bg-[#0A3921] text-primary",
        success:
          "border-success bg-success/9 text-success",
        primary:
          "border-primary bg-primary/9 text-primary",
        destructive:
          "text-destructive bg-destructive/9 border-destructive",
        pending:
          "bg-[#FF8D2817] text-[#FF8D28] border border-[#FF8D28]",
        muted:
          "bg-[#6B728017] text-[#6B7280] border border-[#6B7280]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

function Badge({
  className,
  variant,
  asChild = false,
  ...props
}: React.ComponentProps<"span"> &
  VariantProps<typeof badgeVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "span"

  return (
    <Comp
      data-slot="badge"
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    >
      <span className="size-1 rounded-full bg-current shrink-0" />
      {props.children}
    </Comp>
  )
}

export { Badge }
