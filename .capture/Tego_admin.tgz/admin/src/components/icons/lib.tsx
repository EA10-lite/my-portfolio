import React from "react";
import {
  DashboardFill,
  DashboardOutline,
  AnalyticsFill,
  AnalyticsOutline,
  CustomerFill,
  CustomerOutline,
  ProviderFill,
  ProviderOutline,
  ServiceFill,
  ServiceOutline,
  StoreFill,
  StoreOutline,
  SubscriptionFill,
  SubscriptionOutline,
  BellFill,
  BellOutline,
  RequestFill,
  RequestOutline,
  TicketFill,
  TicketOutline,
  MenuFill,
  MenuOutline,
  ContactFill,
  ContactOutline,
  CardFill,
  CardOutline,
  UserOutline,
  BrickOutline,
  ChartOutline,
  GraphOutline,
  WarningOutline,
  PencilEdit,
  WarningFill,
  Verified,
  TrashFill,
  SuccessFill,
  ReshareAlt,
  UserFill,
  FeatureFill,
  FeatureOutline,
  VerifiedAlt,
  Check,
  CloseOutline,
  CloseFill,
  EditOutline,
  DoubleCheckFill,
  Like,
  LockFill,
  ChatOutline,
  AdminUserOutline,
  AdminUserFill,
  ClockOutline,
  Timer,
  Send,
} from "./icons";

export type IconType =
  "dashboard-fill"
  | "dashboard-outline"
  | "analytics-fill"
  | "analytics-outline"
  | "provider-fill"
  | "provider-outline"
  | "customer-fill"
  | "customer-outline"
  | 'store-fill'
  | 'store-outline'
  | 'service-fill'
  | 'service-outline'
  | 'subscription-fill'
  | 'subscription-outline'
  | 'card-fill'
  | 'card-outline'

  // temporary
  | "request-fill"
  | "request-outline"
  | "category-fill"
  | "category-outline"
  | "verification-fill"
  | "verification-outline"
  | "ticket-fill"
  | "ticket-outline"
  | "bell-fill"
  | "bell-outline"
  | "settings-fill"
  | "settings-outline"
  | "user-outline"
  | "user-fill"
  | "brick-outline"
  | "chart-outline"
  | "graph-outline"
  | "warning-outline"
  | "warning-fill"
  | "trash-fill"
  | "success-fill"
  | "pencil-edit"
  | "reshare-alt-outline"
  | "verified"
  | "verified-alt"
  | "feature-outline"
  | "feature-fill"
  | "check"
  | "close-outline"
  | "close-fill"
  | "edit-outline"
  | "double-check"
  | "like"
  | "lock-fill"
  | "chat-outline"
  | "admin-user-fill"
  | "admin-user-outline"
  | 'clock-outline'
  | "timer"
  | "send"


interface IconProps {
  color?: string;
  size?: number;
}

export const getIcon = (type: IconType, props?: IconProps) => {
  const { color, size = 20 } = props ?? {};

  const iconProps = {
    ...(color && { color }),
    width: size,
    height: size,
  };

  const iconMap: Record<IconType, React.ReactNode> = {
    "dashboard-fill": <DashboardFill {...iconProps} />,
    "dashboard-outline": <DashboardOutline {...iconProps} />,
    "analytics-fill": <AnalyticsFill {...iconProps} />,
    "analytics-outline": <AnalyticsOutline {...iconProps} />,
    "provider-fill": <ProviderFill {...iconProps} />,
    "provider-outline": <ProviderOutline {...iconProps} />,
    "customer-outline": <CustomerOutline {...iconProps} />,
    "customer-fill": <CustomerFill {...iconProps} />,
    "store-outline": <StoreOutline {...iconProps} />,
    "store-fill": <StoreFill {...iconProps} />,
    "service-outline": <ServiceOutline {...iconProps} />,
    "service-fill": <ServiceFill {...iconProps} />,
    "subscription-outline": <SubscriptionOutline {...iconProps} />,
    "subscription-fill": <SubscriptionFill {...iconProps} />,
    "card-fill": <CardFill {...iconProps} />,
    "card-outline": <CardOutline {...iconProps} />,
    "request-fill": <RequestFill {...iconProps} />,
    "request-outline": <RequestOutline {...iconProps} />,
    "category-fill": <MenuFill {...iconProps} />,
    "category-outline": <MenuOutline {...iconProps} />,
    "verification-fill": <ContactFill {...iconProps} />,
    "verification-outline": <ContactOutline {...iconProps} />,
    "ticket-fill": <TicketFill {...iconProps} />,
    "ticket-outline": <TicketOutline {...iconProps} />,
    "bell-fill": <BellFill {...iconProps} />,
    "bell-outline": <BellOutline {...iconProps} />,
    "settings-fill": <SubscriptionFill {...iconProps} />,
    "settings-outline": <SubscriptionOutline {...iconProps} />,
    "user-outline": <UserOutline {...iconProps} />,
    "user-fill": <UserFill {...iconProps} />,
    "brick-outline": <BrickOutline {...iconProps} />,
    "chart-outline": <ChartOutline {...iconProps} />,
    "graph-outline": <GraphOutline {...iconProps} />,
    "warning-outline": <WarningOutline {...iconProps} />,
    "warning-fill": <WarningFill {...iconProps} />,
    "trash-fill": <TrashFill {...iconProps} />,
    "success-fill": <SuccessFill {...iconProps} />,
    "pencil-edit": <PencilEdit {...iconProps} />,
    "reshare-alt-outline": <ReshareAlt {...iconProps} />,
    "verified": <Verified {...iconProps} />,
    "verified-alt": <VerifiedAlt {...iconProps} />,
    "feature-outline": <FeatureOutline {...iconProps} />,
    "feature-fill": <FeatureFill {...iconProps} />,
    "check": <Check {...iconProps} />,
    "close-outline": <CloseOutline {...iconProps} />,
    "close-fill": <CloseFill {...iconProps} />,
    "edit-outline": <EditOutline {...iconProps} />,
    "double-check": <DoubleCheckFill {...iconProps} />,
    "like": <Like {...iconProps} />,
    "lock-fill": <LockFill {...iconProps} />,
    "chat-outline": <ChatOutline {...iconProps} />,
    "admin-user-outline": <AdminUserOutline {...iconProps} />,
    "admin-user-fill": <AdminUserFill {...iconProps} />,
    "clock-outline": <ClockOutline {...iconProps} />,
    "timer": <Timer {...iconProps} />,
    "send": <Send {...iconProps} />,
  };

  return iconMap[type] ?? null;
};