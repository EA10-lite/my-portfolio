import { Plus, Search, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Text } from "../main";
import { Dialog, DialogContent, DialogTrigger } from "../ui/dialog";
import { CATEGORY_ICONS, type CategoryIconName } from "../icons/categoryIcons";
import { useFormikContext, type FormikValues } from "formik";
import { cn } from "../../lib/utils";
import { FieldError } from "../ui/field";

interface IconPickerProps {
  name: string;
}

const IconPicker = ({ name }: IconPickerProps) => {
  const { setFieldValue, values, errors, touched } = useFormikContext<FormikValues>();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const selectedIconName = values[name] as CategoryIconName | undefined;
  const SelectedIcon = CATEGORY_ICONS.find(
    (i) => i.name === selectedIconName,
  )?.component;

  const filtered = useMemo(() => {
    const term = search.toLowerCase().trim();
    if (!term) return CATEGORY_ICONS;
    return CATEGORY_ICONS.filter(
      (icon) =>
        icon.name.toLowerCase().includes(term) ||
        icon.label.toLowerCase().includes(term),
    );
  }, [search]);

  const handleSelect = (iconName: CategoryIconName) => {
    setFieldValue(name, iconName);
    setOpen(false);
    setSearch("");
  };

  const handleClose = () => {
    setOpen(false);
    setSearch("");
  };

  const hasError = errors[name] && touched[name]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <div>
          <div className={
            cn(
              "flex items-center gap-[12px] border border-black/6 p-[16px] rounded-[6px] cursor-pointer hover:border-primary transition-colors",
              hasError
                ? "border-[#D8232A] focus:ring-[#D8232A]"
                  : "border-[#E3E3E3] focus:ring-primary"
              )
            }
          >
            {/* Preview */}
            <div className="w-[70px] h-[70px] rounded-full bg-gray flex items-center justify-center flex-shrink-0">
              {SelectedIcon ? (
                <SelectedIcon className="text-primary" size={22} />
              ) : (
                <Plus className="text-primary" />
              )}
            </div>
            <div className="flex flex-col gap-[2px]">
              <span className="text-[13px] font-[600]">
                {selectedIconName ?? "Choose Icon"}
              </span>
              <span className="text-[12px] text-black/40">
                {selectedIconName ? "Tap to change" : "Select a category icon"}
              </span>
            </div>
          </div>

          <FieldError
            errors={hasError ? [{ message: errors[name] as string }] : []}
          />
        </div>
      </DialogTrigger>

      <DialogContent
        className="
          bg-white rounded-[10px] border border-black/6
          shadow-none [&>button.absolute]:hidden
          z-[99] p-[20px] min-w-[400px] max-w-[440px]
          max-h-[560px] overflow-y-auto
        "
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-[16px]">
          <Text title="Choose Icon" className="font-[600] text-[20px]" />
          <button type="button" onClick={handleClose}>
            <X className="size-4 cursor-pointer text-black/40 hover:text-black" />
          </button>
        </div>

        {/* Search */}
        <div className="relative mb-[16px]">
          <Search className="absolute left-[12px] top-1/2 -translate-y-1/2 size-4 text-black/30" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search icons..."
            className="w-full h-[40px] pl-[36px] pr-[12px] rounded-[6px] border border-black/10 text-[13px] outline-none focus:border-primary"
          />
        </div>

        {/* Icon grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-[32px] text-[13px] text-black/30">
            No icons found for "{search}"
          </div>
        ) : (
          <div className="grid grid-cols-5 gap-[8px]">
            {filtered.map(({ name: iconName, component: Icon, label }) => {
              const isSelected = selectedIconName === iconName;
              return (
                <button
                  key={iconName}
                  type="button"
                  title={label}
                  onClick={() => handleSelect(iconName as CategoryIconName)}
                  className={`
                    w-full aspect-square rounded-full flex items-center justify-center
                    transition-colors
                    ${isSelected
                      ? "bg-primary text-white"
                      : "bg-gray text-primary hover:bg-primary/20"
                    }
                  `}
                >
                  <Icon size={22} />
                </button>
              );
            })}
          </div>
        )}

        <p className="text-[11px] text-black/30 text-center mt-[12px]">
          {filtered.length} icons available
        </p>
      </DialogContent>
    </Dialog>
  );
};

export default IconPicker;