import { useFormikContext, type FormikValues } from "formik";
import { LuLoaderCircle } from "react-icons/lu";
import { mergeClasses } from "../../lib/mergeclasses";
import { Button } from "../ui/button";

type SubmitProps = {
    title: string;
    className?: string;
    disabled?: boolean;
    loading?: boolean;
    type?: "submit" | "button" | "reset";
}

const Submit = ({
    title,
    className,
    disabled,
    loading,
    type = "submit"
}: SubmitProps) => {
    const { handleSubmit } = useFormikContext<FormikValues>();

    const onClick = () => {
        handleSubmit();
    }

    return (
        <Button
            className={mergeClasses("submit-btn bg-primary rounded-full w-full h-[50px] cursor-pointer text-white", className)}
            disabled={disabled || loading}
            type={type}
            onClick={onClick}
        >
            {loading ? (
                <LuLoaderCircle className="animate-spin" />
            ) : (
                <span className="text-sm font-semibold">
                    {title}
                </span>
            )}
        </Button>
    )
}

export default Submit;