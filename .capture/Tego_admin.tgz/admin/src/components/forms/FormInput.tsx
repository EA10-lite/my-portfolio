
import React from "react";
import { Input } from "../ui/input";
import { cn } from "../../lib/utils";

interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> {
    name: string;
    placeholder?: string;
    type: string;
    handleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
    disabled?: boolean;
    value: string | number;
    styles?: string;
    hasError?: boolean;
}

const FormInput: React.FC<InputProps> = ({
    name,
    placeholder,
    type,
    value,
    handleChange,
    disabled = false,
    styles,
    hasError,
    ...otherProps
}) => {
    return (
        <div className="form-input relative">
            <Input
                name={name}
                type={type}
                placeholder={placeholder}
                value={value}
                onChange={handleChange}
                disabled={disabled}
                onKeyDown={(e) => {
                    e.stopPropagation();
                    if (otherProps.onKeyDown) {
                        otherProps.onKeyDown(e);
                    }
                }}
                className={cn(
                    "rounded-[6px] w-full px-[20px] border h-[56px] focus:outline-none focus-visible:ring-black focus-visible:ring-[0.5px] transition-all text-black text-sm font-medium",
                    hasError ? "border-[#D8232A] focus:ring-[#D8232A]" : "border-[#E3E3E3] focus:ring-primary",
                    styles
                  )}
                {...otherProps}
            />
        </div>
    )
}

export default FormInput;