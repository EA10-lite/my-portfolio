import { type FormikValues, useFormikContext } from "formik";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { cn } from "../../lib/utils";


interface TextboxProps {
    name: string;
    label?: string;
    isOptional?: boolean;
    isMandatory?: boolean;
    disabled?: boolean;
    placeholder?: string;
    styles?: string;
}

const Textbox = ({
    label,
    name,
    isOptional,
    isMandatory,
    disabled,
    placeholder,
    styles,
}: TextboxProps) => {
    const { values, handleChange, errors, touched} = useFormikContext<FormikValues>();
    const hasError = touched[name] && errors[name];

    return (
        <div className="">
            <div className="space-y-1.5">
                {label && (
                    <Label className="text-sm font-medium mb-2">
                        {label}
                        {isMandatory && (
                            <span className="text-primary">*</span>
                        )}
                        {isOptional && (
                            <span className="text-primary rounded-full px-2 bg-[#FFFFFF05] text-xs inline py-1">Optional</span>
                        )}
                    </Label>
                )}
                <Textarea
                    name={name}
                    className={cn("min-h-[109px] border border-primary/10 resize-none focus:outline-none focus-visible:ring-black focus-visible:ring-[0.5px] transition-all text-black text-sm font-medium rounded-[6px] shadow-none", hasError ? "border-[#D8232A] focus:ring-[#D8232A]" : "border-[#E3E3E3] focus:ring-primary",
                        styles)}
                    value={values[name]}
                    onChange={handleChange}
                    disabled={disabled}
                    onKeyDown={(e) => e.stopPropagation()}
                    placeholder={placeholder}
                />
            </div>
        </div>
    )
}

export default Textbox;