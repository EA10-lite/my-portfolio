import React, {
    useCallback,
    useEffect,
    useMemo,
    useRef,
} from "react";

import {
    type FormikValues,
    useFormikContext,
} from "formik";

import { LuTrash2 } from "react-icons/lu";
import { Image } from "lucide-react";

import { FieldError } from "../ui/field";
import { cn } from "../../lib/utils";

interface ImagePickerProps {
    name: string;
    label?: string;
    required?: boolean;
    disabled?: boolean;
    acceptedTypes?: string[];
    maxSize?: number;
    placeholder?: string;
    multiple?: boolean;
    maxFiles?: number;
    customHandleChange?: (files: File[] | File | null) => void;
    icon?: boolean;
    showPreview?: boolean;
    note?: string;
}

const ImagePicker: React.FC<ImagePickerProps> = ({
    name,
    disabled = false,
    acceptedTypes = [
        "image/jpeg",
        "image/png",
        "application/pdf",
    ],
    placeholder,
    multiple = false,
    maxFiles = 5,
    customHandleChange,
    showPreview = true,
    note,
}) => {
    const {
        errors,
        touched,
        setFieldValue,
        values,
    } = useFormikContext<FormikValues>();

    const fileInputRef = useRef<HTMLInputElement>(null);

    /**
     * Derive selected files directly from Formik
     */
    const selectedFiles = useMemo(() => {
        const formikFiles = values[name];

        if (!formikFiles) {
            return [];
        }

        return Array.isArray(formikFiles)
            ? formikFiles
            : [formikFiles];
    }, [values, name]);

    /**
     * Create preview URL only when there is
     * exactly one image selected.
     */
    const previewUrl = useMemo(() => {
        if (
            !showPreview ||
            selectedFiles.length !== 1 ||
            !selectedFiles[0]?.type?.startsWith("image/")
        ) {
            return null;
        }

        return URL.createObjectURL(selectedFiles[0]);
    }, [selectedFiles, showPreview]);

    /**
     * Clean up object URL
     */
    useEffect(() => {
        return () => {
            if (previewUrl) {
                URL.revokeObjectURL(previewUrl);
            }
        };
    }, [previewUrl]);

    /**
     * Clear file input when Formik is reset
     */
    useEffect(() => {
        const formikFiles = values[name];

        if (
            !formikFiles ||
            (Array.isArray(formikFiles) &&
                formikFiles.length === 0)
        ) {
            if (fileInputRef.current) {
                fileInputRef.current.value = "";
            }
        }
    }, [values, name]);

    /**
     * Handle file selection
     */
    const handleFileSelect = useCallback(
        (files: File[]) => {
            const currentFiles = values[name];

            const existingFiles = Array.isArray(currentFiles)
                ? currentFiles
                : currentFiles
                    ? [currentFiles]
                    : [];

            /**
             * When multiple is false, selecting a new file
             * should replace the existing file.
             */
            if (!multiple) {
                const file = files[0] || null;

                setFieldValue(name, file);

                customHandleChange?.(file);

                if (fileInputRef.current) {
                    fileInputRef.current.value = "";
                }

                return;
            }

            /**
             * Multiple files
             */
            const newFiles = [...existingFiles];

            files.forEach((file) => {
                /**
                 * Stop adding when max files is reached
                 */
                if (newFiles.length >= maxFiles) {
                    return;
                }

                /**
                 * Prevent duplicate files
                 */
                const isDuplicate = newFiles.some(
                    (existingFile) =>
                        existingFile.name === file.name &&
                        existingFile.size === file.size
                );

                if (!isDuplicate) {
                    newFiles.push(file);
                }
            });

            setFieldValue(name, newFiles);

            customHandleChange?.(newFiles);

            /**
             * Clear input so the same file can
             * be selected again
             */
            if (fileInputRef.current) {
                fileInputRef.current.value = "";
            }
        },
        [
            name,
            maxFiles,
            multiple,
            values,
            setFieldValue,
            customHandleChange,
        ]
    );

    /**
     * Handle drag and drop
     */
    const handleDrop = useCallback(
        (e: React.DragEvent<HTMLDivElement>) => {
            e.preventDefault();

            if (disabled) {
                return;
            }

            const files = Array.from(
                e.dataTransfer.files
            );

            if (files.length > 0) {
                handleFileSelect(files);
            }
        },
        [handleFileSelect, disabled]
    );

    /**
     * Prevent browser from opening dropped files
     */
    const handleDragOver = (
        e: React.DragEvent<HTMLDivElement>
    ) => {
        e.preventDefault();
    };

    /**
     * Handle native file input
     */
    const handleFileInputChange = (
        e: React.ChangeEvent<HTMLInputElement>
    ) => {
        const files = e.target.files;

        if (files && files.length > 0) {
            handleFileSelect(Array.from(files));
        }
    };

    /**
     * Open file picker
     */
    const handleBrowseClick = () => {
        if (
            !disabled &&
            fileInputRef.current
        ) {
            fileInputRef.current.click();
        }
    };

    /**
     * Remove selected file
     */
    const handleRemoveFile = (
        e: React.MouseEvent,
        fileToRemove?: File
    ) => {
        /**
         * Prevent the click from bubbling to
         * the upload/drop zone.
         */
        e.stopPropagation();

        if (fileToRemove) {
            const newFiles = selectedFiles.filter(
                (file) =>
                    !(
                        file.name === fileToRemove.name &&
                        file.size === fileToRemove.size
                    )
            );

            setFieldValue(
                name,
                multiple
                    ? newFiles
                    : newFiles[0] || null
            );

            customHandleChange?.(
                multiple
                    ? newFiles
                    : newFiles[0] || null
            );
        } else {
            setFieldValue(
                name,
                multiple ? [] : null
            );

            customHandleChange?.(
                multiple ? [] : null
            );
        }

        /**
         * Allow selecting the same file again
         */
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    /**
     * Formik validation error
     */
    const hasError =
        Boolean(
            touched[name] &&
            errors[name]
        ) &&
        selectedFiles.length === 0;

    return (
        <div className="form-field mb-5">
            <div className="relative">
                {/* Hidden file input */}
                <input
                    ref={fileInputRef}
                    type="file"
                    accept={acceptedTypes.join(",")}
                    onChange={handleFileInputChange}
                    className="hidden"
                    disabled={disabled}
                    multiple={multiple}
                />

                {/* Upload / Drop zone */}
                <div
                    className={cn(
                        "relative border p-[20px] cursor-pointer transition-all duration-200 rounded-md",
                        disabled &&
                            "cursor-not-allowed opacity-60",
                        hasError
                            ? "border-[#D8232A] focus:ring-[#D8232A]"
                            : "border-[#E3E3E3] focus:ring-primary"
                    )}
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onClick={handleBrowseClick}
                >
                    <div className="flex items-center gap-4 w-full">
                        {/* Image placeholder / Preview */}
                        <div className="w-[50px] h-[50px] border border-black/6 rounded-[8px] overflow-hidden flex items-center justify-center flex-shrink-0">
                            {previewUrl ? (
                                <img
                                    src={previewUrl}
                                    alt={
                                        selectedFiles[0]?.name ||
                                        "Selected image"
                                    }
                                    className="w-full h-full object-cover"
                                />
                            ) : (
                                <Image className="text-primary" />
                            )}
                        </div>

                        {/* Upload information */}
                        <div className="flex flex-col gap-[8px]">
                            <p className="text-black text-sm font-[600] leading-base">
                                {placeholder ||
                                    "Drag & drop or choose file to upload"}
                            </p>

                            <p className="text-black/39 text-xs font-[500] leading-base">
                                Format: JPEG, PNG 3MB Max
                            </p>
                        </div>

                        {/* Note */}
                        {note && (
                            <div className="ml-auto self-start bg-[#C0C0C01A] rounded-[3px] px-[10.77px] h-[17px] flex items-center justify-center">
                                <span className="text-primary text-[9px] font-[600]">
                                    {note}
                                </span>
                            </div>
                        )}
                    </div>
                </div>

                {/* Selected files */}
                {selectedFiles.length > 0 &&
                    showPreview && (
                        <div className="mt-4 space-y-3">
                            <div className="space-y-2">
                                {selectedFiles.map(
                                    (
                                        file,
                                        index
                                    ) => {
                                        const isImage =
                                            file.type?.startsWith(
                                                "image/"
                                            );

                                        /**
                                         * Don't create another object URL
                                         * for the single-image case because
                                         * previewUrl is already handling it.
                                         */
                                        const filePreviewUrl =
                                            isImage &&
                                            !(
                                                selectedFiles.length ===
                                                    1 &&
                                                previewUrl
                                            )
                                                ? URL.createObjectURL(
                                                    file
                                                )
                                                : null;

                                        return (
                                            <div
                                                key={`${file.name}-${file.size}-${index}`}
                                                className="flex items-center gap-3"
                                            >
                                                {/* Multiple image preview */}
                                                {isImage &&
                                                    filePreviewUrl && (
                                                        <div className="relative group w-[50px] h-[50px] flex-shrink-0">
                                                            <img
                                                                src={
                                                                    filePreviewUrl
                                                                }
                                                                alt={
                                                                    file.name
                                                                }
                                                                className="w-full h-full object-cover rounded-md"
                                                                onLoad={() =>
                                                                    URL.revokeObjectURL(
                                                                        filePreviewUrl
                                                                    )
                                                                }
                                                            />

                                                            <button
                                                                type="button"
                                                                className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-md"
                                                                onClick={(
                                                                    e
                                                                ) =>
                                                                    handleRemoveFile(
                                                                        e,
                                                                        file
                                                                    )
                                                                }
                                                            >
                                                                <LuTrash2 className="text-white" />
                                                            </button>
                                                        </div>
                                                    )}

                                                {/* Non-image file */}
                                                {!isImage && (
                                                    <button
                                                        type="button"
                                                        className="text-red-600 cursor-pointer"
                                                        onClick={(
                                                            e
                                                        ) =>
                                                            handleRemoveFile(
                                                                e,
                                                                file
                                                            )
                                                        }
                                                    >
                                                        <LuTrash2 />
                                                    </button>
                                                )}

                                                {/* File name */}
                                                <span className="text-xs text-black/60 truncate">
                                                    {file.name}
                                                </span>
                                            </div>
                                        );
                                    }
                                )}
                            </div>
                        </div>
                    )}

                {/* Error message */}
                <FieldError
                    errors={
                        hasError
                            ? [
                                {
                                    message:
                                        errors[
                                            name
                                        ] as string,
                                },
                            ]
                            : []
                    }
                />
            </div>
        </div>
    );
};

export default ImagePicker;