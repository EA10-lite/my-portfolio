import { PiExport } from "react-icons/pi";
import { Text } from "../main";
import { Button } from "../ui/button";
import MetricCard, { MetricCardSkeleton } from "./MetricCard";
import type { IconType } from "../icons/lib";


interface PageHeaderProps {
    title: string;
    description?: string;
    metrics?: {
        label: string;
        value: number | string;
        percentageIncrease: number;
        filter: string;
        iconType?: IconType;
    }[];
    hasDownload?: boolean;
    onDownload?: () => void;
    actionButton?: {
        title: string;
        onClick: () => void;
        variant: "secondary" | "default",
        icon?: React.ReactNode;
    };
    triggerBtn?: React.ReactNode;
    loading?: boolean;
}

const PageHeader = ({
    title,
    description,
    metrics,
    hasDownload,
    onDownload,
    actionButton,
    triggerBtn,
    loading,
} : PageHeaderProps) => {
    return (
        <div className="space-y-[30px]">
            <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex flex-col gap-[10px]">
                    <Text
                        title={title}
                        type="h2"
                        className="font-semibold text-xl"
                    />
                    {description &&(
                        <Text
                            title={description}
                            className="font-medium text-black/50"
                        />
                    )}
                </div>
                <div className="flex items-center gap-4">
                    {triggerBtn ? triggerBtn : actionButton && (
                        <Button size="lg" variant={actionButton.variant} onClick={onDownload} className="rounded-full flex items-center gap-[4px]">
                            {actionButton.icon}
                            <span className="font-[600] text-[13px]">{actionButton.title}</span>
                        </Button>
                    )}
                    {hasDownload && (
                        <Button size="lg" variant="default" onClick={actionButton?.onClick} className="rounded-full flex items-center gap-[4px]">
                            <PiExport />
                            <span className="font-[600] text-[13px]">Export Report</span>
                        </Button>
                    )}
                </div>
            </div>

            { loading ? (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-[10px]">
                    {[1,2,3,4].map(item => <MetricCardSkeleton key={item} />)}
                </div>
            ) : metrics && (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-[10px]">
                    {metrics.map((metric, index)=> (
                        <MetricCard
                            key={index}
                            title={metric.label}
                            value={metric.value}
                            filter={metric.filter}
                            percentageIncrease={metric.percentageIncrease}
                            iconType={metric.iconType}
                        />
                    ))}
                </div>
            )}
        </div>
    )
}

export default PageHeader;