import { TrendingDown, TrendingUp } from "lucide-react";
import { Text } from "../main";
import { getIcon, type IconType } from "../icons/lib";
import { Skeleton } from "../ui/skeleton";

export interface Metric {
    title: string;
    value: number | string;
    percentageIncrease: number;
    filter: string;
    iconType?: IconType;
}


const MetricCard = ({ title, value, percentageIncrease, filter, iconType} : Metric) => {
    return (
        <div className="bg-gray rounded-[10px] flex flex-col justify-between">
            <div className="p-[20px] flex items-center justify-between">
                <Text
                    className="font-[500] text-black/50 -tracker-[0.24px]"
                    title={title}
                    type="h4"
                />

                {iconType && getIcon(iconType)}
            </div>
            <div className="bg-white border border-black/5 rounded-[10px] px-[20px] py-[18px] flex flex-col gap-[16px]">
                <Text
                    type="h2"
                    className="text-primary font-semibold text-xl"
                    title={value.toString()}
                />

                <div className="flex items-center justify-between">
                    <Text
                        className="text-xs font-[500] text-black/50 uppercase"
                        title={filter}
                    />

                    <div className="flex items-center gap-[4px]">
                        {percentageIncrease > 0 ?
                            <TrendingUp className="text-success" size={14} />
                                : <TrendingDown className="text-destructive" size={14} />}

                        <Text
                            title={`${percentageIncrease > 0 ? "+" : ""}${percentageIncrease}%`}
                            className={`text-xs font-[600] ${percentageIncrease > 0 ? "text-success" : "text-destructive"}`}
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}

export const MetricCardSkeleton = () => {
    return (
        <div className="bg-gray rounded-[10px]">
            <div className="p-[20px] flex items-center justify-between">
                <Skeleton className="h-4 w-28 rounded-md" />
                <Skeleton className="h-6 w-6 rounded-md" />
            </div>

            <div className="bg-white border border-black/5 rounded-[10px] px-[20px] py-[18px] flex flex-col gap-[16px]">
                <Skeleton className="h-8 w-24 rounded-md" />

                <div className="flex items-center justify-between">
                <Skeleton className="h-3 w-16 rounded-md" />

                <div className="flex items-center gap-[4px]">
                    <Skeleton className="h-3 w-3 rounded-full" />
                    <Skeleton className="h-3 w-12 rounded-md" />
                </div>
                </div>
            </div>
        </div>
    );
};


export default MetricCard;