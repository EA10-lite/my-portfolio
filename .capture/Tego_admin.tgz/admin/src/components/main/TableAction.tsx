import { MoreVertical } from "lucide-react";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "../ui/dropdown-menu"
import { Button } from "../ui/button";
import React from "react";

interface TableActionItem {
    label: string
    content: React.ReactNode
}

interface TableActionProps {
    items?: TableActionItem[]
}

const TableAction = ({ items }: TableActionProps) => {
    const validItems = items?.filter(item => !!item.content)

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-8 w-8 p-0 bg-[#C0C0C01A] rounded-full text-black/50 flex items-center justify-center">
                    <MoreVertical className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="table-action-dropdown min-w-[350px] bg-white shadow-none p-[20px] space-y-[6px] rounded-[6px]" align="end">
                {validItems?.map((item, index) => (
                    <React.Fragment key={item.label}>
                        <DropdownMenuItem
                            onSelect={(e) => e.preventDefault()}
                            className="bg-transparent p-0 hover:bg-transparent focus:bg-transparent cursor-pointer"
                        >
                            {item.content}
                        </DropdownMenuItem>
                        {index < validItems.length - 1 && (
                            <DropdownMenuSeparator className="bg-black/6 my-4" />
                        )}
                    </React.Fragment>
                ))}
            </DropdownMenuContent>
        </DropdownMenu>
    )
}

export default TableAction;