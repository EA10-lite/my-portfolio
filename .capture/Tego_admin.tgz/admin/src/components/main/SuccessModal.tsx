import { X } from "lucide-react";
import { Button } from "../ui/button";
import { Dialog, DialogClose, DialogContent } from "../ui/dialog";
import Text from "./Text"
import { mergeClasses } from "../../lib/mergeclasses";


const SuccessModal = ({
    title,
    description,
    onOpenChange,
    open,
    Icon,
    style,
} : {
    title: string;
    description: string;
    onOpenChange: () => void;
    open: boolean;
    Icon: React.ReactNode
    style?: string;
}) => {
    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent
                className="
                    bg-white
                    rounded-[30px]
                    border-none
                    shadow-none
                    overflow-hidden
                    [&>button.absolute]:hidden
                    z-[99]
                    p-0
                    min-w-[457px]
                "
            >
                <div className="success-modal">
                    <div className="success-modal-header min-h-[204px] flex flex-col items-center justify-center relative">
                        <div className="relative w-fit">
                            <img src="/icons/hexagon.svg" alt="Hexagon" />

                            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                                {Icon}
                            </div>
                        </div>

                        <button onClick={onOpenChange} className="absolute right-[30px] top-[30px] bg-white rounded-full w-[24px] h-[24px] flex items-center justify-center">
                            <X className="size-4" />
                        </button>

                    </div>
                    <div className="success-modal-body pb-[40px]">
                        <div className={mergeClasses("max-w-[237px] mx-auto flex flex-col items-center justify-center text-center gap-[40px]", style)}>
                            <div className="gap-[8px]">
                                <Text
                                    title={title}
                                    type="h4"
                                    className="font-[700] text-lg"
                                />
                                <Text
                                    title={description}
                                    type="p"
                                    className=""
                                />
                            </div>

                            <div className="flex items-center gap-[16px]">
                                <DialogClose>
                                    <Button
                                        variant="primary"
                                        className="h-[50px] w-[169px] rounded-[50px]"
                                    >
                                        Continue
                                    </Button>
                                </DialogClose>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    )
}

export default SuccessModal;