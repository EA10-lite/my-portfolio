




import { ChevronDown, ChevronUp } from "lucide-react";
import React, { useState } from "react";
import { Checkbox, Text } from "../main";
import { Button } from "../ui/button";

export interface FilterOption {
  label: string;
  value: string;
}

export interface FilterGroup {
  label: string;
  key: string;
  options: FilterOption[];
}

export interface FilterValues {
  [key: string]: string[];
}

interface FilterProps {
  filters: FilterGroup[];
  values: FilterValues;
  onApply: (values: FilterValues) => void;
  onReset?: () => void;
  closePopover?: (open: boolean) => void;
}

const Filter = ({
  filters,
  values,
  onApply,
  onReset,
  closePopover,
}: FilterProps) => {
  // 👇 lazy initializer — only runs once on mount, not on every re-render
  const [localValues, setLocalValues] = useState<FilterValues>(() =>
    // deep copy so we don't mutate the parent's state
    JSON.parse(JSON.stringify(values)),
  );


    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(filters.map(f => [f.key, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const toggleOption = (groupKey: string, value: string) => {
        setLocalValues((prev) => {
        const current = prev[groupKey] ?? [];
        const exists = current.includes(value);
        return {
            ...prev,
            [groupKey]: exists
            ? current.filter((v) => v !== value)
            : [...current, value],
        };
        });
    };

    const handleApply = () => {
        onApply(localValues);
        closePopover?.(false);
    };

    const handleClear = () => {
        const cleared = filters.reduce(
            (acc, group) => ({ ...acc, [group.key]: [] }),
            {} as FilterValues,
        );
        setLocalValues(cleared);
        onReset?.();
        closePopover?.(false);
    };

    return (
        <div className="flex flex-col gap-[16px]">
            {filters.map((filter, index) => (
                <React.Fragment key={filter.key}>
                    {/* Section */}
                    <div className="flex flex-col gap-[12px]">
                        {/* Header */}
                        <button
                            className="flex items-center justify-between w-full"
                            onClick={() => toggleSection(filter.key)}
                        >
                            <Text title={filter.label} className="text-sm font-[500]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections[filter.key]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>

                        {/* Options */}
                        {openSections[filter.key] && (
                            <div className="flex flex-col gap-[10px]">
                                {filter.options.map((option, index) => {
                                    return (
                                        <Checkbox
                                            key={index}
                                            label={option.label}
                                            checked={(localValues[filter.key] ?? []).includes(
                                                option.value,
                                            )}
                                            onChange={() => toggleOption(filter.key, option.value)}
                                        />
                                    )
                                })}
                            </div>
                        )}
                    </div>

                    {/* Divider */}
                    {index < filters.length - 1 && (
                        <div className="h-px bg-black/4" />
                    )}
                </React.Fragment>
            ))}

            <div className="flex items-center justify-between pt-[4px]">
                <Button
                    variant="muted"
                    className="rounded-[50px] text-xs px-[20px] h-[50px] min-w-[169px] text-sm font-[600]"
                    onClick={handleClear}
                >
                    Reset
                </Button>
                <Button
                    variant="primary"
                    className="rounded-[50px] text-xs px-[20px] h-[50px] min-w-[169px] text-sm font-[600]"
                    onClick={handleApply}
                >
                    Apply
                </Button>
            </div>
        </div>
    );
};

export default Filter;