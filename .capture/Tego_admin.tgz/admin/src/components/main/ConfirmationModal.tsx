import { Loader2, X } from "lucide-react";
import { Button } from "../ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "../ui/dialog";
import Text from "./Text"
import { cn } from "../../lib/utils";
import { mergeClasses } from "../../lib/mergeclasses";


const ConfirmationModal = ({
    title,
    description,
    onOpenChange,
    open,
    onContinue,
    Icon,
    TriggerButton,
    buttonTitle,
    buttonType="primary",
    loading,
    style,
} : {
    title: string;
    description: string;
    onOpenChange: (open: boolean) => void;
    open: boolean;
    Icon: React.ReactNode;
    onContinue: () => void;
    TriggerButton?: React.ReactNode;
    buttonTitle: string;
    buttonType?: "primary" | "muted" | "destructive";
    loading: boolean;
    style?: string;
}) => {
    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogTrigger asChild className="">
                {TriggerButton ? TriggerButton : (
                    <Button
                        variant={buttonType}
                        className={cn("outline w-full rounded-full h-12")}
                    >
                        {buttonTitle}
                    </Button>
                )}
            </DialogTrigger>
            <DialogContent
                className="
                    bg-white
                    rounded-[30px]
                    border-none
                    shadow-none
                    overflow-hidden
                    [&>button.absolute]:hidden
                    z-[99]
                    p-0
                    min-w-[457px]"
            >
                <div className="success-modal">
                    <div className="success-modal-header min-h-[204px] flex flex-col items-center justify-center relative">
                        <div className="relative w-fit">
                            <img src="/icons/hexagon.svg" alt="Hexagon" />

                            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-destructive">
                                {Icon}
                            </div>
                        </div>

                        <button onClick={()=> onOpenChange(false)} className="absolute right-[30px] top-[30px] bg-white rounded-full w-[24px] h-[24px] flex items-center justify-center">
                            <X className="size-4" />
                        </button>

                    </div>
                    <div className="success-modal-body pb-[40px]">
                        <div className={mergeClasses("max-w-[237px] mx-auto flex flex-col items-center justify-center text-center gap-[40px]", style)}>
                            <div className="gap-[8px]">
                                <Text
                                    title={title}
                                    type="h4"
                                    className="font-[700] text-lg"
                                />
                                <Text
                                    title={description}
                                    type="p"
                                    className=""
                                />
                            </div>

                            <div className="flex items-center justify-between gap-[16px]">
                                <DialogClose>
                                    <Button
                                        variant="muted"
                                        className={"h-[50px] w-[169px] rounded-[50px]"}
                                    >
                                        Cancel
                                    </Button>
                                </DialogClose>

                                <Button
                                    variant={buttonType}
                                    className="h-[50px] w-[169px] rounded-[50px]"
                                    onClick={onContinue}
                                >
                                    { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                                        <span>{buttonTitle || "Continue"}</span>
                                    )}
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    )
}

export default ConfirmationModal;