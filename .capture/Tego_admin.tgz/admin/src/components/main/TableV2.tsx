import {
    type ColumnDef,
    flexRender,
    getCoreRowModel,
    useReactTable,
  } from "@tanstack/react-table";
  import { useState } from "react";
  import { Text } from "../main";
  
  interface TableProps<T> {
    data: T[];
    columns: ColumnDef<T>[];
    title?: string;
    TitleComponent?: React.ReactNode; // 👈 inline component next to title
    selectable?: boolean;             // 👈 enable checkboxes
    onSelectionChange?: (selectedRows: T[]) => void;
    ActionComponent?: React.ReactNode;
    filters?: React.ReactNode;
    isLoading?: boolean;
    emptyMessage?: string;
  }
  
  function Table<T>({
    data,
    columns,
    title,
    TitleComponent,
    selectable = false,
    onSelectionChange,
    ActionComponent,
    filters,
    isLoading,
    emptyMessage = "No data available",
  }: TableProps<T>) {
    const [rowSelection, setRowSelection] = useState<Record<string, boolean>>({});
  
    // Inject checkbox column if selectable
    const checkboxColumn: ColumnDef<T> = {
      id: "select",
      header: ({ table }) => (
        <input
          type="checkbox"
          className="w-4 h-4 bg-white border border-primary cursor-pointer hidden"
          checked={table.getIsAllRowsSelected()}
          ref={(el) => {
            if (el) el.indeterminate = table.getIsSomeRowsSelected();
          }}
          onChange={table.getToggleAllRowsSelectedHandler()}
        />
      ),
      cell: ({ row }) => (
        <input
          type="checkbox"
          className="w-4 h-4 bg-white border border-primary cursor-pointer"
          checked={row.getIsSelected()}
          onChange={row.getToggleSelectedHandler()}
        />
      ),
      size: 40,
    };
  
    const resolvedColumns = selectable
      ? [checkboxColumn, ...columns]
      : columns;
  
    const table = useReactTable({
      data,
      columns: resolvedColumns,
      state: { rowSelection },
      onRowSelectionChange: (updater) => {
        const next =
          typeof updater === "function" ? updater(rowSelection) : updater;
        setRowSelection(next);
  
        if (onSelectionChange) {
          const selectedRows = Object.keys(next)
            .filter((key) => next[key])
            .map((key) => data[parseInt(key)]);
          onSelectionChange(selectedRows);
        }
      },
      getCoreRowModel: getCoreRowModel(),
      enableRowSelection: selectable,
    });
  
    const selectedCount = Object.values(rowSelection).filter(Boolean).length;
  
    return (
      <div className="flex flex-col gap-[16px]">
        {/* Header */}
        {(title || ActionComponent || filters) && (
          <div className="flex items-center justify-between gap-[12px]">
            <div className="flex items-center gap-[8px]">
              {title && (
                <Text
                  title={title}
                  type="h3"
                  className="font-[600] text-[16px]"
                />
              )}
              {/* 👇 inline component next to title e.g. badge, count, pill */}
              {TitleComponent}
  
              {/* Selected count badge */}
              {selectable && selectedCount > 0 && (
                <div className="flex items-center gap-[6px] bg-primary/10 text-primary text-[12px] font-[500] px-[10px] py-[4px] rounded-full">
                  <span>{selectedCount} selected</span>
                  <button
                    className="hover:opacity-70 transition-opacity"
                    onClick={() => setRowSelection({})}
                  >
                    ✕
                  </button>
                </div>
              )}
            </div>
  
            <div className="flex items-center gap-[8px]">
              {filters}
              {ActionComponent}
            </div>
          </div>
        )}
  
        {/* Table */}
        <div className="rounded-[10px] border border-black/5 overflow-hidden">
          <table className="w-full">
            <thead>
              {table.getHeaderGroups().map((headerGroup) => (
                <tr
                  key={headerGroup.id}
                  className="bg-[#F9F9F9] border-b border-black/5"
                >
                  {headerGroup.headers.map((header) => (
                    <th
                      key={header.id}
                      className="px-[20px] py-[14px] text-left text-[12px] font-[600] text-black/50 uppercase tracking-wide whitespace-nowrap"
                      style={{ width: header.getSize() }}
                    >
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext(),
                          )}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
  
            <tbody>
              {isLoading ? (
                // Skeleton rows
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b border-black/5 last:border-0">
                    {resolvedColumns.map((_, colIndex) => (
                      <td key={colIndex} className="px-[20px] py-[16px]">
                        <div className="h-[12px] rounded-full bg-black/5 animate-pulse w-[80%]" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : table.getRowModel().rows.length === 0 ? (
                <tr>
                  <td
                    colSpan={resolvedColumns.length}
                    className="text-center py-[40px] text-[13px] text-black/40"
                  >
                    {emptyMessage}
                  </td>
                </tr>
              ) : (
                table.getRowModel().rows.map((row) => (
                  <tr
                    key={row.id}
                    className={`
                      border-b border-black/5 last:border-0 transition-colors
                      ${row.getIsSelected() ? "bg-primary/5" : "hover:bg-[#FAFAFA]"}
                      ${selectable ? "cursor-pointer" : ""}
                    `}
                    onClick={
                      selectable
                        ? () => row.toggleSelected()
                        : undefined
                    }
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td
                        key={cell.id}
                        className="px-[20px] py-[16px] text-[13px] text-black/80"
                        onClick={
                          // prevent row click from double-toggling when clicking checkbox directly
                          cell.column.id === "select"
                            ? (e) => e.stopPropagation()
                            : undefined
                        }
                      >
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext(),
                        )}
                      </td>
                    ))}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  
  export default Table;