import Text from "./Text"

// components/shared/Checkbox.tsx
interface CheckboxProps {
    label: string
    checked: boolean
    onChange: () => void;
    type?: "radio" | "checkbox";
}

const Checkbox = ({
    label,
    checked,
    onChange,
    type = "checkbox"
}: CheckboxProps) => {
    return (
        <button
            className="flex items-center gap-[10px]"
            onClick={onChange}
        >
            <div className={`w-[16px] h-[16px] ${type === "radio" ? "rounded-full" : "rounded-[2px]"} border flex items-center justify-center transition-colors ${checked ? type === "checkbox" ? "bg-primary border-primary" : "border-primary" : "border-black/20"}`}>
                {checked && type !== "radio" && (
                    <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                        <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                )}
                {type === "radio"  &&  checked && (
                    <div className="w-[12px] h-[12px] rounded-full bg-primary" />
                )}
            </div>
            <Text
                title={label}
                className={`text-[13px] font-[500] transition-colors ${checked ? "text-primary" : "text-black/50"}`}
                type="h5"
            />
        </button>
    )
}

export default Checkbox