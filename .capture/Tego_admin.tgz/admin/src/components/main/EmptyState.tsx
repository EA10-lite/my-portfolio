import { getIcon, type IconType } from "../icons/lib"

export interface EmptyStateProps {
    emptyMessage: {
        title: string;
        icon?: IconType;
        description: string;
    }
}

const EmptyState = ({
    emptyMessage
}: EmptyStateProps) => {
    return (
        <div className="flex flex-col items-center justify-center py-22 mx-auto w-full">
            <div className="relative w-fit">
                <img src="/icons/hexagon-alt.svg" alt="Hexagon" />
                <div className="absolute inset-0 flex items-center justify-center">
                    {getIcon(emptyMessage.icon ?? "user-outline", { color: "#33ABF7"})}
                </div>
            </div>
            <div className="gap-[8px] text-center max-w-[355px] mx-auto">
                <h4 className="text-base font-[600]">
                    {emptyMessage.title}
                </h4>
                <p className="text-sm text-black/50 font-[400]">
                    {emptyMessage.description}
                </p>
            </div>
        </div>
    )
}

export default EmptyState;