import type { PropsWithChildren } from "react";
import { Eye, X } from "lucide-react";
import { Button } from "../ui/button"
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "../ui/sheet"
import { cn } from "../../lib/utils";
import Text from "./Text";

type DetailsModalProps = PropsWithChildren<{
  title: string;
  description?: string;
  buttonType?: "ghost" | "default" | "destructive" | "muted",
  buttonTitle?: string;
  ActionButton?: React.ReactNode;
  TriggerButton?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  hasFooter?:boolean;
}>

const DetailsModal = ({
  title,
  description,
  buttonType = "muted",
  buttonTitle = "Cancel",
  ActionButton,
  TriggerButton,
  children,
  open,
  hasFooter=true,
  onOpenChange
}: DetailsModalProps) => {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetTrigger
        asChild
        className={cn(
          "bg-secondary-muted hover:bg-secondary-muted",
          TriggerButton && "bg-transparent hover:bg-transparent")
        }
      >
        {TriggerButton ? TriggerButton : (
          <Button
            className="bg-transparent hover:bg-secondary-alt-foreground hover:text-primary hover:[&>svg]:text-primary text-white rounded-xs w-full justify-start p-1.5 cursor-pointer"
          >
            <Eye className="text-white"/>
            <span>View</span>
          </Button>
        )}
      </SheetTrigger>
      <SheetContent className="min-w-[605px] bg-white border-[0.5px] border-primary/8 right-10 rounded-xl h-fit max-h-[90vh] overflow-auto top-1/2 -translate-y-1/2 p-0 [&>button.absolute]:hidden pb-4">
        <SheetHeader className="flex flex-row items-start justify-between m-0 pb-0">
          <div className="">
            <SheetTitle className="text-black">{title}</SheetTitle>
            {description && (
              <div className="max-w-[442px] mt-[12px]">
                <Text
                  title={description}
                  className="text-[13px] font-[500] text-black/50"
                />
              </div>
            )}
          </div>

          <SheetClose className="text-black border-none">
            <X className="size-4" />
          </SheetClose>
        </SheetHeader>


        {children}

        {hasFooter && (
          <SheetFooter className="flex items-center justify-between">
            <div className="w-full flex items-center justify-between">
              <Button
                className="rounded-full h-12 min-w-[169px]"
                variant={buttonType ?? "muted"}
                onClick={()=> onOpenChange?.(false)}
              >
                <span>{buttonTitle ?? "Cancel"}</span>
              </Button>
              {ActionButton}
            </div>
          </SheetFooter>
        )}
      </SheetContent>
    </Sheet>
  )
}

export default DetailsModal;