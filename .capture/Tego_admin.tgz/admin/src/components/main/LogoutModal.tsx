import { LogOut } from "lucide-react";
import { Button } from "../ui/button";
import { Dialog, DialogClose, DialogContent, DialogTrigger } from "../ui/dialog";
import { SidebarMenuButton, SidebarMenuItem } from "../ui/sidebar";
import Text from "./Text"
import { cn } from "../../lib/utils";


const LogoutModal = ({ handleLogout } : { handleLogout: () => void }) => {
    return (
        <Dialog>
            <DialogTrigger asChild className="">
                <SidebarMenuItem>
                    <SidebarMenuButton
                        asChild
                        className={cn(
                        "text-white py-6 px-4 rounded-lg hover:bg-white/10 hover:text-white active:bg-transparent transition-colors",
                        )}
                    >
                        <div className="cursor-pointer">
                            <LogOut className="size-4 shrink-0" />
                            <span>Logout</span>
                        </div>
                    </SidebarMenuButton>
                </SidebarMenuItem>

            </DialogTrigger>
            <DialogContent
                className="
                    bg-white
                    rounded-[30px]
                    border-none
                    shadow-none
                    overflow-hidden
                    [&>button.absolute]:hidden
                    z-[99]
                    p-0
                    min-w-[580px]
                "
            >
                <div className="logout-modal py-[40px] px-[98px]">
                    <div className="flex flex-col items-center justify-center text-center gap-[40px]">
                        <div className="relative w-fit">
                            <img src="/icons/hexagon.svg" alt="Hexagon" />

                            <LogOut
                                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-destructive"
                                size={18}
                            />
                        </div>
                        <div className="gap-[8px]">
                            <Text
                                title="Are you sure you want to logout?"
                                type="h4"
                                className="font-[700] text-lg"
                            />
                            <Text
                                title="Logging out will end your current session. You can log back in anytime to continue managing your account."
                                type="p"
                                className=""
                            />
                        </div>

                        <div className="flex items-center gap-[16px]">
                            <DialogClose>
                                <Button
                                    variant="secondary"
                                    className="h-[50px] w-[169px] rounded-[50px] bg-[#C0C0C01A] text-black"
                                >
                                    Cancel
                                </Button>
                            </DialogClose>
                            <Button
                                title="Log Out"
                                value="destructive"
                                className="h-[50px] w-[169px] rounded-[50px] bg-destructive"
                                onClick={handleLogout}
                            >
                                Log Out
                            </Button>
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    )
}

export default LogoutModal;