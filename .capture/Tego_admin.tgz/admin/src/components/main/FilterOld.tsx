// components/shared/FilterContent.tsx
"use client"

import * as React from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "../ui/button"
import Text from "./Text"
import Checkbox from "./Checkbox"

interface FilterItem {
    label: string
    key: string
    options: {
        label: string;
        value: string;
    }[]
}

interface FilterContentProps {
    filters: FilterItem[]
    onApply: (selected: Record<string, string[]>) => void
    onReset: () => void;
    closePopover?: (open: boolean) => void;
}

const FilterContent = ({ filters, onApply, onReset, closePopover }: FilterContentProps) => {
    // const [localFilters, setLocalFilters] = React.useState({});
    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(filters.map(f => [f.key, true]))
    );
    const [selected, setSelected] = React.useState<Record<string, string[]>>({})

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const toggleOption = (key: string, option: string) => {
        setSelected(prev => {
            const current = prev[key] ?? []
            const exists = current.includes(option)
            return {
                ...prev,
                [key]: exists ? current.filter(o => o !== option) : [...current, option],
            }
        })
    }

    const handleReset = () => {
        setSelected({})
        setOpenSections(Object.fromEntries(filters.map(f => [f.key, true])))
        onReset()
    }

    const handleApply = () => {
        onApply(selected);
        closePopover?.(false);
    }

    return (
        <div className="flex flex-col gap-[16px]">
            {filters.map((filter, index) => (
                <React.Fragment key={filter.key}>
                    {/* Section */}
                    <div className="flex flex-col gap-[12px]">
                        {/* Header */}
                        <button
                            className="flex items-center justify-between w-full"
                            onClick={() => toggleSection(filter.key)}
                        >
                            <Text title={filter.label} className="text-sm font-[500]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections[filter.key]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>

                        {/* Options */}
                        {openSections[filter.key] && (
                            <div className="flex flex-col gap-[10px]">
                                {filter.options.map((option, index) => {
                                    const isChecked = selected[filter.key]?.includes(option.value) ?? false
                                    return (
                                        <Checkbox
                                            key={index}
                                            label={option.label}
                                            checked={isChecked}
                                            onChange={() => toggleOption(filter.key, option.value)}
                                        />
                                    )
                                })}
                            </div>
                        )}
                    </div>

                    {/* Divider */}
                    {index < filters.length - 1 && (
                        <div className="h-px bg-black/4" />
                    )}
                </React.Fragment>
            ))}

            {/* Actions */}
            <div className="flex items-center justify-between pt-[4px]">
                <Button
                    variant="muted"
                    className="rounded-[50px] text-xs px-[20px] h-[50px] min-w-[169px] text-sm font-[600]"
                    onClick={handleReset}
                >
                    Reset
                </Button>
                <Button
                    variant="primary"
                    className="rounded-[50px] text-xs px-[20px] h-[50px] min-w-[169px] text-sm font-[600]"
                    onClick={handleApply}
                >
                    Apply
                </Button>
            </div>
        </div>
    )
}

export default FilterContent