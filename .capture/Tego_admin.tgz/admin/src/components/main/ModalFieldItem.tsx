import { mergeClasses } from "../../lib/mergeclasses";
import Text from "./Text";


const ModalFieldItem = ({
    label,
    value,
    className,
    content,
}: {
    label?: string;
    value?: string | number;
    className?: string;
    content?: React.ReactNode;
}) => {
    return (
        <div className={mergeClasses(`flex flex-col gap-1.5`, className)}>
            {label && (
                <Text
                    title={label}
                    type="h4"
                    className="text-sm text-black/50 font-[500]"
                />
            )}


            {content && content}

            {value && !content && (
                <Text
                    title={value.toString()}
                    type="p"
                    className={"text-black font-[500] text-sm whitespace-pre-wrap"}
                />
            )}
        </div>
    )
}

export default ModalFieldItem;