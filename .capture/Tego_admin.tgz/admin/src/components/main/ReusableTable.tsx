"use client"

import * as React from "react";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "../ui/popover"
import {
    type ColumnDef,
    type ColumnFiltersState,
    type PaginationState,
    type OnChangeFn,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    useReactTable,
} from "@tanstack/react-table"
import { Check, ChevronDown, ChevronLeft, ChevronRight, Settings2, X } from "lucide-react"

import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "../ui/table"
import { Button } from "../ui/button"
import { Skeleton } from "../ui/skeleton"
import Text from "./Text"
import { type IconType } from "../icons/lib"
import EmptyState from "./EmptyState";
import type { PERIOD } from "../../services/types";

const DATE_OPTIONS: { label: string; value: string }[] = [
    { label: "All Time", value: "" },
    { label: "This Week", value: "7d" },
    { label: "This Month", value: "30d" },
    { label: "This Year", value: "1y" },
    { label: "Last 90 Days", value: "90d" },
]
interface ReusableTableProps<TData extends { id: string }, TValue> {
    columns: ColumnDef<TData, TValue>[]
    data: TData[]
    searchKeys?: string[]
    filterContent?: React.ReactElement<{ closePopover?: (open: boolean) => void }>;
    TitleComponent?: React.ReactElement;
    filterTitle?: string;
    showHeader?: boolean
    manualPagination?: boolean
    pageCount?: number
    rowCount?: number
    pagination?: PaginationState;
    onPaginationChange?: OnChangeFn<PaginationState>;
    onSelectionChange?: (selectedRows: TData[]) => void;
    isLoading?: boolean;
    title?: string;
    hasDateFilter?: boolean;
    dateColumnKey?: string;
    emptyMessage?: {
        title: string;
        description: string;
        icon: IconType;
    };
    showEmptyState?: boolean;
    selectable?: boolean;
    onRowSelect?: (id: string) => void;
    onDateFilterChange?: (period: PERIOD) => void;
}

export function ReusableTable<TData extends { id: string }, TValue>({
    columns,
    data,
    searchKeys,
    showHeader = true,
    manualPagination = false,
    pageCount,
    rowCount,
    pagination,
    onPaginationChange,
    onSelectionChange,
    isLoading = false,
    title = "",
    hasDateFilter = true,
    dateColumnKey = "createdAt",
    emptyMessage = {
        title: "No data found!",
        description: "There is currently no data to display.",
        icon: "customer-outline"
    },
    showEmptyState = true,
    filterContent,
    filterTitle,
    TitleComponent,
    selectable = false,
    onRowSelect,
    onDateFilterChange,
}: ReusableTableProps<TData, TValue>) {
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
    const [globalFilter, setGlobalFilter] = React.useState("")
    const [localPagination, setLocalPagination] = React.useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    })

    const [selectedDate, setSelectedDate] = React.useState<string | null>(null)
    const [datePopoverOpen, setDatePopoverOpen] = React.useState(false)
    const [filterPopoverOpen, setFilterPopoverOpen] = React.useState(false);

    const [rowSelection, setRowSelection] = React.useState<Record<string, boolean>>({});
    // Inject checkbox column if selectable
    const checkboxColumn: ColumnDef<TData> = {
        id: "select",
        header: () => null,
        cell: ({ row }) => (
            <div
                className={`w-4 h-4 rounded-[2px] border border-primary flex items-center justify-center cursor-pointer ${row.getIsSelected() ? "bg-primary" : ""}`}
                onClick={row.getToggleSelectedHandler()}
            >
                {row.getIsSelected() && <Check className="text-white size-3.5" />}
            </div>
        ),
        size: 40,
    };

    const selectedCount = Object.values(rowSelection).filter(Boolean).length;

    const resolvedColumns = selectable
        ? [checkboxColumn, ...columns]
        : columns;

    const table = useReactTable({
        data,
        columns: resolvedColumns,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: onPaginationChange || setLocalPagination,
        manualPagination,
        pageCount,
        rowCount,
        globalFilterFn: (row, _columnId, filterValue) => {
            if (!searchKeys || searchKeys.length === 0) return true;
            const searchValue = filterValue.toLowerCase();
            return searchKeys.some((key) => {
                const value = row.getValue(key);
                return String(value).toLowerCase().includes(searchValue);
            });
        },
        state: {
            columnFilters,
            globalFilter,
            pagination: pagination || localPagination,
            rowSelection,
        },
        onRowSelectionChange: (updater) => {
            const next =
                typeof updater === "function" ? updater(rowSelection) : updater;
            setRowSelection(next);
            if (onSelectionChange) {
                const selectedRows = Object.keys(next)
                    .filter((key) => next[key])
                    .map((key) => data[parseInt(key)]);
                onSelectionChange(selectedRows);
            }
        },
        enableRowSelection: selectable,
    })

    function getPaginationItems(pageCount: number, currentPage: number): (number | "...")[] {
        if (pageCount <= 3) {
            return Array.from({ length: pageCount }, (_, i) => i + 1)
        }

        const items: (number | "...")[] = []
        const showLeftEllipsis = currentPage > 1
        const showRightEllipsis = currentPage < pageCount - 2

        items.push(1)

        if (showLeftEllipsis) items.push("...")

        // Always show current page and its neighbours (clamped to valid range)
        const middle = new Set([currentPage, currentPage + 1, currentPage + 2]
            .filter(p => p > 1 && p < pageCount))
        middle.forEach(p => items.push(p))

        if (showRightEllipsis) items.push("...")
        items.push(pageCount)
        return items
    }

    const isFiltered = !!selectedDate || columnFilters.length > 0;
    const isAnyPopoverOpen = filterPopoverOpen || datePopoverOpen;

    return (
        <div className="reusable-table border border-black/6 rounded-md">
            {/* Overlay */}
            {isAnyPopoverOpen && (
                <div
                    className="fixed inset-0 bg-black/20 z-50"
                    onClick={() => {
                        setFilterPopoverOpen(false)
                        setDatePopoverOpen(false)
                    }}
                />
            )}
            <div className="w-full">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 py-4 px-6 relative">
                    <div className="flex items-center gap-4">
                        <Text title={title} className="font-[600] text-base" />
                        {/* 👇 inline component next to title e.g. badge, count, pill */}
                        {TitleComponent}

                        {/* Selected count badge */}
                        {selectable && selectedCount > 0 && (
                            <button
                                className="text-primary underline text-xs font-[500] cursor-pointer"
                                onClick={() => setRowSelection({})}
                            >
                                Clear Selection
                            </button>
                        )}
                    </div>
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                            {filterContent && (
                                <Popover open={filterPopoverOpen} onOpenChange={setFilterPopoverOpen}>
                                    <PopoverTrigger asChild>
                                        <Button
                                            variant={"outline"}
                                            className={`rounded-[50px] px-[20px] min-w-[105px] flex items-center gap-[6px] hover:bg-primary hover:text-white ${data.length > 0 ? "border-primary text-primary bg-[#FEFFFF]" : "border-black bg-[#F4FAFF80] text-black"}`}

                                        >
                                            Filter
                                            <Settings2 className="size-3" />
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent
                                        align="end"
                                        sideOffset={8}
                                        className="
                                            w-[543px]
                                            max-w-[calc(100vw-32px)]
                                            p-[20px]
                                            flex
                                            flex-col
                                            gap-[16px]
                                            rounded-[6px]
                                            shadow-none
                                            overflow-hidden
                                            z-[51]
                                            max-h-[var(--radix-popover-content-available-height)]
                                        "
                                    >
                                        {/* Fixed header */}
                                        <div className="flex items-center justify-between">
                                            <Text title={filterTitle || "Filter"} type="h4" className="text-sm font-[600]" />
                                            <X className="size-4 cursor-pointer" onClick={() => setFilterPopoverOpen(false)} />
                                        </div>

                                        {/* Scrollable content */}
                                        <div className="overflow-y-auto flex-1 flex flex-col gap-[16px] pr-1">
                                            {React.cloneElement(filterContent as React.ReactElement<{ closePopover: (open: boolean) => void }>, {
                                                closePopover: setFilterPopoverOpen,
                                            })}
                                        </div>
                                    </PopoverContent>
                                </Popover>
                            )}
                        </div>
                        {hasDateFilter && (
                            <Popover open={datePopoverOpen}>
                                <PopoverTrigger asChild onClick={() => setDatePopoverOpen(!datePopoverOpen)}>
                                    <Button
                                        variant={data?.length > 0 ? "primary" : "outline"}
                                        className={`rounded-[50px] border-black flex items-center gap-2`}
                                    >
                                        {selectedDate
                                            ? DATE_OPTIONS.find(o => o.value === selectedDate)?.label
                                            : "All Time"}
                                        <ChevronDown className="size-4" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent align="end" className="w-[350px] p-[20px] flex flex-col gap-[16px] rounded-[6px] shadow-none">
                                    <Text title="Select Time Period" type="h4" className="text-sm font-[600]" />

                                    {DATE_OPTIONS.map((item, index) => (
                                        <React.Fragment key={item.value}>
                                            <div
                                                className="flex items-center justify-between cursor-pointer"
                                                onClick={() => {
                                                    setSelectedDate(item.value)
                                                    table.getColumn(dateColumnKey)?.setFilterValue(item.value)
                                                    if (item.value !== null) {
                                                        onDateFilterChange?.(item.value as PERIOD)
                                                    }
                                                    setDatePopoverOpen(false)
                                                }}
                                            >
                                                <Text title={item.label} className="text-[13px] font-[500]" type="h5" />
                                                <div className="w-[16px] h-[16px] rounded-full border border-black/20 flex items-center justify-center">
                                                    {selectedDate === item.value && (
                                                        <div className="bg-primary w-[10px] h-[10px] rounded-full" />
                                                    )}
                                                </div>
                                            </div>
                                            {index < DATE_OPTIONS.length - 1 && (
                                                <div className="h-px bg-black/6" />
                                            )}
                                        </React.Fragment>
                                    ))}
                                </PopoverContent>
                            </Popover>
                        )}
                    </div>
                </div>

                <div className="rounded-md border-none">
                    <Table>
                        {showHeader && data.length > 0 && (
                            <TableHeader className="bg-gray">
                                {table.getHeaderGroups().map((headerGroup) => (
                                    <TableRow key={headerGroup.id} className="hover:bg-primary/4 border-none">
                                        {headerGroup.headers.map((header) => {
                                            return (
                                                <TableHead key={header.id} className="text-black font-[500] first:pl-6">
                                                    {header.isPlaceholder
                                                        ? null
                                                        : flexRender(
                                                            header.column.columnDef.header,
                                                            header.getContext()
                                                        )}
                                                </TableHead>
                                            )
                                        })}
                                    </TableRow>
                                ))}
                            </TableHeader>
                        )}
                        <TableBody className="[&_tr:last-child]:border-0">
                            {isLoading ? (
                                Array.from({ length: 10 }).map((_, index) => (
                                    <TableRow key={index} className="border-b border-primary/10 hover:bg-transparent">
                                        {resolvedColumns.map((_, colIndex) => (
                                            <TableCell key={colIndex} className="py-4 first:pl-6">
                                                <Skeleton className="h-4 w-full bg-primary/10" />
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map((row) => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && "selected"}
                                        className={`
                                            border-b border-primary/10 hover:bg-transparent
                                            ${row.getIsSelected() ? "bg-primary/5" : "hover:bg-[#FAFAFA]"}
                                            ${selectable ? "cursor-pointer" : ""}
                                          `}
                                        onClick={
                                            selectable
                                                ? () => {
                                                    row.toggleSelected();
                                                    onRowSelect?.(row.original.id ? "" : "" as string);
                                                }
                                                : undefined
                                        }
                                    >
                                        {row.getVisibleCells().map((cell) => (
                                            <TableCell key={cell.id} className="py-4 first:pl-6 text-sm text-black/70 font-[500]">
                                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : null}
                        </TableBody>
                    </Table>

                    {(data.length <= 0 || table.getRowModel().rows?.length <= 0) && showEmptyState && !isLoading && (
                        <EmptyState
                            emptyMessage={{
                                title: isFiltered ? "No results found" : emptyMessage.title,
                                description: isFiltered
                                    ? "Try adjusting your filters or selecting a different time period."
                                    : emptyMessage.description,
                                icon: emptyMessage.icon,
                            }}
                        />
                    )}
                </div>
            </div>
            {/* Pagination */}
            {data.length > 0 && pageCount && pageCount > 0 ? (
                <div className="flex items-center justify-between px-2 py-4">
                    <div className="text-sm text-black/50 font-[500]">
                        Showing {table.getState().pagination.pageIndex * table.getState().pagination.pageSize + 1}-
                        {Math.min(
                            (table.getState().pagination.pageIndex + 1) * table.getState().pagination.pageSize,
                            table.getFilteredRowModel().rows.length
                        )}{" "}
                        from {table.getFilteredRowModel().rows.length}
                    </div>

                    <div className="flex items-center space-x-[22px]">
                        <Button
                            variant="ghost"
                            className="h-10 w-10 p-0 text-black/50 border border-black/5 rounded-full"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            <ChevronLeft className="size-6" />
                        </Button>

                        <div className="flex items-center gap-[22px]">
                            {getPaginationItems(table.getPageCount(), table.getState().pagination.pageIndex).map((item, idx) =>
                                item === "..." ? (
                                    <span key={`ellipsis-${idx}`} className="h-10 w-10 flex items-center justify-center text-black/50 text-sm">
                                        ...
                                    </span>
                                ) : (
                                    <Button
                                        key={item}
                                        variant="ghost"
                                        onClick={() => table.setPageIndex((item as number) - 1)}
                                        className={`h-10 w-10 p-0 rounded-full ${table.getState().pagination.pageIndex === (item as number) - 1
                                                ? "bg-primary text-secondary hover:bg-primary/90"
                                                : "text-black/50 border border-black/10 bg-white"
                                            }`}
                                    >
                                        {item}
                                    </Button>
                                )
                            )}
                        </div>

                        <Button
                            variant="ghost"
                            className="h-10 w-10 p-0 text-black/50 border border-black/5 rounded-full"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            <ChevronRight className="size-6" />
                        </Button>
                    </div>
                </div>
            ) : null}
        </div>
    )
}

export default ReusableTable;