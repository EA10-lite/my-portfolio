import { type Notification } from '../utils/types';
import { getRandomDate, getRandomElement, getRandomNumber } from './utils';

export const systemNotifications: Notification[] = Array.from({ length: 50 }, (_, i) => ({
    id: `SUB-${i + 1}`,
    title: getRandomElement(["Upgrade to pro", "New Categories Available"]),
    trigger: getRandomElement(["Cancellation", "Renewal Success", "Cateroy Created"]),
    status: getRandomElement(["SENT", "DELIVERED"]),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    audience: getRandomElement(["Providers", "Users"]),
}));

export const providerNotifications: Notification[] = Array.from({ length: 50 }, (_, i) => ({
    id: `SUB-${i + 1}`,
    title: getRandomElement(["Upgrade to pro", "New Categories Available", "Booking Request"]),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    audience: "All Providers",
    deliveryRate: getRandomNumber(1,100),
    openRate: getRandomNumber(1,100),
}));

export const userNotifications: Notification[] = Array.from({ length: 50 }, (_, i) => ({
    id: `SUB-${i + 1}`,
    title: getRandomElement(["Upgrade to pro", "New Categories Available", "Booking Reminder"]),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    audience: getRandomElement(["All Users", "Active Customers", "All providers"]),
    deliveryRate: getRandomNumber(1,100),
    openRate: getRandomNumber(1,100),
}));