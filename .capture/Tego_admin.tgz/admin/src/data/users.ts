import { type AdminUser } from '../utils/types';
import { generateName, getRandomDate, getRandomElement } from './utils';

export const users: AdminUser[] = Array.from({ length: 50 }, (_, i) => {
    return {
        id: `USER-${i + 2100}`,
        name: generateName(),
        email: `${generateName()}@example.com`,
        role: getRandomElement(["Support Admin", "Super Admin"]),
        lastActive: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
        status: getRandomElement(["ACTIVE", "INACTIVE"]),
    };
});
