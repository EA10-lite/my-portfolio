import { type JobApplication, type JobListing,} from '../utils/types';
import { generateCategories, generateName, getRandomDate, getRandomElement, getRandomNumber } from './utils';

export const listings: JobListing[] = Array.from({ length: 50 }, (_, i) => {
    return {
        id: `LIS-${i + 2100}`,
        title: getRandomElement(["Pipe Repair", "Apartment cleaning", "AC Repair", "Generator Repair", "Laundry services"]),
        customer: generateName(),
        category: generateCategories(),
        applications: getRandomNumber(50, 200),
        status: getRandomElement(["ACTIVE", "COMPLETED", "CANCELLED", "PENDING"]),
        createdAt: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
    };
});

export const applications: JobApplication[] = Array.from({ length: 50 }, (_, i) => {
    return {
        id: `APP-${i + 2100}`,
        rating: getRandomNumber(4,5,1),
        price: getRandomNumber(10000, 100000),
        time: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
        provider: generateName(),
        category: generateCategories(),
        status: getRandomElement(["SHORTLISTED", "SUBMITTED", "PENDING"]),
        createdAt: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
    };
});
