import {type ServiceOffered } from '../utils/types';
import { generateCategories, getRandomElement, getRandomNumber } from './utils';

export const servicesOffered: ServiceOffered[] = Array.from({ length: 50 }, (_, i) => ({
    id: `servcies_${i + 1}`,
    service: getRandomElement(["Pipe Repair", "Apartment cleaning", "AC Repair", "Generator Repair", "Laundry services"]),
    category: generateCategories(),
    price: getRandomNumber(5000, 100000),
    status: getRandomElement(["ACTIVE", "COMPLETED", "CANCELLED"])
}));
