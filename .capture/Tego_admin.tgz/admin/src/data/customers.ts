import { type Customer,} from '../utils/types';
import { generateEmail, generateLocation, generateName, getRandomDate, getRandomElement } from './utils';

export const customers: Customer[] = Array.from({ length: 50 }, (_, i) => {
    const firstName = generateName();
    const lastName = generateName();
    return {
        id: `partner_${i + 1}`,
        firstName,
        lastName,
        fullName: `${firstName} ${lastName}`,
        email: generateEmail(firstName),
        location: generateLocation(),
        status: getRandomElement(["ACTIVE", "INACTIVE", "SUSPENDED"]),
        createdAt: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
    };
});
