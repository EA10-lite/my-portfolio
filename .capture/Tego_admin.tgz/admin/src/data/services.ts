import { type Service } from '../utils/types';
import { getRandomDate, generateName, generateCategories, getRandomElement, generateLocation } from './utils';

export const services: Service[] = Array.from({ length: 50 }, (_, i) => ({
    id: `servcies_${i + 1}`,
    title: getRandomElement(["Pipe Repair", "Apartment cleaning", "AC Repair", "Generator Repair", "Laundry services"]),
    provider: generateName(),
    category: generateCategories(),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    location: generateLocation(),
    status: getRandomElement(["ACTIVE", "INACTIVE"])
}));
