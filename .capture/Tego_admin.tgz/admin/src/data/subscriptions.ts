import { type FailedSubscription, type Subscription } from '../utils/types';
import { generateName, getRandomDate, getRandomElement } from './utils';

export const subscriptions: Subscription[] = Array.from({ length: 50 }, (_, i) => ({
    id: `SUB-${i + 1}`,
    provider: generateName(),
    status: getRandomElement(["ACTIVE", "FAILED"]),
    plan: getRandomElement(["Pro Monthly", "Pro Yearly", "Free"]),
    renewalDate: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    paymentMethod: getRandomElement(["Card", "Transfer"]),
    autoRenewal: getRandomElement(["On", "Off"]),
}));

export const failedSubscriptions: FailedSubscription[] = Array.from({ length: 50 }, (_, i) => ({
    id: `SUB-${i + 1}`,
    provider: generateName(),
    plan: getRandomElement(["Pro Monthly", "Pro Yearly", "Free"]),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    paymentMethod: getRandomElement(["Card", "Transfer"]),
    failureReason: getRandomElement(["Insufficient Funds", "Payment not received"]),
}));
