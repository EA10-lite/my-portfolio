import { type Provider,} from '../utils/types';
import { generateCategories, generateEmail, generateName, getRandomDate, getRandomElement, getRandomNumber } from './utils';

export const providers: Provider[] = Array.from({ length: 50 }, (_, i) => {
    const firstName = generateName();
    const lastName = generateName();
    return {
        id: `partner_${i + 1}`,
        firstName,
        lastName,
        fullName: `${firstName} ${lastName}`,
        email: generateEmail(firstName),
        category: generateCategories(),
        rating: getRandomNumber(4, 5, 1),
        completedJobs: getRandomNumber(100, 400),
        subscription: getRandomElement(["Free", "Pro Yearly", "Pro Monthly"]),
        status: getRandomElement(["ACTIVE", "INACTIVE", "SUSPENDED"]),
        createdAt: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
        isVerified: getRandomElement([true, false]),
    };
});
