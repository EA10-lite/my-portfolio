import { type Category } from '../utils/types';
import { getRandomDate, getRandomElement, getRandomNumber } from './utils';

export const categories: Category[] = Array.from({ length: 50 }, (_, i) => ({
    id: `category_${i + 1}`,
    title: getRandomElement(["Pipe Repair", "Apartment cleaning", "AC Repair", "Generator Repair", "Laundry services"]),
    jobs: getRandomNumber(500, 1000),
    providers: getRandomNumber(500, 1000),
    services: getRandomNumber(500, 1000),
    createdAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    status: getRandomElement(["ACTIVE", "DISABLED"])
}));
