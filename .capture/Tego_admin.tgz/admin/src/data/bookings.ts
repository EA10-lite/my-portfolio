import { type Booking,} from '../utils/types';
import { generateName, getRandomDate, getRandomElement } from './utils';

export const bookings: Booking[] = Array.from({ length: 50 }, (_, i) => {
    return {
        id: `BOK-${i + 2100}`,
        customer: generateName(),
        provider: generateName(),
        service: getRandomElement(["Pipe Repair", "Apartment cleaning", "AC Repair", "Generator Repair", "Laundry services"]),
        status: getRandomElement(["COMPLETED", "CANCELLED", "PENDING", "SCHEDULED"]),
        createdAt: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
    };
});
