import { type Verification } from '../utils/types';
import { generateCategories, generateName, getRandomDate, getRandomElement } from './utils';

export const verifications: Verification[] = Array.from({ length: 50 }, (_, i) => ({
    id: `category_${i + 1}`,
    provider: generateName(),
    category: generateCategories(),
    submittedAt: getRandomDate(new Date(2023, 0, 1), new Date()).toString(),
    status: getRandomElement(["PENDING", "APPROVED", "REJECTED"]),
    verificationType: getRandomElement(["FULL", "IDENTITY"])
}));
