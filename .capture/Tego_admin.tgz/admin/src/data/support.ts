import { type Support,} from '../utils/types';
import { generateName, generateSentence, getRandomDate, getRandomElement } from './utils';

export const supports: Support[] = Array.from({ length: 50 }, (_, i) => {
    return {
        id: `TK-${i + 2100}`,
        user: generateName(),
        issue: generateSentence(),
        status: getRandomElement(["OPEN", "RESOLVED", "ESCALATED", "PENDING"]),
        createdAt: getRandomDate(new Date(2022, 0, 1), new Date()).toString(),
    };
});
