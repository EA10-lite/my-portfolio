import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import './App.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

import {
  AppLayout,
  ProtectedRoute,
  PublicRoute,
  SupportChatLayout,
} from "./layouts";
import { Toaster } from "./components/ui/sonner";

import {
  Dashboard,
  Login,
  NotFound,
  Subscriptions,
  Support,
  Chat,
  ChatDetails,
  Providers,
  Customers,
  Services,
  Jobs,
  Categories,
  Verifications,
  Settings,
  JobRequests,
  Analytics,
  Notifications,
  ProviderDetails,
  CustomerDetails,
  Users,
} from "./pages"
import SubmissionGuard from "./layouts/SubmissionGuard";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <SubmissionGuard />
        <Routes>
          <Route path="/auth/login" element={(
            <PublicRoute>
              <Login />
            </PublicRoute>
          )}
          />
          <Route path="/" element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }>
            <Route path="/" index element={<Dashboard />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/providers" element={<Providers />} />
            <Route path="/providers/:id" element={<ProviderDetails />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/customers/:id" element={<CustomerDetails />} />
            <Route path="/services" element={<Services />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/requests" element={<JobRequests />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/support" element={<Support />} />
            <Route path="/support/chat" element={<SupportChatLayout />}>
              <Route index element={<Chat />} />
              <Route path=":id" element={<ChatDetails />} />
            </Route>
            <Route path="/settings" element={<Settings />} />
            <Route path="/subscriptions" element={<Subscriptions />} />
            <Route path="/verifications" element={<Verifications />} />
            <Route path="/users" element={<Users />} />
            <Route path="/notifications" element={<Notifications />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
      </BrowserRouter>
    </QueryClientProvider>
  )
}

export default App
