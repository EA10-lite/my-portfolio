import { CartesianGrid,  BarChart, XAxis, YAxis, Bar } from "recharts"

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "../../../components/ui/chart"


type TopCategoriesProps = {
    data?: Array<{ category: string; count: number }>
}

type ChartRow = { category: string; count: number }

const chartConfig = {
    count: {
      label: "Jobs",
      color: "#33ABF7",
    },
} satisfies ChartConfig


const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ name?: string; value?: number; color?: string }>
  label?: string
}) => {
  if (!active || !payload?.length || label == null) return null

  return (
    <div className="bg-white rounded-[6px] p-4 min-w-[168px] border border-black/5 shadow-md">
      <p className="text-xs text-black/50 mb-2">{label}</p>
      <div className="space-y-1.5">
        {payload.map((entry, i) => (
          <div key={i} className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
              <span className="text-xs text-black/60 capitalize">{entry.name}</span>
            </div>
            <span className="text-xs font-semibold text-black">{entry.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}


const TopCategories = ({ data }: TopCategoriesProps) => {
    const chartData: ChartRow[] = data ?? []

    return (
        <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] text-black space-y-6 shadow-none">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 flex-wrap gap-3">
                <CardTitle className="text-lg font-medium">Top Categories</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
                <ChartContainer config={chartConfig} className="max-h-[365px] w-full p-0">
                <BarChart
                    accessibilityLayer
                    data={chartData}
                    barCategoryGap="30%"
                    margin={{ left: 0, right: 12, top: 10, bottom: 0 }}
                >
                    <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="rgba(0,0,0,0.08)" />
                    <XAxis
                    dataKey="category"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={15}
                    tick={{ fill: "rgba(0,0,0,0.4)", fontSize: 12 }}
                    />
                    <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={15}
                    allowDecimals={false}
                    tick={{ fill: "rgba(0,0,0,0.4)", fontSize: 12 }}
                    />
                    <ChartTooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} content={<CustomTooltip />} />
                    <Bar dataKey="count" fill="#33ABF7" radius={5} maxBarSize={19} />
                </BarChart>
                </ChartContainer>
            </CardContent>
        </Card>
    )
}

export default TopCategories