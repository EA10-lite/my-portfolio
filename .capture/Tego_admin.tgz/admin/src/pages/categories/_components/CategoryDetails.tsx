import React, { useState } from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { ChevronDown, ChevronUp } from "lucide-react";
import { getIcon } from "../../../components/icons/lib";
import type { Category } from "../../../services/response-structure";
import { formatCreatedAt } from "../../../utils/formatter";


const CategoryDetails = ({ category } : { category: Category }) => {
    const [open, setOpen] = useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "gallery"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Category Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    {getIcon("category-outline", { color: "black" })}
                    <span className="text-sm font-[500]">View Category</span>
                </div>
            )}
            ActionButton={null}
            open={open}
            onOpenChange={setOpen}
            hasFooter={false}
        >
            <div className="px-[16px] space-y-[20px]">
                <div className="flex items-center gap-[13px]">
                    <div className="bg-[#C0C0C01A] w-[60px] h-[60px] rounded-full flex items-center justify-center">
                        <img
                            src={category.image}
                            className="w-[24px] h-[24px]"
                            loading="lazy"
                        />
                    </div>
                    <div className="flex flex-col justify-between gap-[14px]">
                        <Text
                            type="h4"
                            className="font-[600] text-lg"
                            title={category.name}
                        />
                        <Text
                            type="p"
                            className="font-[500] text-base text-black/60"
                            title={category.status}
                        />
                    </div>
                </div>

                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("summary")}
                        >
                            <Text title="Category Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["summary"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["summary"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Created"
                                    value={
                                        category.created_at
                                            ? formatCreatedAt(category.created_at)
                                                : "-"
                                    }
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Active Providers"
                                    value={category.providers}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Services"
                                    value={category.services}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Jobs"
                                    value={category.jobs}
                                />
                            </div>
                        )}
                    </div>
                </div>

            </div>
        </DetailsModal>
    )
}


export default CategoryDetails;