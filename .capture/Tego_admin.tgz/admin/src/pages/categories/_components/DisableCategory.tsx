import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { X } from "lucide-react";
import { updateCategoryStatus } from "../../../services/category.service";

const DisableCategory = ({ categoryId } : { categoryId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleDisable = async () => {
        try {
            setLoading(true);
            await updateCategoryStatus(categoryId, "INACTIVE");
            await queryClient.invalidateQueries({ queryKey: ["categories"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to disabled category"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Category Disabled"
                description={`The category has been disabled successfully. New services and jobs are now paused.`}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
                style="min-w-[317px]"
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="New services and jobs will be paused until this category is enabled again."
                title="Disable Category"
                onContinue={handleDisable}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("close-outline", { color: "#D8232A" })}
                        <span className="text-sm font-[500] text-destructive">Disable Category</span>
                    </div>
                )}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
                buttonTitle="Disable Category"
                buttonType="destructive"
                loading={loading}
                style="min-w-[317px]"
            />
        </>
    )
}


export default DisableCategory;