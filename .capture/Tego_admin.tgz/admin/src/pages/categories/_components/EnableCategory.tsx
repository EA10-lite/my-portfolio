import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { X } from "lucide-react";
import { updateCategoryStatus } from "../../../services/category.service";

const EnableCategory = ({ categoryId } : { categoryId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleEnable = async () => {
        try {
            setLoading(true);
            await updateCategoryStatus(categoryId, "ACTIVE");
            await queryClient.invalidateQueries({ queryKey: ["categories"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to enable category"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Category Enabled"
                description={`The category has been enabled successfully and is now available for marketplace activity.`}
                Icon={getIcon("close-fill")}
                style="min-w-[317px]"
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="Providers will be able to publish services and accept new jobs in this category again."
                title="Enable Category"
                onContinue={handleEnable}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("verified-alt")}
                        <span className="text-sm font-[500]">Enable Categoy</span>
                    </div>
                )}
                Icon={getIcon("close-fill")}
                buttonTitle="Enable Category"
                loading={loading}
                style="min-w-[317px]"
            />
        </>
    )
}


export default EnableCategory;