import React from "react";
import {
  DetailsModal,
  FormField,
  IconPicker,
  ImagePicker,
  SuccessModal,
  Text,
} from "../../../components";
import { Plus, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Formik, type FormikHelpers, type FormikProps } from "formik";
import { getIcon } from "../../../components/icons/lib";
import { useQueryClient } from "@tanstack/react-query";
import { createCategory } from "../../../services/category.service";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { CLOUDINARY_FOLDERS, uploadFileToCloudinary } from "../../../lib/cloudinary";
import { categorySchema } from "../../../utils/validation";
import { useSubmissionStore } from "../../../store/submissionStore";

interface CategoryValues {
  icon: string;
  name: string;
  image: File | null; // 👈 File type
}


const AddCategory = () => {
  const queryClient = useQueryClient();
  const [open, setOpen] = React.useState<boolean>(false);
  const [isSuccess, setIsSuccess] = React.useState<boolean>(false);

  const { setSubmitting: checkSubmitting } = useSubmissionStore();

  const handleSubmit = async (
    values: CategoryValues,
    { setSubmitting, resetForm }: FormikHelpers<CategoryValues>,
  ) => {
    if (!values.image) return;

    try {
      checkSubmitting(true);
      // Upload cover image to Cloudinary
      const result = await uploadFileToCloudinary(values.image, {
        folder: CLOUDINARY_FOLDERS.CATEGORIES,
      });

      // Create category
      await createCategory({
        name: values.name,          // 👈 from Formik values
        image: values.icon,        // 👈 icon name from IconPicker
        cover_image: result.secure_url,
      });

      await queryClient.invalidateQueries({
        queryKey: ["categories"]
      });

      // Reset everything
      resetForm()
      setOpen(false);

      toast.success("Category created successfully");
    } catch (error) {
      toast.error(getErrorMessage(error, "Failed to create category"), {
        icon: (
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
            <X className="size-4 text-primary" />
          </div>
        ),
      });
    } finally {
      setSubmitting(false);
      checkSubmitting(false);
    }
  };

  const handleClose = (isOpen: boolean) => {
    setOpen(isOpen);
  };

  return (
    <>
      <SuccessModal
        title="Category Created"
        description="The new category is now available for providers and customers across the marketplace."
        Icon={getIcon("bell-fill", { color: "#33ABF7" })}
        open={isSuccess}
        onOpenChange={() => setIsSuccess(false)}
        style="min-w-[317px]"
      />
      <Formik<CategoryValues>
        initialValues={{
          icon: "",
          name: "",
          image: null,
        }}
        onSubmit={handleSubmit}
        validationSchema={categorySchema}
      >
        {({ submitForm, isSubmitting, setFieldValue, setFieldTouched }: FormikProps<CategoryValues>) => (
          <DetailsModal
            title={"Add New Category"}
            TriggerButton={(
              <Button
                size="lg"
                variant="secondary"
                className="rounded-full flex items-center gap-[4px] bg-black hover:bg-black"
              >
                <Plus />
                <span className="font-[600] text-[13px]">Add Category</span>
              </Button>
            )}
            ActionButton={(
                <Button
                  className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                  onClick={submitForm}
                  disabled={isSubmitting}
                >
                  <span>{isSubmitting ? "Saving..." : "Save Changes"}</span>
                </Button>
              )
            }
            open={open}
            onOpenChange={handleClose}
          >
            <div className="px-[16px] space-y-[20px]">
                <div className="flex flex-col gap-[18px]">

                    {/* Image Picker */}

                    <IconPicker name="icon" />

                    <div className="">
                        <ImagePicker
                          name="image"
                          label="Cover Photo"
                          placeholder="Upload Category image"
                          maxFiles={1}
                          multiple={false}
                          note="Dimensions 3200 x 420PX"
                          customHandleChange={(files) => {
                            const file = Array.isArray(files) ? files[0] : files;
                            setFieldValue("image", file ?? null);
                            setFieldTouched("image", true);
                          }}
                        />
                    </div>

                    {/* Notification Details */}
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button className="flex items-center justify-between w-full p-[16px]">
                            <Text title="Category Information" className="text-[13px] font-[600]" type="h5" />
                        </button>
                        <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                            <FormField name="name" placeholder="Category Name" className="shadow-none" />
                        </div>
                    </div>
                </div>
            </div>
          </DetailsModal>
        )}
      </Formik>
    </>
  );
};

export default AddCategory;