import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { X } from "lucide-react";
import { deleteCategory } from "../../../services/category.service";

const DeleteCategory = ({ categoryId } : { categoryId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteCategory(categoryId,);
            await queryClient.invalidateQueries({
                queryKey: ["categories"]
            });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete category"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Category Deleted"
                description={`The category has been Deleted successfully.`}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
                style="min-w-[317px]"
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This category will be permanently deleted and all services will be removed."
                title="Delete Category"
                onContinue={handleDelete}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("close-outline", { color: "#D8232A" })}
                        <span className="text-sm font-[500] text-destructive">Delete Category</span>
                    </div>
                )}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
                buttonTitle="Delete Category"
                buttonType="destructive"
                loading={loading}
                style="min-w-[317px]"
            />
        </>
    )
}


export default DeleteCategory;