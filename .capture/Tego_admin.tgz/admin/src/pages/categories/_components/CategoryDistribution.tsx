import { Label, Pie, PieChart } from "recharts";

import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card";

import {
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
    type ChartConfig,
} from "../../../components/ui/chart";

import type { CategoryDistributionItem } from "../../../services/response-structure";

const FILL_COLORS = ["#33ABF7", "#33ABF733", "#33ABF799"];

const chartConfig = {
    jobs: {
        label: "Jobs",
        color: "#33ABF7",
    },
    services: {
        label: "Services",
        color: "#33ABF7",
    },
    providers: {
        label: "Providers",
        color: "#33ABF7",
    },
} satisfies ChartConfig;

const CategoryDistribution = ({
    distribution,
}: {
    distribution: CategoryDistributionItem[];
}) => {
    const totals = distribution.reduce(
        (acc, item) => ({
            jobs: acc.jobs + item.jobs,
            services: acc.services + item.services,
            providers: acc.providers + item.providers,
        }),
        {
            jobs: 0,
            services: 0,
            providers: 0,
        }
    );

    const total =
        totals.jobs +
        totals.services +
        totals.providers;

    const data = [
        {
            type: "Jobs",
            count: totals.jobs,
            percentage: total
                ? Math.round((totals.jobs / total) * 100)
                : 0,
            fill: FILL_COLORS[0],
        },
        {
            type: "Services",
            count: totals.services,
            percentage: total
                ? Math.round((totals.services / total) * 100)
                : 0,
            fill: FILL_COLORS[1],
        },
        {
            type: "Providers",
            count: totals.providers,
            percentage: total
                ? Math.round((totals.providers / total) * 100)
                : 0,
            fill: FILL_COLORS[2],
        },
    ];

    const hasData = total > 0;

    const chartData = hasData
        ? data
        : data.map((item) => ({
              ...item,
              count: 1,
          }));

    const topPlan = hasData
        ? data.reduce((top, item) =>
              item.percentage > top.percentage ? item : top
          )
        : {
              type: "No data",
              percentage: 0,
          };

    return (
        <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] shadow-none">
            <CardHeader className="items-center pb-0 px-0">
                <CardTitle className="text-black">
                    Category Distribution
                </CardTitle>
            </CardHeader>

            <CardContent className="flex-1 pb-0">
                <ChartContainer
                    config={chartConfig}
                    className="mx-auto aspect-square max-h-[250px]"
                >
                    <PieChart>
                        <ChartTooltip
                            cursor={false}
                            content={
                                <ChartTooltipContent hideLabel />
                            }
                        />

                        <Pie
                            data={chartData}
                            dataKey="count"
                            nameKey="type"
                            innerRadius={75}
                            strokeWidth={5}
                            cornerRadius={8}
                            paddingAngle={4}
                        >
                            <Label
                                className="text-black"
                                content={({ viewBox }) => {
                                    if (
                                        viewBox &&
                                        "cx" in viewBox &&
                                        "cy" in viewBox
                                    ) {
                                        return (
                                            <text
                                                x={viewBox.cx}
                                                y={viewBox.cy}
                                                textAnchor="middle"
                                                dominantBaseline="middle"
                                                className="text-black font-[700]"
                                            >
                                                <tspan
                                                    x={viewBox.cx}
                                                    y={viewBox.cy}
                                                    className="fill-black text-lg font-semibold"
                                                >
                                                    {topPlan.type}
                                                </tspan>

                                                <tspan
                                                    x={viewBox.cx}
                                                    y={(viewBox.cy || 0) + 24}
                                                    className="fill-black"
                                                >
                                                    {topPlan.percentage}%
                                                </tspan>
                                            </text>
                                        );
                                    }

                                    return null;
                                }}
                            />
                        </Pie>
                    </PieChart>
                </ChartContainer>
            </CardContent>

            <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
                {data.map((item) => (
                    <div
                        key={item.type}
                        className="flex items-center gap-2 leading-none font-medium"
                    >
                        <div
                            className="w-2.5 h-2.5 rounded-full"
                            style={{
                                background: item.fill,
                            }}
                        />

                        <span className="capitalize">
                            {item.type}
                        </span>
                    </div>
                ))}
            </CardFooter>
        </Card>
    );
};

export default CategoryDistribution;