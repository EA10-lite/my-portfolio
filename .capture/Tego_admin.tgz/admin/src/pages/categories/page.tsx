import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import CategoryDistribution from "./_components/CategoryDistribution";
import TopCategories from "./_components/TopCategories";
import DisableCategory from "./_components/DisableCategory";
import EnableCategory from "./_components/EnableCategory";
import CategoryDetails from "./_components/CategoryDetails";
import AddCategory from "./_components/AddCategory";
import { getCategories, getCategoryInsights, getCategoryStats } from "../../services/category.service";
import { useQueries } from "@tanstack/react-query";
import type { Category } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import DeleteCategory from "./_components/DeleteCategory";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";


const columns: ColumnDef<Category>[] = [
    {
        accessorKey: "name",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.name}</span>
        )
    },
    {
        accessorKey: "providers",
        header: "Providers",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.providers}</span>
        )
    },
    {
        accessorKey: "services",
        header: "Services",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.services}</span>
        )
    },
    {
        accessorKey: "jobs",
        header: "Jobs",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.jobs}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "active") badgeVariant = "success";
            if (status.toLowerCase() === "disabled") badgeVariant = "destructive";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "success" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => {
            const status = row.original.status?.toLowerCase()
            return (
                <div className="flex justify-start">
                    <TableAction
                        items={[
                            {
                                label: "View Category",
                                content: <CategoryDetails category={row.original} />
                            },
                            {
                                label: status === "active" ? "Disable Category" : "Enable Category",
                                content: status === "active"
                                    ? <DisableCategory categoryId={row.original.id} />
                                    : <EnableCategory categoryId={row.original.id} />
                            },
                            {
                                label: "Delete Category",
                                content: <DeleteCategory categoryId={row.original.id} />
                            },
                        ]}
                    />
                </div>
            )
        }
    },
]

const Categories = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});

    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data: stat,
            isLoading: isStatLoading,
        },
        {
            data: insights,
        },
        {
            data,
            isLoading,
            isError,
            error,
        }
    ] = useQueries({
        queries: [
            {
                queryKey: [
                    "category-stats",
                    pagination.pageIndex,
                    pagination.pageSize,
                    filters,
                ],
                queryFn: () => getCategoryStats(),
            },
            {
                queryKey: [
                    "category-insights",
                    pagination.pageIndex,
                    pagination.pageSize,
                ],
                queryFn: () => getCategoryInsights(),
            },
            {
                queryKey: [
                    "categories",
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters,
                ],
                queryFn: () =>
                    getCategories({
                        page: pagination.pageIndex + 1,
                        limit: pagination.pageSize,
                        search,
                        ...filters,
                    }),
            },
        ],
    });



    return (
        <div className="categories space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Categories"
                    description="Control marketplace structure, organize services, and monitor category performance."
                    metrics={[
                        {
                            label: "Total Categories",
                            value: stat?.summary?.total_categories.value ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.summary?.total_categories.change_pct ?? 0,
                        },
                        {
                            label: "Active Categories",
                            value: stat?.summary?.active_categories.value ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.summary?.active_categories.change_pct ?? 0,
                        },
                        {
                            label: "Active Providers",
                            value: stat?.summary?.active_providers.value ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.summary?.active_providers.change_pct ?? 0,
                        },
                        {
                            label: "Active Services",
                            value: stat?.summary?.active_services.value ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.summary?.active_services.change_pct ?? 0,
                        },
                    ]}
                    hasDownload={true}
                    triggerBtn={<AddCategory />}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body space-y-[20px]">
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                    <div className="col-span-12 lg:col-span-3">
                        {insights && <TopCategories data={insights.top_categories} />}
                    </div>
                    <div className="col-span-12 lg:col-span-2">
                        {insights?.category_distribution && <CategoryDistribution distribution={insights.category_distribution} />}
                    </div>
                </div>
                <ReusableTable
                    title="Categories List"
                    data={isError ? [] : data?.categories || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No category activity",
                        description: isError
                            ? error.message
                            : "Jobs and services will appear after category usage begins.",
                        icon: "card-fill"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterTitle="Filter Category"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Category Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value: "ACTIVE" },
                                        { label: "Inactive", value: "DISABLED" },
                                    ],
                                },
                                {
                                    label: "Performance",
                                    key: "performance",
                                    options: [
                                        { label: "High Job Volume", value: "high_jobs" },
                                        { label: "High Provider Count", value: "high_providers" },
                                        { label: "High Service Count", value: "high_services" },
                                        { label: "Low Activity", value: "low_activity" },
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Categories;

