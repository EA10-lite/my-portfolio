import { useMemo } from "react"

import {
  CartesianGrid,
  BarChart,
  XAxis,
  YAxis,
  Bar,
} from "recharts"

import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"

import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "../../../components/ui/chart"

import { Button } from "../../../components/ui/button"
import type { JobActivity as JobActivityItem } from "../../../services/response-structure"
import type { RANGE } from "../../../services/types"

type JobActivityProps = {
  data?: JobActivityItem
  timeframe: RANGE
  setTimeframe: React.Dispatch<React.SetStateAction<RANGE>>
}

type ChartRow = {
  label: string
  posted: number
  ongoing: number
  completed: number
}

const TIMEFRAMES: {
  label: string
  value: RANGE
}[] = [
  {
    label: "Week",
    value: "week",
  },
  {
    label: "Month",
    value: "month",
  },
  {
    label: "Year",
    value: "year",
  },
]

const formatAxisLabel = (
  timeframe: RANGE,
  rawLabel: string
): string => {
  if (timeframe === "week") {
    const parts = rawLabel.trim().split(/\s+/)

    return parts[parts.length - 1] ?? rawLabel
  }

  if (timeframe === "month") {
    const date = new Date(`${rawLabel}T12:00:00`)

    if (!Number.isNaN(date.getTime())) {
      return date.toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
      })
    }
  }

  return rawLabel
}

const buildChartRows = (
  points: JobActivityItem["points"] | undefined,
  timeframe: RANGE
): ChartRow[] => {
  if (!points?.length) return []

  return points.map((point) => ({
    label: formatAxisLabel(timeframe, point.name),
    posted: point.postedJobs,
    ongoing: point.inProgressJobs,
    completed: point.completedJobs,
  }))
}

const chartConfig = {
  posted: {
    label: "Posted Jobs",
    color: "#33ABF799",
  },

  ongoing: {
    label: "In Progress Jobs",
    color: "#33ABF733",
  },

  completed: {
    label: "Completed Jobs",
    color: "#33ABF7",
  },
} satisfies ChartConfig

const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{
    name?: string
    value?: number
    color?: string
  }>
  label?: string
}) => {
  if (!active || !payload?.length || label == null) {
    return null
  }

  return (
    <div className="bg-white rounded-[6px] p-4 min-w-[168px] border border-black/5 shadow-md">
      <p className="text-xs text-black/50 mb-2">
        {label}
      </p>

      <div className="space-y-1.5">
        {payload.map((entry, index) => (
          <div
            key={index}
            className="flex items-center justify-between gap-4"
          >
            <div className="flex items-center gap-1.5">
              <span
                className="w-2 h-2 rounded-full"
                style={{
                  background: entry.color,
                }}
              />

              <span className="text-xs text-black/60 capitalize">
                {entry.name}
              </span>
            </div>

            <span className="text-xs font-semibold text-black">
              {entry.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

const JobActivity = ({
  data,
  timeframe,
  setTimeframe,
}: JobActivityProps) => {
  const chartData = useMemo(() => {
    return buildChartRows(data?.points, timeframe)
  }, [data, timeframe])

  const chartItem = [
    {
      type: "Completed Jobs",
      fill: "#33ABF7",
    },
    {
      type: "Posted Jobs",
      fill: "#33ABF799",
    },
    {
      type: "In Progress Jobs",
      fill: "#33ABF733",
    },
  ]

  return (
    <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] text-black space-y-6 shadow-none">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 flex-wrap gap-3">
        <CardTitle className="text-lg font-medium">
          Job Activity
        </CardTitle>

        <div className="flex items-center gap-2 p-1 rounded-full flex-wrap justify-end">
          {TIMEFRAMES.map((filter) => (
            <Button
              key={filter.value}
              variant="ghost"
              size="sm"
              onClick={() => setTimeframe(filter.value)}
              className={`rounded-full px-4 h-8 text-xs font-medium transition-all ${
                filter.value === timeframe
                  ? "bg-primary text-white pointer-events-none"
                  : "bg-lightblue/50 text-primary border border-primary hover:text-white hover:bg-primary"
              }`}
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <ChartContainer
          config={chartConfig}
          className="max-h-[365px] w-full p-0"
        >
          <BarChart
            accessibilityLayer
            data={chartData}
            barCategoryGap="33%"
            barGap={2}
            margin={{
              left: 0,
              right: 12,
              top: 10,
              bottom: 0,
            }}
          >
            <CartesianGrid
              vertical={false}
              strokeDasharray="3 3"
              stroke="rgba(0,0,0,0.08)"
            />

            <XAxis
              dataKey="label"
              tickLine={false}
              axisLine={false}
              tickMargin={15}
              minTickGap={timeframe === "week" ? 8 : 24}
              tick={{
                fill: "rgba(0,0,0,0.4)",
                fontSize: 12,
              }}
            />

            <YAxis
              tickLine={false}
              axisLine={false}
              tickMargin={15}
              allowDecimals={false}
              tick={{
                fill: "rgba(0,0,0,0.4)",
                fontSize: 12,
              }}
            />

            <ChartTooltip
              cursor={{
                fill: "rgba(0,0,0,0.04)",
              }}
              content={<CustomTooltip />}
            />

            <Bar
              dataKey="completed"
              fill="#33ABF7"
              radius={5}
              maxBarSize={19}
            />

            <Bar
              dataKey="posted"
              fill="#33ABF733"
              radius={5}
              maxBarSize={19}
            />

            <Bar
              dataKey="ongoing"
              fill="#33ABF799"
              radius={5}
              maxBarSize={19}
            />
          </BarChart>
        </ChartContainer>
      </CardContent>

      <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
        {chartItem.map((item) => (
          <div
            key={item.type}
            className="flex items-center gap-2 leading-none font-medium"
          >
            <div
              className="w-2.5 h-2.5 rounded-full"
              style={{
                background: item.fill,
              }}
            />

            <span className="capitalize text-[#909090] text-xs font-[400]">
              {item.type}
            </span>
          </div>
        ))}
      </CardFooter>
    </Card>
  )
}

export default JobActivity