import { EmptyState, Text } from "../../../components"
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card"
import { formatDateString, formatTime } from "../../../utils/formatter";
import { getIcon, type IconType } from "../../../components/icons/lib";
import type { RecentActivity } from "../../../services/response-structure";

interface ActivityFeedProps {
    data?: RecentActivity[];
    emptyMessage?: {
        title: string;
        description: string;
        icon: IconType;
    }
}


const ActivityFeed = ({
    data,
    emptyMessage={
        title: "No recent activity",
        description: "Provider registrations, subscriptions, and marketplace updates will appear here.",
        icon: "category-outline"
    }
} : ActivityFeedProps) => {
    const getType = (type: string) => {
        let formattedType = "";

        if (type.includes("registration") || type.includes("profile")) {
            formattedType = "account";
        } else if (type.includes("ticket")) {
            formattedType = "support";
        } else if (type.includes("subscription")) {
            formattedType = "subscription";
        } else if (type.includes("job")) {
            formattedType = "job";
        }

        return formattedType;
    }
    return (
        <Card className="bg-white border border-black/5 p-[20px] rounded-[8px] gap-0 shadow-none">
            <CardHeader className="m-0 p-0">
                <CardTitle className="text-black">Recent Activity Feed</CardTitle>
            </CardHeader>

            <CardContent className="p-0 pb-4 mt-[16px] flex-1">
                {data && data?.length > 0 ? (
                    <div className="flex flex-col gap-[16px]">
                        {data?.slice(0, 5).map((item, index) => (
                            <Activity
                                key={index}
                                type={getType(item.type)}
                                title={item.title}
                                date={item.timestamp}
                                time={item.relative}
                                message={item.description}
                            />
                        ))}
                    </div>
                ) : (
                    <EmptyState emptyMessage={emptyMessage} />
                )}
            </CardContent>
        </Card>
    )
}


type ActivityProps = {
    title: string;
    date: string;
    time: string;
    type: string;
    message: string;
}

const Activity = ({
    title,
    message,
    date,
    type,
}: ActivityProps) => {
    return (
        <div className="bg-[#C0C0C01A] w-full flex items-center gap-4 px-[16px] py-[14px] rounded-[8px]">
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#C0C0C01A]">
                {type === "account" && getIcon("customer-fill")}
                {type === "support" && getIcon("ticket-fill")}
                {type === "subscription" && getIcon("subscription-fill")}
                {type === "job" && getIcon("request-fill")}
            </div>


            <div className="flex flex-col gap-[8px]">
                <Text
                    title={title}
                    type="h4"
                    className="font-[600] text-sm text-black"
                />
                <Text
                    title={message}
                    type="p"
                    className="text-xs font-[500] text-black/70"
                />

                <div className="flex items-center gap-[4px]">
                    <Text
                        title={formatDateString(date)}
                        type="p"
                        className="text-[10px] text-black/50 font-normal"
                    />
                    <div className="w-1 h-1 rounded-full bg-success" />
                    <Text
                        title={formatTime(date)}
                        type="p"
                        className="text-[10px] text-black/50 font-normal"
                    />
                </div>
            </div>
        </div>
    )
}

export default ActivityFeed;