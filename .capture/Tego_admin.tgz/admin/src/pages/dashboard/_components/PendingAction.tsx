import { Link } from "react-router-dom";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
  } from "../../../components/ui/card"
import { EmptyState, Text } from "../../../components";
import { getIcon, type IconType } from "../../../components/icons/lib";
import { ArrowRight } from "lucide-react";
import type { PendingActions } from "../../../services/response-structure";

interface PendingActionProps {
    data?: PendingActions;
    emptyMessage?: {
        title: string;
        description: string;
        icon: IconType;
    }
}

const PendingAction = ({
    data,
    emptyMessage={
        title: "No pending actions",
        description: "Everything looks good. New reviews and approvals will appear here.",
        icon: "subscription-outline"
    }
}: PendingActionProps) => {
    const getType = (type: string) => {
        let formattedType = "";

        if (type.includes("verification")) {
            formattedType = "verification";
        } else if (type.includes("support")) {
            formattedType = "support";
        } else if (type.includes("subscription")) {
            formattedType = "subscription";
        } else if (type.includes("job")) {
            formattedType = "job";
        }

        return formattedType;
    }

    const getMessage = (key: string, value: number): string => {
        if (key === "provider_verifications_pending") {
            return `${value} providers awaiting approval`;
        }
        if (key === "subscriptions_expiring_7d") {
            return `${value} subscriptions expire within 7 days`;
        }
        if (key === "support_tickets_awaiting_response") {
            return `${value} customer support tickets awaiting response.`;
        }
        return "";
    };
    return (
        <Card className="border border-black/5 bg-white p-[20px] rounded-[10px] gap-0 shadow-none">
            <CardHeader className="p-0 m-0">
                <CardTitle className="text-black">Pending Actions</CardTitle>
            </CardHeader>

            <CardContent className="mt-[16px] flex-1 p-0">
                { data ? (
                    <div className="flex flex-col gap-[16px]">
                        {Object.entries(data).map(([key, value]) => {
                            const type = getType(key);

                            return (
                                <ActionField
                                    key={key}
                                    title={key}
                                    message={getMessage(key, value)}
                                    type={type}
                                />
                            );
                        })}
                    </div>
                ) : (
                    <EmptyState emptyMessage={emptyMessage} />
                )}

            </CardContent>
        </Card>
    )
}

type ActivityProps = {
    title: string;
    type: string;
    message: string;
}

const ActionField = ({
    title,
    message,
    type,
}: ActivityProps) => {
    const getLink = (): string => {
        if (type === "verification") return "/verifications";
        if (type === "support") return "/support";
        if (type === "subscription") return "/subscriptions";
        return "#";
    };
    return (
        <div className="bg-[#C0C0C01A] w-full flex items-center gap-4 px-[16px] py-[14px] rounded-[8px]">
            <div className="w-10 h-10 flex items-center justify-center rounded-full bg-[#C0C0C01A]">
                {type === "support" && getIcon("ticket-fill")}
                {type === "subscription" && getIcon("subscription-fill")}
                {type === "verification" && getIcon("verification-fill")}
            </div>


            <div className="flex flex-col gap-[8px]">
                <Text
                    title={title}
                    type="h4"
                    className="font-[600] text-sm text-black"
                />
                <Text
                    title={message}
                    type="p"
                    className="text-xs font-[500] text-black/70"
                />
                <Link to={`${getLink()}`} className="text-primary flex items-center gap-[4px]">
                    <span className="text-xs font-[500] ">Review</span>
                    <ArrowRight size={16} />
                </Link>
            </div>
        </div>
    )
}

export default PendingAction;