import { TrendingDown, TrendingUp } from "lucide-react"
import { useMemo } from "react"
import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts"

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "../../../components/ui/chart"
import type { IconType } from "../../../components/icons/lib"
import { EmptyState } from "../../../components"
import { Button } from "../../../components/ui/button"
import type { RANGE } from "../../../services/types"

export interface SubscriptionGrowthPoint {
  period: string
  count: number
}

type SubscriptionGrowthProps = {
  data?: SubscriptionGrowthPoint[]
  emptyMessage?: {
    title: string
    icon: IconType
    description: string
  };
  dateFilter: RANGE;
  onDateChange: (period: RANGE) => void;
}

type ChartRow = {
  label: string
  growth: number
}

function buildChartRows(
  points: SubscriptionGrowthPoint[] | undefined
): ChartRow[] {
  if (!points?.length) return []

  return points.map((point) => {
    const date = new Date(`${point.period}-01T12:00:00`)

    return {
      label: Number.isNaN(date.getTime())
        ? point.period
        : date.toLocaleDateString(undefined, {
            month: "short",
            year: "numeric",
          }),
      growth: point.count,
    }
  })
}

const chartConfig = {
  growth: {
    label: "Subscriptions",
    color: "#33ABF7",
  },
} satisfies ChartConfig

const CustomTooltip = ({
  active,
  payload,
  label,
  chartData,
}: {
  active?: boolean
  payload?: Array<{ value?: number }>
  label?: string
  chartData: ChartRow[]
}) => {
  if (!active || !payload?.length || label == null) return null

  const value = Number(payload[0].value ?? 0)

  const idx = chartData.findIndex((d) => d.label === label)
  const prev = idx > 0 ? chartData[idx - 1].growth : null

  let comparison: React.ReactNode = null

  if (prev !== null) {
    const diff = value - prev

    if (diff > 0) {
      comparison = (
        <div className="flex items-center gap-1.5 mt-2">
          <TrendingUp className="w-4 h-4 text-primary shrink-0" />
          <span className="text-sm font-medium text-black">
            +{diff} vs previous period
          </span>
        </div>
      )
    } else if (diff < 0) {
      comparison = (
        <div className="flex items-center gap-1.5 mt-2">
          <TrendingDown className="w-4 h-4 text-red-400 shrink-0" />
          <span className="text-sm font-medium text-black">
            {diff} vs previous period
          </span>
        </div>
      )
    } else {
      comparison = (
        <p className="text-sm text-black/50 mt-2">
          Same as previous period
        </p>
      )
    }
  }

  return (
    <div className="bg-white rounded-[6px] p-4 min-w-[168px] border border-black/5">
      <p className="text-xs text-black/50 mb-1">{label}</p>

      <div className="flex items-baseline gap-1.5">
        <span className="text-base font-semibold text-black">
          {value}
        </span>

        <span className="text-xs text-black/50">
          subscriptions
        </span>
      </div>

      {comparison}
    </div>
  )
}

const SubscriptionGrowth = ({
  data,
  emptyMessage = {
    title: "No activity available",
    description: "Data will appear after users engage with the platform.",
    icon: "graph-outline",
  },
  dateFilter,
  onDateChange,
}: SubscriptionGrowthProps) => {
  const chartData = useMemo(
    () => buildChartRows(data),
    [data]
  )

  const hasData = chartData.length > 0

  return (
    <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] text-black space-y-6 shadow-none">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 flex-wrap gap-3">
        <CardTitle className="text-lg font-medium">
          Subscription Growth
        </CardTitle>
        <div className="flex items-center gap-2 p-1 rounded-full flex-wrap justify-end">
          {[
            { label: "Week", value: "week" },
            { label: "Month", value: "month" },
            { label: "Year", value: "year" },
          ].map((filter) => (
            <Button
              key={filter.label}
              variant="ghost"
              size="sm"
              onClick={()=> onDateChange(filter.value as RANGE)}
              className={`rounded-full px-4 h-8 text-xs font-medium transition-all ${
                filter.value === dateFilter
                  ? "bg-primary text-white pointer-events-none"
                  : "bg-lightblue/50 text-primary border border-primary hover:text-white hover:bg-primary"
              }`}
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {hasData ? (
          <ChartContainer
            config={chartConfig}
            className="max-h-[365px] w-full p-0"
          >
            <LineChart
              accessibilityLayer
              data={chartData}
              margin={{
                left: 0,
                right: 12,
                top: 10,
                bottom: 0,
              }}
            >
              <CartesianGrid
                vertical={false}
                strokeDasharray="3 3"
                stroke="rgba(0,0,0,0.08)"
              />

              <XAxis
                dataKey="label"
                tickLine={false}
                axisLine={false}
                tickMargin={15}
                minTickGap={24}
                tick={{
                  fill: "rgba(0,0,0,0.4)",
                  fontSize: 12,
                }}
              />

              <YAxis
                tickLine={false}
                axisLine={false}
                tickMargin={15}
                allowDecimals={false}
                tick={{
                  fill: "rgba(0,0,0,0.4)",
                  fontSize: 12,
                }}
              />

              <ChartTooltip
                cursor={false}
                content={
                  <CustomTooltip chartData={chartData} />
                }
              />

              <Line
                dataKey="growth"
                type="linear"
                stroke="#33ABF7"
                strokeWidth={1.5}
                dot={{
                  fill: "#fff",
                  stroke: "#33ABF7",
                  r: 5,
                  strokeWidth: 1,
                }}
                activeDot={{
                  r: 5,
                  fill: "#fff",
                  stroke: "#33ABF7",
                  strokeWidth: 2,
                }}
              />
            </LineChart>
          </ChartContainer>
        ) : (
          <EmptyState emptyMessage={emptyMessage} />
        )}
      </CardContent>
    </Card>
  )
}

export default SubscriptionGrowth