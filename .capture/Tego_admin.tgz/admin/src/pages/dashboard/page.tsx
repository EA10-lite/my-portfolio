import { useQueries } from "@tanstack/react-query";
import { PageHeader } from "../../components/shared";
import { useAdminStore } from "../../store/adminStore";
import ActivityFeed from "./_components/ActivityFeed";
import PendingAction from "./_components/PendingAction";
import SubscriptionGrowth from "./_components/SubscriptionGrowth";
import {
  getDashboardStats,
  getJobActivity,
  getPendingActions,
  getRecentActivity,
} from "../../services/dashboard.service";
import { getSubscriptionStats } from "../../services/subscription.service";
import { Skeleton } from "../../components/ui/skeleton";
import { useState } from "react";
import JobActivity from "./_components/JobActivity";
import type { RANGE } from "../../services/types";

const Dashboard = () => {
  const [dateFilter, setDateFilter] = useState<RANGE>("week");
  const [timeframe, setTimeframe] = useState<RANGE>("week");
  const { admin } = useAdminStore();

  const [
    {
      data: stat,
      isLoading: isStatLoading,
    },
    {
      data: subscription,
      isLoading: isSubscriptionLoading
    },
    {
      data: pendingActions,
      isLoading: isPendingActionLoading,
    },
    {
      data: recentActivities,
      isLoading: isRecentActivitiesLoading
    },
    {
      data: jobActivity,
      isLoading: isJobActivityLoading,
    }
  ] = useQueries({
    queries: [
      {
        queryKey: ["dashboard-data"],
        queryFn: ()=> getDashboardStats(),
      },
      {
        queryKey: ["subscription-data", dateFilter],
        queryFn: () => getSubscriptionStats(dateFilter),
      },
      {
        queryKey: ["pending-actions"],
        queryFn: ()=> getPendingActions(),
      },
      {
        queryKey: ["recent-activity"],
        queryFn: () => getRecentActivity(),
      },
      {
        queryKey: ["job-activity", timeframe],
        queryFn: () => getJobActivity(timeframe),
      },
    ]
  })

    return (
        <div className="dashboard space-y-[20px] px-6">
            <PageHeader
              title={`Hello ${admin?.firstName} 👋`}
              metrics={[
                {
                  label: "Total Customers",
                  value: stat?.total_customers.value ?? 0,
                  filter: "All Time",
                  percentageIncrease: stat?.total_customers.change_pct ?? 0,
                },
                {
                  label: "Total Providers",
                  value: stat?.total_providers.value ?? 0,
                  filter: "All Time",
                  percentageIncrease: stat?.total_providers.change_pct ?? 0,
                },
                {
                  label: "Active Subscriptions",
                  value: stat?.active_subscriptions.value ?? 0,
                  filter: "All Time",
                  percentageIncrease: stat?.active_subscriptions.change_pct ?? 0,
                },
                {
                  label: "Active Jobs",
                  value: stat?.active_jobs.value ?? 0,
                  filter: "All Time",
                  percentageIncrease: stat?.active_jobs.change_pct ?? 0,
                },
              ]}
              hasDownload={false}
              loading={isStatLoading}
            />
            <div className="page-body space-y-[20px]">
              {isSubscriptionLoading
                ? <ChartSkeleton />
                  : <SubscriptionGrowth
                      data={subscription?.growth}
                      dateFilter={dateFilter}
                      onDateChange={setDateFilter}
                    />
              }

              { isJobActivityLoading
                ? <ChartSkeleton />
                  : <JobActivity
                    data={jobActivity}
                    timeframe={timeframe}
                    setTimeframe={setTimeframe}
                  />
              }

              {isPendingActionLoading || isRecentActivitiesLoading
                ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <PanelSkeleton />
                    <PanelSkeleton />
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <ActivityFeed data={recentActivities?.activities} />
                    <PendingAction data={pendingActions} />
                  </div>
                )}
            </div>
        </div>
    )
}

const ChartSkeleton = () => {
    return (
      <div className="border-[0.5px] border-primary/8 bg-secondary-foreground rounded-sm p-4 space-y-4">
        <Skeleton className="h-5 w-40 bg-gray" />
        <Skeleton className="h-64 w-full bg-gray" />
      </div>
    );
};

const PanelSkeleton = () => {
    return (
      <div className="border-[0.5px] border-primary/8 bg-secondary-foreground rounded-sm p-4 space-y-3">
        <Skeleton className="h-5 w-40 bg-gray" />
        <Skeleton className="h-4 w-full bg-gray" />
        <Skeleton className="h-4 w-5/6 bg-gray" />
        <Skeleton className="h-4 w-3/4 bg-gray" />
        <Skeleton className="h-4 w-4/5 bg-gray" />
        <Skeleton className="h-4 w-2/3 bg-gray" />
      </div>
    );
};

export default Dashboard;