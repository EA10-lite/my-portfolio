import { useRef, useState } from "react";
import { FormField, ModalFieldItem, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { Formik } from "formik";
import { Upload, X } from "lucide-react";
import SaveChangesConfirmation from "../_components/SaveChangesConfirmation";
import type { AdminDetails } from "../../../services/response-structure";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { uploadFileToCloudinary } from "../../../lib/cloudinary";


const Profile = ({ profile } : { profile?: AdminDetails }) => {
    const [step, setStep] = useState<"profile" | "edit">("profile");

    const fileInputRef = useRef<HTMLInputElement>(null);
    const [image_url, set_image_url] = useState<string>("");
    const [uploading, setUploading] = useState<boolean>(false);

    const handleImageUpload = async (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];

        if (!file) return;

        try {
            setUploading(true);

            const result = await uploadFileToCloudinary(file, {
                folder: "tego/admin_profile_picture",
            });

            set_image_url(result.secure_url);
            console.log("Uploaded image:", result.secure_url);
        } catch (error) {
            toast.error(
                getErrorMessage(error, "Failed to update admin profile picture"),
                {
                    icon: (
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                            <X className="size-4 text-primary" />
                        </div>
                    ),
                }
            );
        } finally {
            setUploading(false);

            // Allows selecting the same image again
            event.target.value = "";
        }
    };

    return (
        <>
            {step === "profile" && (
                <div className="border border-black/6 rounded-[10px] p-[30px]">
                    {/* PROFILE */}
                    <div className="space-y-[20px]">
                        <div className="flex items-center justify-between">
                            <Text title="My Profile" className="uppercase text-sm font-[600] text-black/50" />
                        </div>
                        <div className="flex items-center gap-[34px]">
                            <div className="relative">
                                <img
                                    src={profile?.profile_picture ?? "/images/avatar.png"}
                                    className="rounded-full w-[100px] h-[100px] object-cover border-[2.04px] border-white"
                                />

                                <div className="absolute z-10 top-[70px] left-[70px] w-[30px] h-[30px] bg-white rounded-full flex items-center justify-center">
                                    {getIcon("pencil-edit", { color: "#33ABF7" })}
                                </div>
                            </div>
                            <div className="flex justify-between flex-1">
                                <div className="flex flex-col gap-[8px]">
                                    <Text title={`${profile?.first_name} ${profile?.last_name}`} className="font-[600] text-lg" />
                                    <Text title={profile?.user_type.replaceAll("_", " ") ?? "ADMIN"} className="text-sm font-[500] text-black/60" />
                                    <Text
                                        title={
                                            profile?.location.city && profile.location.state
                                                ? `${profile.location.city}, ${profile.location.state}`
                                                    : "-"
                                            }
                                        className="text-sm font-[500] text-black/60"
                                    />
                                </div>

                                <Button
                                    className="rounded-[1000px] border border-primary" variant={"outline"}
                                    onClick={()=> setStep("edit")}
                                >
                                    <span className="text-sm text-primary">Edit</span>
                                    {getIcon("pencil-edit", { color: "#33ABF7" })}
                                </Button>
                            </div>
                        </div>
                    </div>

                    <div className="w-full h-[1px] bg-black/10 my-8" />

                    <div className="space-y-[30px]">
                        <div className="flex items-center justify-between">
                            <Text title="Personal Information" className="uppercase text-sm font-[600] text-black/50" />
                        </div>
                        <div className="w-[402px] space-y-[20px]">
                            <div className="flex items-center">
                                <ModalFieldItem label="First Name" value={profile?.first_name} className="w-1/2 flex flex-col" />
                                <ModalFieldItem label="Last Name" value={profile?.last_name} className="w-1/2 flex flex-col" />
                            </div>
                            <div className="flex items-center">
                                <ModalFieldItem label="Email" value={profile?.email} className="w-1/2 flex flex-col" />
                                <ModalFieldItem label="Role" value={profile?.user_type} className="w-1/2 flex flex-col" />
                            </div>
                        </div>
                    </div>

                    <div className="w-full h-[1px] bg-black/10 my-8" />

                    <div className="space-y-[30px]">
                        <div className="flex items-center justify-between">
                            <Text title="Address" className="uppercase text-sm font-[600] text-black/50" />
                        </div>

                        <div className="w-[402px] space-y-[20px]">
                            <div className="flex items-center">
                                <ModalFieldItem
                                    label="Country"
                                    value={profile?.location.country || "-"}
                                    className="w-1/2 flex flex-col"
                                />
                                <ModalFieldItem
                                    label="State"
                                    value={profile?.location.state || "-"}
                                    className="w-1/2 flex flex-col"
                                />
                            </div>
                            <div className="flex items-center">
                            <ModalFieldItem
                                    label="City"
                                    value={profile?.location.city || "-"}
                                    className="w-1/2 flex flex-col"
                                />
                                <ModalFieldItem
                                    label="Street"
                                    value={profile?.location.address || "-"}
                                    className="w-1/2 flex flex-col"
                                />
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {step === "edit" && (
                <div className="">
                    <Formik
                        initialValues={{
                            first_name: profile?.first_name ?? "",
                            last_name: profile?.last_name ?? "",
                            email: profile?.email ?? "",
                            phone_number: profile?.phone_number ?? "",
                            country: profile?.location.country ?? "",
                            state: profile?.location.state ?? "",
                            city: profile?.location.city ?? "",
                            address: profile?.location.address ?? "",
                            profile_picture: profile?.profile_picture ?? ""
                        }}
                        onSubmit={()=> {}}
                    >
                        {({ values })=> (
                            <div className="flex flex-col gap-[20px] w-full">
                                <div className="border border-black/6 rounded-[10px] p-[30px]">
                                    <div className="flex items-center gap-[24px]">
                                        <img
                                            src={image_url || profile?.profile_picture || "/images/avatar.png"}
                                            className="rounded-full w-[70px] h-[70px] object-cover border-[2.04px] border-white"
                                            alt="Profile"
                                        />

                                        <div
                                            className="flex items-center gap-2.5 cursor-pointer"
                                            onClick={() => fileInputRef.current?.click()}
                                        >
                                            <Upload className="size-4" />

                                            <Text
                                            title={uploading ? "Uploading..." : "Upload Profile Picture"}
                                            className="text-sm font-[500]"
                                            />
                                        </div>

                                        <input
                                            ref={fileInputRef}
                                            type="file"
                                            accept="image/png,image/jpeg,image/jpg"
                                            className="hidden"
                                            onChange={handleImageUpload}
                                        />
                                    </div>
                                </div>
                                <div className="flex w-full gap-[24px]">
                                    <div className="w-1/2">
                                        <FormField
                                            name="first_name"
                                            placeholder="First Name"
                                            className="shadow-none"
                                        />
                                    </div>
                                    <div className="w-1/2">
                                        <FormField
                                            name="last_name"
                                            placeholder="Last Name"
                                            className="shadow-none"
                                        />
                                    </div>
                                </div>
                                <div className="flex w-full gap-[24px]">
                                     <div className="w-1/2">
                                        <FormField
                                            name="email"
                                            placeholder="Email Address"
                                            type="email"
                                            className="shadow-none"
                                            disabled
                                        />
                                     </div>
                                     <div className="w-1/2">
                                        <FormField
                                            name="phone_number"
                                            placeholder="Phone Number"
                                            className="shadow-none"
                                        />
                                     </div>
                                </div>
                                <div className="flex w-full gap-[24px]">
                                     <div className="w-1/2">
                                        <FormField
                                            name="country"
                                            placeholder="Country"
                                            className="shadow-none"
                                        />
                                     </div>
                                     <div className="w-1/2">
                                        <FormField
                                            name="city"
                                            placeholder="City"
                                            className="shadow-none"
                                        />
                                     </div>
                                </div>
                                <div className="flex w-full gap-[24px]">
                                     <div className="w-1/2">
                                        <FormField
                                            name="area"
                                            placeholder="Area"
                                            className="shadow-none"
                                        />
                                     </div>
                                     <div className="w-1/2">
                                        <FormField
                                            name="street"
                                            placeholder="Street"
                                            className="shadow-none"
                                        />
                                     </div>
                                </div>

                                <div className="flex">
                                    <SaveChangesConfirmation
                                        data={{
                                            first_name: values.first_name,
                                            last_name: values.last_name,
                                            phone_number: values.phone_number,
                                            profile_picture: image_url,
                                            location: {
                                                country: values.country,
                                                state: values.state,
                                                city: values.city,
                                                address: values.address
                                            }
                                        }}
                                        type="details"
                                    />
                                </div>
                            </div>
                        )}
                    </Formik>
                </div>
            )}
        </>
    )
}

export default Profile;