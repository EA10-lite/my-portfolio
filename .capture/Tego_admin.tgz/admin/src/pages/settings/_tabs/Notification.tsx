import { useState } from "react";
import { Text } from "../../../components";
import { Switch } from "../../../components/ui/switch";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Formik } from "formik";
import SaveChangesConfirmation from "../_components/SaveChangesConfirmation";
import type { AdminNotificationSettings } from "../../../services/response-structure";


const Notification = ({ notifications } : { notifications?: AdminNotificationSettings }) => {
    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["provider", "customer", "job", "support"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }
    return (
        <Formik
            initialValues={{
                newProviderRegistration: notifications?.provider.new_provider_registration ?? true,
                verificationRequests: notifications?.provider.verification_requests ?? true,
                subscriptionRenewals: notifications?.provider.subscription_renewals ?? true,
                subscriptionFailures: notifications?.provider.subscription_failures ?? true,
                newCustomerRegistration: notifications?.customers_bookings.new_customer_registration ?? true,
                newBooking: notifications?.customers_bookings.new_booking ?? true,
                bookingCancellation: notifications?.customers_bookings.booking_cancellations ?? true,
                quoteRequests: notifications?.customers_bookings.quote_requests ?? true,
                newJobPosts: notifications?.marketplace_activity.new_job_posts ?? true,
                jobApplications: notifications?.marketplace_activity.job_applications ?? true,
                categoryUpdates: notifications?.marketplace_activity.category_updates ?? true,
                newSupportTicket: notifications?.support.new_support_tickets ?? true,
                ticketEscalated: notifications?.support.escalated_tickets ?? true,
                ticketResolution: notifications?.support.ticket_resolution ?? true,
            }}
            onSubmit={()=> {}}
        >
            {({ values })=> (
                <div className="space-y-[20px]">
                    <div className="bg-[#C0C0C01A] flex flex-col gap-[11px] p-[20px]">
                        <Text
                            title="Notifications"
                            className="font-[600] text-base"
                        />
                        <Text
                            title="Manage account preferences, platform configuration, and operational controls."
                            className="text-black/50 font-[500] text-sm"
                        />
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("provider")}
                        >
                            <Text title="Provider" className="font-[600] text-base" />
                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["provider"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["provider"] && (
                            <div className="bg-white rounded-[6px] p-[16px] border border-[#E8E7E766] flex flex-col gap-[16px]">
                                <Field
                                    title="New Provider Registration"
                                    name="newProviderRegistration"
                                    description="Receive an alert whenever a new provider signs up"
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Verification Requests"
                                    name="verificationRequests"
                                    description="Be notified when providers submit verification documents."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Subscription Renewals"
                                    name="subscriptionRenewals"
                                    description="Get notified when a provider renews their subscription."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Subscription Failures"
                                    name="subscriptionFailures"
                                    description="Receive alerts when subscription payments fail or expire."
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("customer")}
                        >
                            <Text title="Customer & Bookings" className="font-[600] text-base" />
                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["customer"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["customer"] && (
                            <div className="bg-white rounded-[6px] p-[16px] border border-[#E8E7E766] flex flex-col gap-[16px]">
                                <Field
                                    title="New Customer Registration"
                                    name="newCustomerRegistration"
                                    description="Receive an alert whenever a new customer creates an account."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="New Booking"
                                    name="newBooking"
                                    description="Get notified when a customer successfully books a service."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Booking Cancellations"
                                    name="bookingCancellation"
                                    description="Receive alerts whenever a booking is cancelled."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Quote Requests"
                                    name="quoteRequests"
                                    description="Get notified when customers submit quote requests."
                                />
                            </div>
                        )}
                    </div>


                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("job")}
                        >
                            <Text title="Marketplace Activity" className="font-[600] text-base" />
                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["job"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["job"] && (
                            <div className="bg-white rounded-[6px] p-[16px] border border-[#E8E7E766] flex flex-col gap-[16px]">
                                <Field
                                    title="New Job Posts"
                                    name="newJobPosts"
                                    description="Receive an alert when customers publish a new job."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Job Applications"
                                    name="jobApplications"
                                    description="Be notified when providers apply for posted jobs."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Category Updates"
                                    name="categoryUpdates"
                                    description="Receive notifications when categories are created, updated, or disabled."
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("support")}
                        >
                            <Text title="Support" className="font-[600] text-base" />
                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["support"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["support"] && (
                            <div className="bg-white rounded-[6px] p-[16px] border border-[#E8E7E766] flex flex-col gap-[16px]">
                                <Field
                                    title="New Support Tickets"
                                    name="newSupportTicket"
                                    description="Receive alerts when a new support ticket is created."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Ticket Escalated"
                                    name="ticketEscalated"
                                    description="Be notified when a ticket is escalated."
                                />
                                <div className="h-px bg-black/4" />
                                <Field
                                    title="Ticket Resolutions"
                                    name="ticketResolution"
                                    description="Receive notifications when tickets are successfully resolved."
                                />
                            </div>
                        )}
                    </div>

                    <div className="flex justify-end">
                        <SaveChangesConfirmation
                            confirmationDescription="Your notification preferences have been updated. Save these changes to apply your new notification settings."
                            successDescription="Your notification settings have been saved successfully."
                            successTitle="Notification Updated"
                            icon="bell-fill"
                            notification={{
                                provider: {
                                    new_provider_registration: values.newProviderRegistration,
                                    verification_requests: values.verificationRequests,
                                    subscription_renewals: values.subscriptionRenewals,
                                    subscription_failures:  values.subscriptionFailures,
                                },
                                customers_bookings: {
                                    new_customer_registration: values.newCustomerRegistration,
                                    new_booking: values.newBooking,
                                    booking_cancellations: values.bookingCancellation,
                                    quote_requests:  values.quoteRequests,
                                },
                                marketplace_activity: {
                                    new_job_posts: values.newJobPosts,
                                    job_applications: values.jobApplications,
                                    category_updates: values.categoryUpdates,
                                },
                                support: {
                                    new_support_tickets: values.newSupportTicket,
                                    escalated_tickets: values.ticketEscalated,
                                    ticket_resolution:  values.ticketResolution,
                                }
                            }}
                            type="notification"
                        />
                    </div>
                </div>
            )}
        </Formik>
    )
}

const Field = (
    {
        title,
        description,
        name
    } : {
        name: string;
        title: string;
        description: string
    }
) => {
    return (
        <div className="flex items-end justify-between">
            <div className="flex flex-col gap-[11px]">
                <Text title={title} className="text-sm font-[500]" />
                <Text title={description} className="text-xs font-[500] text-black/50" />
            </div>

            <Switch name={name} />
        </div>
    )
}

export default Notification;