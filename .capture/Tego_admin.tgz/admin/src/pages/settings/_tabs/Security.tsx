import { Formik } from "formik";
import { FormField } from "../../../components";
import SaveChangesConfirmation from "../_components/SaveChangesConfirmation";


const Security = () => {
    return (
        <div className="">
            <Formik
                initialValues={{
                    old_password: "",
                    new_password: "",
                    confirmPassword: "",
                }}
                onSubmit={()=> {}}
            >
                {({ values })=> (
                    <div className="flex flex-col gap-[20px]">
                        <FormField
                            name="old_password"
                            type="password"
                            placeholder="Current Password"
                            className="shadow-none"
                        />
                        <FormField
                            name="new_password"
                            type="password"
                            placeholder="New Password"
                            className="shadow-none"
                        />
                        <FormField
                            name="confirm_password"
                            type="confirmPassword"
                            placeholder="Confirm New Password"
                            className="shadow-none"
                        />

                        <div className="flex">
                            <SaveChangesConfirmation
                                buttonTitle="Save Password"
                                confirmationDescription="Save your changes to update your account password. You'll need to use your new password the next time you sign in"
                                confirmationTitle="Update Password"
                                successDescription="Your password has been changed successfully. Your account is now secured with your new password."
                                successTitle="Password Updated"
                                icon="lock-fill"
                                password={{
                                    old_password: values.old_password,
                                    new_password: values.new_password
                                }}
                                type="password"
                            />
                        </div>
                    </div>
                )}
            </Formik>
        </div>
    )
}

export default Security;