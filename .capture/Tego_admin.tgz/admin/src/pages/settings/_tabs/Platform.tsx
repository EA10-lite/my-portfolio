

const Platform = () => {
    return (
        <div className="">Platform</div>
    )
}

export default Platform;