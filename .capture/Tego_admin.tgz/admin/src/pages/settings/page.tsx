import { useQueries } from "@tanstack/react-query";
import { PageHeader } from "../../components/shared";
import {
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
}  from "../../components/ui/tabs"
import Notification from "./_tabs/Notification";
import Profile from "./_tabs/Profile";
import Security from "./_tabs/Security";
import { getAdminNotificationSettings, getAdminProfile } from "../../services/admin-settings.service";
import { Text } from "../../components";

const TABS = [
    { label: "My Profile", value: "profile", component: Profile },
    { label: "Security", value: "security", component: Security },
    { label: "Notification", value: "notification", component: Notification },
];

const Settings = () => {
    const [
        {
            data: profile,
            isLoading,
        },
        {
            data: notifications,
            isLoading: isNotificationLoading,
        }
    ] = useQueries({
        queries: [
            {
                queryKey: ["admin-profile"],
                queryFn: () => getAdminProfile(),
            },
            {
                queryKey: ["admin-notification-settings"],
                queryFn: () => getAdminNotificationSettings(),
            },
        ],
    });

    if (isLoading || isNotificationLoading ) {
        return (
            <div className="min-h-[60vh] flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                    <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                    <Text
                        title="Loading admin details..."
                        type="p"
                        className="text-sm text-black/60"
                    />
                </div>
            </div>
        );
    }

    return (
        <div className="settings space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Settings"
                    description="Manage account preferences, platform configuration, and operational controls."
                    hasDownload={false}
                />
            </div>

            <div className="page-body">
                <Tabs defaultValue="profile" className="w-full space-y-[20px]">
                    <TabsList className="bg-transparent flex gap-[16px]">
                        {TABS.map((tab, index)=> (
                            <TabsTrigger
                                key={index}
                                value={tab.value}
                                className="rounded-full h-10 px-[20px] bg-muted text-black data-[state=active]:bg-black data-[state=active]:text-white"
                            >
                                {tab.label}
                            </TabsTrigger>
                        ))}
                    </TabsList>
                    {TABS.map((tab) => {
                        const Component = tab.component;

                        return (
                            <TabsContent key={tab.value} value={tab.value}>
                                {tab.value === "profile" ? (
                                    <Component profile={profile} />
                                ) : tab.value === "notification" ? (
                                    <Component notifications={notifications} />
                                ) : (
                                    <Component />
                                )}
                            </TabsContent>
                        );
                    })}
                </Tabs>
            </div>
        </div>
    )
}


export default Settings;