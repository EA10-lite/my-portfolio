import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon, type IconType } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { Button } from "../../../components/ui/button";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { X } from "lucide-react";
import { updateAdminNotification, updateAdminPassword, updateAdminProfile, type AdminUserProfile, type ResetAdminPassword } from "../../../services/admin-settings.service";
import type { AdminNotificationSettings } from "../../../services/response-structure";
import { useQueryClient } from "@tanstack/react-query";

const SaveChangesConfirmation = ({
    buttonTitle="Save Changes",
    confirmationTitle="Save Changes",
    confirmationDescription="You have made updates to the profile settings. Do you want to save these changes? Once saved, they will take immediate effect.",
    successDescription="Changes saved successfully.",
    successTitle="Changes Saved",
    icon="like",
    data,
    password,
    notification,
    type,
}:{
    buttonTitle?: string;
    confirmationTitle?: string;
    confirmationDescription?: string;
    successTitle?: string;
    successDescription?: string;
    icon?: string;
    data?: AdminUserProfile,
    password?: ResetAdminPassword,
    notification?: AdminNotificationSettings,
    type: "password" | "details" | "notification"
}) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const handleSubmit = async () => {
        try {
            setLoading(true);
            if(type === "details" && data) await updateAdminProfile(data);
            else if (type === "password" && password) await updateAdminPassword(password)
            else if (type === "notification" && notification) await updateAdminNotification(notification)
            else return;

            await queryClient.invalidateQueries({ queryKey: ["admin-profile", "admin-notification-settings"] });
            setOpen(false)
            setSuccessOpen(true);
        } catch (error) {
            toast.error(getErrorMessage(error, `Failed to update admin ${type}`), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title={successTitle}
                description={successDescription}
                Icon={getIcon(icon as IconType)}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description={confirmationDescription}
                title={confirmationTitle}
                onContinue={handleSubmit}
                TriggerButton={(
                    <Button className="w-[191px] rounded-full h-12">
                        <span>{buttonTitle}</span>
                    </Button>
                )}
                Icon={getIcon(icon as IconType)}
                buttonTitle="Save Changes"
                loading={loading}
                style="min-w-[400px]"
            />
        </>
    )
}


export default SaveChangesConfirmation;