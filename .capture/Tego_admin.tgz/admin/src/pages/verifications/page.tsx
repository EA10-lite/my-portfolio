import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt, formatDateString } from "../../utils/formatter";
import VerificationDetails from "./_components/VerificationDetails";
import ApproveVerification from "./_components/ApproveVerification";
import RejectVerification from "./_components/RejectVerification";
import { useQueries } from "@tanstack/react-query";
import { getVerifications, getVerificationStat } from "../../services/verification.service";
import type { Verification } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { getCategories } from "../../services/category.service";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";
import ReverifyIdentity from "./_components/ReverifyIdentity";

const columns: ColumnDef<Verification>[] = [
    {
        accessorKey: "provider",
        header: "Provider",
        cell: ({ row }) => (
            <span className="capitalize">
                { row.original.provider.name
                    ? row.original.provider.name
                    : `${row.original.provider.first_name} ${row.original.provider.last_name}`
                }
            </span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.category?.name ?? "-"}</span>
        )
    },
    {
        accessorKey: "submittedAt",
        filterFn: dateFilterFn,
        header: "Submitted At",
        cell: ({ row }) => (
            <span className="">
                {formatCreatedAt(row.original.submitted_at)}
            </span>
        )
    },
    {
        accessorKey: "verificationType",
        header: "Verification Type",
        cell: ({ row }) => (
            <span className="capitalize">
                { row.original.verification_type }
            </span>
        )
    },
    {
        accessorKey: "identity_verified",
        header: "Identity Verified",
        cell: ({ row }) => (
            <span className="">
                { row.original.identity_verified ? "True" : "False" }
            </span>
        )
    },
    {
        accessorKey: "status",
        header: "Document",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "approved") badgeVariant = "success";
            if (status === "rejected") badgeVariant = "destructive";
            if (status === "pending") badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {
        header: "Action",
        cell: ({ row }) => {
            return (
                <div className="flex justify-start">
                    <TableAction
                        items={[
                            {
                                label: "view",
                                content: <VerificationDetails verification={row.original} />,
                            },
                            {
                                label:  "approve-verification",
                                content:
                                    row.original.identity_verified
                                        ? null
                                        : <ApproveVerification verificationId={row.original.id} />,
                            },
                            {
                                label: "reverify-identity",
                                content:
                                    row.original.identity_verified
                                        ? null
                                        : <ReverifyIdentity verificationId={row.original.id} />,
                            },
                            {
                                label: "reject-verification",
                                content:
                                    row.original.status.toLowerCase() === "rejected"
                                        ? null
                                        : <RejectVerification verification={row.original} />,
                            }
                        ]}
                    />
                </div>
            )
        }
    }
]

const Verifications = () => {
    const search = useDebouncedSearch();
    const [filters, setFilters] = useState<FilterValues>({});

    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data: stat,
            isLoading: isStatLoading,
        },
        {
            data,
            isLoading,
            isError,
            error,
        },
        {
            data: categories,
        }
    ] = useQueries({
        queries: [
            {
                queryKey: ["verifications-stats"],
                queryFn: getVerificationStat,
            },
            {
                queryKey: [
                    "verifications",
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters,
                ],
                queryFn: () =>
                    getVerifications({
                        page: pagination.pageIndex + 1,
                        limit: pagination.pageSize,
                        search,
                        ...filters,
                    }),
            },
            {
                queryKey: [
                    "categories",
                ],
                queryFn: () =>
                    getCategories({
                        page: 1,
                        limit: 100,
                    }),
            },
        ],
    });

    const handleExport = () => {
        if (!data?.verifications) return;

        const dataToExport = data?.verifications.map((verification: Verification) => ({
            "Provider": `${verification.provider.first_name} ${verification.provider.last_name}`,
            "Verification Type": verification.verification_type,
            "Identity Verified": verification.identity_verified,
            "Business Verified": verification.business_verified,
            "Address Verified": verification.address_verified,
            "Government ID": verification.government_id,
            "Status": verification.status,
            "Created At": formatDateString(verification.reviewed_at),
        }));

        exportToCSV(dataToExport, "verifications");
    };

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Verification Management"
                    description="Review provider identity and business verification documents before approval."
                    metrics={[
                        {
                            label: "Approved Providers",
                            value: stat?.approved.count ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.approved.monthly_change_pct ?? 0,
                        },
                        {
                            label: "Pending Verification",
                            value: stat?.pending.count ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.pending.monthly_change_pct ?? 0,
                        },
                        {
                            label: "Rejected Applications",
                            value: stat?.rejected.count ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.rejected.monthly_change_pct ?? 0,
                        }
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body">
                <ReusableTable
                    title="Verification Queue"
                    data={isError ? [] : data?.verifications || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No verification requests",
                        description: isError ? error.message : "Provider verification submissions will appear here.",
                        icon: "verification-outline"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterTitle="Filter Verification Requests"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Verification Status",
                                    key: "status",
                                    options: [
                                        { label: "Approved", value: "APPROVED" },
                                        { label: "Pending", value: "PENDING" },
                                        { label: "Rejected", value: "REJECTED" },
                                    ],
                                },
                                {
                                    label: "Provider Category",
                                    key: "category",
                                    options: categories?.categories.map(category => ({
                                        label: category.name,
                                        value: category.id,
                                    })) || [],
                                },
                                {
                                    label: "Verification Type",
                                    key: "status",
                                    options: [
                                        { label: "Full Verification", value: "full" },
                                        { label: "Identity Only", value: "identity" },
                                        { label: "Business Verification", value: "BUSINESS" },
                                        { label: "None", value: "none" },
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Verifications;

