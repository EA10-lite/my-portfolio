import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { X } from "lucide-react";
import { approveIdentity } from "../../../services/verification.service";

const ApproveVerification = ({ verificationId } : { verificationId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleApprove = async () => {
        try {
            setLoading(true);
            await approveIdentity(verificationId);
            await queryClient.invalidateQueries({ queryKey: ["verifications"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to approve provider verification"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Approve Verification"
                description={`The provider has been verified successfully and now has full marketplace access`}
                Icon={getIcon("verified")}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="Approving this verification will grant the provider access to publish services and receive marketplace requests."
                title="Approve Verification"
                onContinue={handleApprove}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("verified-alt")}
                        <span className="text-sm font-[500]">Approve Verification</span>
                    </div>
                )}
                Icon={getIcon("verified")}
                buttonTitle="Approve provider"
                loading={loading}
                style="min-w-[371px]"
            />
        </>
    )
}


export default ApproveVerification;