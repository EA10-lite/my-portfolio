import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { X } from "lucide-react";
import { reverifyVerification } from "../../../services/verification.service";

const ReverifyIdentity = ({ verificationId } : { verificationId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleReverification = async () => {
        try {
            setLoading(true);
            await reverifyVerification(verificationId);
            await queryClient.invalidateQueries({ queryKey: ["verifications"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to reverify provider identity"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Identitity Verified"
                description={`The provider identity has been reverified successfully`}
                Icon={getIcon("verified")}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="Reverifying this verification will grant the provider access to publish services and receive marketplace requests."
                title="Reverify Identity"
                onContinue={handleReverification}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("verification-outline", { color: "black" })}
                        <span className="text-sm font-[500]">Verify Identity</span>
                    </div>
                )}
                Icon={getIcon("verified")}
                buttonTitle="Reverify identity"
                loading={loading}
                style="min-w-[371px]"
            />
        </>
    )
}


export default ReverifyIdentity;