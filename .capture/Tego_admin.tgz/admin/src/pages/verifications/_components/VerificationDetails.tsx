import React, { useState } from "react";
import { DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { ChevronDown, ChevronUp, X } from "lucide-react";
import { getIcon } from "../../../components/icons/lib";
import type { Verification } from "../../../services/response-structure";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";
import { Button } from "../../../components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { approveVerification } from "../../../services/verification.service";
import { toast } from "sonner";
import DocumentModal from "../../providers/_components/DocumentModal";

const VerificationDetails = ({ verification } : { verification: Verification }) => {
    const [open, setOpen] = useState<boolean>(false);
    const [openDocument, setOpenDocument] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "document"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const queryClient = useQueryClient();

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleApprove = async () => {
        try {
            setLoading(true);
            await approveVerification(verification.id);
            await queryClient.invalidateQueries({ queryKey: ["verifications"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to approve provider document"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Document Approved"
                description={`The provider document has been verified successfully.`}
                Icon={getIcon("verified")}
            />
            <DocumentModal
                documents={
                    verification?.professional_document
                        ? [verification?.professional_document.file_url]
                        : []
                }
                type={verification?.professional_document?.file_type}
                open={openDocument}
                onOpenChange={()=> setOpenDocument(false)}
                title="Documents"
            />


            <DetailsModal
                title="Verification Details"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("verification-outline", { color: "black" })}
                        <span className="text-sm font-[500]">View Verification</span>
                    </div>
                )}
                ActionButton={verification.status.toLowerCase() !== "approved" && (
                    <Button
                        variant="primary"
                        className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                        onClick={handleApprove}
                    >
                        <span>{loading ? "Approving..." : "Approve Document"}</span>
                    </Button>
                )}
                open={open}
                onOpenChange={setOpen}
                hasFooter={verification.status.toLowerCase() !== "approved"}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={verification?.provider?.profile_picture || "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={verification.provider.first_name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title={verification.provider.phone_number}
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Email"
                                        value={verification.provider.email ?? ""}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Submitted"
                                        value={formatCreatedAt(verification.submitted_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Verification Type"
                                        value={verification.verification_type}
                                    />
                                </div>
                            )}
                        </div>
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("document")}
                            >
                                <Text title="Submitted Document" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["document"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["document"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Document"
                                        content={verification.professional_document && (
                                            <button
                                                onClick={() => setOpenDocument(true)}
                                                className="underline text-primary text-sm font-[500]"
                                            >
                                                View Document
                                            </button>
                                        )}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Government ID"
                                        value={verification.government_id ?? "-"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Business Verification"
                                        value={verification.business_verified ? "Verified" : "Not Verified"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Identify Verification"
                                        value={verification.identity_verified ? "Verified" : "Not Verified"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Address Verification"
                                        value={verification.address ?? "-"}
                                    />
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default VerificationDetails;