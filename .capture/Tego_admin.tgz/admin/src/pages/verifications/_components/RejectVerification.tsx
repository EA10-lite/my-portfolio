import { useQueryClient } from "@tanstack/react-query";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import React, { useState } from "react";
import { toast } from "sonner";
import {
    Checkbox,
    DetailsModal,
    ModalFieldItem,
    SuccessModal,
    Text,
} from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import type { Verification } from "../../../services/response-structure";
import { rejectVerification } from "../../../services/verification.service";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";

const RejectVerification = ({
  verification,
}: {
  verification: Verification;
}) => {
  const queryClient = useQueryClient();
  const [open, setOpen] = React.useState<boolean>(false);

  const [openSections, setOpenSections] = React.useState<
    Record<string, boolean>
  >(() =>
    Object.fromEntries(["summary", "reason", "settings"].map((f) => [f, true])),
  );

  const toggleSection = (key: string) => {
    setOpenSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const [selected, setSelected] = useState<string[]>([]);
  const toggleOption = (option: string) => {
    setSelected((prev) =>
      prev.includes(option)
        ? prev.filter((item) => item !== option)
        : [...prev, option],
    );
  };

  const [loading, setLoading] = useState(false);
  const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
  const handleReject = async () => {
    try {
      setLoading(true);
      await rejectVerification(verification.id, { reason: selected[0] });
      await queryClient.invalidateQueries({
        queryKey: ["verifications"],
      });
      setSuccessOpen(true);
      setOpen(false);
    } catch (error) {
      toast.error(
        getErrorMessage(error, "Failed to reject provider verification"),
        {
          icon: (
            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
              <X className="size-4 text-primary" />
            </div>
          ),
        },
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <SuccessModal
        open={successOpen}
        onOpenChange={() => setSuccessOpen(false)}
        title="Verification Rejected"
        description={"The provider's verification request has been declined."}
        Icon={getIcon("close-fill", { color: "#D8232A" })}
      />
      <DetailsModal
        title="Reject Verification"
        TriggerButton={
          <div className="flex items-center gap-[6px]">
            {getIcon("close-outline")}
            <span className="text-sm font-[500]">Reject Verification</span>
          </div>
        }
        ActionButton={
          <Button
            className="rounded-full h-12 min-w-[169px]"
            variant="destructive"
            onClick={handleReject}
          >
            {loading ? (
              <Loader2 className="animate-spin delay-150ms" />
            ) : (
              <span>Reject Verification</span>
            )}
          </Button>
        }
        open={open}
        onOpenChange={setOpen}
      >
        <div className="px-[16px] space-y-[20px]">
          <div className="flex items-center gap-[13px]">
            <div className="avatar relative">
              <img
                src={
                  verification?.provider?.profile_picture ?? "/images/avatar.png"
                }
                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                loading="lazy"
              />
            </div>
            <div className="flex flex-col justify-between gap-[14px]">
              <Text
                type="h4"
                className="font-[600] text-lg"
                title={`${verification?.provider?.name}`}
              />
              <Text
                type="p"
                className="font-[500] text-base text-black/60"
                title={verification?.category?.name}
              />
            </div>
          </div>

          <div className="flex flex-col gap-[18px]">
            <div className="bg-[#F9F9F9] rounded-[6px]">
              <button
                className="flex items-center justify-between w-full p-[16px]"
                onClick={() => toggleSection("summary")}
              >
                <Text
                  title="Provider Information"
                  className="text-[13px] font-[600]"
                  type="h5"
                />

                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                  {openSections["summary"] ? (
                    <ChevronUp className="size-4 text-primary" />
                  ) : (
                    <ChevronDown className="size-4 text-primary" />
                  )}
                </div>
              </button>
              {openSections["summary"] && (
                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                  <ModalFieldItem
                    className="flex-row items-center justify-between"
                    label="Email"
                    value={verification?.provider?.phone_number ?? "-"}
                  />
                  <ModalFieldItem
                    className="flex-row items-center justify-between"
                    label="Submitted"
                    value={formatCreatedAt(verification.submitted_at)}
                  />
                  <ModalFieldItem
                    className="flex-row items-center justify-between"
                    label="Verification Type"
                    value={"Full Verification"}
                  />
                </div>
              )}
            </div>

            <div className="bg-[#F9F9F9] rounded-[6px]">
              <button
                className="flex items-center justify-between w-full p-[16px]"
                onClick={() => toggleSection("reason")}
              >
                <Text
                  title="Rejection Reason"
                  className="text-[13px] font-[600]"
                  type="h5"
                />

                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                  {openSections["reason"] ? (
                    <ChevronUp className="size-4 text-primary" />
                  ) : (
                    <ChevronDown className="size-4 text-primary" />
                  )}
                </div>
              </button>
              {openSections["reason"] && (
                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                  {[
                    { label: "Fraudulent", value: "FRAUD_CONCERN" },
                    {
                      label: "Invalid Documents",
                      value: "INVALID_ID_DOCUMENTS",
                    },
                    {
                      label: "Mismatched Selfie Verification",
                      value: "MISMATCHED_SELFIE_VERIFICATION",
                    },
                    {
                      label: "Unclear Business Document",
                      value: "UNCLEAR_BUSINESS_DOCUMENT",
                    },
                    {
                      label: "Incomplete Submission",
                      value: "INCOMPLETE_SUBMISSION",
                    },
                  ].map((option) => {
                    const isChecked = selected?.includes(option.value) ?? false;
                    return (
                      <Checkbox
                        key={option.value}
                        onChange={() => toggleOption(option.value)}
                        checked={isChecked}
                        label={option.label}
                        type="radio"
                      />
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </DetailsModal>
    </>
  );
};

export default RejectVerification;
