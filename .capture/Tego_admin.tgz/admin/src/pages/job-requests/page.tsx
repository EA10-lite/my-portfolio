import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatDateString } from "../../utils/formatter";
import BookingDetails from "./_components/BookingDetails";
import { useQueries } from "@tanstack/react-query";
import { getRequestAndBookings } from "../../services/service-booking.service";
import type { RequestAndBooking } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { getCategories } from "../../services/category.service";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const columns: ColumnDef<RequestAndBooking>[] = [
    {
        accessorKey: "id",
        header: "Booking ID",
        cell: ({ row }) => (
            <span className="text-sm uppercase">
                BOK-{row.original.id.slice(-4)}
            </span>
        )
    },
    {
        accessorKey: "customer",
        header: "Customer",
        cell: ({ row }) => (
            <span className="capitalize">
                {`${row.original.customer.first_name} ${row.original.customer.last_name}`}
                </span>
        )
    },
    {
        accessorKey: "provider",
        header: "Provider",
        cell: ({ row }) => (
            <span className="capitalize">
                {`${row.original.provider.first_name} ${row.original.provider.last_name}`}
            </span>
        )
    },
    {
        accessorKey: "service",
        header: "Service",
        cell: ({ row }) => (
            <span className="capitalize">
                {row.original.service_name}
            </span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = !row.original.order_status
                ? row.original.booking_status.toLowerCase()
                    : row.original.order_status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "completed") badgeVariant = "success";
            if (status === "cancelled") badgeVariant = "destructive";
            if (
                status === "pending"
                || status === "awaiting_provider"
                || status === "in_negotiation"
                || status === "cancellation_requested"
            ) badgeVariant = "pending";
            if (
                status === "in_progress"
                || status === "accepted"
            ) badgeVariant = "primary";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <TableAction
                    items={[
                        {
                            label: "view",
                            content: <BookingDetails booking={row.original} />,
                        }
                    ]}
                />
            </div>
        )
    },
    {
        accessorKey: "createdAt",
        header: () => null,
        cell: () => null,
        filterFn: dateFilterFn,
        enableHiding: true,
    }
]

const JobRequests = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({})
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data,
            isLoading,
            isError,
            error,
        },
        {
            data: categories,
        }
    ] = useQueries({
        queries: [
            {
                queryKey: [
                    'request-and-bookings',
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters
                ],
                queryFn: () => getRequestAndBookings({
                    page: pagination.pageIndex + 1,
                    limit: pagination.pageSize,
                    search,
                    ...filters,
                }),
            },
            {
                queryKey: [
                    "categories",
                ],
                queryFn: () =>
                    getCategories({
                        page: 1,
                        limit: 100,
                    }),
            },
        ],
    });

    const handleExport = () => {
        if (!data?.bookings) return;

        const dataToExport = data.bookings.map((booking: RequestAndBooking) => ({
            "Category": booking.category.name,
            "Customer": `${booking.customer.first_name} ${booking.customer.last_name}`,
            "Provider": `${booking.provider.first_name} ${booking.provider.last_name}`,
            "Price": booking.price,
            "Status": booking.booking_status,
            "Created At": formatDateString(booking.created_at),
        }));

        exportToCSV(dataToExport, "direct-bookings");
    };

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Bookings & Requests"
                    description="Track customer requests, booking activity, provider responses, and service progress."
                    metrics={[
                        {
                            label: "Total Requests",
                            value: data?.stats?.total_requests?.count ?? 0,
                            filter: "This month",
                            percentageIncrease: data?.stats?.total_requests?.change_pct ?? 0
                        },
                        {
                            label: "Active Bookings",
                            value: data?.stats?.active_bookings?.count ?? 0,
                            filter: "This month",
                            percentageIncrease: data?.stats?.active_bookings?.change_pct ?? 0
                        },
                        {
                            label: "Completed Requests",
                            value: data?.stats?.completed_requests?.count ?? 0,
                            filter: "This month",
                            percentageIncrease: data?.stats?.completed_requests?.change_pct ?? 0
                        },
                        {
                            label: "Pending Provider Action",
                            value: data?.stats?.pending_actions?.count ?? 0,
                            filter: "This month",
                            percentageIncrease: data?.stats?.pending_actions?.change_pct ?? 0
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isLoading}
                />
            </div>
            <div className="page-body">
                <ReusableTable
                    title="Direct Bookings"
                    data={isError ? [] : data?.bookings || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No requests yet",
                        description: isError ? error.message : "Bookings, quote requests, and inspections will appear here.",
                        icon: "request-outline"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                          ...prev,
                          pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                          ...prev,
                          period: [period],
                        }));
                    }}
                    filterTitle="Filter Requests & Bookings"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Booking Type",
                                    key: "request_type",
                                    options: [
                                        { label: "Direct Booking", value: "book_service" },
                                        { label: "Quote Request", value: "job_request" }
                                    ],
                                },
                                {
                                    label: "Booking Status",
                                    key: "status",
                                    options: [
                                        { label: "Pending", value: "PENDING" },
                                        { label: "Awaiting Provider", value: "AWAITING_PROVIDER" },
                                        { label: "Accepted", value: "ACCEPTED" },
                                        { label: "Completed", value: "COMPLETED" },
                                        { label: "Cancelled", value: "CANCELLED" },
                                    ],
                                },
                                {
                                    label: "Category",
                                    key: "category",
                                    options: categories?.categories.map(category => ({
                                        label: category.name,
                                        value: category.id
                                    })) || [],
                                }
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default JobRequests;

