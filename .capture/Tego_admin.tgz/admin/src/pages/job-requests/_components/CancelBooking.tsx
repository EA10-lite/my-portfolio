import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { getErrorMessage } from "../../../utils/formatter";
import { X } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { cancelBooking } from "../../../services/service-booking.service";

const CancelBooking = ({ bookingId } : { bookingId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleCancel = async () => {
        try {
            setLoading(true);
            await cancelBooking(bookingId, { reason: "" });
            await queryClient.invalidateQueries({ queryKey: ["request-and-bookings"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to cancel booking"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Cancel Booking"
                description={`Booking has been cancelled.`}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This booking will stop and both parties will be notified."
                title="Cancel Booking"
                onContinue={handleCancel}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("close-outline", { color: "#D8232A"})}
                        <span className="text-sm font-[500] text-destructive">Cancel Booking</span>
                    </div>
                )}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
                buttonTitle="Cancel Booking"
                buttonType="destructive"
                loading={loading}
            />
        </>
    )
}


export default CancelBooking;