import React, { useState } from "react";
import {DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2 } from "lucide-react";
import { formatCurrency } from "../../../utils/formatter";

const ReasignProvider = () => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["booking", "provider"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleReassign = () => {
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            setOpen(false);        // close the sheet
            setSuccessOpen(true)   // open success modal
        }, 1000)
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Provider Reassigned"
                description={`Provider access has been reassigned to booking successfully.`}
                Icon={getIcon("edit-outline")}
            />
            <DetailsModal
                title="Reassign Provider"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("edit-outline", { color: "#000000" })}
                        <span className="text-sm font-[500]">Reassign Provider</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="primary"
                        onClick={handleReassign}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Reassign Provider</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] ">

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("booking")}
                            >
                                <Text title="Booking Information" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["booking"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["booking"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Booking ID"
                                        value={"BOK-234"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Booking Type"
                                        value={"Direct Booking"}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Suspension Reason" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["provider"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Provider's Name"
                                        value={"Daniel Okeke"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Subscription"
                                        value={"Pro Annual"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Serivce"
                                        value={"Generator Repair"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Price"
                                        value={formatCurrency(18000)}
                                    />
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default ReasignProvider;