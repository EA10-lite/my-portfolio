import React from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { ChevronDown, ChevronUp } from "lucide-react";
import { formatCreatedAt, formatCurrency, formatDateString } from "../../../utils/formatter";
import type { RequestAndBooking } from "../../../services/response-structure";

const BookingDetails = ({ booking } : { booking: RequestAndBooking }) => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["booking", "provider", "customer", "activity"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Booking Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    {getIcon("request-outline", { color: "#000000" })}
                    <span className="text-sm font-[500]">View Booking</span>
                </div>
            )}
            ActionButton={null}
            hasFooter={false}
            open={open}
            onOpenChange={setOpen}
        >
            <div className="px-[16px]">
                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("booking")}
                        >
                            <Text title="Booking Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["booking"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["booking"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Booking ID"
                                    value={booking.id}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Status"
                                    value={booking.booking_status}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Booking Type"
                                    value={
                                        booking.request__type === "book_service"
                                            ? "Direct Booking"
                                                : "Service Request"
                                    }
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("provider")}
                        >
                            <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["provider"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["provider"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Provider's Name"
                                    value={`${booking.provider.first_name} ${booking.provider.last_name}`}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Service Type"
                                    value={booking.service_name}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Price"
                                    value={booking.price ? formatCurrency(booking.price) : "-"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Date"
                                    value={formatDateString(booking.date)}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("customer")}
                        >
                            <Text title="Customer Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["customer"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["customer"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Customer's Name"
                                    value={`${booking.customer.first_name} ${booking.customer.last_name}`}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Phone"
                                    value={booking.customer.phone_number ?? "-"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Email"
                                    value={booking.customer.email ?? "-"}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("activity")}
                        >
                            <Text title="Activity Log" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["activity"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["activity"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                {booking.activity_log.map((log, index)=> (
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label={log.description}
                                        value={formatCreatedAt(log.timestamp)}
                                        key={index}
                                    />
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </DetailsModal>
    )
}


export default BookingDetails;