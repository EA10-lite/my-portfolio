import { useState } from "react";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { featureService } from "../../../services/services.service";
import type { Service } from "../../../services/response-structure";

const FeatureService = ({ service }: { service: Service }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "timeline", "placement"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [timeline, setTimeline] = useState<string | null>(null)
    const [selected, setSelected] = useState<string[]>([]);
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        );
    };

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleFeatureService = async () => {
        try {
            setLoading(true);
            await featureService({
                service_id: service.id,
                timeline: 14,
                placement: selected,
            });
            await queryClient.invalidateQueries({ queryKey: ["services"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to approve provider services"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Featured Service"
                description={`Service featured successfully.`}
                Icon={getIcon("feature-fill")}
            />
            <DetailsModal
                title="Feature Service"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("feature-outline", { color: "#000000" })}
                        <span className="text-sm font-[500]">Feature Service</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="primary"
                        onClick={handleFeatureService}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Feature Service</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src="https://media.gettyimages.com/id/75407569/photo/apprentice-plumber.jpg?s=612x612&w=0&k=20&c=QyIuYeaAcDFwJWUf7jcD7TmINHRbrd1lf8-77BDtjqw="
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={service.provider.first_name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title="Active"
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Provider Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Category"
                                        value={service?.category?.name ?? "-"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Subscription"
                                        value={service?.subscription_type}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={service.provider.phone_number ?? "-"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(service?.created_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={service.last_active ? formatCreatedAt(service.last_active) : "-"}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("timeline")}
                            >
                                <Text title="Timeline" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["timeline"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["timeline"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "7 days",
                                        "14 days",
                                        "30 days",
                                    ].map(option => {
                                        const isChecked = timeline === option
                                        return (
                                            <button
                                                key={option}
                                                className="flex items-center gap-[10px]"
                                                onClick={() => setTimeline(option)}
                                            >
                                                <div className={`w-[16px] h-[16px] rounded-full border flex items-center justify-center transition-colors border-black/20`}>
                                                    {isChecked && (
                                                        <div className="w-[10px] h-[10px] rounded-full bg-primary" />
                                                    )}
                                                </div>
                                                <Text
                                                    title={option}
                                                    className={`text-[13px] font-[500] transition-colors ${isChecked ? "text-primary" : "text-black/50"}`}
                                                    type="h5"
                                                />
                                            </button>
                                        )
                                    })}
                            </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("placement")}
                            >
                                <Text title="Placement" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["placement"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["placement"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        { label: "Homepage", value: "homepage" },
                                        { label: "Featured services", value: "featured_services" },
                                        { label: "Category Highlights", value: "category"},
                                    ].map((option, index) => {
                                        const isChecked = selected?.includes(option.value) ?? false
                                        return (
                                            <Checkbox
                                                key={index}
                                                label={option.label}
                                                checked={isChecked}
                                                onChange={() => toggleOption(option.value)}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default FeatureService;