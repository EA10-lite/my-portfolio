import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { approveService } from "../../../services/services.service";
import { toast } from "sonner";
import { X } from "lucide-react";
import { getErrorMessage } from "../../../utils/formatter";

const ApproveService = ({ serviceId } : { serviceId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleApprove = async () => {
        try {
            setLoading(true);
            await approveService(serviceId);
            await queryClient.invalidateQueries({ queryKey: ["services"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to approve provider services"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Approve Service"
                description={`Service approved successfully.`}
                Icon={getIcon("check")}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This service will become visible to all users."
                title="Approve Service"
                onContinue={handleApprove}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("verified-alt")}
                        <span className="text-sm font-[500]">Approve service</span>
                    </div>
                )}
                Icon={getIcon("check")}
                buttonTitle="Approve"
                loading={loading}
            />
        </>
    )
}


export default ApproveService;