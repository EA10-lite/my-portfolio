import React, { useState } from "react";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { removeService } from "../../../services/services.service";
import type { Service } from "../../../services/response-structure";

const RemoveService = ({ service }: { service: Service }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["checklist", "summary"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [selected, setSelected] = useState<string[]>([]);
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        );
    };

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleRemoveService = async () => {
        try {
            setLoading(true);
            await removeService({
                service_id: service.id,
                notify_customer: selected.length > 0,
            });
            await queryClient.invalidateQueries({ queryKey: ["services"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to remove service"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Service deleted"
                description={`Service has been permanently removed.`}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
            />
            <DetailsModal
                title="Feature Service"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("trash-fill", { color: "#D8232A" })}
                        <span className="text-sm font-[500] text-destructive">Delete Service</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="destructive"
                        onClick={handleRemoveService}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Remove Service</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={service.provider.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={`${service.provider.first_name} ${service.provider.last_name}`}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title={service.last_active}
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Provider Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Category"
                                        value={service?.category?.name ?? "-"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Subscription"
                                        value={service?.subscription_type}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={service?.provider?.phone_number ?? "-" }
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(service.created_at)}
                                    />
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("checklist")}
                            >
                                <Text title="Checklist" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["checklist"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["checklist"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Notify Provider",
                                    ].map(option => {
                                        const isChecked = selected?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                label={option}
                                                checked={isChecked}
                                                onChange={() => toggleOption(option)}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default RemoveService;