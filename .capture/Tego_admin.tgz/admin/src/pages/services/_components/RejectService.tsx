import { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { rejectService } from "../../../services/services.service";
import { X } from "lucide-react";

const ApproveService = ({ serviceId } : { serviceId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleReject = async () => {
        try {
            setLoading(true);
            await rejectService({
                service_id: serviceId,
                rejection_reason: "Service images do not match the listed category",
            });
            await queryClient.invalidateQueries({ queryKey: ["services"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to reject provider services"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }


    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Reject Service"
                description={`This service has been rejected and hidden from customers.`}
                Icon={getIcon("close-fill")}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This service will not appear publicly."
                title="Reject Service"
                onContinue={handleReject}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("close-outline")}
                        <span className="text-sm font-[500]">Reject service</span>
                    </div>
                )}
                Icon={getIcon("close-fill")}
                buttonTitle="Reject"
                loading={loading}
            />
        </>
    )
}


export default ApproveService;