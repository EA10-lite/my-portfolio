import { useState } from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { ChevronDown, ChevronUp, Settings } from "lucide-react";
import { formatCreatedAt, formatCurrency } from "../../../utils/formatter";
import type { Service } from "../../../services/response-structure";


const ServiceDetails = ({ service }: { service: Service }) => {
    const [open, setOpen] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "services"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Service Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    <Settings />
                    <span className="text-sm font-[500]">View service</span>
                </div>
            )}
            ActionButton={null}
            open={open}
            onOpenChange={setOpen}
            hasFooter={false}
        >
            <div className="px-[16px] space-y-[20px]">
                <div className="flex items-center gap-[13px]">
                    <div className="avatar relative">
                        <img
                            src={service.provider.profile_picture ?? "/images/avatar.png"}
                            className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                            loading="lazy"
                        />
                    </div>
                    <div className="flex flex-col justify-between gap-[14px]">
                        <Text
                            type="h4"
                            className="font-[600] text-lg"
                            title={`${service.provider.first_name} ${service.provider.last_name}`}
                        />
                        <Text
                            type="p"
                            className="font-[500] text-base text-black/60"
                            title={
                                service.provider.email
                                    ? service.provider.email
                                    : service.service_name
                            }
                        />
                    </div>
                </div>

                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("summary")}
                        >
                            <Text title="Provider Summary Card" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["summary"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["summary"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Category"
                                    value={service?.category?.name}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Subscription"
                                    value={service?.subscription_type}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Phone Number"
                                    value={service?.provider?.phone_number}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Joined Date"
                                    value={formatCreatedAt(service?.created_at)}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("services")}
                        >
                            <Text title="Services" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["services"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["services"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                {service.service_items.map((item, index)=> (
                                    <ModalFieldItem
                                        key={index}
                                        className="flex-row items-center justify-between"
                                        label={item.service_name}
                                        value={
                                            item.pricing_type === "FIXED"
                                                ? formatCurrency(item.price)
                                                : item.pricing_type.replaceAll("_", " ")
                                        }
                                    />
                                ))}
                            </div>
                        )}
                    </div>

                    {/* <div className="bg-[#F9F9F9] rounded-[6px] hidden">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("gallery")}
                        >
                            <Text title="Gallery" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["gallery"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["gallery"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                                    {WORK_IMAGES.slice(0,count).map((work, index)=> (
                                        <img
                                            src={work}
                                            key={index}
                                            className="rounded-[6px] min-h-[142px] w-full object-cover"
                                            loading="lazy"
                                        />
                                    ))}
                                </div>
                                {WORK_IMAGES.length > 4 && (
                                    <div className="flex justify-end">
                                        <button
                                            className="underline text-primary text-[13px] font-[500]"
                                            onClick={() => setCount(WORK_IMAGES.length > count ? WORK_IMAGES.length : 4)}
                                        >
                                            See {WORK_IMAGES.length > count ? "more" : "less"}
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div> */}
                </div>

            </div>
        </DetailsModal>
    )
}


export default ServiceDetails;