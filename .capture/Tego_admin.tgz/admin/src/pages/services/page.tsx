import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt, formatDateString } from "../../utils/formatter";
import FeatureService from "./_components/FeatureService";
import RemoveService from "./_components/RemoveService";
import ServiceDetails from "./_components/ServiceDetails";
import ApproveService from "./_components/ApproveService";
import RejectService from "./_components/RejectService";
import { useQueries } from "@tanstack/react-query";
import { getServices } from "../../services/services.service";
import type { Service } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { getCategories } from "../../services/category.service";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const columns: ColumnDef<Service>[] = [
    {
        accessorKey: "title",
        header: "Service",
        cell: ({ row }) => (
            <span className="text-sm">{row?.original?.service_name}</span>
        )
    },
    {
        accessorKey: "provider",
        header: "Provider",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.provider.first_name}</span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original?.category?.name ?? "-"}</span>
        )
    },
    {
        accessorKey: "createdAt",
        filterFn: dateFilterFn,
        header: "Created",
        cell: ({ row }) => (
            <span className="">
                {formatCreatedAt(row.original?.created_at)}
            </span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "active") badgeVariant = "success";
            if (status.toLowerCase() === "inactive") badgeVariant = "destructive";
            if (status.includes("pending")) badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status.replaceAll("_", " ")}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <TableAction
                    items={[
                        {
                            label: "view",
                            content: <ServiceDetails service={row.original} />,
                        },
                        {
                            label: "approve",
                            content:
                                row.original.status === "ACTIVE"
                                    ? null
                                    : <ApproveService serviceId={row.original.id} />,
                        },
                        {
                            label: "feature",
                            content: <FeatureService service={row.original} />,
                        },
                        {
                            label: "reject",
                            content: <RejectService serviceId={row.original.id} />,
                        },
                        {
                            label: "delete",
                            content: <RemoveService service={row.original} />,
                        },
                    ]}
                />
            </div>
        )
    }
]

const Services = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data,
            isLoading,
            isError,
            error,
        },
        {
            data: categories,
        }
    ] = useQueries({
        queries: [
            {
                queryKey: [
                    'services',
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters,
                ],
                queryFn: () => getServices({
                    page: pagination.pageIndex + 1,
                    limit: pagination.pageSize,
                    search,
                    ...filters
                })
            },
            {
                queryKey: [
                    "categories",
                ],
                queryFn: () =>
                    getCategories({
                        page: 1,
                        limit: 100,
                    }),
            },
        ],
    });


    const handleExport = () => {
        if (!data?.services) return;

        const dataToExport = data.services.map((service: Service) => ({
            "Name": `${service.provider.first_name} ${service.provider.last_name}`,
            "Title": service.service_name,
            "Category": service.category.name,
            "Status": service.status,
            "Created At": formatDateString(service.created_at),
        }));

        exportToCSV(dataToExport, "services");
    };

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Services"
                    description="Review, moderate, approve, and manage all service listings across the marketplace."
                    metrics={[
                        {
                            label: "Total Services",
                            value: data?.stats?.total_services?.count ?? 0,
                            filter: "All Time",
                            percentageIncrease: data?.stats?.total_services?.change_pct ?? 0,
                        },
                        {
                            label: "Active Services",
                            value: data?.stats?.active_services?.count ?? 0,
                            filter: "All Time",
                            percentageIncrease:  data?.stats?.active_services?.change_pct ?? 0,
                        },
                        {
                            label: "Featured Services",
                            value: data?.stats?.featured_services?.count ?? 0,
                            filter: "All Time",
                            percentageIncrease: data?.stats?.featured_services?.change_pct ?? 0,
                        },
                        {
                            label: "Pending Approvals",
                            value: data?.stats?.pending_approval?.count ?? 0,
                            filter: "All Time",
                            percentageIncrease: data?.stats?.pending_approval?.change_pct ?? 0,
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isLoading}
                />
            </div>
            <div className="page-body">
                <ReusableTable
                    title="Services"
                    data={isError ? [] : data?.services || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No services available",
                        description: isError ? error.message : "Published provider services will appear here.",
                        icon: "service-outline"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                          ...prev,
                          pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                          ...prev,
                          period: [period],
                        }));
                    }}
                    filterTitle="Filter Services"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Service Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value :"active" },
                                        { label: "Pending Approval", value: "pending" },
                                        { label: "Rejected", value: "rejected" },
                                        { label: "Featured", value: "featured" },
                                        { label: "Removed", value: "removed" }
                                    ],
                                },
                                {
                                    label: "Category",
                                    key: "category",
                                    options: categories?.categories.map(category => ({
                                        label: category.name,
                                        value: category.id
                                    })) || [],
                                },
                                {
                                    label: "Service Performance",
                                    key: "performance",
                                    options: [
                                        { label: "Most Booked", value: "most_booked" },
                                        { label: "Least Booked", value: "least_booked" },
                                        { label: "Highest Rated", value: "highest_rated" },
                                        { label: "Low Engagement", value: "low_engagement" }
                                    ],
                                },
                                {
                                    label: "Subscription",
                                    key: "subscription",
                                    options: [
                                        { label: "Free", value: "FREE" },
                                        { label: "Pro Monthly", value: "PRO_MONTHLY" },
                                        { label: "Pro Yearly", value: "PRO_YEARLY" }
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Services;

