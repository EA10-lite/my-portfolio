import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt, formatCurrency, formatDateString } from "../../utils/formatter";
import JobDetails from "./_components/JobDetails";
import AssignProvider from "./_components/AssignProvider";
import DeleteJob from "./_components/DeleteJob";
import ApplicationDetails from "./_components/ApplicationDetails";
import {
    getApplications,
    getJobStats,
    getListings,
} from "../../services/job-market.service";
import { useQueries } from "@tanstack/react-query";
import type { Application, Job } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { getCategories } from "../../services/category.service";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const listingColumns: ColumnDef<Job>[] = [
    {
        accessorKey: "title",
        header: "Job Title",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.title}</span>
        )
    },
    {
        accessorKey: "customer",
        header: "Posted By",
        cell: ({ row }) => (
            <span className="capitalize">
                {`${row.original.postedBy.firstName} ${row.original.postedBy.lastName}`}
            </span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.category.name}</span>
        )
    },
    {
        accessorKey: "applications",
        header: "Applications",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.applications}</span>
        )
    },
    {
        accessorKey: "createdAt",
        header: "Posted",
        cell: ({ row }) => (
            <span className="capitalize">{formatCreatedAt(row.original.postedAt)}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "accepted") badgeVariant = "primary";
            if (
                status === "delivered" ||
                status === "completed" ||
                status === "active"
            ) badgeVariant = "success";
            if (status === "expired" || status === "cancelled") badgeVariant = "destructive";
            if (status === "pending") badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <TableAction
                    items={[
                        {
                            label: "Job Details",
                            content: <JobDetails />
                        },
                        {
                            label: "Assign Provider",
                            content: <AssignProvider />
                        },
                        {
                            label: "Delete Job",
                            content: <DeleteJob jobId={row.original.id} />
                        }
                    ]}
                />
            </div>
        )
    },
]

const applicationColumns: ColumnDef<Application>[] = [
    {
        accessorKey: "provider",
        header: "Provider",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.provider.name}</span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.category.name}</span>
        )
    },
    {
        accessorKey: "price",
        header: "Price",
        cell: ({ row }) => (
            <span className="capitalize">
                {row.original.proposed_price ? formatCurrency(row.original.proposed_price) : "-"}
            </span>
        )
    },
    {
        accessorKey: "time",
        header: "Estimated Time",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.estimated_time}</span>
        )
    },
    {
        accessorKey: "rating",
        header: "Rating",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.provider.rating ?? "-"}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "accepted" || status === "submitted") badgeVariant = "primary";
            if (
                status === "expired" ||
                status === "cancelled" ||
                status === "rejected"
            ) badgeVariant = "destructive";
            if (status === "pending") badgeVariant = "pending";
            if (status === "withdrawn") badgeVariant = "muted";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "muted" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <ApplicationDetails application={row.original} />
            </div>
        )
    },
    {
        accessorKey: "createdAt",
        header: () => null,
        cell: () => null,
        filterFn: dateFilterFn,
        enableHiding: true,
    }
]

const Jobs = () => {
    const search = useDebouncedSearch(500);
    const [listingFilter, setListingFilter] = useState<FilterValues>({});
    const [applicationFilter, setApplicationFilter] =
        useState<FilterValues>({});

    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [pagination2, setPagination2] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data: stat,
            isLoading: isStatLoading,
        },
        {
            data: listings,
            isLoading,
            isError,
            error,
        },
        {
            data: applications,
            isLoading: isLoading2,
            isError: isError2,
            error: error2,
        },
        {
            data: categories
        }
    ] = useQueries({
        queries: [
            {
                queryKey: ["job-stats"],
                queryFn: getJobStats,
            },

            {
                queryKey: [
                    "job-listings",
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    listingFilter,
                ],
                queryFn: () =>
                    getListings({
                        page: pagination.pageIndex + 1,
                        limit: pagination.pageSize,
                        search,
                        ...listingFilter,
                    }),
            },

            {
                queryKey: [
                    "job-applications",
                    pagination2.pageIndex,
                    pagination2.pageSize,
                    search,
                    applicationFilter,
                ],
                queryFn: () =>
                    getApplications({
                        page: pagination2.pageIndex + 1,
                        limit: pagination2.pageSize,
                        search,
                        ...applicationFilter,
                    }),
            },
            {
                queryKey: [
                    "categories",
                ],
                queryFn: () =>
                    getCategories({
                        page: 1,
                        limit: 100,
                    }),
            },
        ],
    });

    const handleExport = () => {
        if (!listings?.jobRequests || !applications?.applications) return;

        const dataToExport = listings?.jobRequests.map((job: Job) => ({
            "Title": job.title,
            "Description": job.description,
            "Applications": job.applications,
            "Category": job.category.name,
            "Status": job.status,
            "Created At": formatDateString(job.postedAt),
        }));

        const dataToExport2 = applications?.applications.map((application: Application) => ({
            "Provider": application.provider.name,
            "Proposed Price": application.proposed_price,
            "Rating": application.provider.rating,
            "Category": application.category.name,
            "Status": application.status,
            "Created At": formatDateString(application.created_at),
        }));

        exportToCSV(dataToExport, "jobs");
        exportToCSV(dataToExport2, "applications");
    };

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Job Marketplace"
                    description="Track posted jobs, review applications, and manage marketplace activity."
                    metrics={[
                        {
                            label: "Total Jobs",
                            value: stat?.stats.totalJobs ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.trends.totalJobs ?? 0
                        },
                        {
                            label: "Active Jobs",
                            value: stat?.stats.activeJobs ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.trends.activeJobs ?? 0
                        },
                        {
                            label: "Completed Jobs",
                            value: stat?.stats.completedJobs ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.trends.completedJobs ?? 0
                        },
                        {
                            label: "Average Applications",
                            value: stat?.stats.averageApplications ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.trends.averageApplications ?? 0
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body space-y-[20px]">
                <ReusableTable
                    title="Listings"
                    data={isError ? [] : listings?.jobRequests || []}
                    columns={listingColumns}
                    manualPagination={true}
                    pageCount={listings?.total_pages ?? listings?.totalPages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No jobs posted",
                        description: isError ? error.message : "Jobs created by customers will appear here.",
                        icon: "store-fill"
                    }}
                    filterTitle="Filter Jobs"
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                          ...prev,
                          pageIndex: 0,
                        }));
                        setListingFilter((prev) => ({
                          ...prev,
                          period: [period],
                        }));
                    }}
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value: "ACTIVE" },
                                        { label: "Completed", value: "COMPLETED" },
                                        { label: "pending", value: "PENDING" },
                                        { label: "cancelled", value: "CANCELLED" },
                                    ],
                                },
                                {
                                    label: "Posted Date",
                                    key: "period",
                                    options: [
                                        { label: "Today", value: "1day" },
                                        { label: "This Week", value: "7d" },
                                        { label: "Last 30 days", value: "30d" }
                                    ],
                                },
                                {
                                    label: "Application Count",
                                    key: "applications",
                                    options: [
                                        { label: "0-10", value: "0-10" },
                                        { label: "11-50", value: "11-50" },
                                        { label: "51-100", value: "51-100" },
                                        { label: "100+", value: "100+" }
                                    ],
                                },
                                {
                                    label: "Category",
                                    key: "category",
                                    options: categories?.categories.map(category => ({
                                        label: category.name,
                                        value: category.id,
                                    })) || [],
                                },
                            ]}
                            values={listingFilter}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setListingFilter(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setListingFilter({});
                            }}
                        />
                    )}
                />
                <ReusableTable
                    title="Applications"
                    data={isError2 ? [] : applications?.applications || []}
                    columns={applicationColumns}
                    manualPagination={true}
                    pageCount={applications?.total_pages ?? applications?.totalPages}
                    pagination={pagination2}
                    onPaginationChange={setPagination2}
                    isLoading={isLoading2}
                    emptyMessage={{
                        title: isError2 ? error2?.name : "No applications received",
                        description: isError2 ? error2.message : "Provider offers will appear once applications begin.",
                        icon: "store-fill"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                          ...prev,
                          pageIndex: 0,
                        }));
                        setApplicationFilter((prev) => ({
                          ...prev,
                          period: [period],
                        }));
                    }}
                    filterTitle="Filter Applications"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Category",
                                    key: "category",
                                    options: categories?.categories.map(category => ({
                                        label: category.name,
                                        value: category.id,
                                    })) || [],
                                },
                                {
                                    label: "Subscription Plan",
                                    key: "subscription",
                                    options: [
                                        { label: "Free", value: "FREE" },
                                        { label: "Pro Monthly", value: "PRO_MONTHLY" },
                                        { label: "Pro Yearly", value: "PRO_ANNUAL" }
                                    ],
                                },
                                {
                                    label: "Rating",
                                    key: "rating",
                                    options: [
                                        { label: "4.0+", value: "4.0" },
                                        { label: "4.5+", value: "4.5" },
                                        { label: "4.8+", value: "4.8" },
                                    ],
                                },
                                {
                                    label: "Application Status",
                                    key: "status",
                                    options: [
                                        { label: "Pending", value: "PENDING" },
                                        { label: "Accepted", value: "ACCEPTED" },
                                        { label: "Rejected", value: "REJECTED" },
                                        { label: "Withdrawn", value: "WITHDRAWN" },
                                        { label: "Expired", value: "EXPIRED" },
                                    ],
                                },
                            ]}
                            values={applicationFilter}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setApplicationFilter(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setApplicationFilter({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Jobs;

