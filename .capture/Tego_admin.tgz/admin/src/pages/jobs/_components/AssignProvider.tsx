import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";

const AssignProvider = () => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const handleSubmit = () => {
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            setOpen(false);        // close the sheet
            setSuccessOpen(true)   // open success modal
        }, 1000)
    }

    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Provider Assigned"
                description={`Provider has been assigned successfully`}
                Icon={getIcon("edit-outline", { color: "#33ABF7" })}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="You are about to assign this job to the selected provider. This action will notify both parties and begin job execution."
                title="Assign Provider"
                onContinue={handleSubmit}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("edit-outline", { color: "black"})}
                        <span className="text-sm font-[500]">Assign Provider</span>
                    </div>
                )}
                Icon={getIcon("edit-outline", { color: "#33ABF7" })}
                buttonTitle="Assign Provider"
                buttonType="primary"
                loading={loading}
                style="min-w-[371px]"
            />
        </>
    )
}


export default AssignProvider;