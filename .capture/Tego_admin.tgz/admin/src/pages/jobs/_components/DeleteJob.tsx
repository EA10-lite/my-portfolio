import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { X } from "lucide-react";
import { deleteJob } from "../../../services/job-market.service";
import { useQueryClient } from "@tanstack/react-query";

const DeleteJob = ({ jobId } : { jobId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteJob(jobId);
            await queryClient.invalidateQueries({ queryKey: ["job-listings"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete job"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Job Deleted"
                description={`Job has been deleted successfully`}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This permanently removes the job from marketplace discovery and closes all related applications."
                title="Delete Job"
                onContinue={handleDelete}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("trash-fill", { color: "#D8232A"})}
                        <span className="text-sm font-[500] text-destructive">Delete Job</span>
                    </div>
                )}
                Icon={getIcon("trash-fill", { color: "#33ABF7" })}
                buttonTitle="Delete Job"
                buttonType="destructive"
                loading={loading}
                style="min-w-[371px]"
            />
        </>
    )
}


export default DeleteJob;