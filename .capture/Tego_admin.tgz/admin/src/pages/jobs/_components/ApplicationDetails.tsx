import React from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { formatCurrency } from "../../../utils/formatter";
import { Button } from "../../../components/ui/button";
import type { Application } from "../../../services/response-structure";

const ApplicationDetails = ({ application } : { application: Application }) => {
    const [open, setOpen] = React.useState<boolean>(false);

    return (
        <DetailsModal
            title="Application Details"
            TriggerButton={(
                <button className="text-primary underline text-sm font-[500]">
                    <span>View</span>
                </button>
            )}
            ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="primary"
                    >
                        Assign Provider
                    </Button>
                }
            open={open}
            onOpenChange={setOpen}
        >
            <div className="px-[16px] space-y-[20px]">
                <div className="flex items-center gap-[13px]">
                    <div className="avatar relative">
                        <img
                            src={application.provider.avatar ?? "/images/avatar.png"}
                            className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                            loading="lazy"
                        />
                    </div>
                    <div className="flex flex-col justify-between gap-[14px]">
                        <Text
                            type="h4"
                            className="font-[600] text-lg"
                            title={application.provider.name}
                        />
                        <Text
                            type="p"
                            className="font-[500] text-base text-black/60"
                            title={application.status}
                        />
                    </div>
                </div>

                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                        >
                            <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />
                        </button>
                        <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                            <ModalFieldItem
                                className="flex-row items-center justify-between"
                                label="Service"
                                value={application.category.name}
                            />
                            <ModalFieldItem
                                className="flex-row items-center justify-between"
                                label="Ratings"
                                value={application.provider.rating}
                            />
                            <ModalFieldItem
                                className="flex-row items-center justify-between"
                                label="Proposals"
                                value={application.proposed_price ? formatCurrency(application.proposed_price) : "-"}
                            />
                            <ModalFieldItem
                                className="flex-row items-center justify-between"
                                label="Estimated Completion"
                                value={application.estimated_time}
                            />
                        </div>
                    </div>
                </div>

            </div>
        </DetailsModal>
    )
}


export default ApplicationDetails;