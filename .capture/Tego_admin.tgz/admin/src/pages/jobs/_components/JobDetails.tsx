import React from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { ChevronDown, ChevronUp } from "lucide-react";
import { getIcon } from "../../../components/icons/lib";

const JobDetails = () => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["customer", "summary", "marketplace"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Job Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    {getIcon("store-outline", {color: "black"})}
                    <span className="text-sm font-[500]">View Job</span>
                </div>
            )}
            ActionButton={null}
            hasFooter={false}
            open={open}
            onOpenChange={setOpen}
        >
            <div className="px-[16px]">
                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("summary")}
                        >
                            <Text title="Job Summary" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["summary"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["summary"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Job ID"
                                    value={"JOB-0124"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Status"
                                    value={"Active"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Category"
                                    value={"Cleaning"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Posted"
                                    value={"Today"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Title"
                                    value={"House Painting"}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("customer")}
                        >
                            <Text title="Customer Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["customer"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["customer"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Customer's Name"
                                    value={"Daniel Okeke"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Phone"
                                    value={"07061326122"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Email"
                                    value={"danielOkeks@gmail.com"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Location"
                                    value={"Lekki, Lagos"}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("marketplace")}
                        >
                            <Text title="Marketplace Metrics" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["marketplace"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["marketplace"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Applications"
                                    value={"290"}
                                />
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </DetailsModal>
    )
}


export default JobDetails;