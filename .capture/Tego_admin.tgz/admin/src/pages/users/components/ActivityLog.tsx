import { useState } from "react";
import { DetailsModal, EmptyState, ModalFieldItem, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { LogOut } from "lucide-react";
import type { AdminUser } from "../../../services/response-structure";
import { getAdminActivityLog } from "../../../services/admin-users.service";
import { useQuery } from "@tanstack/react-query";
import { formatCreatedAt } from "../../../utils/formatter";
import type { ADMIN_ACTIONS } from "../../../services/types";

const ActivityLog = ({ admin }: { admin: AdminUser }) => {
    const [open, setOpen] = useState<boolean>(false);
    const { data, isLoading } = useQuery({
        queryKey: ['admins'],
        queryFn: () => getAdminActivityLog(admin.id),
        enabled: !!admin.id && open
    });
    return (
        <>
            <DetailsModal
                title="Activity Log"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("clock-outline")}
                        <span className="text-sm font-[500]">View Activity Log</span>
                    </div>
                )}
                ActionButton={null}
                open={open}
                onOpenChange={setOpen}
                hasFooter={false}
            >
                <div className="px-[16px] space-y-[20px]">

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                            >
                                <Text title="Account Information" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Email"
                                    value={admin.email}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Phone"
                                    value={admin.phone_number}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between capitalize"
                                    label="Account Status"
                                    content={(
                                        <div className="text-primary uppercase bg-[#C0C0C01A] px-[10.77px] h-[17px] flex items-center justify-center rounded-[3px]">
                                            <span className="text-[9px] font-[600]">{admin.status}</span>
                                        </div>
                                    )}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Date Created"
                                    value={formatCreatedAt(admin.created_at)}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Last Active"
                                    value={formatCreatedAt(admin.last_login)}
                                />
                            </div>
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                            >
                                <Text title="Activity Timeline" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                {!isLoading && data?.activity_log && data?.activity_log?.length > 0 ? data?.activity_log?.map((log, index) => (
                                    <Log
                                        key={index}
                                        type={log.action}
                                    />
                                )) : (
                                    <EmptyState
                                        emptyMessage={{
                                            title: "No Activity Yet",
                                            description: "This user hasn't logged in or performed any actions on the admin portal."
                                        }}
                                    />
                                )}
                            </div>
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}

const Log = ({
    type,
}: {
    type: ADMIN_ACTIONS;
}) => {
    const getIconType = (type: string) => {
        switch (type) {
            case "auth":
                return <LogOut className="text-primary" size={14} />
            case "account":
                return getIcon("user-outline", { color: "#33ABF7" })
            case "notification":
                return getIcon("bell-outline", { color: "#33ABF7" })
        }
    }

    const getTitle = () => {
        return "";
    }
    return (
        <div className="flex items-center gap-[13px] py-[16px]">
            <div className="w-[40px] h-[40px] rounded-full bg-[#F8F8F8] flex items-center justify-center">
                {getIconType(type)}
            </div>

            <div className="flex flex-col gap-[8px]">
                <Text title={getTitle()} className="text-sm font-semibold" />
                <div className="flex items-center gap-[6px]">
                    <Text title="Today" className="text-[10px] font-[400] opacity-50" />
                    <span className="w-[5px] h-[5px] rounded-full bg-success" />
                    <Text title="10:32 AM" className="text-[10px] font-[400] opacity-50" />
                </div>
            </div>
        </div>
    )
}


export default ActivityLog;