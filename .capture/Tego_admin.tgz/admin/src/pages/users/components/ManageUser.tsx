import React, { useState } from "react";
import { Checkbox, DetailsModal, FormField, SuccessModal, Text } from "../../../components";
import { CircleQuestionMark, Loader2, Plus, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Formik, type FormikProps } from "formik";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { createAdmin, updateAdmin, type AdminUser as AdminUserForm } from "../../../services/admin-users.service";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { createAdminUserValidation } from "../../../utils/validation";
import type { AdminUser } from "../../../services/response-structure";

const ManageUser = ({ type = "add", admin }: { type: "add" | "edit", admin?: AdminUser }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);
    const [confirmModalOpen, setConfirmModalOpen] = React.useState<boolean>(false);
    const [successModal, setSuccessModal] = React.useState<boolean>(false);
    const [loading, setLoading] = useState(false);

    const [confirmationValues, setConfirmationValues] = useState<AdminUserForm | null>(null);
    const handleConfirm = async () => {
        try {
            setLoading(true);
            if (type === "edit" && admin?.id && confirmationValues) {
                await updateAdmin(admin?.id, confirmationValues);
                await queryClient.invalidateQueries({ queryKey: ["admins"] });
                setConfirmModalOpen(false);
                setSuccessModal(true);
                setConfirmationValues(null);
                setOpen(false);
            }
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to update user"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (values: AdminUserForm) => {
        try {
            if (type === "add") {
                setLoading(true);
                await createAdmin(values);
                setSuccessModal(true);
                setOpen(false);
                await queryClient.invalidateQueries({ queryKey: ["admins"] })
            }
            else if (type === "edit" && admin?.id) {
                setConfirmModalOpen(true);
                setConfirmationValues(values);
                setOpen(false);
            }
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to create user"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                title={type === "add" ? "New User Created" : "Changes Saved"}
                description={type === "add"
                    ? "The new user has been created successfully."
                    : "The user's information has been updated successfully."
                }
                Icon={getIcon("check", { color: "#33ABF7" })}
                open={successModal}
                onOpenChange={() => setSuccessModal(false)}
                style="min-w-[317px]"
            />

            {confirmModalOpen && (
                <ConfirmationModal
                    open={confirmModalOpen && type === "edit"}
                    onOpenChange={setConfirmModalOpen}
                    description="Are you sure you want to save these changes? The user's information will be updated."
                    title="Save Changes"
                    onContinue={handleConfirm}
                    buttonTitle="Save Changes"
                    TriggerButton={null}
                    Icon={<CircleQuestionMark size={18} color="#33ABF7" />}
                    loading={loading}
                />
            )}
            <Formik<AdminUserForm>
                initialValues={{
                    full_name: admin ? `${admin.first_name} ${admin.last_name}` : "",
                    email: admin?.email ?? "",
                    role: admin?.role ?? "SUPER_ADMIN",
                    phone_number: admin?.phone_number ?? "",
                    temporary_password: "",
                    confirm_password: "",
                    enable_mfa: admin?.mfa_enabled ?? false,
                    status: admin?.status ?? "active",

                }}
                onSubmit={handleSubmit}
                validationSchema={createAdminUserValidation(type)}
            >
                {({ values, setFieldValue, submitForm }: FormikProps<AdminUserForm>) => (
                    <DetailsModal
                        title={type === "add" ? "Add User" : "Edit User"}
                        TriggerButton={type === "add" ? (
                            <Button
                                size="lg"
                                className="rounded-full flex items-center gap-[4px] bg-primary hover:bg-primary"
                            >
                                <Plus />
                                <span className="font-[600] text-[13px]">{type === "add" ? "Add User" : "Edit User"}</span>
                            </Button>
                        ) : (
                            <div className="flex items-center gap-[6px]">
                                {getIcon("pencil-edit")}
                                <span className="text-sm font-[500]">Edit</span>
                            </div>
                        )}
                        ActionButton={(
                            <Button
                                className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                                onClick={submitForm}
                                disabled={loading}
                            >
                                {loading ? <Loader2 className="animate-spin" /> : (
                                    <span>{type === "add" ? "Create User" : "Save Changes"}</span>
                                )}
                            </Button>
                        )}
                        open={open}
                        onOpenChange={setOpen}
                    >
                        <div className="px-[16px] space-y-[20px]">
                            <div className="flex flex-col gap-[18px]">
                                {/* Enable MFA (Optional) */}
                                <div className="bg-[#F9F9F9] rounded-[6px]">
                                    <button className="flex items-center justify-between w-full p-[16px]">
                                        <Text title="Enable MFA (Optional)" className="text-[13px] font-[600]" type="h5" />
                                    </button>
                                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                        {[
                                            { label: "Yes", value: true },
                                            { label: "No", value: false },
                                        ].map((option, index) => (
                                            <Checkbox
                                                key={index}
                                                label={option.label}
                                                checked={values.enable_mfa === option.value}
                                                onChange={() => setFieldValue("enable_mfa", option.value)}
                                                type="radio"
                                            />
                                        ))}
                                    </div>
                                </div>
                                {/* Role */}
                                <div className="bg-[#F9F9F9] rounded-[6px]">
                                    <button className="flex items-center justify-between w-full p-[16px]">
                                        <Text title="Role" className="text-[13px] font-[600]" type="h5" />
                                    </button>
                                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                        {[
                                            { label: "Super Admin", value: "SUPER_ADMIN" },
                                            { label: "Support Admin", value: "SUPPORT_ADMIN" },
                                        ].map((option) => (
                                            <Checkbox
                                                key={option.value}
                                                label={option.label}
                                                checked={values.role === option.value}
                                                onChange={() => setFieldValue("role", option.value)}
                                                type="radio"
                                            />
                                        ))}
                                    </div>
                                </div>
                                {/* Status */}
                                <div className="bg-[#F9F9F9] rounded-[6px]">
                                    <button className="flex items-center justify-between w-full p-[16px]">
                                        <Text title="Status" className="text-[13px] font-[600]" type="h5" />
                                    </button>
                                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                        {[
                                            { label: "Active", value: "active" },
                                            { label: "Inactive", value: "inactive" },
                                        ].map((option) => (
                                            <Checkbox
                                                key={option.value}
                                                label={option.label}
                                                checked={values.status === option.value}
                                                onChange={() => setFieldValue("status", option.value)}
                                                type="radio"
                                            />
                                        ))}
                                    </div>
                                </div>

                                {/* User Details */}
                                <div className="bg-[#F9F9F9] rounded-[6px]">
                                    <button className="flex items-center justify-between w-full p-[16px]">
                                        <Text title="User Information" className="text-[13px] font-[600]" type="h5" />
                                    </button>
                                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                        <FormField name="full_name" placeholder="Full Name" className="shadow-none" />
                                        <FormField name="email" placeholder="Email" className="shadow-none" />
                                        <FormField name="phone_number" placeholder="Phone Number" className="shadow-none" />
                                        {type !== "edit" && <FormField name="temporary_password" placeholder="Password" className="shadow-none" />}
                                        {type !== "edit" && <FormField name="confirm_password" placeholder="Confirm Password" className="shadow-none" />}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </DetailsModal>
                )}
            </Formik>
        </>
    );
};

export default ManageUser;