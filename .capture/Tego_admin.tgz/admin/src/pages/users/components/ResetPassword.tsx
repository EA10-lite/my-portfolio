import { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Loader2, X } from "lucide-react";
import { Dialog, DialogContent, DialogTrigger } from "../../../components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "../../../components/ui/radio-group";
import Checkbox from "../../../components/main/Checkbox";
import { Button } from "../../../components/ui/button";
import FormInput from "../../../components/forms/FormInput";
import type { AdminUser } from "../../../services/response-structure";
import { resetAdminPAssword } from "../../../services/admin-users.service";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";

const ResetPassword = ({ admin } : { admin: AdminUser }) => {
    const [open, setOpen] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const [loading, setLoading] = useState(false);

    // Multi-step form state
    const [step, setStep] = useState<'method' | 'manual'>('method');
    const [method, setMethod] = useState<'auto' | 'manual'>('auto');
    const [emailUser, setEmailUser] = useState(true);
    const [tempPassword, setTempPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    const handleProceed = () => {
        if (step === 'method' && method === 'manual') {
            setStep('manual');
        }
        else if (step === "manual") {
            handleSubmit(tempPassword, confirmPassword);
        }
        else {
            autoGeneratePassword();
        }
    }

    const handleOpenChange = (val: boolean) => {
        setOpen(val);
        if (!val) {
            setTimeout(() => {
                setStep('method');
                setMethod('auto');
                setEmailUser(true);
                setTempPassword("");
                setConfirmPassword("");
            }, 200); // delay reset to avoid seeing it change while animating out
        }
    }


    const autoGeneratePassword = async () => {
        try {
            setLoading(true);
            await resetAdminPAssword(admin.id, { mode: "auto", email_password: true })
            setOpen(false)
            setSuccessOpen(true);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to generate admin password"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    const handleSubmit = async (password: string, confirm_password: string) => {
        try {
            setLoading(true);
            await resetAdminPAssword(admin.id, {
                mode: "manual",
                email_password: true,
                password,
                confirm_password,
            })
            setOpen(false)
            setSuccessOpen(true);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to reset admin password"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => { setSuccessOpen(false); setOpen(false) }}
                title="Password generated"
                description="Temporary password has been generated and sent to user"
                Icon={getIcon("check", { color: "#33ABF7" })}
            />

            <Dialog open={open} onOpenChange={handleOpenChange}>
                <DialogTrigger asChild>
                    <div className="flex items-center gap-[6px] cursor-pointer">
                        {getIcon("timer")}
                        <span className="text-sm font-[500]">Reset Password</span>
                    </div>
                </DialogTrigger>
                <DialogContent
                    className="
                        bg-white
                        rounded-[10px]
                        border-none
                        shadow-none
                        overflow-hidden
                        [&>button.absolute]:hidden
                        z-[99]
                        p-6
                        w-full
                        max-w-[457px]
                        mx-auto"
                >
                    <div className="flex items-center justify-between mb-[30px]">
                        <h2 className="text-[18px] font-bold text-black">
                            {step === 'method' ? 'Reset User Password' : 'Manually set a new password'}
                        </h2>
                        <button onClick={() => setOpen(false)} className="text-[#344054] hover:opacity-70 transition-opacity">
                            <X size={20} />
                        </button>
                    </div>

                    <div className="mb-[40px]">
                        {step === 'method' ? (
                            <div className="space-y-6">
                                <RadioGroup value={method} onValueChange={(val: 'auto' | 'manual') => setMethod(val)} className="flex flex-col gap-6">
                                    <div className="flex items-center gap-3 cursor-pointer" onClick={() => setMethod('auto')}>
                                        <RadioGroupItem value="auto" id="auto" className={method === 'auto' ? "border-[#33ABF7] text-[#33ABF7]" : "border-[#E4E7EC]"} />
                                        <label htmlFor="auto" className="text-sm font-medium text-[#344054] cursor-pointer">Auto-generate a temporary password</label>
                                    </div>
                                    <div className="flex items-center gap-3 cursor-pointer" onClick={() => setMethod('manual')}>
                                        <RadioGroupItem value="manual" id="manual" className={method === 'manual' ? "border-[#33ABF7] text-[#33ABF7]" : "border-[#E4E7EC]"} />
                                        <label htmlFor="manual" className="text-sm font-medium text-[#344054] cursor-pointer">Manually set a new password</label>
                                    </div>
                                </RadioGroup>

                                <div className="flex items-center gap-[10px] mt-8 cursor-pointer" onClick={() => setEmailUser(!emailUser)}>
                                    <Checkbox checked={emailUser} onChange={() => setEmailUser(!emailUser)} label="Email password to user" />
                                </div>
                            </div>
                        ) : (
                            <div className="space-y-[20px]">
                                <FormInput
                                    name="tempPassword"
                                    type="password"
                                    placeholder="Temporary Password"
                                    value={tempPassword}
                                    handleChange={(e) => setTempPassword(e.target.value)}
                                // className="shadow-none"
                                />
                                <FormInput
                                    name="confirmPassword"
                                    type="password"
                                    placeholder="Confirm Password"
                                    value={confirmPassword}
                                    handleChange={(e) => setConfirmPassword(e.target.value)}
                                // className="shadow-none"
                                />
                                <div className="flex items-center gap-[10px] mt-6 cursor-pointer" onClick={() => setEmailUser(!emailUser)}>
                                    <Checkbox checked={emailUser} onChange={() => setEmailUser(!emailUser)} label="Email password to user" />
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="flex items-center justify-between gap-[16px]">
                        <Button
                            variant="muted"
                            className="h-[50px] w-full max-w-[169px] rounded-[50px]"
                            onClick={() => handleOpenChange(false)}
                        >
                            Cancel
                        </Button>

                        <Button
                            className="h-[50px] w-full max-w-[169px] rounded-[50px] bg-[#33ABF7] hover:bg-[#209bf0] text-white"
                            onClick={handleProceed}
                            disabled={loading || (step === 'manual' && (!tempPassword || tempPassword !== confirmPassword))}
                        >
                            {loading ? <Loader2 className="animate-spin" /> : <span>Yes, Proceed</span>}
                        </Button>
                    </div>
                </DialogContent>
            </Dialog>
        </>
    )
}

export default ResetPassword;