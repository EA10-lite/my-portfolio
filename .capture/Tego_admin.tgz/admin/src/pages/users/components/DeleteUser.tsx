import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { deleteAdmin } from "../../../services/admin-users.service";
import { useQueryClient } from "@tanstack/react-query";
import { getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { X } from "lucide-react";

const DeleteUser = ({ adminId }: { adminId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteAdmin(adminId);
            await queryClient.invalidateQueries({ queryKey: ["admins"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete admin account"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="User Deleted"
                description={`The user has been deleted successfully.`}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="Are you sure you want to delete this user? This action cannot be undone."
                title="Delete User"
                onContinue={handleDelete}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("trash-fill", { color: "#D8232A" })}
                        <span className="text-sm font-[500] text-destructive">Delete</span>
                    </div>
                )}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
                buttonTitle="Delete"
                buttonType="destructive"
                loading={loading}
            />
        </>
    )
}


export default DeleteUser;