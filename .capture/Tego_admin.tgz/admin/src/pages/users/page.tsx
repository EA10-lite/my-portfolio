

import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt } from "../../utils/formatter";
import DeleteUser from "./components/DeleteUser";
import ActivityLog from "./components/ActivityLog";
import ResetPassword from "./components/ResetPassword";
import ManageUser from "./components/ManageUser";
import { getAdmins } from "../../services/admin-users.service";
import { useQuery } from "@tanstack/react-query";
import type { AdminUser } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const columns: ColumnDef<AdminUser>[] = [
    {
        accessorKey: "full_name",
        header: "Name",
        cell: ({ row }) => (
            <span className="capitalize">{`${row.original.first_name} ${row.original.last_name}`}</span>
        )
    },
    {
        accessorKey: "email",
        header: "Email",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("email")}</span>
        )
    },
    {
        accessorKey: "role",
        header: "Role",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("role")}</span>
        )
    },
    {
        accessorKey: "last_login",
        filterFn: dateFilterFn,
        header: "Last Login",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("last_login") ? formatCreatedAt(row.getValue("last_login")) : "-"}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "active") badgeVariant = "success";
            if (status.toLowerCase() === "inactive") badgeVariant = "destructive";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "success" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <TableAction
                    items={[
                        {
                            label: "Edit User",
                            content: <ManageUser type="edit" admin={row.original} />
                        },
                        {
                            label: "Reset Password",
                            content: <ResetPassword admin={row.original} />
                        },
                        {
                            label: "View Activity",
                            content: <ActivityLog admin={row.original} />
                        },
                        {
                            label: "Delete User",
                            content: <DeleteUser adminId={row.original.id} />
                        }
                    ]}
                />
            </div>
        )
    }
]

const AdminUsers = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const { data, isLoading, isError, error, } = useQuery({
        queryKey: [
            'admins',
            pagination.pageIndex,
            pagination.pageSize,
            search,
            filters
        ],
        queryFn: () => getAdmins({
            page: pagination.pageIndex + 1,
            limit: pagination.pageSize,
            search,
            ...filters,
        })
    });

    return (
        <div className="categories space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="User Management"
                    description="Manage administrator accounts, assign permissions, and control access to the Tego Admin Portal."
                    metrics={[]}
                    hasDownload={false}
                    onDownload={() => { }}
                    triggerBtn={<ManageUser type="add" />}
                />
            </div>
            <div className="page-body space-y-[20px]">
                <ReusableTable
                    title="Users"
                    data={isError ? [] : data?.admins || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.pagination.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error?.name : "No users found",
                        description: isError ? error.message : "Users will appear here as they are added to the platform.",
                        icon: "ticket-outline",
                    }}
                    filterTitle="Filter Users"
                    hasDateFilter={false}
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value: "active" },
                                        { label: "Inactive", value: "inactive" },
                                        { label: "Suspended", value: "suspended" }
                                    ],
                                },
                                {
                                    label: "Role",
                                    key: "role",
                                    options: [
                                        { label: "Admin", value: "ADMIN" },
                                        { label: "Support Admin", value: "SUPPORT_ADMIN" },
                                        { label: "Super Admin", value: "SUPER_ADMIN" }
                                    ],
                                },
                            ]}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            values={filters}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default AdminUsers;

