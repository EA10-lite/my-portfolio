import { Formik } from "formik";
import { login as loginService } from "../../../services/auth.service";
import { toast } from "sonner";
import { loginValidation } from "../../../utils/validation";
import { FormField, Submit } from "../../../components";
import { useAdminStore } from "../../../store/adminStore";
import { Check, X } from "lucide-react";
import { getErrorMessage } from "../../../utils/formatter";


const Login = () => {
    const { login } = useAdminStore();
    const handleSubmit = async (values: { phoneNumber: string; password: string }) => {
        try {
            const response = await loginService({
                ...values,
                "device_name": "Admin Console",
                "device_ip": "127.0.0.1",
                "location": {
                    "longitude": 3.3792,
                    "latitude": 6.5244,
                    "state": "Lagos",
                    "country": "Nigeria"
                }
            });
            login(response);
            toast.success("Login successful", {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <Check className="size-4 text-primary" />
                    </div>
                )
            })
        } catch (error) {
            toast.error(getErrorMessage(error, "Login Failed"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        }
    }

    return (
        <div className="login min-h-screen flex items-center justify-center app-background">
            <div className="form bg-white border-[0.5px] border-primary/10 w-[562px] rounded-[10px] px-4 py-[120px]">

                <div className="w-[71%] mx-auto space-y-[30px]">
                    <div className="gap-4  max-w-[295px] mx-auto flex flex-col items-center justify-center">
                        <div className="mx-auto">
                            <img src="/images/icon.svg" alt="Tego" />
                        </div>
                        <div className="text-center">
                            <p className="text-black/50 text-sm font-[500] tracking-[-0.24px]">
                                Manage bookings, providers, and platform operations in one place.
                            </p>
                        </div>
                    </div>

                    <div className="form-container w-full">
                        <Formik
                            initialValues={{ phoneNumber: "09088766543", password: "qwerty12345" }}
                            onSubmit={handleSubmit}
                            validationSchema={loginValidation}
                        >
                            {({ isSubmitting, values }) => (
                                <div className="form-content w-full space-y-[26px]">
                                    <div className="space-y-[20px]">
                                        <FormField
                                            name="phoneNumber"
                                            placeholder="Phone number:"
                                            type="text"
                                            disabled={isSubmitting}
                                        />
                                        <FormField
                                            name="password"
                                            placeholder="Password"
                                            type="password"
                                            disabled={isSubmitting}
                                        />
                                    </div>

                                    <div className="">
                                        <Submit
                                            title="Login"
                                            loading={isSubmitting}
                                            disabled={!values.phoneNumber || !values.password}
                                        />
                                    </div>
                                </div>
                            )}
                        </Formik>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login;