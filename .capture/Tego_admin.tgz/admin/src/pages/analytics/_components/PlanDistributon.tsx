import { Label, Pie, PieChart } from "recharts";

import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card";

import {
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
    type ChartConfig,
} from "../../../components/ui/chart";

import { EmptyState } from "../../../components";
import type { PlanDistribution as PlanDistributionInterface } from "../../../services/response-structure";

interface PlanDistributionProps {
    distribution?: PlanDistributionInterface;
}

const FILL_COLORS = [
    "#33ABF7",   // Free - 100%
    "#33ABF733", // Pro Monthly - 20%
    "#33ABF799", // Pro Annual - 60%
];

const chartConfig = {
    free: {
        label: "Free",
        color: "#33ABF7",
    },
    pro_monthly: {
        label: "Pro Monthly",
        color: "#33ABF7",
    },
    pro_annual: {
        label: "Pro Annual",
        color: "#33ABF7",
    },
} satisfies ChartConfig;

const PlanDistribution = ({
    distribution,
}: PlanDistributionProps) => {
    const chartData = distribution
        ? [
              {
                  plan: "Free",
                  key: "FREE",
                  count: distribution.FREE,
                  percentage: distribution.percentages.FREE,
                  fill: FILL_COLORS[0],
              },
              {
                  plan: "Pro Monthly",
                  key: "PRO_MONTHLY",
                  count: distribution.PRO_MONTHLY,
                  percentage: distribution.percentages.PRO_MONTHLY,
                  fill: FILL_COLORS[1],
              },
              {
                  plan: "Pro Annual",
                  key: "PRO_ANNUAL",
                  count: distribution.PRO_ANNUAL,
                  percentage: distribution.percentages.PRO_ANNUAL,
                  fill: FILL_COLORS[2],
              },
          ]
        : [];

    const topPlan = chartData.reduce(
        (top, item) => (item.count > top.count ? item : top),
        chartData[0]
    );

    return (
        <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] shadow-none">
            <CardHeader className="items-center pb-0 px-0">
                <CardTitle className="text-black">
                    Plan Distribution
                </CardTitle>
            </CardHeader>

            <CardContent className="flex-1 pb-0">
                {chartData.length > 0 ? (
                    <ChartContainer
                        config={chartConfig}
                        className="mx-auto aspect-square max-h-[250px]"
                    >
                        <PieChart>
                            <ChartTooltip
                                cursor={false}
                                content={<ChartTooltipContent hideLabel />}
                            />

                            <Pie
                                data={chartData}
                                dataKey="count"
                                nameKey="plan"
                                innerRadius={75}
                                strokeWidth={5}
                                cornerRadius={8}
                                paddingAngle={4}
                            >
                                <Label
                                    content={({ viewBox }) => {
                                        if (
                                            viewBox &&
                                            "cx" in viewBox &&
                                            "cy" in viewBox &&
                                            topPlan
                                        ) {
                                            return (
                                                <text
                                                    x={viewBox.cx}
                                                    y={viewBox.cy}
                                                    textAnchor="middle"
                                                    dominantBaseline="middle"
                                                >
                                                    <tspan
                                                        x={viewBox.cx}
                                                        y={viewBox.cy}
                                                        className="fill-black text-lg font-semibold"
                                                    >
                                                        {topPlan.plan}
                                                    </tspan>

                                                    <tspan
                                                        x={viewBox.cx}
                                                        y={(viewBox.cy || 0) + 24}
                                                        className="fill-black"
                                                    >
                                                        {topPlan.percentage}%
                                                    </tspan>
                                                </text>
                                            );
                                        }

                                        return null;
                                    }}
                                />
                            </Pie>
                        </PieChart>
                    </ChartContainer>
                ) : (
                    <EmptyState
                        emptyMessage={{
                            title: "No analytics available",
                            description:
                                "Data will appear after users engage with the platform.",
                        }}
                    />
                )}
            </CardContent>

            {chartData.length > 0 && (
                <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
                    {chartData.map((item) => (
                        <div
                            key={item.key}
                            className="flex items-center gap-2 leading-none font-medium"
                        >
                            <div
                                className="w-2.5 h-2.5 rounded-full"
                                style={{
                                    background: item.fill,
                                }}
                            />

                            <span>{item.plan}</span>
                        </div>
                    ))}
                </CardFooter>
            )}
        </Card>
    );
};

export default PlanDistribution;