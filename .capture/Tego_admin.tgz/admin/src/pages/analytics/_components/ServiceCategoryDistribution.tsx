import { Label, Pie, PieChart } from "recharts";

import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card";

import {
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
    type ChartConfig,
} from "../../../components/ui/chart";

import { EmptyState } from "../../../components";
import type { CategoryDistributionItem } from "../../../services/response-structure";


interface ServiceCategoryDistributionProps {
    distribution?: CategoryDistributionItem[];
}

const FILL_COLORS = [
    "#FFCC00",
    "#988AFC",
    "#33ABF7",
    "#34C759",
    "#FFAE4C",
];

const chartConfig = {
    cleaning: {
        label: "Cleaning",
        color: "#FFCC00",
    },
    electrical: {
        label: "Electrical",
        color: "#988AFC",
    },
    laundry: {
        label: "Laundry",
        color: "#33ABF7",
    },
    carpentry: {
        label: "Carpentry",
        color: "#34C759",
    },
    plumbing: {
        label: "Plumbing",
        color: "#FFAE4C",
    },
} satisfies ChartConfig;

const ServiceCategoryDistribution = ({
    distribution,
}: ServiceCategoryDistributionProps) => {
    const chartData =
        distribution?.map((item, index) => ({
            ...item,
            name: item.category,
            count: item.jobs,
            percentage: item.jobs_pct,
            fill: FILL_COLORS[index % FILL_COLORS.length],
        })) ?? [];

    const topCategory = chartData.reduce<
        (typeof chartData)[number] | undefined
    >(
        (top, item) => (!top || item.count > top.count ? item : top),
        undefined
    );

    return (
        <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] shadow-none">
            <CardHeader className="items-center pb-0 px-0">
                <CardTitle className="text-black">
                    Service Category Distribution
                </CardTitle>
            </CardHeader>

            <CardContent className="flex-1 pb-0">
                {chartData.length > 0 ? (
                    <ChartContainer
                        config={chartConfig}
                        className="mx-auto aspect-square max-h-[250px]"
                    >
                        <PieChart>
                            <ChartTooltip
                                cursor={false}
                                content={<ChartTooltipContent hideLabel />}
                            />

                            <Pie
                                data={chartData}
                                dataKey="count"
                                nameKey="name"
                                innerRadius={75}
                                strokeWidth={5}
                                cornerRadius={8}
                                paddingAngle={4}
                            >
                                <Label
                                    content={({ viewBox }) => {
                                        if (
                                            viewBox &&
                                            "cx" in viewBox &&
                                            "cy" in viewBox &&
                                            topCategory
                                        ) {
                                            return (
                                                <text
                                                    x={viewBox.cx}
                                                    y={viewBox.cy}
                                                    textAnchor="middle"
                                                    dominantBaseline="middle"
                                                >
                                                    <tspan
                                                        x={viewBox.cx}
                                                        y={viewBox.cy}
                                                        className="fill-black text-lg font-semibold"
                                                    >
                                                        {topCategory.name}
                                                    </tspan>

                                                    <tspan
                                                        x={viewBox.cx}
                                                        y={(viewBox.cy || 0) + 24}
                                                        className="fill-black"
                                                    >
                                                        {topCategory.percentage}%
                                                    </tspan>
                                                </text>
                                            );
                                        }

                                        return null;
                                    }}
                                />
                            </Pie>
                        </PieChart>
                    </ChartContainer>
                ) : (
                    <EmptyState
                        emptyMessage={{
                            title: "No analytics available",
                            description:
                                "Data will appear after users engage with the platform.",
                        }}
                    />
                )}
            </CardContent>

            {chartData.length > 0 && (
                <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
                    {chartData.map((item) => (
                        <div
                            key={item.id}
                            className="flex items-center gap-2 leading-none font-medium"
                        >
                            <div
                                className="w-2.5 h-2.5 rounded-full"
                                style={{
                                    background: item.fill,
                                }}
                            />

                            <span>{item.name}</span>
                        </div>
                    ))}
                </CardFooter>
            )}
        </Card>
    );
};

export default ServiceCategoryDistribution;