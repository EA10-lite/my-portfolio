
import type { ColumnDef } from "@tanstack/react-table";
import { ReusableTable } from "../../components";
import { PageHeader } from "../../components/shared";
import { Link } from "react-router-dom";
import PlanDistribution from "./_components/PlanDistributon";
import ServiceCategoryDistribution from "./_components/ServiceCategoryDistribution";
import RevenueGrowth from "./_components/RevenueGrowth";
import { dateFilterFn } from "../../utils/formatter";
import { useQueries } from "@tanstack/react-query";
import { getCategoryDistribution, getDashboardStats, getTopProviders } from "../../services/dashboard.service";
import type { TopProvider } from "../../services/response-structure";
import { Skeleton } from "../../components/ui/skeleton";
import { getSubscriptionStats } from "../../services/subscription.service";
import { useState } from "react";
import type { RANGE } from "../../services/types";

const columns: ColumnDef<TopProvider>[] = [
    {
        accessorKey: "firstName",
        header: "Provider",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.name ?? "-"}</span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.category ?? "-"}</span>
        )
    },
    {
        accessorKey: "rating",
        header: "Rating",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.rating ?? "-"}</span>
        )
    },
    {
        accessorKey: "completedJobs",
        header: "Completed Jobs",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.completed_jobs}</span>
        )
    },
    {
        accessorKey: "subscription",
        header: "Subscription",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.subscription}</span>
        )
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="">
                <Link to={`/providers/${row.original.id}`} className="underline text-primary text-sm font-[500]">
                    View Profile
                </Link>
            </div>
        )
    },
    {
        accessorKey: "createdAt",
        header: () => null,
        cell: () => null,
        filterFn: dateFilterFn,
        enableHiding: true,
    }
]

const Analytics = () => {
    const [dateFilter, setDateFilter] = useState<RANGE>("week");
    const [
        {
          data: stat,
          isLoading: isStatLoading,
        },
        {
            data: providers,
            isLoading,
            isError,
            error,
        },
        {
            data: subscription,
            isLoading: isSubscriptionLoading
        },
        {
            data: categoryDistribution,
            isLoading: isCategoryDistributionLoading
        },
      ] = useQueries({
        queries: [
          {
            queryKey: ["analytics-data"],
            queryFn: ()=> getDashboardStats(),
          },
          {
            queryKey: ["top-providers"],
            queryFn: ()=> getTopProviders(),
          },
          {
            queryKey: ["subscription-data", dateFilter],
            queryFn: () => getSubscriptionStats(dateFilter),
          },
          {
            queryKey: ["category-distribution"],
            queryFn: () => getCategoryDistribution(),
          },
        ]
    })
    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Report & Analyticss"
                    description="Monitor platform growth, subscription performance, provider activity, and marketplace trends."
                    metrics={[
                        {
                            label: "Total Customers",
                            value: stat?.total_customers.value ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.total_customers.change_pct ?? 0,
                            iconType: "customer-fill"
                        },
                        {
                            label: "Total Providers",
                            value: stat?.total_providers.value ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.total_providers.change_pct ?? 0,
                            iconType: "provider-fill"
                        },
                        {
                            label: "Active Jobs",
                            value: stat?.active_jobs.value ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.active_jobs.change_pct ?? 0,
                            iconType: "store-fill"
                        },
                        {
                            label: "Total Revenue",
                            value: stat?.total_revenue.value ?? 0,
                            filter: "All Time",
                            percentageIncrease: stat?.total_revenue.change_pct ?? 0,
                            iconType: "card-fill"
                        },
                    ]}
                    hasDownload={true}
                    onDownload={()=> {}}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body space-y-[20px]">
                {isSubscriptionLoading
                    ? <ChartSkeleton />
                        : <RevenueGrowth
                            dateFilter={dateFilter}
                            onDateChange={setDateFilter}
                            data={subscription?.growth}
                        />
                }
                {isCategoryDistributionLoading
                    ? <ChartSkeleton />
                    : (
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                            <PlanDistribution distribution={subscription?.plan_distribution} />
                            <ServiceCategoryDistribution distribution={categoryDistribution?.categories} />
                        </div>
                    )
                }
                <ReusableTable
                    title="Top Providers"
                    data={isError ? [] : providers?.providers || []}
                    columns={columns}
                    manualPagination={false}
                    pageCount={0}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No data collected yet",
                        description: isError ? error.message : "Reports will be generated when marketplace activity begins.",
                        icon: "user-outline"
                    }}
                    hasDateFilter={false}
                />
            </div>
        </div>
    )
}

const ChartSkeleton = () => {
    return (
      <div className="border-[0.5px] border-primary/8 bg-secondary-foreground rounded-sm p-4 space-y-4">
        <Skeleton className="h-5 w-40 bg-primary/10" />
        <Skeleton className="h-64 w-full bg-primary/10" />
      </div>
    );
};

export default Analytics;

