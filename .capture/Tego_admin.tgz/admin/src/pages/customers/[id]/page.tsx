import { ReusableTable, Text } from "../../../components";
import { Button } from "../../../components/ui/button";
import { useState } from "react";
import { Badge } from "../../../components/ui/badge";
import type { ColumnDef } from "@tanstack/react-table";
import { formatCreatedAt, formatCurrency } from "../../../utils/formatter";
import { useParams } from "react-router-dom";
import { getCustomerDetails } from "../../../services/users.service";
import { useQuery } from "@tanstack/react-query";
import type { JobRequest, Order, ServiceBooking } from "../../../services/response-structure";

const columns: ColumnDef<ServiceBooking>[] = [
    {
        accessorKey: "service",
        header: "Service",
        cell: ({ row }) => (
            <span className="text-sm">{row.getValue("service")}</span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("category")}</span>
        )
    },
    {
        accessorKey: "price",
        header: "Price",
        cell: ({ row }) => (
            <span className="capitalize">{formatCurrency(row.getValue("price"))}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "active") badgeVariant = "primary";
            if (status.toLowerCase() === "completed") badgeVariant = "success";
            if (status.toLowerCase() === "cancelled") badgeVariant = "destructive";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    }
]
const jobColumns: ColumnDef<JobRequest>[] = [
    {
        accessorKey: "title",
        header: "Title",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.title}</span>
        )
    },
    {
        accessorKey: "description",
        header: "Description",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.description}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "accepted" || status === "in_progress") badgeVariant = "primary";
            if (status === "completed" || status === "delivered") badgeVariant = "success";
            if (status === "pending") badgeVariant = "pending";
            if (status === "cancelled") badgeVariant = "destructive";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status.replaceAll("_", " ")}
                </Badge>
            )
        }
    }
]
const orderColumns: ColumnDef<Order>[] = [
    {
        accessorKey: "provider",
        header: "Provider",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.provider}</span>
        )
    },
    {
        accessorKey: "created",
        header: "Date Created",
        cell: ({ row }) => (
            <span className="capitalize">{formatCreatedAt(row.original.created_at)}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "accepted" || status === "in_progress") badgeVariant = "primary";
            if (status === "completed" || status === "delivered") badgeVariant = "success";
            if (status === "pending" || status === "completion_requested") badgeVariant = "pending";
            if (status === "cancelled") badgeVariant = "destructive";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status.replaceAll("_", " ")}
                </Badge>
            )
        }
    }
]

const CustomerDetails = () => {
    const [activeTab, setActiveTab] = useState("services");
    const { id } = useParams();

    const {
        data,
        isLoading,
        isError,
        error,
    } = useQuery({
        queryKey: ["customer-details", id],
        queryFn: () => getCustomerDetails(id!.toString()),
        enabled: !!id,
    });

    if (isLoading) {
        return (
            <div className="min-h-[60vh] flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                    <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                    <Text
                        title="Loading provider details..."
                        type="p"
                        className="text-sm text-black/60"
                    />
                </div>
            </div>
        );
    }

    if (isError) {
        return (
            <div className="min-h-[60vh] flex items-center justify-center px-6">
                <div className="flex flex-col items-center text-center gap-3 max-w-md">
                    <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center">
                        <span className="text-red-500 text-xl">!</span>
                    </div>
                    <Text
                        title="Unable to load provider details"
                        type="h4"
                        className="font-semibold text-lg"
                    />
                    <Text
                        title={
                            error instanceof Error
                                ? error.message
                                : "Something went wrong while loading this provider. Please try again."
                        }
                        type="p"
                        className="text-sm text-black/60"
                    />
                    <Button
                        variant="primary"
                        onClick={() => window.location.reload()}
                        className="mt-2"
                    >
                        Try Again
                    </Button>
                </div>
            </div>
        );
    }
    return (
        <div className="space-y-[20px] px-6">
            {/* Breadcrumsb */}
            {/* Profile Heading */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[48px]">
                <div className="flex items-center gap-[13px]">
                    <div className="avatar relative">
                        <img
                            src={data?.user_profile.profile_picture || "/images/avatar.png"}
                            className="w-14 h-14 rounded-full border border-white object-cover"
                            loading="lazy"
                        />
                    </div>
                    <div className="flex flex-col justify-between gap-[14px]">
                        <Text
                            type="h4"
                            className="font-[600] text-lg"
                            title={`${data?.user_profile?.first_name} ${data?.user_profile?.last_name}`}
                        />
                        <Text
                            type="p"
                            className="font-[500] text-base text-black/60"
                            title={data?.location?.city ? `${data?.location?.city} ${data?.location?.state}` : "N/A"}
                        />
                    </div>
                </div>
                <div className="grid grid-cols-4 gap-[12px]">
                    {[
                        { label: "Requests Made", value: data?.job_requests_made  ?? "0" },
                        { label: "Jobs Posted", value: data?.job_requests.length ?? "0" },
                        { label: "Providers Hired", value: data?.providers_hired ?? "0" },
                        { label: "Support Tickets", value: data?.support_tickets ?? "0" },
                    ].map((item, index)=> (
                        <ProfileStat key={index} label={item.label} value={item.value.toString()} />
                    ))}
                </div>
            </div>

            {/* Profile Information */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <Text
                    title="Customer Information"
                    type="h4"
                    className="font-[600] text-base"
                />

                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                    {[
                        {
                            label: "Name",
                            value: `${data?.user_profile?.first_name}`
                        },
                        {
                            label: "Email",
                            value: data?.user_profile?.email ?? "-"
                        },
                        {
                            label: "Phone Number",
                            value: data?.user_profile?.phone_number ?? "-"
                        },
                        {
                            label: "Gender",
                            value: "Male"
                        },
                        {
                            label: "Location",
                            value: `${data?.location?.city} ${data?.location?.state}`
                        },
                        {
                            label: "Joined Date",
                            value: data?.date_joined ? formatCreatedAt(data?.date_joined) : "-"
                        },
                        {
                            label: "Last Active",
                            value: data?.last_active ? formatCreatedAt(data?.last_active) : "-"
                        },
                    ].map((item, index)=> (
                        <InfoField key={index} label={item.label} value={item.value} />
                    ))}
                </div>
            </div>


            {/* Account Status Information */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <Text
                    title="Security & Account Status"
                    type="h4"
                    className="font-[600] text-base"
                />

                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                    {[
                        {
                            label: "Email Verification",
                            value: data?.email_verified ? data?.email_verified : "Not Verified"
                        },
                        {
                            label: "Account Status",
                            value: data?.account_status ? data?.account_status : "Not Active"
                        },
                        {
                            label: "Phone Verification",
                            value: data?.phone_verified ? data?.phone_verified : "Not Verified"
                        },
                        {
                            label: "Login Device",
                            value: data?.login_devices ? data?.login_devices[0].device_name : "Unknown Device"
                        },
                    ].map((item, index)=> (
                        <InfoField key={index} label={item.label} value={item.value.toString()} />
                    ))}
                </div>
            </div>

            {/* Histories & Timeline */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <div className="flex items-center gap-4">
                    {[
                        { label: "Services Requests", value: "services" },
                        { label: "Job Posts", value: "job" },
                        { label: "Orders", value: "orders" }
                    ].map((tab, index) => (
                        <Button
                            key={index}
                            variant={activeTab === tab.value ? "primary" : "muted"}
                            className={`rounded-[50px] text-[13px] font-[500] px-[20px]`}
                            onClick={()=> setActiveTab(tab.value)}
                        >
                            {tab.label}
                        </Button>
                    ))}
                </div>
                {activeTab === "job" && (
                    <ReusableTable
                        data={data?.job_requests.slice(0,8) || []}
                        columns={jobColumns}
                        manualPagination={true}
                        pageCount={0}
                        isLoading={false}
                        emptyMessage={{
                            title: "No jobs posted yet",
                            description: "",
                            icon: "user-outline",
                        }}
                        hasDateFilter={false}
                    />
                )}
                {activeTab === "services" && (
                    <ReusableTable
                        data={data?.service_bookings.slice(0,8) || []}
                        columns={columns}
                        manualPagination={true}
                        pageCount={0}
                        isLoading={false}
                        emptyMessage={{
                            title: "No services requested yet.",
                            description: "",
                            icon: "user-outline",
                        }}
                        hasDateFilter={false}
                    />
                )}
                {activeTab === "orders" && (
                    <ReusableTable
                        data={data?.orders.slice(0,8) || []}
                        columns={orderColumns}
                        manualPagination={true}
                        pageCount={0}
                        isLoading={false}
                        emptyMessage={{
                            title: "No services requested yet.",
                            description: "",
                            icon: "user-outline",
                        }}
                        hasDateFilter={false}
                    />
                )}
            </div>
        </div>
    )
}

const ProfileStat = ({ label, value }: { label: string; value: string}) => {
    return (
        <div className="bg-gray py-[36px] flex items-center justify-center">
            <div className="text-center flex flex-col gap-[14px]">
                <Text
                    title={value}
                    className="text-lg font-[700]"
                    type="h4"
                />
                <Text
                    title={label}
                    className="text-base font-[500] text-black/60"
                    type="p"
                />
            </div>
        </div>
    )
}


const InfoField = ({ label, value }: { label: string; value: string}) => {
    return (
        <div className="flex flex-col gap-[8px]">
            <Text
                title={label}
                className="text-sm font-[500] text-black/60"
                type="p"
            />
            <Text
                title={value}
                className="text-base font-[600]"
                type="h4"
            />
        </div>
    )
}

export default CustomerDetails;