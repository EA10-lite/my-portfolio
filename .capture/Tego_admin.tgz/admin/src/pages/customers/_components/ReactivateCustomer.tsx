import { useState } from "react";
import type { Customer } from "../../../services/response-structure";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import { formatCreatedAt } from "../../../utils/formatter";
import { Switch } from "../../../components/ui/switch";
import { reactivateCustomer } from "../../../services/users.service";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

const ReactivateCustomer = ({ Customer }: { Customer: Customer }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] =useState<boolean>(false);

    const [openSections, setOpenSections] =useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "reason", "restore", "notify"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [notifyCustomer, setNotifyCustomer] = useState<boolean>(true);
    const [selected, setSelected] = useState<string[]>([])
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        )
    }

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleReactivate = async () => {
        try {
            setLoading(true);
            await reactivateCustomer(Customer.id, { restore_settings: selected, notify_customer: notifyCustomer });
            await queryClient.invalidateQueries({ queryKey: ["customers"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            console.log("error:", error);
            toast.error("Failed to reactivate customer", {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Customer reactivated"
                description={`Customer access has been restored successfully.`}
                Icon={getIcon("user-fill")}
            />
            <DetailsModal
                title="Reactivate Customer"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("reshare-alt-outline", { color: "#000000" })}
                        <span className="text-sm font-[500]">Reactivate Customer</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="primary"
                        onClick={handleReactivate}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Reactivate Customer</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={Customer.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={Customer.name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title="Electrician Technician"
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Customer Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Email"
                                        value={Customer.email}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Location"
                                        value={Customer.location ?? ""}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={Customer.phone_number}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(Customer.created_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={formatCreatedAt(Customer.last_active)}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Suspension Reason" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["reason"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    <Text className="text-sm text-black/50 font-[500]" title="Marketplace Violation" />
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("restore")}
                            >
                                <Text title="Restore Setting" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["restore"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["restore"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Restore service visibility",
                                        "Restore subscription benefits",
                                        "Re-enable marketplace ranking",
                                        "Restore pending requests",
                                    ].map(option => {
                                        const isChecked = selected?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                onChange={() => toggleOption(option)}
                                                checked={isChecked}
                                                label={option}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("notify")}
                            >
                                <Text title="Notify Customer" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["notify"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["notify"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    <div className="flex items-center justify-between">
                                        <Text className="text-sm text-black/50 font-[500]" title="Notify Customer of reactivation" />
                                        <Switch
                                            onCheckedChange={setNotifyCustomer}
                                            checked={notifyCustomer}
                                        />
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default ReactivateCustomer;