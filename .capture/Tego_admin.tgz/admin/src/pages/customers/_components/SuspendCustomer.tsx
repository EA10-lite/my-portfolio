import { useState } from "react";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import { formatCreatedAt } from "../../../utils/formatter";
import type { Customer } from "../../../services/response-structure";
import { suspendCustomer } from "../../../services/users.service";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

const SuspendCustomer = ({ Customer }: { Customer: Customer }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "reason", "settings"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [selected, setSelected] = useState<string[]>([])
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        )
    }

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleSuspend = async () => {
        try {
            setLoading(true);
            await suspendCustomer(Customer.id, selected);
            await queryClient.invalidateQueries({ queryKey: ["customers"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            console.log("error:", error);
            toast.error("Failed to suspend customer", {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Customer Suspended"
                description={`${Customer.name} has been successfully suspended.`}
                Icon={getIcon("warning-fill", { color: "#D8232A" })}
            />
            <DetailsModal
                title="Suspend Customer"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("warning-outline", { color: "#000000" })}
                        <span className="text-sm font-[500]">Suspend Customer</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="destructive"
                        onClick={handleSuspend}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Suspend Customer</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={Customer.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={Customer.name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title="Electrician Technician"
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Customer Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Email"
                                        value={Customer.email}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Location"
                                        value={Customer.location ?? ""}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={Customer.phone_number}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(Customer.created_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={formatCreatedAt(Customer.last_active)}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Suspension Reason" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["reason"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Fraudulent activity",
                                        "Repeated cancellations",
                                        "Policy violation",
                                        "Abusive behaviour",
                                        "Other"
                                    ].map(option => {
                                        const isChecked = selected?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                onChange={() => toggleOption(option)}
                                                checked={isChecked}
                                                label={option}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("settings")}
                            >
                                <Text title="What Happens After Suspension?" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["settings"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["settings"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    {[
                                        "User cannot login",
                                        "Existing requests remain visible",
                                        "Open jobs stay active",
                                        "Archive job history",
                                        "Account data remains stored",
                                    ].map(option => {
                                        return (
                                            <div
                                                key={option}
                                                className="flex items-center gap-[8px]"
                                            >
                                                {getIcon("success-fill")}
                                                <Text title={option} className="text-[13px] font-[500] text-black/50" type="h5" />
                                            </div>
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default SuspendCustomer;