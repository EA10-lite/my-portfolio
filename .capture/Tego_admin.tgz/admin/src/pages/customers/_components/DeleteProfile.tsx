import { useState } from "react";
import type { Customer } from "../../../services/response-structure";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, Trash2, X } from "lucide-react";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";
import { deleteCustomer } from "../../../services/users.service";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

const DeleteProfile = ({ Customer }: { Customer: Customer }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "reason", "settings"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }


    const [selected, setSelected] = useState<string[]>([]);
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        );
    };

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteCustomer(Customer.id, selected);
            await queryClient.invalidateQueries({ queryKey: ["customers"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete customer account"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Account deleted"
                description={"The Customer account has been permanently removed."}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
            />
            <DetailsModal
                title="Delete Customer Account"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        <Trash2 className="text-destructive" />
                        <span className="text-sm font-[500] text-destructive">Delete Profile</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="destructive"
                        onClick={handleDelete}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Delete Account</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={Customer.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={Customer.name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title={Customer.email}
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Customer Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Jobs Posted"
                                        value={Customer?.bookings_count ?? 0}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Request Made"
                                        value={Customer?.requests_count ?? 0}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Tickets Opened"
                                        value={Customer?.tickets_opened ?? 0}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(Customer.created_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={formatCreatedAt(Customer.last_active)}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Reason for Deleting" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["reason"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Fraudulent",
                                        "Inactive Account",
                                        "Duplicate Account",
                                        "Marketplace violation",
                                        "Customer Request",
                                    ].map(option => {
                                        const isChecked = selected?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                onChange={() => toggleOption(option)}
                                                checked={isChecked}
                                                label={option}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("settings")}
                            >
                                <Text title="Deleting this account will" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["settings"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["settings"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    {[
                                        "Remove profile visibility",
                                        "Remove login access",
                                        "Archive activity history",
                                        "Remove notifications",
                                        "Keep transaction records for audit",
                                    ].map(option => {
                                        return (
                                            <div
                                                key={option}
                                                className="flex items-center gap-[8px]"
                                            >
                                                {getIcon("success-fill")}
                                                <Text title={option} className="text-[13px] font-[500] text-black/50" type="h5" />
                                            </div>
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default DeleteProfile;