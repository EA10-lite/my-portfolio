import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt, formatDateString, getFilterLabel } from "../../utils/formatter";
import { Link } from "react-router-dom";
import { getIcon } from "../../components/icons/lib";
import DeleteProfile from "./_components/DeleteProfile";
import SuspendCustomer from "./_components/SuspendCustomer";
import ReactivateCustomer from "./_components/ReactivateCustomer";
import { useQuery } from "@tanstack/react-query";
import { getCustomers } from "../../services/users.service";
import type { Customer } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const columns: ColumnDef<Customer>[] = [
    {
        accessorKey: "name",
        header: "Name",
        cell: ({ row }) => (
            <span className="text-sm">{row.getValue("name")}</span>
        )
    },
    {
        accessorKey: "email",
        header: "Email",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("email")}</span>
        )
    },
    {
        accessorKey: "location",
        header: "Location",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("location")}</span>
        )
    },
    {
        accessorKey: "created_at",
        header: "Created",
        filterFn: dateFilterFn,
        cell: ({ row }) => (
            <span className="">
                {formatCreatedAt(row.getValue("created_at"))}
            </span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "active") badgeVariant = "success";
            if (status.toLowerCase() === "inactive" || status.toLowerCase() === "non active") badgeVariant = "destructive";
            if (status.toLowerCase() === "suspended") badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {
        header: "Action",
        cell: ({ row }) => {
            const status = row.original.status?.toLowerCase()
            return (
                <div className="flex justify-start">
                    <TableAction
                        items={[
                            {
                                label: "view",
                                content: (
                                    <Link to={`/customers/${row.original.id}`} className="flex items-center gap-[6px]">
                                        {getIcon("user-outline", { color: "#000000" })}
                                        <span className="text-sm font-[500]">View Profile</span>
                                    </Link>
                                ),
                            },
                            {
                                label: "suspend",
                                content: status === "suspended"
                                    ? null
                                    : <SuspendCustomer Customer={row.original} />,
                            },
                            {
                                label: "reactivate",
                                content: status === "suspended"
                                    ? <ReactivateCustomer Customer={row.original} />
                                    : null,
                            },
                            {
                                label: "delete",
                                content: <DeleteProfile Customer={row.original} />,
                            },
                        ]}
                    />
                </div>
            )
        }
    }
]

const Customers = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const { data, isLoading, isError, error } = useQuery({
        queryKey: [
            'customers',
            pagination.pageIndex,
            pagination.pageSize,
            search,
            filters,
        ],
        queryFn: () => getCustomers({
            page: pagination.pageIndex + 1,
            limit: pagination.pageSize,
            search,
            ...filters,
        })
    });

    const handleExport = () => {
        if (!data?.full_customer_list) return;

        const dataToExport = data.full_customer_list.map((user: Customer) => ({
            "Name": user.name,
            "Email": user.email,
            "Phone Number": user.phone_number,
            "Status": user.status,
            "Last Active": formatDateString(user.last_active),
            "Created At": formatDateString(user.created_at),
        }));

        exportToCSV(dataToExport, "customers");
    };

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Customers"
                    description="Manage customer accounts, monitor platform activity, and review account history."
                    metrics={[
                        {
                            label: "Total Customers",
                            value: data?.total_customers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase?.total_customers ?? 0
                        },
                        {
                            label: "Active Customers",
                            value: data?.active_customers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase?.active_customers ?? 0
                        },
                        {
                            label: "Inactive Customers",
                            value: data?.inactive_customers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase?.inactive_customers ?? 0
                        },
                        {
                            label: "Suspended Accounts",
                            value: data?.suspended_customers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase?.suspended_customers ?? 0
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isLoading}
                />
            </div>
            <div className="page-body">
                <ReusableTable
                    title="Customers Records"
                    data={isError ? [] : data?.full_customer_list || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.pagination?.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No customers yet",
                        description: isError ? error.message : "Customers will appear here once people begin creating accounts.",
                        icon: "user-outline"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterTitle="Filter Customer"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Customer Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value: "active" },
                                        { label: "Inactive", value: "inactive" },
                                        { label: "Suspended", value: "suspended" },
                                    ]
                                },
                                {
                                    label: "Jobs Posted",
                                    key: "jobs_posted",
                                    options: [
                                        { label: "No Jobs", value: "0" },
                                        { label: "1-5 Jobs", value: "1-5" },
                                        { label: "6-20 Jobs", value: "6-20" },
                                        { label: "20+ Jobs", value: "21" }
                                    ],
                                },
                                {
                                    label: "Request Activity",
                                    key: "service_bookings",
                                    options: [
                                        { label: "No Requests", value: "0" },
                                        { label: "1-5 Requests", value: "1-5" },
                                        { label: "6-20 Requests", value: "6-20" },
                                        { label: "20+ Requests", value: "21" }
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Customers;

