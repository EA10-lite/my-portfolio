import { useParams } from "react-router-dom";
import { ChatBody, ChatHeader, ChatInput } from "../_components";
import { Text } from "../../../../components";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getTicketDetails, replyTicketWithText } from "../../../../services/support.service";
import { toast } from "sonner";
import { getErrorMessage } from "../../../../utils/formatter";
import { X } from "lucide-react";
import { useState } from "react";


const ChatDetails = () => {
    const queryClient = useQueryClient();
    const { id } = useParams();

    const { data, isLoading } = useQuery({
        queryKey: [
            'chats',
            id?.toString(),
        ],
        queryFn: () => getTicketDetails(id!.toString())
    })

    const [message, setMessage] = useState<string>("")
    const handleReplyTicket = async () => {
        if (!data?.id) return;
        try {
            await replyTicketWithText(data?.id, { message, message_type: "TEXT" });
            await queryClient.invalidateQueries({ queryKey: ["chats"] });
            setMessage("");
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to reply chat"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        }
    }


    if(!id) return (
        <div className="flex items-center justify-center h-full">
            <Text
                title="No Chat Selected"
            />
        </div>
    )
    return (
        <div className="support-chats space-y-[20px] px-6 h-full w-full relative overflow-hidden flex flex-col">
            {data && (
                <ChatHeader
                    id={data?.ticket_no}
                    username={`${data?.user?.first_name} ${data?.user?.last_name}`}
                    date={data?.created_at}
                    avatar={data?.user?.profile_picture ?? ""}
                />
            )}
            <div className="overflow-y-auto pb-[200px] flex-1">
                {isLoading ? (
                    <div className="min-h-full flex items-center justify-center">
                        <div className="flex flex-col items-center gap-3">
                            <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                            <Text
                                title="Loading conversations..."
                                type="p"
                                className="text-sm text-black/60"
                            />
                        </div>
                    </div>
                ) : data && (
                    <ChatBody
                        details={data}
                    />
                )}
            </div>
            <ChatInput
                onSubmit={handleReplyTicket}
                chat={message}
                setChat={setMessage}
            />
        </div>
    )
}

export default ChatDetails;