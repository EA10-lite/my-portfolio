import { Text } from "../../../../components";
import { cn } from "../../../../lib/utils";
import type { ChatMessage } from "../../../../services/response-structure";
import type { USER_BRIEF } from "../../../../services/types";
import { formatCreatedAt } from "../../../../utils/formatter";

interface MessageProps {
    message: ChatMessage;
    user: USER_BRIEF;
    isSupport: boolean;
}

const Message = ({ message, isSupport, user } : MessageProps) => {
    return (
        <div
            className={
                cn(
                    "max-w-[365px] flex gap-[12px] items-end",
                    isSupport ? "ml-auto" :"flex-row-reverse justify-end"
                )
            }
        >
            <div className="flex flex-col gap-[8px]">
                <div
                    className={
                        cn(
                            "p-[16px] rounded-[10px]",
                            isSupport
                                ? "bg-primary text-white rounded-bl-[0px]"
                                    : "bg-[#F9F9F9] text-black rounded-br-[0px]"
                        )
                    }
                >
                    <Text
                        title={message.message}
                    />
                </div>
                <div
                    className={cn(isSupport ? "self-end" : "self-start")}
                >
                    <Text
                        title={formatCreatedAt(message.updated_at)}
                        className="text-xs font-[500] text-black/70"
                    />
                </div>
            </div>

            <div className="min-w-[30px] min-h-[30px]">
                <img
                    src={
                            !isSupport
                                ? user.profile_picture ?? ""
                                : "/images/avatar.png"
                    }
                    className="w-[30px] h-[30px] rounded-full"
                />
            </div>
        </div>
    )
}

export default Message;