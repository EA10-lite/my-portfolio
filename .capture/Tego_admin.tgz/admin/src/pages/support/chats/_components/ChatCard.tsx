import { useNavigate } from "react-router-dom";
import { Text } from "../../../../components";
import type { TICKET_STATUS, } from "../../../../services/types";
import { truncateText } from "../../../../utils/formatter";

interface ChatProps {
    id: string;
    user: string;
    status: TICKET_STATUS;
    category: string;
    message: string;
}

const SupportChat = ({ id, user, status, category, message }: ChatProps) => {
    const navigate = useNavigate();
    const openChat = () => {
        navigate(`/support/chat/${id}`)
    }
    return (
        <div
            className="bg-[#C0C0C01A] px-[20px] py-[16px] rounded-[6px] flex items-start gap-[16px]"
            onClick={openChat}
        >
            <div className="relative">
                <img
                    src="/images/avatar.png"
                    className="w-10 h-10 rounded-full"
                />

                <div className="absolute bg-white rounded-full w-[20px] h-[20px] flex items-center justify-center -right-[5px] -bottom-[5px] border-[2.15px] border-primary/10">
                    <Text
                        title={user.slice(0, 1)}
                        className="text-primary text-[8px] font-[500]"
                    />
                </div>
            </div>
            <div className="flex flex-col gap-[8px] flex-1">
                <Text
                    title={user}
                    className="text-sm font-semibold"
                    type="h4"
                />
                <Text
                    title={category}
                    className="text-xs font-[400] text-black/50 capitalize"
                    type="span"
                />
                <Text
                    title={truncateText(message, 50)}
                    className="text-xs font-[500]"
                    type="p"
                />
            </div>
            <div className="items-end">
                <Text
                    title={status}
                    className="uppercase text-primary font-[500] text-xs"
                />
            </div>
        </div>
    )
}


export default SupportChat;