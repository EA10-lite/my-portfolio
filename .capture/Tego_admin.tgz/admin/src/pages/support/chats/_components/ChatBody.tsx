import type { TicketDetails } from "../../../../services/response-structure";
import Message from "./Message";

export interface ChatBodyProps {
    details: TicketDetails;

}

const ChatBody = ({ details } : ChatBodyProps) => {
    return (
        <div className="space-y-[30px]">
            {details.messages.map((message, index)=> (
                <Message
                    key={index}
                    message={message}
                    user={details.user}
                    isSupport={message.admin_sender_id !== null}
                />
            ))}
        </div>
    )
}

export default ChatBody;