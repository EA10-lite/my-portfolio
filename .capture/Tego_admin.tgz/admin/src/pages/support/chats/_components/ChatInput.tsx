import { getIcon } from "../../../../components/icons/lib";
import { useParams } from "react-router-dom";


const ChatInput = ({
    onSubmit,
    chat,
    setChat
} : {
    onSubmit: (message: string) => void;
    chat: string;
    setChat: (text: string) => void;
}) => {
    const { id } = useParams();

    const handleSubmit =  () => {
        onSubmit(chat);
    }
    return (
        <div className="bg-[#C0C0C01A] p-[20px] flex items-center justify-between z-99">
            <input
                value={chat}
                onChange={(e) => setChat(e.target.value)}
                className="flex w-full outline-none"
                placeholder="Type to send message..."
                disabled={!id}
            />
            <button
                className="bg-primary flex items-center justify-center rounded-full w-10 h-10 cursor-pointer"
                disabled={!id && chat.length <= 0}
                onClick={handleSubmit}
            >
                {getIcon("send")}
            </button>
        </div>
    )
}

export default ChatInput;