import { TableAction, Text } from "../../../../components";
import { formatCreatedAt } from "../../../../utils/formatter";


interface ChatHeaderProps {
    id: string;
    username: string;
    avatar?: string;
    date: string;
}

const ChatHeader = ({ username, date, avatar, id }: ChatHeaderProps) => {
    return (
        <div className="flex items-start gap-4 border-b border-black/6 pb-6">
            <div className="relative">
                <img
                    src={avatar ?? "/images/avatar.png"}
                    className="w-10 h-10 rounded-full"
                />

                <div className="absolute bg-white rounded-full w-[20px] h-[20px] flex items-center justify-center -right-[5px] -bottom-[5px] border-[2.15px] border-primary/10">
                    <Text
                        title={username.slice(0, 1)}
                        className="text-primary text-[8px] font-[500]"
                    />
                </div>
            </div>

            <div className="flex flex-col gap-[8px] flex-1">
                <Text
                    title={username}
                    className="font-semibold text-xl"
                />

                <div className="flex items-center gap-2">
                    <Text
                        title={id}
                        className="text-sm text-black/60 font-[500]"
                    />
                    <div className="w-1.5 h-1.5 rounded-full bg-black" />
                    <Text
                        title={`Created ${formatCreatedAt(date)}`}
                        className="text-sm text-black/60 font-[500]"
                    />
                </div>
            </div>

            <TableAction
                items={[
                    {
                        label: "View Ticket",
                        content: null
                    }
                ]}
            />
        </div>
    )
}

export default ChatHeader;