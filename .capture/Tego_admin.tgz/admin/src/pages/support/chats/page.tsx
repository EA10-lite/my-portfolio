import { Text } from "../../../components";
import { ChatInput } from "./_components";


const Chats = () => {
    return (
        <div className="support-chats space-y-[20px] px-6 h-full w-full relative">
            <div className="flex items-center justify-center h-full">
                <Text
                    title="No Chat Selected"
                />
            </div>

            <ChatInput
                chat=""
                onSubmit={()=> {}}
                setChat={() => {}}
            />
        </div>
    )
}

export default Chats;