import React, { useState } from "react";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { Loader2, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { getIcon } from "../../../components/icons/lib";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { deleteTicket } from "../../../services/support.service";

const DeleteIssue = ({ ticketId } : { ticketId: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);
    const [checked, setChecked] = useState<boolean>(false);


    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteTicket(ticketId);
            await queryClient.invalidateQueries({ queryKey: ["tickets"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete ticket"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Ticket Resolved"
                description={`The ticket has been marked as resolved. The customer has been notified.`}
                Icon={getIcon("double-check")}
            />
            <DetailsModal
                title="Issue Details"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("trash-fill", { color: "#D8232A" })}
                        <span className="text-sm font-[500] text-destructive">Delete Ticket</span>
                    </div>
                )}
                ActionButton={(
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        onClick={handleDelete}
                        disabled={!checked}
                        variant="destructive"
                    >
                         { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Delete Ticket</span>
                         )}
                    </Button>
                )}
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                            >
                                <Text title="Ticket Summary" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Ticket ID"
                                    value={"TK-2101"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Issue Type"
                                    value={"Booking Issue"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Created"
                                    value={"26th July, 2026"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Priority"
                                    value={"High"}
                                />
                            </div>
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                            >
                                <Text title="Confirmation" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <Checkbox
                                    label="I understand that this action cannot be undone."
                                    onChange={()=> setChecked(!checked)}
                                    checked={checked}
                                />
                            </div>
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default DeleteIssue;