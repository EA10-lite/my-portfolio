import { useState } from "react";
import { DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { Loader2, X } from "lucide-react";
import type { Ticket } from "../../../services/response-structure";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { useQueryClient } from "@tanstack/react-query";

const AssignTicket = ({ type="assigned", ticket } : { type?: "assigned" | "re-assigned", ticket: Ticket }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);
    const word = type === "assigned" ? "Assign" : "Re-Assign";

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleSubmit = async () => {
        try {
            setLoading(true);
            await queryClient.invalidateQueries({ queryKey: ["tickets"] });
        } catch (error) {
            toast.error(getErrorMessage(error, `Failed to ${type} delete ticket`), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }


    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title={`Ticket ${word}ed`}
                description={`You have successfully ${type} ticket to a admin`}
                Icon={getIcon("double-check")}
            />

            <DetailsModal
                title={`${word} Tickets`}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        <span className="text-sm font-[500] text-primary">{word} Ticket</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="primary"
                        onClick={handleSubmit}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>{word} Admin</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button className="flex items-center justify-between w-full p-[16px]">
                                <Text title="Ticket Selected" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Ticket ID"
                                    value={ticket.ticket_no}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="User"
                                    value={`${ticket.user.first_name} ${ticket.user.last_name}`}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Issue"
                                    value={ticket.title}
                                />
                            </div>
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default AssignTicket;