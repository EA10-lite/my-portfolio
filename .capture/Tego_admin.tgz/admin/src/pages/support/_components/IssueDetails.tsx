import React, { useState } from "react";
import { DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { Loader2, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { getIcon } from "../../../components/icons/lib";
import type { Ticket } from "../../../services/response-structure";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";
import { deleteTicket } from "../../../services/support.service";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

const IssueDetails = ({ ticket } : { ticket: Ticket }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteTicket(ticket.id);
            await queryClient.invalidateQueries({ queryKey: ["tickets"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete ticket"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Ticket Resolved"
                description={`The ticket has been marked as resolved. The customer has been notified.`}
                Icon={getIcon("double-check")}
            />
            <DetailsModal
                title="Issue Details"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("verification-outline", { color: "#000000" })}
                        <span className="text-sm font-[500]">View Ticket</span>
                    </div>
                )}
                ActionButton={(
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        onClick={handleDelete}
                    >
                         { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Resolve Ticket</span>
                         )}
                    </Button>
                )}
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                            >
                                <Text title="Issue Details" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Ticket ID"
                                    value={ticket.ticket_no}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Title"
                                    value={ticket.title}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Issue Type"
                                    value={ticket.category}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Created"
                                    value={formatCreatedAt(ticket.created_at)}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Priority"
                                    value={ticket.priority}
                                />
                            </div>
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                            >
                                <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />
                            </button>
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Name"
                                    value={`${ticket.user.first_name} ${ticket.user.last_name}`}
                                />
                            </div>
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default IssueDetails;