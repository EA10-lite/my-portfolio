import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { X } from "lucide-react";
import { claimTicket } from "../../../services/support.service";

const ClaimTicket = ({ ticketId } : { ticketId: string; }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const handleClaim = async () => {
        try {
            setLoading(true);
            await claimTicket(ticketId);
            await queryClient.invalidateQueries({ queryKey: ["tickets"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to release ticket back to the pool"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Ticket Claimed"
                description={`Ticket has been claimed by you moved and added to your list of tickets.`}
                Icon={getIcon("double-check")}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="The ticket will be assigned to you."
                title="Claim Ticket"
                onContinue={handleClaim}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("double-check", { color: "#000000" })}
                        <span className="text-sm font-[500]">Claim Ticket</span>
                    </div>
                )}
                Icon={getIcon("double-check")}
                buttonTitle="Claim Ticket"
                loading={loading}
            />
        </>
    )
}


export default ClaimTicket;