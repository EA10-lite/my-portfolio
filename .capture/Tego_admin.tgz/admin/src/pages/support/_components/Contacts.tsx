import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "../../../components/ui/popover"
import { cn } from "../../../lib/utils";
import type { AdminUser } from "../../../services/response-structure"

interface Admin {
    name: string;
    id: string;
}

const SupportContacts = ({
    contacts,
    handleSelect,
    count,
} : {
    contacts: AdminUser[],
    handleSelect: (admin: Admin) => void;
    count: number;
}) => {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <div
            className="flex items-center gap-2"
        >
            <div className="bg-black flex items-center justify-center w-6 h-6 rounded-full">
                <p className="text-white text-xs font-[500]">{count}</p>
            </div>
            <p className="text-xs font-[500] text-primary">
                Assign To
            </p>
        </div>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="
            w-[192px]
            max-h-[298px]
            overflow-auto
            shadow-[0px_4px_100px_0px_#007D3614]
            rounded-[10px]
            p-0 m-0
        "
    >
        <div className="">
          {contacts.map((contact, index) => (
            <div
                className={
                    cn(
                        "px-4 py-3 cursor-pointer",
                        index === contacts.length - 1 ? "border-none" : "border-b border-black/4"
                    )
                }
                onClick={()=>
                    handleSelect({
                        name: `${contact.first_name} ${contact.last_name}`,
                        id: contact.id
                    })
                }
            >
                <p className="text-xs hover:text-primary font-[500]">{`${contact.first_name} ${contact.last_name}`}</p>
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  )
}

export default SupportContacts