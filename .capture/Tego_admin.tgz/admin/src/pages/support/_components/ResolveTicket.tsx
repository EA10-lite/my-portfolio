import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { X } from "lucide-react";
import { updateTicket } from "../../../services/support.service";

const ResolveTicket = ({ ticketId, category } : { ticketId: string; category: string }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);
    const resolveTicket = async () => {
        try {
            setLoading(true);
            await updateTicket(ticketId, { status: "RESOLVED", category });
            await queryClient.invalidateQueries({ queryKey: ["tickets"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to update ticket status"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Ticket Resolved"
                description={`The ticket has been marked as resolved. The customer has been notified.`}
                Icon={getIcon("double-check")}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="The customer will be notified that their issue has been resolved."
                title="Resolve Ticket"
                onContinue={resolveTicket}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("double-check", { color: "#000000" })}
                        <span className="text-sm font-[500]">Mark as resolved</span>
                    </div>
                )}
                Icon={getIcon("double-check")}
                buttonTitle="Resolve Ticket"
                loading={loading}
            />
        </>
    )
}


export default ResolveTicket;