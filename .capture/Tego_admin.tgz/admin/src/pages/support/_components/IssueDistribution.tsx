import { Label, Pie, PieChart } from "recharts";
import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from "../../../components/ui/card";
import {
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
    type ChartConfig,
} from "../../../components/ui/chart";
import type { TicketDistribution } from "../../../services/response-structure";

const FILL_COLORS = [
    "#FFCC00",
    "#988AFC",
    "#33ABF7",
    "#34C759",
    "#FFAE4C",
];

interface IssueDistributionProps {
    distribution: TicketDistribution[];
}

export const description = "Issue Distribution";

const IssueDistribution = ({
    distribution,
}: IssueDistributionProps) => {
    const hasData =
        distribution?.length > 0 &&
        distribution.some((item) => item.count > 0);

    const chartData = distribution?.map((item, index) => ({
        ...item,
        fill: FILL_COLORS[index % FILL_COLORS.length],
    }));

    const total = chartData.reduce((sum, item) => sum + item.count, 0);

    const topPlan = hasData
        ? chartData.reduce((highest, current) =>
              current.count > highest.count ? current : highest
          )
        : null;

    const topPlanPercentage = topPlan
        ? Math.round((topPlan.count / total) * 100)
        : 0;

    /**
     * Generate chart config from API data
     */
    const chartConfig = distribution.reduce((config, item, index) => {
        config[item.category] = {
            label: item.category,
            color: FILL_COLORS[index % FILL_COLORS.length],
        };

        return config;
    }, {} as ChartConfig);

    return (
        <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] shadow-none">
            <CardHeader className="items-center pb-0 px-0">
                <CardTitle className="text-black">
                    Issue Distribution
                </CardTitle>
            </CardHeader>

            <CardContent className="flex-1 pb-0">
                <ChartContainer
                    config={chartConfig}
                    className="mx-auto aspect-square max-h-[250px]"
                >
                    <PieChart>
                        <ChartTooltip
                            cursor={false}
                            content={
                                <ChartTooltipContent hideLabel />
                            }
                        />

                        <Pie
                            data={chartData}
                            dataKey="count"
                            nameKey="category"
                            innerRadius={75}
                            strokeWidth={5}
                            cornerRadius={8}
                            paddingAngle={4}
                        >
                            <Label
                                content={({ viewBox }) => {
                                    if (
                                        viewBox &&
                                        "cx" in viewBox &&
                                        "cy" in viewBox &&
                                        topPlan
                                    ) {
                                        return (
                                            <text
                                                x={viewBox.cx}
                                                y={viewBox.cy}
                                                textAnchor="middle"
                                                dominantBaseline="middle"
                                            >
                                                <tspan
                                                    x={viewBox.cx}
                                                    y={viewBox.cy}
                                                    className="fill-black text-lg font-semibold capitalize"
                                                >
                                                    {topPlan.category}
                                                </tspan>

                                                <tspan
                                                    x={viewBox.cx}
                                                    y={(viewBox.cy || 0) + 24}
                                                    className="fill-black"
                                                >
                                                    {topPlanPercentage}%
                                                </tspan>
                                            </text>
                                        );
                                    }

                                    return null;
                                }}
                            />
                        </Pie>
                    </PieChart>
                </ChartContainer>
            </CardContent>

            {hasData && (
                <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
                    {chartData.map((item) => (
                        <div
                            key={item.category}
                            className="flex items-center gap-2 leading-none font-medium"
                        >
                            <div
                                className="w-2.5 h-2.5 rounded-full"
                                style={{
                                    background: item.fill,
                                }}
                            />

                            <span className="capitalize">
                                {item.category}
                            </span>
                        </div>
                    ))}
                </CardFooter>
            )}
        </Card>
    );
};

export default IssueDistribution;