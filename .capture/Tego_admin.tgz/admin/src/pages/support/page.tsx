import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt, formatDateString, getErrorMessage } from "../../utils/formatter";
import IssueDistribution from "./_components/IssueDistribution";
import TicketVolume from "./_components/TicketVolume";
import ResolveTicket from "./_components/ResolveTicket";
import IssueDetails from "./_components/IssueDetails";
import DeleteIssue from "./_components/DeleteIssue";
import { Link } from "react-router-dom";
import { getIcon } from "../../components/icons/lib";
import { useQueries, useQueryClient } from "@tanstack/react-query";
import { assignTicketsToAdmin, getTickets, getTicketStats } from "../../services/support.service";
import type { Ticket } from "../../services/response-structure";
import { useAdminStore } from "../../store/adminStore";
import type { FilterValues } from "../../components/main/FilterContent";
import ClaimTicket from "./_components/ClaimTicket";
import { exportToCSV } from "../../utils/exportToCSV";
import SupportContacts from "./_components/Contacts";
import { getAdmins } from "../../services/admin-users.service";
import { toast } from "sonner";
import { Check, X } from "lucide-react";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";


const myColumns: ColumnDef<Ticket>[] = [
    {
        accessorKey: "id",
        header: "Ticket ID",
        cell: ({ row }) => (
            <span className="text-sm uppercase">
                BOK-{row.original.ticket_no.slice(-4)}
            </span>
        )
    },
    {
        accessorKey: "user",
        header: "User",
        cell: ({ row }) => (
            <span className="capitalize">{`${row.original.user.first_name} ${row.original.user.last_name}`}</span>
        )
    },
    {
        accessorKey: "issue",
        header: "Issue",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.title}</span>
        )
    },
    {
        accessorKey: "createdAt",
        filterFn: dateFilterFn,
        header: "Date Created",
        cell: ({ row }) => (
            <span className="capitalize">{formatCreatedAt(row.original.created_at)}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "resolved") badgeVariant = "success";
            if (status === "escalated") badgeVariant = "destructive";
            if (status === "open" || status === "in_progress") badgeVariant = "primary";
            if (status === "pending") badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "success" | "destructive"}
                >
                    {status.replaceAll("_", " ")}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => {
            const status = row.original.status?.toLowerCase();
            return (
                <div className="flex justify-start">
                    <TableAction
                        items={[
                            {
                                label: "View Ticket",
                                content: <IssueDetails ticket={row.original} />
                            },
                            {
                                label: "View Chat",
                                content: (
                                    <Link to={`/support/chat/${row.original.id}`} className="flex items-center gap-[6px]">
                                        {getIcon("chat-outline")}
                                        <span className="text-sm font-[500]">View chat</span>
                                    </Link>
                                )
                            },
                            {
                                label: "Mark as Resolve",
                                content: status === "resolved"
                                    ? null
                                    : <ResolveTicket ticketId={row.original.id} category={row.original.category} />
                            },
                            {
                                label: "Delete Issue",
                                content: <DeleteIssue ticketId={row.original.id} />
                            }
                        ]}
                    />
                </div>
            )
        }
    }
]
const columns: ColumnDef<Ticket>[] = [
    {
        accessorKey: "id",
        header: "Ticket ID",
        cell: ({ row }) => (
            <span className="text-sm uppercase">
                BOK-{row.original.ticket_no.slice(-4)}
            </span>
        )
    },
    {
        accessorKey: "user",
        header: "User",
        cell: ({ row }) => (
            <span className="capitalize">{`${row.original.user.first_name} ${row.original.user.last_name}`}</span>
        )
    },
    {
        accessorKey: "issue",
        header: "Issue",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.title}</span>
        )
    },
    {
        accessorKey: "createdAt",
        filterFn: dateFilterFn,
        header: "Date Created",
        cell: ({ row }) => (
            <span className="capitalize">{formatCreatedAt(row.original.created_at)}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "resolved") badgeVariant = "success";
            if (status === "escalated") badgeVariant = "destructive";
            if (status === "open" || status === "in_progress") badgeVariant = "primary";
            if (status === "pending") badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "success" | "destructive"}
                >
                    {status === "pending" ? "In Progress" : status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => {
            const status = row.original.status?.toLowerCase();
            const isOpen = status === "open";
            return (
                <div className="flex justify-start">
                    <TableAction
                        items={[
                            {
                                label: "View Ticket",
                                content: <IssueDetails ticket={row.original} />
                            },
                            {
                                label: "View Chat",
                                content: (
                                    <Link to={`/support/chat/${row.original.id}`} className="flex items-center gap-[6px]">
                                        {getIcon("chat-outline")}
                                        <span className="text-sm font-[500]">View chat</span>
                                    </Link>
                                )
                            },
                            {
                                label: "Claim Ticket",
                                content: isOpen
                                    ? <ClaimTicket ticketId={row.original.id} />
                                    : null
                            },
                            {
                                label: "Mark as Resolve",
                                content: status === "resolved"
                                    ? null
                                    : <ResolveTicket ticketId={row.original.id} category={row.original.category} />
                            },
                            {
                                label: "Delete Issue",
                                content: <DeleteIssue ticketId={row.original.id} />
                            }
                        ]}
                    />
                </div>
            )
        }
    }
]

const ContactSupport = () => {
    const queryClient = useQueryClient();
    const search = useDebouncedSearch(500);
    const { admin } = useAdminStore();

    const [filters, setFilters] = useState<FilterValues>({});
    const [filters2, setFilters2] = useState<FilterValues>({});
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });
    const [pagination2, setPagination2] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data: stats,
            isLoading: isStatLoading,
        },
        {
            data: contacts,
        },
        {
            data,
            isLoading,
            isError,
            error
        },
        {
            data: data2,
            isLoading: isLoading2,
            isError: isError2,
            error: error2,
        },
    ] = useQueries({
        queries: [
            {
                queryKey: ['ticket-stats'],
                queryFn: () => getTicketStats()
            },
            {
                queryKey: ['support-admins'],
                queryFn: () => getAdmins({ limit: 100 })
            },
            {
                queryKey: [
                    'all-tickets',
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters
                ],
                enabled: !!admin?.userType,
                queryFn: () => getTickets({
                    page: pagination.pageIndex + 1,
                    limit: pagination.pageSize,
                    scope: "pool",
                    search,
                    ...filters,
                }),
            },
            {
                queryKey: [
                    'my-tickets',
                    pagination2.pageIndex,
                    pagination2.pageSize,
                    search,
                    filters2
                ],
                enabled: !!admin?.userType,
                queryFn: () => getTickets({
                    page: pagination2.pageIndex + 1,
                    limit: pagination2.pageSize,
                    scope: "mine",
                    search,
                    ...filters2,
                }),
            }
        ]
    })

    const handleExport = () => {
        if (!data?.tickets) return;

        const dataToExport = data.tickets.map((ticket: Ticket) => ({
            "Name": `${ticket.user.first_name} ${ticket.user.last_name}`,
            "Title ID": ticket.ticket_no,
            "Title": ticket.title,
            "Category": ticket.category,
            "Description": ticket.last_message,
            "Status": ticket.status,
            "Created At": formatDateString(ticket.created_at),
        }));

        exportToCSV(dataToExport, "tickets");
    };


    const [selectedTickets, setSelectedTickets] = useState<string[]>([]);

    const [loading, setLoading] = useState<boolean>(false);
    const assignTickets = async (values: { name: string, id: string }) => {
        try {
            setLoading(true);
            await assignTicketsToAdmin({
                admin_id: values.id,
                ticket_ids: selectedTickets,
            });
            await queryClient.invalidateQueries({ queryKey: ["tickets"] });
            toast.success(`${selectedTickets.length} successfully assigned to Admin ${values?.name}`, {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <Check className="size-4 text-primary" />
                    </div>
                )
            })
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to release ticket back to the pool"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
            console.log("Loading: ", loading);
        }
    }

    const toggleSelected = (id: string) => {
        if (selectedTickets.includes(id)) {
          const temp = selectedTickets.filter((ticket) => ticket !== id);
          setSelectedTickets(temp);
        } else {
          setSelectedTickets((prev) => [...prev, id]);
        }
    };

    return (
        <div className="categories space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Support Centre"
                    description="Monitor support requests, respond to users, and resolve platform issues efficiently."
                    metrics={[
                        {
                            label: "Open Tickets",
                            value: stats?.open_tickets ?? 0,
                            filter: "All Time",
                            percentageIncrease: stats?.open_tickets_pct ?? 0
                        },
                        {
                            label: "Resolved Today",
                            value: stats?.resolved_today ?? 0,
                            filter: "All Time",
                            percentageIncrease: stats?.resolved_today_pct ?? 0
                        },
                        {
                            label: "Escalated Issues",
                            value: stats?.escalated ?? 0,
                            filter: "All Time",
                            percentageIncrease: stats?.escalated_pct ?? 0
                        },
                        {
                            label: "Average Response Time",
                            value: `${stats?.avg_response_hours ?? 0} Hrs`,
                            filter: "All Time",
                            percentageIncrease: stats?.avg_response_hours_pct ?? 0
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body space-y-[20px]">
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                    <div className="col-span-12 lg:col-span-3">
                        {stats?.weekly_volume && stats?.weekly_volume?.length > 0 && (
                            <TicketVolume data={stats.weekly_volume} />
                        )}
                    </div>
                    <div className="col-span-12 lg:col-span-2">
                        {stats?.distribution && stats?.distribution?.length > 0 && (
                            <IssueDistribution distribution={stats?.distribution ?? []} />
                        )}
                    </div>
                </div>
                <ReusableTable
                    title="My Tickets"
                    data={isError2 ? [] : data2?.tickets || []}
                    columns={myColumns}
                    manualPagination={true}
                    pageCount={data2?.pagination.total_pages}
                    pagination={pagination2}
                    onPaginationChange={setPagination2}
                    isLoading={isLoading2}
                    emptyMessage={{
                        title: isError2 ? error2.name : "No active tickets",
                        description: isError2 ? error2.message : "You don't have any active ticket",
                        icon: "ticket-outline",
                    }}
                    filterTitle="Filter Support Tickets"
                    onDateFilterChange={(period) => {
                        setPagination2((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters2((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Status",
                                    key: "status",
                                    options: [
                                        { label: "All", value: "all" },
                                        { label: "Open", value: "open" },
                                        { label: "Closed", value: "closed" },
                                    ],
                                },
                                {
                                    label: "Issue Type",
                                    key: "categories",
                                    options: [
                                        { label: "Booking Issue", value: "BOOKING" },
                                        { label: "Payment Issue", value: "PAYMENT" },
                                        { label: "Provider Complaint", value: "PROVIDER_COMPLAINT" },
                                        { label: "Subscription", value: "SUBSCRIPTION" },
                                        { label: "Verification", value: "VERIFICATION" },
                                        { label: "Service Issue", value: "SERVICE" },
                                        { label: "Account Issue", value: "ACCOUNT" },
                                        { label: "Other", value: "OTHER" },
                                    ],
                                },
                                {
                                    label: "Submitted By",
                                    key: "submitted_by",
                                    options: [
                                        { label: "Customer", value: "CUSTOMER" },
                                        { label: "Provider", value: "PROVIDER" },
                                    ],
                                },
                                {
                                    label: "Priority",
                                    key: "priority",
                                    options: [
                                        { label: "Low", value: "LOW" },
                                        { label: "Medium", value: "MEDIUM" },
                                        { label: "High", value: "HIGH" },
                                        { label: "Critical", value: "CRITICAL" },
                                    ],
                                },
                                {
                                    label: "Posted Date",
                                    key: "posted_date",
                                    options: [
                                        { label: "Today", value: "1d" },
                                        { label: "This week", value: "7d" },
                                        { label: "Last 30 days", value: "30d" },
                                        { label: "Last 90 days", value: "90d" },
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination2((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters2(selected);
                            }}
                            onReset={() => {
                                setPagination2((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters2({});
                            }}
                        />
                    )}
                />
                <ReusableTable
                    title="All Tickets"
                    data={isError ? [] : data?.tickets || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.pagination.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    onRowSelect={toggleSelected}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No support tickets",
                        description: isError ? error.message : "Support requests from users and providers will appear here.",
                        icon: "ticket-outline",
                    }}
                    selectable={true}
                    TitleComponent={(
                        <SupportContacts
                            contacts={contacts?.admins || []}
                            count={selectedTickets.length}
                            handleSelect={assignTickets}
                        />
                    )}
                    filterTitle="Filter Support Tickets"
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Status",
                                    key: "status",
                                    options: [
                                        { label: "Open", value: "OPEN" },
                                        { label: "In Progress", value: "IN_PROGRESS" },
                                        { label: "Resolved", value: "RESOLVED" },
                                        { label: "Escalated", value: "ESCALATED" },
                                        { label: "Closed", value: "CLOSED" },
                                    ],
                                },
                                {
                                    label: "Issue Type",
                                    key: "categories",
                                    options: [
                                        { label: "Booking Issue", value: "BOOKING" },
                                        { label: "Payment Issue", value: "PAYMENT" },
                                        { label: "Provider Complaint", value: "PROVIDER_COMPLAINT" },
                                        { label: "Subscription", value: "SUBSCRIPTION" },
                                        { label: "Verification", value: "VERIFICATION" },
                                        { label: "Service Issue", value: "SERVICE" },
                                        { label: "Account Issue", value: "ACCOUNT" },
                                        { label: "Other", value: "OTHER" },
                                    ],
                                },
                                {
                                    label: "Submitted By",
                                    key: "submitted_by",
                                    options: [
                                        { label: "Customer", value: "CUSTOMER" },
                                        { label: "Provider", value: "PROVIDER" },
                                    ],
                                },
                                {
                                    label: "Priority",
                                    key: "priority",
                                    options: [
                                        { label: "Low", value: "LOW" },
                                        { label: "Medium", value: "MEDIUM" },
                                        { label: "High", value: "HIGH" },
                                        { label: "Critical", value: "CRITICAL" },
                                    ],
                                },
                                {
                                    label: "Posted Date",
                                    key: "posted_date",
                                    options: [
                                        { label: "Today", value: "1d" },
                                        { label: "This week", value: "7d" },
                                        { label: "Last 30 days", value: "30d" },
                                        { label: "Last 90 days", value: "90d" },
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default ContactSupport;

