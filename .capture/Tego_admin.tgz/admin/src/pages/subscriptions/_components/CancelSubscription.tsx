import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";

const CancelSubscription = () => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const handleSubmit = () => {
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            setOpen(false);        // close the sheet
            setSuccessOpen(true)   // open success modal
        }, 1000)
    }

    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Subscription Cancelled"
                description={`This provider will move to the Free plan once the current subscription period ends`}
                Icon={getIcon("close-fill", { color: "#33ABF7" })}
                style="min-w-[313px]"
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This provider will lose premium benefits at the end of the current billing cycle."
                title="Cancel Subscription"
                onContinue={handleSubmit}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("close-outline", { color: "#D8232A"})}
                        <span className="text-sm font-[500] text-destructive">Cancel Subscription</span>
                    </div>
                )}
                Icon={getIcon("close-fill", { color: "#D8232A" })}
                buttonTitle="Cancel Subscription"
                buttonType="destructive"
                style="min-w-[313px]"
                loading={loading}
            />
        </>
    )
}


export default CancelSubscription;