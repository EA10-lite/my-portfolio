import React from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { ChevronDown, ChevronUp, Eye } from "lucide-react";
import { formatCurrency } from "../../../utils/formatter";

const RenewalDetails = () => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["provider", "renewal", "reason"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Renewal Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    <Eye />
                    <span className="text-sm font-[500]">View Renewal Details</span>
                </div>
            )}
            ActionButton={null}
            hasFooter={false}
            open={open}
            onOpenChange={setOpen}
        >
            <div className="px-[16px]">
                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("provider")}
                        >
                            <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["provider"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["provider"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Name"
                                    value={"Daniel Okeke"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Service"
                                    value={"Generator Repari"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Status"
                                    value={"Pending"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Plan"
                                    value={"Pro Monthly"}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("renewal")}
                        >
                            <Text title="Renewal Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["renewal"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["renewal"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Current Plan"
                                    value={"Pro Monthly"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Renewal Amount"
                                    value={formatCurrency(12000)}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Renewal Date"
                                    value={"12 July 2027"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Status"
                                    value={"Failed"}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("reason")}
                        >
                            <Text title="Failure Reason" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["reason"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["reason"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Failure Reason"
                                    value={"Insufficient Funds"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Gateway Response"
                                    value={"Insufficient Funds"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Retry Attempts"
                                    value={"2 of 3"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Last Rety"
                                    value={"10 July 2027"}
                                />
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </DetailsModal>
    )
}


export default RenewalDetails;