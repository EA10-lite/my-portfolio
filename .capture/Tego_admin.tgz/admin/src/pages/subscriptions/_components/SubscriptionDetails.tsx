import React from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { ChevronDown, ChevronUp } from "lucide-react";
import { formatCreatedAt } from "../../../utils/formatter";
import { getIcon } from "../../../components/icons/lib";
import type { SubscriptionRecord } from "../../../services/response-structure";

const SubscriptionDetails = ({ subscription }: { subscription: SubscriptionRecord }) => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Subscription Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    {getIcon("subscription-outline", { color: "black" })}
                    <span className="text-sm font-[500]">View Subscription</span>
                </div>
            )}
            ActionButton={null}
            open={open}
            onOpenChange={setOpen}
            hasFooter={false}
        >
            <div className="px-[16px] space-y-[20px]">
                <div className="flex items-center gap-[13px]">
                    <div className="avatar relative">
                        <img
                            src={subscription.provider.avatar ?? "/images/avatar.png"}
                            className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                            loading="lazy"
                        />
                    </div>
                    <div className="flex flex-col justify-between gap-[14px]">
                        <Text
                            type="h4"
                            className="font-[600] text-lg"
                            title={subscription.provider.name}
                        />
                        <Text
                            type="p"
                            className="font-[500] text-base text-black/60"
                            title={subscription.status}
                        />
                    </div>
                </div>

                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("summary")}
                        >
                            <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["summary"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["summary"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Current Plan"
                                    value={subscription.plan_name}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Started"
                                    value={formatCreatedAt(subscription.started_at)}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Renews"
                                    value={subscription.renewal_date ? formatCreatedAt(subscription.renewal_date) : "-"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Billing Method"
                                    value={"Bank Transfer"}
                                />
                            </div>
                        )}
                    </div>
                </div>

            </div>
        </DetailsModal>
    )
}


export default SubscriptionDetails;