import { useMemo } from "react"
import { CartesianGrid, BarChart, XAxis, YAxis, Bar } from "recharts"

import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "../../../components/ui/chart"
import { EmptyState } from "../../../components"
import type { IconType } from "../../../components/icons/lib"

export interface RevenueByPlanPoint {
  period: string
  FREE: number
  PRO_MONTHLY: number
  PRO_ANNUAL: number
}

type RevenueByPlanProps = {
  data?: RevenueByPlanPoint[]
  emptyMessage?: {
    title: string
    icon: IconType
    description: string
  }
}

type ChartRow = {
  label: string
  free: number
  pro_monthly: number
  pro_yearly: number
}

function buildChartRows(
  points: RevenueByPlanPoint[] | undefined
): ChartRow[] {
  if (!points?.length) return []

  return points.map((point) => {
    const date = new Date(`${point.period}T12:00:00`)

    return {
      label: Number.isNaN(date.getTime())
        ? point.period
        : date.toLocaleDateString(undefined, {
            month: "short",
            day: "numeric",
          }),
      free: point.FREE,
      pro_monthly: point.PRO_MONTHLY,
      pro_yearly: point.PRO_ANNUAL,
    }
  })
}

const chartConfig = {
  free: {
    label: "Free",
    color: "#33ABF7",
  },
  pro_monthly: {
    label: "Pro Monthly",
    color: "#33ABF799",
  },
  pro_yearly: {
    label: "Pro Yearly",
    color: "#33ABF733",
  },
} satisfies ChartConfig

const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{
    name?: string
    value?: number
    color?: string
  }>
  label?: string
}) => {
  if (!active || !payload?.length || label == null) return null

  const labels: Record<string, string> = {
    free: "Free",
    pro_monthly: "Pro Monthly",
    pro_yearly: "Pro Yearly",
  }

  const formatRevenue = (value: number) => {
    return new Intl.NumberFormat("en-NG", {
      style: "currency",
      currency: "NGN",
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="bg-white rounded-[6px] p-4 min-w-[190px] border border-black/5 shadow-md">
      <p className="text-xs text-black/50 mb-2">{label}</p>

      <div className="space-y-2">
        {payload.map((entry, index) => {
          const value = Number(entry.value ?? 0)
          const name = entry.name ?? ""

          return (
            <div
              key={`${name}-${index}`}
              className="flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-1.5">
                <span
                  className="w-2 h-2 rounded-full"
                  style={{
                    background: entry.color,
                  }}
                />

                <span className="text-xs text-black/60">
                  {labels[name] ?? name}
                </span>
              </div>

              <span className="text-xs font-semibold text-black">
                {formatRevenue(value)}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

const RevenueByPlan = ({
  data,
  emptyMessage = {
    title: "No revenue data available",
    description:
      "Revenue data will appear after users subscribe to a plan.",
    icon: "chart-outline",
  },
}: RevenueByPlanProps) => {
  const chartData = useMemo(
    () => buildChartRows(data),
    [data]
  )

  const hasData = chartData.length > 0

  const chartItems = [
    {
      type: "Free",
      fill: "#33ABF7",
    },
    {
      type: "Pro Monthly",
      fill: "#33ABF799",
    },
    {
      type: "Pro Yearly",
      fill: "#33ABF733",
    },
  ]

  return (
    <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] text-black space-y-6 shadow-none">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0">
        <CardTitle className="text-lg font-medium">
          Revenue By Plan
        </CardTitle>
      </CardHeader>

      <CardContent className="p-0">
        {hasData ? (
          <ChartContainer
            config={chartConfig}
            className="max-h-[365px] w-full p-0"
          >
            <BarChart
              accessibilityLayer
              data={chartData}
              barCategoryGap="33%"
              barGap={2}
              margin={{
                left: 0,
                right: 12,
                top: 10,
                bottom: 0,
              }}
            >
              <CartesianGrid
                vertical={false}
                strokeDasharray="3 3"
                stroke="rgba(0,0,0,0.08)"
              />

              <XAxis
                dataKey="label"
                tickLine={false}
                axisLine={false}
                tickMargin={15}
                minTickGap={24}
                tick={{
                  fill: "rgba(0,0,0,0.4)",
                  fontSize: 12,
                }}
              />

              <YAxis
                tickLine={false}
                axisLine={false}
                tickMargin={15}
                allowDecimals={false}
                tick={{
                  fill: "rgba(0,0,0,0.4)",
                  fontSize: 12,
                }}
                tickFormatter={(value) =>
                  new Intl.NumberFormat("en-NG", {
                    notation: "compact",
                    maximumFractionDigits: 1,
                  }).format(value)
                }
              />

              <ChartTooltip
                cursor={{
                  fill: "rgba(0,0,0,0.04)",
                }}
                content={<CustomTooltip />}
              />

              <Bar
                dataKey="free"
                fill="#33ABF7"
                radius={5}
                maxBarSize={19}
              />

              <Bar
                dataKey="pro_monthly"
                fill="#33ABF799"
                radius={5}
                maxBarSize={19}
              />

              <Bar
                dataKey="pro_yearly"
                fill="#33ABF733"
                radius={5}
                maxBarSize={19}
              />
            </BarChart>
          </ChartContainer>
        ) : (
          <EmptyState emptyMessage={emptyMessage} />
        )}
      </CardContent>

      {hasData && (
        <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
          {chartItems.map((item) => (
            <div
              key={item.type}
              className="flex items-center gap-2 leading-none font-medium"
            >
              <div
                className="w-2.5 h-2.5 rounded-full"
                style={{
                  background: item.fill,
                }}
              />

              <span className="capitalize text-[#909090] text-xs font-[400]">
                {item.type}
              </span>
            </div>
          ))}
        </CardFooter>
      )}
    </Card>
  )
}

export default RevenueByPlan