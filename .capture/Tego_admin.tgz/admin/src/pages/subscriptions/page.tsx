import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { formatCreatedAt, formatCurrency, formatDateString, getFilterLabelByRange } from "../../utils/formatter";
import SubscriptionGrowth from "./_components/SubscriptionGrowth";
import RevenueByPlan from "./_components/RevenueByPlan";
import SubscriptionDetails from "./_components/SubscriptionDetails";
import type { SubscriptionRecord } from "../../services/response-structure";
import { getSubscriptions, getSubscriptionStats } from "../../services/subscription.service";
import { useQueries } from "@tanstack/react-query";
import type { FilterValues } from "../../components/main/FilterContent";
import type { RANGE } from "../../services/types";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const columns: ColumnDef<SubscriptionRecord>[] = [
    {
        accessorKey: "provider",
        header: "Provider",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.provider.name}</span>
        )
    },
    {
        accessorKey: "plan",
        header: "Plan",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.plan_name}</span>
        )
    },
    {
        accessorKey: "paymentMethod",
        header: "Payment Method",
        cell: () => (
            <span className="capitalize">{"Bank Transfer"}</span>
        )
    },
    {
        accessorKey: "renewalDate",
        header: "Renewal Date",
        cell: ({ row }) => (
            <span className="capitalize">{formatCreatedAt(row.original.renewal_date)}</span>
        )
    },
    {
        accessorKey: "autoRenewal",
        header: "Auto Renewal",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.auto_renewal}</span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.original.status.toLowerCase() as string;

            let badgeVariant = "secondary";
            if (status === "active") badgeVariant = "success";
            if (status === "expired" || status === "cancelled") badgeVariant = "destructive";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "success" | "destructive" | "primary"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <TableAction
                    items={[
                        {
                            label: "view",
                            content: <SubscriptionDetails subscription={row.original} />,
                        }
                    ]}
                />
            </div>
        )
    }
]

const Subscriptions = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});
    const [dateFilter, setDateFilter] = useState<RANGE>("week");
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });


    const [
        {
            data: stat,
            isLoading: isStatLoading
        },
        {
            data,
            isLoading,
            isError,
            error
        }
    ] = useQueries({
            queries: [
            {
                queryKey: [
                    'subscription-stats',
                    pagination.pageIndex,
                    pagination.pageSize,
                    dateFilter,
                    filters
                ],
                queryFn: () => getSubscriptionStats(dateFilter),
            },
            {
                queryKey: [
                    'subscriptions',
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters
                ],
                queryFn: () => getSubscriptions({
                    page: pagination.pageIndex + 1,
                    limit: pagination.pageSize,
                    search,
                    ...filters,
                }),
            }
        ]
    })

    const handleExport = () => {
        if (!data?.records) return;

        const dataToExport = data.records.map((subscription: SubscriptionRecord) => ({
            "Title": subscription.plan_name,
            "Provider": subscription.provider.name,
            "Amount": subscription.amount,
            "Currency": subscription.currency,
            "Status": subscription.status,
            "Created At": formatDateString(subscription.started_at),
            "Renewal Date": formatDateString(subscription.renewal_date),
        }));

        exportToCSV(dataToExport, "subscriptions");
    };

    return (
        <div className="categories space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Subscription Management"
                    description="Manage provider subscriptions, monitor recurring revenue, and optimize plan performance."
                    metrics={[
                        {
                            label: "Active Subscriptions",
                            value: stat?.summary?.active_subscriptions?.value ?? 0,
                            filter: getFilterLabelByRange(dateFilter),
                            percentageIncrease: stat?.summary?.active_subscriptions?.change_pct ?? 0
                        },
                        {
                            label: "Free Users",
                            value: stat?.summary?.free_users?.value ?? 0,
                            filter: getFilterLabelByRange(dateFilter),
                            percentageIncrease: stat?.summary?.free_users?.change_pct ?? 0
                        },
                        {
                            label: "Pro Users",
                            value: stat?.summary?.pro_users?.value ?? 0,
                            filter: getFilterLabelByRange(dateFilter),
                            percentageIncrease: stat?.summary?.pro_users?.change_pct ?? 0,
                        },
                        {
                            label: "Monthly Revenue",
                            value: `${formatCurrency(stat?.summary?.monthly_revenue?.value ?? 0)}`,
                            filter: getFilterLabelByRange(dateFilter),
                            percentageIncrease: stat?.summary?.monthly_revenue?.change_pct ?? 0,
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body space-y-[20px]">
                {stat?.growth && (
                    <SubscriptionGrowth
                        data={stat.growth}
                        dateFilter={dateFilter}
                        onDateChange={setDateFilter}
                    />
                )}
                {stat?.revenue_by_plan && <RevenueByPlan data={stat.revenue_by_plan} />}

                <ReusableTable
                    title="Subscription Records"
                    data={isError ? [] : data?.records || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={10}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        title: isError ? error.name : "No active subscriptions",
                        description: isError ? error.message : "Provider subscriptions will appear once plans are activated.",
                        icon: "subscription-outline"
                    }}
                    filterTitle="Filter Subscriptions"
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Subscription Plan",
                                    key: "subscription",
                                    options: [
                                        { label: "Free", value: "FREE" },
                                        { label: "Pro Monthly", value: "PRO_MONTHLY" },
                                        { label: "Pro Yearly", value: "PRO_ANNUAL" },
                                    ],
                                },
                                {
                                    label: "Subscription Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value: "ACTIVE" },
                                        { label: "Expired", value: "EXPIRED" },
                                        { label: "Cancelled", value: "CANCELLED" },
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Subscriptions;

