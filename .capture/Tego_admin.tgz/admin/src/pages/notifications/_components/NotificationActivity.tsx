import { useMemo, useState } from "react"
import { CartesianGrid,  BarChart, XAxis, YAxis, Bar } from "recharts"

import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  type ChartConfig,
} from "../../../components/ui/chart"
import { Button } from "../../../components/ui/button"
import type { RevenueGrowthSeries } from "../../../services/dashboard.service"

type Timeframe = "Day" | "Week" | "Year"

type JobActivityProps = {
  data?: {
    day: { system: RevenueGrowthSeries; provider: RevenueGrowthSeries; user: RevenueGrowthSeries }
    week: { system: RevenueGrowthSeries; provider: RevenueGrowthSeries; user: RevenueGrowthSeries }
    year: { system: RevenueGrowthSeries; provider: RevenueGrowthSeries; user: RevenueGrowthSeries }
  }
}

const TIMEFRAME_KEY: Record<Timeframe, keyof NonNullable<JobActivityProps["data"]>> = {
  Day: "day",
  Week: "week",
  Year: "year",
}

type ChartRow = { label: string; system: number; provider: number; user: number }

function formatAxisLabel(timeframe: Timeframe, rawLabel: string): string {
  if (timeframe === "Day") {
    const parts = rawLabel.trim().split(/\s+/)
    return parts[parts.length - 1] ?? rawLabel
  }
  if (timeframe === "Week") {
    const d = new Date(`${rawLabel}T12:00:00`)
    if (!Number.isNaN(d.getTime())) {
      return d.toLocaleDateString(undefined, { month: "short", day: "numeric" })
    }
  }
  if (timeframe === "Year") {
    const [y, m] = rawLabel.split("-")
    if (y && m) {
      const d = new Date(Number(y), parseInt(m, 10) - 1, 1)
      if (!Number.isNaN(d.getTime())) {
        return d.toLocaleDateString(undefined, { month: "short", year: "2-digit" })
      }
    }
  }
  return rawLabel
}

function buildChartRows(
  series: { system: RevenueGrowthSeries; provider: RevenueGrowthSeries; user: RevenueGrowthSeries } | undefined,
  timeframe: Timeframe
): ChartRow[] {
  if (!series?.system?.points?.length) return []
  return series.system.points.map((p, i) => ({
    label: formatAxisLabel(timeframe, p.label),
    system: p.count,
    provider: series.provider.points[i]?.count ?? 0,
    user: series.user.points[i]?.count ?? 0,
  }))
}

// ["#33ABF7", "#33ABF733", "#33ABF799"];

const chartConfig = {
  system: {
    label: "System",
    color: "#33ABF799",
  },
  provider: {
    label: "Provider",
    color: "#33ABF733",
  },
  user: {
    label: "User",
    color: "#33ABF7",
  },
} satisfies ChartConfig

const CustomTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: Array<{ name?: string; value?: number; color?: string }>
  label?: string
}) => {
  if (!active || !payload?.length || label == null) return null

  return (
    <div className="bg-white rounded-[6px] p-4 min-w-[168px] border border-black/5 shadow-md">
      <p className="text-xs text-black/50 mb-2">{label}</p>
      <div className="space-y-1.5">
        {payload.map((entry, i) => (
          <div key={i} className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
              <span className="text-xs text-black/60 capitalize">{entry.name}</span>
            </div>
            <span className="text-xs font-semibold text-black">{entry.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

const NotificationActivity = ({ data }: JobActivityProps) => {
  const [timeframe, setTimeframe] = useState<Timeframe>("Year")

  const chartData = useMemo(() => {
    const key = TIMEFRAME_KEY[timeframe]
    return buildChartRows(data?.[key], timeframe)
  }, [data, timeframe])

  const chartItem = [
    { type: "System", fill: "#33ABF7"},
    { type: "Provider", fill: "#33ABF799"},
    {type: "user", fill: "#33ABF733"}
  ]

  return (
    <Card className="h-full border border-black/6 bg-white p-4 rounded-[10px] text-black space-y-6 shadow-none">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 p-0 flex-wrap gap-3">
        <CardTitle className="text-lg font-medium">Notification Activity</CardTitle>
        <div className="flex items-center gap-2 p-1 rounded-full flex-wrap justify-end">
          {(Object.keys(TIMEFRAME_KEY) as Timeframe[]).map((filter) => (
            <Button
              key={filter}
              variant="ghost"
              size="sm"
              onClick={() => setTimeframe(filter)}
              className={`rounded-full px-4 h-8 text-xs font-medium transition-all ${
                filter === timeframe
                  ? "bg-primary text-white pointer-events-none"
                  : "bg-lightblue/50 text-primary border border-primary hover:text-white hover:bg-primary"
              }`}
            >
              {filter}
            </Button>
          ))}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ChartContainer config={chartConfig} className="max-h-[365px] w-full p-0">
        <BarChart
            accessibilityLayer
            data={chartData}
            barCategoryGap="33%"
            barGap={2}
            margin={{ left: 0, right: 12, top: 10, bottom: 0 }}
        >
            <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="rgba(0,0,0,0.08)" />
            <XAxis
              dataKey="label"
              tickLine={false}
              axisLine={false}
              tickMargin={15}
              minTickGap={timeframe === "Day" ? 8 : 24}
              tick={{ fill: "rgba(0,0,0,0.4)", fontSize: 12 }}
            />
            <YAxis
              tickLine={false}
              axisLine={false}
              tickMargin={15}
              allowDecimals={false}
              tick={{ fill: "rgba(0,0,0,0.4)", fontSize: 12 }}
            />
            <ChartTooltip cursor={{ fill: "rgba(0,0,0,0.04)" }} content={<CustomTooltip />} />
            <Bar dataKey="system" fill="#33ABF7" radius={5} maxBarSize={19} />
            <Bar dataKey="provider" fill="#33ABF733" radius={5} maxBarSize={19} />
            <Bar dataKey="user" fill="#33ABF799" radius={5} maxBarSize={19} />
        </BarChart>
        </ChartContainer>
      </CardContent>
        <CardFooter className="max-w-3/4 mx-auto text-base text-black flex items-center gap-6 justify-center flex-wrap pb-6">
            {chartItem?.map((item, index) => (
                <div
                    key={index}
                    className="flex items-center gap-2 leading-none font-medium"
                >
                    <div
                        className="w-2.5 h-2.5 rounded-full"
                        style={{
                            background: item.fill
                        }}
                    />
                    <span className="capitalize text-[#909090] text-xs font-[400]">{item.type}</span>
                </div>
            ))}
        </CardFooter>
    </Card>
  )
}

export default NotificationActivity