import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";
import { toast } from "sonner";
import { getErrorMessage } from "../../../utils/formatter";
import { useQueryClient } from "@tanstack/react-query";
import { resendNotificationCampaign } from "../../../services/notification.service";
import type { NotificationCampaign } from "../../../services/response-structure";
import { X } from "lucide-react";

const ResendNotification = ({ Trigger, notification }:{ Trigger?: React.ReactNode, notification: NotificationCampaign}) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);
    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const handleSubmit = async () => {
        try {
            setLoading(true);
            await resendNotificationCampaign(notification.id);
            await queryClient.invalidateQueries({ queryKey: ["notifications", "notifications-stat"] });
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to resend notification"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Notification Sent"
                description={`The notification has been resent to the selected audience`}
                Icon={getIcon("bell-fill", { color: "#33ABF7" })}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="This notification will be sent again to the selected audience."
                title="Resend Notification"
                onContinue={handleSubmit}
                TriggerButton={Trigger ? Trigger : (
                    <div className="flex items-center gap-[6px]">
                        {getIcon("reshare-alt-outline")}
                        <span className="text-sm font-[500]">Resend Notification</span>
                    </div>
                )}
                Icon={getIcon("bell-fill", { color: "#33ABF7" })}
                buttonTitle="Approve"
                loading={loading}
            />
        </>
    )
}


export default ResendNotification;