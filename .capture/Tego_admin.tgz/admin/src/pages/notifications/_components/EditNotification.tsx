import React, { useState } from "react";
import { Checkbox, DetailsModal, FormField, SuccessModal, Text, Textbox } from "../../../components";
import { Button } from "../../../components/ui/button";
import { Formik, type FormikProps } from "formik";
import { getIcon } from "../../../components/icons/lib";
import { Loader2 } from "lucide-react";

interface NotificationValues {
  audience: string[];
  title: string;
  body: string;
  deliveryChannel: string[];
}

const CUSTOMER_AUDIENCE = [
  { label: "All Customers", value: "all" },
  { label: "New Customers", value: "new" },
  { label: "Active Customers", value: "active" },
  { label: "Inactive Customers", value: "inactive" },
];

const PROVIDER_AUDIENCE = [
  { label: "All Providers", value: "all" },
  { label: "New Providers", value: "new" },
  { label: "Active Providers", value: "active" },
  { label: "Inactive Providers", value: "inactive" },
];

const DELIVERY_CHANNELS = [
  { label: "Push Notification", field: "pushNotification" },
  { label: "In App Notification", field: "inAppNotification" },
  { label: "Email", field: "emailNotification" },
  { label: "SMS", field: "smsNotification" },
];

const EditNotification = ({ type = "customers" }: { type?: "customers" | "providers" }) => {
  const [open, setOpen] = React.useState<boolean>(false);
  const [step, setStep] = useState<"edit" | "success">("edit");
  const [loading, setLoading] = useState(false);

  const audienceOptions = type === "customers" ? CUSTOMER_AUDIENCE : PROVIDER_AUDIENCE;

  const handleSubmit = (values: NotificationValues) => {
    setLoading(true);
    console.log("[EditNotification] submitting:", values);
    setTimeout(() => {
      setLoading(false);
      setOpen(false);
      setStep("success");
    }, 1000);
  };

  const isValid = (values: NotificationValues) =>
    !!values.audience && !!values.title && !!values.body;

  return (
    <>
      <SuccessModal
        title="Notification Updated"
        description="Your updates have been saved successfully. The notification has been updated with the latest changes."
        Icon={getIcon("bell-fill", { color: "#33ABF7" })}
        open={step === "success"}
        onOpenChange={() => setStep("edit")}
        style="min-w-[317px]"
      />

      <Formik<NotificationValues>
        initialValues={{
          audience: [],
          title: "",
          body: "",
          deliveryChannel: [],
        }}
        onSubmit={handleSubmit}
      >
        {({ values, setFieldValue, submitForm }: FormikProps<NotificationValues>) => (
          <DetailsModal
            title="Edit Notification"
            TriggerButton={(
              <div className="flex items-center gap-[6px] cursor-pointer">
                {getIcon("pencil-edit", { color: "#000000" })}
                <span className="text-sm font-[500]">Edit Notification</span>
              </div>
            )}
            ActionButton={(
              <Button
                className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                onClick={submitForm}
                disabled={loading || !isValid(values)}
              >
                {loading
                  ? <Loader2 className="animate-spin" />
                  : <span>Save Changes</span>
                }
              </Button>
            )}
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setStep("edit");
            }}
          >
            <div className="px-[16px] space-y-[20px]">
              <div className="flex flex-col gap-[18px]">

                {/* Campaign Information */}
                <div className="bg-[#F9F9F9] rounded-[6px]">
                  <div className="p-[16px]">
                    <Text
                      title="Campaign Information"
                      className="text-[13px] font-[600]"
                      type="h5"
                    />
                  </div>
                  <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                    <FormField
                      name="title"
                      placeholder="Title"
                      className="shadow-none"
                    />
                    <Textbox
                      name="body"
                      placeholder="Message"
                    />
                  </div>
                </div>

                {/* Audience */}
                <div className="bg-[#F9F9F9] rounded-[6px]">
                  <div className="p-[16px]">
                    <Text
                      title="Audience"
                      className="text-[13px] font-[600]"
                      type="h5"
                    />
                  </div>
                  <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                    {audienceOptions.map((option) => (
                      <Checkbox
                        key={option.value}
                        label={option.label}
                        checked={values.audience.includes(option.value)}
                        onChange={() =>
                          setFieldValue(
                            option.value,
                            !values[option.value as keyof NotificationValues],
                          )
                        }
                      />
                    ))}
                  </div>
                </div>

                {/* Delivery Channel */}
                <div className="bg-[#F9F9F9] rounded-[6px]">
                  <div className="p-[16px]">
                    <Text
                      title="Delivery Channel"
                      className="text-[13px] font-[600]"
                      type="h5"
                    />
                  </div>
                  <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                    {DELIVERY_CHANNELS.map((channel) => (
                      <Checkbox
                        key={channel.field}
                        label={channel.label}
                        checked={values.deliveryChannel.includes(channel.field)}
                        onChange={() =>
                          setFieldValue(
                            channel.field,
                            !values[channel.field as keyof NotificationValues],
                          )
                        }
                      />
                    ))}
                  </div>
                </div>

                {/* Validation hint */}
                {!isValid(values) && (
                  <p className="text-[12px] text-[#00000066] text-center">
                    Fill in all required fields to save changes.
                  </p>
                )}

              </div>
            </div>
          </DetailsModal>
        )}
      </Formik>
    </>
  );
};

export default EditNotification;