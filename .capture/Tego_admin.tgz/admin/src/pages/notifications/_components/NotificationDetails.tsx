import React from "react";
import { DetailsModal, ModalFieldItem, Text } from "../../../components";
import { ChevronDown, ChevronUp } from "lucide-react";
import ResendNotification from "./ResendNotification";
import { Button } from "../../../components/ui/button";
import { getIcon } from "../../../components/icons/lib";
import type { NotificationCampaign } from "../../../services/response-structure";
import { formatCreatedAt } from "../../../utils/formatter";

const NotificationDetails = ({ notification } : { notification:  NotificationCampaign }) => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["overview", "content"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    return (
        <DetailsModal
            title="Notification Details"
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                   {getIcon("bell-outline", { color: "#000000" })}
                    <span className="text-sm font-[500]">View Notification</span>
                </div>
            )}
            ActionButton={(
                <ResendNotification
                    Trigger={(
                        <Button className="rounded-full h-12 min-w-[169px]">
                            Resend
                        </Button>
                    )}
                    notification={notification}
                />
            )}
            open={open}
            onOpenChange={setOpen}
        >
            <div className="px-[16px] space-y-[20px]">

                <div className="flex flex-col gap-[18px]">
                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("overview")}
                        >
                            <Text title="Campaign Overview" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["overview"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["overview"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Campaign Name"
                                    value={notification.title}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Status"
                                    value={"Delivered"}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Audience"
                                    value={notification.audience}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Created Date"
                                    value={formatCreatedAt(notification.starts_at)}
                                />
                                <ModalFieldItem
                                    className="flex-row items-center justify-between"
                                    label="Recipients"
                                    value={notification.sent_count}
                                />
                            </div>
                        )}
                    </div>

                    <div className="bg-[#F9F9F9] rounded-[6px]">
                        <button
                            className="flex items-center justify-between w-full p-[16px]"
                            onClick={() => toggleSection("content")}
                        >
                            <Text title="Message Content" className="text-[13px] font-[600]" type="h5" />

                            <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                {openSections["content"]
                                    ? <ChevronUp className="size-4 text-primary" />
                                    : <ChevronDown className="size-4 text-primary" />
                                }
                            </div>
                        </button>
                        {openSections["content"] && (
                            <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                <div className="border border-[#E3E3E3] p-[20px] rounded-[6px]">
                                    <Text
                                        title={notification.body}
                                        type="p"
                                        className=""
                                    />
                                </div>
                            </div>
                        )}
                    </div>
                </div>

            </div>
        </DetailsModal>
    )
}


export default NotificationDetails;