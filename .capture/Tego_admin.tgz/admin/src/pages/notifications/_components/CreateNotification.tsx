import React, { useState } from "react";
import { Checkbox, DetailsModal, FormField, SuccessModal, Text, Textbox } from "../../../components";
import { Send, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Formik, type FormikProps } from "formik";
import { getIcon } from "../../../components/icons/lib";
import { createNotification, type NotificationData } from "../../../services/notification.service";
import type { NOTIFICATION_CHANNELS } from "../../../services/types";
import { getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

const AUDIENCE_LABELS: Record<string, string> = {
  customers: "Customers",
  providers: "Providers",
  all: "Both Customer & Provider",
};

const REPEAT_LABELS: Record<string, string> = {
  none: "None",
  daily: "Daily",
  weekly: "Weekly",
  monthly: "Monthly",
};

const ReviewSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="bg-[#F9F9F9] rounded-[6px] overflow-hidden">
    <div className="p-[16px]">
      <Text title={title} className="text-[13px] font-[600]" type="h5" />
    </div>
    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px]">
      {children}
    </div>
  </div>
);


const CreateNotification = () => {
  const queryClient = useQueryClient();
  const [open, setOpen] = React.useState<boolean>(false);
  const [step, setStep] = useState<"create" | "review" | "success">("create");


  const [loading, setLoading] = useState(false);
  const handleSubmit = async (values: NotificationData) => {
    try {
        setLoading(true);
        await createNotification(values);
        await queryClient.invalidateQueries({ queryKey: ["notifications", "notifications-stat"] });
        setStep("success");
        setOpen(false);
    } catch (error) {
        toast.error(getErrorMessage(error, "Failed to create notification"), {
            icon: (
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                    <X className="size-4 text-primary" />
                </div>
            )
        })
    } finally {
        setLoading(false);
    }
  }

  const getDeliveryChannels = (values: string[]): string[] => {
    const channels = [];
    if (values.includes("PUSH")) channels.push("Push Notification");
    if (values.includes("IN_APP")) channels.push("In-App Notification");
    if (values.includes("EMAIL")) channels.push("Email");
    if (values.includes("SMS")) channels.push("SMS");
    return channels;
  };

  return (
    <>
      <SuccessModal
        title="Notification Sent"
        description="Your notification has been successfully sent to the selected audience"
        Icon={getIcon("bell-fill", { color: "#33ABF7" })}
        open={step === "success"}
        onOpenChange={() => setStep("create")}
        style="min-w-[317px]"
      />
      <Formik<NotificationData>
        initialValues={{
          audience: "ALL",
          title: "",
          body: "",
          repeat: "NONE",
          channels: [],
          starts_at: "",
        }}
        onSubmit={(values) => handleSubmit(values)}
      >
        {({ values, setFieldValue, submitForm }: FormikProps<NotificationData>) => (
          <DetailsModal
            title={step === "review" ? "Review Notification" : "Create Notification"}
            TriggerButton={(
              <Button
                size="lg"
                variant="secondary"
                className="rounded-full flex items-center gap-[4px] bg-black hover:bg-black"
              >
                <Send />
                <span className="font-[600] text-[13px]">Create Notification</span>
              </Button>
            )}
            ActionButton={
              step === "create" ? (
                <Button
                  className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                  onClick={() => setStep("review")}
                  disabled={!values.audience || !values.title || !values.body}
                >
                  <span>Review</span>
                </Button>
              ) : (
                <Button
                  className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                  onClick={submitForm}
                  disabled={loading}
                >
                  <Send size={16} />
                  <span>{loading ? "Sending..." : "Send Notification"}</span>
                </Button>
              )
            }
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setStep("create"); // reset step on close
            }}
          >
            {step === "create" ? (
              /* ── CREATE STEP ─────────────────────────────────── */
              <div className="px-[16px] space-y-[20px]">
                <div className="flex flex-col gap-[18px]">

                  {/* Audience */}
                  <div className="bg-[#F9F9F9] rounded-[6px]">
                    <button className="flex items-center justify-between w-full p-[16px]">
                      <Text title="Choose who should receive this notification" className="text-[13px] font-[600]" type="h5" />
                    </button>
                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                      {[
                        { label: "Customers", value: "CUSTOMERS" },
                        { label: "Providers", value: "PROVIDERS" },
                        { label: "Both Customer & Provider", value: "ALL" },
                      ].map((option) => (
                        <Checkbox
                          key={option.value}
                          label={option.label}
                          checked={values.audience === option.value}
                          onChange={() => setFieldValue("audience", option.value)}
                          type="radio"
                        />
                      ))}
                    </div>
                  </div>

                  {/* Delivery Channel */}
                  <div className="bg-[#F9F9F9] rounded-[6px]">
                    <button className="flex items-center justify-between w-full p-[16px]">
                      <Text title="Delivery Channel" className="text-[13px] font-[600]" type="h5" />
                    </button>
                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                      {[
                        { label: "Push Notification", field: "PUSH" },
                        { label: "In App Notification", field: "IN_APP" },
                        { label: "Email", field: "EMAIL" },
                        { label: "SMS", field: "SMS" },
                      ].map((channel) => (
                        <Checkbox
                          key={channel.field}
                          label={channel.label}
                          checked={values.channels.includes(channel.field as NOTIFICATION_CHANNELS)}
                          onChange={() => {

                          }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Repeat */}
                  <div className="bg-[#F9F9F9] rounded-[6px]">
                    <button className="flex items-center justify-between w-full p-[16px]">
                      <Text title="Repeat (optional)" className="text-[13px] font-[600]" type="h5" />
                    </button>
                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                      {["NONE", "DAILY", "WEEKLY", "MONTHLY"].map((opt) => (
                        <Checkbox
                          key={opt}
                          label={REPEAT_LABELS[opt]}
                          checked={values.repeat === opt}
                          onChange={() => setFieldValue("repeat", opt)}
                          type="radio"
                        />
                      ))}
                    </div>
                  </div>

                  {/* Notification Details */}
                  <div className="bg-[#F9F9F9] rounded-[6px]">
                    <button className="flex items-center justify-between w-full p-[16px]">
                      <Text title="Notification Details" className="text-[13px] font-[600]" type="h5" />
                    </button>
                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                      <FormField name="title" placeholder="Title" className="shadow-none" />
                      <Textbox name="body" placeholder="Message" />
                    </div>
                  </div>

                </div>
              </div>
            ) : (
              /* ── REVIEW STEP ─────────────────────────────────── */
              <div className="px-[16px] space-y-[16px]">

                {/* Audience */}
                <ReviewSection title="Audience">
                  <span className="text-[13px] text-black/50 font-[500]">
                    {
                      values.audience
                        ? AUDIENCE_LABELS[values.audience.toLowerCase()]
                          : "-"
                    }
                  </span>
                </ReviewSection>

                {/* Notification Details */}
                <ReviewSection title="Notification Details">
                  <div className="space-y-[16px]">
                    <FormField name="title" placeholder="Title" className="shadow-none" />
                    <Textbox name="body" placeholder="Message" />
                  </div>
                </ReviewSection>

                {/* Delivery Channels */}
                <ReviewSection title="Delivery Channels">
                  {getDeliveryChannels(values.channels).length > 0 ? (
                    <div className="space-y-[16px]">
                      {getDeliveryChannels(values.channels).map((channel) => (
                        <Checkbox
                          label={channel}
                          checked={true}
                          onChange={() => {}}
                        />
                      ))}
                    </div>
                  ) : (
                    <span className="text-[13px] text-[#00000088]">No channels selected</span>
                  )}
                </ReviewSection>

                {/* Repeat */}
                <ReviewSection title="Repeat">
                  <Checkbox
                    label={REPEAT_LABELS[values.repeat]}
                    checked={true}
                    onChange={() => {}}
                    type="radio"
                  />
                </ReviewSection>

              </div>
            )}
          </DetailsModal>
        )}
      </Formik>
    </>
  );
};

export default CreateNotification;