import React, { useState } from "react";
import { Checkbox, DetailsModal, SuccessModal, Text } from "../../../components";
import { Button } from "../../../components/ui/button";
import { Formik, type FormikProps } from "formik";
import { getIcon } from "../../../components/icons/lib";
import { Loader2 } from "lucide-react";
interface NotificationValues {
  channels: string[];
}

const DELIVERY_CHANNELS = [
  { label: "Push Notification", field: "pushNotification" },
  { label: "In App Notification", field: "inAppNotification" },
  { label: "Email", field: "emailNotification" },
];

const ResendSystemNotification = () => {
  const [open, setOpen] = React.useState<boolean>(false);
  const [step, setStep] = useState<"edit" | "success">("edit");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (values: NotificationValues) => {
    setLoading(true);
    console.log("[EditNotification] submitting:", values);
    setTimeout(() => {
      setLoading(false);
      setOpen(false);
      setStep("success");
    }, 1000);
  };

  return (
    <>
      <SuccessModal
        title="Notification Updated"
        description="Your updates have been saved successfully. The notification has been updated with the latest changes."
        Icon={getIcon("bell-fill", { color: "#33ABF7" })}
        open={step === "success"}
        onOpenChange={() => setStep("edit")}
        style="min-w-[317px]"
      />

      <Formik<NotificationValues>
        initialValues={{
          channels: []
        }}
        onSubmit={handleSubmit}
      >
        {({ values, setFieldValue, submitForm }: FormikProps<NotificationValues>) => (
          <DetailsModal
            title="Resend Notification"
            description="This notification will be sent again to the original recipients. Please confirm before continuing."
            TriggerButton={(
                <div className="flex items-center gap-[6px]">
                    {getIcon("reshare-alt-outline")}
                    <span className="text-sm font-[500]">Resend Notification</span>
                </div>
            )}
            ActionButton={(
              <Button
                className="rounded-full flex items-center gap-[4px] h-12 min-w-[169px]"
                onClick={submitForm}
                disabled={loading}
              >
                {loading
                  ? <Loader2 className="animate-spin" />
                  : <span>Resend Notification</span>
                }
              </Button>
            )}
            open={open}
            onOpenChange={(isOpen) => {
              setOpen(isOpen);
              if (!isOpen) setStep("edit");
            }}
          >
            <div className="px-[16px] space-y-[20px]">
              <div className="flex flex-col gap-[18px]">
                {/* Audience */}
                <div className="bg-[#F9F9F9] rounded-[6px]">
                  <div className="p-[16px]">
                    <Text
                      title="Recipients"
                      className="text-[13px] font-[600]"
                      type="h5"
                    />
                  </div>
                  <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                    <span className="text-[13px] font-[500] text-black/50">2460 Customers</span>
                  </div>
                </div>

                {/* Delivery Channel */}
                <div className="bg-[#F9F9F9] rounded-[6px]">
                  <div className="p-[16px]">
                    <Text
                      title="Channels"
                      className="text-[13px] font-[600]"
                      type="h5"
                    />
                  </div>
                  <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                    {DELIVERY_CHANNELS.map((channel) => (
                      <Checkbox
                        key={channel.field}
                        label={channel.label}
                        checked={values.channels.includes(channel.field)}
                        onChange={() =>
                          setFieldValue(
                            "channels",
                            !values[channel.field as keyof NotificationValues],
                          )
                        }
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </DetailsModal>
        )}
      </Formik>
    </>
  );
};

export default ResendSystemNotification;