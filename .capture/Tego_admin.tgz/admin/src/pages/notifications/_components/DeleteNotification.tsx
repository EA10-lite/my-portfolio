import React, { useState } from "react";
import { SuccessModal } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import ConfirmationModal from "../../../components/main/ConfirmationModal";

const DeleteNotification = () => {
    const [open, setOpen] = React.useState<boolean>(false);

    const [loading, setLoading] = useState(false);
    const handleSubmit = () => {
        setLoading(true);
        setTimeout(() => {
            setLoading(false);
            setOpen(false);        // close the sheet
            setSuccessOpen(true)   // open success modal
        }, 1000)
    }

    const [successOpen, setSuccessOpen] = React.useState<boolean>(false);

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Notification Deleted"
                description={`This notification has been deleted successfully.`}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
            />

            <ConfirmationModal
                open={open}
                onOpenChange={setOpen}
                description="Are you sure you want to remove this notification from the notification history?"
                title="Delete Notification"
                onContinue={handleSubmit}
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("trash-fill", { color: "#D8232A" })}
                        <span className="text-sm font-[500] text-destructive">Delete Record</span>
                    </div>
                )}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
                buttonTitle="Disable Record"
                buttonType="destructive"
                loading={loading}
            />
        </>
    )
}


export default DeleteNotification;