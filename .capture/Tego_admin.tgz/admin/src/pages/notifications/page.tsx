import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt } from "../../utils/formatter";
import NotificationDetails from "./_components/NotificationDetails";
import CreateNotification from "./_components/CreateNotification";
import { useQueries } from "@tanstack/react-query";
import { getNotifications, getNotificationStat } from "../../services/notification.service";
import type { NotificationCampaign } from "../../services/response-structure";
import ResendNotification from "./_components/ResendNotification";
import type { FilterValues } from "../../components/main/FilterContent";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const systemNotificationColumn: ColumnDef<NotificationCampaign>[] = [
    {
        accessorKey: "title",
        header: "Notification",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.title}</span>
        )
    },
    {
        accessorKey: "trigger",
        header: "Trigger",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("trigger")}</span>
        )
    },
    {
        accessorKey: "audience",
        header: "Audience",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.audience}</span>
        )
    },
    {
        accessorKey: "createdAt",
        filterFn: dateFilterFn,
        header: "Sent",
        cell: ({ row }) => (
            <span className="">
                {formatCreatedAt(row.original.starts_at)}
            </span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "sent") badgeVariant = "primary";
            if (status.toLowerCase() === "delivered") badgeVariant = "success";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {

        header: "Action",
        cell: ({ row }) => (
            <div className="flex justify-start">
                <TableAction
                    items={[
                        {
                            label: "View Notification",
                            content: <NotificationDetails notification={row.original} />
                        },
                        {
                            label: "Resend Notification",
                            content: <ResendNotification notification={row.original} />
                        }
                    ]}
                />
            </div>
        )
    }
]

const Notifications = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});

    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data: stat,
            isLoading: isStatLoading,
        },
        {
            data,
            isLoading,
            isError,
            error,
        },
    ] = useQueries({
        queries: [
            {
                queryKey: ["notifications-stats"],
                queryFn: getNotificationStat,
            },
            {
                queryKey: [
                    "notifications",
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters,
                ],
                queryFn: () =>
                    getNotifications({
                        page: pagination.pageIndex + 1,
                        limit: pagination.pageSize,
                        search,
                        ...filters,
                    }),
            },
        ],
    });

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Notifications"
                    description="Manage announcements, alerts, campaigns, and platform communications.."
                    metrics={[
                        {
                            label: "Notifications Sent",
                            value: stat?.campaign_notifications_sent?.value ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.campaign_notifications_sent?.monthly_change_pct ?? 0
                        },
                        {
                            label: "Scheduled Messages",
                            value: stat?.scheduled_notifications_sent?.value ?? 0,
                            filter: "All time",
                            percentageIncrease: stat?.scheduled_notifications_sent?.monthly_change_pct ?? 0
                        },
                        {
                            label: "Delivery Rate",
                            value: stat?.delivery_rate_pct?.value ? `${stat?.delivery_rate_pct?.value}%` : 0,
                            filter: "All time",
                            percentageIncrease: stat?.delivery_rate_pct?.monthly_change_pct ?? 0
                        },
                        {
                            label: "Open Rate",
                            value: stat?.open_rate_pct?.value ? `${stat?.open_rate_pct?.value}%` : 0,
                            filter: "All time",
                            percentageIncrease: stat?.open_rate_pct?.monthly_change_pct ?? 0
                        },
                    ]}
                    triggerBtn={<CreateNotification />}
                    loading={isStatLoading}
                />
            </div>
            <div className="page-body space-y-[20px]">
                <ReusableTable
                    title="System Notifications"
                    data={isError ? [] : data?.campaigns || []}
                    columns={systemNotificationColumn}
                    manualPagination={true}
                    pageCount={data?.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    emptyMessage={{
                        description: isError ? error.name : "Notification performance metrics will appear after sending.",
                        title: isError ? error.message : "No notification sent",
                        icon: "bell-outline"
                    }}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({
                            ...prev,
                            period: [period],
                        }));
                    }}
                    filterTitle="Filter System Notifications"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Notification Status",
                                    key: "status",
                                    options: [
                                        { label: "All", value: "all" },
                                        { label: "Delivered", value: "sent" },
                                        { label: "Scheduled", value: "scheduled" },
                                        { label: "Inactive", value: "inactive" },
                                    ],
                                },
                                {
                                    label: "Channels",
                                    key: "channels",
                                    options: [
                                        { label: "In App", value: "IN_APP" },
                                        { label: "Push", value: "PUSH" },
                                        { label: "Email", value: "EMAIL" },
                                        { label: "SMS", value: "SMS" },
                                    ],
                                },
                                {
                                    label: "Submitted By",
                                    key: "audience",
                                    options: [
                                        { label: "All", value: "ALL" },
                                        { label: "Customer", value: "CUSTOMERS" },
                                        { label: "Provider", value: "PROVIDERS" },
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Notifications;

