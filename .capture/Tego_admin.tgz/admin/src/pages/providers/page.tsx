import { FilterContent, ReusableTable, TableAction } from "../../components";
import { type ColumnDef, type PaginationState } from "@tanstack/react-table";
import { Badge } from "../../components/ui/badge";
import { useState } from "react";
import { PageHeader } from "../../components/shared";
import { dateFilterFn, formatCreatedAt, formatDateString, getFilterLabel } from "../../utils/formatter";
import { Link } from "react-router-dom";
import { getIcon } from "../../components/icons/lib";
import DeleteProfile from "./_components/DeleteProfile";
import SuspendProvider from "./_components/SuspendProvider";
import VerifyProvider from "./_components/VerifyProvider";
import ReactivateProvider from "./_components/ReactivateProvider";
import { useQueries } from "@tanstack/react-query";
import { getProviders } from "../../services/users.service";
import type { Provider } from "../../services/response-structure";
import type { FilterValues } from "../../components/main/FilterContent";
import { getCategories } from "../../services/category.service";
import { exportToCSV } from "../../utils/exportToCSV";
import { useDebouncedSearch } from "../../hooks/useDebounceSearch";

const columns: ColumnDef<Provider>[] = [
    {
        accessorKey: "name",
        header: "Provider",
        cell: ({ row }) => (
            <span className="text-sm">{row.getValue("name")}</span>
        )
    },
    {
        accessorKey: "service_category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("service_category")}</span>
        )
    },
    {
        accessorKey: "subscription",
        header: "Subscription",
        cell: ({ row }) => (
            <span className="capitalize">{row.getValue("subscription")}</span>
        )
    },
    {
        accessorKey: "last_active",
        header: "Last Active",
        filterFn: dateFilterFn,
        cell: ({ row }) => (
            <span className="">
                {formatCreatedAt(row.getValue("last_active"))}
            </span>
        )
    },
    {
        accessorKey: "status",
        header: "Status",
        cell: ({ row }) => {
            const status = row.getValue("status") as string;

            let badgeVariant = "secondary";
            if (status.toLowerCase() === "active") badgeVariant = "success";
            if (status.toLowerCase() === "inactive" || status.toLowerCase() === "non active") badgeVariant = "destructive";
            if (status.toLowerCase() === "suspended") badgeVariant = "pending";
            return (
                <Badge
                    className={`hover:bg-secondary-foreground/80 font-normal capitalize`}
                    variant={badgeVariant as "default" | "success" | "primary" | "pending" | "destructive"}
                >
                    {status}
                </Badge>
            )
        }
    },
    {
        header: "Action",
        cell: ({ row }) => {
            const status = row.original.status?.toLowerCase()
            const isVerified = row.original.verification?.status?.toLowerCase() as string;
            return (
                <div className="flex justify-start">
                    <TableAction
                        items={[
                            {
                                label: "view",
                                content: (
                                    <Link to={`/providers/${row.original.id}`} className="flex items-center gap-[6px]">
                                        {getIcon("user-outline", { color: "#000000" })}
                                        <span className="text-sm font-[500]">View Profile</span>
                                    </Link>
                                ),
                            },
                            {
                                label: "verify",
                                content: isVerified === "approved"
                                    ? null
                                    : <VerifyProvider provider={row.original} />,
                            },
                            {
                                label: "suspend",
                                content: status === "suspended"
                                    ? null
                                    : <SuspendProvider provider={row.original} />,
                            },
                            {
                                label: "reactivate",
                                content: status === "suspended"
                                    ? <ReactivateProvider provider={row.original} />
                                    : null,
                            },
                            {
                                label: "delete",
                                content: <DeleteProfile provider={row.original} />,
                            },
                        ]}
                    />
                </div>
            )
        }
    }
]

const Providers = () => {
    const search = useDebouncedSearch(500);
    const [filters, setFilters] = useState<FilterValues>({});
    const [pagination, setPagination] = useState<PaginationState>({
        pageIndex: 0,
        pageSize: 10,
    });

    const [
        {
            data,
            isLoading,
            isError,
            error,
        },
        {
            data: categories,
        }
    ] = useQueries({
        queries: [
            {
                queryKey: [
                    'providers',
                    pagination.pageIndex,
                    pagination.pageSize,
                    search,
                    filters
                ],
                queryFn: () => getProviders({
                    page: pagination.pageIndex + 1,
                    limit: pagination.pageSize,
                    search,
                    ...filters
                })
            },
            {
                queryKey: [
                    "categories",
                ],
                queryFn: () =>
                    getCategories({
                        page: 1,
                        limit: 100,
                    }),
            },
        ],
    });

    const handleExport = () => {
        if (!data?.full_provider_list) return;

        const dataToExport = data.full_provider_list.map((user: Provider) => ({
            "Name": user.name,
            "Email": user.email,
            "Phone Number": user.phone_number,
            "Status": user.status,
            "Service": user.service_category,
            "Subscription": user.subscription,
            "Created At": formatDateString(user.created_at),
            "Last Active": formatDateString(user.last_active),
        }));

        exportToCSV(dataToExport, "providers");
    };

    return (
        <div className="services space-y-[20px] px-6">
            <div className="page-header">
                <PageHeader
                    title="Providers"
                    description="Manage provider operations, subscriptions, verification, and marketplace performance."
                    metrics={[
                        {
                            label: "Total Providers",
                            value: data?.total_providers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase.total_providers ?? 0
                        },
                        {
                            label: "Active Providers",
                            value: data?.active_providers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase.active_providers ?? 0
                        },
                        {
                            label: "Inactive Providers",
                            value: data?.inactive_providers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase.inactive_providers ?? 0
                        },
                        {
                            label: "Verified Providers",
                            value: data?.verified_providers ?? 0,
                            filter: getFilterLabel(filters),
                            percentageIncrease: data?.current_month_percentage_increase.verified_providers ?? 0
                        },
                    ]}
                    hasDownload={true}
                    onDownload={handleExport}
                    loading={isLoading}
                />
            </div>
            <div className="page-body">
                <ReusableTable
                    title="Providers"
                    data={isError ? [] : data?.full_provider_list || []}
                    columns={columns}
                    manualPagination={true}
                    pageCount={data?.pagination.total_pages}
                    pagination={pagination}
                    onPaginationChange={setPagination}
                    isLoading={isLoading}
                    onDateFilterChange={(period) => {
                        setPagination((prev) => ({
                            ...prev,
                            pageIndex: 0,
                        }));
                        setFilters((prev) => ({ ...prev, period: [period] })); // ✅ period is PERIOD type
                    }}
                    emptyMessage={{
                        title: isError ? error.name : "No providers available",
                        description: isError ? error.message : "Verified and subscribed providers will appear here.",
                        icon: "user-outline",
                    }}
                    filterTitle="Filter Providers"
                    filterContent={(
                        <FilterContent
                            filters={[
                                {
                                    label: "Category",
                                    key: "category",
                                    options: categories?.categories.map(category => ({
                                        label: category.name,
                                        value: category.id,
                                    })) || [],
                                },
                                {
                                    label: "Subscription",
                                    key: "subscription",
                                    options: [
                                        { label: "Free", value: "FREE" },
                                        { label: "Pro Monthly", value: "PRO_ANNUAL" },
                                        { label: "Pro Yearly", value: "PRO_ANNUAL" }
                                    ],
                                },
                                {
                                    label: "Verification Status",
                                    key: "verification",
                                    options: [
                                        { label: "Verified", value: "verified" },
                                        { label: "Pending", value: "pending" },
                                        { label: "Rejected", value: "rejected" }
                                    ],
                                },
                                {
                                    label: "Provider Status",
                                    key: "status",
                                    options: [
                                        { label: "Active", value: "active" },
                                        { label: "Inactive", value: "inactive" },
                                        { label: "Suspended", value: "suspended" }
                                    ],
                                },
                            ]}
                            values={filters}
                            onApply={(selected) => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters(selected);
                            }}
                            onReset={() => {
                                setPagination((prev) => ({
                                    ...prev,
                                    pageIndex: 0,
                                }));
                                setFilters({});
                            }}
                        />
                    )}
                />
            </div>
        </div>
    )
}

export default Providers;

