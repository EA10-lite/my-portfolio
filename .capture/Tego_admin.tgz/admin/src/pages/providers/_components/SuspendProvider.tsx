import { useState } from "react";
import type { Provider } from "../../../services/response-structure";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import { formatCreatedAt } from "../../../utils/formatter";
import { suspendProvider } from "../../../services/users.service";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

const SuspendProvider = ({ provider }: { provider: Provider }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "reason", "settings"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }


    const [selectedSettings, setSelectedSettings] = useState<string[]>([])
    const toggleSettingsOption = (option: string) => {
        setSelectedSettings((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        )
    }

    const [selected, setSelected] = useState<string[]>([])
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        )
    }

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleSuspend = async () => {
        try {
            setLoading(true);
            await suspendProvider(provider.id, selected, selectedSettings);
            await queryClient.invalidateQueries({ queryKey: ["providers"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            console.log("error:", error);
            toast.error("Failed to suspend provider", {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Provider Suspended"
                description={`${provider.name} has been successfully suspended.`}
                Icon={getIcon("warning-fill", { color: "#D8232A" })}
            />
            <DetailsModal
                title="Suspend Provider"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("warning-outline", { color: "#000000" })}
                        <span className="text-sm font-[500]">Suspend Provider</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="destructive"
                        onClick={handleSuspend}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Suspend Provider</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={provider.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={provider.name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title={provider.service_category}
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Provider Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Category"
                                        value={provider.service_category}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Subscription"
                                        value={provider.subscription}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={"07061326122"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(provider.created_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={formatCreatedAt(provider.last_active)}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Suspension Reason" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["reason"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Fraudulent activity",
                                        "Verification concerns",
                                        "Poor service quality",
                                        "Customer compliants",
                                        "Other"
                                    ].map(option => {
                                        const isChecked = selected?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                label={option}
                                                checked={isChecked}
                                                onChange={() => toggleOption(option)}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("settings")}
                            >
                                <Text title="Suspension Settings" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["settings"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["settings"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Notify provider immediately",
                                        "Disable service listings",
                                        "Pause subscription benefits",
                                        "Hide profile from search",
                                    ].map(option => {
                                        const isChecked = selectedSettings?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                onChange={() => toggleSettingsOption(option)}
                                                checked={isChecked}
                                                label={option}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default SuspendProvider;