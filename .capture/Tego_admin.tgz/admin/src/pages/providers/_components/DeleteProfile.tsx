import React, { useState } from "react";
import type { Provider } from "../../../services/response-structure";
import { Checkbox, DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, Trash2, X } from "lucide-react";
import { formatCreatedAt, getErrorMessage } from "../../../utils/formatter";
import { toast } from "sonner";
import { deleteProvider } from "../../../services/users.service";
import { useQueryClient } from "@tanstack/react-query";

const DeleteProfile = ({ provider }: { provider: Provider }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = React.useState<boolean>(false);

    const [openSections, setOpenSections] = React.useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "reason", "settings"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [selected, setSelected] = useState<string[]>([]);
    const toggleOption = (option: string) => {
        setSelected((prev) =>
            prev.includes(option)
            ? prev.filter((item) => item !== option)
            : [...prev, option]
        );
    };

    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleDelete = async () => {
        try {
            setLoading(true);
            await deleteProvider(provider.id, selected);
            await queryClient.invalidateQueries({ queryKey: ["providers"] });
            setSuccessOpen(true);
            setOpen(false);
        } catch (error) {
            toast.error(getErrorMessage(error, "Failed to delete provider account"), {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Account deleted"
                description={"The provider account has been permanently removed."}
                Icon={getIcon("trash-fill", { color: "#D8232A" })}
            />
            <DetailsModal
                title="Delete Provider Account"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        <Trash2 className="text-destructive" />
                        <span className="text-sm font-[500] text-destructive">Delete Profile</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="destructive"
                        onClick={handleDelete}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Delete Account</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={provider.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={provider.name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title={provider.service_category}
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Provider Summary Card" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Category"
                                        value={provider.service_category}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Subscription"
                                        value={provider.subscription}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={"07061326122"}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(provider.last_active)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={"2 Hours Ago"}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Reason for Deleting" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["reason"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        "Fraudulent",
                                        "Inactive Account",
                                        "Duplicate Account",
                                        "Marketplace violation",
                                        "Provider Request",
                                    ].map(option => {
                                        const isChecked = selected?.includes(option) ?? false
                                        return (
                                            <Checkbox
                                                key={option}
                                                label={option}
                                                checked={isChecked}
                                                onChange={() => toggleOption(option)}
                                            />
                                        )
                                    })}
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("settings")}
                            >
                                <Text title="Suspension Settings" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["settings"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["settings"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    {[
                                        "Remove profile access",
                                        "Remove active listings",
                                        "Cancel subscriptions",
                                        "Archive job history",
                                        "Remove marketplace visiblity",
                                    ].map(option => {
                                        return (
                                            <div
                                                key={option}
                                                className="flex items-center gap-[8px]"
                                            >
                                                {getIcon("success-fill")}
                                                <Text title={option} className="text-[13px] font-[500] text-black/50" type="h5" />
                                            </div>
                                        )
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default DeleteProfile;