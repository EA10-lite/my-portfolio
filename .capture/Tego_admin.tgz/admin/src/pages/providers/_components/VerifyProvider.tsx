import React, { useState } from "react";
import { DetailsModal, ModalFieldItem, SuccessModal, Text } from "../../../components";
import { getIcon } from "../../../components/icons/lib";
import { Button } from "../../../components/ui/button";
import { ChevronDown, ChevronUp, Loader2, X } from "lucide-react";
import { formatCreatedAt } from "../../../utils/formatter";
import DocumentModal from "./DocumentModal";
import type { Provider } from "../../../services/response-structure";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { approveVerification, rejectVerification } from "../../../services/verification.service";

const REASONS = [
    { label: "Invalid ID documents", value: "INVALID_ID_DOCUMENTS" },
    { label: "Mismatched selfie verification", value: "MISMATCHED_SELFIE_VERIFICATION" },
    { label: "Unclear business document", value: "UNCLEAR_BUSINESS_DOCUMENT" },
    { label: "Fraud concern", value: "FRAUD_CONCERN" },
    { label: "Incomplete submission", value: "INCOMPLETE_SUBMISSION" },
]

const VerifyProvider = ({ provider }: { provider: Provider }) => {
    const queryClient = useQueryClient();
    const [open, setOpen] = useState<boolean>(false);
    const [documentModal, setDocumentModal] = useState<boolean>(false);

    const [openSections, setOpenSections] = useState<Record<string, boolean>>(
        () => Object.fromEntries(["summary", "decision", "documents", "reason"].map(f => [f, true]))
    );

    const toggleSection = (key: string) => {
        setOpenSections(prev => ({ ...prev, [key]: !prev[key] }))
    }

    const [decision, setDecision] = React.useState<string | null>(null);
    const [reason, setReason] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false);
    const [successOpen, setSuccessOpen] = useState<boolean>(false);
    const handleVerify = async () => {
        try {
            setLoading(true);
            if(decision === "approve") {
                await approveVerification(provider.id);
            }
            else if (decision === "reject") {
                await rejectVerification(provider.id, { reason });
            }
            await queryClient.invalidateQueries({ queryKey: ["providers"] });
            setSuccessOpen(true);
            setOpen(false);
            setDecision(null);
            setReason("");
        } catch (error) {
            console.log("error:", error);
            toast.error("Failed to verify provider", {
                icon: (
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white border-[0.5px] border-primary/10">
                        <X className="size-4 text-primary" />
                    </div>
                )
            })
        } finally {
            setLoading(false);
        }
    }

    return (
        <>
            <SuccessModal
                open={successOpen}
                onOpenChange={() => setSuccessOpen(false)}
                title="Provider Verified"
                description={`Provider can now publish services and receive requests.`}
                Icon={getIcon("verified")}
            />
            <DetailsModal
                title="Verify Provider"
                TriggerButton={(
                    <div className="flex items-center gap-[6px]">
                        {getIcon("pencil-edit", { color: "#000000" })}
                        <span className="text-sm font-[500]">Verify Provider</span>
                    </div>
                )}
                ActionButton={
                    <Button
                        className="rounded-full h-12 min-w-[169px]"
                        variant="primary"
                        onClick={handleVerify}
                    >
                        { loading ? <Loader2 className="animate-spin delay-150ms" /> : (
                            <span>Submit</span>
                        )}
                    </Button>
                }
                open={open}
                onOpenChange={setOpen}
            >
                <DocumentModal
                    open={documentModal}
                    onOpenChange={() => setDocumentModal(false)}
                    title="Business Verification"
                    documents={
                        provider.verification?.government_id
                            ? [provider.verification.government_id]
                            : []
                    }
                />
                <div className="px-[16px] space-y-[20px]">
                    <div className="flex items-center gap-[13px]">
                        <div className="avatar relative">
                            <img
                                src={provider.profile_picture ?? "/images/avatar.png"}
                                className="w-[61px] h-[61px] rounded-full border border-white object-cover"
                                loading="lazy"
                            />
                        </div>
                        <div className="flex flex-col justify-between gap-[14px]">
                            <Text
                                type="h4"
                                className="font-[600] text-lg"
                                title={provider.name}
                            />
                            <Text
                                type="p"
                                className="font-[500] text-base text-black/60"
                                title={provider.service_category}
                            />
                        </div>
                    </div>

                    <div className="flex flex-col gap-[18px]">
                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("summary")}
                            >
                                <Text title="Provider Information" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["summary"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["summary"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Category"
                                        value={provider.service_category}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Subscription"
                                        value={provider.subscription}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Phone Number"
                                        value={provider.phone_number}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Joined Date"
                                        value={formatCreatedAt(provider.created_at)}
                                    />
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Last Active"
                                        value={formatCreatedAt(provider.last_active)}
                                    />
                                </div>
                            )}
                        </div>

                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("reason")}
                            >
                                <Text title="Verification Documents" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["reason"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["documents"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[16px]">
                                    <ModalFieldItem
                                        className="flex-row items-center justify-between"
                                        label="Goverment ID"
                                        content={(
                                            <button
                                                onClick={() => setDocumentModal(true)}
                                                className="underline text-primary text-sm font-[500]"
                                            >
                                                View Document
                                            </button>
                                        )}
                                    />
                                </div>
                            )}
                        </div>


                        <div className="bg-[#F9F9F9] rounded-[6px]">
                            <button
                                className="flex items-center justify-between w-full p-[16px]"
                                onClick={() => toggleSection("decision")}
                            >
                                <Text title="Decision" className="text-[13px] font-[600]" type="h5" />

                                <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                    {openSections["decision"]
                                        ? <ChevronUp className="size-4 text-primary" />
                                        : <ChevronDown className="size-4 text-primary" />
                                    }
                                </div>
                            </button>
                            {openSections["decision"] && (
                                <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                    {[
                                        { label: "Approve Provider", value: "approve" },
                                        { label: "Reject Verification", value: "reject" },
                                    ].map(option => {
                                        const isChecked = decision === option.value
                                        return (
                                            <button
                                                key={option.value}
                                                className="flex items-center gap-[10px]"
                                                onClick={() => setDecision(option.value)}
                                            >
                                                <div className={`w-[16px] h-[16px] rounded-full border flex items-center justify-center transition-colors border-black/20`}>
                                                    {isChecked && (
                                                        <div className="w-[10px] h-[10px] rounded-full bg-primary" />
                                                    )}
                                                </div>
                                                <Text
                                                    title={option.label}
                                                    className={`text-[13px] font-[500] transition-colors ${isChecked ? "text-primary" : "text-black/50"}`}
                                                    type="h5"
                                                />
                                            </button>
                                        )
                                    })}
                                </div>
                            )}
                        </div>


                        {decision === "reject" && (
                            <div className="bg-[#F9F9F9] rounded-[6px]">
                                <button
                                    className="flex items-center justify-between w-full p-[16px]"
                                    onClick={() => toggleSection("reason")}
                                >
                                    <Text title="Rejection Reason" className="text-[13px] font-[600]" type="h5" />

                                    <div className="w-[20px] h-[20px] rounded-full bg-[#C0C0C01A] flex items-center justify-center">
                                        {openSections["reason"]
                                            ? <ChevronUp className="size-4 text-primary" />
                                            : <ChevronDown className="size-4 text-primary" />
                                        }
                                    </div>
                                </button>
                                {openSections["reason"] && (
                                    <div className="bg-white border border-[#E8E7E766] rounded-[6px] p-[16px] space-y-[10px]">
                                        {REASONS.map(option => {
                                            const isChecked = reason === option.value
                                            return (
                                                <button
                                                    key={option.value}
                                                    className="flex items-center gap-[10px]"
                                                    onClick={() => setReason(option.value)}
                                                >
                                                    <div className={`w-[16px] h-[16px] rounded-full border flex items-center justify-center transition-colors border-black/20`}>
                                                        {isChecked && (
                                                            <div className="w-[10px] h-[10px] rounded-full bg-primary" />
                                                        )}
                                                    </div>
                                                    <Text
                                                        title={option.label}
                                                        className={`text-[13px] font-[500] transition-colors ${isChecked ? "text-primary" : "text-black/50"}`}
                                                        type="h5"
                                                    />
                                                </button>
                                            )
                                        })}
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                </div>
            </DetailsModal>
        </>
    )
}


export default VerifyProvider;