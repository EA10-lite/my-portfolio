import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { Dialog, DialogContent } from "../../../components/ui/dialog";
import { Text } from "../../../components";
import React from "react";
import { Button } from "../../../components/ui/button";

const DocumentModal = ({
    title,
    onOpenChange,
    open,
    documents = [],
    type,
}: {
    title: string;
    onOpenChange: () => void;
    open: boolean;
    documents: string[];
    type?: string;
}) => {
    const [activeIndex, setActiveIndex] = React.useState(0)
    const [direction, setDirection] = React.useState<"left" | "right">("right")
    const [animating, setAnimating] = React.useState(false)
    const [displayIndex, setDisplayIndex] = React.useState(0)

    const handlePrev = () => {
        if (animating || activeIndex === 0) return
        setDirection("left")
        setAnimating(true)
        setTimeout(() => {
            setActiveIndex(prev => prev - 1)
            setDisplayIndex(prev => prev - 1)
            setAnimating(false)
        }, 250)
    }

    const handleNext = () => {
        if (animating || activeIndex === documents.length - 1) return
        setDirection("right")
        setAnimating(true)
        setTimeout(() => {
            setActiveIndex(prev => prev + 1)
            setDisplayIndex(prev => prev + 1)
            setAnimating(false)
        }, 250)
    }

    const handleThumbnail = (index: number) => {
        if (animating || index === activeIndex) return
        setDirection(index > activeIndex ? "right" : "left")
        setAnimating(true)
        setTimeout(() => {
            setActiveIndex(index)
            setDisplayIndex(index)
            setAnimating(false)
        }, 250)
    }

    // Reset index when modal opens
    React.useEffect(() => {
        if (open) {
            setActiveIndex(0)
            setDisplayIndex(0)
        }
    }, [open])

    const activeDoc = documents[displayIndex]
    const isPdf = activeDoc?.endsWith(".pdf")

    const slideClass = animating
        ? direction === "right"
            ? "translate-x-[-20px] opacity-0"
            : "translate-x-[20px] opacity-0"
        : "translate-x-0 opacity-100"

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent
                className="
                    bg-white
                    rounded-[10px]
                    border-none
                    shadow-none
                    overflow-hidden
                    [&>button.absolute]:hidden
                    z-[99]
                    p-0
                    min-w-[472px]
                "
            >
                <div className="document-modal p-[24px] flex flex-col gap-[20px]">
                    {/* Header */}
                    <div className="flex items-center justify-between">
                        <Text
                            title={title || "Verification Document"}
                            className="font-[600] text-[13px]"
                        />
                        <X onClick={onOpenChange} className="size-4 cursor-pointer text-black/50 hover:text-black" />
                    </div>

                    {documents.length > 0 ? (
                        <>
                            {/* Main Preview */}
                            <div className="relative w-full h-[256px] overflow-hidden flex items-center justify-center">
                                {/* Prev / Next */}
                                {documents.length > 1 && (
                                    <>
                                        <Button
                                            variant="ghost"
                                            onClick={handlePrev}
                                            disabled={activeIndex === 0 || animating}
                                            className="absolute left-2 top-1/2 -translate-y-1/2 h-10 w-10 z-10 border border-black/5 rounded-full hover:bg-white disabled:opacity-30"
                                        >
                                            <ChevronLeft className="size-6" />
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            onClick={handleNext}
                                            disabled={activeIndex === documents.length - 1 || animating}
                                            className="absolute right-2 top-1/2 -translate-y-1/2 h-10 w-10 z-10 border border-black/5 rounded-full hover:bg-white disabled:opacity-30"
                                        >
                                            <ChevronRight className="size-6" />
                                        </Button>
                                    </>
                                )}

                                {/* Sliding content */}
                                <div
                                    className={`w-[194px] mx-auto transition-all duration-250 ease-in-out ${slideClass}`}
                                >
                                    {isPdf ? (
                                        <iframe
                                            src={activeDoc}
                                            className="w-full h-[256px]"
                                            title={`Document ${displayIndex + 1}`}
                                        />
                                    ) : (
                                        <img
                                            src={activeDoc}
                                            alt={`Document ${displayIndex + 1}`}
                                            className="w-full h-full object-contain"
                                        />
                                    )}
                                </div>
                            </div>

                            {/* Thumbnails */}
                            {documents.length > 1 && (
                                <div className="flex items-center justify-center gap-[8px] overflow-x-auto pb-1">
                                    {documents.map((doc, index) => {
                                        const isActive = index === activeIndex
                                        const isDocPdf = doc.endsWith(".pdf") || type === "pdf"
                                        return (
                                            <button
                                                key={index}
                                                onClick={() => handleThumbnail(index)}
                                                className={`flex-shrink-0 w-[72px] h-[72px] rounded-[8px] overflow-hidden border-2 transition-colors ${
                                                    isActive ? "border-primary" : "border-transparent"
                                                }`}
                                            >
                                                {isDocPdf ? (
                                                    <div className="w-full h-full bg-black/6 flex items-center justify-center">
                                                        <span className="text-[10px] font-[600] text-black/40">PDF</span>
                                                    </div>
                                                ) : (
                                                    <img
                                                        src={doc}
                                                        alt={`Thumbnail ${index + 1}`}
                                                        className="w-full h-full object-cover"
                                                    />
                                                )}
                                            </button>
                                        )
                                    })}
                                </div>
                            )}
                        </>
                    ) : (
                        <div className="flex items-center justify-center h-[320px] text-sm text-black/40">
                            No documents available.
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    )
}

export default DocumentModal;