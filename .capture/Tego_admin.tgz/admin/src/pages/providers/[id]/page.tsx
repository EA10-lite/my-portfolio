import { useParams } from "react-router-dom";
import { ReusableTable, Text } from "../../../components";
import { Button } from "../../../components/ui/button";
import { useState } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { formatCreatedAt, formatCurrency } from "../../../utils/formatter";
import { getProviderDetails } from "../../../services/users.service";
import { useQuery } from "@tanstack/react-query";
import type { ProviderService } from "../../../services/response-structure";
import DocumentModal from "../_components/DocumentModal";

const columns: ColumnDef<ProviderService>[] = [
    {
        accessorKey: "service",
        header: "Service",
        cell: ({ row }) => (
            <span className="text-sm">{row.original.name}</span>
        )
    },
    {
        accessorKey: "category",
        header: "Category",
        cell: ({ row }) => (
            <span className="capitalize">{row.original.category}</span>
        )
    },
    {
        accessorKey: "price",
        header: "Price",
        cell: ({ row }) => (
            <span className="capitalize">{formatCurrency(row.original.price)}</span>
        )
    },
]

const ProviderDetails = () => {
    const [activeTab, setActiveTab] = useState("services");
    const [count, setCount] = useState(4);
    const [open, setOpen] = useState<boolean>(false);

    const { id } = useParams();

    const {
        data,
        isLoading,
        isError,
        error,
    } = useQuery({
        queryKey: ["provider-details", id],
        queryFn: () => getProviderDetails(id!.toString()),
        enabled: !!id,
    });


    if (isLoading) {
        return (
            <div className="min-h-[60vh] flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                    <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                    <Text
                        title="Loading provider details..."
                        type="p"
                        className="text-sm text-black/60"
                    />
                </div>
            </div>
        );
    }

    if (isError) {
        return (
            <div className="min-h-[60vh] flex items-center justify-center px-6">
                <div className="flex flex-col items-center text-center gap-3 max-w-md">
                    <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center">
                        <span className="text-red-500 text-xl">!</span>
                    </div>
                    <Text
                        title="Unable to load provider details"
                        type="h4"
                        className="font-semibold text-lg"
                    />
                    <Text
                        title={
                            error instanceof Error
                                ? error.message
                                : "Something went wrong while loading this provider. Please try again."
                        }
                        type="p"
                        className="text-sm text-black/60"
                    />
                    <Button
                        variant="primary"
                        onClick={() => window.location.reload()}
                        className="mt-2"
                    >
                        Try Again
                    </Button>
                </div>
            </div>
        );
    }
    return (
        <div className="space-y-[20px] px-6">
            {/* Breadcrumsb */}
            {/* Profile Heading */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[48px]">
                <div className="flex items-center gap-[13px]">
                    <div className="avatar relative">
                        <img
                            src={data?.provider?.profile_picture || "/images/avatar.png"}
                            className="w-14 h-14 rounded-full border border-white object-cover"
                            loading="lazy"
                        />
                    </div>
                    <div className="flex flex-col justify-between gap-[14px]">
                        <Text
                            type="h4"
                            className="font-[600] text-lg"
                            title={`${data?.provider.name}`}
                        />
                        <Text
                            type="p"
                            className="font-[500] text-base text-black/60"
                            title={data?.service_category ?? ""}
                        />
                    </div>
                </div>
                <div className="grid grid-cols-4 gap-[12px]">
                    <ProfileStat label={"Jobs Done"} value={`${data?.stats.jobs_done}`} />
                    <ProfileStat label={"Active Jobs"} value={`${data?.stats.active_jobs}`} />
                    <ProfileStat label={"Rating"} value={`${data?.stats.average_rating}`} />
                    <ProfileStat label={"Repeat Clients"} value={`${data?.stats.repeat_client_percent}`} />
                </div>
            </div>

            {/* Profile Information */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <Text
                    title="Provider Information"
                    type="h4"
                    className="font-[600] text-base"
                />

                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                    <InfoField label={"Name"} value={`${data?.provider.name}`} />
                    <InfoField label={"Email"} value={data?.provider.email ?? "-"} />
                    <InfoField label={"Phone Number"} value={`${data?.provider.phone_number}`} />
                    <InfoField label={"Gender"} value={`${data?.provider.gender}`} />
                    <InfoField
                        label={"Location"}
                        value={
                            (data?.provider?.location?.city && data?.provider?.location?.state)
                                ? `${data?.provider.location.city} ${data?.provider.location.state}`
                                : "-"
                        }
                    />
                    <InfoField
                        label={"Last Active"}
                        value={
                            data?.provider?.last_active
                                ? formatCreatedAt(data?.provider.last_active)
                                    : "-"
                        }
                    />
                </div>
            </div>


            {/* Subscription Information */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <Text
                    title="Subscription Information"
                    type="h4"
                    className="font-[600] text-base"
                />

                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                    <InfoField
                        label={"Current Plan"}
                        value={data?.subscription.current_plan ?? "-"}
                    />
                    <InfoField
                        label={"Subscription Status"}
                        value={data?.subscription.status ?? "-"}
                    />
                    <InfoField
                        label={"Auto Renewal"}
                        value={data?.subscription.auto_renewal ? "Enabled" : "Not Enabled"}
                    />
                    <InfoField
                        label={"Renewal Date"}
                        value={
                            data?.subscription?.renewal_date
                                ? formatCreatedAt(data?.subscription?.renewal_date)
                                    : "-"
                        }
                    />
                </div>
            </div>


            {/* Verification Information */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <div className="flex items-center justify-between">
                    <Text
                        title="Verification Information"
                        type="h4"
                        className="font-[600] text-base"
                    />

                    <DocumentModal
                        documents={
                            data?.verification?.professional_document
                                ? [data?.verification?.professional_document.file_url]
                                : []
                        }
                        type={data?.verification?.professional_document?.file_type}
                        open={open}
                        onOpenChange={()=> setOpen(false)}
                        title="Documents"
                    />
                    <button
                        onClick={() => setOpen(true)}
                        className="underline text-primary text-sm font-[500]"
                    >
                        View Documents
                    </button>
                </div>

                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                    <InfoField label={"Identity Verification"} value={data?.verification?.status ?? "Pending"} />
                    <InfoField label={"Address Verification"} value={data?.verification?.status ?? "Pending"} />
                    <InfoField label={"Business Verification"} value={data?.verification?.status ?? "Pending"} />
                    <InfoField label={"BVN"} value={data?.verification?.status ?? "Pending"} />
                    <InfoField label={"NIN"} value={data?.verification?.status ?? "Pending"} />
                </div>
            </div>

            {/* Work galery */}
            <div className="hidden border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <Text
                    title="Work Gallery"
                    type="h4"
                    className="font-[600] text-sm"
                />

                <div className="grid grid-cols-4 justify-between gap-x-4 gap-y-[20px]">
                    {data?.work_gallery?.slice(0,count).map((work, index)=> (
                        <img
                            src={work}
                            key={index}
                            className="rounded-[6px] min-h-[142px] w-full object-cover"
                            loading="lazy"
                        />
                    ))}
                </div>
                {data?.work_gallery && data?.work_gallery?.length > 4 && (
                    <div className="flex justify-end">
                        <button
                            className="underline text-primary text-[13px] font-[500]"
                            onClick={() => setCount(data?.work_gallery?.length > count ? data?.work_gallery?.length : 4)}
                        >
                            See {data?.work_gallery?.length > count ? "more" : "less"}
                        </button>
                    </div>
                )}
            </div>

            {/* Histories & Timeline */}
            <div className="border border-black/6 p-[20px] rounded-[10px] flex flex-col gap-[20px]">
                <div className="flex items-center gap-4">
                    {[
                        { label: "Services Offered", value: "services" },
                    ].map((tab, index) => (
                        <Button
                            key={index}
                            variant={activeTab === tab.value ? "primary" : "muted"}
                            className={`rounded-[50px] text-[13px] font-[500] px-[20px]`}
                            onClick={()=> setActiveTab(tab.value)}
                        >
                            {tab.label}
                        </Button>
                    ))}
                </div>
                {activeTab === "services" && (
                    <ReusableTable
                        data={data?.services_offered ?? []}
                        columns={columns}
                        manualPagination={true}
                        pageCount={0}
                        isLoading={false}
                        emptyMessage={{
                            title: "No services available",
                            description: "Verified and subscribed providers will appear here.",
                            icon: "provider-outline"
                        }}
                        hasDateFilter={false}
                    />
                )}
            </div>
        </div>
    )
}

const ProfileStat = ({ label, value }: { label: string; value: string}) => {
    return (
        <div className="bg-gray py-[36px] flex items-center justify-center">
            <div className="text-center flex flex-col gap-[14px]">
                <Text
                    title={value}
                    className="text-lg font-[700]"
                    type="h4"
                />
                <Text
                    title={label}
                    className="text-base font-[500] text-black/60"
                    type="p"
                />
            </div>
        </div>
    )
}


const InfoField = ({ label, value }: { label: string; value: string}) => {
    return (
        <div className="flex flex-col gap-[8px]">
            <Text
                title={label}
                className="text-sm font-[500] text-black/60"
                type="p"
            />
            <Text
                title={value}
                className="text-base font-[600]"
                type="h4"
            />
        </div>
    )
}

export default ProviderDetails;