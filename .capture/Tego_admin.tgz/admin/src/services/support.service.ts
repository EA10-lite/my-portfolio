import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import type { TicketDashboard, TicketDetails, TicketList } from "./response-structure";
import type { TICKET_STATUS } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface TicketsParams extends Record<string, unknown>, BaseParams {
    status?: TICKET_STATUS
}

export const getTicketStats = async () => {
    const response = await client.get<TicketDashboard>("/admin/tickets/stats");
    return response.data;
}

export const getTickets = async (params?: TicketsParams) => {
    const response = await client.get<TicketList>("/admin/tickets", {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}
export const getMyTickets = async (params?: TicketsParams) => {
    const response = await client.get<TicketList>(`/tickets/my`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}
export const getSupportContact = async () => {
    const response = await client.get(`/tickets/support-contact`);
    return response.data;
}

export const getTicketDetails = async (ticketId: string) => {
    const response = await client.get<TicketDetails>(`/admin/tickets/${ticketId}`);
    return response.data;
}



export interface BulkAssign {
    admin_id: string;
    ticket_ids: string[];
}

// *********SUPPORT ACTIONS************ //
export const claimTicket = async (ticketId: string) => {
    const response = await client.post(`/admin/tickets/${ticketId}/claim`);
    return response.data;
}
export const releaseTicket = async (ticketId: string) => {
    const response = await client.post(`/admin/tickets/${ticketId}/release`);
    return response.data;
}
export const assignTicketToAnotherAdmin = async (ticketId: string) => {
    const response = await client.post(`/admin/tickets/${ticketId}/transfer`);
    return response.data;
}

export const assignTicketsToAdmin = async (data: BulkAssign) => {
    const response = await client.post(`/admin/tickets/bulk-assign`, data);
    return response.data;
}


// *********SUPPORT ACTIONS************ //
export interface TicketStatus {
    status: string;
    category: string;
}
export interface ReplyText {
    message_type: "TEXT" | "IMAGE",
    message?: string;
    media?: string[];
}

export const updateTicket = async (ticketId: string, data: TicketStatus) => {
    const response = await client.patch(`/admin/tickets/${ticketId}`, data);
    return response.data;
}
export const replyTicketWithText = async (ticketId: string, data: ReplyText) => {
    const response = await client.post(`/admin/tickets/${ticketId}/reply`, data);
    return response.data;
}
export const replyTicketWithImage = async (ticketId: string, data: ReplyText) => {
    const response = await client.post(`/admin/tickets/${ticketId}/reply`, data);
    return response.data;
}
export const deleteTicket = async (ticketId: string) => {
    const response = await client.delete(`/admin/tickets/${ticketId}`);
    return response.data;
}