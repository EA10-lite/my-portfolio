import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import type { ServiceList } from "./response-structure";
import type { PERFORMANCE, PERIOD, SERVICE_STATUS, SUBSCRIPTION } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface ServicesParams extends Record<string, unknown>, BaseParams {
    category_ids?: string[];
    subscription_types?: SUBSCRIPTION[];
    status?: SERVICE_STATUS[];
    time_period?: PERIOD;
    performance?: PERFORMANCE;
}

// *********SERVICES GET************ //
export const getServices = async (params?: ServicesParams) => {
    const response = await client.get<ServiceList>(`/services/admin/records`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}




export interface FeatureServiceSettings {
    service_id: string;
    timeline: number;
    placement: string[];
}
export interface RejectServiceSettings {
    service_id: string;
    rejection_reason: string;
}
export interface RemoveServiceSettings {
    service_id: string;
    notify_customer: boolean;
}


// *********SERVICES ACTIONS************ //
export const approveService = async (serviceId: string) => {
    const response = await client.post(`/services/admin/approve`, { service_id: serviceId });
    return response.data;
}
export const rejectService = async (data: RejectServiceSettings) => {
    const response = await client.post(`/services/admin/reject`, data);
    return response.data;
}
export const featureService = async (data: FeatureServiceSettings) => {
    const response = await client.post(`/services/admin/feature`, data);
    return response.data;
}
export const unfeatureService = async (serviceId: string) => {
    const response = await client.post(`/services/admin/unfeature`, { service_id: serviceId });
    return response.data;
}
export const removeService = async (data: RemoveServiceSettings) => {
    const response = await client.post(`/services/admin/remove`, data);
    return response.data;
}