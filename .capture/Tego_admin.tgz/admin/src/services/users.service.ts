import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import type { CustomerDetails, CustomerList, ProviderDetails, ProviderList } from "./response-structure";
import type { PERIOD, SUBSCRIPTION, USER_STATUS, VERIFICATION } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
}

export interface ProvidersParam extends Record<string, unknown>, BaseParams {
    category?: string;
    subscription?: SUBSCRIPTION;
    verification?: VERIFICATION;
    status?: USER_STATUS;
    period?: PERIOD;
}
export interface CustomersParam extends Record<string, unknown>, BaseParams {
    status?: USER_STATUS
    period?: PERIOD;
    location?: string;
}

export interface ReactivateCustomerSettings {
    restore_settings: string[];
    notify_customer: boolean;
}
export interface ReactivateProviderSettings {
    restore_settings: string[];
    notify_customer: boolean;
}

// *********PROVIDER GET************ //
export const getProviders = async (params?: ProvidersParam) => {
    const response = await client.get<ProviderList>(`/users/admin/providers`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}
export const getProviderDetails = async (providerId: string) => {
    const response = await client.get<ProviderDetails>(`/users/admin/providers/${providerId}`);
    return response.data;
}
export const getProviderBrief = async (providerId: string) => {
    const response = await client.get(`/users/admin/providers/${providerId}/brief`);
    return response.data;
}

// *********CUSTOMER GET************ //
export const getCustomers = async (params?: CustomersParam) => {
    const response = await client.get<CustomerList>(`/users/admin/customers`, {
        params: mapToApiParams(params),
    });
    return response.data;
}
export const getCustomerDetails = async (customerId: string) => {
    const response = await client.get<CustomerDetails>(`/users/admin/customers/${customerId}`);
    return response.data;
}
export const getCustomerBrief = async (customerId: string) => {
    const response = await client.get(`/users/admin/customers/${customerId}/brief`);
    return response.data;
}



// *********PROVIDER ACTIONS************ //
export const suspendProvider = async (providerId: string, reason: string[], suspension_settings: string[]) => {
    const response = await client.patch(`/users/admin/providers/${providerId}/suspend`, { reason, suspension_settings });
    return response.data;
}
export const reactivateProvider = async (providerId: string, data: ReactivateProviderSettings) => {
    const response = await client.patch(`/users/admin/providers/${providerId}/reactivate`, data);
    return response.data;
}
export const deleteProvider = async (providerId: string, reason: string[]) => {
    const response = await client.delete(`/users/admin/providers/${providerId}`, { data: {reason} });
    return response.data;
}


// *********CUSTOMER ACTIONS************ //
export const suspendCustomer = async (customerId: string, reason: string[]) => {
    const response = await client.patch(`/users/admin/customers/${customerId}/suspend`, { reason });
    return response.data;
}
export const reactivateCustomer = async (customerId: string, data: ReactivateCustomerSettings) => {
    const response = await client.patch(`/users/admin/customers/${customerId}/reactivate`, data);
    return response.data;
}
export const deleteCustomer = async (customerId: string, reason: string[]) => {
    const response = await client.delete(`/users/admin/customers/${customerId}`, { data: {reason} });
    return response.data;
}