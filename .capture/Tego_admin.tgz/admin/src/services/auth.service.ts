import client from "./client.service";

type LoginData = {
    phoneNumber: string;
    password: string;
    device_name: string;
    device_ip: string;
    location: {
        longitude: number;
        latitude: number;
        state: string;
        country: string;
    }
}

export const login = async (data: LoginData) => {
    const response = await client.post("/users/admin/login", data);
    return response.data;
};