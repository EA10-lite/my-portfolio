export type SUBSCRIPTION = "free" | "pro_monthly" | "pro_yearly";
export type SUBSCRIPTION_STATUS = "ACTIVE" | "CANCELLED" | "EXPIRED";
export type USER_STATUS = "active" | "inactive" | "suspended";
export type PERIOD = "7d" | "30d" | "90d" | "180d" | "1y";
export type RANGE = "week" | "month" | "year";
export type VERIFICATION = "verified" | "unverified";
export type VERIFICATION_STATUS = "PENDING" | "APPROVED" | "REJECTED";
export type PERFORMANCE = "high" | "most_booked" | "low";
export type SERVICE_STATUS = "PENDING" | "APPROVED" | "REJECTED" | "FEATURE";
export type ADMIN_ROLE = "SUPER_ADMIN" | "SUPPORT_ADMIN";
export type ADMIN_STATUS = "active" | "inactive";
export type TICKET_STATUS = "open" | "close" | "in_progress"
export type CATEGORY_STATUS = "ACTIVE" | "INACTIVE"
export type REQUEST_TYPE = "book_service" | "job_request";
export type NOTIFICATION_AUDIENCE = "CUSTOMERS" | "PROVIDERS" | "ALL" | "INDIVIDUALS"
export type NOTIFICATION_CHANNELS = "IN_APP" | "PUSH" | "EMAIL" | "SMS";
export type NOTIFICATION_REPEATE_TYPE = "NONE" | "DAILY" | "WEEKLY" | "MONTHLY"
export type USER_TYPE = "PROVIDER" | "CUSTOMER";
export type BOOKING_STATUS =
    "PENDING"
    | "AWAITING_PROVIDER"
    | "ACCEPTED"
    | "IN_NEGOTIATION"
    | "CANCELLED";
export type ORDER_STATUS =
    "PENDING"
    | "IN_PROGRESS"
    | "COMPLETED"
    | "CANCELLATION_REQUESTED"
    | "CANCELLED";
export type REQUEST_AND_BOOKING_LOG = "booking_created" | "status_in_negotiation" | "scheduled"
export type ADMIN_ACTIONS =
    "ADMIN_UPDATED"
    | "ADMIN_CREATED"
    | "ADMIN_LOGIN"
    | "ADMIN_DELETED"
    | "ADMIN_RESET_PASSWORD"
export type Gender =
    "MALE"
    | "FEMALE"
    | "NOT_SPECIFIED"
    | "OTHER";
export type ACTIVITY_TYPE =
    "job_posted"
    | "provider_registration"
    | "ticket_opened"
    | "subscription_purchased"

export interface PAGINATION {
    page: number;
    limit: number;
    total: number;
    total_pages: number;
    totalPages: number;
}

export interface LOCATION {
    state: string | null;
    city: string | null;
    country: string | null;
    address: string | null;
}

export interface LOGIN_DEVICE {
    id: string;
    device_name: string;
    last_login: string;
}

export interface USER_BRIEF {
    id: string;
    name?: string;
    first_name: string;
    last_name: string;
    phone_number: string;
    email: string | null;
    profile_picture: string | null;
}

export interface CATEGORY {
    id: string;
    name: string;
}