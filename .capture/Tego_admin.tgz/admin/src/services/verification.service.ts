// /status=&category=&type=&from=&to=


import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import type { VerificationList, VerificationStats } from "./response-structure";
import type { PERIOD, VERIFICATION } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface VerificationParams extends Record<string, unknown>, BaseParams {
    category?: string[];
    status?: VERIFICATION[];
    period?: PERIOD;
    from?: string;
    to?: string
}

// *********SERVICES GET************ //
export const getVerifications = async (params?: VerificationParams) => {
    const response = await client.get<VerificationList>(`/admin/verifications`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}

export const getVerificationStat = async () => {
    const response = await client.get<VerificationStats>(`/admin/verifications/stats`);
    return response.data;
}



// *********SERVICES ACTIONS************ //
export interface RejectVerification {
    reason: string;
}
export const approveVerification = async (id: string) => {
    const response = await client.patch(`/admin/verifications/${id}/approve`);
    return response.data;
}
export const approveIdentity = async (id: string) => {
    const response = await client.post(`/admin/verifications/${id}/approve-identity`);
    return response.data;
}
export const reverifyVerification = async (id: string) => {
    const response = await client.post(`/admin/verifications/${id}/reverify`);
    return response.data;
}
export const rejectVerification = async (id: string, data: RejectVerification) => {
    const response = await client.patch(`/admin/verifications/${id}/reject`, data);
    return response.data;
}