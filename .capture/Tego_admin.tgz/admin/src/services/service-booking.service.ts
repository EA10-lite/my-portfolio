//period=week&request_type=booking&status=ACCEPTED
import client from "./client.service";
import type { RequestAndBookingList } from "./response-structure";
import { mapToApiParams } from "../utils/formatter";
import type { BOOKING_STATUS, PERIOD, REQUEST_TYPE } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface RequestAndBookingParams extends Record<string, unknown>, BaseParams {
    request_type?: REQUEST_TYPE;
    status?: BOOKING_STATUS;
    category_ids?: string[];
    period?: PERIOD;
}

export const getRequestAndBookings = async (params?: RequestAndBookingParams) => {
    const response = await client.get<RequestAndBookingList>(`/service-booking/admin/records`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}

// *********CATEGORY ACTIONS************ //
export interface CancellationReason {
    reason: string;
}

export interface ReassignData {
    order_id: string;
    new_provider_id: string,
    notify_new_provider: boolean;
}

export const reassignProvider = async (data: ReassignData) => {
    const response = await client.patch(`/service-categories/`, data);
    return response.data;
}
export const cancelBooking = async (orderId: string, data: CancellationReason) => {
    const response = await client.post(`/orders/admin/cancel/${orderId}`, data);
    return response.data;
}