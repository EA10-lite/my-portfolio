import client from "./client.service";
import type { AdminDetails, AdminNotificationSettings } from "./response-structure";
import type { ADMIN_ROLE, ADMIN_STATUS } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
}

export interface AdminParams extends BaseParams {
    status?: ADMIN_STATUS;
    role?: ADMIN_ROLE;
}


export const getAdminProfile = async () => {
    const response = await client.get<AdminDetails>(`/users/admin/profile`);
    return response.data;
}
export const getAdminNotificationSettings = async () => {
    const response = await client.get<AdminNotificationSettings>(`/users/admin/notification-settings`);
    return response.data;
}


// *********SUPPORT ACTIONS************ //
export interface AdminUserProfile {
    first_name: string;
    last_name: string;
    phone_number: string;
    profile_picture: string;
    location: {
        address: string;
        city: string;
        state: string;
        country: string;
    }
}

export interface ResetAdminPassword {
    old_password: string;
    new_password: string;
}

export const updateAdminProfile = async (data: AdminUserProfile) => {
    const response = await client.post(`/users/admin/profile`, data);
    return response.data;
}
export const updateAdminPassword = async (data: ResetAdminPassword) => {
    const response = await client.post(`/users/change-password`, data);
    return response.data;
}

export const updateAdminNotification = async (data: AdminNotificationSettings) => {
    const response = await client.patch(`/users/admin/notification-settings`, data);
    return response.data;
}