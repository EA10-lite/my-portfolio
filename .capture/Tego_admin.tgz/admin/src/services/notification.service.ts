import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import type { NotificationList, NotificationStat } from "./response-structure";
import type {
    NOTIFICATION_AUDIENCE,
    NOTIFICATION_CHANNELS,
    NOTIFICATION_REPEATE_TYPE
} from "./types";


export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface NotificationParams extends Record<string, unknown>, BaseParams {
    audience?: NOTIFICATION_AUDIENCE;
    is_active?: boolean;
}

export const getNotifications = async (params?: NotificationParams) => {
    const response = await client.get<NotificationList>("/admin/notifications", {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}

export const getNotificationStat = async () => {
    const response = await client.get<NotificationStat>("admin/notification-stats");
    return response.data;
}

export interface NotificationData {
    title: string;
    body: string;
    audience?: NOTIFICATION_AUDIENCE;
    channels: NOTIFICATION_CHANNELS[],
    user_ids?: string[];
    repeat: NOTIFICATION_REPEATE_TYPE;
    starts_at: string;
}


export const createNotification = async (data: NotificationData) => {
    const response = await client.post(`/admin/notifications`, data);
    return response.data;
}

export const stopNotificationCampaign = async (notificationId: string) => {
    const response = await client.patch(`/admin/notifications/${notificationId}/stop`);
    return response.data;
}

export const resendNotificationCampaign = async (notificationId: string) => {
    const response = await client.patch(`/admin/notifications/${notificationId}/resend`);
    return response.data;
}