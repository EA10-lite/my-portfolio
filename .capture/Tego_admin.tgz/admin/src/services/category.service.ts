import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import type { CategoryInsight, CategoryList, CategoryStat } from "./response-structure";
import type { CATEGORY_STATUS, TICKET_STATUS } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface CategoryParams extends Record<string, unknown>, BaseParams {
    status?: TICKET_STATUS
}

export interface CategoryInsightParam {
    day: number;
}

export const getCategoryStats = async () => {
    const response = await client.get<CategoryStat>("/admin/category-stats");
    return response.data;
}

export const getCategoryInsights = async (params?: CategoryInsightParam) => {
    const response = await client.get<CategoryInsight>("/admin/category-insights", {
        params
    });
    return response.data;
}

export const getCategories = async (params?: CategoryParams) => {
    const response = await client.get<CategoryList>("/admin/categories", {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}

// *********CATEGORY ACTIONS************ //
export interface Category {
    name: string;
    image: string; // icon
    cover_image: string; // image
}

export const createCategory = async (data: Category) => {
    const response = await client.post(`/service-categories/`, data);
    return response.data;
}
export const updateCategory = async (categoryId: string, data: Category) => {
    const response = await client.patch(`/service-categories/${categoryId}`, data);
    return response.data;
}
export const updateCategoryStatus = async (categoryId: string, status: CATEGORY_STATUS) => {
    const response = await client.patch(`/service-categories/${categoryId}`, { status });
    return response.data;
}
export const deleteCategory = async (categoryId: string) => {
    const response = await client.delete(`/service-categories/${categoryId}`);
    return response.data;
}