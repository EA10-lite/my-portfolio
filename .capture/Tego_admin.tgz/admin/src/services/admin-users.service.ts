import { mapToApiParams } from "../utils/formatter";
import client from "./client.service";
import { type AdminActivityLog, type AdminUserList } from "./response-structure";
import type { ADMIN_ROLE, ADMIN_STATUS } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
}

export interface AdminParams extends Record<string, unknown>, BaseParams {
    status?: ADMIN_STATUS;
    role?: ADMIN_ROLE;
}


export const getAdmins = async (params?: AdminParams) => {
    const response = await client.get<AdminUserList>(`/admin/admins`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}

export const getAdminActivityLog = async (adminId: string) => {
    const response = await client.get<AdminActivityLog>(`/admin/admins/${adminId}/activity-log`);
    return response.data;
}


// *********SUPPORT ACTIONS************ //
export interface BaseAdminUser {
    full_name: string;
    email: string;
    phone_number: string;
    role: ADMIN_ROLE;
    status: ADMIN_STATUS;
    enable_mfa: boolean;
}

export interface AdminUser extends BaseAdminUser {
    temporary_password: string;
    confirm_password: string;
}

export interface ResetPassword {
    mode: "manual" | "auto"
    email_password: boolean;
    password?: string;
    confirm_password?: string;
}

export const createAdmin = async (data: AdminUser) => {
    const response = await client.post(`/admin/admins`, data);
    return response.data;
}
export const updateAdmin = async (adminId: string, data: BaseAdminUser) => {
    const response = await client.patch(`/admin/admins/${adminId}`, data);
    return response.data;
}
export const resetAdminPAssword = async (adminId: string, data: ResetPassword) => {
    const response = await client.post(`/admin/admins/${adminId}/reset-password`, data);
    return response.data;
}
export const deleteAdmin = async (adminId: string) => {
    const response = await client.delete(`/admin/admins/${adminId}`);
    return response.data;
}