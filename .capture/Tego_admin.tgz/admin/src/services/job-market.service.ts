//period=week&request_type=booking&status=ACCEPTED
import client from "./client.service";
import type { ApplicationListing, JobListing, JobStat, } from "./response-structure";
import { mapToApiParams } from "../utils/formatter";
import type { PERIOD, SUBSCRIPTION } from "./types";
import type { STATUS } from "../utils/types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface JobListingParams extends Record<string, unknown>, BaseParams {
    status?: STATUS;
    category?: string;
    period?: PERIOD;
}
export interface ApplicationParams extends Record<string, unknown>, BaseParams {
    status?: STATUS;
    category?: string;
    period?: PERIOD;
    subscription?: SUBSCRIPTION;
    rating?: number;
}

export const getJobStats = async () => {
    const response = await client.get<JobStat>(`/admin/job-stats`);
    return response.data;
}
export const getListings = async (params?: JobListingParams) => {
    const response = await client.get<JobListing>(`/admin/jobs`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}
export const getApplications = async (params?: ApplicationParams) => {
    const response = await client.get<ApplicationListing>(`/admin/applications`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}

// *********JOB ACTIONS************ //
export const deleteJob = async (jobId: string) => {
    const response = await client.delete(`/admin/jobs/${jobId}`);
    return response.data;
}