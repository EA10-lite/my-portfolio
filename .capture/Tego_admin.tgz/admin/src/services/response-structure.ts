import type { STATUS } from "../utils/types";
import type {
    ACTIVITY_TYPE,
    ADMIN_ACTIONS,
    ADMIN_ROLE,
    ADMIN_STATUS,
    BOOKING_STATUS,
    CATEGORY,
    CATEGORY_STATUS,
    Gender,
    LOCATION,
    LOGIN_DEVICE,
    NOTIFICATION_AUDIENCE,
    NOTIFICATION_CHANNELS,
    NOTIFICATION_REPEATE_TYPE,
    ORDER_STATUS,
    PAGINATION,
    REQUEST_AND_BOOKING_LOG,
    REQUEST_TYPE,
    SUBSCRIPTION,
    SUBSCRIPTION_STATUS,
    TICKET_STATUS,
    USER_BRIEF,
    USER_STATUS,
    VERIFICATION_STATUS
} from "./types"


export interface BriefUser {
    id: string;
    first_name: string;
    last_name: string;
    phone_number?: string;
    email?: string;
    profile_picture?: string;
}

export interface Customer {
    id: string;
    name: string;
    profile_picture?: string;
    phone_number: string;
    email: string;
    location: null;
    last_active: string;
    created_at: string;
    status: USER_STATUS;
    tickets_opened?: number;
    bookings_count?: number;
    requests_count?: number;
}

export interface CustomerList {
    total_customers: number;
    active_customers: number;
    inactive_customers: number;
    suspended_customers: number;
    current_month_percentage_increase: {
        total_customers: number;
        active_customers: number;
        inactive_customers: number;
        suspended_customers: number;
    };
    full_customer_list: Customer[];
    pagination: PAGINATION;
}

export interface Provider {
    id: string;
    name: string;
    profile_picture: string;
    service_category: string;
    subscription: SUBSCRIPTION;
    phone_number: string;
    email: string;
    last_active: string;
    created_at: string;
    status: USER_STATUS;
    verification?: {
        status: VERIFICATION_STATUS,
        identity_verified: boolean;
        nin_verified: boolean;
        bvn_verified: boolean;
        address_verified: boolean;
        business_verified: boolean;
        government_id: string;
    }
}

export interface ProviderList {
    total_providers: number;
    active_providers: number;
    inactive_providers: number;
    verified_providers: number;
    current_month_percentage_increase: {
        total_providers: number;
        active_providers: number;
        inactive_providers: number;
        verified_providers: number;
    };
    full_provider_list: Provider[];
    pagination: PAGINATION;
}


export interface CustomerDetails {
    user_profile: USER_BRIEF;
    job_requests_made: number;
    bookings_done: number;
    providers_hired: number;
    support_tickets: number;
    location: LOCATION;
    gender: "MALE" | "FEMALE";
    last_active: string;
    date_joined: string;
    email_verified: boolean;
    phone_verified: boolean;
    account_status: USER_STATUS;
    login_devices: LOGIN_DEVICE[];
    job_requests: JobRequest[];
    orders: Order[];
    service_bookings: ServiceBooking[];
}
export interface ProviderDetails {
    provider: {
        id: string;
        name: string;
        email: string;
        phone_number: string;
        gender: Gender
        location: {
            state: string;
            city: string;
            country: string;
        },
        status: "ONLINE" | "OFFLINE",
        last_active: string;
        profile_picture: string;
    },
    service_category: string;
    stats: {
        jobs_done: number;
        active_jobs: number;
        average_rating: number;
        repeat_client_percent: number;
        total_reviews: number;
    },
    subscription: {
        current_plan: SUBSCRIPTION;
        status: SUBSCRIPTION_STATUS
        auto_renewal: boolean;
        renewal_date: string;
    },
    verification: {
        status: VERIFICATION_STATUS,
        identity_verified: boolean;
        nin_verified: boolean;
        bvn_verified: boolean;
        address_verified: boolean;
        business_verified: boolean;
        government_id: string;
        professional_document: {
            file_type: "image" | "pdf",
            file_url: string;
        },
    },
    services_offered: ProviderService[];
    work_gallery: string[];
}


export interface ProviderService {
    id: string;
    name: string;
    price: number;
    pricing_type: "FIXED" | "REQUEST_QUOTE";
    category: string;
}

export interface JobRequest {
    id: string;
    title: string;
    description: string;
    status: string;
    date: string;
    created_at: string;
}

export interface Order {
    id: string;
    status: string;
    created_at: string;
    provider: string;
}

export interface ServiceBooking {
    id: string;
    status: string;
    created_at: string;
    provider: string;
}



// Category
export interface CategoryStat {
    summary: {
        total_categories: STAT2;
        active_categories: STAT2;
        active_providers: STAT2;
        active_services: STAT2;
    };
}

export interface CategoryInsight {
    days: number;
    top_categories: TopCategory[];
    distribution: {
      top_category: string;
      jobs_pct: number;
      services_pct: number;
      providers_pct: number;
    }
    category_distribution: CategoryDistributionItem[]
}

export interface CategoryDistribution {
    days: string;
    categories: CategoryDistributionItem[];
    totals: {
        providers: number;
        services: number;
        jobs: number;
    }
}

export interface CategoryDistributionItem {
    id: string;
    category: string;
    jobs: number;
    services: number;
    providers: number;
    jobs_pct: number;
    services_pct: number;
    providers_pct: number;
}

export interface TopCategory {
    category_id: string;
    category: string;
    count: number;
}

export interface CategoryList extends PAGINATION {
    categories: Category[]
}

export interface Category {
    id: string;
    name: string;
    status: CATEGORY_STATUS;
    providers: number;
    services: number;
    jobs: number;
    image: string;
    created_at: string;
}

export interface ServiceList extends PAGINATION {
    stats: ServiceStats;
    services: Service[];
}

export interface Service {
    id: string;
    service_name: string;
    provider: BriefUser,
    category: {
      id: string;
      name: string;
    },
    status: STATUS;
    subscription_type: SUBSCRIPTION;
    service_items: {
        id: string;
        service_name: string;
        price: number;
        pricing_type: "FIXED" | "REQUEST_QUOTE"
    }[];
    total_bookings: number | null,
    average_rating: null | number,
    created_at: string;
    last_active: string;
}

export interface STAT {
    count: number | null;
    change_pct: number | null;
}
export interface ServiceStats {
    total_services: STAT;
    active_services: STAT;
    featured_services: STAT;
    pending_approval: STAT;
}


export interface AdminUserList {
    admins: AdminUser[];
    pagination: PAGINATION;
}

export interface AdminUser {
    id: string;
    first_name: string;
    last_name: string;
    phone_number: string;
    email: string;
    role: ADMIN_ROLE;
    last_login: string;
    status: ADMIN_STATUS;
    mfa_enabled: boolean;
    created_at: string;
}

export interface AdminActivityLog {
    activity_log: ActivityLog[];
    pagination: PAGINATION;
}

export interface ActivityLog {
    id: string;
    resource: "admin";
    action: ADMIN_ACTIONS;
    resource_id: string;
    actor: BriefUser;
    target: BriefUser;
    metadata: {
        changed_fields: string[]
    }
    ip_address: string;
    created_ad: string;
}



export interface TicketDashboard {
    open_tickets: number;
    open_tickets_pct: number;
    resolved_today: number;
    resolved_today_pct: number;
    escalated: number;
    escalated_pct: number | null;
    avg_response_hours: number;
    avg_response_hours_pct: number;
    weekly_volume: WeeklyVolume[];
    distribution: TicketDistribution[];
}
export interface WeeklyVolume {
    date: string;
    created: number;
    resolved: number;
}
export interface TicketDistribution {
    category: string;
    count: number;
}

export interface TicketList {
    tickets: Ticket[];
    pagination: PAGINATION;
}
export interface Ticket {
    id: string;
    ticket_no: string;
    status: TICKET_STATUS;
    category: "BOOKING" | "REQUEST";
    priority?: string;
    title: string;
    user: BriefUser;
    assigned_admin: null;
    last_message: string;
    last_message_at: string;
    unread_count: number,
    created_at: string;
    closed_at: null
}

export interface TicketDetails {
    id: string;
    ticket_no: string;
    status: "IN_PROGRESS";
    priority: "MEDIUM";
    category: string;
    title: string;
    user: USER_BRIEF,
    assigned_admin: {
        id: string;
        first_name: string;
        last_name: string;
    };
    last_message: string;
    last_message_at: string;
    unread_count: number;
    created_at: string;
    closed_at: null,
    messages: ChatMessage[];
}

export interface ChatMessage {
    id: string;
    conversation_id: string;
    sender_id: string;
    receiver_id: string;
    admin_sender_id:string;
    message: string;
    message_type: "TEXT",
    media: [],
    message_status: "SEEN",
    ticket_id: string;
    created_at: string;
    updated_at: string;
}

export interface RequestAndBookingList extends PAGINATION {
    stats: RequestAndBookingStat;
    bookings: RequestAndBooking[];
}

export interface RequestAndBookingStat {
    total_requests: STAT;
    active_bookings: STAT;
    completed_requests: STAT;
    pending_actions: STAT;
}
export interface RequestAndBooking {
    customer: USER_BRIEF;
    provider: USER_BRIEF;
    id: string;
    request__type: REQUEST_TYPE;
    service_name: string;
    booking_status: BOOKING_STATUS;
    order_status: ORDER_STATUS | null;
    category: {
        id: string;
        name: string;
    };
    activity_log: {
        type: REQUEST_AND_BOOKING_LOG;
        description: string;
        timestamp: string;
    }[];
    price: number;
    date: string;
    time?: string;
    created_at: string;
}


// JOB MARKET PLACE

export interface JobStat {
    stats: {
      totalJobs: number;
      activeJobs: number;
      completedJobs: number;
      averageApplications: number;
    },
    trends: {
      totalJobs: number;
      activeJobs: number;
      completedJobs: number;
      averageApplications: number;
    }
}

export interface JobListing extends PAGINATION {
    jobRequests: Job[];
}

export interface Job {
    id: string;
    title: string;
    description: string;
    postedBy: {
        id: string;
        lastName: string;
        firstName: string;
        email: string;
        phoneNumber: string;
    };
    category: CATEGORY;
    applications: number;
    postedAt: string;
    status: STATUS;
}

export interface ApplicationListing extends PAGINATION {
    applications: Application[];
}
export interface Application {
    id: string;
    provider: {
        id: string;
        name: string;
        avatar: string;
        rating: number;
    };
    category: CATEGORY;
    proposed_price: number;
    estimated_time: string;
    status: "PENDING",
    created_at: string;
}


// SUBSCRIPTION
export interface STAT2 {
    value: number;
    change_pct: number;
}

export interface SubscriptionStat {
    summary: {
      active_subscriptions: STAT2;
      free_users: STAT2;
      pro_users: STAT2;
      monthly_revenue: STAT2;
    };
    plan_distribution: PlanDistribution;
    growth: {
        count: number;
        period: string;
    }[];
    revenue_by_plan: {
        period: string;
        FREE: number;
        PRO_MONTHLY: number;
        PRO_ANNUAL: number;
    }[]
}

export interface SubscriptionListing extends PAGINATION {
    records: SubscriptionRecord[],
}


export interface SubscriptionRecord {
    id: string;
    plan: SUBSCRIPTION;
    plan_name: string;
    amount: number;
    currency: "NGN";
    auto_renewal: boolean;
    started_at: string;
    renewal_date: string;
    status:SUBSCRIPTION_STATUS;
    payment_method: string;
    provider: {
        id: string;
        name: string;
        phone: string;
        email: string;
        avatar: string;
    }
}



// VERIFICATION

export interface VerificationStats {
    approved: {
        count: number;
        monthly_change_pct: number
    },
    pending: {
        count: number;
        monthly_change_pct: number
    },
    rejected: {
        count: number;
        monthly_change_pct: number;
    }
}

export interface VerificationList extends PAGINATION {
    verifications: Verification[];
}

export interface Verification {
    id: string;
    provider: USER_BRIEF;
    status: VERIFICATION_STATUS;
    submitted_at: string;
    category: {
        id: string;
        name: string;
    };
    verification_type: string;
    identity_verified: boolean;
    address_verified: boolean;
    business_verified: boolean;
    government_id: string;
    address: string;
    reviewed_at: string;
    reviewed_by: string;
    rejection_reason: string;
    rejection_reason_code: string;
    nin: {
        masked: string;
        is_verified: boolean;
        error: string;
        verified_at: string;
        manually_verified_by: string;
        manually_verified_at: string;
    },
    bvn: {
        masked: string;
        is_verified: boolean;
        error: string;
        verified_at: string;
        manually_verified_by: string;
        manually_verified_at: string;
    },
    professional_document: {
        file_type: "image" | "pdf",
        file_url: string;
    },
}



// Notification

export interface NotificationList extends PAGINATION {
    campaigns: NotificationCampaign[];
}

export interface NotificationCampaign {
    id: string;
    title: string;
    channels: NOTIFICATION_CHANNELS;
    repeat: NOTIFICATION_REPEATE_TYPE;
    audience: NOTIFICATION_AUDIENCE;
    body: string;
    is_active: boolean;
    sent_count: number;
    starts_at: string;
    created_at: string;
}

export interface NotificationStat {
    campaign_notifications_sent: {
        value: number;
        monthly_change_pct: number;
    },
    scheduled_notifications_sent: {
        value: number;
        monthly_change_pct: number;
    },
    delivery_rate_pct:            {
        value: number;
        monthly_change_pct: number;
    },
    open_rate_pct:                {
        value: number;
        monthly_change_pct: number;
    }
}



// ADMIN

export interface AdminDetails {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
    phone_number: string;
    user_type: "ADMIN",
    gender: Gender;
    profile_picture: string;
    location: LOCATION,
    created_at: string;
}


export interface AdminNotificationSettings {
    provider: {
        new_provider_registration: boolean;
        verification_requests: boolean;
        subscription_renewals: boolean;
        subscription_failures: boolean;
    };
    customers_bookings: {
        new_customer_registration: boolean;
        new_booking: boolean;
        booking_cancellations: boolean;
        quote_requests: boolean;
    };
    marketplace_activity: {
        new_job_posts: boolean;
        job_applications: boolean;
        category_updates: boolean;
    };
    support: {
        new_support_tickets: boolean;
        escalated_tickets: boolean;
        ticket_resolution: boolean;
    }
}


// DASHBOARD AND ANALYTICS

export interface DashboardStat {
    total_customers: STAT2;
    total_providers: STAT2;
    active_subscriptions: STAT2
    active_jobs: STAT2;
    total_revenue: STAT2;
}

export interface TopProviders {
    providers: TopProvider[]
}

export interface TopProvider {
    id: string;
    name: string;
    category: string;
    rating: number;
    completed_jobs: number;
    subscription: SUBSCRIPTION
}

export interface SubscriptionRevenueData extends SubscriptionStat {
    plan_distribution: PlanDistribution;
}

export interface PlanDistribution {
    FREE: number
    PRO_MONTHLY: number
    PRO_ANNUAL: number;
    total: number;
    percentages: {
        FREE: number;
        PRO_MONTHLY: number;
        PRO_ANNUAL: number;
    }
}

export interface PendingActions {
    provider_verifications_pending: number;
    subscriptions_expiring_7d: number;
    support_tickets_awaiting_response: number;
}
export interface RecentActivities {
    activities: RecentActivity[];
}

export interface RecentActivity {
    id: string;
    type: ACTIVITY_TYPE;
    title: string;
    description: string;
    timestamp: string;
    relative: string;
}


export interface JobActivity {
    range: string;
    points: {
        name: string;
        completedJobs: number;
        postedJobs: number;
        inProgressJobs: number;
    }[]
}