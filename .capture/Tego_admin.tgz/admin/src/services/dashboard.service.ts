
import client from "./client.service";
import type {
    CategoryDistribution,
    DashboardStat,
    JobActivity,
    PendingActions,
    RecentActivities,
    SubscriptionRevenueData,
    TopProviders
} from "./response-structure";
import type { RANGE } from "./types";

export interface RevenueGrowthPoint {
    label: string;
    count: number;
}

export interface RevenueGrowthSeries {
    range: string;
    start: string;
    end: string;
    points: RevenueGrowthPoint[];
}


export const getDashboardStats = async () => {
    const response = await client.get<DashboardStat>("/admin/dashboard-stats");
    return response.data;
}

export const getPendingActions = async () => {
    const response = await client.get<PendingActions>("/admin/pending-actions?limit=10");
    return response.data;
}
export const getRecentActivity = async () => {
    const response = await client.get<RecentActivities>("/admin/recent-activity?limit=10");
    return response.data;
}

export const getSubscriptionAnalytics = async (range?: RANGE) => {
    const response = await client.get<SubscriptionRevenueData>(`/admin/subscription-stats?period=${range}`);
    return response.data;
}

export const getJobActivity = async (range: RANGE) => {
    const response = await client.get<JobActivity>(`/analytics/job-activity?range=${range}`);
    return response.data;
}


export const getCategoryDistribution = async () => {
    const response = await client.get<CategoryDistribution>(`/admin/reports/category-distribution`);
    return response.data;
}

export const getTopProviders = async () => {
    const response = await client.get<TopProviders>("/admin/reports/top-providers?limit=10");
    return response.data;
}

// admin/reports/category-distribution?days=30
// admin/category-insights?days=7