//period=week&request_type=booking&status=ACCEPTED
import client from "./client.service";
import type { SubscriptionListing, SubscriptionStat, } from "./response-structure";
import { mapToApiParams } from "../utils/formatter";
import type { RANGE, SUBSCRIPTION } from "./types";

export interface BaseParams {
    page?: number;
    limit?: number;
    search?: string;
}

export interface SubscriptionParams extends Record<string, unknown>, BaseParams {
    status?: "ACTIVE" | "INACTIVE";
    plan?: SUBSCRIPTION;
}

export const getSubscriptionStats = async (period: RANGE) => {
    const response = await client.get<SubscriptionStat>(`/admin/subscription-stats?range=${period}`);
    return response.data;
}
export const getSubscriptions = async (params?: SubscriptionParams) => {
    const response = await client.get<SubscriptionListing>(`/admin/subscription-records`, {
        params: params ? mapToApiParams(params) : {},
    });
    return response.data;
}