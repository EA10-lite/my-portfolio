import { Outlet } from "react-router-dom";
import { CustomBreadCrumb, Text } from "../components";
import { useState } from "react";
import { Button } from "../components/ui/button";
import { SupportChat } from "../pages/support/chats/_components";
import type { TICKET_STATUS } from "../services/types";
import { useQuery } from "@tanstack/react-query";
import { getTickets } from "../services/support.service";


export const SupportChatLayout = () => {
    const [filter, setFilter] = useState<TICKET_STATUS>("open");
    const { data, isLoading } = useQuery({
        queryKey: [
            'chats',
            filter,
        ],
        queryFn: () => getTickets({
            scope: "mine",
            status: filter,
        })
    })
    return (
        <div className="support-chats space-y-[20px] px-6 h-full">
            <div className="space-y-[8px]">
                <CustomBreadCrumb
                    items={[
                        { label: "Support Tickets", href: "/support" },
                        { label: "Support Chat", href: "/support/chat" },
                    ]}
                />
                <Text
                    title="Support Chats"
                    className="text-[20px] font-semibold"
                />
            </div>
            <div className="border border-black/6 p-[20px] rounded-[10px] flex gap-4 h-[80%]">
                <div className="w-1/3 space-y-[20px]">
                    <div className="flex items-center gap-4">
                        <Button
                            onClick={()=> setFilter("open")}
                            variant={filter === "open" ? "primary" : "muted"}
                            className="rounded-full w-[118px]"
                        >
                            <span>Open Tickets</span>
                        </Button>
                        <Button
                            onClick={()=> setFilter("close")}
                            variant={filter === "close" ? "primary" : "muted"}
                            className="rounded-full w-[118px]"
                        >
                            <span>Closed Tickets</span>
                        </Button>
                    </div>

                    <div className="space-y-[20px] overflow-y-auto">
                        {!isLoading && data?.tickets.map((ticket)=> (
                            <SupportChat
                                id={ticket.id}
                                user={`${ticket.user.first_name} ${ticket.user.last_name}`}
                                status={ticket.status as TICKET_STATUS}
                                category={ticket.category}
                                key={ticket.id}
                                message={ticket.last_message}
                            />
                        ))}
                    </div>
                </div>
                <div className="w-2/3 w-full h-full">
                    <Outlet />
                </div>
            </div>
        </div>
    )
}

export default SupportChatLayout;