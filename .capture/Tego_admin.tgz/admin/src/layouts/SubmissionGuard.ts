import { useEffect } from "react";
import { useSubmissionStore } from "../store/submissionStore";

const SubmissionGuard = () => {
  const isSubmitting = useSubmissionStore(
    (state) => state.isSubmitting
  );

  useEffect(() => {
    if (!isSubmitting) return;

    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isSubmitting]);

  return null;
};

export default SubmissionGuard;