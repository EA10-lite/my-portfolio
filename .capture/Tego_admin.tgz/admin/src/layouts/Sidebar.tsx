import {
  Settings,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroupContent,
  // SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "../components/ui/sidebar"

import { Link, useLocation } from "react-router-dom";
import { cn } from "../lib/utils";
import { getIcon, type IconType } from "../components/icons/lib";
import { LogoutModal } from "../components";
import { useAdminStore } from "../store/adminStore";
import { useEffect, useRef } from "react";


const items = [
  {
    label: "Overview",
    menu: [
      {
        title: "Dashboard",
        url: "/",
        icon: {
          active: "dashboard-fill",
          inactive: "dashboard-outline"
        },
      },
      {
        title: "Analytics and Reports",
        url: "/analytics",
        icon: {
          active: "analytics-fill",
          inactive: "analytics-outline"
        },
      },
    ]
  },
  {
    label: "Operations",
    menu: [
      {
        title: "Users",
        url: "/users",
        icon: {
          active: "admin-user-fill",
          inactive: "user-outline"
        },
      },
      {
        title: "Providers",
        url: "/providers",
        icon: {
          active: "provider-fill",
          inactive: "provider-outline"
        },
      },
      {
        title: "Customers",
        url: "/customers",
        icon: {
          active: "customer-fill",
          inactive: "customer-outline"
        },
      },
      {
        title: "Services",
        url: "/services",
        icon: {
          active: "service-fill",
          inactive: "service-outline"
        },
      },
      {
        title: "Direct Bookings",
        url: "/requests",
        icon: {
          active: "request-fill",
          inactive: "request-outline"
        },
      },
      {
        title: "Job Marketplace",
        url: "/jobs",
        icon: {
          active: "store-fill",
          inactive: "store-outline"
        },
      },
    ]
  },
  {
    label: "Operations",
    menu: [
      {
        title: "Subscriptions",
        url: "/subscriptions",
        icon: {
          active: "subscription-fill",
          inactive: "subscription-outline"
        },
      },
      {
        title: "Categories",
        url: "/categories",
        icon: {
          active: "category-fill",
          inactive: "category-outline"
        },
      },
      {
        title: "Verfications",
        url: "/verifications",
        icon: {
          active: "verification-fill",
          inactive: "verification-outline"
        },
      },
    ]
  },
  {
    label: "Support",
    menu: [
      {
        title: "Support Tickets",
        url: "/support",
        icon: {
          active: "ticket-fill",
          inactive: "ticket-outline"
        },
      },
      {
        title: "Notifications",
        url: "/notifications",
        icon: {
          active: "bell-fill",
          inactive: "bell-outline"
        },
      }
    ]
  },
]

const AppSidebar = () => {
  const { pathname } = useLocation();
  const { logout } = useAdminStore();

  const activeItemRef = useRef<HTMLLIElement | null>(null);

  useEffect(() => {
    activeItemRef.current?.scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  }, [pathname]);

  return (
    <Sidebar className="fixed left-4 top-24 bottom-20 h-[calc(100vh-8rem)] w-[300px] rounded-2xl shadow-2xl overflow-hidden z-40">
      <SidebarContent className="bg-primary h-full flex flex-col overflow-y-auto no-scrollbar">
        <SidebarGroupContent className="p-4 flex-1">
          {items.map((group, index) => (
            <div key={index} className="mb-4">
              {/* Group label */}
              <p className="text-white/40 text-xs font-semibold uppercase tracking-widest px-4 mb-1">
                {group.label}
              </p>

              {/* Group menu items */}
              <SidebarMenu className="space-y-1 mt-4">
                {group.menu.map((item, i) => {
                  const isActive =
                    pathname === item.url ||
                    (item.url !== "/" && pathname.includes(item.url));

                  return (
                    <SidebarMenuItem
                      key={i}
                      ref={isActive ? activeItemRef : null}
                    >
                      <SidebarMenuButton
                        asChild
                        className={cn(
                          "text-white py-6 px-4 rounded-lg hover:bg-white/10 hover:text-white active:bg-transparent transition-colors",
                          (pathname === item.url || (item.url !== "/" && pathname.includes(item.url))) &&
                          "text-primary bg-white border-[0.5px] border-primary/10 hover:bg-white hover:text-primary"
                        )}
                      >
                        <Link to={item.url}>
                          {getIcon(
                            isActive
                              ? item.icon.active as IconType
                              : item.icon.inactive as IconType
                          )}
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )
                })}
              </SidebarMenu>
            </div>
          ))}
        </SidebarGroupContent>

        <SidebarFooter className="p-4">
          <div className="mb-4">
            {/* Group label */}
            <p className="text-white/40 text-xs font-semibold uppercase tracking-widest px-4 mb-1">
              General
            </p>

            {/* Group menu items */}
            <SidebarMenu className="space-y-1 mt-4">
              <SidebarMenuItem
                ref={pathname.includes("/settings") ? activeItemRef : null}
              >
                <SidebarMenuButton
                  asChild
                  className={cn(
                    "text-white py-6 px-4 rounded-lg hover:bg-white/10 hover:text-white active:bg-transparent transition-colors",
                    (pathname === "/settings") &&
                    "text-primary bg-white border-[0.5px] border-primary/10 hover:bg-white hover:text-primary"
                  )}
                >
                  <Link to={"/settings"}>
                    <Settings className="size-4 shrink-0" />
                    <span>Settings</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <LogoutModal handleLogout={logout} />
            </SidebarMenu>
          </div>
        </SidebarFooter>
      </SidebarContent>
    </Sidebar>
  );
};


export default AppSidebar;
