import { Outlet } from "react-router-dom";
import { SidebarInset, SidebarProvider } from "../components/ui/sidebar";
import Navbar from "./Navbar";
import AppSidebar from "./Sidebar";

/**
 * Top-level layout responsible for synchronising the sidebar and navbar.
 * Uses shadcn/ui SidebarProvider for state management.
 */
const AppLayout = () => {
    return (
        <div className="flex flex-col h-screen">
            <header className="sticky bg-white top-0 z-50 h-20 shrink-0 flex items-center px-4 border-b border-black/6">
                <Navbar />
            </header>

            <div className="flex flex-1 overflow-hidden relative">
                <SidebarProvider>
                    <div className="fixed left-4 top-4 bottom-4 z-20">
                        <AppSidebar />
                    </div>

                    <SidebarInset className="ml-[300px] flex-1 overflow-y-auto">
                        <div className="flex flex-col gap-4 p-4 pb-20 h-full overflow-y-auto">
                            <Outlet />
                        </div>
                    </SidebarInset>
                </SidebarProvider>
            </div>
        </div>
    );
};

export default AppLayout;