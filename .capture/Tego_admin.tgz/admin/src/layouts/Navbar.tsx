import { Bell, Search } from "lucide-react";
import { Text } from "../components";
import { useAdminStore } from "../store/adminStore";
import { useSearchStore } from "../store/searchStore";



const Navbar = () => {
    const { search, setSearch } = useSearchStore();
    const { admin } = useAdminStore();

    return (
        <div className="flex items-center justify-between w-full">
            <img src={"/images/main.svg"} className="w-auto" />
            <div className="flex items-center gap-4">
            <div className="bg-lightblue/50 px-[20px] py-[10px] flex items-center gap-[10px] rounded-[66px] border border-transparent focus-within:border-primary/30 transition-colors">
                <Search size={16} className="text-black/50" />
                <input
                    placeholder="Search service name, provider, category or Service ID..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="outline-none text-xs font-[400] bg-transparent"
                />
            </div>
                <div className="w-10 h-10 flex items-center justify-center bg-lightblue/50 rounded-full">
                    <Bell fill="#33ABF7" color="#33ABF7" size={16} />
                </div>
                <div className="px-[23px] py-[10px] bg-lightblue/50 rounded-full flex gap-2.5">
                    <img src={"./images/avatar.png"} className="w-10 h-10 rounded-full border-[2.04px] border-white" />
                    <div className="space-y-1.5">
                        <Text
                            title={admin?.firstName ?? ''}
                            type="h4"
                            className="font-medium text-black text-[13px]"
                        />
                        <Text
                            title={admin?.userType ?? "Admin"}
                            type="p"
                            className="text-xs"
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Navbar;