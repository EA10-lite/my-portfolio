import { create } from "zustand";

interface SubmissionStore {
  isSubmitting: boolean;
  setSubmitting: (value: boolean) => void;
}

export const useSubmissionStore = create<SubmissionStore>((set) => ({
  isSubmitting: false,

  setSubmitting: (value) => set({
    isSubmitting: value,
  }),
}));