import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import { setAuthToken, removeAuthToken, COOKIE_NAMES } from '../utils/cookies'
import type { ADMIN_ROLE } from '../services/types';

interface Admin {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  userType: ADMIN_ROLE;
  phoneNumber: string;
  createdAt: string;
  updatedAt: string;
}

interface AdminState {
  admin: Admin | null
  isAuthenticated: boolean
  login: (data: { user: Admin; accessToken: string, refreshToken: string}) => void
  logout: () => void
}

export const useAdminStore = create<AdminState>()(
  persist(
    (set) => ({
      admin: null,
      isAuthenticated: false,
      login: ({ user, accessToken, refreshToken}) => {
        setAuthToken(accessToken, COOKIE_NAMES.ACCESS_TOKEN);
        setAuthToken(refreshToken, COOKIE_NAMES.REFRESH_TOKEN);
        set({ admin: user, isAuthenticated: true });
      },
      logout: () => {
        removeAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
        removeAuthToken(COOKIE_NAMES.REFRESH_TOKEN);
        set({ admin: null, isAuthenticated: false });
      },
    }),
    {
      name: 'tego-admin',
      storage: createJSONStorage(() => sessionStorage),
    }
  )
)