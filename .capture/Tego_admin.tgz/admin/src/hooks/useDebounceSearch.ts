// hooks/useDebouncedSearch.ts
import { useEffect, useState } from "react";
import { useSearchStore } from "../store/searchStore";

export const useDebouncedSearch = (delay = 500) => {
  const search = useSearchStore((state) => state.search);

  const [debouncedSearch, setDebouncedSearch] = useState(search);

  useEffect(() => {
    const timeout = setTimeout(() => {
      setDebouncedSearch(search.trim());
    }, delay);

    return () => clearTimeout(timeout);
  }, [search, delay]);

  return debouncedSearch;
};