import axios from "axios";
import type { FilterValues } from "../components/main/FilterContent";
import type { RANGE } from "../services/types";

export const formatDateString = (date?: Date | string | null) => {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;

  if (!d || isNaN(d.getTime())) {

    return "-";
  }

  const day = d.getDate();
  const month = d.toLocaleString("en-US", { month: "long" });
  const year = d.getFullYear();

  const getOrdinal = (n: number) => {
    if (n > 3 && n < 21) return "th";
    switch (n % 10) {
      case 1: return "st";
      case 2: return "nd";
      case 3: return "rd";
      default: return "th";
    }
  };

  let hours = d.getHours();
  const minutes = d.getMinutes().toString().padStart(2, "0");
  const ampm = hours >= 12 ? "pm" : "am";

  hours = hours % 12 || 12;
  const formattedHours = hours.toString().padStart(2, "0");
  return `${day}${getOrdinal(day)} ${month} ${year}, ${formattedHours}:${minutes}${ampm}`;
};


export const formatTime = (date: string | Date) => {
  const d = typeof date === "string" ? new Date(date) : date;

  if (isNaN(d.getTime())) {
    return "-";
  }

  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - d.getTime()) / 1000);

  if (diffInSeconds < 60) {
    return "just now";
  }

  const minutes = Math.floor(diffInSeconds / 60);
  if (minutes < 60) {
    return `${minutes} min${minutes > 1 ? "s" : ""} ago`;
  }

  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  }

  const days = Math.floor(hours / 24);
  if (days < 7) {
    return `${days} day${days > 1 ? "s" : ""} ago`;
  }

  const weeks = Math.floor(days / 7);
  if (weeks < 4) {
    return `${weeks} week${weeks > 1 ? "s" : ""} ago`;
  }

  const months = Math.floor(days / 30);
  if (months < 12) {
    return `${months} month${months > 1 ? "s" : ""} ago`;
  }

  const years = Math.floor(days / 365);
  return `${years} year${years > 1 ? "s" : ""} ago`;
};





/**
 * Formats a number with "k" suffix for thousands
 * Examples:
 * - 2500 => "2.5k"
 * - 19874 => "19.8k"
 * - 500 => "500" (numbers less than 1000 are returned as-is)
 */
export const formatNumber = (value: number) => {
  if (value >= 1000) {
    const thousands = value / 1000;
    // Round to 1 decimal place, but remove trailing zero if it's a whole number
    const rounded = Math.round(thousands * 10) / 10;
    return rounded % 1 === 0 ? `${rounded}k` : `${rounded.toFixed(1)}k`;
  }
  return value.toString();
}

export const formatCurrency = (
  amount: number,
  currency: string = "NGN",
  locale: string = "en-NG",
  showDecimals: boolean = false,
) => {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    minimumFractionDigits: showDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(amount);
};

export const formatFileSize = (size: number): string => {
  if (size < 1024) {
    return `${size} B`;
  }
  if (size < 1024 * 1024) {
    return `${(size / 1024).toFixed(2)} KB`;
  }
  return `${(size / 1024 / 1024).toFixed(2)} MB`;
};

export const formatCreatedAt = (createdAt: string | Date): string => {
  const date = new Date(createdAt);
  const now = new Date();

  const diffMs = now.getTime() - date.getTime();

  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;
  const week = 7 * day;

  // Less than 1 minute
  if (diffMs < minute) {
    return 'Just now';
  }

  // Less than 1 hour
  if (diffMs < hour) {
    const minutes = Math.floor(diffMs / minute);
    return `${minutes}m ago`;
  }

  // Same day
  if (date.toDateString() === now.toDateString()) {
    const hours = Math.floor(diffMs / hour);
    return `${hours}h ago`;
  }

  // Yesterday
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);

  if (date.toDateString() === yesterday.toDateString()) {
    return 'Yesterday';
  }

  // Within last 7 days
  if (diffMs < week) {
    const days = Math.floor(diffMs / day);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }

  // Within last 14 days
  if (diffMs < week * 2) {
    return 'Last week';
  }

  // Older dates
  return date.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
};


// utils/tableFilters.ts (or lib/tableFilters.ts)

export function dateFilterFn(row: any, columnId: string, filterValue: string | null): boolean {
  if (!filterValue) return true  // 👈 no filter applied, show all rows

  const date = new Date(row.getValue(columnId))
  const now = new Date()

  if (filterValue === "week") {
    const weekAgo = new Date(now)
    weekAgo.setDate(now.getDate() - 7)
    return date >= weekAgo
  }
  if (filterValue === "month") {
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()
  }
  if (filterValue === "year") {
    return date.getFullYear() === now.getFullYear()
  }
  if (filterValue === "90days") {
    const past = new Date(now)
    past.setDate(now.getDate() - 90)
    return date >= past
  }
  return true
}

export const getErrorMessage = (
  error: unknown,
  fallbackMessage: string
): string => {
  if (axios.isAxiosError(error)) {
    return (
      error.response?.data?.message ||
      error.message ||
      fallbackMessage
    );
  }

  if (error instanceof Error) {
    return error.message;
  }

  return fallbackMessage;
};


export const mapToApiParams = <T extends Record<string, unknown>>(params?: T) => {
  if (!params) return undefined;
  return Object.fromEntries(
    Object.entries(params)
      .filter(([, value]) => value !== undefined)
      .map(([key, value]) => [
        key,
        Array.isArray(value) ? value.join(",") : value,
      ])
  );
};


export const getFilterLabel = (filters: FilterValues) => {
  return filters["period"]?.includes("1d")
    ? "Today"
    : filters["period"]?.includes("7d")
      ? "This week"
      : filters["period"]?.includes("30d")
        ? "This month"
        : filters["period"]?.includes("90d")
          ? "This quarter"
          : filters["period"]?.includes("1y")
            ? "This year"
            : "All Time";
};

export const getFilterLabelByRange = (date: RANGE) => {
  return date === "week"
      ? "This week"
      : date === "month"
        ? "This month"
        : date === "year"
          ? "This Year"
          : ""
};


export const truncateText = (text: string, maxLength: number = 30): string => {
  if (!text) return "";

  return text.length > maxLength ? `${text.slice(0, maxLength)}...` : text;
};