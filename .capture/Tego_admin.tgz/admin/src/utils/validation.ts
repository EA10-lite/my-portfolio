import * as Yup from "yup";
import type { ADMIN_ROLE, ADMIN_STATUS } from "../services/types";


export const loginValidation = Yup.object().shape({
    phoneNumber: Yup.string().required(),
    password: Yup.string().min(8).max(50).required(),
});

const ADMIN_ROLES: ADMIN_ROLE[] = [
    "SUPER_ADMIN",
    "SUPPORT_ADMIN",
];

const ADMIN_STATUSES: ADMIN_STATUS[] = [
    "active",
    "inactive",
];

export const createAdminUserValidation = (type: "add" | "edit") =>
    Yup.object({
        full_name: Yup.string()
            .trim()
            .min(2, "Full name must be at least 2 characters")
            .max(100, "Full name must not exceed 100 characters")
            .required("Full name is required"),

        email: Yup.string()
            .trim()
            .email("Please enter a valid email address")
            .max(255, "Email must not exceed 255 characters")
            .required("Email is required"),

        phone_number: Yup.string()
            .trim()
            .matches(
                /^\+?[1-9]\d{7,14}$/,
                "Please enter a valid phone number"
            )
            .required("Phone number is required"),

        role: Yup.mixed<ADMIN_ROLE>()
            .oneOf(ADMIN_ROLES, "Please select a valid admin role")
            .required("Admin role is required"),

        status: Yup.mixed<ADMIN_STATUS>()
            .oneOf(ADMIN_STATUSES, "Please select a valid status")
            .required("Status is required"),

        enable_mfa: Yup.boolean()
            .required("MFA preference is required"),

        temporary_password:
            type === "add"
                ? Yup.string()
                    .min(8, "Password must be at least 8 characters")
                    .max(128, "Password must not exceed 128 characters")
                    .matches(
                        /[A-Z]/,
                        "Password must contain at least one uppercase letter"
                    )
                    .matches(
                        /[a-z]/,
                        "Password must contain at least one lowercase letter"
                    )
                    .matches(
                        /\d/,
                        "Password must contain at least one number"
                    )
                    .matches(
                        /[^A-Za-z0-9]/,
                        "Password must contain at least one special character"
                    )
                    .required("Password is required")
                : Yup.string().notRequired(),

        confirm_password:
            type === "add"
                ? Yup.string()
                    .oneOf(
                        [Yup.ref("temporary_password")],
                        "Passwords must match"
                    )
                    .required("Confirm password is required")
                : Yup.string().notRequired(),
});

export const categorySchema = Yup.object({
    name: Yup.string()
        .trim()
        .min(2, "Name must be at least 2 characters")
        .max(50, "Name must not exceed 50 characters")
        .required("Category name is required"),
    icon: Yup.string()
        .required("Please select an icon"),
    image: Yup.mixed<File>()
        .required("Please upload a cover image")
        .test("fileType", "Only image files are allowed", (value) => {
            if (!value) return false;
            return ["image/jpeg", "image/png", "image/webp", "image/jpg"].includes(
                (value as File).type,
            );
        })
        .test("fileSize", "Image must be less than 5MB", (value) => {
            if (!value) return false;
            return (value as File).size <= 5 * 1024 * 1024;
        }),
  });

