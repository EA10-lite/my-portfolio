
export const exportToCSV = (data: any[], filename: string = 'export.csv') => {
    if (!data || !data.length) {
        return;
    }

    // Get headers from the first object
    const headers = Object.keys(data[0]);

    const csvContent = [
        headers.join(','),
        ...data.map(row => headers.map(header => {
            let value = row[header];

            // Handle null/undefined
            if (value === null || value === undefined) {
                return '';
            }

            // Handle objects/arrays
            if (typeof value === 'object') {
                value = JSON.stringify(value).replace(/"/g, '""');
                return `"${value}"`;
            }

            // Handle strings (escape quotes and wrap in quotes if contains comma or newline)
            if (typeof value === 'string') {
                value = value.replace(/"/g, '""');
                return `"${value}"`;
            }

            return value;
        }).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};
