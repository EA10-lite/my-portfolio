/*
    User interface
*/
export type STATUS = "ACTIVE" | "INACTIVE" | "SUSPENDED" | "PENDING_APPROVAL";

export interface Provider {
    id: string;
    firstName: string;
    lastName: string;
    fullName: string;
    category: string;
    createdAt: string;
    subscription: string;
    status: STATUS;
    rating: number;
    completedJobs: number;
    isVerified: boolean;
}

export interface Customer {
    id: string;
    firstName: string;
    lastName: string;
    fullName: string;
    email: string;
    location: string;
    createdAt: string;
    status: STATUS;
}


export interface Service {
    id: string;
    title: string;
    provider: string;
    category: string;
    location: string;
    createdAt: string;
    status: STATUS;
}

export interface Booking {
    id: string;
    customer: string;
    provider: string;
    service: string;
    status: "PENDING" | "COMPLETED" | "CANCELLED" | "SCHEDULED";
    createdAt: string;
}

export interface JobListing {
    id: string;
    title: string;
    applications: number;
    customer: string;
    createdAt: string;
    status: "ACTIVE" | "COMPLETED" | "PENDING" | "CANCELLED";
    category: string;
}

export interface JobApplication {
    id: string;
    rating: number;
    provider: string;
    category: string;
    createdAt: string;
    status: "PENDING" | "SHORTLISTED" | "SUBMITTED";
    price: number;
    time: string;
}

export interface Category {
    id: string;
    title: string;
    services: number;
    providers: number;
    jobs: number;
    status: "ACTIVE" | "DISABLED";
    createdAt: string;
}

export interface Verification {
    id: string;
    provider: string;
    category: string;
    status: "PENDING" | "APPROVED" | "REJECTED";
    submittedAt: string;
    verificationType: "FULL" | "IDENTITY";
}

export interface Support {
    id: string;
    status: "PENDING" | "OPEN" | "RESOLVED" | "ESCALATED";
    user: string;
    issue: string;
    createdAt: string;
}

export interface AdminUser {
    id: string;
    name: string;
    email: string;
    role: string;
    lastActive: string;
    status: "ACTIVE" | "INACTIVE"
}


export interface Subscription {
    id: string;
    plan: string;
    provider: string;
    paymentMethod: string;
    createdAt: string;
    renewalDate: string;
    autoRenewal: "On" | "Off";
    status: "ACTIVE" | "FAILED";
}

export interface FailedSubscription {
    id: string;
    plan: string;
    provider: string;
    paymentMethod: string;
    createdAt: string;
    failureReason: string;
}

export interface Notification {
    id: string;
    title: string;
    audience: string;
    createdAt: string;
    status?: "SENT" | "DELIVERED";
    deliveryRate?: number;
    openRate?: number;
    trigger?: string;
}


export interface ServiceOffered {
    id: string;
    price: number;
    service: string;
    category: string;
    status: "ACTIVE" | "CANCELLED" | "COMPLETED"
}