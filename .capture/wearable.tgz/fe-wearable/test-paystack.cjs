const { usePaystackPayment } = require('react-paystack');
console.log("Found:", typeof usePaystackPayment);
