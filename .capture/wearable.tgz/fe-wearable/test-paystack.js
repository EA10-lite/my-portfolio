const { usePaystackPayment } = require('react-paystack');
console.log(usePaystackPayment);
