import { useState, useMemo } from "react";
import { ProductCard } from "../../components";
import { useGet } from "../../hooks/useGet";

/**
 * Product type from API response
 */
type Product = {
    id: string;
    name: string;
    images: string[];
    price: number;
    discountPrice?: number;
    category: string;
    subCategory?: string;
};

const BestSellers = () => {
    const [selectedCategory, setSelectedCategory] = useState<string>("");

    /**
     * Build API URL with category filter
     */
    const apiUrl = useMemo(() => {
        const params = new URLSearchParams();
        if (selectedCategory) params.append('category', selectedCategory);
        params.append('limit', '20');
        return `/products/user/best-sellers?${params.toString()}`;
    }, [selectedCategory]);

    /**
     * Fetch best-selling products using TanStack Query
     */
    const { data: bestSellersResponse, isLoading: loading, error: queryError } = useGet<{
        success: boolean;
        message: string;
        products?: Product[];
    }>(
        ['products', 'best-sellers', selectedCategory || 'all'],
        apiUrl,
        {
            staleTime: 1000 * 60 * 5, // 5 minutes
        }
    );

    // Extract products from response
    const products = bestSellersResponse?.products || [];
    const error = queryError ? "Failed to load best sellers. Please try again later." : (bestSellersResponse && !bestSellersResponse.success ? bestSellersResponse.message : null);

    return (
        <div className="mb-10 lg:mb-28">
            <div className="container mx-auto px-4 py-10 mb-10 lg:mb-28">
                <div className="flex items-center justify-between gap-4 flex-wrap mb-8 lg:mb-12">
                    <h2
                        className="text-[24px] lg:text-[52px] font-chivo-medium uppercase leading-[100%] text-black"
                        style={{
                            letterSpacing: "-2%"
                        }}
                    >
                        Best Sellers
                    </h2>

                    {/* Category filters */}
                    <div className="flex items-center gap-4 flex-wrap">
                        {["", "male", "female", "accessories", "footwear"].map((category) => (
                            <div
                                key={category}
                                className={`px-8 py-2 cursor-pointer ${selectedCategory === category ? "bg-black text-white" : "bg-black/10 text-black"}`}
                                onClick={() => setSelectedCategory(category)}
                            >
                                <span className="text-sm font-chivo-regular font-normal leading-[100%] uppercase">
                                    {category || "All"}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

                {loading ? (
                    <div className="text-center py-12">
                        <p className="text-sm font-chivo-regular text-[#6C6C6C]">Loading best sellers...</p>
                    </div>
                ) : error ? (
                    <div className="text-center py-12">
                        <p className="text-sm font-chivo-regular text-red-600">{error}</p>
                    </div>
                ) : products.length === 0 ? (
                    <div className="text-center py-12">
                        <p className="text-sm font-chivo-regular text-[#6C6C6C]">No best sellers found.</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {products.map((product) => (
                            <ProductCard
                                key={product.id}
                                id={product.id}
                                image={product.images && product.images.length > 0 ? product.images[0] : "/images/products/placeholder.png"}
                                title={product.name}
                                category={product.category}
                                price={product.discountPrice || product.price}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}

export default BestSellers;