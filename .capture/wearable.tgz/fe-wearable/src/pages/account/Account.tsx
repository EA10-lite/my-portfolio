import { useState, useEffect } from "react";
import { useUserStore } from "../../stores/userStore";
import { Link } from "react-router-dom";
import { LuUser, LuPackage, LuHeart, LuLogOut, LuLoader } from "react-icons/lu";
import { SEO } from "../../components/main";
import { getMyOrders } from "../../services/order.service";
import { formatPrice } from "../../utils/formatter";

type Tab = "profile" | "orders" | "wishlist";

const Account = () => {
    const { user, isAuthenticated, logout, setOpenLoginModal } = useUserStore();
    const [activeTab, setActiveTab] = useState<Tab>("profile");
    const [orders, setOrders] = useState<any[]>([]);
    const [isLoadingOrders, setIsLoadingOrders] = useState(false);

    useEffect(() => {
        if (activeTab === "orders" && isAuthenticated) {
            setIsLoadingOrders(true);
            getMyOrders()
                .then(res => {
                    if (res.success) {
                        setOrders(res.orders || []);
                    }
                })
                .finally(() => {
                    setIsLoadingOrders(false);
                });
        }
    }, [activeTab, isAuthenticated]);

    if (!isAuthenticated || !user) {
        return (
            <div className="account-page">
                <SEO title="Sign In - My Account" />
                <div className="container mx-auto px-4 py-16 lg:py-24 text-center max-w-md">
                    <div className="w-16 h-16 bg-[#F2F2F2] flex items-center justify-center mx-auto mb-6">
                        <LuUser size={28} className="text-[#6C6C6C]" />
                    </div>
                    <h1 className="text-[28px] font-chivo-medium uppercase text-black mb-3" style={{ letterSpacing: "-2%" }}>
                        My Account
                    </h1>
                    <p className="text-sm font-chivo-regular text-[#6C6C6C] mb-8">
                        Sign in to view your profile, orders, and wishlist.
                    </p>
                    <button
                        onClick={() => setOpenLoginModal(true)}
                        className="bg-black text-white px-10 py-4 text-sm font-chivo-medium uppercase hover:bg-gray-900 transition-colors duration-200"
                    >
                        Sign In
                    </button>
                </div>
            </div>
        );
    }

    const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
        { key: "profile", label: "Profile", icon: <LuUser size={16} /> },
        { key: "orders", label: "Orders", icon: <LuPackage size={16} /> },
        { key: "wishlist", label: "Wishlist", icon: <LuHeart size={16} /> },
    ];

    return (
        <div className="account-page">
            <SEO title="My Account" />
            <div className="container mx-auto px-4 py-10 lg:py-16 mb-10 lg:mb-28">
                <div className="flex items-center justify-between mb-8 lg:mb-12">
                    <h1 className="text-[28px] lg:text-[48px] font-chivo-medium uppercase text-black" style={{ letterSpacing: "-2%" }}>
                        My Account
                    </h1>
                    <button
                        onClick={logout}
                        className="flex items-center gap-2 text-sm font-chivo-regular text-[#6C6C6C] hover:text-black transition-colors duration-200 uppercase"
                    >
                        <LuLogOut size={16} />
                        Sign Out
                    </button>
                </div>

                {/* Tab Navigation */}
                <div className="flex items-center gap-0 border-b border-[#E4E4E4] mb-8 overflow-x-auto">
                    {tabs.map((tab) => (
                        <button
                            key={tab.key}
                            onClick={() => setActiveTab(tab.key)}
                            className={`flex items-center gap-2 px-6 py-3 text-sm font-chivo-regular uppercase border-b-2 transition-all duration-200 whitespace-nowrap ${
                                activeTab === tab.key
                                    ? "border-black text-black"
                                    : "border-transparent text-[#6C6C6C] hover:text-black"
                            }`}
                        >
                            {tab.icon}
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Profile Tab */}
                {activeTab === "profile" && (
                    <div className="max-w-lg" style={{ animation: "fadeInUp 0.4s ease-out both" }}>
                        <h2 className="text-base font-chivo-medium uppercase text-black mb-6" style={{ letterSpacing: "-2%" }}>
                            Personal Information
                        </h2>
                        <div className="space-y-6">
                            <div>
                                <label className="text-xs font-chivo-medium uppercase text-[#6C6C6C] mb-1 block">Full Name</label>
                                <p className="text-base font-chivo-regular text-black border-b border-[#E4E4E4] pb-2">{user.name || "Not set"}</p>
                            </div>
                            <div>
                                <label className="text-xs font-chivo-medium uppercase text-[#6C6C6C] mb-1 block">Email Address</label>
                                <p className="text-base font-chivo-regular text-black border-b border-[#E4E4E4] pb-2">{user.email}</p>
                            </div>
                            <div>
                                <label className="text-xs font-chivo-medium uppercase text-[#6C6C6C] mb-1 block">Phone Number</label>
                                <p className="text-base font-chivo-regular text-black border-b border-[#E4E4E4] pb-2">{user.phone || "Not set"}</p>
                            </div>
                            <div>
                                <label className="text-xs font-chivo-medium uppercase text-[#6C6C6C] mb-1 block">Delivery Address</label>
                                <p className="text-base font-chivo-regular text-black border-b border-[#E4E4E4] pb-2">{user.address || "Not set"}</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Orders Tab */}
                {activeTab === "orders" && (
                    <div style={{ animation: "fadeInUp 0.4s ease-out both" }}>
                        <h2 className="text-base font-chivo-medium uppercase text-black mb-6" style={{ letterSpacing: "-2%" }}>
                            Order History
                        </h2>
                        {isLoadingOrders ? (
                            <div className="flex flex-col items-center justify-center py-16">
                                <LuLoader className="w-8 h-8 animate-spin text-[#6C6C6C] mb-4" />
                                <p className="text-sm font-chivo-regular text-[#6C6C6C]">Loading your orders...</p>
                            </div>
                        ) : orders.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-16 text-center">
                                <LuPackage size={48} className="text-[#E4E4E4] mb-4" />
                                <h3 className="text-base font-chivo-medium uppercase text-black mb-2">No orders yet</h3>
                                <p className="text-sm font-chivo-regular text-[#6C6C6C] mb-6">
                                    Start shopping to see your order history here.
                                </p>
                                <Link
                                    to="/category/male"
                                    className="bg-black text-white px-8 py-3 text-sm font-chivo-medium uppercase hover:bg-gray-900 transition-colors duration-200"
                                >
                                    Browse Products
                                </Link>
                            </div>
                        ) : (
                            <div className="space-y-6">
                                {orders.map(order => (
                                    <div key={order._id} className="border border-[#E4E4E4] p-6 flex flex-col md:flex-row gap-6 justify-between">
                                        <div>
                                            <p className="text-xs font-chivo-medium uppercase text-[#6C6C6C] mb-1">Order #{order._id.slice(-6)}</p>
                                            <p className="text-sm font-chivo-regular mb-4">{new Date(order.createdAt).toLocaleDateString()}</p>
                                            <p className="text-sm font-chivo-medium mb-1">Status: <span className="uppercase">{order.orderStatus}</span></p>
                                            <p className="text-sm font-chivo-medium">Payment: <span className="uppercase">{order.paymentStatus}</span></p>
                                        </div>
                                        <div className="text-left md:text-right flex flex-col justify-between">
                                            <p className="text-base font-chivo-medium">{formatPrice(order.total)} NGN</p>
                                            <p className="text-sm font-chivo-regular text-[#6C6C6C]">Qty: {order.quantity}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Wishlist Tab */}
                {activeTab === "wishlist" && (
                    <div style={{ animation: "fadeInUp 0.4s ease-out both" }}>
                        <h2 className="text-base font-chivo-medium uppercase text-black mb-6" style={{ letterSpacing: "-2%" }}>
                            Wishlist
                        </h2>
                        <div className="flex flex-col items-center justify-center py-16 text-center">
                            <LuHeart size={48} className="text-[#E4E4E4] mb-4" />
                            <h3 className="text-base font-chivo-medium uppercase text-black mb-2">Your wishlist is empty</h3>
                            <p className="text-sm font-chivo-regular text-[#6C6C6C] mb-6">
                                Save your favourite products here.
                            </p>
                            <Link
                                to="/"
                                className="bg-black text-white px-8 py-3 text-sm font-chivo-medium uppercase hover:bg-gray-900 transition-colors duration-200"
                            >
                                Explore Products
                            </Link>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Account;
