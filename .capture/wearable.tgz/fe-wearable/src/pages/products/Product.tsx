import { useState, useEffect, useMemo, useRef } from "react";
import { Quantity, ProductCard, SEO } from "../../components";
import { Skeleton } from "../../components/main";
import { formatPrice } from "../../utils/formatter";
import { LuShoppingBag, LuZoomIn } from "react-icons/lu";
import { Link, useParams } from "react-router-dom";
import useCartStore, { type CartItem } from "../../stores/cartStore";
import { useToastStore } from "../../stores/toastStore";
import { useGet } from "../../hooks/useGet";
import { motion, AnimatePresence } from "framer-motion";

type Product = {
    id: string;
    name: string;
    description?: string;
    images: string[];
    price: number;
    discountPrice?: number;
    category: string;
    subCategory?: string;
    colors: string[];
    sizes: string[];
    stock: number;
};

type SimilarProduct = {
    id: string;
    name: string;
    images: string[];
    price: number;
    discountPrice?: number;
    category: string;
    subCategory?: string;
};

const Product = () => {
    const { id } = useParams<{ category: string; id: string }>();
    const [selectedSize, setSelectedSize] = useState<string | null>(null);
    const [selectedColor, setSelectedColor] = useState<string | null>(null);
    const [quantity, setQuantity] = useState<number>(1);
    const [activeImage, setActiveImage] = useState<number>(0);
    const [lightboxOpen, setLightboxOpen] = useState(false);

    const { addItem, updateQuantity, isInCart } = useCartStore();
    const { showToast } = useToastStore();

    const prevSelectionsRef = useRef<{ size: string | null; color: string | null; id: string | undefined }>({
        size: null, color: null, id: undefined,
    });

    const { data: productResponse, isLoading: loading, error: queryError } = useGet<{
        success: boolean;
        message: string;
        product?: Product;
        similarProducts?: SimilarProduct[];
    }>(
        ['product', id || ''],
        id ? `/products/user/${id}` : '',
        { enabled: !!id, staleTime: 1000 * 60 * 5 }
    );

    const product = productResponse?.product || null;
    const similarProducts = productResponse?.similarProducts || [];
    const error = queryError
        ? "Failed to load product. Please try again later."
        : (productResponse && !productResponse.success ? productResponse.message : null);

    const generateCartItemId = (productId: string, color?: string, size?: string) =>
        `${productId}${color ? `-${color}` : ''}${size ? `-${size}` : ''}`;

    const handleAddToCart = () => {
        if (!product) { showToast("Product loading, please wait", "warning", "top"); return; }
        if (!selectedSize) { showToast("Please select a size", "warning", "top"); return; }

        const productId = product.id;
        const productPrice = product.discountPrice || product.price;
        const productImage = product.images?.[0] || "/images/products/placeholder.png";

        const existingCartItem = isInCart(productId, selectedColor || undefined, selectedSize);

        if (existingCartItem) {
            updateQuantity(existingCartItem.id, quantity);
            showToast("Cart updated", "success", "top");
        } else {
            const cartItem: CartItem = {
                id: generateCartItemId(productId, selectedColor || undefined, selectedSize),
                name: product.name,
                price: productPrice,
                quantity,
                image: productImage,
                color: selectedColor || undefined,
                size: selectedSize,
                productId,
            };
            addItem(cartItem);
            showToast(`${product.name} added to cart!`, "success", "top");
        }
    };

    const existingItem = useMemo(() => {
        if (!selectedSize || !product) return undefined;
        return isInCart(product.id, selectedColor || undefined, selectedSize);
    }, [product, selectedColor, selectedSize, isInCart]);

    useEffect(() => {
        const currentSelections = { size: selectedSize, color: selectedColor, id };
        const changed =
            prevSelectionsRef.current.size !== currentSelections.size ||
            prevSelectionsRef.current.color !== currentSelections.color ||
            prevSelectionsRef.current.id !== currentSelections.id;
        if (changed) {
            if (existingItem && selectedSize) setQuantity(existingItem.quantity);
            else if (selectedSize) setQuantity(1);
            prevSelectionsRef.current = currentSelections;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [existingItem?.id, selectedSize, selectedColor, id]);

    // Reset active image when product changes
    useEffect(() => {
        setActiveImage(0);
    }, [id]);

    const isButtonDisabled = existingItem !== undefined && existingItem.quantity === quantity;

    // Loading skeleton
    if (loading) {
        return (
            <div className="product">
                <div className="container mx-auto px-4 py-16 mb-10 lg:mb-28">
                    <Skeleton className="w-48 h-4 mb-8" />
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div>
                            <Skeleton className="w-full h-[304px] lg:h-[673px] mb-4" />
                            <div className="flex gap-3">
                                {Array.from({ length: 4 }).map((_, i) => (
                                    <Skeleton key={i} className="w-16 h-16 lg:w-[140px] lg:h-[140px]" />
                                ))}
                            </div>
                        </div>
                        <div>
                            <Skeleton className="w-1/3 h-4 mb-3" />
                            <Skeleton className="w-2/3 h-10 mb-4" />
                            <Skeleton className="w-1/4 h-6 mb-8" />
                            <Skeleton className="w-full h-24 mb-8" />
                            <Skeleton className="w-1/3 h-6 mb-3" />
                            <div className="flex gap-3 mb-8">
                                {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="w-16 h-10" />)}
                            </div>
                            <Skeleton className="w-full h-14" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (error || !product) {
        return (
            <div className="product">
                <div className="container mx-auto px-4 py-16">
                    <div className="text-center py-12">
                        <p className="text-sm font-chivo-regular text-red-600">{error || "Product not found"}</p>
                        <Link to="/" className="mt-4 inline-block text-sm font-chivo-regular text-[#6C6C6C] underline">
                            Return to Home
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    const availableSizes = product.sizes || [];
    const availableColors = product.colors || [];

    return (
        <div className="product">
            <SEO title={product.name} description={product.description} />
            {/* Lightbox */}
            {lightboxOpen && (
                <div
                    className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
                    onClick={() => setLightboxOpen(false)}
                >
                    <button
                        className="absolute top-4 right-4 text-white text-2xl font-chivo-regular hover:text-[#6C6C6C] transition-colors"
                        onClick={() => setLightboxOpen(false)}
                    >
                        ✕
                    </button>
                    <img
                        src={product.images[activeImage]}
                        alt={product.name}
                        className="max-h-[90vh] max-w-[90vw] object-contain"
                        onClick={(e) => e.stopPropagation()}
                    />
                </div>
            )}

            <div className="container mx-auto px-4 py-16 mb-10 lg:mb-28">
                {/* Breadcrumb */}
                <div className="breadcrumb mb-6">
                    <Link to={`/${product.category}`}>
                        <span className="text-sm font-chivo-regular uppercase text-[#6C6C6C] underline">{product.category}</span>
                    </Link>
                    {product.subCategory && (
                        <>
                            {" / "}
                            <span className="text-sm font-chivo-regular uppercase text-[#6C6C6C]">{product.subCategory}</span>
                        </>
                    )}
                    {" / "}
                    <span className="text-sm font-chivo-regular uppercase text-black">Product Details</span>
                </div>

                <div className="product-details">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Images */}
                        <div className="product-images flex flex-col gap-4">
                            <div
                                className="product-banner grow w-full h-[304px] lg:h-[673px] relative group cursor-zoom-in overflow-hidden"
                                onClick={() => setLightboxOpen(true)}
                            >
                                <AnimatePresence mode="wait">
                                    <motion.img
                                        key={activeImage}
                                        initial={{ opacity: 0 }}
                                        animate={{ opacity: 1 }}
                                        exit={{ opacity: 0 }}
                                        transition={{ duration: 0.3 }}
                                        src={product.images[activeImage] || "/images/products/placeholder.png"}
                                        alt={product.name}
                                        className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                                    />
                                </AnimatePresence>
                                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/10">
                                    <LuZoomIn size={32} className="text-white drop-shadow-lg" />
                                </div>
                                {product.stock > 0 && product.stock < 10 && (
                                    <div className="absolute top-4 right-4 bg-black text-white px-3 py-1">
                                        <span className="text-xs font-chivo-regular uppercase">Only {product.stock} left</span>
                                    </div>
                                )}
                                {product.stock === 0 && (
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                                        <span className="text-white font-chivo-medium uppercase text-sm bg-black px-4 py-2">Out of Stock</span>
                                    </div>
                                )}
                            </div>

                            {product.images.length > 1 && (
                                <div className="flex items-center gap-3 overflow-x-auto">
                                    {product.images.map((image, index) => (
                                        <button
                                            key={index}
                                            onClick={() => setActiveImage(index)}
                                            className={`w-[64px] lg:w-[100px] h-[64px] lg:h-[100px] flex-shrink-0 overflow-hidden transition-all duration-300 ${
                                                activeImage === index ? "ring-2 ring-black" : "opacity-50 hover:opacity-100"
                                            }`}
                                        >
                                            <img
                                                src={image}
                                                alt={`${product.name} ${index + 1}`}
                                                className="w-full h-full object-cover"
                                                loading="lazy"
                                            />
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Product Info */}
                        <div className="product-info flex flex-col">
                            <div className="flex-1 grow">
                                <div className="product-title mb-6 lg:mb-10">
                                    <p className="text-sm font-chivo-regular uppercase text-[#6C6C6C] mb-2">
                                        {product.category}{product.subCategory ? ` / ${product.subCategory}` : ""}
                                    </p>
                                    <h1 className="text-[24px] lg:text-[40px] font-chivo-medium uppercase leading-[100%] text-black mb-4" style={{ letterSpacing: "-2%" }}>
                                        {product.name}
                                    </h1>
                                    <p className="text-[20px] lg:text-[24px] font-chivo-regular uppercase text-[#6C6C6C]">
                                        {formatPrice(product.discountPrice || product.price)} NGN
                                        {product.discountPrice && product.discountPrice < product.price && (
                                            <span className="ml-3 text-base line-through text-[#AFAFAF]">
                                                {formatPrice(product.price)} NGN
                                            </span>
                                        )}
                                    </p>
                                </div>

                                {product.description && (
                                    <div className="description mb-6 lg:mb-10">
                                        <h4 className="text-base font-chivo-medium uppercase text-black mb-3" style={{ letterSpacing: "-2%" }}>
                                            Product Description
                                        </h4>
                                        <p className="text-sm lg:text-base font-chivo-regular font-[300] leading-[24px] text-[#6C6C6C]" style={{ letterSpacing: "-2%" }}>
                                            {product.description}
                                        </p>
                                    </div>
                                )}

                                {/* Sizes */}
                                {availableSizes.length > 0 && (
                                    <div className="sizes mb-6 lg:mb-10">
                                        <h4 className="text-base font-chivo-medium uppercase text-black mb-4" style={{ letterSpacing: "-2%" }}>
                                            Available Sizes
                                        </h4>
                                        <div className="flex items-center gap-3 flex-wrap">
                                            {availableSizes.map((size) => (
                                                <button
                                                    key={size}
                                                    onClick={() => setSelectedSize(size)}
                                                    className={`px-5 py-2 text-sm font-chivo-regular uppercase transition-all duration-200 ${
                                                        selectedSize === size
                                                            ? "bg-black text-white"
                                                            : "bg-black/10 text-black hover:bg-black/20"
                                                    }`}
                                                >
                                                    {size}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/* Colors — from API data */}
                                {availableColors.length > 0 && (
                                    <div className="color mb-6 lg:mb-10">
                                        <h4 className="text-base font-chivo-medium uppercase text-black mb-4" style={{ letterSpacing: "-2%" }}>
                                            Select Color
                                        </h4>
                                        <div className="flex items-center gap-3 flex-wrap">
                                            {availableColors.map((color) => (
                                                <button
                                                    key={color}
                                                    onClick={() => setSelectedColor(color)}
                                                    className={`px-5 py-2 text-sm font-chivo-regular uppercase transition-all duration-200 ${
                                                        selectedColor === color
                                                            ? "bg-black text-white"
                                                            : "bg-black/10 text-black hover:bg-black/20"
                                                    }`}
                                                >
                                                    {color}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                {/* Quantity */}
                                <div className="quantity mb-6">
                                    <h4 className="text-base font-chivo-medium uppercase text-black mb-4" style={{ letterSpacing: "-2%" }}>
                                        Quantity
                                    </h4>
                                    <Quantity
                                        quantity={quantity}
                                        increment={() => setQuantity((p) => Math.min(p + 1, 99))}
                                        decrement={() => setQuantity((p) => Math.max(p - 1, 1))}
                                    />
                                </div>
                            </div>

                            <div className="w-full h-[1px] bg-[#E4E4E4] my-4" />

                            <button
                                className={`p-4 text-sm lg:text-base font-chivo-medium leading-[100%] uppercase w-full flex items-center justify-center gap-2 transition-all duration-200 ${
                                    isButtonDisabled || product.stock === 0
                                        ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                                        : "bg-black text-white cursor-pointer hover:bg-gray-900 active:scale-[0.99]"
                                }`}
                                onClick={handleAddToCart}
                                disabled={isButtonDisabled || product.stock === 0}
                            >
                                <span>
                                    {product.stock === 0 ? "Out of Stock" : existingItem ? "Update Cart" : "Add to Cart"}
                                </span>
                                <LuShoppingBag size={16} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Similar Products */}
            {similarProducts.length > 0 && (
                <div className="similar-products mb-10 lg:mb-28">
                    <div className="container mx-auto px-4">
                        <h2 className="text-[24px] lg:text-[52px] font-chivo-medium uppercase leading-[100%] text-black mb-8 lg:mb-12" style={{ letterSpacing: "-2%" }}>
                            You May Also Like
                        </h2>
                        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
                            {similarProducts.map((p) => (
                                <ProductCard
                                    key={p.id}
                                    id={p.id}
                                    image={p.images?.[0] || "/images/products/placeholder.png"}
                                    title={p.name}
                                    category={p.category}
                                    price={p.discountPrice || p.price}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Product;