import { Link } from "react-router-dom";

const NotFound = () => {
    return (
        <div className="not-found min-h-[60vh] flex items-center justify-center">
            <div className="container mx-auto px-4 text-center">
                <h1 className="text-6xl lg:text-8xl font-chivo-bold mb-4">404</h1>
                <h2 className="text-2xl lg:text-4xl font-chivo-medium uppercase mb-4">
                    Page Not Found
                </h2>
                <p className="text-base lg:text-lg font-chivo-regular text-[#6C6C6C] mb-8">
                    The page you're looking for doesn't exist or has been moved.
                </p>
                <Link
                    to="/"
                    className="inline-block px-8 py-4 text-sm lg:text-base font-chivo-regular font-normal leading-[100%] uppercase bg-black text-white cursor-pointer"
                >
                    Go Back Home
                </Link>
            </div>
        </div>
    );
};

export default NotFound;

