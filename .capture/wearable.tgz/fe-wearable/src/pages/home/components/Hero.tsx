import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

/**
 * Hero Section Component
 * Features staggered fade-in animations for a smooth, elegant entrance using Framer Motion
 */
const Hero = () => {
    const navigate = useNavigate();

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.15,
                delayChildren: 0.1,
            }
        }
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { 
            opacity: 1, 
            y: 0,
            transition: {
                duration: 0.8
            }
        }
    };

    return (
        <div className="mb-8 app-hero bg-black">
            <div className="container mx-auto py-16 relative">
                <motion.div 
                    className="hero-content w-full px-4 lg:max-w-[700px] min-h-screen flex flex-col justify-end"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    {/* Badge */}
                    <motion.div 
                        className="flex items-center gap-4 mb-4 bg-black px-4 py-2 w-fit"
                        variants={itemVariants}
                    >
                        <img src="/icons/bag.svg" alt="shopping-bag" />
                        <p className="font-chivo-regular font-normal uppercase text-sm leading-[100%] text-white">Your Ultimate Fashion Hub</p>
                    </motion.div>
                    
                    {/* Main Heading */}
                    <motion.h1 
                        className="text-[32px] lg:text-[80px] leading-[37px] lg:leading-[69px] font-chivo-medium uppercase mb-4 text-white"
                        style={{ letterSpacing: "-2%" }}
                        variants={itemVariants}
                    >
                        Your Style Hub — All in One Place
                    </motion.h1>
                    
                    {/* Description */}
                    <motion.p 
                        className="font-chivo-regular font-normal uppercase text-sm lg:text-base leading-[21px] lg:leading-[24px] text-justify mb-6 text-white"
                        style={{ letterSpacing: "-2%" }}
                        variants={itemVariants}
                    >
                        Discover the best of men's and women's fashion, from everyday essentials to statement accessories — all curated in one stylish marketplace
                    </motion.p>
                    
                    {/* CTA Button */}
                    <motion.button
                        onClick={() => navigate('/category/male')}
                        className="bg-white text-black p-4 text-sm lg:text-base font-chivo font-medium leading-[100%] uppercase w-fit hover:bg-[#F2F2F2] hover:scale-105 active:scale-95 transition-all"
                        variants={itemVariants}
                    >
                        <span>Explore Categories</span>
                    </motion.button>
                </motion.div>
            </div>
        </div>
    )
}

export default Hero;
