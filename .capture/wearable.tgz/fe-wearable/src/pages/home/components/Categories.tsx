import { Link } from "react-router-dom";
import { CATEGORIES } from "../../../constants/data";

const Categories = () => {
    return (
        <div className="categories mb-10 lg:mb-28">
            <div className="container mx-auto px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {CATEGORIES.map((category) => (
                        <Category 
                            key={category.title} 
                            title={category.title} 
                            image={category.image} 
                            count={category.count} 
                            href={category.href} 
                        />
                    ))}
                </div>
            </div>
        </div>
    )
}


type CategoryProps = {
    title: string;
    image: string;
    count: number;
    href: string;
}

const Category = ({ title, image, count, href }: CategoryProps) => {
    return (
        <div className="category">
            <Link to={href}> 
                <div className="category-image mb-4 h-[365px] bg-[#F2F2F2]">
                    <img 
                        src={image} 
                        alt={title} 
                        className="w-full h-full object-cover"
                    />
                </div>
                <div className="category-content flex items-center justify-between">
                    <h3 className="category-title text-base font-chivo-medium uppercase">{title}</h3>
                    <p className="category-count text-sm font-chivo-regular uppercase">({count})</p>
                </div>
            </Link>
        </div>
    )
}

export default Categories;