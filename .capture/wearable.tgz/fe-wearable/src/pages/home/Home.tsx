import { BestSellers, NewArrivals, SEO } from "../../components";
import { Categories, Hero } from "./components";

const Home = () => {
    return (
        <div className="">
            <SEO title="Home" />
            <Hero />
            <Categories />
            <NewArrivals />
            <BestSellers />
        </div>
    )
}

export default Home;