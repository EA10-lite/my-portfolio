import { Link, useParams } from "react-router-dom";
import { useMemo } from "react";
import { BestSellers, NewArrivals, ProductCard, SEO } from "../../components";
import { Skeleton } from "../../components/main";
import { useGet } from "../../hooks/useGet";


/**
 * Product type from API response
 */
type Product = {
    id: string;
    name: string;
    images: string[];
    price: number;
    discountPrice?: number;
    category: string;
    subCategory?: string;
};

const Category = () => {
    const { category, subcategory } = useParams<{ category?: string; subcategory?: string }>();

    /**
     * Build API URL based on category and subcategory
     * Include newArrivals and bestSellers in the request to reduce API calls
     */
    const apiUrl = useMemo(() => {
        if (subcategory) {
            const params = new URLSearchParams();
            if (category) params.append('category', category);
            params.append('limit', '20');
            params.append('include', 'newArrivals,bestSellers'); // Request additional data
            return `/products/user/subcategory/${subcategory}?${params.toString()}`;
        } else if (category) {
            const params = new URLSearchParams();
            params.append('limit', '20');
            params.append('include', 'newArrivals,bestSellers'); // Request additional data
            return `/products/user/category/${category}?${params.toString()}`;
        }
        return '';
    }, [category, subcategory]);

    /**
     * Fetch products based on category and subcategory using TanStack Query
     * This single request will also include newArrivals and bestSellers if available
     */
    const { data: productsResponse, isLoading: loading, error: queryError } = useGet<{
        success: boolean;
        message: string;
        products?: Product[];
        newArrivals?: Product[];
        bestSellers?: Product[];
    }>(
        ['products', 'category', category || '', 'subcategory', subcategory || '', 'with-extras'],
        apiUrl,
        {
            enabled: !!apiUrl,
            staleTime: 1000 * 60 * 5, // 5 minutes
        }
    );

    // Extract products, newArrivals, and bestSellers from response
    const products = productsResponse?.products || [];
    const newArrivals = productsResponse?.newArrivals;
    const bestSellers = productsResponse?.bestSellers;
    const categoryTitle = useMemo(() => {
        if (subcategory) return `${subcategory} - ${category}`;
        if (category) return category;
        return "Category";
    }, [category, subcategory]);
    const error = queryError ? "Failed to load products. Please try again later." : (productsResponse && !productsResponse.success ? productsResponse.message : null);

    return (
        <div className="category">
            <SEO title={categoryTitle.charAt(0).toUpperCase() + categoryTitle.slice(1)} />
            <div className="container mx-auto px-4 py-10 lg:py-16 mb-10 lg:mb-28">
                <div className="breadcrumb mb-8">
                    <Link to={`/`}>
                        <span className="text-sm lg:text-base font-chivo-regular uppercase leading-[100%] text-[#6C6C6C] underline">Home</span>
                    </Link>
                    {category && (
                        <>
                            {" / "}
                            {!subcategory ? (
                                <span className="text-sm lg:text-base font-chivo-regular uppercase leading-[100%] text-black">{category}</span>
                            ) : (
                                <>
                                    <Link to={`/${category}`}>
                                        <span className="text-sm lg:text-base font-chivo-regular uppercase leading-[100%] text-[#6C6C6C] underline">{category}</span>
                                    </Link>
                                    {" / "}
                                    <span className="text-sm lg:text-base font-chivo-regular uppercase leading-[100%] text-black">{subcategory}</span>
                                </>
                            )}
                        </>
                    )}
                </div>

                {loading ? (
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
                        {Array.from({ length: 8 }).map((_, i) => (
                            <div key={i}>
                                <Skeleton className="w-full h-[225px] md:h-[325px] lg:h-[365px] mb-4" />
                                <Skeleton className="w-1/2 h-3 mb-2" />
                                <Skeleton className="w-full h-4 mb-2" />
                                <Skeleton className="w-1/3 h-3" />
                            </div>
                        ))}
                    </div>
                ) : error ? (
                    <div className="text-center py-12">
                        <p className="text-sm font-chivo-regular text-red-600">{error}</p>
                    </div>
                ) : products.length === 0 ? (
                    <div className="text-center py-12">
                        <p className="text-sm font-chivo-regular text-[#6C6C6C]">No products found in this category.</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
                        {products.map((product) => (
                            <ProductCard
                                key={product.id}
                                id={product.id}
                                image={product.images && product.images.length > 0 ? product.images[0] : "/images/products/placeholder.png"}
                                title={product.name}
                                category={product.subCategory || product.category}
                                price={product.discountPrice || product.price}
                            />
                        ))}
                    </div>
                )}
            </div>
            {/* 
                Pass products as props if available from the main request (hybrid approach).
                If not available, components will fetch their own data (fallback to uncontrolled mode).
                This optimizes performance by reducing API calls when possible.
            */}
            <NewArrivals category={category} products={newArrivals} />
            <BestSellers showFilters={false} category={category} products={bestSellers} />
            <NewArrivals title={"Explore Products"} category={category} products={newArrivals} />
        </div>
    )
}

export default Category;