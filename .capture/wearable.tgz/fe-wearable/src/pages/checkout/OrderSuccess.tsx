import { useLocation, Link } from "react-router-dom";
import { LuPackageCheck, LuArrowRight } from "react-icons/lu";

const OrderSuccess = () => {
    const { state } = useLocation();
    const customerName = state?.customerName || "Customer";
    const customerEmail = state?.customerEmail || "";
    const orders = state?.orders || [];

    return (
        <div className="order-success">
            <div className="container mx-auto px-4 py-16 lg:py-24 text-center">
                <div
                    className="flex flex-col items-center max-w-lg mx-auto"
                    style={{ animation: "fadeInUp 0.6s ease-out both" }}
                >
                    {/* Success Icon */}
                    <div className="w-20 h-20 bg-black flex items-center justify-center mb-8">
                        <LuPackageCheck size={40} className="text-white" />
                    </div>

                    {/* Heading */}
                    <h1
                        className="text-[28px] lg:text-[48px] font-chivo-medium uppercase leading-[100%] text-black mb-4"
                        style={{ letterSpacing: "-2%" }}
                    >
                        Order Placed
                    </h1>

                    <p className="text-base font-chivo-regular text-[#6C6C6C] mb-2">
                        Thank you, <span className="text-black font-chivo-medium">{customerName}</span>!
                    </p>
                    {customerEmail && (
                        <p className="text-sm font-chivo-regular text-[#6C6C6C] mb-8">
                            A confirmation will be sent to <span className="text-black">{customerEmail}</span>.
                        </p>
                    )}

                    {/* Order Count */}
                    {orders.length > 0 && (
                        <div className="w-full border border-[#E4E4E4] p-6 mb-8 text-left">
                            <p className="text-sm font-chivo-medium uppercase mb-3">
                                {orders.length} item{orders.length !== 1 ? "s" : ""} ordered
                            </p>
                            <p className="text-sm font-chivo-regular text-[#6C6C6C]">
                                Your order is being processed. You will receive updates via email.
                            </p>
                        </div>
                    )}

                    {/* CTAs */}
                    <div className="flex flex-col sm:flex-row items-center gap-4 w-full">
                        <Link
                            to="/"
                            className="w-full sm:w-auto bg-black text-white px-8 py-4 text-sm font-chivo-medium uppercase flex items-center justify-center gap-2 hover:bg-gray-900 transition-colors duration-200"
                        >
                            Continue Shopping
                            <LuArrowRight size={16} />
                        </Link>
                        <Link
                            to="/account"
                            className="w-full sm:w-auto border border-black text-black px-8 py-4 text-sm font-chivo-medium uppercase flex items-center justify-center gap-2 hover:bg-black hover:text-white transition-all duration-200"
                        >
                            View Orders
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OrderSuccess;
