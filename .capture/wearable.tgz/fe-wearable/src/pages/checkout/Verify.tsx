import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { verifyPayment } from "../../services/payment.service";
import useCartStore from "../../stores/cartStore";
import { useToastStore } from "../../stores/toastStore";
import { LuLoader, LuCircleCheck, LuCircle } from "react-icons/lu";

const Verify = () => {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const reference = searchParams.get("reference");
    const { clearCart } = useCartStore();
    const { showToast } = useToastStore();
    const [status, setStatus] = useState<"loading" | "success" | "error">("loading");

    useEffect(() => {
        const verify = async () => {
            if (!reference) {
                setStatus("error");
                showToast("No payment reference found.", "error", "top");
                return;
            }

            try {
                const result = await verifyPayment(reference);

                if (result.success) {
                    setStatus("success");
                    clearCart();
                    showToast("Payment successful!", "success", "top");

                    setTimeout(() => {
                        navigate("/order-success", {
                            state: {
                                paymentVerified: true,
                            },
                        });
                    }, 2000);
                } else {
                    setStatus("error");
                    showToast(result.message || "Payment verification failed", "error", "top");
                }
            } catch (err) {
                setStatus("error");
                showToast("Error during verification", "error", "top");
            }
        };

        verify();
    }, [reference, navigate, clearCart, showToast]);

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] py-16 px-4 text-center">
            {status === "loading" && (
                <>
                    <LuLoader className="w-16 h-16 animate-spin text-black mb-6" />
                    <h2 className="text-2xl font-chivo-medium mb-2 uppercase">Verifying Payment</h2>
                    <p className="text-[#6C6C6C] font-chivo-regular">Please wait while we confirm your payment with Paystack...</p>
                </>
            )}

            {status === "success" && (
                <>
                    <LuCircleCheck className="w-16 h-16 text-green-500 mb-6" />
                    <h2 className="text-2xl font-chivo-medium mb-2 uppercase">Payment Confirmed</h2>
                    <p className="text-[#6C6C6C] font-chivo-regular">Redirecting you to the order success page...</p>
                </>
            )}

            {status === "error" && (
                <>
                    <LuCircle className="w-16 h-16 text-red-500 mb-6" />
                    <h2 className="text-2xl font-chivo-medium mb-2 uppercase">Payment Failed</h2>
                    <p className="text-[#6C6C6C] font-chivo-regular mb-8">We could not verify your payment. Please try again or contact support.</p>
                    <button
                        onClick={() => navigate("/checkout")}
                        className="bg-black text-white px-8 py-3 uppercase font-chivo-medium text-sm hover:bg-black/90 transition-colors"
                    >
                        Return to Checkout
                    </button>
                </>
            )}
        </div>
    );
};

export default Verify;
