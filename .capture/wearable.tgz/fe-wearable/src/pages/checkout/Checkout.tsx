import { Formik, Form } from "formik";
import * as Yup from "yup";
import { Field, Quantity, Submit, SEO } from "../../components";
import { formatPrice } from "../../utils/formatter";
import { FaRegTrashAlt } from "react-icons/fa";
import useCartStore, { type CartItem } from "../../stores/cartStore";
import { LuArrowUpRight, LuShieldCheck, LuPackageCheck } from "react-icons/lu";

import { useToastStore } from "../../stores/toastStore";
import { useUserStore } from "../../stores/userStore";
import { createOrder } from "../../services/order.service";
import { useState, useEffect } from "react";
import naija from "naija-state-local-government";
import api from "../../services/api";

const validationSchema = Yup.object({
    email: Yup.string().email("Enter a valid email address").required("Email is required"),
    fullName: Yup.string().min(2, "Name must be at least 2 characters").required("Full name is required"),
    phone: Yup.string().min(7, "Enter a valid phone number").required("Phone number is required"),
    address: Yup.string().min(5, "Enter a complete street address").required("Address is required"),
    state: Yup.string().required("State is required"),
    lga: Yup.string().required("Local Government Area is required"),
});

/**
 * Checkout Page Component
 * Handles delivery details, Paystack payment, and order creation
 */
const Checkout = () => {
    const { items: cartItems, total } = useCartStore();
    const { showToast } = useToastStore();
    const { user } = useUserStore();
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Shipping Fee State
    const [shippingFee, setShippingFee] = useState<number | null>(null);
    const [isCalculatingShipping, setIsCalculatingShipping] = useState(false);
    const [shippingError, setShippingError] = useState<string | null>(null);

    const [selectedState, setSelectedState] = useState("");
    const [selectedLga, setSelectedLga] = useState("");
    const [availableLgas, setAvailableLgas] = useState<string[]>([]);

    useEffect(() => {
        if (selectedState) {
            try {
                const stateData = naija.lgas(selectedState);
                setAvailableLgas(stateData ? stateData.lgas : []);
            } catch (error) {
                setAvailableLgas([]);
            }
        } else {
            setAvailableLgas([]);
        }
    }, [selectedState]);

    useEffect(() => {
        const calculateShipping = async () => {
            if (!selectedState || !selectedLga) {
                setShippingFee(null);
                setShippingError(null);
                return;
            }

            setIsCalculatingShipping(true);
            setShippingError(null);

            try {
                const response = await api.get(`/shipping-fees/calculate?state=${selectedState}&lga=${selectedLga}`);
                if (response.data.status === 'success') {
                    setShippingFee(response.data.data.fee);
                }
            } catch (error: any) {
                setShippingFee(null);
                setShippingError(error?.response?.data?.message || "Shipping not available for this location.");
            } finally {
                setIsCalculatingShipping(false);
            }
        };

        calculateShipping();
    }, [selectedState, selectedLga]);

    const handleSubmit = async (values: any) => {
        if (cartItems.length === 0) {
            showToast("Your cart is empty", "warning", "top");
            return;
        }

        if (shippingFee === null) {
            showToast("Please select a valid delivery location with available shipping.", "warning", "top");
            return;
        }

        setIsSubmitting(true);

        try {
            // 1. Create order
            const payload = {
                customerName: values.fullName,
                customerEmail: values.email,
                customerPhone: values.phone,
                deliveryAddress: {
                    street: values.address,
                    state: values.state,
                    lga: values.lga
                },
                paymentMethod: "paystack",
                items: cartItems.map((item) => ({
                    productId: item.productId,
                    quantity: item.quantity,
                    price: item.price,
                    colors: item.color ? [item.color] : [],
                    sizes: item.size ? [item.size] : [],
                }))
            };

            const result = await createOrder(payload);

            if (!result.success) {
                showToast(result.message || "Failed to place order. Please try again.", "error", "top");
                setIsSubmitting(false);
                return;
            }

            const orders = Array.isArray(result.order) ? result.order : [result.order];
            const orderIds = orders.map((o: any) => o._id);

            // 2. Initialize payment
            const { initializePayment } = await import("../../services/payment.service");
            const finalTotal = total + (shippingFee || 0);

            const paymentResult = await initializePayment({
                orderIds,
                email: values.email,
                amount: finalTotal * 100, // Paystack requires kobo
                // @ts-ignore
                metadata: {
                    callback_url: `${window.location.origin}/checkout/verify`
                }
            });

            if (paymentResult.success && paymentResult.authorization_url) {
                // Redirect to Paystack
                window.location.href = paymentResult.authorization_url;
            } else {
                showToast(paymentResult.message || "Failed to initialize payment.", "error", "top");
                setIsSubmitting(false);
            }

        } catch (err) {
            showToast("Failed to place order. Please contact support.", "error", "top");
            setIsSubmitting(false);
        }
    };

    const finalTotal = total + (shippingFee || 0);
    const isPlaceOrderDisabled = isSubmitting || isCalculatingShipping || shippingFee === null || !!shippingError;

    return (
        <div className="checkout">
            <SEO title="Checkout" />
            <div className="container mx-auto px-4 py-8 lg:py-16">
                <div className="flex gap-10 lg:gap-16 flex-col-reverse lg:flex-row">

                    {/* Left: Delivery Form */}
                    <div className="w-full lg:w-1/2 border-t pt-6 lg:pt-0 lg:border-t-0 lg:border-r lg:pr-16 border-[#E4E4E4]">
                        <div className="checkout-form w-full lg:w-[85%] mx-auto">
                            <h2 className="text-base lg:text-xl font-chivo-medium uppercase leading-[100%] text-black mb-6 border-b border-[#E4E4E4] pb-4">
                                Delivery Details
                            </h2>

                            <Formik
                                initialValues={{
                                    fullName: user?.name || "",
                                    email: user?.email || "",
                                    phone: "",
                                    address: "",
                                    state: "",
                                    lga: "",
                                }}
                                validationSchema={validationSchema}
                                onSubmit={handleSubmit}
                            >
                                {({ values, setFieldValue, touched, errors }) => {
                                    // Sync Formik state with component state for shipping calculation
                                    useEffect(() => {
                                        if (values.state !== selectedState) setSelectedState(values.state);
                                    }, [values.state]);

                                    useEffect(() => {
                                        if (values.lga !== selectedLga) setSelectedLga(values.lga);
                                    }, [values.lga]);

                                    return (
                                        <Form>
                                            <Field
                                                name="email"
                                                type="email"
                                                placeholder="example@gmail.com"
                                                label="Email Address"
                                            />
                                            <Field
                                                name="fullName"
                                                type="text"
                                                placeholder="John Doe"
                                                label="Full Name"
                                            />
                                            <Field
                                                name="phone"
                                                type="text"
                                                placeholder="+234 806 123 4567"
                                                label="Phone Number"
                                            />

                                            <div className="mb-4">
                                                <label className="block text-[12px] font-chivo-medium uppercase text-black mb-2" style={{ letterSpacing: "-2%" }}>
                                                    State
                                                </label>
                                                <select
                                                    name="state"
                                                    value={values.state}
                                                    onChange={(e) => {
                                                        setFieldValue("state", e.target.value);
                                                        setFieldValue("lga", "");
                                                    }}
                                                    className={`w-full py-4 border-b bg-transparent text-sm font-chivo-regular focus:outline-none focus:border-black transition-colors uppercase ${touched.state && errors.state ? 'border-red-500' : ''}`}
                                                >
                                                    <option value="">Select State</option>
                                                    {naija.states().map((state: string) => (
                                                        <option key={state} value={state}>{state}</option>
                                                    ))}
                                                </select>
                                                {touched.state && errors.state && (
                                                    <div className="text-red-500 text-xs mt-1 font-chivo-regular">{errors.state}</div>
                                                )}
                                            </div>

                                            <div className="mb-4">
                                                <label className="block text-[12px] font-chivo-medium uppercase text-black mb-2" style={{ letterSpacing: "-2%" }}>
                                                    Local Government Area
                                                </label>
                                                <select
                                                    name="lga"
                                                    value={values.lga}
                                                    onChange={(e) => setFieldValue("lga", e.target.value)}
                                                    disabled={!values.state || availableLgas.length === 0}
                                                    className={`w-full py-4 border-b bg-transparent text-sm font-chivo-regular focus:outline-none focus:border-black transition-colors uppercase ${touched.lga && errors.lga ? 'border-red-500' : ''} ${(!values.state || availableLgas.length === 0) ? 'opacity-50 cursor-not-allowed' : ''}`}
                                                >
                                                    <option value="">Select LGA</option>
                                                    {availableLgas.map((lga: string) => (
                                                        <option key={lga} value={lga}>{lga}</option>
                                                    ))}
                                                </select>
                                                {touched.lga && errors.lga && (
                                                    <div className="text-red-500 text-xs mt-1 font-chivo-regular">{errors.lga}</div>
                                                )}
                                            </div>

                                            <Field
                                                name="address"
                                                type="text"
                                                placeholder="123 Main St"
                                                label="Street Address"
                                            />

                                            <div className="mb-5 pt-5">
                                                <div className="flex items-center gap-2 mb-2">
                                                    <LuShieldCheck size={14} className="text-[#6C6C6C]" />
                                                    <h4 className="text-[12px] leading-[16px] font-[500] font-chivo-medium uppercase" style={{ letterSpacing: "-2%" }}>
                                                        Secure Payment
                                                    </h4>
                                                </div>
                                                <p className="text-sm text-[#6C6C6C] font-chivo-regular font-[300] mb-4" style={{ letterSpacing: "-2%" }}>
                                                    All transactions are secure and encrypted.
                                                </p>
                                            </div>

                                            <div>
                                                <h4 className="text-[12px] leading-[16px] font-[500] mb-4 block font-chivo-medium uppercase" style={{ letterSpacing: "-2%" }}>
                                                    Place Order
                                                </h4>
                                                <Submit
                                                    title={isSubmitting ? "Placing Order..." : `Pay ₦${formatPrice(finalTotal)} NGN`}
                                                    loading={isSubmitting}
                                                    disabled={isPlaceOrderDisabled}
                                                    className="bg-black text-white w-full disabled:opacity-50 disabled:cursor-not-allowed"
                                                    icon={<LuArrowUpRight size={18} />}
                                                />
                                            </div>
                                        </Form>
                                    );
                                }}
                            </Formik>
                        </div>
                    </div>

                    {/* Right: Cart Summary */}
                    <div className="w-full lg:w-1/2 lg:bg-black items-stretch">
                        <div className="checkout-summary lg:p-6 h-full">
                            {cartItems.length === 0 ? (
                                <div className="flex flex-col items-center justify-center py-12 text-center">
                                    <LuPackageCheck size={40} className="text-white/30 mb-4" />
                                    <p className="text-sm font-chivo-regular text-white/60">Your cart is empty</p>
                                </div>
                            ) : (
                                <div className="flex flex-col h-full">
                                    <div className="grow mb-6">
                                        {cartItems.map((item) => (
                                            <CartItemCard key={item.id} item={item} />
                                        ))}
                                    </div>

                                    <div className="flex flex-col gap-3 border-t border-white/10 pt-4">
                                        <div className="flex items-center justify-between">
                                            <span className="text-sm font-chivo-regular uppercase text-[#6C6C6C]">Subtotal:</span>
                                            <span className="text-base font-chivo-medium uppercase text-black lg:text-white">{formatPrice(total)} NGN</span>
                                        </div>

                                        <div className="flex items-center justify-between">
                                            <span className="text-sm font-chivo-regular uppercase text-[#6C6C6C]">Shipping:</span>
                                            {isCalculatingShipping ? (
                                                <span className="text-sm font-chivo-regular text-black lg:text-white/70 animate-pulse">Calculating...</span>
                                            ) : shippingError ? (
                                                <span className="text-sm font-chivo-regular text-red-500">{shippingError}</span>
                                            ) : shippingFee !== null ? (
                                                <span className="text-base font-chivo-medium uppercase text-black lg:text-white">{formatPrice(shippingFee)} NGN</span>
                                            ) : (
                                                <span className="text-sm font-chivo-regular text-black lg:text-white/70">Select Location</span>
                                            )}
                                        </div>

                                        <div className="flex items-center justify-between border-t border-white/10 pt-3">
                                            <span className="text-sm font-chivo-medium uppercase text-[#6C6C6C]">Total:</span>
                                            <span className="text-base font-chivo-medium uppercase text-black lg:text-white">{formatPrice(finalTotal)} NGN</span>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div >
    );
};

const CartItemCard = ({ item }: { item: CartItem }) => {
    const { updateQuantity, removeItem } = useCartStore();
    return (
        <div className="cart-item border-b border-[#E4E4E44D] pb-4 mb-4">
            <div className="flex gap-4">
                <div className="cart-image w-[56px] h-[50px] lg:w-[90px] lg:h-[79px] bg-[#F2F2F2] flex-shrink-0 overflow-hidden">
                    <img
                        src={item.image || "/images/products/placeholder.png"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                    />
                </div>
                <div className="cart-content grow">
                    <div className="flex items-start gap-6 justify-between text-black lg:text-white">
                        <div className="text-sm leading-[20px] font-chivo-medium font-medium">{item.name}</div>
                        <div className="text-sm leading-sm font-chivo-regular font-[300] whitespace-nowrap">{formatPrice(item.price)} NGN</div>
                    </div>
                    <div className="my-2">
                        {item.color && <div className="text-xs font-chivo-regular font-[300] text-[#6C6C6C] mb-1">Color: {item.color}</div>}
                        {item.size && <div className="text-xs font-chivo-regular font-[300] text-[#6C6C6C]">Size: {item.size}</div>}
                    </div>
                    <div className="flex items-center justify-between w-full mt-2">
                        <Quantity
                            quantity={item.quantity}
                            increment={() => updateQuantity(item.id, item.quantity + 1)}
                            decrement={() => updateQuantity(item.id, item.quantity - 1)}
                        />
                        <button onClick={() => removeItem(item.id)} className="p-1 hover:scale-110 transition-transform duration-200">
                            <FaRegTrashAlt size={14} className="text-red-500" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Checkout;