import { useState, useEffect, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { ProductCard } from "../../components/cards";
import { Skeleton, SEO } from "../../components/main";
import { searchProducts } from "../../services/product.service";
import { LuSearch, LuX, LuPackageSearch } from "react-icons/lu";

type Product = {
    id: string;
    name: string;
    images: string[];
    price: number;
    discountPrice?: number;
    category: string;
    subCategory?: string;
};

const CATEGORIES = ["all", "male", "female", "accessories", "footwear"];

const Search = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const initialQuery = searchParams.get("q") || "";

    const [query, setQuery] = useState(initialQuery);
    const [debouncedQuery, setDebouncedQuery] = useState(initialQuery);
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(false);
    const [totalResults, setTotalResults] = useState(0);
    const [selectedCategory, setSelectedCategory] = useState("all");

    // Debounce the search query
    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedQuery(query);
            setPage(1);
            setProducts([]);
        }, 350);
        return () => clearTimeout(timer);
    }, [query]);

    // Sync query to URL params
    useEffect(() => {
        if (debouncedQuery) {
            setSearchParams({ q: debouncedQuery }, { replace: true });
        } else {
            setSearchParams({}, { replace: true });
        }
    }, [debouncedQuery, setSearchParams]);

    const doSearch = useCallback(async () => {
        if (!debouncedQuery.trim()) {
            setProducts([]);
            setTotalResults(0);
            return;
        }
        setLoading(true);
        setError(null);
        try {
            const result = await searchProducts(debouncedQuery, page, 12);
            if (result.success && result.products) {
                const incoming = result.products as Product[];
                if (selectedCategory !== "all") {
                    const filtered = incoming.filter(p => p.category === selectedCategory);
                    setProducts(prev => page === 1 ? filtered : [...prev, ...filtered]);
                } else {
                    setProducts(prev => page === 1 ? incoming : [...prev, ...incoming]);
                }
                setTotalResults(result.pagination?.total || 0);
                setHasMore(result.pagination ? page < result.pagination.pages : false);
            } else {
                setError(result.success === false ? "Search failed. Please try again." : null);
            }
        } catch (e) {
            setError("Unable to connect. Please check your connection.");
        } finally {
            setLoading(false);
        }
    }, [debouncedQuery, page, selectedCategory]);

    useEffect(() => {
        doSearch();
    }, [doSearch]);

    // Reset when category changes
    useEffect(() => {
        setPage(1);
        setProducts([]);
    }, [selectedCategory]);

    return (
        <div className="search-page">
            <SEO title={debouncedQuery ? `Search results for "${debouncedQuery}"` : "Search"} />
            <div className="container mx-auto px-4 py-10 lg:py-16 mb-10 lg:mb-28">

                {/* Search Header */}
                <div className="mb-8 lg:mb-12">
                    <h1 className="text-[28px] lg:text-[52px] font-chivo-medium uppercase leading-[100%] text-black mb-6" style={{ letterSpacing: "-2%" }}>
                        Search
                    </h1>

                    {/* Search Input */}
                    <div className="relative w-full max-w-2xl group">
                        <LuSearch
                            size={20}
                            className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6C6C6C] transition-colors duration-200 group-focus-within:text-black"
                        />
                        <input
                            id="search-input"
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Search for products, categories..."
                            autoFocus
                            className="w-full border border-[#E4E4E4] bg-[#F2F2F2] pl-12 pr-12 py-4 text-sm font-chivo-regular text-black placeholder-[#6C6C6C] focus:outline-none focus:border-black transition-all duration-200"
                        />
                        {query && (
                            <button
                                onClick={() => { setQuery(""); setProducts([]); }}
                                className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6C6C6C] hover:text-black transition-colors duration-200"
                            >
                                <LuX size={18} />
                            </button>
                        )}
                    </div>

                    {/* Category Filters */}
                    <div className="flex items-center gap-3 mt-4 flex-wrap">
                        {CATEGORIES.map((cat) => (
                            <button
                                key={cat}
                                onClick={() => setSelectedCategory(cat)}
                                className={`px-5 py-2 text-sm font-chivo-regular uppercase transition-all duration-200 ${
                                    selectedCategory === cat
                                        ? "bg-black text-white"
                                        : "bg-[#F2F2F2] text-black hover:bg-black/10"
                                }`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Results Count */}
                {debouncedQuery && !loading && (
                    <p className="text-sm font-chivo-regular text-[#6C6C6C] mb-6 uppercase">
                        {totalResults > 0
                            ? `${totalResults} result${totalResults !== 1 ? "s" : ""} for "${debouncedQuery}"`
                            : products.length === 0 ? `No results for "${debouncedQuery}"` : ""
                        }
                    </p>
                )}

                {/* Skeleton Loading */}
                {loading && page === 1 && (
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
                        {Array.from({ length: 8 }).map((_, i) => (
                            <div key={i}>
                                <Skeleton className="w-full h-[225px] md:h-[325px] lg:h-[365px] mb-4" />
                                <Skeleton className="w-1/2 h-3 mb-2" />
                                <Skeleton className="w-full h-4 mb-2" />
                                <Skeleton className="w-1/3 h-3" />
                            </div>
                        ))}
                    </div>
                )}

                {/* Error State */}
                {error && (
                    <div className="flex flex-col items-center justify-center py-16">
                        <p className="text-sm font-chivo-regular text-red-600">{error}</p>
                    </div>
                )}

                {/* Empty State - no query */}
                {!debouncedQuery && !loading && (
                    <div className="flex flex-col items-center justify-center py-24 text-center">
                        <LuSearch size={56} className="text-[#E4E4E4] mb-6" />
                        <h2 className="text-xl font-chivo-medium uppercase text-black mb-2" style={{ letterSpacing: "-2%" }}>
                            Start Searching
                        </h2>
                        <p className="text-sm font-chivo-regular text-[#6C6C6C] max-w-xs">
                            Type a product name, category, or style to find what you're looking for.
                        </p>
                    </div>
                )}

                {/* Empty State - no results */}
                {debouncedQuery && !loading && products.length === 0 && !error && (
                    <div className="flex flex-col items-center justify-center py-24 text-center">
                        <LuPackageSearch size={56} className="text-[#E4E4E4] mb-6" />
                        <h2 className="text-xl font-chivo-medium uppercase text-black mb-2" style={{ letterSpacing: "-2%" }}>
                            No Results Found
                        </h2>
                        <p className="text-sm font-chivo-regular text-[#6C6C6C] max-w-xs">
                            We couldn't find anything for "{debouncedQuery}". Try different keywords or browse our categories.
                        </p>
                    </div>
                )}

                {/* Product Grid */}
                {products.length > 0 && (
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
                        {products.map((product, index) => (
                            <div
                                key={product.id}
                                style={{ animation: `fadeInUp 0.5s ease-out ${(index % 8) * 60}ms both` }}
                            >
                                <ProductCard
                                    id={product.id}
                                    image={product.images?.[0] || "/images/products/placeholder.png"}
                                    title={product.name}
                                    category={product.category}
                                    price={product.discountPrice || product.price}
                                />
                            </div>
                        ))}
                    </div>
                )}

                {/* Load More */}
                {hasMore && !loading && (
                    <div className="flex justify-center mt-12">
                        <button
                            onClick={() => setPage(p => p + 1)}
                            className="bg-black text-white px-10 py-4 text-sm font-chivo-medium uppercase hover:bg-gray-900 transition-colors duration-200"
                        >
                            Load More
                        </button>
                    </div>
                )}

                {/* Loading More Indicator */}
                {loading && page > 1 && (
                    <div className="flex justify-center mt-8">
                        <p className="text-sm font-chivo-regular text-[#6C6C6C]">Loading more...</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Search;