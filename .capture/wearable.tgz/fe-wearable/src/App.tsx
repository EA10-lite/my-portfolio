import { lazy, Suspense } from 'react';
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppLayout } from './layouts';
import ProtectedCheckout from './layouts/ProtectedCheckout';
import { Skeleton } from './components/main';

// Lazy-load all page-level components
const Home = lazy(() => import('./pages/home/Home'));
const Product = lazy(() => import('./pages/products/Product'));
const Category = lazy(() => import('./pages/category/Category'));
const BestSellers = lazy(() => import('./pages/best-sellers/BestSellers'));
const NotFound = lazy(() => import('./pages/not-found/NotFound'));
const Search = lazy(() => import('./pages/search/Search'));
const Checkout = lazy(() => import('./pages/checkout/Checkout'));
const OrderSuccess = lazy(() => import('./pages/checkout/OrderSuccess'));
const Account = lazy(() => import('./pages/account/Account'));

const Verify = lazy(() => import('./pages/checkout/Verify'));

const PageLoader = () => (
  <div className="container mx-auto px-4 py-16">
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i}>
          <Skeleton className="w-full h-[365px] mb-4" />
          <Skeleton className="w-1/2 h-3 mb-2" />
          <Skeleton className="w-full h-4 mb-2" />
          <Skeleton className="w-1/3 h-3" />
        </div>
      ))}
    </div>
  </div>
);

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<AppLayout />}>
            <Route index element={<Home />} />
            <Route path="search" element={<Search />} />
            <Route path="best-sellers" element={<BestSellers />} />
            <Route path="account" element={<Account />} />
            <Route path="order-success" element={<OrderSuccess />} />
            <Route path="checkout/verify" element={<Verify />} />
            <Route
              path="checkout"
              element={
                <ProtectedCheckout>
                  <Checkout />
                </ProtectedCheckout>
              }
            />
            <Route path="category/:category/:subcategory" element={<Category />} />
            <Route path="category/:category/product/:id" element={<Product />} />
            <Route path="category/:category" element={<Category />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
