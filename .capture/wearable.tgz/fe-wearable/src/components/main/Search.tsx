import { MdClose } from "react-icons/md";

import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTrigger,
} from "../ui/sheet"
import { Button } from "../reusable";
import { FiSearch } from "react-icons/fi";
import { useState, useEffect } from "react";
import { formatPrice } from "../../utils/formatter";
import { useGet } from "../../hooks/useGet";
import { Link } from "react-router-dom";

type SearchResult = {
    id: string;
    name: string;
    images: string[];
    price: number;
    category: string;
    subCategory?: string;
}

const Search = () => {
    const [search, setSearch] = useState<string>("");
    const [filteredItems, setFilteredItems] = useState<string[]>([]);
    const [debouncedSearch, setDebouncedSearch] = useState<string>("");

    /**
     * Debounce search input - waits 500ms after user stops typing
     */
    useEffect(() => {
        const timeoutId = setTimeout(() => {
            setDebouncedSearch(search.trim());
        }, 500); // 500ms debounce

        return () => clearTimeout(timeoutId);
    }, [search]);

    /**
     * Fetch search results using TanStack Query
     * Only runs when debouncedSearch has a value
     */
    const { data: searchResponse, isLoading: isSearching, error: queryError } = useGet<{
        success: boolean;
        message: string;
        products?: SearchResult[];
    }>(
        ['products', 'search', debouncedSearch],
        debouncedSearch ? `/products/user/search/${encodeURIComponent(debouncedSearch)}?limit=8` : '',
        {
            enabled: !!debouncedSearch,
            staleTime: 1000 * 60 * 2, // 2 minutes for search results
        }
    );

    // Extract search results from response
    const searchResults = searchResponse?.products || [];
    const searchError = queryError ? "Failed to search products" : (searchResponse && !searchResponse.success ? searchResponse.message : null);
    return (
        <Sheet>
            <SheetTrigger asChild className="p-0 m-0">
                <button className="cursor-pointer">
                    <div className="flex items-center gap-1">
                        <FiSearch />
                        <div className="text-black hidden lg:inline-flex font-chivo-regular font-normal  text-sm leading-[100%]">search</div>
                    </div>
                </button>
            </SheetTrigger>
            <SheetContent className="z-[999] w-[95%] md:min-w-[538px] p-0">
                <SheetHeader className="p-0">
                    <div className="flex items-center justify-between p-4 border-b border-[#E4E4E4] flex items-center justify-between sticky top-0 z-50">
                        <input
                            type="text"
                            placeholder="Search for anything"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="w-full flex-1 text-sm leading-[100%] font-chivo-regular font-normal"
                        />

                        <SheetClose>
                            <button
                                className="w-8 h-8 bg-black flex items-center justify-center"
                                onClick={() => {}}
                            >
                                <MdClose className="text-white" />
                            </button>
                        </SheetClose>
                    </div>
                </SheetHeader>

                <div className="overflow-y-auto">
                    <div className="p-6 border-b borde-[#E4E4E4]">
                        <div className="quick-search">
                            <h4 className="text-sm leading-[100%] font-chivo-regular font-normal  text-[#6C6C6C] mb-4">Quick Search</h4>
                        </div>
                        <div className="flex items-center gap-4 flex-wrap">
                            {["T-shirts", "Shirts", "Jeans", "Trousers", "Shoes", "Accessories"].map((item, index) => (
                                <div
                                    key={index}
                                    className={`px-6 py-2.5 cursor-pointer ${filteredItems.includes(item) ? "bg-black text-white" : "bg-[#0000000A] text-black"}`}
                                    onClick={() => {
                                        setSearch(item);
                                        setFilteredItems([...filteredItems, item]);
                                    }}
                                >
                                    <p className="text-sm leading-[100%] font-chivo-regular font-normal">{item}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="search-results px-6 py-4">
                        {isSearching ? (
                            <div className="text-center py-8 text-sm text-[#6C6C6C]">
                                Searching...
                            </div>
                        ) : searchError ? (
                            <div className="text-center py-8 text-sm text-[#6C6C6C]">
                                {searchError}
                            </div>
                        ) : searchResults.length > 0 ? (
                            searchResults.map((result) => (
                                <SearchResult key={result.id} {...result} />
                            ))
                        ) : search.trim() ? (
                            <div className="text-center py-8 text-sm text-[#6C6C6C]">
                                No products found
                            </div>
                        ) : (
                            <div className="text-center py-8 text-sm text-[#6C6C6C]">
                                Start typing to search for products
                            </div>
                        )}
                    </div>
                </div>


                {search.trim() && searchResults.length > 0 && (
                    <SheetFooter className="p-6">
                        <Link to={`/search?q=${encodeURIComponent(search.trim())}`} className="w-full">
                            <Button
                                title="View All Results"
                                className="w-full"
                                onClick={() => {}}
                            />
                        </Link>
                    </SheetFooter>
                )}
            </SheetContent>
        </Sheet>
    )
}

const SearchResult = ({
    id,
    name,
    images,
    price,
    category,
    subCategory
}: SearchResult) => {
    const productImage = images && images.length > 0 ? images[0] : "/images/products/placeholder.png";
    const displayCategory = subCategory || category;

    return (
        <Link to={`/product/${category}/${id}`}>
            <div className="search-result flex items-center gap-4 pb-4 mb-4 border-b border-[#E4E4E4] cursor-pointer hover:bg-gray-50 transition-colors">
                <div className="search-result-image w-16 h-16 bg-[#F2F2F2] flex-shrink-0">
                    <img
                        src={productImage}
                        alt={name}
                        className="w-full h-full object-contain"
                    />
                </div>
                <div className="search-result-content flex-1">
                    <div className="flex justify-between mb-1">
                        <h3 className="text-sm font-chivo-regular uppercase leading-[100%]">{name}</h3>
                        <p className="text-sm font-chivo-regular uppercase leading-[100%] text-[#6C6C6C]">{formatPrice(price.toString())} NGN</p>
                    </div>
                    <p className="text-sm font-chivo-regular uppercase leading-[100%] text-[#6C6C6C]">{displayCategory}</p>
                </div>
            </div>
        </Link>
    )
}

export default Search;