import { MdClose } from "react-icons/md";

import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTrigger,
} from "../ui/sheet"
import { LuInfo, LuShoppingBag } from "react-icons/lu";
import { Button, Quantity } from "../reusable";
import { formatPrice } from "../../utils/formatter";
import useCartStore, { type CartItem } from "../../stores/cartStore";
import { FaRegTrashAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";

const Cart = () => {
  const { items: cartItems, total } = useCartStore();
  const navigate = useNavigate();
  return (
    <Sheet>
      <SheetTrigger asChild className="p-0 m-0">
        <button className="">
          <div className="flex items-center gap-1">
            <LuShoppingBag />
            <div className="cursor-pointer hidden lg:flex items-center gap-1">
              <div className="text-black font-chivo-regular font-normal  text-sm leading-[100%]">cart</div>
              <div className="text-black font-chivo-regular font-normal  text-sm leading-[100%]">({cartItems?.length})</div>
            </div>
          </div>
        </button>
      </SheetTrigger>
      <SheetContent className="z-[999] w-[95%] md:min-w-[538px] p-0">
        <SheetHeader className="p-0">
          <div className="flex items-center justify-between p-4 bg-black flex items-center justify-between sticky top-0 z-50">
            <h4 className="text-sm font-chivo-regular font-normal  text-white">Cart ({cartItems?.length})</h4>

            <SheetClose>
              <button
                className="w-8 h-8 bg-[#f2f2f2] flex items-center justify-center"
                onClick={() => { }}
              >
                <MdClose />
              </button>
            </SheetClose>
          </div>
        </SheetHeader>


        <div className="overflow-auto">
          <div className="p-6">
            {cartItems?.length <= 0 ? (
              <div className="empty-cart flex flex-col items-center justify-center py-10">
                <div className="bg-[#F7F7F7] w-14 lg:w-18 h-14 lg:h-18 flex items-center justify-center mx-auto">
                  <LuShoppingBag className="w-6 lg:w-10 h-6 lg:h-10" />
                </div>

                <div className="my-6 text-center">
                  <h4 className="text-sm lg:text-xl font-chivo-regular font-normal  text-black mb-2">Your cart is empty</h4>
                  <p className="text-sm lg:text-base font-chivo-regular font-normal  text-[#6C6C6C]">Looks like you haven&apos;t added anything yet</p>
                </div>

                <Button
                  title="Start Shopping"
                  className="w-fit lg:w-full"
                  onClick={() => { }}
                />
              </div>
            ) : (
              <div className="cart-items">
                {cartItems?.map((item, index) => (
                  <CartItem
                    key={index}
                    item={item}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <SheetFooter className="p-6">
          {cartItems.length <= 0 && (
            <div
              className="flex items-start justify-between p-4 border border-dashed border-[#6C6C6C] gap-1"
              style={{
                borderSpacing: 5,
              }}
            >
              <div className="min-w-6">
                <LuInfo className="text-[#6C6C6C]" size={20} />
              </div>
              <p
                className="text-sm font-chivo-regular font-[300]  text-[#6C6C6C]"
                style={{
                  letterSpacing: "-2%"
                }}
              >Not sure where to start? Check out the Top Sellers — they’re trending for a reason.</p>
            </div>
          )}

          {cartItems.length > 0 && (
            <div className="proceed-to-checkout">
              <div className="flex items-center justify-between gap-2 my-3">
                <div className="text-sm font-chivo-regular font-[300] text-[#6C6C6C]">ESTIMATED COST + VAT</div>
                <div className="text-sm font-chivo-regular font-normal text-black">{formatPrice(total)} NGN</div>
              </div>
              <Button
                title="Proceed to Checkout"
                className="w-full"
                onClick={() => navigate("/checkout")}
              />
              <div className="mt-3">
                <SheetClose className="w-full">
                  <p
                    className="text-sm font-chivo-regular font-[300] underline text-center cursor-pointer"
                    onClick={() => { }}
                  >
                    Continue shopping
                  </p>
                </SheetClose>
              </div>
            </div>
          )}
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}

const CartItem = ({ item }: { item: CartItem }) => {
  const { updateQuantity, removeItem } = useCartStore();
  return (
    <div className="cart-item mb-4 pb-4 border-b border-[#E4E4E4]">
      <div className="flex gap-4">
        <div className="cart-image w-20 h-20 bg-[#F2F2F2] flex items-center justify-center">
          <img
            src={item?.image}
            alt={item.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="cart-content grow">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="text-sm leading-[20px] font-chivo-medium font-medium text-black">{item.name}</div>
            <div className="text-sm leading-sm font-chivo-regular font-[300] text-[#6C6C6C]">{formatPrice(item.price)} NGN</div>
          </div>
          <div className="my-4">
            {item.color && (
              <div className="text-sm leading-sm font-chivo-regular font-[300] text-[#6C6C6C] mb-3">
                Select Color: {item.color}
              </div>
            )}
            {item.size && (
              <div className="text-sm leading-sm font-chivo-regular font-[300] text-[#6C6C6C]">
                Select Size: {item.size}
              </div>
            )}
          </div>
          <div className="flex items-center justify-between w-full">
            <Quantity
              quantity={item.quantity}
              increment={() => updateQuantity(item.id, item.quantity + 1)}
              decrement={() => updateQuantity(item.id, item.quantity - 1)}
            />
            <button className="" onClick={() => removeItem(item.id)}>
              <FaRegTrashAlt size={16} className="text-red-500" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Cart;