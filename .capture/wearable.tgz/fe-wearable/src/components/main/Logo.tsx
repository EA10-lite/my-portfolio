import { Link } from "react-router-dom";

const  Logo = () => {
    return (
        <div className="logo">
            <Link to="/">
                <img src="/images/logo.svg" alt="Wearable" />
            </Link>
        </div>
    )
}

export default Logo;