import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title: string;
  description?: string;
  name?: string;
  type?: string;
}

export default function SEO({ title, description, name, type }: SEOProps) {
  const defaultDescription = "Discover the best of men's and women's fashion, from everyday essentials to statement accessories. Shop trendy clothing, footwear, and accessories all in one stylish marketplace.";
  const defaultName = "Wearable";
  
  return (
    <Helmet>
      {/* Standard metadata tags */}
      <title>{title} | Wearable</title>
      <meta name='description' content={description || defaultDescription} />
      
      {/* OpenGraph tags */}
      <meta property="og:type" content={type || "website"} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description || defaultDescription} />
      
      {/* Twitter tags */}
      <meta name="twitter:creator" content={name || defaultName} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description || defaultDescription} />
    </Helmet>
  );
}
