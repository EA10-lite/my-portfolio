import { useFormikContext, type FormikValues } from "formik";
import { LuLoader } from "react-icons/lu";
import { mergeClasses } from "../../lib/mergeclasses";

type SubmitProps = {
    title: string;
    className?: string;
    disabled?: boolean;
    loading?: boolean;
    icon?: React.ReactNode;
}

const Submit = ({ title, className, disabled, loading, icon }: SubmitProps) => {
    const { handleSubmit } = useFormikContext<FormikValues>();

    return (
        <button
            className={mergeClasses(`bg-white text-black px-8 py-4 text-sm lg:text-base font-chivo font-medium leading-[100%] uppercase w-fit flex items-center gap-2 justify-center`, className)}
            disabled={disabled}
            onClick={() => handleSubmit()}
        >
            {loading ? <LuLoader className="w-4 h-4 animate-spin" /> : <span>{title}</span>}
            {!loading && icon && icon}
        </button>
    )
}

export default Submit;