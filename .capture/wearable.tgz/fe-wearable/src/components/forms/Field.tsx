import React from "react";
import { type FormikValues, useFormikContext } from "formik";

import Input from "./Input";
import Error from "./Error";

interface FieldProps {
    name:               string;
    type?:              string;
    label:              string;
    disabled?:          boolean,
    placeholder?:       string;
    isStringArr?:       boolean;
    parentName?:        string;
    index?:             number;
    className?:         string;
    customHandleChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const Field: React.FC<FieldProps> = ({
    name,
    parentName,
    isStringArr,
    index,
    type = "text",
    label,
    placeholder,
    customHandleChange,
    disabled=false,
    className,
    ...otherProps
}) => {
    const { errors, touched, handleChange, values } = useFormikContext<FormikValues>();
    
    return (
        <div className="form-field mb-5">
            <label
                className={`label text-[12px] leading-[16px] font-[500] mb-[4px] block`} 
                id={name}
            >
                { label }
            </label>
            <Input
                name={name}
                type={type}
                placeholder={placeholder || ""}
                handleChange={customHandleChange ? customHandleChange : handleChange}
                disabled={disabled}
                value={(isStringArr && parentName) ? values[parentName][index || 0] : values[name] || ""}
                className={className}
                {...otherProps}
            />

            <Error 
                error={errors?.[name] as string | undefined}
                visible={!!touched?.[name]}
            />

        </div>
    )
}

export default Field;