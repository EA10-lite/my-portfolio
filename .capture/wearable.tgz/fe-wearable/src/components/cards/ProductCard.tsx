import { Link } from "react-router-dom";
import { formatPrice } from "../../utils/formatter";
import { AiOutlinePlus } from "react-icons/ai";
import useCartStore from "../../stores/cartStore";
import { useToastStore } from "../../stores/toastStore";

type ProductCardProps = {
    id: string;
    image: string;
    title: string;
    category: string;
    price: number | string;
    isNew?: boolean;
}

const ProductCard = ({
    image,
    title,
    category,
    price,
    isNew,
    id,
}: ProductCardProps) => {
    const { showToast } = useToastStore();
    const { addItem } = useCartStore();

    const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        e.preventDefault();


        addItem({
            id,
            name: title,
            price: Number(price),
            image,
            quantity: 1,
            productId: id,
        });

        showToast("Item added to cart", "success");
    }
    return (
        <Link to={`/category/${category}/product/${id}`}>
            <div className="card group transition-all duration-300 ease-out hover:scale-[1.02]">
                <div className="card-image mb-4 relative h-[225px] md:h-[325px] lg:h-[365px] bg-[#F2F2F2] overflow-hidden">
                    {isNew && (
                        <div className="absolute top-4 left-4 z-10 animate-fade-in">
                            <div className="bg-white px-4 py-2">
                                <p className="font-chivo-regular font-normal uppercase text-sm leading-[100%] text-black">NEW</p>
                            </div>
                        </div>
                    )}
                    <img
                        src={image}
                        alt={title}
                        className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-110" 
                    />

                    <div className="absolute bottom-4 right-4 z-99 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-all duration-300 ease-in-out transform translate-y-2 lg:group-hover:translate-y-0">
                        <button
                            className="bg-black w-10 h-10 flex items-center justify-center transition-all duration-300 ease-in-out cursor-pointer hover:scale-110 active:scale-95 hover:bg-gray-800"
                            onClick={handleAddToCart}
                        >
                            <AiOutlinePlus size={16} className="text-white transition-transform duration-300 group-hover:rotate-90" />
                        </button>
                    </div>
                </div>

                <div className="card-content transition-all duration-300 ease-out">
                    <h3 className="text-sm font-chivo-regular uppercase leading-[100%] text-[#6C6C6C] transition-colors duration-300 group-hover:text-black">{category}</h3>
                    <h3 className="text-base font-chivo-medium uppercase leading-[100%] text-black my-2.5">{title}</h3>
                    <p className="text-sm font-chivo-regular uppercase leading-[100%] text-[#6C6C6C] transition-colors duration-300 group-hover:text-black">{formatPrice(price)} NGN</p>
                </div>
            </div>
        </Link>
    )
}

export default ProductCard;