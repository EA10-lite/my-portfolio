import { useMemo } from "react";
import { ProductCard } from "../cards";
import { useGet } from "../../hooks/useGet";
import { Skeleton } from "../main";
import { LuPackage, LuInfo } from "react-icons/lu";
import { useScrollAnimation } from "../../hooks";

/**
 * Product type from API response
 */
type Product = {
    id: string;
    name: string;
    images: string[];
    price: number;
    discountPrice?: number;
    category: string;
    subCategory?: string;
};

const NewArrivals = ({ 
    title, 
    category, 
    products: providedProducts 
}: { 
    title?: string; 
    category?: string;
    products?: Product[]; // Optional: if provided, use these products instead of fetching
}) => {
    const [sectionRef, isSectionVisible] = useScrollAnimation(0.1);

    /**
     * Build API URL with optional category filter (only used if products not provided)
     */
    const apiUrl = useMemo(() => {
        if (providedProducts !== undefined) {
            return null; // Don't fetch if products are provided
        }
        const params = new URLSearchParams();
        if (category) params.append('category', category);
        params.append('limit', '8');
        return `/products/user/new-arrivals?${params.toString()}`;
    }, [category, providedProducts]);

    /**
     * Fetch new arrival products using TanStack Query (only if products not provided)
     */
    const { data: newArrivalsResponse, isLoading: loading, error: queryError } = useGet<{
        success: boolean;
        message: string;
        products?: Product[];
    }>(
        ['products', 'new-arrivals', category || 'all'],
        apiUrl || '',
        {
            enabled: providedProducts === undefined, // Only fetch if products not provided
            staleTime: 1000 * 60 * 5, // 5 minutes
        }
    );

    // Use provided products if available, otherwise use fetched products
    const products = providedProducts || newArrivalsResponse?.products || [];
    const isLoading = providedProducts === undefined ? loading : false;
    const error = providedProducts === undefined 
        ? (queryError ? "Failed to load new arrivals. Please try again later." : (newArrivalsResponse && !newArrivalsResponse.success ? newArrivalsResponse.message : null))
        : null;

    return (
        <div ref={sectionRef as React.RefObject<HTMLDivElement>} className="new-arrivals mb-10 lg:mb-28">
            <div className="container mx-auto px-4">
                <h2
                    className={`text-[24px] lg:text-[52px] font-chivo-medium uppercase leading-[100%] text-black mb-8 lg:mb-12 transition-all duration-700 ease-out ${
                        isSectionVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                    }`}
                    style={{
                        letterSpacing: "-2%"
                    }}
                >
                    {title || "New Arrivals"}
                </h2>

                {isLoading ? (
                    <div className="flex md:grid md:grid-cols-2 lg:grid-cols-4 gap-8 overflow-x-auto snap-x snap-mandatory md:overflow-visible scrollbar-hide">
                        {Array.from({ length: 8 }).map((_, index) => (
                            <div key={index} className="flex-shrink-0 w-full min-w-full md:min-w-0 md:w-auto snap-start">
                                <Skeleton className="w-full h-[365px] mb-4" />
                                <Skeleton className="w-1/2 h-3" />
                                <Skeleton className="w-full h-4 my-2.5" />
                                <Skeleton className="w-1/3 h-3" />
                            </div>
                        ))}
                    </div>
                ) : error ? (
                    <div className="flex flex-col items-center justify-center py-16 lg:py-24">
                        <div className="mb-6 lg:mb-8">
                            <div className="w-20 h-20 lg:w-24 lg:h-24 rounded-full bg-red-50 flex items-center justify-center">
                                <LuInfo className="w-10 h-10 lg:w-12 lg:h-12 text-red-600" />
                            </div>
                        </div>
                        <h3 className="text-lg lg:text-xl font-chivo-medium uppercase text-black mb-2 lg:mb-3" style={{ letterSpacing: "-2%" }}>
                            Unable to Load Products
                        </h3>
                        <p className="text-sm lg:text-base font-chivo-regular text-red-600 max-w-md text-center px-4">
                            {error}
                        </p>
                    </div>
                ) : products.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 lg:py-24">
                        <div className="mb-6 lg:mb-8">
                            <div className="w-20 h-20 lg:w-24 lg:h-24 rounded-full bg-[#F2F2F2] flex items-center justify-center">
                                <LuPackage className="w-10 h-10 lg:w-12 lg:h-12 text-[#6C6C6C]" />
                            </div>
                        </div>
                        <h3 className="text-lg lg:text-xl font-chivo-medium uppercase text-black mb-2 lg:mb-3" style={{ letterSpacing: "-2%" }}>
                            No New Arrivals Yet
                        </h3>
                        <p className="text-sm lg:text-base font-chivo-regular text-[#6C6C6C] max-w-md text-center px-4">
                            {category 
                                ? `We're working on adding new ${category} products. Check back soon!`
                                : "We're working on adding new products. Check back soon!"
                            }
                        </p>
                    </div>
                ) : (
                    /* Mobile: Flexbox with snap scroll, Desktop: Grid layout */
                    <div className={`flex md:grid md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8 overflow-x-auto snap-x snap-mandatory md:overflow-visible scrollbar-hide transition-all duration-700 ease-out ${
                        isSectionVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                    }`} style={{ transitionDelay: "200ms" }}>
                        {products.map((product, index) => (
                            <div
                                key={product.id}
                                className="flex-shrink-0 w-1/2 md:min-w-0 md:w-auto snap-start"
                                style={{
                                    animation: isSectionVisible ? `fadeInUp 0.6s ease-out ${index * 100}ms both` : undefined
                                }}
                            >
                                <ProductCard
                                    id={product.id}
                                    image={
                                        product.images && product.images.length > 0 ?
                                        product.images[0] :
                                        "/images/products/placeholder.png"
                                    }
                                    title={product.name}
                                    category={product.category}
                                    price={product.discountPrice || product.price}
                                    isNew={true}
                                />
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    )
}

export default NewArrivals;