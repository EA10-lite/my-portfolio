export { default as BestSellers } from "./BestSellers";
export { default as NewArrivals } from "./NewArrivals";