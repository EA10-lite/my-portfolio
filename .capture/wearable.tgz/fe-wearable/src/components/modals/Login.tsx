import { Formik } from "formik";
import { Field, Submit } from "../forms";
import { useUserStore } from "../../stores/userStore";
import { useState } from "react";


const Login = () => {
    const { setOpenLoginModal } = useUserStore();

    const handleOverlayClick = () => {
        setOpenLoginModal(false);
    };
    const handleContainerClick = (e: React.MouseEvent) => {
        e.stopPropagation();
    };


    const [step, setStep] = useState<number>(0);
    const [email, setEmail] = useState<string>("");

    const submitEmail = async (values: { email: string }) => {
        setEmail(values.email);
        setStep(1);
    }

    const submitCode = async (values: { code: string }) => {
        console.log(values);
    }

    return (
        <div 
            className="fixed top-16 left-0 w-full h-full z-99"
            onClick={handleOverlayClick}
        >
            <div className="container mx-auto px-4">
                <div 
                    className="bg-black px-8 py-6 w-[365px] max-w-md ml-auto z-99 relative mt-6"
                    onClick={handleContainerClick}
                >

                    {step === 0 && (
                        <Formik
                            initialValues={{ email: "" }}
                            onSubmit={(values)=> submitEmail(values)}
                        >
                            {()=> (
                                <div className="">
                                    <h4 className="text-white text-base font-chivo font-medium leading-[100%] uppercase">LOGIN WITH EMAIL</h4>

                                    <Field 
                                        name="email"
                                        label="Email"
                                        type="email"
                                        placeholder="Enter your email"
                                    />

                                    <Submit title="Login" loading={false} />
                                </div>
                            )}
                        </Formik>
                    )}

                    {step === 1 && (
                        <Formik
                            initialValues={{ code: "" }}
                            onSubmit={(values)=> submitCode(values)}
                        >
                            {()=> (
                                <div className="">
                                    <h4 
                                        className="text-white text-base font-chivo font-medium leading-[100%] uppercase"
                                        style={{
                                            letterSpacing: "-2%"
                                        }}
                                    >Enter the code sent to {email}</h4>

                                    <Field 
                                        name="code"
                                        label="Code"
                                        type="email"
                                        placeholder="Enter the code"
                                    />

                                    <Submit title="Submit" loading={false} />

                                    <p 
                                        className="text-white text-sm font-chivo font-normal leading-[100%] uppercase underline cursor-pointer mt-4" 
                                        onClick={()=> setStep(0)}
                                    >
                                        Sign in with another email
                                    </p>
                                </div>
                            )}
                        </Formik>
                    )}
                </div>
            </div>
        </div>
    )
}


export default Login;