import { AiOutlineMinus, AiOutlinePlus } from "react-icons/ai";

type QuantityProps = {
    quantity: number;
    increment: () => void;
    decrement: () => void;
}

const Quantity = ({ quantity=1, increment, decrement }: QuantityProps) => {
    return (
        <div className="flex items-center gap-2">
            <button
                className="bg-[#f2f2f2] w-8 h-8 lg:w-10 lg:h-10 flex items-center justify-center"
                onClick={decrement}
                disabled={quantity <= 1}
            >
                <AiOutlineMinus size={16} />
            </button>

            <div className="w-8 h-8 lg:w-10 lg:h-10 flex items-center justify-center bg-black">
                <span className="text-sm font-chivo-regular uppercase leading-[100%] text-white">{quantity}</span>
            </div>

            <button className="bg-[#f2f2f2] w-8 h-8 lg:w-10 lg:h-10 flex items-center justify-center" onClick={increment}>
                <AiOutlinePlus size={16} />
            </button>
        </div>
    )
}

export default Quantity;