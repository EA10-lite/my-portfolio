import React, { useEffect, useRef } from "react";
import { useToastStore } from "../../stores/toastStore";

/**
 * Toast Notification Component
 * Displays temporary notification messages at the top or bottom of the screen
 * Automatically hides after 3 seconds
 * 
 * Supports different toast types: success, error, warning, info, danger, confirmation
 * Features smooth slide-in from right and fade-out animations
 */
const Toast: React.FC = () => {
    const { message, type, isVisible, hideToast, position } = useToastStore();
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    /**
     * Auto-hide toast after 3 seconds when it becomes visible
     * Clears any existing timeout when a new toast appears
     */
    useEffect(() => {
        if (isVisible && message) {
            // Clear any existing timeout
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }

            // Set new timeout to hide toast after 3 seconds
            timeoutRef.current = setTimeout(() => {
                hideToast();
            }, 3000);

            // Cleanup function to clear timeout on unmount or when dependencies change
            return () => {
                if (timeoutRef.current) {
                    clearTimeout(timeoutRef.current);
                }
            };
        }
    }, [isVisible, message, hideToast]);

    // Don't render if toast is not visible or missing required data
    if (!isVisible || !message || !type) {
        return null;
    }

    // Position classes based on position prop
    const positionClasses = position === "top" 
        ? "top-5" 
        : "bottom-5";

    return (
        <div className="fixed z-[999] top-5 right-5 pointer-events-none">
            <div
                className={`min-w-[343px] border bg-${type}-light border-${type} shadow-lg transform transition-all duration-300 ease-out animate-slide-in-right ${positionClasses} pointer-events-auto`}
            >
                {/* Colored top bar indicating toast type */}
                <div className="h-4 w-full bg-black" />
                
                {/* Toast content */}
                <div className="px-4 py-2 bg-white">
                    <h4 className="text-sm font-chivo-medium font-medium uppercase">{type}</h4>
                    <p className="text-sm font-chivo-regular font-normal uppercase text-[#909090]">{message}</p>
                </div>
            </div>
        </div>
    );
};

export default Toast;
