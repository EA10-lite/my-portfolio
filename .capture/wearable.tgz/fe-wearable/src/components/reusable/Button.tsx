import { Link } from "react-router-dom";


type ButtonProps = {
    title: string;
    className?: string;
    disabled?: boolean;
    loading?: boolean;
    onClick: () => void;
    href?: string;
    icon?: React.ReactNode;
    variant?: "black" | "white";
}

const Button = ({
    title,
    className,
    disabled,
    loading,
    onClick,
    href,
    icon,
    variant = "black"
}: ButtonProps) => {

    const variantClasses = {
        black: "bg-black text-white",
        white: "bg-white text-black",
    }

    const baseClasses = "px-8 py-4 text-sm lg:text-base font-chivo-regular font-normal leading-[100%] uppercase w-fit cursor-pointer flex items-center gap-2 justify-center transition-all duration-300 ease-out hover:scale-105 active:scale-95 hover:shadow-lg";

    if (href) {
        return (
            <Link
                to={href}
                className={`${baseClasses} ${variantClasses[variant]} ${className}`}
                style={{
                    letterSpacing: "-2%",
                }}
            >
                {icon && <span className="transition-transform duration-300 group-hover:rotate-12">{icon}</span>}
                <span>{title}</span>
            </Link>
        )
    }
    return (
        <button
            className={`${baseClasses} ${variantClasses[variant]} ${className} group`}
            onClick={onClick}
            disabled={disabled}
            style={{
                opacity: loading ? 0.5 : 1,
                letterSpacing: "-2%",
            }}
        >
            <div className="flex items-center justify-center gap-2">
                {icon && <span className="transition-transform duration-300 group-hover:rotate-12">{icon}</span>}
                <span>{title}</span>
            </div>
        </button>
    )
}

export default Button