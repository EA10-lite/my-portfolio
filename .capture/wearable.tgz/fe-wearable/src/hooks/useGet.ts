import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

/**
 * API Configuration
 * Base URL for the backend API
 * In production, this should be set via environment variables
 */
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

/**
 * Create axios instance with default configuration
 */
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

interface UseGetOptions {
  enabled?: boolean
  staleTime?: number
  refetchOnWindowFocus?: boolean
}

/**
 * Custom hook for GET requests using TanStack Query
 * @param queryKey - Unique key for the query (array format)
 * @param url - API endpoint URL (relative to base URL)
 * @param options - Optional query configuration
 * @returns TanStack Query result object
 */
export const useGet = <T = any>(
  queryKey: string[],
  url: string,
  options?: UseGetOptions
) => {
  return useQuery({
    queryKey,
    queryFn: async (): Promise<T> => {
      const response = await api.get(url)
      return response.data
    },
    enabled: options?.enabled ?? true,
    staleTime: options?.staleTime,
    refetchOnWindowFocus: options?.refetchOnWindowFocus ?? false,
  })
}
