import { useEffect, useRef, useState } from "react";

/**
 * Custom hook for scroll-triggered animations
 * Detects when an element enters the viewport and triggers animation
 * 
 * @param threshold - Percentage of element that must be visible (0-1)
 * @param rootMargin - Margin around the root element
 * @returns [ref, isVisible] - Ref to attach to element and visibility state
 */
export const useScrollAnimation = (
    threshold: number = 0.1,
    rootMargin: string = "0px"
) => {
    const [isVisible, setIsVisible] = useState(false);
    const ref = useRef<HTMLElement>(null);

    useEffect(() => {
        const element = ref.current;
        if (!element) return;

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        setIsVisible(true);
                        // Optionally unobserve after first trigger for performance
                        // observer.unobserve(entry.target);
                    }
                });
            },
            {
                threshold,
                rootMargin,
            }
        );

        observer.observe(element);

        return () => {
            if (element) {
                observer.unobserve(element);
            }
        };
    }, [threshold, rootMargin]);

    return [ref, isVisible] as const;
};
