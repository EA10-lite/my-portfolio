export const NAV_LINKS = [
    {
        href: "/category/male",
        label: "Male",
        sublinks: [
            {
                label: "T-Shirts",
                href: "/category/male/t-shirts"
            },
            {
                label: "Polo",
                href: "/category/male/polo"
            },
            {
                label: "Under wears",
                href: "/category/male/underwears"
            },
            {
                label: "Trousers",
                href: "/category/male/trousers"
            },
            {
                label: "Accessories",
                href: "/category/male/accessories"
            },
            {
                label: "Footwears",
                href: "/category/male/footwears"
            }
        ]
    },
    {
        href: "/category/female",
        label: "Female",
        sublinks: [
            {
                label: "T-Shirts",
                href: "/category/female/t-shirts"
            },
            {
                label: "Polo",
                href: "/category/female/polo"
            },
            {
                label: "Under wears",
                href: "/category/female/underwears"
            },
            {
                label: "Trousers",
                href: "/category/female/trousers"
            },
            {
                label: "Accessories",
                href: "/category/female/accessories"
            },
            {
                label: "Footwears",
                href: "/category/female/footwears"
            }
        ]
    },
    {
        href: "/category/accessories",
        label: "Accessories",
        sublinks: [
            {
                label: "Jewelry",
                href: "/category/accessories/jewelry"
            },
            {
                label: "Watches",
                href: "/category/accessories/watches"
            },
            {
                label: "Bags",
                href: "/category/accessories/bags"
            },
            {
                label: "Belts",
                href: "/category/accessories/belts"
            },
            {
                label: "Hats",
                href: "/category/accessories/hats"
            }
        ]
    },
    {
        href: "/category/footwears",
        label: "Footwears",
        sublinks: [
            {
                label: "Shoes",
                href: "/category/footwears/shoes"
            },
            {
                label: "Sandals",
                href: "/category/footwears/sandals"
            },
            {
                label: "Sneakers",
                href: "/category/footwears/sneakers"
            },
            {
                label: "Boots",
                href: "/category/footwears/boots"
            }
        ]
    }
]

export const CATEGORIES = [
    {
        title: "Male",
        image: "/images/men.png",
        count: 10,
        href: "/category/male"
    },
    {
        title: "Female",
        image: "/images/women.png",
        count: 10,
        href: "/category/female"
    },
    {
        title: "Accessories",
        image: "/images/accessories.png",
        count: 10,
        href: "/category/accessories"
    },
    {
        title: "Footwears",
        image: "/images/shoes.png",
        count: 10,
        href: "/category/footwears"
    }
]

export const PRODUCTS = [
    {
        id: 1,
        image: "/images/products/sweatshirt.png",
        title: "Classic Adidas-Style Sweatshirt",
        category: "Sweatshirts / Hoodies",
        price: "150000"
    },
    {
        id: 2,
        image: "/images/products/hoodie.png",
        title: "Oversized Graphic Hoodie",
        category: "Hoodie",
        price: "120000"
    },
    {
        id: 3,
        image: "/images/products/shirt.png",
        title: "Premium Cotton T-Shirt",
        category: "T-Shirts",
        price: "150000"
    },
    {
        id: 4,
        image: "/images/products/sleeveless.png",
        title: "Ribbed Sleeveless Crop Top",
        category: "Tops / crop tops",
        price: "80000"
    },
    {
        id: 5,
        image: "/images/products/sweatshirt.png",
        title: "Classic Adidas-Style Sweatshirt",
        category: "Sweatshirts / Hoodies",
        price: "150000"
    },
    {
        id: 6,
        image: "/images/products/hoodie.png",
        title: "Oversized Graphic Hoodie",
        category: "Hoodie",
        price: "120000"
    },
    {
        id: 7,
        image: "/images/products/shirt.png",
        title: "Premium Cotton T-Shirt",
        category: "T-Shirts",
        price: "150000"
    },
    {
        id: 8,
        image: "/images/products/sleeveless.png",
        title: "Ribbed Sleeveless Crop Top",
        category: "Tops / crop tops",
        price: "80000"
    },
]