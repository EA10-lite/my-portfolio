import api from './api';

export const searchProducts = async (
  query: string,
  page = 1,
  limit = 12
): Promise<{ success: boolean; products?: any[]; pagination?: any }> => {
  const params = new URLSearchParams();
  params.append('search', query);
  params.append('page', String(page));
  params.append('limit', String(limit));
  const response = await api.get(`/products/user?${params.toString()}`);
  return response.data;
};
