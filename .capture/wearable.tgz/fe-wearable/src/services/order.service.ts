import api from './api';

export interface OrderItem {
  productId: string;
  quantity: number;
  price: number;
  variants?: string[];
  colors?: string[];
  sizes?: string[];
}

export interface OrderPayload {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  paymentMethod: string;
  paymentReference?: string;
  items: OrderItem[];
}

export interface CreateOrderResponse {
  success: boolean;
  message: string;
  order?: any;
}

export const createOrder = async (
  payload: OrderPayload
): Promise<CreateOrderResponse> => {
  const response = await api.post<CreateOrderResponse>('/orders', payload);
  return response.data;
};

export const getOrdersByEmail = async (
  email: string
): Promise<{ success: boolean; orders?: any[] }> => {
  const response = await api.get(`/orders?email=${encodeURIComponent(email)}`);
  return response.data;
};

export const getMyOrders = async (): Promise<{ success: boolean; orders?: any[] }> => {
  const response = await api.get('/orders/my-orders');
  return response.data;
};
