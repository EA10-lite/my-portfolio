import api from './api';

export const initializePayment = async (payload: { orderIds: string[], email: string, amount: number }) => {
    try {
        const response = await api.post('/payments/initialize', payload);
        return response.data;
    } catch (error: any) {
        return error.response?.data || { success: false, message: 'Failed to initialize payment' };
    }
};

export const verifyPayment = async (reference: string) => {
    try {
        const response = await api.get(`/payments/verify/${reference}`);
        return response.data;
    } catch (error: any) {
        return error.response?.data || { success: false, message: 'Failed to verify payment' };
    }
};
