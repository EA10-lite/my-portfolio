
/**
 * Formats a price value (string or number) with thousand separators
 * @param price - The price value to format (can be string or number)
 * @returns Formatted price string with thousand separators (commas)
 * @example
 * formatPrice(80000) // "80,000"
 * formatPrice("80000") // "80,000"
 * formatPrice(1234567) // "1,234,567"
 */
export const formatPrice = (price: string | number): string => {
    // Convert to number, handling edge cases
    const numericPrice = typeof price === "string" ? parseFloat(price) : price;
    
    // Return "0" if the value is invalid, null, or undefined
    if (isNaN(numericPrice) || numericPrice === null || numericPrice === undefined) {
        return "0";
    }
    
    // Format the number with thousand separators
    // Using toLocaleString for proper formatting with commas
    return numericPrice.toLocaleString("en-US", {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    });
}