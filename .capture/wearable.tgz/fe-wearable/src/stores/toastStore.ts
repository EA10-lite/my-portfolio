import { create } from "zustand";

/**
 * Toast notification types
 * Used to style and categorize different types of notifications
 */
export type ToastType = "confirmation" | "success" | "error" | "warning" | "info" | "danger";

/**
 * Toast store interface
 * Manages toast notification state and actions
 */
interface ToastStore {
    message: string;
    type: ToastType | null;
    isVisible: boolean;
    position: "top" | "bottom";
    showToast: (message: string, type: ToastType, position?: "top" | "bottom") => void;
    hideToast: () => void;
}

/**
 * Zustand store for managing toast notifications
 * Provides functions to show and hide toast messages with different types
 */
export const useToastStore = create<ToastStore>((set) => ({
    message: "",
    type: null,
    isVisible: false,
    position: "bottom",
    
    /**
     * Show a toast notification with a message and type
     * Position defaults to "bottom" for consistency
     * 
     * @param message - The message to display in the toast
     * @param type - The type of toast (success, error, warning, etc.)
     * @param position - Optional position (top or bottom), defaults to "bottom"
     */
    showToast: (message: string, type: ToastType, position: "top" | "bottom" = "bottom") =>
        set({ message, type, position, isVisible: true }),
    
    /**
     * Hide the currently visible toast notification
     */
    hideToast: () => set({ isVisible: false }),
}));
