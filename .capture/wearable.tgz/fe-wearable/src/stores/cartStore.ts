import { create } from "zustand";
import { createJSONStorage, persist } from 'zustand/middleware';

/**
 * Represents a single item in the shopping cart
 * Each item is uniquely identified by the combination of productId, color, and size
 */
export interface CartItem {
    id: string; // Unique cart item ID (combination of productId, color, size)
    name: string;
    price: number;
    quantity: number;
    image: string;
    color?: string;
    size?: string;
    productId: string;
}

/**
 * Cart store interface defining all cart operations and state
 */
interface CartStore {
    items: CartItem[];
    total: number; // Total price of all items (price * quantity for each item)
    itemCount: number; // Total number of items in cart (sum of all quantities)
    
    // Actions
    addItem: (item: CartItem) => void;
    removeItem: (id: string) => void;
    updateQuantity: (id: string, quantity: number) => void;
    clearCart: () => void;
    
    // Helpers
    getItemById: (id: string) => CartItem | undefined;
    isInCart: (productId: string, color?: string, size?: string) => CartItem | undefined;
}

/**
 * Helper function to check if two cart items are the same
 * Items are considered the same if they have the same productId, color, and size
 */
const isSameItem = (item1: CartItem, item2: CartItem): boolean => {
    return (
        item1.productId === item2.productId &&
        item1.color === item2.color &&
        item1.size === item2.size
    );
};

/**
 * Calculate total price from cart items
 * Multiplies each item's price by its quantity and sums them up
 */
const calculateTotal = (items: CartItem[]): number => {
    return items.reduce((sum, item) => sum + item.price * item.quantity, 0);
};

/**
 * Calculate total item count (sum of all quantities)
 */
const calculateItemCount = (items: CartItem[]): number => {
    return items.reduce((count, item) => count + item.quantity, 0);
};

/**
 * Zustand store for managing shopping cart state
 * Includes persistence to localStorage so cart persists across page refreshes
 * 
 * Note: total and itemCount are computed from items array to ensure consistency
 */
const useCartStore = create<CartStore>()(
    persist(
        (set, get) => {
            // Helper to update computed properties based on items
            const updateComputed = (items: CartItem[]) => {
                const total = calculateTotal(items);
                const itemCount = calculateItemCount(items);
                return { items, total, itemCount };
            };

            return {
                items: [],
                total: 0,
                itemCount: 0,

                /**
                 * Add an item to the cart
                 * If an item with the same productId, color, and size already exists,
                 * it increments the quantity instead of adding a duplicate
                 */
                addItem: (newItem: CartItem) => {
                    set((state) => {
                        // Check if item already exists in cart
                        const existingItemIndex = state.items.findIndex((item) =>
                            isSameItem(item, newItem)
                        );

                        let updatedItems: CartItem[];

                        if (existingItemIndex >= 0) {
                            // Item exists, increment quantity
                            updatedItems = state.items.map((item, index) =>
                                index === existingItemIndex
                                    ? { ...item, quantity: item.quantity + newItem.quantity }
                                    : item
                            );
                        } else {
                            // New item, add to cart
                            updatedItems = [...state.items, newItem];
                        }

                        // Recalculate totals from items array to ensure consistency
                        return updateComputed(updatedItems);
                    });
                },

                /**
                 * Remove an item from the cart by its ID
                 */
                removeItem: (id: string) => {
                    set((state) => {
                        const updatedItems = state.items.filter((item) => item.id !== id);
                        return updateComputed(updatedItems);
                    });
                },

                /**
                 * Update the quantity of a specific cart item
                 * If quantity is 0 or less, the item is removed from the cart
                 */
                updateQuantity: (id: string, quantity: number) => {
                    if (quantity <= 0) {
                        // Remove item if quantity is 0 or negative
                        get().removeItem(id);
                        return;
                    }

                    set((state) => {
                        const updatedItems = state.items.map((item) =>
                            item.id === id ? { ...item, quantity } : item
                        );
                        return updateComputed(updatedItems);
                    });
                },

                /**
                 * Clear all items from the cart
                 */
                clearCart: () => {
                    set({
                        items: [],
                        total: 0,
                        itemCount: 0,
                    });
                },

                /**
                 * Get a cart item by its ID
                 * Returns undefined if item is not found
                 */
                getItemById: (id: string) => {
                    return get().items.find((item) => item.id === id);
                },

                /**
                 * Check if a product variant (productId, color, size) is already in the cart
                 * Returns the cart item if found, undefined otherwise
                 * 
                 * @param productId - The product ID to check
                 * @param color - Optional color variant
                 * @param size - Optional size variant
                 * @returns The cart item if found, undefined otherwise
                 */
                isInCart: (productId: string, color?: string, size?: string) => {
                    const items = get().items;
                    return items.find((item) => 
                        item.productId === productId &&
                        item.color === color &&
                        item.size === size
                    );
                },
            };
        },
        {
            name: 'cart-storage', // Unique name for localStorage key
            storage: createJSONStorage(() => localStorage),
            // Only persist items, total and itemCount are computed on rehydration
            partialize: (state) => ({ items: state.items }),
            // Recalculate computed properties when loading from storage
            onRehydrateStorage: () => (state) => {
                if (state) {
                    const total = calculateTotal(state.items);
                    const itemCount = calculateItemCount(state.items);
                    state.total = total;
                    state.itemCount = itemCount;
                }
            },
        }
    )
);

export default useCartStore;