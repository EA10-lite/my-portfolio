import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

interface User {
    id: string;
    name: string;
    email: string;
    phone?: string;
    address?: string;
}

interface UserState {
    user: User | null;
    setUser: (user: User | null) => void;
    login: (userData: User) => void;
    logout: () => void;
    isAuthenticated: boolean;
    isLoading: boolean;
    openLoginModal: boolean;
    setOpenLoginModal: (open: boolean) => void;
}

export const useUserStore = create<UserState>()(
    persist(
      (set) => ({
        user: null,
        setUser: (user: User | null) => set({ user, isAuthenticated: !!user }),
        login: (userData: User) => set({ user: userData, isAuthenticated: true }),
        logout: () => set({ user: null, isAuthenticated: false }),
        isAuthenticated: false,
        isLoading: false,
        openLoginModal: false,
        setOpenLoginModal: (open: boolean) => set({ openLoginModal: open }),
      }),
      {
        name: 'wearable-user',
        storage: createJSONStorage(() => sessionStorage),
        onRehydrateStorage: () => (state) => {
          if (state) {
            state.isAuthenticated = !!state.user;
          }
        }
      }
    )
  );