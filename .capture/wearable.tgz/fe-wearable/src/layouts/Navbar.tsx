import { useRef, useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Logo } from "../components";
import { GoPlus } from "react-icons/go";
import { useUserStore } from "../stores/userStore";
import { Cart, Search } from "../components/main";
import MobileMenu from "./MobileMenu";
import { NAV_LINKS } from "../constants/data";
import { useOutsideClick } from "../hooks";

const Navbar = () => {
    const { setOpenLoginModal, openLoginModal } = useUserStore();
    const [activeLink, setActiveLink] = useState<string | number | null>(-1);

    return (
        <nav className="navbar bg-white border-b border-[#0000001A] fixed top-0 z-[999] h-16 flex justify-center items-center w-full">
            <div className="container mx-auto py-4 px-4">
                <div className="flex items-center justify-between">
                    <Logo />

                    <div className="flex items-center gap-4">
                        <div className="hidden lg:flex items-center justify-between gap-16">
                            <ul className="flex items-center gap-16">
                                {NAV_LINKS.map((link, index) => (
                                    <NavLink
                                        key={link.href}
                                        href={link.href}
                                        label={link.label}
                                        sublinks={link.sublinks}
                                        isActive={activeLink === index}
                                        onClick={() => setActiveLink(activeLink === index ? null : index)}
                                    />
                                ))}
                            </ul>

                            <div className="flex items-center gap-4">
                                <Search />
                                <Cart />

                                <div className="w-[1px] self-stretch bg-black" />

                                <button
                                    className="text-black font-chivo-regular font-normal uppercase text-sm leading-[100%] cursor-pointer"
                                    onClick={() => setOpenLoginModal(!openLoginModal)}
                                >
                                    <span>login</span>
                                </button>
                            </div>
                        </div>


                        <div className="mobile-menu lg:hidden">
                            <div className="flex items-center gap-4">
                                <Search />
                                <Cart />
                                <MobileMenu />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    )
}

type NavLinkProps  = {
    href: string;
    label: string;
    sublinks?: {
        label: string;
        href: string;
    }[];
    isActive?: boolean;
    onClick: () => void;
}

const NavLink = ({
    href,
    label,
    sublinks,
    isActive,
    onClick
}: NavLinkProps) => {
    const { pathname } = useLocation();

    const dropdownRef = useRef<HTMLDivElement>(null);
    const containerRef = useRef<HTMLLIElement>(null);
    const [isHovered, setIsHovered] = useState(false);
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    // Handle hover to show/hide dropdown with delay to account for gap
    const handleMouseEnter = () => {
        if (sublinks) {
            // Clear any pending close timeout
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
            setIsHovered(true);
        }
    };

    const handleMouseLeave = (e: React.MouseEvent) => {
        if (sublinks) {
            // Check if mouse is moving to the dropdown or still within the container
            const relatedTarget = e.relatedTarget as HTMLElement;
            if (
                containerRef.current &&
                relatedTarget &&
                containerRef.current.contains(relatedTarget)
            ) {
                // Mouse is still within our component, don't close
                return;
            }

            // Add a small delay before closing to allow movement to dropdown
            timeoutRef.current = setTimeout(() => {
                setIsHovered(false);
            }, 150);
        }
    };

    useOutsideClick(dropdownRef, () => {
        setIsHovered(false);
        if (isActive) {
            onClick();
        }
    });

    // Cleanup timeout on unmount
    useEffect(() => {
        return () => {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }
        };
    }, []);

    return (
        <li
            ref={containerRef}
            className="relative group"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
        >
            <Link
                to={href}
                className="flex items-center gap-1 cursor-pointer transition-all duration-200 hover:opacity-70"
            >
                <span className="text-black font-chivo-regular font-normal uppercase text-sm leading-[100%]">{label}</span>
                {sublinks && (
                    <GoPlus className="group-hover:rotate-[45deg] transition-transform duration-300" />
                )}
            </Link>

            {/* Dropdown menu for sublinks */}
            {sublinks && (isActive || isHovered) && (
                <div
                    className={`absolute top-full left-0 mt-2 bg-white border border-[#0000001A] shadow-lg min-w-[123px] z-50 transition-all duration-300 ease-out ${
                        isActive || isHovered 
                            ? "opacity-100 translate-y-0" 
                            : "opacity-0 -translate-y-2"
                    }`}
                    ref={dropdownRef}
                    onMouseEnter={handleMouseEnter}
                    onMouseLeave={handleMouseLeave}
                >
                    <ul className="">
                        {sublinks.map((sublink, index) => (
                            <li 
                                key={sublink.href}
                                style={{
                                    animation: `fadeInUp 0.3s ease-out ${index * 50}ms both`
                                }}
                            >
                                <Link
                                    to={sublink.href}
                                    className={`block px-4 py-2.5 text-black font-chivo-regular font-normal uppercase text-xs leading-[100%] hover:bg-black hover:text-white transition-all duration-200 ${pathname === sublink.href ? "bg-black text-white" : ""}`}
                                    style={{
                                        letterSpacing: "-2%"
                                    }}
                                >
                                    {sublink.label}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </li>
    )
}

export default Navbar;