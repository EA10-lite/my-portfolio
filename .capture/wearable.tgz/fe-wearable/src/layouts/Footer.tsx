import React from "react";
import {
    FaFacebook,
    FaInstagram,
    FaTiktok,
    FaTwitter
} from 'react-icons/fa';
import { Link } from "react-router-dom";



const SOCIAL_LINKS = [
    {
        icon: <FaFacebook />,
        href: "https://www.facebook.com/profile.php?id=61590889324516"
    },
    {
        icon: <FaInstagram />,
        href: "https://www.instagram.com/wearablenigeria?igsh=MWh5dDZyamo1NmpxZA=="
    },
    {
        icon: <FaTwitter />,
        href: "https://x.com/wearableng"
    },
    {
        icon: <FaTiktok />,
        href: "https://www.tiktok.com/@wearablesnigeria?_r=1&_d=f2ba532e4e5h5f&sec_uid=MS4wLjABAAAARtLi9yvrJYFE8aXFVYCocYy8u_3aDHn9esG-cH9A7hSlfkVxF9Lhf9YR8H7sedUM&share_author_id=7615281286806766608&sharer_language=en&source=h5_m&u_code=f2ba680kcgjmf0&timestamp=1781770558&user_id=7615281286806766608&sec_user_id=MS4wLjABAAAARtLi9yvrJYFE8aXFVYCocYy8u_3aDHn9esG-cH9A7hSlfkVxF9Lhf9YR8H7sedUM&item_author_type=1&utm_source=copy&utm_campaign=client_share&utm_medium=android&share_iid=7651694150954714901&share_link_id=d2507968-9c27-40ad-a5b9-728e098a45da&share_app_id=1233&ugbiz_name=ACCOUNT&ug_btm=b8727%2Cb7360&social_share_type=5&enable_checksum=1"
    }
]


const FOOTER_LINKS = [
    {
        label: "Male",
        href: "/category/male"
    },
    {
        label: "Female",
        href: "/category/female"
    },
    {
        label: "Accessories",
        href: "/category/accessories"
    },
    {
        label: "Footwears",
        href: "/category/footwears"
    }
]

const Footer = React.forwardRef<HTMLElement>((_props, ref) => {
    return (
        <footer ref={ref} className="footer">
            <div className="bg-black">
                <div className="container mx-auto py-6">
                    <div className="flex items-center justify-center py-20">
                        <div className="max-w-lg mx-auto text-white text-center">
                            <div className="w-full mx-auto mb-6">
                                <h2 className="text-[24px] lg:text-[52px] lg:leading-[50px] font-chivo font-medium leading-[100%] uppercase mb-4">Join the<br className="hidden lg:block" />Style Circle</h2>
                                <p 
                                    className="text-sm lg:text-base font-chivo font-normal leading-[100%]"
                                    style={{
                                        letterSpacing: "-2%"
                                    }}
                                >DON’T MISS AN UPDATE FROM US AT WEARABLES</p>
                            </div>

                            <div className="w-full">
                                <form action="">
                                    <div className="flex flex-col lg:flex-row items-center gap-4 lg:gap-0">
                                        <input 
                                            type="email" 
                                            className="w-full p-2 border border-white lg:border-r-0 bg-transparent text-white h-[48px]" 
                                        />
                                        <button 
                                            type="submit" 
                                            className="bg-white text-black px-4 py-2 text-sm lg:text-base font-chivo font-medium leading-[100%] uppercase h-[48px]"
                                        >
                                            Subscribe
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div className="hidden lg:flex items-center justify-center gap-16">
                        {FOOTER_LINKS.map((link) => (
                            <Link 
                                key={link.href} 
                                to={link.href} 
                                className="text-white text-sm font-chivo font-normal leading-[100%] uppercase hover:underline transition-all duration-300"
                            >
                                {link.label}
                            </Link>
                        ))}
                    </div>
                </div>
            </div>

            <div className="">
                <div className="container mx-auto w-full py-4 px-6">
                    <div className="flex flex-col-reverse md:flex-row md:items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                            <p className="text-base uppercase font-chivo font-medium leading-[100%]">© 2025 - Wearable</p>
                        </div>

                        <div className="flex items-center gap-2">
                            {SOCIAL_LINKS.map((link) => (
                                <SocialLinks 
                                    key={link.href} 
                                    icon={link.icon} 
                                    href={link.href} 
                                />
                            ))}
                        </div>
                    </div>

                </div>
            </div>
        </footer>
    )
});

Footer.displayName = "Footer";

type SocialLinksProps = {
    icon: React.ReactNode;
    href: string;
}

const SocialLinks = ({ icon, href }: SocialLinksProps) => {
    return (
        <div className="flex items-center justify-center text-white bg-black w-10 h-10">
            <a 
                href={href}
                target="_blank" 
                rel="noopener noreferrer"
            >
                {icon}
            </a>
        </div>
    )
}

export default Footer;