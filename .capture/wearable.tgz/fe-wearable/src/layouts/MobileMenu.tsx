import { MdClose } from "react-icons/md";

import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTrigger,
} from "../components/ui/sheet"
import { FiMenu } from "react-icons/fi";
import { GoPlus } from "react-icons/go";
import { Link } from "react-router-dom";
import { useState } from "react";
import { NAV_LINKS } from "../constants/data";
import { useUserStore } from "../stores/userStore";


const MobileMenu = () => {
    const [activeLink, setActiveLink] = useState<string | number | null>(-1);
    const { setOpenLoginModal, openLoginModal } = useUserStore();

    // Handle login click - close sheet and open login modal
    const handleLoginClick = () => {
        setOpenLoginModal(!openLoginModal);
    };

    return (
        <Sheet>
            <SheetTrigger asChild className="p-0 m-0">
                <button className="">
                <div className="flex items-center gap-1">
                    <FiMenu size={18} />
                </div>
                </button>
            </SheetTrigger>
            <SheetContent className="z-[999] w-[95%] md:min-w-[538px] p-0">
                <SheetHeader className="p-0">
                    <div className="flex items-center justify-between p-4 bg-black flex items-center justify-between sticky top-0 z-50">
                        <h4 className="text-base font-chivo-regular font-normal  text-white">Menu</h4>

                        <div className="flex items-center gap-2">
                            <SheetClose asChild>
                                <button
                                    className="text-sm font-chivo-regular font-normal text-white cursor-pointer hover:opacity-80 transition-opacity"
                                    onClick={handleLoginClick}
                                >
                                    Login
                                </button>
                            </SheetClose>
                            <SheetClose>
                                <button
                                    className="w-8 h-8 bg-[#f2f2f2] flex items-center justify-center"
                                    >
                                    <MdClose />
                                </button>
                            </SheetClose>
                        </div>
                    </div>
                </SheetHeader>

                <div className="px-4 py-8 flex flex-col gap-4">
                    {NAV_LINKS.map((link, index) => (
                        <MenuItem
                            key={link.href}
                            href={link.href}
                            label={link.label}
                            sublinks={link.sublinks}
                            isActive={activeLink === index}
                            onClick={() => setActiveLink(activeLink === index ? null : index)}
                        />
                    ))}
                </div>
            </SheetContent>
        </Sheet>
    )
}

type NavLinkProps  = {
    href: string;
    label: string;
    sublinks?: {
        label: string;
        href: string;
    }[];
    isActive?: boolean;
    onClick: () => void;
}

const MenuItem = ({ label, sublinks, isActive, onClick }: NavLinkProps) => {
    return (
        <div className="">
            <div
                className="flex items-center gap-1 cursor-pointer"
                onClick={onClick}
            >
                <span className="text-black font-chivo-regular font-normal uppercase text-sm leading-[100%]">{label}</span>
                {sublinks && (
                    <button
                        className="flex items-center justify-center"
                        aria-label="Toggle submenu"
                    >
                        <GoPlus />
                    </button>
                )}
            </div>

            {isActive && (
                <div className="flex flex-col gap-2 mt-2 animate-fade-in">
                    {sublinks?.map((sublink, index) => (
                        <Link 
                            to={sublink.href} 
                            key={sublink.href} 
                            className="block px-4 py-1.5 hover:bg-black hover:text-white transition-all duration-300 w-fit"
                            style={{
                                animation: `fadeInUp 0.3s ease-out ${index * 50}ms both`
                            }}
                        >
                            <span
                                className="font-chivo-regular font-normal uppercase text-xs leading-[100%]"
                                style={{
                                    letterSpacing: "-2%"
                                }}
                            >
                                {sublink.label}
                            </span>
                        </Link>
                    ))}
                </div>
            )}
        </div>
    )
}

export default MobileMenu;