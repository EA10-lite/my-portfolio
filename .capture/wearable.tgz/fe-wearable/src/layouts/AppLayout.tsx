import { useEffect, useState, useCallback } from "react";
import { Outlet } from "react-router-dom";
import Footer from "./Footer";
import Navbar from "./Navbar";
import { Login, Toast } from "../components";
import { useUserStore } from "../stores/userStore";


const AppLayout = () => {
    const { openLoginModal } = useUserStore();
    const [isFooterVisible, setIsFooterVisible] = useState(false);
    const [footerElement, setFooterElement] = useState<HTMLElement | null>(null);

    // Callback ref to get the footer element
    const footerRef = useCallback((node: HTMLElement | null) => {
        if (node) {
            setFooterElement(node);
        }
    }, []);

    // Hide WhatsApp button when footer is visible
    useEffect(() => {
        if (!footerElement) return;

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    setIsFooterVisible(entry.isIntersecting);
                });
            },
            {
                threshold: 0.1, // Trigger when 10% of footer is visible
            }
        );

        observer.observe(footerElement);

        return () => {
            observer.unobserve(footerElement);
        };
    }, [footerElement]);

    return (
        <div className="min-h-screen w-full overflow-auto relative flex flex-col">
            <Navbar />
            <main className="flex-1 mt-16 pb-8 relative flex-1">
                {openLoginModal && <Login />}
                <div className="">
                    <Outlet />
                </div>

                {/* Hide WhatsApp button when footer is visible */}
                {!isFooterVisible && (
                <div className="fixed bottom-12 z-[999] w-full pointer-events-none animate-fade-in-up">
                    <div className="container mx-auto px-4">
                    <div className="flex justify-end pointer-events-auto">
                        <a
                        href="https://wa.me/qr/KMNFY7HOJ33OI1"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-black rounded-[35px] flex items-center gap-4 p-4 transition-all duration-300 ease-out hover:scale-105 hover:shadow-lg cursor-pointer"
                        >
                        <p className="font-chivo-regular font-normal uppercase text-sm lg:text-base leading-[100%] lg:leading-[24px] text-justify text-white hidden lg:inline-flex">
                            NEED HELP?
                        </p>

                        <img
                            src="/icons/whatsapp.svg"
                            alt="WhatsApp"
                            className="transition-transform duration-300 hover:scale-110"
                        />
                        </a>
                    </div>
                    </div>
                </div>
                )}
            </main>
            <Footer ref={footerRef} />
            <Toast />
        </div>
    )
}

export default AppLayout;