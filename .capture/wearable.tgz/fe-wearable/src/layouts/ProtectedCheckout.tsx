import { Navigate } from "react-router-dom";
import useCartStore from "../stores/cartStore";

interface ProtectedCheckoutProps {
    children: React.ReactNode;
}

const ProtectedCheckout = ({ children }: ProtectedCheckoutProps) => {
    const { items } = useCartStore();

    if (items.length === 0) {
        return <Navigate to="/" replace />;
    }

    return <>{children}</>;
};

export default ProtectedCheckout;

