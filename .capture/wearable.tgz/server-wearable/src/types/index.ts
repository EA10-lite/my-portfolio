

export interface ApiResponse<T = any> {
    success: boolean;
    message: string;
    data?: T;
    error?: string;
}

export interface JWTPayload {
    id: string;
    email: string;
    isAdmin: boolean;
    iat?: number;
    exp?: number;
  }
  