
/**
 * Product image interface
 */
export interface ProductImage {
    url: string;
    publicId: string;
}

/**
 * Request interface for adding a product
 * Note: images will be uploaded files, not URLs
 */
export interface AddProductRequest {
    name: string;
    description?: string;
    category: string;
    colors: string[];
    sizes: string[];
    variants: string[];
    price: number;
    discountPrice: number;
    samePriceForAllSizes: boolean;
    variantsPrice: number[];
    stock: number;
}

/**
 * Customer-facing product response (public data only)
 * Excludes sensitive information like sales, status, and Cloudinary publicIds
 */
export interface CustomerProductResponse {
    id: string;
    name: string;
    description?: string;
    category: string;
    subCategory?: string;
    colors: string[];
    sizes: string[];
    variants: string[];
    price: number;
    discountPrice: number;
    samePriceForAllSizes: boolean;
    variantsPrice: number[];
    stock: number;
    images: string[]; // Only URLs, no publicIds
    createdAt: string;
}

/**
 * Admin product response (includes all data)
 * Includes sensitive information like sales, status, and Cloudinary publicIds
 */
export interface ProductResponse {
    id: string;
    name: string;
    description?: string;
    category: string;
    subCategory?: string;
    colors: string[];
    sizes: string[];
    variants: string[];
    price: number;
    discountPrice: number;
    samePriceForAllSizes: boolean;
    variantsPrice: number[];
    stock: number;
    images: ProductImage[]; // Includes URLs and publicIds
    sales: number;
    status: 'active' | 'inactive' | 'out_of_stock';
    createdAt: string;
    updatedAt: string;
}

/**
 * Request interface for editing a product
 */
export interface EditProductRequest extends Partial<AddProductRequest> {
    // Images can be updated (new files uploaded)
    // Old images will be deleted if not included
}



export interface OrderRequest {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    productId: string;
    quantity: number;
    price: number;
    variants?: string[];
    colors?: string[];
    sizes?: string[];
    deliveryAddress: {
        street: string;
        state: string;
        lga: string;
    };
    paymentMethod: string;
    paymentReference?: string;
}

export interface UpdateOrderStatusRequest {
    orderStatus: 'pending' | 'confirmed' | 'processing' | 'packed' | 'assigned' | 'shipped' | 'delivered' | 'cancelled';
}

export interface OrderResponse {
    id: string;
    customerId?: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    product: {
        id: string;
        name: string;
        description?: string;
        images: string[];
        category: string;
        price: number;
    };
    quantity: number;
    price: number;
    total: number;
    variants?: string[];
    colors?: string[];
    sizes?: string[];
    deliveryAddress: {
        street: string;
        state: string;
        lga: string;
    };
    paymentMethod: string;
    paymentStatus: 'pending' | 'paid' | 'failed' | 'refunded';
    paymentReference?: string;
    orderStatus: 'pending' | 'confirmed' | 'processing' | 'packed' | 'assigned' | 'shipped' | 'delivered' | 'cancelled';
    paymentConfirmedAt?: string;
    packedAt?: string;
    assignedAt?: string;
    shippedAt?: string;
    deliveredAt?: string;
    cancelledAt?: string;
    createdAt: string;
    updatedAt: string;
}