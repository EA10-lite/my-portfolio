import Joi from 'joi';

/**
 * Validation schema for adding/editing products
 * Note: Images are handled separately via multer middleware (file uploads)
 * This schema validates the text fields sent in the request body
 * Values are parsed by validateFormData middleware before validation
 */
export const addProductSchema = Joi.object({
    name: Joi.string().required().trim().messages({
        'string.empty': 'Product name is required',
        'any.required': 'Product name is required',
    }),
    description: Joi.string().optional().allow('').trim(),
    category: Joi.string().required().trim().messages({
        'string.empty': 'Category is required',
        'any.required': 'Category is required',
    }),
    colors: Joi.array().items(Joi.string()).min(1).required().messages({
        'array.min': 'At least one color is required',
        'any.required': 'Colors are required',
    }),
    sizes: Joi.array().items(Joi.string()).min(1).required().messages({
        'array.min': 'At least one size is required',
        'any.required': 'Sizes are required',
    }),
    variants: Joi.array().items(Joi.string()).required().messages({
        'any.required': 'Variants are required',
    }),
    price: Joi.number().required().min(0).messages({
        'number.base': 'Price must be a number',
        'number.min': 'Price must be greater than or equal to 0',
        'any.required': 'Price is required',
    }),
    discountPrice: Joi.number().required().min(0).messages({
        'number.base': 'Discount price must be a number',
        'number.min': 'Discount price must be greater than or equal to 0',
        'any.required': 'Discount price is required',
    }),
    samePriceForAllSizes: Joi.boolean().required().messages({
        'boolean.base': 'samePriceForAllSizes must be a boolean',
        'any.required': 'samePriceForAllSizes is required',
    }),
    variantsPrice: Joi.array().items(Joi.number().min(0)).required().messages({
        'any.required': 'Variants price is required',
    }),
    stock: Joi.number().required().integer().min(0).messages({
        'number.base': 'Stock must be a number',
        'number.integer': 'Stock must be an integer',
        'number.min': 'Stock must be greater than or equal to 0',
        'any.required': 'Stock is required',
    }),
    // imagesToKeep is optional and used when editing products
    imagesToKeep: Joi.array().items(Joi.string()).optional(),
});