import Joi from 'joi';

export const createOrderSchema = Joi.object({
    customerName: Joi.string().required().trim().messages({
        'string.empty': 'Customer name is required',
        'any.required': 'Customer name is required',
    }),
    customerEmail: Joi.string().email().required().trim().messages({
        'string.email': 'Please provide a valid email address',
        'string.empty': 'Customer email is required',
        'any.required': 'Customer email is required',
    }),
    customerPhone: Joi.string().required().trim().messages({
        'string.empty': 'Customer phone is required',
        'any.required': 'Customer phone is required',
    }),
    items: Joi.array().items(
        Joi.object({
            productId: Joi.string().required().trim().messages({
                'string.empty': 'Product ID is required',
                'any.required': 'Product ID is required',
            }),
            quantity: Joi.number().integer().min(1).required().messages({
                'number.base': 'Quantity must be a number',
                'number.integer': 'Quantity must be an integer',
                'number.min': 'Quantity must be at least 1',
                'any.required': 'Quantity is required',
            }),
            price: Joi.number().min(0).required().messages({
                'number.base': 'Price must be a number',
                'number.min': 'Price must be greater than or equal to 0',
                'any.required': 'Price is required',
            }),
            variants: Joi.array().items(Joi.string()).optional(),
            colors: Joi.array().items(Joi.string()).optional(),
            sizes: Joi.array().items(Joi.string()).optional(),
        })
    ).min(1).required().messages({
        'array.min': 'Order must contain at least one item',
        'any.required': 'Items are required',
    }),
    deliveryAddress: Joi.string().required().trim().messages({
        'string.empty': 'Delivery address is required',
        'any.required': 'Delivery address is required',
    }),
    paymentMethod: Joi.string().required().trim().messages({
        'string.empty': 'Payment method is required',
        'any.required': 'Payment method is required',
    }),
    paymentReference: Joi.string().optional().trim().allow(''),
});

export const updateOrderStatusSchema = Joi.object({
    orderStatus: Joi.string()
        .valid('pending', 'processing', 'packed', 'assigned', 'shipped', 'delivered', 'cancelled')
        .required()
        .messages({
            'any.only': 'Order status must be one of: pending, processing, packed, assigned, shipped, delivered, cancelled',
            'any.required': 'Order status is required',
        }),
});
