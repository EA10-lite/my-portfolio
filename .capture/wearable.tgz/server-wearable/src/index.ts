// Load environment variables first, before any other imports
import dotenv from 'dotenv';
dotenv.config();

import express, { Application, Request, Response, NextFunction } from 'express';
import { config } from './startup/config';
import { cors } from './startup/cors';
import { swagger } from './startup/swagger';
import { routes } from './startup/routes';
import { db } from './startup/db';
import { handleError } from './utils/responseHandler';
import helmet from 'helmet';
import mongoSanitize from 'express-mongo-sanitize';
import { apiLimiter } from './middleware/rateLimiter';

// Initialize Express application
const app: Application = express();

// Security Middlewares
app.use(helmet());
app.use(mongoSanitize());

// General API Rate Limiting
app.use('/api', apiLimiter);

import cookieParser from 'cookie-parser';

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Startup configurations
config(); // Validate environment variables
cors(app); // Configure CORS
db(app); // Connect to MongoDB
swagger(app); // Setup Swagger documentation
routes(app); // Setup routes

// Root endpoint - Welcome page
app.get('/', (req: Request, res: Response) => {
  // Get base URL from request or environment variable
  const protocol = req.protocol || 'http';
  const host = req.get('host') || `localhost:${process.env.PORT || 3000}`;
  const baseUrl = process.env.BASE_URL || `${protocol}://${host}`;
  const docsUrl = `${baseUrl}/api-docs`;
  
  res.status(200).send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Welcome to Wearable API</title>
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
        }
        .container {
          background: white;
          border-radius: 20px;
          padding: 60px 40px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          text-align: center;
          max-width: 600px;
          width: 100%;
        }
        h1 {
          color: #333;
          font-size: 2.5rem;
          margin-bottom: 20px;
          font-weight: 700;
        }
        p {
          color: #666;
          font-size: 1.2rem;
          margin-bottom: 40px;
          line-height: 1.6;
        }
        .docs-link {
          display: inline-block;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          text-decoration: none;
          padding: 16px 40px;
          border-radius: 50px;
          font-size: 1.1rem;
          font-weight: 600;
          transition: transform 0.2s, box-shadow 0.2s;
          box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        .docs-link:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .docs-link:active {
          transform: translateY(0);
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Welcome to Wearable API</h1>
        <p>E-commerce API for managing clothing products, orders, and customers.</p>
        <a href="${docsUrl}" class="docs-link">View API Documentation</a>
      </div>
    </body>
    </html>
  `);
});

// Health check endpoint
app.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'OK',
    message: 'Server is running',
    timestamp: new Date().toISOString()
  });
});

// Error handling middleware (should be last)
// This catches errors from async route handlers and other middleware
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Error:', err);
  handleError(err, res);
});

// Start server only if not in serverless environment (Vercel)
// Vercel serverless functions don't need app.listen()
if (process.env.VERCEL !== '1') {
  // Default to 3000 to avoid conflict with macOS AirPlay on port 5000
  const PORT = process.env.PORT || 3000;
  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`API Documentation: http://localhost:${PORT}/api-docs`);
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server');
    server.close(() => {
      console.log('HTTP server closed');
      process.exit(0);
    });
  });
}

export default app;

