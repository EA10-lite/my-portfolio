import mongoose, { Document, Schema } from 'mongoose';

export interface IShippingFee extends Document {
  state: string;
  lga?: string;
  fee: number;
  isDefault: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const shippingFeeSchema = new Schema<IShippingFee>(
  {
    state: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    lga: {
      type: String,
      trim: true,
      index: true,
    },
    fee: {
      type: Number,
      required: true,
      min: 0,
    },
    isDefault: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

shippingFeeSchema.index({ state: 1, lga: 1 });

// Ensure only one default shipping fee exists
shippingFeeSchema.pre('save', async function (next) {
  if (this.isDefault) {
    await mongoose.model('ShippingFee').updateMany(
      { _id: { $ne: this._id } },
      { $set: { isDefault: false } }
    );
  }
  next();
});

export const ShippingFee = mongoose.model<IShippingFee>('ShippingFee', shippingFeeSchema);
