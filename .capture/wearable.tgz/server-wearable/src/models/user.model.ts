import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcrypt';

/**
 * User role types
 * - admin: Has full access to the dashboard
 * - customer: Regular customer who can place orders
 */
export type UserRole = 'admin' | 'customer';

/**
 * User document interface
 * Represents a user in the system (either admin or customer)
 */
export interface IUser extends Document {
  email: string;
  password?: string; // Only for admin users
  role: UserRole;
  name?: string; // Optional name for customers
  phone?: string; // Optional phone number
  address?: string; // Optional delivery address
  isVerified: boolean; // Email verification status
  isBlocked: boolean; // Whether the account is blocked by admin
  createdAt: Date;
  updatedAt: Date;
}

/**
 * User schema definition
 * Stores user information for both admin and customer accounts
 */
const userSchema = new Schema<IUser>(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      index: true,
    },
    password: {
      type: String,
      required: function (this: IUser) {
        // Password is required only for admin users
        return this.role === 'admin';
      },
      select: false, // Don't return password by default in queries
    },
    role: {
      type: String,
      enum: ['admin', 'customer'],
      required: true,
      default: 'customer',
    },
    name: {
      type: String,
      trim: true,
    },
    phone: {
      type: String,
      trim: true,
    },
    address: {
      type: String,
      trim: true,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
    isBlocked: {
      type: Boolean,
      default: false,
      index: true,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt
  }
);

// Hash password before saving (only for admin users)
userSchema.pre('save', async function (next) {
  // Only hash password if it's modified and user is admin
  if (this.isModified('password') && this.role === 'admin' && this.password) {
    try {
      const saltRounds = 10;
      this.password = await bcrypt.hash(this.password, saltRounds);
    } catch (error) {
      return next(error as Error);
    }
  }
  next();
});

// Hash password before updating (only for admin users)
userSchema.pre('findOneAndUpdate', async function (next) {
  const update = this.getUpdate() as { password?: string; role?: string };
  
  // Only hash password if it's being updated and user is admin
  if (update.password && update.role === 'admin') {
    try {
      const saltRounds = 10;
      update.password = await bcrypt.hash(update.password, saltRounds);
    } catch (error) {
      return next(error as Error);
    }
  }
  next();
});

// Index for faster queries
userSchema.index({ email: 1, role: 1 });

export const User = mongoose.model<IUser>('User', userSchema);

