import mongoose, { Document, Schema } from 'mongoose';

/**
 * Product document interface
 * Represents a clothing product in the e-commerce system
 */
export interface IProduct extends Document {
  name: string;
  description?: string;
  category: string; // Main category: male, female, accessories, footwear
  subCategory?: string; // Subcategory based on main category
  colors: string[];
  sizes: string[];
  variants: string[];
  price: number;
  discountPrice: number;
  samePriceForAllSizes: boolean;
  variantsPrice: number[];
  stock: number;
  images: Array<{
    url: string;
    publicId: string; // Cloudinary public ID for deletion
  }>;
  sales: number; // Total number of sales
  status: 'active' | 'inactive' | 'out_of_stock';
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Product schema definition
 * Stores product information including images, pricing, and inventory
 */
const productSchema = new Schema<IProduct>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    description: {
      type: String,
      trim: true,
    },
    category: {
      type: String,
      required: true,
      trim: true,
      index: true,
      enum: ['male', 'female', 'accessories', 'footwear'],
    },
    subCategory: {
      type: String,
      trim: true,
      index: true,
    },
    colors: {
      type: [String],
      required: true,
      default: [],
    },
    sizes: {
      type: [String],
      required: true,
      default: [],
    },
    variants: {
      type: [String],
      required: true,
      default: [],
    },
    price: {
      type: Number,
      required: true,
      min: 0,
    },
    discountPrice: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    samePriceForAllSizes: {
      type: Boolean,
      required: true,
      default: false,
    },
    variantsPrice: {
      type: [Number],
      required: true,
      default: [],
    },
    stock: {
      type: Number,
      required: true,
      min: 0,
      default: 0,
    },
    images: [
      {
        url: {
          type: String,
          required: true,
        },
        publicId: {
          type: String,
          required: true,
        },
      },
    ],
    sales: {
      type: Number,
      default: 0,
      min: 0,
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'out_of_stock'],
      default: 'active',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for faster queries
productSchema.index({ category: 1, status: 1 });
productSchema.index({ category: 1, subCategory: 1 }); // For category/subcategory queries
productSchema.index({ name: 'text', description: 'text' }); // Text search index
productSchema.index({ createdAt: -1 }); // For sorting by newest
productSchema.index({ sales: -1 }); // For best selling products

export const Product = mongoose.model<IProduct>('Product', productSchema);


