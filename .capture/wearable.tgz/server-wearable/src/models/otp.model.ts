import mongoose, { Document, Schema } from 'mongoose';

/**
 * OTP document interface
 * Stores one-time passwords for email verification
 */
export interface IOTP extends Document {
  email: string;
  otp: string;
  expiresAt: Date;
  isUsed: boolean;
  createdAt: Date;
}

/**
 * OTP schema definition
 * Stores OTPs with expiration time for customer email verification
 * OTPs expire after 10 minutes and can only be used once
 */
const otpSchema = new Schema<IOTP>(
  {
    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
      index: true,
    },
    otp: {
      type: String,
      required: true,
    },
    expiresAt: {
      type: Date,
      required: true,
    },
    isUsed: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

// Index for faster queries
otpSchema.index({ email: 1, expiresAt: 1 });

// TTL index for automatic cleanup of expired documents (10 minutes)
otpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export const OTP = mongoose.model<IOTP>('OTP', otpSchema);

