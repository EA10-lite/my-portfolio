import cloudinary from '../config/cloudinary';
import { UploadApiResponse, UploadApiErrorResponse } from 'cloudinary';

/**
 * Uploads a single image to Cloudinary
 * @param file - File buffer or path
 * @param folder - Cloudinary folder path (optional)
 * @returns Promise with uploaded image URL and public_id
 */
export const uploadImageToCloudinary = async (
  file: Express.Multer.File,
  folder: string = 'wearable/products'
): Promise<{ url: string; publicId: string }> => {
  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder,
        resource_type: 'image',
        transformation: [
          { width: 1200, height: 1200, crop: 'limit', quality: 'auto' },
          { fetch_format: 'auto' },
        ],
      },
      (error: UploadApiErrorResponse | undefined, result: UploadApiResponse | undefined) => {
        if (error) {
          console.error('Cloudinary upload error:', error);
          reject(new Error(`Failed to upload image: ${error.message}`));
          return;
        }
        if (!result || !result.secure_url) {
          reject(new Error('Failed to upload image: No URL returned'));
          return;
        }
        resolve({
          url: result.secure_url,
          publicId: result.public_id,
        });
      }
    );

    uploadStream.end(file.buffer);
  });
};

/**
 * Uploads multiple images to Cloudinary
 * @param files - Array of file buffers
 * @param folder - Cloudinary folder path (optional)
 * @returns Promise with array of uploaded image URLs and public_ids
 */
export const uploadMultipleImages = async (
  files: Express.Multer.File[],
  folder: string = 'wearable/products'
): Promise<{ url: string; publicId: string }[]> => {
  try {
    const uploadPromises = files.map((file) => uploadImageToCloudinary(file, folder));
    const results = await Promise.all(uploadPromises);
    return results;
  } catch (error) {
    console.error('Error uploading multiple images:', error);
    throw error;
  }
};

/**
 * Deletes an image from Cloudinary
 * @param publicId - Cloudinary public ID of the image
 * @returns Promise that resolves when image is deleted
 */
export const deleteImageFromCloudinary = async (publicId: string): Promise<void> => {
  try {
    await cloudinary.uploader.destroy(publicId);
  } catch (error) {
    console.error('Error deleting image from Cloudinary:', error);
    throw new Error('Failed to delete image from Cloudinary');
  }
};













