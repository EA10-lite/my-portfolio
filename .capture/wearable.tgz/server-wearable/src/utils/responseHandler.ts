import { Response } from 'express';
import { ApiResponse } from '../types/index';
import { AppError } from './AppError';

export const sendSuccess = <T>(
  res: Response<ApiResponse<T>>,
  data: T,
  message: string = 'Success',
  statusCode: number = 200
): void => {
  res.status(statusCode).json({
    success: true,
    message,
    data,
  });
};

export const sendError = (
  res: Response<ApiResponse>,
  message: string,
  statusCode: number = 500,
  error?: string
): void => {
  res.status(statusCode).json({
    success: false,
    message,
    error: error || message,
  });
};

export const handleError = (err: Error | AppError, res: Response<ApiResponse>): void => {
  if (err instanceof AppError) {
    sendError(res, err.message, err.statusCode);
    return;
  }

  console.error('Unexpected error:', err);
  const errorMessage = process.env.NODE_ENV === 'development' 
    ? err.message 
    : 'Internal server error';
  sendError(res, errorMessage, 500);
};
