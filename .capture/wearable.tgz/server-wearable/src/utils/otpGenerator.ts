/**
 * Generates a random 6-digit OTP (One-Time Password)
 * @returns A 6-digit string OTP
 * 
 * @example
 * generateOTP() // "123456"
 */
export const generateOTP = (): string => {
  // Generate a random 6-digit number
  const otp = Math.floor(100000 + Math.random() * 900000);
  return otp.toString();
};

/**
 * Calculates OTP expiration time
 * Default expiration is 10 minutes from now
 * @param minutes - Number of minutes until expiration (default: 10)
 * @returns Date object representing expiration time
 */
export const getOTPExpiration = (minutes: number = 10): Date => {
  const expirationTime = new Date();
  expirationTime.setMinutes(expirationTime.getMinutes() + minutes);
  return expirationTime;
};



















