import nodemailer from 'nodemailer';

/**
 * Creates nodemailer transporter with improved connection settings
 * Includes timeout configurations and better error handling for SMTP connections
 */
const createTransporter = () => {
  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  const port = parseInt(process.env.SMTP_PORT || '587');
  const isSecure = port === 465;

  return nodemailer.createTransport({
    host,
    port,
    secure: isSecure, // true for 465, false for other ports
    auth: {
      user: process.env.SMTP_USER || '',
      pass: process.env.SMTP_PASS || '',
    },
    // Connection timeout settings
    connectionTimeout: 10000, // 10 seconds
    greetingTimeout: 10000, // 10 seconds
    socketTimeout: 10000, // 10 seconds
    // TLS options for secure connections
    tls: {
      rejectUnauthorized: false, // Accept self-signed certificates (set to true in production with valid certs)
      ciphers: 'SSLv3',
    },
    // Pool connections for better performance
    pool: true,
    maxConnections: 1,
    maxMessages: 3,
  });
};

const transporter = createTransporter();

/**
 * Sends OTP email to the user
 * Uses nodemailer with improved error handling and connection management
 * 
 * @param email - Recipient email address
 * @param otp - The OTP code to send
 * @returns Promise that resolves when email is sent
 * @throws Error with descriptive message if email sending fails
 */
export const sendOTPEmail = async (email: string, otp: string): Promise<void> => {
  // Validate SMTP configuration
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.SMTP_HOST) {
    console.warn('⚠️  SMTP not configured. Logging OTP to console instead.');
    console.log(`📧 OTP Email to ${email}: Your verification code is ${otp}`);
    console.log(`⏰ This OTP expires in 10 minutes`);
    return;
  }

  try {
    // Verify transporter connection before sending
    await transporter.verify();

    const mailOptions = {
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: email,
      subject: 'Your Wearable Verification Code',
      text: `Your verification code is ${otp}. This code expires in 10 minutes.`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #333; text-align: center;">Wearable Verification Code</h2>
          <p style="color: #666; font-size: 16px; line-height: 1.6;">
            Hello,
          </p>
          <p style="color: #666; font-size: 16px; line-height: 1.6;">
            Your verification code is:
          </p>
          <div style="background-color: #f5f5f5; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0;">
            <h1 style="color: #667eea; font-size: 32px; letter-spacing: 8px; margin: 0;">${otp}</h1>
          </div>
          <p style="color: #666; font-size: 14px; line-height: 1.6;">
            This code will expire in <strong>10 minutes</strong>. Please do not share this code with anyone.
          </p>
          <p style="color: #999; font-size: 12px; margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px;">
            If you didn't request this code, please ignore this email.
          </p>
        </div>
      `,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ OTP email sent successfully to ${email}. Message ID: ${info.messageId}`);
  } catch (error) {
    console.error('❌ Email sending error:', error);
    
    // Fallback to console logging if email fails (development mode)
    console.log(`📧 OTP Email to ${email}: Your verification code is ${otp}`);
    console.log(`⏰ This OTP expires in 10 minutes`);
    
    // In development, don't throw error - just log and continue
    // In production, you might want to throw to alert monitoring systems
    if (process.env.NODE_ENV === 'production') {
      if (error instanceof Error) {
        // Provide user-friendly error messages for production
        if (error.message.includes('Invalid login') || error.message.includes('authentication') || error.message.includes('535')) {
          throw new Error('SMTP authentication failed. Please check your email credentials (SMTP_USER and SMTP_PASS)');
        }
        if (error.message.includes('ECONNREFUSED') || error.message.includes('ETIMEDOUT') || error.message.includes('ESOCKET')) {
          throw new Error(`Unable to connect to email server (${process.env.SMTP_HOST}:${process.env.SMTP_PORT}). Please check your SMTP configuration and network connection.`);
        }
        if (error.message.includes('ENOTFOUND')) {
          throw new Error(`SMTP host not found: ${process.env.SMTP_HOST}. Please check your SMTP_HOST configuration.`);
        }
        throw new Error(`Failed to send email: ${error.message}`);
      }
      throw new Error('Failed to send email. Please try again later.');
    }
    
    // In development, just log the error and continue (OTP is logged to console)
    console.warn('⚠️  Email sending failed, but OTP has been logged to console for development purposes.');
  }
};

