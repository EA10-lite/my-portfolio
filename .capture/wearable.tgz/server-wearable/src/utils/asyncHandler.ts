/**
 * Async Handler Utility
 * Wraps async route handlers to automatically catch and forward errors
 * This replaces express-async-errors functionality for Express 5.x compatibility
 * 
 * Usage:
 *   app.get('/route', asyncHandler(async (req, res) => {
 *     // Your async code here
 *   }));
 */

import { Request, Response, NextFunction } from 'express';

/**
 * Type definition for async route handlers
 */
type AsyncRequestHandler = (
  req: Request,
  res: Response,
  next: NextFunction
) => Promise<any>;

/**
 * Wraps an async route handler to automatically catch errors
 * Errors are passed to the Express error handling middleware
 * 
 * @param fn - Async route handler function
 * @returns Wrapped handler that catches errors
 */
export const asyncHandler = (fn: AsyncRequestHandler) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};


