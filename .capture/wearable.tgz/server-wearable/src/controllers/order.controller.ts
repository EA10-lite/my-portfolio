import { Request, Response } from 'express';
import { GetOrders } from '../services/Order/GetOrders';
import { GetOrderById } from '../services/Order/GetOrderById';
import { UpdateOrderStatus } from '../services/Order/UpdateOrderStatus';
import { CancelOrder } from '../services/Order/CancelOrder';
import { CreateOrder } from '../services/Order/CreateOrder';

export const createOrder = async (req: Request, res: Response) => {
    try {
        const orderData = req.body;
        // Optionally pass user ID if authenticated
        const customerId = req.user?.userId;

        const result = await CreateOrder(orderData, customerId);

        if (!result.success) {
            return res.status(400).json(result);
        }

        return res.status(201).json(result);
    } catch (error) {
        console.error('Error in createOrder controller:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
}

export const getOrders = async (req: Request, res: Response): Promise<void> => {
    try {
        const { page, limit, orderStatus, paymentStatus } = req.query;

        const result = await GetOrders({
            page: page ? parseInt(page as string) : undefined,
            limit: limit ? parseInt(limit as string) : undefined,
            orderStatus: orderStatus as string,
            paymentStatus: paymentStatus as string,
        });

        if (!result.success) {
            res.status(400).json(result);
            return;
        }

        res.status(200).json(result);
    } catch (error) {
        console.error('Error in getOrders controller:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
}

import { GetMyOrders } from '../services/Order/GetMyOrders';

export const getMyOrders = async (req: Request, res: Response): Promise<void> => {
    try {
        const customerId = req.user?.userId;
        if (!customerId) {
            res.status(401).json({ success: false, message: 'Unauthorized' });
            return;
        }

        const result = await GetMyOrders(customerId);

        if (!result.success) {
            res.status(400).json(result);
            return;
        }

        res.status(200).json(result);
    } catch (error) {
        console.error('Error in getMyOrders controller:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
}

export const getOrderById = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        const result = await GetOrderById(id);

        if (!result.success) {
            res.status(404).json(result);
            return;
        }

        res.status(200).json(result);
    } catch (error) {
        console.error('Error in getOrderById controller:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
}

export const updateOrderById = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const { orderStatus } = req.body as { orderStatus: 'pending' | 'confirmed' | 'processing' | 'packed' | 'assigned' | 'shipped' | 'delivered' };

        const result = await UpdateOrderStatus(id, orderStatus);

        if (!result.success) {
            res.status(400).json(result);
            return;
        }

        res.status(200).json(result);
    } catch (error) {
        console.error('Error in updateOrderById controller:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
}

export const cancelOrderById = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        const { orderStatus } = req.body as { orderStatus: 'cancelled' };

        if (orderStatus !== 'cancelled') {
            res.status(400).json({
                success: false,
                message: 'Invalid order status',
            });
            return;
        }

        const result = await CancelOrder(id);

        if (!result.success) {
            res.status(400).json(result);
            return;
        }

        res.status(200).json(result);
    } catch (error) {
        console.error('Error in cancelOrderById controller:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
}
