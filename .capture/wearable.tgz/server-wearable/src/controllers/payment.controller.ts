import { Request, Response } from 'express';
import { InitializePayment } from '../services/Payment/InitializePayment';
import { VerifyPayment } from '../services/Payment/VerifyPayment';
import { HandleWebhook } from '../services/Payment/HandleWebhook';

export const initializePayment = async (req: Request, res: Response) => {
  try {
    const { orderIds, email, amount, metadata } = req.body;

    if (!orderIds || !Array.isArray(orderIds) || orderIds.length === 0 || !email || !amount) {
      return res.status(400).json({ success: false, message: 'Missing required fields: orderIds, email, amount' });
    }

    const result = await InitializePayment({ orderIds, email, amount, metadata });

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in initializePayment controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const verifyPayment = async (req: Request, res: Response) => {
  try {
    const { reference } = req.params;

    if (!reference) {
      return res.status(400).json({ success: false, message: 'Reference is required' });
    }

    const result = await VerifyPayment(reference);

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in verifyPayment controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const handleWebhook = async (req: Request, res: Response) => {
  try {
    const signature = req.headers['x-paystack-signature'] as string;
    if (!signature) {
      return res.status(401).json({ success: false, message: 'Missing signature' });
    }

    // Pass req.body and signature to the service
    // Note: ensure express.json() is used to parse the body
    const result = await HandleWebhook(req.body, signature);

    if (!result.success) {
      // Rejecting webhook with 401 if unauthorized
      if (result.message === 'Invalid signature') {
        return res.status(401).json(result);
      }
      return res.status(400).json(result);
    }

    // Always return 200 immediately for webhooks
    return res.status(200).send('OK');
  } catch (error) {
    console.error('Error in handleWebhook controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};
