import { Request, Response } from 'express';
import { LoginCustomer } from '../services/Auth/LoginCustomer';
import { LoginAdmin } from '../services/Auth/LoginAdmin';
import { VerifyEmail } from '../services/Auth/VerifyEmail';

/**
 * Controller for customer login
 * POST /api/auth/login/customer
 * 
 * @param req - Express request object
 * @param res - Express response object
 */
export const customerLogin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email } = req.body;

    const result = await LoginCustomer(email);

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in customerLogin controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for admin login
 * POST /api/auth/login/admin
 * 
 * @param req - Express request object
 * @param res - Express response object
 */
export const adminLogin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    const result = await LoginAdmin(email, password);

    if (!result.success) {
      res.status(401).json(result);
      return;
    }

    if (result.refreshToken) {
      res.cookie('refreshToken', result.refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
      
      // Remove refreshToken from response body for security
      delete result.refreshToken;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in adminLogin controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for email verification (OTP)
 * POST /api/auth/verify
 * 
 * @param req - Express request object
 * @param res - Express response object
 */
export const verifyEmailOTP = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, otp } = req.body;

    const result = await VerifyEmail(email, otp);

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    if (result.refreshToken) {
      res.cookie('refreshToken', result.refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
      
      // Remove refreshToken from response body for security
      delete result.refreshToken;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in verifyEmailOTP controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

import jwt from 'jsonwebtoken';
import type { StringValue } from 'ms';

export const refreshToken = async (req: Request, res: Response): Promise<void> => {
  try {
    const rToken = req.cookies.refreshToken;

    if (!rToken) {
      res.status(401).json({ success: false, message: 'No refresh token provided' });
      return;
    }

    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      res.status(500).json({ success: false, message: 'Server configuration error' });
      return;
    }

    jwt.verify(rToken, jwtSecret, (err: any, decoded: any) => {
      if (err) {
        res.status(403).json({ success: false, message: 'Invalid refresh token' });
        return;
      }

      const expiresIn: StringValue | number = '15m';

      const newToken = jwt.sign(
        {
          userId: decoded.userId,
          email: decoded.email,
          role: decoded.role,
        },
        jwtSecret,
        { expiresIn }
      );

      res.status(200).json({
        success: true,
        token: newToken,
      });
      return;
    });
  } catch (error) {
    console.error('Error in refreshToken controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};
