import { Request, Response } from 'express';
import { asyncHandler } from '../utils/asyncHandler';
import { AppError } from '../utils/AppError';
import { ShippingFee } from '../models/shippingFee.model';

export const getShippingFees = asyncHandler(async (_req: Request, res: Response) => {
  const fees = await ShippingFee.find().sort({ createdAt: -1 });
  
  res.status(200).json({
    status: 'success',
    data: fees,
  });
});

export const createShippingFee = asyncHandler(async (req: Request, res: Response) => {
  const { state, lga, fee, isDefault, isActive } = req.body;

  if (!state || fee === undefined) {
    throw new AppError('State and fee are required', 400);
  }

  // Check for duplicates
  const existingFee = await ShippingFee.findOne({ 
    state: new RegExp(`^${state}$`, 'i'), 
    lga: lga ? new RegExp(`^${lga}$`, 'i') : undefined 
  });

  if (existingFee) {
    throw new AppError('A shipping fee for this state and LGA already exists', 400);
  }

  const shippingFee = await ShippingFee.create({
    state,
    lga,
    fee,
    isDefault: isDefault || false,
    isActive: isActive !== undefined ? isActive : true,
  });

  res.status(201).json({
    status: 'success',
    data: shippingFee,
  });
});

export const updateShippingFee = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const updates = req.body;

  const fee = await ShippingFee.findById(id);
  
  if (!fee) {
    throw new AppError('Shipping fee not found', 404);
  }

  // If we are updating to default, we must handle the hook
  if (updates.isDefault === true) {
    fee.isDefault = true;
  } else if (updates.isDefault === false) {
    fee.isDefault = false;
  }
  
  if (updates.state !== undefined) fee.state = updates.state;
  if (updates.lga !== undefined) fee.lga = updates.lga;
  if (updates.fee !== undefined) fee.fee = updates.fee;
  if (updates.isActive !== undefined) fee.isActive = updates.isActive;

  await fee.save();

  res.status(200).json({
    status: 'success',
    data: fee,
  });
});

export const deleteShippingFee = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;

  const fee = await ShippingFee.findByIdAndDelete(id);

  if (!fee) {
    throw new AppError('Shipping fee not found', 404);
  }

  res.status(200).json({
    status: 'success',
    message: 'Shipping fee deleted successfully',
  });
});

export const calculateShippingFee = asyncHandler(async (req: Request, res: Response) => {
  const { state, lga } = req.query;

  if (!state) {
    throw new AppError('State is required to calculate shipping fee', 400);
  }

  // 1. Look for an exact match on both state + lga
  if (lga) {
    const exactMatch = await ShippingFee.findOne({
      state: new RegExp(`^${state}$`, 'i'),
      lga: new RegExp(`^${lga}$`, 'i'),
      isActive: true,
    });

    if (exactMatch) {
      return res.status(200).json({
        status: 'success',
        data: {
          state: exactMatch.state,
          lga: exactMatch.lga,
          fee: exactMatch.fee,
          matchType: 'exact',
        },
      });
    }
  }

  // 2. If no LGA match or lga not provided, fall back to state-only fee
  const stateMatch = await ShippingFee.findOne({
    state: new RegExp(`^${state}$`, 'i'),
    lga: { $exists: false },
    isActive: true,
  });

  // some records might have empty string for lga
  const stateMatchEmptyLga = await ShippingFee.findOne({
    state: new RegExp(`^${state}$`, 'i'),
    $or: [{ lga: null }, { lga: '' }],
    isActive: true,
  });

  const finalStateMatch = stateMatch || stateMatchEmptyLga;

  if (finalStateMatch) {
    return res.status(200).json({
      status: 'success',
      data: {
        state: finalStateMatch.state,
        lga: finalStateMatch.lga,
        fee: finalStateMatch.fee,
        matchType: 'state',
      },
    });
  }

  // 3. If no state match, fall back to the default fee
  const defaultMatch = await ShippingFee.findOne({
    isDefault: true,
    isActive: true,
  });

  if (defaultMatch) {
    return res.status(200).json({
      status: 'success',
      data: {
        state: defaultMatch.state,
        lga: defaultMatch.lga,
        fee: defaultMatch.fee,
        matchType: 'default',
      },
    });
  }

  // 4. If no default exists, return an error
  return res.status(404).json({
    status: 'error',
    message: 'Shipping fee not available for this location',
    data: {
      matchType: 'unavailable'
    }
  });
});
