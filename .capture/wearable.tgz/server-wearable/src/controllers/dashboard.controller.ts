import { Request, Response } from 'express';
import { GetDashboardStats } from '../services/Dashboard/GetDashboardStats';
import { GetSalesData } from '../services/Dashboard/GetSalesData';
import { GetCategoryPerformance } from '../services/Dashboard/GetCategoryPerformance';
import { GetOrdersTrend } from '../services/Dashboard/GetOrdersTrend';

export const getDashboardStats = async (_req: Request, res: Response) => {
  try {
    const result = await GetDashboardStats();
    if (!result.success) return res.status(400).json(result);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in getDashboardStats controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const getSalesData = async (req: Request, res: Response) => {
  try {
    const timeFilter = req.query.timeFilter as string || 'last12months';
    const result = await GetSalesData(timeFilter);
    if (!result.success) return res.status(400).json(result);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in getSalesData controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const getCategoryPerformance = async (_req: Request, res: Response) => {
  try {
    const result = await GetCategoryPerformance();
    if (!result.success) return res.status(400).json(result);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in getCategoryPerformance controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

export const getOrdersTrend = async (_req: Request, res: Response) => {
  try {
    const result = await GetOrdersTrend();
    if (!result.success) return res.status(400).json(result);
    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in getOrdersTrend controller:', error);
    return res.status(500).json({ success: false, message: 'Internal server error' });
  }
};
