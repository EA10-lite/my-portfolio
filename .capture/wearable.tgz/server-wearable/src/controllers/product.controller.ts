import { Request, Response } from 'express';
import { AddProduct } from '../services/Product/AddProduct';
import { EditProduct } from '../services/Product/EditProduct';
import { GetProducts } from '../services/Product/GetProducts';
import { GetProductById } from '../services/Product/GetProductById';
import { DeleteProduct } from '../services/Product/DeleteProduct';
import { AddProductRequest, EditProductRequest } from '../types/services.types';

/**
 * Controller for getting all products
 * GET /api/products
 * Supports query parameters: category, search, page, limit, status
 */
export const getAllProducts = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, subcategory, search, page, limit } = req.query;

    // Customer endpoint - only active products, no sensitive data
    const result = await GetProducts({
      category: category as string,
      subcategory: subcategory as string,
      search: search as string,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: 'active', // Customers only see active products
      isAdmin: false, // Customer view
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getAllProducts controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for getting all products (admin only - includes inactive)
 * GET /api/products/all
 */
export const getAllProductsAdmin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, search, page, limit, status, include } = req.query;

    // Check if stats should be included
    const includeStats = include === 'stats' || include === 'true';

    // Admin endpoint - can see all products with all data
    const result = await GetProducts({
      category: category as string,
      search: search as string,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: status as 'active' | 'inactive' | 'out_of_stock' | undefined, // Admin can see all statuses
      isAdmin: true, // Admin view
      includeStats, // Include stats if requested
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getAllProductsAdmin controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

export const getProductByAdmin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const result = await GetProductById(id);
    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getProductByAdmin controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for getting a single product by ID
 * GET /api/products/:id
 */
export const getProduct = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    // Customer endpoint - no sensitive data, only active products
    const result = await GetProductById(id, false);

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getProduct controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for getting products by category
 * GET /api/products/category/:category
 * Supports query parameter: include=newArrivals,bestSellers
 */
export const getProductsByCategory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category } = req.params;
    const { page, limit, include } = req.query;

    // Parse include parameter to determine what additional data to fetch
    const includeArray = include ? (include as string).split(',') : [];
    const includeNewArrivals = includeArray.includes('newArrivals') || includeArray.includes('new-arrivals');
    const includeBestSellers = includeArray.includes('bestSellers') || includeArray.includes('best-sellers');

    // Customer endpoint - only active products, no sensitive data
    const result = await GetProducts({
      category,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: 'active', // Customers only see active products
      isAdmin: false, // Customer view
      includeNewArrivals,
      includeBestSellers,
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getProductsByCategory controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for getting products by subcategory
 * GET /api/products/subcategory/:subcategory
 * Supports query parameter: include=newArrivals,bestSellers
 */
export const getProductsBySubcategory = async (req: Request, res: Response): Promise<void> => {
  try {
    const { subcategory } = req.params;
    const { category, page, limit, include } = req.query;

    // Parse include parameter to determine what additional data to fetch
    const includeArray = include ? (include as string).split(',') : [];
    const includeNewArrivals = includeArray.includes('newArrivals') || includeArray.includes('new-arrivals');
    const includeBestSellers = includeArray.includes('bestSellers') || includeArray.includes('best-sellers');

    // Customer endpoint - only active products, no sensitive data
    const result = await GetProducts({
      category: category as string,
      subcategory,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: 'active', // Customers only see active products
      isAdmin: false, // Customer view
      includeNewArrivals,
      includeBestSellers,
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getProductsBySubcategory controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for getting best-selling products
 * GET /api/products/best-sellers
 * Returns products sorted by sales count (descending)
 */
export const getBestSellers = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, page, limit } = req.query;

    // Customer endpoint - only active products, no sensitive data
    const result = await GetProducts({
      category: category as string,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: 'active', // Customers only see active products
      isAdmin: false, // Customer view
      sortBy: 'sales', // Sort by sales count
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getBestSellers controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for getting new arrival products
 * GET /api/products/new-arrivals
 * Returns products sorted by creation date (newest first)
 */
export const getNewArrivals = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, page, limit } = req.query;

    // Customer endpoint - only active products, no sensitive data
    const result = await GetProducts({
      category: category as string,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: 'active', // Customers only see active products
      isAdmin: false, // Customer view
      sortBy: 'newest', // Sort by creation date
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in getNewArrivals controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for searching products
 * GET /api/products/search/:search
 */
export const searchProducts = async (req: Request, res: Response): Promise<void> => {
  try {
    const { search } = req.params;
    const { page, limit } = req.query;

    // Customer endpoint - only active products, no sensitive data
    const result = await GetProducts({
      search,
      page: page ? parseInt(page as string) : undefined,
      limit: limit ? parseInt(limit as string) : undefined,
      status: 'active', // Customers only see active products
      isAdmin: false, // Customer view
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in searchProducts controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for adding a new product
 * POST /api/products
 * Requires: multipart/form-data with product data and images
 */
export const createProduct = async (req: Request, res: Response): Promise<void> => {
  try {
    // Extract product data from request body (already validated and parsed)
    const productData: AddProductRequest = {
      name: req.body.name,
      description: req.body.description,
      category: req.body.category,
      colors: req.body.colors,
      sizes: req.body.sizes,
      variants: req.body.variants,
      price: req.body.price,
      discountPrice: req.body.discountPrice,
      samePriceForAllSizes: req.body.samePriceForAllSizes,
      variantsPrice: req.body.variantsPrice,
      stock: req.body.stock,
    };

    // Get uploaded images
    const imageFiles = req.files as Express.Multer.File[];

    const result = await AddProduct(productData, imageFiles);

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(201).json(result);
  } catch (error) {
    console.error('Error in createProduct controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for updating a product
 * PUT /api/products/:id
 * Requires: multipart/form-data with product data and optionally new images
 */
export const updateProduct = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    // Extract product data from request body (already validated and parsed)
    const productData: EditProductRequest = {};
    
    if (req.body.name !== undefined) productData.name = req.body.name;
    if (req.body.description !== undefined) productData.description = req.body.description;
    if (req.body.category !== undefined) productData.category = req.body.category;
    if (req.body.colors !== undefined) productData.colors = req.body.colors;
    if (req.body.sizes !== undefined) productData.sizes = req.body.sizes;
    if (req.body.variants !== undefined) productData.variants = req.body.variants;
    if (req.body.price !== undefined) productData.price = req.body.price;
    if (req.body.discountPrice !== undefined) productData.discountPrice = req.body.discountPrice;
    if (req.body.samePriceForAllSizes !== undefined) productData.samePriceForAllSizes = req.body.samePriceForAllSizes;
    if (req.body.variantsPrice !== undefined) productData.variantsPrice = req.body.variantsPrice;
    if (req.body.stock !== undefined) productData.stock = req.body.stock;

    // Get new images if uploaded
    const newImageFiles = req.files as Express.Multer.File[] | undefined;
    
    // Get images to keep (if provided, already parsed by middleware)
    const imagesToKeep = req.body.imagesToKeep;

    const result = await EditProduct(id, productData, newImageFiles, imagesToKeep);

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in updateProduct controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller for deleting a product
 * DELETE /api/products/:id
 */
export const removeProduct = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const result = await DeleteProduct(id);

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (error) {
    console.error('Error in removeProduct controller:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

