import { Request, Response } from 'express';
import { GetCustomers } from '../services/Customer/GetCustomers';
import { GetCustomerById } from '../services/Customer/GetCustomerById';
import { BlockCustomer } from '../services/Customer/BlockCustomer';

/**
 * Controller to get all customers with pagination, search and filters
 */
export const getCustomers = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const search = req.query.search as string | undefined;
    const status = req.query.status as 'active' | 'blocked' | 'all' | undefined;

    const result = await GetCustomers({ page, limit, search, status });

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in getCustomers controller:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller to get a single customer by ID with their order history
 */
export const getCustomerById = async (req: Request, res: Response) => {
  try {
    const customerId = req.params.id;

    if (!customerId) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID is required',
      });
    }

    const result = await GetCustomerById(customerId);

    if (!result.success) {
      return res.status(result.message === 'Customer not found' ? 404 : 400).json(result);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in getCustomerById controller:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};

/**
 * Controller to block or unblock a customer
 */
export const blockCustomer = async (req: Request, res: Response) => {
  try {
    const customerId = req.params.id;
    const { block } = req.body;

    if (!customerId) {
      return res.status(400).json({
        success: false,
        message: 'Customer ID is required',
      });
    }

    if (typeof block !== 'boolean') {
      return res.status(400).json({
        success: false,
        message: 'Block status (boolean) is required in request body',
      });
    }

    const result = await BlockCustomer(customerId, block);

    if (!result.success) {
      return res.status(result.message === 'Customer not found' ? 404 : 400).json(result);
    }

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error in blockCustomer controller:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};
