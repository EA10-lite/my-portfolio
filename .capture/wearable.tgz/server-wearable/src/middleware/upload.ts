import multer from 'multer';
import { Request } from 'express';

/**
 * Multer configuration for file uploads
 * Stores files in memory as buffers for Cloudinary upload
 */
const storage = multer.memoryStorage();

/**
 * File filter to only accept image files
 */
const fileFilter = (
  _req: Request,
  file: Express.Multer.File,
  cb: multer.FileFilterCallback
): void => {
  // Accept only image files
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed'));
  }
};

/**
 * Multer upload middleware for product images
 * - Accepts multiple files (up to 10)
 * - Max file size: 5MB per file
 * - Only accepts image files
 */
export const uploadProductImages = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB per file
    files: 10, // Maximum 10 images per product
  },
  fileFilter,
});





