import { Request, Response, NextFunction } from 'express';
import { Schema } from 'joi';

/**
 * Validation middleware factory
 * Creates a middleware function that validates request data against a Joi schema
 * 
 * @param schema - Joi schema to validate against
 * @param source - Where to validate data from ('body', 'query', 'params')
 * @returns Express middleware function
 */
export const validate = (
  schema: Schema,
  source: 'body' | 'query' | 'params' = 'body'
) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const { error, value } = schema.validate(req[source], {
      abortEarly: false, // Return all validation errors, not just the first one
      stripUnknown: true, // Remove unknown fields
    });

    if (error) {
      const errors = error.details.map((detail) => ({
        field: detail.path.join('.'),
        message: detail.message,
      }));

      res.status(400).json({
        success: false,
        message: 'Validation error',
        errors,
      });
      return;
    }

    // Replace request data with validated and sanitized data
    req[source] = value;
    next();
  };
};





