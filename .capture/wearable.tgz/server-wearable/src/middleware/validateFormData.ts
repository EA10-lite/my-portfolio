import { Request, Response, NextFunction } from 'express';
import { Schema } from 'joi';

/**
 * Validation middleware for multipart/form-data
 * Parses string values from form-data and validates them
 * 
 * @param schema - Joi schema to validate against
 * @returns Express middleware function
 */
export const validateFormData = (schema: Schema) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    // For multipart/form-data, all values come as strings
    // We need to parse them before validation
    const dataToValidate: any = { ...req.body };

    // Parse JSON strings to objects/arrays
    if (dataToValidate.colors && typeof dataToValidate.colors === 'string') {
      try {
        dataToValidate.colors = JSON.parse(dataToValidate.colors);
      } catch {
        // Keep as string if parsing fails, validation will catch it
      }
    }
    if (dataToValidate.sizes && typeof dataToValidate.sizes === 'string') {
      try {
        dataToValidate.sizes = JSON.parse(dataToValidate.sizes);
      } catch {
        // Keep as string if parsing fails
      }
    }
    if (dataToValidate.variants && typeof dataToValidate.variants === 'string') {
      try {
        dataToValidate.variants = JSON.parse(dataToValidate.variants);
      } catch {
        // Keep as string if parsing fails
      }
    }
    if (dataToValidate.variantsPrice && typeof dataToValidate.variantsPrice === 'string') {
      try {
        dataToValidate.variantsPrice = JSON.parse(dataToValidate.variantsPrice);
      } catch {
        // Keep as string if parsing fails
      }
    }
    if (dataToValidate.imagesToKeep && typeof dataToValidate.imagesToKeep === 'string') {
      try {
        dataToValidate.imagesToKeep = JSON.parse(dataToValidate.imagesToKeep);
      } catch {
        // Keep as string if parsing fails
      }
    }

    // Parse numbers and booleans
    if (dataToValidate.price) dataToValidate.price = parseFloat(dataToValidate.price);
    if (dataToValidate.discountPrice) dataToValidate.discountPrice = parseFloat(dataToValidate.discountPrice);
    if (dataToValidate.stock) dataToValidate.stock = parseInt(dataToValidate.stock);
    if (dataToValidate.samePriceForAllSizes) {
      dataToValidate.samePriceForAllSizes = dataToValidate.samePriceForAllSizes === 'true';
    }

    const { error, value } = schema.validate(dataToValidate, {
      abortEarly: false,
      stripUnknown: true,
    });

    if (error) {
      const errors = error.details.map((detail) => ({
        field: detail.path.join('.'),
        message: detail.message,
      }));

      res.status(400).json({
        success: false,
        message: 'Validation error',
        errors,
      });
      return;
    }

    // Replace request body with validated and parsed data
    req.body = value;
    next();
  };
};





