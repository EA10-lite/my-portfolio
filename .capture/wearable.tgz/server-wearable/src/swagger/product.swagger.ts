/**
 * @swagger
 * components:
 *   schemas:
 *     ProductImage:
 *       type: object
 *       properties:
 *         url:
 *           type: string
 *           format: uri
 *           description: URL of the product image
 *           example: https://res.cloudinary.com/example/image/upload/v1234567890/product.jpg
 *         publicId:
 *           type: string
 *           description: Cloudinary public ID for the image
 *           example: wearable/products/abc123
 *     CustomerProduct:
 *       type: object
 *       description: Product response for customers (public data only, excludes sensitive information)
 *       properties:
 *         id:
 *           type: string
 *           description: Product ID
 *           example: 507f1f77bcf86cd799439011
 *         name:
 *           type: string
 *           description: Product name
 *           example: Classic Cotton T-Shirt
 *         description:
 *           type: string
 *           description: Product description
 *           example: A comfortable and stylish cotton t-shirt perfect for everyday wear
 *         category:
 *           type: string
 *           description: Product category
 *           example: t-shirts
 *         colors:
 *           type: array
 *           items:
 *             type: string
 *           description: Available colors
 *           example: ["black", "white", "navy"]
 *         sizes:
 *           type: array
 *           items:
 *             type: string
 *           description: Available sizes
 *           example: ["S", "M", "L", "XL"]
 *         variants:
 *           type: array
 *           items:
 *             type: string
 *           description: Product variants
 *           example: ["regular", "slim fit"]
 *         price:
 *           type: number
 *           description: Product price
 *           example: 29.99
 *         discountPrice:
 *           type: number
 *           description: Discounted price
 *           example: 24.99
 *         samePriceForAllSizes:
 *           type: boolean
 *           description: Whether all sizes have the same price
 *           example: true
 *         variantsPrice:
 *           type: array
 *           items:
 *             type: number
 *           description: Prices for each variant
 *           example: [29.99, 32.99]
 *         stock:
 *           type: number
 *           description: Available stock quantity
 *           example: 100
 *         images:
 *           type: array
 *           items:
 *             type: string
 *             format: uri
 *           description: Product image URLs (no Cloudinary publicIds)
 *           example: ["https://res.cloudinary.com/example/image/upload/v1234567890/product.jpg"]
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Product creation date
 *           example: 2024-01-15T10:30:00.000Z
 *     Product:
 *       type: object
 *       description: Product response for admins (includes all data including sensitive information)
 *       properties:
 *         id:
 *           type: string
 *           description: Product ID
 *           example: 507f1f77bcf86cd799439011
 *         name:
 *           type: string
 *           description: Product name
 *           example: Classic Cotton T-Shirt
 *         description:
 *           type: string
 *           description: Product description
 *           example: A comfortable and stylish cotton t-shirt perfect for everyday wear
 *         category:
 *           type: string
 *           description: Product category
 *           example: t-shirts
 *         colors:
 *           type: array
 *           items:
 *             type: string
 *           description: Available colors
 *           example: ["black", "white", "navy"]
 *         sizes:
 *           type: array
 *           items:
 *             type: string
 *           description: Available sizes
 *           example: ["S", "M", "L", "XL"]
 *         variants:
 *           type: array
 *           items:
 *             type: string
 *           description: Product variants
 *           example: ["regular", "slim fit"]
 *         price:
 *           type: number
 *           description: Product price
 *           example: 29.99
 *         discountPrice:
 *           type: number
 *           description: Discounted price
 *           example: 24.99
 *         samePriceForAllSizes:
 *           type: boolean
 *           description: Whether all sizes have the same price
 *           example: true
 *         variantsPrice:
 *           type: array
 *           items:
 *             type: number
 *           description: Prices for each variant
 *           example: [29.99, 32.99]
 *         stock:
 *           type: number
 *           description: Available stock quantity
 *           example: 100
 *         images:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ProductImage'
 *           description: Product images with Cloudinary publicIds
 *         sales:
 *           type: number
 *           description: Total number of sales (admin only)
 *           example: 45
 *         status:
 *           type: string
 *           enum: [active, inactive, out_of_stock]
 *           description: Product status (admin only)
 *           example: active
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Product creation date
 *           example: 2024-01-15T10:30:00.000Z
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: Product last update date (admin only)
 *           example: 2024-01-20T14:45:00.000Z
 *     AddProductRequest:
 *       type: object
 *       required:
 *         - name
 *         - category
 *         - colors
 *         - sizes
 *         - variants
 *         - price
 *         - discountPrice
 *         - samePriceForAllSizes
 *         - variantsPrice
 *         - stock
 *       properties:
 *         name:
 *           type: string
 *           description: Product name
 *           example: Classic Cotton T-Shirt
 *         description:
 *           type: string
 *           description: Product description
 *           example: A comfortable and stylish cotton t-shirt
 *         category:
 *           type: string
 *           description: Product category
 *           example: t-shirts
 *         colors:
 *           type: array
 *           items:
 *             type: string
 *           description: Available colors (JSON string in form-data)
 *           example: ["black", "white"]
 *         sizes:
 *           type: array
 *           items:
 *             type: string
 *           description: Available sizes (JSON string in form-data)
 *           example: ["S", "M", "L"]
 *         variants:
 *           type: array
 *           items:
 *             type: string
 *           description: Product variants (JSON string in form-data)
 *           example: ["regular"]
 *         price:
 *           type: number
 *           description: Product price
 *           example: 29.99
 *         discountPrice:
 *           type: number
 *           description: Discounted price
 *           example: 24.99
 *         samePriceForAllSizes:
 *           type: boolean
 *           description: Whether all sizes have the same price
 *           example: true
 *         variantsPrice:
 *           type: array
 *           items:
 *             type: number
 *           description: Prices for each variant (JSON string in form-data)
 *           example: [29.99]
 *         stock:
 *           type: number
 *           description: Available stock quantity
 *           example: 100
 *         images:
 *           type: array
 *           items:
 *             type: string
 *             format: binary
 *           description: Product images (multipart/form-data files)
 *     CustomerProductListResponse:
 *       type: object
 *       description: Response for customer product list (public endpoints)
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Products retrieved successfully
 *         products:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/CustomerProduct'
 *         pagination:
 *           type: object
 *           properties:
 *             page:
 *               type: number
 *               example: 1
 *             limit:
 *               type: number
 *               example: 20
 *             total:
 *               type: number
 *               example: 150
 *             pages:
 *               type: number
 *               example: 8
 *     ProductListResponse:
 *       type: object
 *       description: Response for admin product list (includes all data)
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Products retrieved successfully
 *         products:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/Product'
 *         pagination:
 *           type: object
 *           properties:
 *             page:
 *               type: number
 *               example: 1
 *             limit:
 *               type: number
 *               example: 20
 *             total:
 *               type: number
 *               example: 150
 *             pages:
 *               type: number
 *               example: 8
 *     CustomerProductResponse:
 *       type: object
 *       description: Response for single customer product (public endpoint)
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Product retrieved successfully
 *         product:
 *           $ref: '#/components/schemas/CustomerProduct'
 *     ProductResponse:
 *       type: object
 *       description: Response for admin product operations (includes all data)
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Product created successfully
 *         product:
 *           $ref: '#/components/schemas/Product'
 * 
 * tags:
 *   - name: Products
 *     description: Product management endpoints for clothing items
 */

/**
 * @swagger
 * /api/products:
 *   get:
 *     summary: Get all products (Customer view)
 *     description: |
 *       Retrieves a paginated list of active products.
 *       Supports filtering by category and search queries.
 *       Public endpoint - no authentication required.
 *       Returns customer-friendly data (excludes sales, status, and Cloudinary publicIds).
 *     tags: [Products]
 *     parameters:
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *         description: Filter by product category
 *         example: t-shirts
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search products by name or description
 *         example: cotton
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number for pagination
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Number of products per page
 *     responses:
 *       200:
 *         description: Products retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ProductListResponse'
 *       400:
 *         description: Invalid query parameters
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products/{id}:
 *   get:
 *     summary: Get product by ID (Customer view)
 *     description: |
 *       Retrieves a single product by its ID.
 *       Public endpoint - no authentication required.
 *       Returns customer-friendly data (excludes sales, status, and Cloudinary publicIds).
 *       Only returns active products to customers.
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Product ID
 *         example: 507f1f77bcf86cd799439011
 *     responses:
 *       200:
 *         description: Product retrieved successfully (customer view - excludes sensitive data)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CustomerProductResponse'
 *       404:
 *         description: Product not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: Product not found
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products/category/{category}:
 *   get:
 *     summary: Get products by category (Customer view)
 *     description: |
 *       Retrieves products filtered by category.
 *       Public endpoint - no authentication required.
 *       Returns customer-friendly data (excludes sales, status, and Cloudinary publicIds).
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: category
 *         required: true
 *         schema:
 *           type: string
 *         description: Product category
 *         example: t-shirts
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number for pagination
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Number of products per page
 *     responses:
 *       200:
 *         description: Products retrieved successfully (customer view - excludes sensitive data)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CustomerProductListResponse'
 *       400:
 *         description: Invalid query parameters
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products/search/{search}:
 *   get:
 *     summary: Search products (Customer view)
 *     description: |
 *       Searches products by name or description.
 *       Public endpoint - no authentication required.
 *       Returns customer-friendly data (excludes sales, status, and Cloudinary publicIds).
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: search
 *         required: true
 *         schema:
 *           type: string
 *         description: Search query
 *         example: cotton shirt
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number for pagination
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Number of products per page
 *     responses:
 *       200:
 *         description: Products retrieved successfully (customer view - excludes sensitive data)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CustomerProductListResponse'
 *       400:
 *         description: Invalid query parameters
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products/all:
 *   get:
 *     summary: Get all products (Admin only)
 *     description: |
 *       Retrieves all products including inactive ones.
 *       Admin authentication required.
 *       Returns full product data including sales, status, and Cloudinary publicIds.
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *         description: Filter by product category
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search products by name or description
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [active, inactive, out_of_stock]
 *         description: Filter by product status
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number for pagination
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Number of products per page
 *     responses:
 *       200:
 *         description: Products retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ProductListResponse'
 *       401:
 *         description: Unauthorized - Admin authentication required
 *       403:
 *         description: Forbidden - Admin privileges required
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products:
 *   post:
 *     summary: Create a new product (Admin only)
 *     description: |
 *       Creates a new product with images.
 *       Images are uploaded to Cloudinary and URLs are stored in the database.
 *       Requires multipart/form-data format.
 *       Admin authentication required.
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - category
 *               - colors
 *               - sizes
 *               - variants
 *               - price
 *               - discountPrice
 *               - samePriceForAllSizes
 *               - variantsPrice
 *               - stock
 *               - images
 *             properties:
 *               name:
 *                 type: string
 *                 example: Classic Cotton T-Shirt
 *               description:
 *                 type: string
 *                 example: A comfortable and stylish cotton t-shirt
 *               category:
 *                 type: string
 *                 example: t-shirts
 *               colors:
 *                 type: string
 *                 description: JSON array string
 *                 example: '["black", "white", "navy"]'
 *               sizes:
 *                 type: string
 *                 description: JSON array string
 *                 example: '["S", "M", "L", "XL"]'
 *               variants:
 *                 type: string
 *                 description: JSON array string
 *                 example: '["regular", "slim fit"]'
 *               price:
 *                 type: number
 *                 example: 29.99
 *               discountPrice:
 *                 type: number
 *                 example: 24.99
 *               samePriceForAllSizes:
 *                 type: string
 *                 enum: ["true", "false"]
 *                 example: "true"
 *               variantsPrice:
 *                 type: string
 *                 description: JSON array string
 *                 example: '[29.99, 32.99]'
 *               stock:
 *                 type: number
 *                 example: 100
 *               images:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *                 description: Product images (max 10 files, 5MB each)
 *           encoding:
 *             images:
 *               contentType: image/jpeg, image/png, image/webp
 *     responses:
 *       201:
 *         description: Product created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ProductResponse'
 *       400:
 *         description: Validation error or missing required fields
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: false
 *                 message:
 *                   type: string
 *                   example: Validation error
 *                 errors:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       field:
 *                         type: string
 *                       message:
 *                         type: string
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin privileges required
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products/{id}:
 *   put:
 *     summary: Update a product (Admin only)
 *     description: |
 *       Updates an existing product.
 *       Can update product data and/or images.
 *       New images can be uploaded, and old images can be kept or deleted.
 *       Requires multipart/form-data format.
 *       Admin authentication required.
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Product ID
 *         example: 507f1f77bcf86cd799439011
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: Classic Cotton T-Shirt
 *               description:
 *                 type: string
 *                 example: Updated description
 *               category:
 *                 type: string
 *                 example: t-shirts
 *               colors:
 *                 type: string
 *                 description: JSON array string
 *                 example: '["black", "white"]'
 *               sizes:
 *                 type: string
 *                 description: JSON array string
 *                 example: '["S", "M", "L"]'
 *               variants:
 *                 type: string
 *                 description: JSON array string
 *                 example: '["regular"]'
 *               price:
 *                 type: number
 *                 example: 29.99
 *               discountPrice:
 *                 type: number
 *                 example: 24.99
 *               samePriceForAllSizes:
 *                 type: string
 *                 enum: ["true", "false"]
 *                 example: "true"
 *               variantsPrice:
 *                 type: string
 *                 description: JSON array string
 *                 example: '[29.99]'
 *               stock:
 *                 type: number
 *                 example: 150
 *               images:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *                 description: New images to add (optional)
 *               imagesToKeep:
 *                 type: string
 *                 description: JSON array of publicIds to keep (optional)
 *                 example: '["wearable/products/img1", "wearable/products/img2"]'
 *           encoding:
 *             images:
 *               contentType: image/jpeg, image/png, image/webp
 *     responses:
 *       200:
 *         description: Product updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ProductResponse'
 *       400:
 *         description: Validation error or invalid data
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin privileges required
 *       404:
 *         description: Product not found
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/products/{id}:
 *   delete:
 *     summary: Delete a product (Admin only)
 *     description: |
 *       Deletes a product and removes associated images from Cloudinary.
 *       Admin authentication required.
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Product ID
 *         example: 507f1f77bcf86cd799439011
 *     responses:
 *       200:
 *         description: Product deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Product deleted successfully
 *       401:
 *         description: Unauthorized - Authentication required
 *       403:
 *         description: Forbidden - Admin privileges required
 *       404:
 *         description: Product not found
 *       500:
 *         description: Internal server error
 */

