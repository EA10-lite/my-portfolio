/**
 * @swagger
 * components:
 *   schemas:
 *     OrderRequest:
 *       type: object
 *       required:
 *         - customerName
 *         - customerEmail
 *         - customerPhone
 *         - productId
 *         - quantity
 *         - price
 *         - deliveryAddress
 *         - paymentMethod
 *       properties:
 *         customerName:
 *           type: string
 *           description: Customer full name
 *           example: John Doe
 *         customerEmail:
 *           type: string
 *           format: email
 *           description: Customer email address
 *           example: john.doe@example.com
 *         customerPhone:
 *           type: string
 *           description: Customer phone number
 *           example: "+1234567890"
 *         productId:
 *           type: string
 *           description: Product ID
 *           example: 507f1f77bcf86cd799439011
 *         quantity:
 *           type: number
 *           minimum: 1
 *           description: Quantity of items ordered
 *           example: 2
 *         price:
 *           type: number
 *           minimum: 0
 *           description: Price per unit at time of order
 *           example: 29.99
 *         variants:
 *           type: array
 *           items:
 *             type: string
 *           description: Product variants selected
 *           example: ["regular", "slim fit"]
 *         colors:
 *           type: array
 *           items:
 *             type: string
 *           description: Product colors selected
 *           example: ["black", "white"]
 *         sizes:
 *           type: array
 *           items:
 *             type: string
 *           description: Product sizes selected
 *           example: ["M", "L"]
 *         deliveryAddress:
 *           type: string
 *           description: Delivery address
 *           example: "123 Main St, Anytown, USA"
 *         paymentMethod:
 *           type: string
 *           description: Payment method used
 *           example: "Credit Card"
 *         paymentReference:
 *           type: string
 *           description: Payment reference number (optional)
 *           example: "PAY-1234567890"
 *     UpdateOrderStatusRequest:
 *       type: object
 *       required:
 *         - orderStatus
 *       properties:
 *         orderStatus:
 *           type: string
 *           enum: [pending, processing, packed, assigned, shipped, delivered, cancelled]
 *           description: New order status
 *           example: shipped
 *     OrderProduct:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: 507f1f77bcf86cd799439011
 *         name:
 *           type: string
 *           example: Classic Cotton T-Shirt
 *         description:
 *           type: string
 *           example: A comfortable and stylish cotton t-shirt
 *         images:
 *           type: array
 *           items:
 *             type: string
 *             format: uri
 *           example: ["https://res.cloudinary.com/example/image/upload/v1234567890/product.jpg"]
 *         category:
 *           type: string
 *           example: t-shirts
 *         price:
 *           type: number
 *           example: 29.99
 *     Order:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: Order ID
 *           example: 507f1f77bcf86cd799439011
 *         customerId:
 *           type: string
 *           nullable: true
 *           description: Customer ID if customer exists in system
 *           example: 507f1f77bcf86cd799439012
 *         customerName:
 *           type: string
 *           description: Customer name
 *           example: John Doe
 *         customerEmail:
 *           type: string
 *           format: email
 *           description: Customer email
 *           example: john.doe@example.com
 *         customerPhone:
 *           type: string
 *           description: Customer phone
 *           example: "+1234567890"
 *         product:
 *           $ref: '#/components/schemas/OrderProduct'
 *         quantity:
 *           type: number
 *           example: 2
 *         price:
 *           type: number
 *           example: 29.99
 *         total:
 *           type: number
 *           example: 59.98
 *         variants:
 *           type: array
 *           items:
 *             type: string
 *           example: ["regular"]
 *         colors:
 *           type: array
 *           items:
 *             type: string
 *           example: ["black"]
 *         sizes:
 *           type: array
 *           items:
 *             type: string
 *           example: ["M"]
 *         deliveryAddress:
 *           type: string
 *           example: "123 Main St, Anytown, USA"
 *         paymentMethod:
 *           type: string
 *           example: "Credit Card"
 *         paymentStatus:
 *           type: string
 *           enum: [pending, paid, failed, refunded]
 *           example: paid
 *         paymentReference:
 *           type: string
 *           example: "PAY-1234567890"
 *         orderStatus:
 *           type: string
 *           enum: [pending, processing, packed, assigned, shipped, delivered, cancelled]
 *           example: shipped
 *         paymentConfirmedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2024-01-15T10:30:00.000Z"
 *         packedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2024-01-15T11:00:00.000Z"
 *         assignedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2024-01-15T12:00:00.000Z"
 *         shippedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2024-01-16T09:00:00.000Z"
 *         deliveredAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: "2024-01-17T14:30:00.000Z"
 *         cancelledAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: null
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-15T10:00:00.000Z"
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           example: "2024-01-17T14:30:00.000Z"
 *     OrderListResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Orders retrieved successfully
 *         orders:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/Order'
 *         pagination:
 *           type: object
 *           properties:
 *             page:
 *               type: number
 *               example: 1
 *             limit:
 *               type: number
 *               example: 20
 *             total:
 *               type: number
 *               example: 150
 *             pages:
 *               type: number
 *               example: 8
 *     OrderResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Order retrieved successfully
 *         order:
 *           $ref: '#/components/schemas/Order'
 *     OrderStatusUpdateResponse:
 *       type: object
 *       properties:
 *         success:
 *           type: boolean
 *           example: true
 *         message:
 *           type: string
 *           example: Order status updated successfully
 *         order:
 *           $ref: '#/components/schemas/Order'
 * 
 * tags:
 *   - name: Orders
 *     description: Order management endpoints
 */

/**
 * @swagger
 * /api/orders:
 *   get:
 *     summary: Get all orders (Admin only)
 *     description: Retrieves a paginated list of orders with optional filtering by status
 *     tags: [Orders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 20
 *         description: Number of orders per page
 *       - in: query
 *         name: orderStatus
 *         schema:
 *           type: string
 *           enum: [pending, processing, packed, assigned, shipped, delivered, cancelled]
 *         description: Filter by order status
 *       - in: query
 *         name: paymentStatus
 *         schema:
 *           type: string
 *           enum: [pending, paid, failed, refunded]
 *         description: Filter by payment status
 *     responses:
 *       200:
 *         description: Orders retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/OrderListResponse'
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 *   post:
 *     summary: Create a new order
 *     description: Creates a new order. Customer does not need to be logged in. Backend will check if customer exists and map accordingly.
 *     tags: [Orders]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/OrderRequest'
 *     responses:
 *       201:
 *         description: Order created successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/OrderResponse'
 *       400:
 *         description: Validation error or invalid request
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/orders/{id}:
 *   get:
 *     summary: Get order by ID (Admin only)
 *     description: Retrieves a single order by its ID
 *     tags: [Orders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Order ID
 *     responses:
 *       200:
 *         description: Order retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/OrderResponse'
 *       404:
 *         description: Order not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 *   put:
 *     summary: Update order status (Admin only)
 *     description: Updates the status of an order. Automatically sets the corresponding date field when status changes.
 *     tags: [Orders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Order ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateOrderStatusRequest'
 *     responses:
 *       200:
 *         description: Order status updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/OrderStatusUpdateResponse'
 *       400:
 *         description: Validation error or invalid request
 *       404:
 *         description: Order not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /api/orders/{id}/cancel:
 *   put:
 *     summary: Cancel an order (Admin only)
 *     description: Cancels an order and sets the cancelledAt timestamp
 *     tags: [Orders]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Order ID
 *     responses:
 *       200:
 *         description: Order cancelled successfully
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/OrderStatusUpdateResponse'
 *       400:
 *         description: Order cannot be cancelled or order not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
