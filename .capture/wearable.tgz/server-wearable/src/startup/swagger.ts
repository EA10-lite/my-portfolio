import swaggerJsdoc from 'swagger-jsdoc';
import { Application, Request, Response } from 'express';
import path from 'path';

/**
 * Swagger/OpenAPI Configuration
 * Generates API documentation from JSDoc comments in route files
 */
const options: swaggerJsdoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Wearable E-commerce API',
      version: '1.0.0',
      description: 'API documentation for Wearable E-commerce API',
      contact: {
        name: 'Emmanuel Chris',
        email: 'emanuelanyigor@gmail.com',
        url: 'https://ea10.vercel.app/'
      },
    },
    servers: [
      {
        url: process.env.PRODUCTION_URL ? `${process.env.PRODUCTION_URL}/` : `http://localhost:${process.env.PORT || 3000}/`,
        description: process.env.PRODUCTION_URL ? 'Production server' : 'Development server'
      },
      {
        url: 'http://localhost:3000/',
        description: 'Development server (default)'
      }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
    paths: {},
  },
  // Use paths that work in both development and production
  // Try multiple path patterns to ensure files are found
  apis: [
    // Development (TypeScript)
    './src/routes/*.{ts,js}',
    './src/swagger/*.{ts,js}',
  
    // Production (compiled JS in dist)
    path.join(process.cwd(), 'dist/routes/*.{js}'),
    path.join(process.cwd(), 'dist/swagger/*.{js}'),
  
    // Backup
    path.join(__dirname, '../routes/*.{js}'),
    path.join(__dirname, '../swagger/*.{js}'),
  ],
};

const specs = swaggerJsdoc(options) as {
  paths?: Record<string, unknown>;
  components?: Record<string, unknown>;
  [key: string]: unknown;
};

// Debug: Log if specs are being generated (remove in production)
if (process.env.NODE_ENV === 'development') {
  console.log('Swagger specs generated:', {
    pathsCount: Object.keys(specs.paths || {}).length,
    componentsCount: Object.keys(specs.components || {}).length,
    apis: options.apis,
  });
}

/**
 * Setup Swagger UI for API documentation
 * @param app - Express Application instance
 * 
 * Note: Uses custom HTML template with CDN assets for serverless compatibility (Vercel, etc.)
 */
export const swagger = (app: Application): void => {
  // Custom HTML template that loads Swagger UI from CDN
  // This works better in serverless environments where static files aren't accessible
  const customHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Wearable E-commerce API Documentation</title>
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.10.5/swagger-ui.min.css" />
      <style>
        .swagger-ui .topbar { display: none; }
      </style>
    </head>
    <body>
      <div id="swagger-ui"></div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.10.5/swagger-ui-bundle.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/swagger-ui/5.10.5/swagger-ui-standalone-preset.min.js"></script>
      <script>
        window.onload = function() {
          const spec = ${JSON.stringify(specs)};
          SwaggerUIBundle({
            spec: spec,
            dom_id: '#swagger-ui',
            deepLinking: true,
            presets: [
              SwaggerUIBundle.presets.apis,
              SwaggerUIStandalonePreset
            ],
            plugins: [
              SwaggerUIBundle.plugins.DownloadUrl
            ],
            layout: "StandaloneLayout"
          });
        };
      </script>
    </body>
    </html>
  `;

  app.get('/api-docs', (_req: Request, res: Response) => {
    res.send(customHtml);
  });
};

