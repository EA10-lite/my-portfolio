import { Application } from 'express';
import authRoutes from '../routes/auth.route';
import productRoutes from '../routes/product.route';
import orderRoutes from '../routes/order.route';
import customerRoutes from '../routes/customer.route';
import dashboardRoutes from '../routes/dashboard.route';
import paymentRoutes from '../routes/payment.route';
import shippingFeeRoutes from '../routes/shippingFee.route';

export const routes = (app: Application): void => {
  app.use('/api/auth', authRoutes);
  app.use('/api/products', productRoutes);
  app.use('/api/orders', orderRoutes);
  app.use('/api/customers', customerRoutes);
  app.use('/api/dashboard', dashboardRoutes);
  app.use('/api/payments', paymentRoutes);
  app.use('/api/shipping-fees', shippingFeeRoutes);
};