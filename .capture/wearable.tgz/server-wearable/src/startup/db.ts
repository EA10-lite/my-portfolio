import { Application } from 'express';
import mongoose from 'mongoose';

/**
 * Connect to MongoDB with proper connection options
 * Handles connection state, timeouts, and retries
 */
export const db = (_app: Application): void => {
  const mongoUri = process.env.MONGODB_URI as string;

  if (!mongoUri) {
    console.error('MONGODB_URI is not defined in environment variables');
    return;
  }

  // Configure connection options for production stability
  const connectionOptions: mongoose.ConnectOptions = {
    // Connection timeout settings
    serverSelectionTimeoutMS: 30000, // 30 seconds - time to wait for server selection
    socketTimeoutMS: 45000, // 45 seconds - time to wait for socket operations
    connectTimeoutMS: 30000, // 30 seconds - time to wait for initial connection
    
    // Retry settings
    retryWrites: true,
    retryReads: true,
    
    // Buffer commands until connection is ready
    bufferCommands: true,
    
    // Connection pool settings
    maxPoolSize: 10, // Maximum number of connections in the pool
    minPoolSize: 2, // Minimum number of connections in the pool
    maxIdleTimeMS: 30000, // Close connections after 30 seconds of inactivity
    
    // Heartbeat settings for connection monitoring
    heartbeatFrequencyMS: 10000, // Send heartbeat every 10 seconds
    
    // Additional options for production
    readPreference: 'primary', // Always read from primary
  };

  // Handle connection events
  mongoose.connection.on('connected', () => {
    console.log('✅ Connected to MongoDB');
  });

  mongoose.connection.on('error', (err) => {
    console.error('❌ MongoDB connection error:', err);
  });

  mongoose.connection.on('disconnected', () => {
    console.warn('⚠️  MongoDB disconnected');
  });

  mongoose.connection.on('reconnected', () => {
    console.log('✅ MongoDB reconnected');
  });

  // Handle process termination
  process.on('SIGINT', async () => {
    await mongoose.connection.close();
    console.log('MongoDB connection closed due to application termination');
    process.exit(0);
  });

  // Connect to MongoDB
  mongoose
    .connect(mongoUri, connectionOptions)
    .then(() => {
      console.log('MongoDB connection established');
    })
    .catch((err) => {
      console.error('Failed to connect to MongoDB:', err);
      // In production, you might want to exit the process
      // For now, we'll let the app continue and handle errors at query time
    });
};