import corsMiddleware from 'cors';
import { Application } from 'express';

/**
 * CORS Configuration
 * Configures Cross-Origin Resource Sharing for the Express application
 * Allows requests from specified origins with credentials support
 */
const corsOptions: corsMiddleware.CorsOptions = {
  origin: [
    'https://admin.wearable.ng/',
    'https://admin.wearable.ng',

    'https://www.wearable.ng/',
    'https://www.wearable.ng',

    'http://localhost:5173',
    'http://localhost:5174',
    'http://localhost:3000',
    'http://localhost:3001'
  ],
  credentials: true
};

/**
 * Apply CORS middleware to the Express application
 * @param app - Express Application instance
 */
export const cors = (app: Application): void => {
  app.use(corsMiddleware(corsOptions));
};

