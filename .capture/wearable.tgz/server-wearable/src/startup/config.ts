/**
 * Configuration validation
 * Validates required environment variables on application startup
 * Exits the process if critical variables are missing
 */
export const config = (): void => {
  if (!process.env.JWT_SECRET) {
    console.log('FATAL ERROR: No JWT KEY Provided');
    process.exit(1);
  }

  // Add more environment variable validations here
  // Example:
  // if (!process.env.MONGODB_URI) {
  //   console.log('FATAL ERROR: No MongoDB URI Provided');
  //   process.exit(1);
  // }
};

