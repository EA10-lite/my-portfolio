import express from 'express';
import {
  getDashboardStats,
  getSalesData,
  getCategoryPerformance,
  getOrdersTrend
} from '../controllers/dashboard.controller';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

router.use(authenticate, requireAdmin);

router.get('/stats', getDashboardStats);
router.get('/sales', getSalesData);
router.get('/category-performance', getCategoryPerformance);
router.get('/orders-trend', getOrdersTrend);

export default router;
