import express from 'express';
import { authenticate, requireAdmin } from '../middleware/auth';
import { uploadProductImages } from '../middleware/upload';
import { validateFormData } from '../middleware/validateFormData';
import { addProductSchema } from '../validations/product.validation';
import {
  getAllProducts,
  getAllProductsAdmin,
  getProduct,
  getProductByAdmin,
  getProductsByCategory,
  getProductsBySubcategory,
  getBestSellers,
  getNewArrivals,
  searchProducts,
  createProduct,
  updateProduct,
  removeProduct,
} from '../controllers/product.controller';

const router = express.Router();

// Public routes (no authentication required)
router.get('/', getAllProducts); // GET /api/products - Get all active products (supports category, subcategory, search query params)
router.get('/user', getAllProducts); // Alias for backward compatibility
router.get('/user/category/:category', getProductsByCategory);
router.get('/user/subcategory/:subcategory', getProductsBySubcategory); // GET /api/products/user/subcategory/:subcategory
router.get('/user/best-sellers', getBestSellers); // GET /api/products/user/best-sellers
router.get('/user/new-arrivals', getNewArrivals); // GET /api/products/user/new-arrivals
router.get('/user/search/:search', searchProducts);
router.get('/user/:id', getProduct);

// Admin-only routes (require authentication and admin role)
router.get('/admin/all', authenticate, requireAdmin, getAllProductsAdmin);
router.get('/admin/:id', authenticate, requireAdmin, getProductByAdmin);
router.post(
  '/',
  authenticate,
  requireAdmin,
  uploadProductImages.array('images', 10), // 'images' is the field name, max 10 files
  validateFormData(addProductSchema),
  createProduct
);
router.put(
  '/:id',
  authenticate,
  requireAdmin,
  uploadProductImages.array('images', 10), // New images can be uploaded
  validateFormData(addProductSchema),
  updateProduct
);
router.delete('/:id', authenticate, requireAdmin, removeProduct);

export default router;
