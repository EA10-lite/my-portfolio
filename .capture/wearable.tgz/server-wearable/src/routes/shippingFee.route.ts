import { Router } from 'express';
import {
  getShippingFees,
  createShippingFee,
  updateShippingFee,
  deleteShippingFee,
  calculateShippingFee,
} from '../controllers/shippingFee.controller';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = Router();

// Public route for checkout
router.get('/calculate', calculateShippingFee);

// Admin routes
router.use(authenticate, requireAdmin);

router.route('/')
  .get(getShippingFees)
  .post(createShippingFee);

router.route('/:id')
  .patch(updateShippingFee)
  .delete(deleteShippingFee);

export default router;
