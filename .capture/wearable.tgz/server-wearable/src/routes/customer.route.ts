import express from 'express';
import {
  getCustomers,
  getCustomerById,
  blockCustomer,
} from '../controllers/customer.controller';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = express.Router();

// All customer routes require admin authentication
router.use(authenticate, requireAdmin);

router.get('/', getCustomers);
router.get('/:id', getCustomerById);
router.put('/:id/block', blockCustomer);

export default router;