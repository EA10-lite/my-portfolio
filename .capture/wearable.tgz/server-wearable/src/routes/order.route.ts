import express from "express";
import {
    createOrder,
    getOrders,
    getOrderById,
    updateOrderById,
    cancelOrderById,
    getMyOrders,
} from "../controllers/order.controller";
import { authenticate, requireAdmin } from "../middleware/auth";
import { validate } from "../middleware/validate";
import { createOrderSchema, updateOrderStatusSchema } from "../validations/order.validation";

const router = express.Router();

router.get("/my-orders", authenticate, getMyOrders);
router.get("/", authenticate, requireAdmin, getOrders);
router.get("/:id", authenticate, requireAdmin, getOrderById);
router.put("/:id", authenticate, requireAdmin, validate(updateOrderStatusSchema), updateOrderById);
router.post("/", validate(createOrderSchema), createOrder);
router.put("/:id/cancel", authenticate, requireAdmin, validate(updateOrderStatusSchema), cancelOrderById);

export default router;