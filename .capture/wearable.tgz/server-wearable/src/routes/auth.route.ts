import express from 'express';
import { validate } from '../middleware/validate';
import { authLimiter } from '../middleware/rateLimiter';
import {
    customerLogin,
    adminLogin,
    verifyEmailOTP,
    refreshToken
} from '../controllers/auth.controller';
import {
    customerLoginSchema,
    adminLoginSchema,
    verifyEmailSchema
} from '../validations/auth.validation';

const router = express.Router();

router.post('/login/customer', authLimiter, validate(customerLoginSchema), customerLogin);
router.post('/login/admin', authLimiter, validate(adminLoginSchema), adminLogin);
router.post('/verify', authLimiter, validate(verifyEmailSchema), verifyEmailOTP);
router.post('/refresh-token', authLimiter, refreshToken);

export default router;
