import crypto from 'crypto';
import { Payment } from '../../models/payment.model';
import { Order } from '../../models/order.model';

export const HandleWebhook = async (body: any, signature: string) => {
  try {
    const secret = process.env.PAYSTACK_SECRET_KEY;
    if (!secret) {
      return { success: false, message: 'Paystack secret key not configured' };
    }

    // Verify signature
    const hash = crypto.createHmac('sha512', secret).update(JSON.stringify(body)).digest('hex');
    if (hash !== signature) {
      return { success: false, message: 'Invalid signature' };
    }

    const event = body.event;
    const data = body.data;

    if (event === 'charge.success') {
      const reference = data.reference;
      const payment = await Payment.findOne({ reference });

      if (payment && payment.status !== 'success') {
        // Double check amount in kobo
        if (data.amount >= payment.amount) {
          payment.status = 'success';
          payment.channel = data.channel;
          payment.paidAt = new Date(data.paid_at);
          await payment.save();

          await Order.updateMany(
            { paymentReference: reference },
            { $set: { paymentStatus: 'paid', paymentConfirmedAt: new Date(), orderStatus: 'confirmed' } }
          );
        } else {
          payment.status = 'failed';
          await payment.save();
          await Order.updateMany(
            { paymentReference: reference },
            { $set: { paymentStatus: 'failed' } }
          );
        }
      }
    } else if (event === 'transfer.failed') {
      // Custom logic for transfer failed if applicable
      const reference = data.reference;
      const payment = await Payment.findOne({ reference });
      if (payment && payment.status !== 'failed') {
        payment.status = 'failed';
        await payment.save();
        await Order.updateMany(
          { paymentReference: reference },
          { $set: { paymentStatus: 'failed' } }
        );
      }
    } else if (event === 'refund.processed') {
      const reference = data.reference;
      const payment = await Payment.findOne({ reference });
      if (payment) {
        payment.status = 'refunded';
        await payment.save();
        await Order.updateMany(
          { paymentReference: reference },
          { $set: { paymentStatus: 'refunded' } }
        );
      }
    }

    return { success: true };
  } catch (error) {
    console.error('Error handling webhook:', error);
    return { success: false, message: 'Internal server error' };
  }
};
