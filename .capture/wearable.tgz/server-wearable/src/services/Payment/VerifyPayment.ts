import { Payment } from '../../models/payment.model';
import { Order } from '../../models/order.model';

export const VerifyPayment = async (reference: string) => {
  try {
    if (!reference) {
      return { success: false, message: 'Reference is required' };
    }

    const paystackSecret = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackSecret) {
      return { success: false, message: 'Paystack secret key not configured' };
    }

    const payment = await Payment.findOne({ reference });
    if (!payment) {
      return { success: false, message: 'Payment record not found' };
    }

    if (payment.status === 'success') {
      return { success: true, message: 'Payment already verified', data: payment };
    }

    const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${paystackSecret}`,
      },
    });

    const data = (await response.json()) as any;

    if (!data.status) {
      return { success: false, message: data.message || 'Failed to verify transaction' };
    }

    if (data.data.status === 'success') {
      // Amount check in kobo
      if (data.data.amount >= payment.amount) {
        payment.status = 'success';
        payment.channel = data.data.channel;
        payment.paidAt = new Date(data.data.paid_at);
        await payment.save();

        // Update orders
        await Order.updateMany(
          { paymentReference: reference },
          { $set: { paymentStatus: 'paid', orderStatus: 'confirmed', paymentConfirmedAt: new Date() } }
        );

        return { success: true, message: 'Payment successful', data: payment };
      } else {
        payment.status = 'failed';
        await payment.save();
        await Order.updateMany(
          { paymentReference: reference },
          { $set: { paymentStatus: 'failed' } }
        );
        return { success: false, message: 'Payment amount mismatch' };
      }
    } else {
      payment.status = 'failed';
      await payment.save();
      await Order.updateMany(
        { paymentReference: reference },
        { $set: { paymentStatus: 'failed' } }
      );
      return { success: false, message: 'Transaction was not successful' };
    }
  } catch (error) {
    console.error('Error verifying payment:', error);
    return { success: false, message: 'Internal server error during payment verification' };
  }
};
