import { Payment } from '../../models/payment.model';
import { Order } from '../../models/order.model';
import mongoose from 'mongoose';

interface InitializePaymentParams {
  orderIds: string[];
  email: string;
  amount: number; // in kobo
  metadata?: Record<string, any>;
}

export const InitializePayment = async ({
  orderIds,
  email,
  amount,
  metadata,
}: InitializePaymentParams) => {
  try {
    const orders = await Order.find({ _id: { $in: orderIds } });
    if (!orders || orders.length === 0) {
      return { success: false, message: 'Orders not found' };
    }

    const paystackSecret = process.env.PAYSTACK_SECRET_KEY;
    if (!paystackSecret) {
      return { success: false, message: 'Paystack secret key not configured' };
    }

    const response = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${paystackSecret}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        amount,
        callback_url: metadata?.callback_url,
        metadata: {
          ...metadata,
          orderIds,
        },
      }),
    });

    const data = (await response.json()) as any;

    if (!data.status) {
      return { success: false, message: data.message || 'Failed to initialize payment' };
    }

    const { authorization_url, reference } = data.data;

    // Create payment record
    const payment = new Payment({
      orderIds: orderIds.map(id => new mongoose.Types.ObjectId(id)),
      reference,
      amount,
      currency: 'NGN',
      status: 'pending',
      metadata,
    });
    await payment.save();

    // Link reference to orders
    await Order.updateMany(
      { _id: { $in: orderIds } },
      { $set: { paymentReference: reference } }
    );

    return {
      success: true,
      authorization_url,
      reference,
    };
  } catch (error) {
    console.error('Error initializing payment:', error);
    return { success: false, message: 'Internal server error during payment initialization' };
  }
};
