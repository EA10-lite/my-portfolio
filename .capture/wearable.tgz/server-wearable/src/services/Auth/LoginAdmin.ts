import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import type { StringValue } from 'ms';
import { User } from '../../models/user.model';

/**
 * Interface for admin login response
 */
interface AdminLoginResponse {
  success: boolean;
  message: string;
  token?: string;
  refreshToken?: string;
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

/**
 * Service for admin login with email and password
 * Validates credentials and returns JWT token upon successful authentication
 * 
 * @param email - Admin email address
 * @param password - Admin password
 * @returns Object with success status, message, and JWT token if successful
 */
export const LoginAdmin = async (
  email: string,
  password: string
): Promise<AdminLoginResponse> => {
  try {
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return {
        success: false,
        message: 'Invalid email format',
      };
    }

    // Validate password is provided
    if (!password || password.trim().length === 0) {
      return {
        success: false,
        message: 'Password is required',
      };
    }

    // Normalize email
    const normalizedEmail = email.toLowerCase().trim();

    // Find admin user with password field included
    const admin = await User.findOne({ email: normalizedEmail, role: 'admin' }).select('+password');

    if (!admin) {
      return {
        success: false,
        message: 'Invalid email or password',
      };
    }

    // Check if password exists (should always exist for admin)
    if (!admin.password) {
      return {
        success: false,
        message: 'Account configuration error. Please contact support.',
      };
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, admin.password);

    if (!isPasswordValid) {
      return {
        success: false,
        message: 'Invalid email or password',
      };
    }

    // Generate JWT token
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      console.error('JWT_SECRET is not defined in environment variables');
      return {
        success: false,
        message: 'Server configuration error',
      };
    }

    const expiresIn: StringValue | number = '15m'; // Short-lived access token
    const refreshExpiresIn: StringValue | number = '7d'; // Long-lived refresh token

    const token = jwt.sign(
      {
        userId: admin._id.toString(),
        email: admin.email,
        role: admin.role,
      },
      jwtSecret,
      { expiresIn }
    );

    const refreshToken = jwt.sign(
      {
        userId: admin._id.toString(),
        email: admin.email,
        role: admin.role,
      },
      jwtSecret,
      { expiresIn: refreshExpiresIn }
    );

    return {
      success: true,
      message: 'Login successful',
      token,
      refreshToken,
      user: {
        id: admin._id.toString(),
        email: admin.email,
        role: admin.role,
      },
    };
  } catch (error) {
    console.error('Error in loginAdmin service:', error);
    return {
      success: false,
      message: 'Failed to process login request. Please try again.',
    };
  }
};

