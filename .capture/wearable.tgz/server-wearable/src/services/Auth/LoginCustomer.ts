import { User } from '../../models/user.model';
import { OTP } from '../../models/otp.model';
import { generateOTP, getOTPExpiration } from '../../utils/otpGenerator';
import { sendOTPEmail } from '../../utils/emailService';

/**
 * Service for customer login via email
 * Creates or finds customer by email and sends OTP for verification
 * 
 * @param email - Customer email address
 * @returns Object with success status and message
 */
export const LoginCustomer = async (email: string): Promise<{
  success: boolean;
  message: string;
  email?: string;
}> => {
  try {
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return {
        success: false,
        message: 'Invalid email format',
      };
    }

    // Normalize email (lowercase, trim)
    const normalizedEmail = email.toLowerCase().trim();

    // Find or create customer
    let customer = await User.findOne({ email: normalizedEmail, role: 'customer' });

    if (!customer) {
      // Create new customer account
      customer = await User.create({
        email: normalizedEmail,
        role: 'customer',
        isVerified: false,
      });
    }

    // Invalidate any existing unused OTPs for this email
    await OTP.updateMany(
      { email: normalizedEmail, isUsed: false },
      { isUsed: true }
    );

    // Generate new OTP
    const otp = generateOTP();
    const expiresAt = getOTPExpiration(10); // 10 minutes expiration

    // Save OTP to database
    await OTP.create({
      email: normalizedEmail,
      otp,
      expiresAt,
      isUsed: false,
    });

    // Send OTP via email
    await sendOTPEmail(normalizedEmail, otp);

    return {
      success: true,
      message: 'OTP sent to your email. Please check your inbox.',
      email: normalizedEmail,
    };
  } catch (error) {
    console.error('Error in loginCustomer service:', error);
    return {
      success: false,
      message: 'Failed to process login request. Please try again.',
    };
  }
};

