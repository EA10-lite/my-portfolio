import { Product } from '../../models/product.model';
import { deleteImageFromCloudinary } from '../../utils/uploadImage';

/**
 * Service for deleting a product
 * Also deletes associated images from Cloudinary
 * 
 * @param productId - Product ID to delete
 * @returns Success message
 */
export const DeleteProduct = async (
  productId: string
): Promise<{ success: boolean; message: string }> => {
  try {
    // Find the product to get image publicIds
    const product = await Product.findById(productId);

    if (!product) {
      return {
        success: false,
        message: 'Product not found',
      };
    }

    // Delete images from Cloudinary
    for (const image of product.images) {
      try {
        await deleteImageFromCloudinary(image.publicId);
      } catch (error) {
        console.error(`Failed to delete image ${image.publicId}:`, error);
        // Continue even if image deletion fails
      }
    }

    // Delete the product
    await Product.findByIdAndDelete(productId);

    return {
      success: true,
      message: 'Product deleted successfully',
    };
  } catch (error) {
    console.error('Error in deleteProduct service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to delete product',
    };
  }
};

