import { Product } from '../../models/product.model';
import { uploadMultipleImages, deleteImageFromCloudinary } from '../../utils/uploadImage';
import { EditProductRequest, ProductResponse } from '../../types/services.types';

/**
 * Service for editing an existing product
 * Handles image updates, deletions, and product data updates
 * 
 * @param productId - ID of the product to update
 * @param productData - Updated product data
 * @param newImageFiles - New image files to add (optional)
 * @param imagesToKeep - Public IDs of images to keep (optional, if not provided, all old images are kept)
 * @returns Product response with updated data
 */
export const EditProduct = async (
  productId: string,
  productData: EditProductRequest,
  newImageFiles?: Express.Multer.File[],
  imagesToKeep?: string[] // Array of publicIds to keep
): Promise<{ success: boolean; message: string; product?: ProductResponse }> => {
  try {
    // Find the product
    const product = await Product.findById(productId);
    if (!product) {
      return {
        success: false,
        message: 'Product not found',
      };
    }

    // Handle image updates
    let updatedImages = [...product.images];

    // If imagesToKeep is provided, delete images not in the list
    if (imagesToKeep && imagesToKeep.length > 0) {
      const imagesToDelete = updatedImages.filter(
        (img) => !imagesToKeep.includes(img.publicId)
      );

      // Delete images from Cloudinary
      for (const img of imagesToDelete) {
        try {
          await deleteImageFromCloudinary(img.publicId);
        } catch (error) {
          console.error(`Failed to delete image ${img.publicId}:`, error);
          // Continue even if deletion fails
        }
      }

      // Keep only specified images
      updatedImages = updatedImages.filter((img) => imagesToKeep.includes(img.publicId));
    }

    // Upload new images if provided
    if (newImageFiles && newImageFiles.length > 0) {
      const uploadedImages = await uploadMultipleImages(newImageFiles);
      const newImages = uploadedImages.map((img) => ({
        url: img.url,
        publicId: img.publicId,
      }));
      updatedImages = [...updatedImages, ...newImages];
    }

    // Update product data
    const updateData: any = { ...productData };
    
    // Update status based on stock if stock is being updated
    if (productData.stock !== undefined) {
      if (productData.stock > 0 && product.status === 'out_of_stock') {
        updateData.status = 'active';
      } else if (productData.stock === 0) {
        updateData.status = 'out_of_stock';
      }
    }

    // Update images
    if (newImageFiles || imagesToKeep) {
      updateData.images = updatedImages;
    }

    // Update the product
    const updatedProduct = await Product.findByIdAndUpdate(
      productId,
      updateData,
      { new: true, runValidators: true }
    );

    if (!updatedProduct) {
      return {
        success: false,
        message: 'Failed to update product',
      };
    }

    // Format response
    const productResponse: ProductResponse = {
      id: updatedProduct._id.toString(),
      name: updatedProduct.name,
      description: updatedProduct.description,
      category: updatedProduct.category,
      colors: updatedProduct.colors,
      sizes: updatedProduct.sizes,
      variants: updatedProduct.variants,
      price: updatedProduct.price,
      discountPrice: updatedProduct.discountPrice,
      samePriceForAllSizes: updatedProduct.samePriceForAllSizes,
      variantsPrice: updatedProduct.variantsPrice,
      stock: updatedProduct.stock,
      images: updatedProduct.images.map((img) => ({
        url: img.url,
        publicId: img.publicId,
      })),
      sales: updatedProduct.sales,
      status: updatedProduct.status,
      createdAt: updatedProduct.createdAt.toISOString(),
      updatedAt: updatedProduct.updatedAt.toISOString(),
    };

    return {
      success: true,
      message: 'Product updated successfully',
      product: productResponse,
    };
  } catch (error) {
    console.error('Error in editProduct service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to update product',
    };
  }
};

