import { Product } from '../../models/product.model';
import { ProductResponse, CustomerProductResponse } from '../../types/services.types';
import { GetProductStats, ProductStats } from './GetProductStats';
import { cache } from '../../utils/cache';
import mongoose from 'mongoose';

/**
 * Service for getting products with filtering and pagination
 * Returns different data based on whether the requester is an admin or customer
 * 
 * @param options - Query options (category, search, page, limit, status, isAdmin)
 * @returns Products list with pagination info
 */
export const GetProducts = async (options: {
  category?: string;
  subcategory?: string;
  search?: string;
  page?: number;
  limit?: number;
  status?: 'active' | 'inactive' | 'out_of_stock';
  isAdmin?: boolean;
  includeStats?: boolean;
  includeNewArrivals?: boolean;
  includeBestSellers?: boolean;
  sortBy?: 'sales' | 'newest' | 'oldest';
}): Promise<{
  success: boolean;
  message: string;
  products?: ProductResponse[] | CustomerProductResponse[];
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  stats?: ProductStats;
  newArrivals?: CustomerProductResponse[];
  bestSellers?: CustomerProductResponse[];
}> => {
  try {
    // Ensure MongoDB connection is ready before executing queries
    // This prevents "buffering timed out" errors in production
    if (mongoose.connection.readyState === 0) {
      // Not connected - return error immediately
      return {
        success: false,
        message: 'Database connection not available. Please try again later.',
      };
    }

    // If connecting, wait up to 5 seconds for connection
    if (mongoose.connection.readyState === 2) {
      const maxWaitTime = 5000; // 5 seconds
      const checkInterval = 100; // Check every 100ms
      let waited = 0;

      while (mongoose.connection.readyState === 2 && waited < maxWaitTime) {
        await new Promise((resolve) => setTimeout(resolve, checkInterval));
        waited += checkInterval;
      }

      if (Number(mongoose.connection.readyState) !== 1) {
        return {
          success: false,
          message: 'Database connection timeout. Please try again later.',
        };
      }
    }

    const page = options.page || 1;
    const limit = options.limit || 10; // Default to 10 items per page
    const skip = (page - 1) * limit;

    // Build query
    const query: any = {};

    // Filter by category
    if (options.category) {
      query.category = options.category;
    }

    // Filter by subcategory (only if category is also provided)
    if (options.subcategory) {
      query.subCategory = options.subcategory;
    }

    // Filter by status
    if (options.status) {
      // If status is explicitly provided, use it
      query.status = options.status;
    } else if (!options.isAdmin) {
      // For non-admin users (public), show active products or products without status
      // MongoDB will treat top-level fields as AND, so we can combine $or with other fields
      query.$or = [
        { status: 'active' },
        { status: { $exists: false } }
      ];
    }
    // For admin users without status filter, show all products (no status filter applied)

    // Text search
    if (options.search) {
      query.$text = { $search: options.search };
    }

    // Get total count for pagination with timeout protection
    // Use Promise.race to prevent indefinite hanging in production
    let total: number;
    try {
      const countPromise = Product.countDocuments(query);
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error('Count operation timed out after 25 seconds')), 25000);
      });

      total = await Promise.race([countPromise, timeoutPromise]);
    } catch (error) {
      console.error('Error counting documents:', error);
      // If count fails, we can't provide accurate pagination, but we'll try to continue
      // Return an error response instead of continuing with wrong data
      return {
        success: false,
        message: 'Failed to retrieve product count. Please try again later.',
      };
    }

    // Determine sort order based on options
    let sortOrder: any = { createdAt: -1 }; // Default: newest first
    if (options.search) {
      // Text search: sort by relevance score
      sortOrder = { score: { $meta: 'textScore' } };
    } else if (options.sortBy === 'sales') {
      // Sort by sales count (descending)
      sortOrder = { sales: -1, createdAt: -1 };
    } else if (options.sortBy === 'newest') {
      // Sort by creation date (newest first)
      sortOrder = { createdAt: -1 };
    } else if (options.sortBy === 'oldest') {
      // Sort by creation date (oldest first)
      sortOrder = { createdAt: 1 };
    }

    // Get products
    const products = await Product.find(query)
      .sort(sortOrder)
      .skip(skip)
      .limit(limit)
      .lean();

    // Get stats if requested (only for admin)
    let stats: ProductStats | undefined;
    if (options.includeStats && options.isAdmin) {
      const cacheKey = 'product:stats';
      
      // Try to get from cache first
      const cachedStats = cache.get<ProductStats>(cacheKey);
      if (cachedStats) {
        stats = cachedStats;
      } else {
        // Calculate stats and cache for 5 minutes
        stats = await GetProductStats();
        cache.set(cacheKey, stats, 5 * 60 * 1000); // Cache for 5 minutes
      }
    }

    // Get new arrivals if requested (for customer view only)
    let newArrivals: CustomerProductResponse[] | undefined;
    if (options.includeNewArrivals && !options.isAdmin) {
      // Build query for new arrivals - use same filters as main query
      const newArrivalsQuery: any = {};
      
      // Copy category and subcategory filters
      if (query.category) newArrivalsQuery.category = query.category;
      if (query.subCategory) newArrivalsQuery.subCategory = query.subCategory;
      
      // Apply same status filter logic as main query
      if (query.status) {
        newArrivalsQuery.status = query.status;
      } else if (query.$or) {
        // Preserve existing $or condition if it exists
        newArrivalsQuery.$or = query.$or;
      } else if (!options.isAdmin) {
        // For non-admin users, show active products or products without status
        newArrivalsQuery.$or = [
          { status: 'active' },
          { status: { $exists: false } }
        ];
      }
      
      const newArrivalsProducts = await Product.find(newArrivalsQuery)
        .sort({ createdAt: -1 }) // Newest first
        .limit(8) // Limit to 8 items
        .lean();

      newArrivals = newArrivalsProducts.map((product) => ({
        id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.category,
        subCategory: product.subCategory,
        colors: product.colors,
        sizes: product.sizes,
        variants: product.variants,
        price: product.price,
        discountPrice: product.discountPrice,
        samePriceForAllSizes: product.samePriceForAllSizes,
        variantsPrice: product.variantsPrice,
        stock: product.stock,
        images: product.images.map((img) => img.url),
        createdAt: product.createdAt.toISOString(),
      }));
    }

    // Get best sellers if requested (for customer view only)
    let bestSellers: CustomerProductResponse[] | undefined;
    if (options.includeBestSellers && !options.isAdmin) {
      // Build query for best sellers - use same filters as main query
      const bestSellersQuery: any = {};
      
      // Copy category and subcategory filters
      if (query.category) bestSellersQuery.category = query.category;
      if (query.subCategory) bestSellersQuery.subCategory = query.subCategory;
      
      // Apply same status filter logic as main query
      if (query.status) {
        bestSellersQuery.status = query.status;
      } else if (query.$or) {
        // Preserve existing $or condition if it exists
        bestSellersQuery.$or = query.$or;
      } else if (!options.isAdmin) {
        // For non-admin users, show active products or products without status
        bestSellersQuery.$or = [
          { status: 'active' },
          { status: { $exists: false } }
        ];
      }
      
      const bestSellersProducts = await Product.find(bestSellersQuery)
        .sort({ sales: -1, createdAt: -1 }) // Sort by sales count, then by creation date
        .limit(8) // Limit to 8 items
        .lean();

      bestSellers = bestSellersProducts.map((product) => ({
        id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.category,
        subCategory: product.subCategory,
        colors: product.colors,
        sizes: product.sizes,
        variants: product.variants,
        price: product.price,
        discountPrice: product.discountPrice,
        samePriceForAllSizes: product.samePriceForAllSizes,
        variantsPrice: product.variantsPrice,
        stock: product.stock,
        images: product.images.map((img) => img.url),
        createdAt: product.createdAt.toISOString(),
      }));
    }

    // Format response based on user role
    const isAdmin = options.isAdmin || false;
    
    if (isAdmin) {
      // Admin response - includes all data
      const productsResponse: ProductResponse[] = products.map((product) => ({
        id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.category,
        subCategory: product.subCategory,
        colors: product.colors,
        sizes: product.sizes,
        variants: product.variants,
        price: product.price,
        discountPrice: product.discountPrice,
        samePriceForAllSizes: product.samePriceForAllSizes,
        variantsPrice: product.variantsPrice,
        stock: product.stock,
        images: product.images.map((img) => ({
          url: img.url,
          publicId: img.publicId,
        })),
        sales: product.sales,
        status: product.status,
        createdAt: product.createdAt.toISOString(),
        updatedAt: product.updatedAt.toISOString(),
      }));

      return {
        success: true,
        message: 'Products retrieved successfully',
        products: productsResponse,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
        ...(stats && { stats }), // Include stats if requested
      };
    } else {
      // Customer response - excludes sensitive data
      const productsResponse: CustomerProductResponse[] = products.map((product) => ({
        id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.category,
        subCategory: product.subCategory, // Include subcategory for customer view
        colors: product.colors,
        sizes: product.sizes,
        variants: product.variants,
        price: product.price,
        discountPrice: product.discountPrice,
        samePriceForAllSizes: product.samePriceForAllSizes,
        variantsPrice: product.variantsPrice,
        stock: product.stock,
        images: product.images.map((img) => img.url), // Only URLs, no publicIds
        createdAt: product.createdAt.toISOString(),
      }));

      return {
        success: true,
        message: 'Products retrieved successfully',
        products: productsResponse,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
        },
        ...(newArrivals && { newArrivals }), // Include new arrivals if requested
        ...(bestSellers && { bestSellers }), // Include best sellers if requested
      };
    }
  } catch (error) {
    console.error('Error in getProducts service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to retrieve products',
    };
  }
};

