import { Product } from '../../models/product.model';
import { uploadMultipleImages } from '../../utils/uploadImage';
import { AddProductRequest, ProductResponse } from '../../types/services.types';

/**
 * Service for adding a new product
 * Handles image uploads to Cloudinary and product creation
 * 
 * @param productData - Product data without images
 * @param imageFiles - Array of uploaded image files
 * @returns Product response with uploaded image URLs
 */
export const AddProduct = async (
  productData: AddProductRequest,
  imageFiles: Express.Multer.File[]
): Promise<{ success: boolean; message: string; product?: ProductResponse }> => {
  try {
    // Validate that at least one image is provided
    if (!imageFiles || imageFiles.length === 0) {
      return {
        success: false,
        message: 'At least one product image is required',
      };
    }

    // Upload images to Cloudinary
    const uploadedImages = await uploadMultipleImages(imageFiles);

    // Create product with image URLs
    const product = await Product.create({
      ...productData,
      images: uploadedImages.map((img) => ({
        url: img.url,
        publicId: img.publicId,
      })),
      status: productData.stock > 0 ? 'active' : 'out_of_stock',
    });

    // Format response
    const productResponse: ProductResponse = {
      id: product._id.toString(),
      name: product.name,
      description: product.description,
      category: product.category,
      colors: product.colors,
      sizes: product.sizes,
      variants: product.variants,
      price: product.price,
      discountPrice: product.discountPrice,
      samePriceForAllSizes: product.samePriceForAllSizes,
      variantsPrice: product.variantsPrice,
      stock: product.stock,
      images: product.images.map((img) => ({
        url: img.url,
        publicId: img.publicId,
      })),
      sales: product.sales,
      status: product.status,
      createdAt: product.createdAt.toISOString(),
      updatedAt: product.updatedAt.toISOString(),
    };

    return {
      success: true,
      message: 'Product created successfully',
      product: productResponse,
    };
  } catch (error) {
    console.error('Error in addProduct service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to create product',
    };
  }
};

