import { Product } from '../../models/product.model';

/**
 * Product statistics interface
 */
export interface ProductStats {
  totalProducts: number;
  lowStockProducts: number;
  outOfStockProducts: number;
  lowStockProductsList: Array<{ name: string; stock: number }>;
  outOfStockProductsList: Array<{ name: string; stock: number }>;
  bestSellingProducts: Array<{
    id: string;
    name: string;
    sales: number;
    revenue: number; // Calculated from sales * price
  }>;
  categoryBreakdown: Array<{
    category: string;
    sales: number; // Total sales count for this category
  }>;
}

/**
 * Service for getting product statistics
 * Calculates various metrics about products including stock levels, sales, and category breakdown
 * 
 * @returns Product statistics including totals, stock levels, best sellers, and category data
 */
export const GetProductStats = async (): Promise<ProductStats> => {
  try {
    // Get all products (we need all for accurate stats)
    const allProducts = await Product.find({}).lean();

    // Calculate basic counts
    const totalProducts = allProducts.length;
    
    // Low stock threshold (products with stock <= 10)
    const LOW_STOCK_THRESHOLD = 10;
    
    // Filter products by stock levels
    const lowStockProducts = allProducts.filter(p => p.stock > 0 && p.stock <= LOW_STOCK_THRESHOLD);
    const outOfStockProducts = allProducts.filter(p => p.stock === 0);

    // Get low stock products list (top 10)
    const lowStockProductsList = lowStockProducts
      .map(p => ({ name: p.name, stock: p.stock }))
      .sort((a, b) => a.stock - b.stock) // Sort by stock ascending
      .slice(0, 10);

    // Get out of stock products list (top 10)
    const outOfStockProductsList = outOfStockProducts
      .map(p => ({ name: p.name, stock: p.stock }))
      .slice(0, 10);

    // Calculate best selling products (top 5 by sales count)
    const bestSellingProducts = allProducts
      .map(p => ({
        id: p._id.toString(),
        name: p.name,
        sales: p.sales || 0,
        revenue: (p.sales || 0) * (p.price || 0),
        category: p.category || 'unknown', // Approximate revenue
      }))
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5);

    // Calculate category breakdown (total sales per category)
    // Include all categories that have products, even if sales are 0
    const categorySalesMap = new Map<string, number>();
    const categoryProductCountMap = new Map<string, number>();
    
    allProducts.forEach(product => {
      const category = product.category || 'unknown';
      const capitalizedCategory = category.charAt(0).toUpperCase() + category.slice(1);
      
      // Count sales for this category
      const currentSales = categorySalesMap.get(capitalizedCategory) || 0;
      categorySalesMap.set(capitalizedCategory, currentSales + (product.sales || 0));
      
      // Count products for this category
      const currentCount = categoryProductCountMap.get(capitalizedCategory) || 0;
      categoryProductCountMap.set(capitalizedCategory, currentCount + 1);
    });

    // Convert to array format (without fill colors - handled on frontend)
    // Include all categories that have products, even with 0 sales
    const categoryBreakdown = Array.from(categoryProductCountMap.entries())
      .map(([category, productCount]) => ({
        category,
        sales: categorySalesMap.get(category) || 0, // Sales count (can be 0)
        productCount, // Also include product count for reference
      }))
      .sort((a, b) => {
        // Sort by sales first (descending), then by product count (descending)
        if (b.sales !== a.sales) {
          return b.sales - a.sales;
        }
        return b.productCount - a.productCount;
      })
      .map(({ category, sales }) => ({
        category,
        sales, // Only return sales for the API response
      }));

    return {
      totalProducts,
      lowStockProducts: lowStockProducts.length,
      outOfStockProducts: outOfStockProducts.length,
      lowStockProductsList,
      outOfStockProductsList,
      bestSellingProducts,
      categoryBreakdown,
    };
  } catch (error) {
    console.error('Error in GetProductStats service:', error);
    throw new Error('Failed to retrieve product statistics');
  }
};
