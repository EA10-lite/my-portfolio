import { Product } from '../../models/product.model';
import { ProductResponse, CustomerProductResponse } from '../../types/services.types';

/**
 * Service for getting a single product by ID
 * Returns different data based on whether the requester is an admin or customer
 * Also returns similar products based on category and subcategory
 * 
 * @param productId - Product ID
 * @param isAdmin - Whether the requester is an admin
 * @returns Product response with similar products
 */
export const GetProductById = async (
  productId: string,
  isAdmin: boolean = false
): Promise<{ 
  success: boolean; 
  message: string; 
  product?: ProductResponse | CustomerProductResponse;
  similarProducts?: CustomerProductResponse[];
}> => {
  try {
    const product = await Product.findById(productId).lean();

    if (!product) {
      return {
        success: false,
        message: 'Product not found',
      };
    }

    // Format response based on user role
    if (isAdmin) {
      // Admin response - includes all data
      const productResponse: ProductResponse = {
        id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.category,
        colors: product.colors,
        sizes: product.sizes,
        variants: product.variants,
        price: product.price,
        discountPrice: product.discountPrice,
        samePriceForAllSizes: product.samePriceForAllSizes,
        variantsPrice: product.variantsPrice,
        stock: product.stock,
        images: product.images.map((img) => ({
          url: img.url,
          publicId: img.publicId,
        })),
        sales: product.sales,
        status: product.status,
        createdAt: product.createdAt.toISOString(),
        updatedAt: product.updatedAt.toISOString(),
      };

      // Get similar products for admin view as well
      const similarQuery: any = {
        category: product.category,
        _id: { $ne: product._id },
      };

      if (product.subCategory) {
        similarQuery.subCategory = product.subCategory;
      }

      const similarProducts = await Product.find(similarQuery)
        .limit(8)
        .sort({ createdAt: -1 })
        .lean();

      const similarProductsResponse: CustomerProductResponse[] = similarProducts.map((similarProduct) => ({
        id: similarProduct._id.toString(),
        name: similarProduct.name,
        description: similarProduct.description,
        category: similarProduct.category,
        subCategory: similarProduct.subCategory,
        colors: similarProduct.colors,
        sizes: similarProduct.sizes,
        variants: similarProduct.variants,
        price: similarProduct.price,
        discountPrice: similarProduct.discountPrice,
        samePriceForAllSizes: similarProduct.samePriceForAllSizes,
        variantsPrice: similarProduct.variantsPrice,
        stock: similarProduct.stock,
        images: similarProduct.images.map((img) => img.url),
        createdAt: similarProduct.createdAt.toISOString(),
      }));

      return {
        success: true,
        message: 'Product retrieved successfully',
        product: productResponse,
        similarProducts: similarProductsResponse,
      };
    } else {
      // Customer response - excludes sensitive data
      // Only show active products to customers
      if (product.status !== 'active') {
        return {
          success: false,
          message: 'Product not found',
        };
      }

      const productResponse: CustomerProductResponse = {
        id: product._id.toString(),
        name: product.name,
        description: product.description,
        category: product.category,
        subCategory: product.subCategory,
        colors: product.colors,
        sizes: product.sizes,
        variants: product.variants,
        price: product.price,
        discountPrice: product.discountPrice,
        samePriceForAllSizes: product.samePriceForAllSizes,
        variantsPrice: product.variantsPrice,
        stock: product.stock,
        images: product.images.map((img) => img.url), // Only URLs, no publicIds
        createdAt: product.createdAt.toISOString(),
      };

      // Get similar products (same category, exclude current product, limit to 8)
      // Prioritize same subcategory if available
      const similarQuery: any = {
        category: product.category,
        status: 'active',
        _id: { $ne: product._id }, // Exclude current product
      };

      // If product has subcategory, prioritize products with same subcategory
      if (product.subCategory) {
        similarQuery.subCategory = product.subCategory;
      }

      const similarProducts = await Product.find(similarQuery)
        .limit(8)
        .sort({ createdAt: -1 })
        .lean();

      const similarProductsResponse: CustomerProductResponse[] = similarProducts.map((similarProduct) => ({
        id: similarProduct._id.toString(),
        name: similarProduct.name,
        description: similarProduct.description,
        category: similarProduct.category,
        subCategory: similarProduct.subCategory,
        colors: similarProduct.colors,
        sizes: similarProduct.sizes,
        variants: similarProduct.variants,
        price: similarProduct.price,
        discountPrice: similarProduct.discountPrice,
        samePriceForAllSizes: similarProduct.samePriceForAllSizes,
        variantsPrice: similarProduct.variantsPrice,
        stock: similarProduct.stock,
        images: similarProduct.images.map((img) => img.url),
        createdAt: similarProduct.createdAt.toISOString(),
      }));

      return {
        success: true,
        message: 'Product retrieved successfully',
        product: productResponse,
        similarProducts: similarProductsResponse,
      };
    }
  } catch (error) {
    console.error('Error in getProductById service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to retrieve product',
    };
  }
};

