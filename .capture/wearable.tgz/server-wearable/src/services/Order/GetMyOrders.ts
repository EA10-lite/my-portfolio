import { Order } from '../../models/order.model';

export const GetMyOrders = async (customerId: string) => {
  try {
    const orders = await Order.find({ customerId }).sort({ createdAt: -1 });
    return { success: true, orders };
  } catch (error) {
    console.error('Error fetching my orders:', error);
    return { success: false, message: 'Failed to fetch orders' };
  }
};
