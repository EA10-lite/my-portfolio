import { Order, OrderStatus } from '../../models/order.model';

export const UpdateOrderStatus = async (
  orderId: string,
  orderStatus: OrderStatus
): Promise<{
  success: boolean;
  message: string;
  order?: any;
}> => {
  try {
    const order = await Order.findById(orderId);

    if (!order) {
      return {
        success: false,
        message: 'Order not found',
      };
    }

    const updateData: any = {
      orderStatus,
    };

    const now = new Date();

    switch (orderStatus) {
      case 'processing':
        if (!order.paymentConfirmedAt) {
          updateData.paymentConfirmedAt = now;
          updateData.paymentStatus = 'paid';
        }
        break;
      case 'packed':
        if (!order.packedAt) {
          updateData.packedAt = now;
        }
        break;
      case 'assigned':
        if (!order.assignedAt) {
          updateData.assignedAt = now;
        }
        break;
      case 'shipped':
        if (!order.shippedAt) {
          updateData.shippedAt = now;
        }
        break;
      case 'delivered':
        if (!order.deliveredAt) {
          updateData.deliveredAt = now;
        }
        break;
      case 'cancelled':
        if (!order.cancelledAt) {
          updateData.cancelledAt = now;
        }
        break;
    }

    const updatedOrder = await Order.findByIdAndUpdate(orderId, updateData, {
      new: true,
    }).populate('productId', 'name description images category price');

    if (!updatedOrder) {
      return {
        success: false,
        message: 'Failed to update order',
      };
    }

    return {
      success: true,
      message: 'Order status updated successfully',
      order: updatedOrder,
    };
  } catch (error) {
    console.error('Error in UpdateOrderStatus service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to update order status',
    };
  }
};
