import { Order } from '../../models/order.model';
import { OrderResponse } from '../../types/services.types';

export const GetOrderById = async (orderId: string): Promise<{
  success: boolean;
  message: string;
  order?: OrderResponse;
}> => {
  try {
    const order = await Order.findById(orderId)
      .populate('productId', 'name description images category price')
      .lean();

    if (!order) {
      return {
        success: false,
        message: 'Order not found',
      };
    }

    const product: any = order.productId;

    const orderResponse: OrderResponse = {
      id: order._id.toString(),
      customerId: order.customerId ? order.customerId.toString() : undefined,
      customerName: order.customerName,
      customerEmail: order.customerEmail,
      customerPhone: order.customerPhone,
      product: product ? {
        id: product._id?.toString() || '',
        name: product.name || 'Unknown Product',
        description: product.description || '',
        images: product.images?.map((img: any) => img.url) || [],
        category: product.category || '',
        price: product.price || 0,
      } : {
        id: '', name: 'Unknown Product', description: '', images: [], category: '', price: 0
      },
      quantity: order.quantity,
      price: order.price,
      total: order.total,
      variants: order.variants,
      colors: order.colors,
      sizes: order.sizes,
      deliveryAddress: order.deliveryAddress,
      paymentMethod: order.paymentMethod,
      paymentStatus: order.paymentStatus,
      paymentReference: order.paymentReference,
      orderStatus: order.orderStatus,
      paymentConfirmedAt: order.paymentConfirmedAt?.toISOString(),
      packedAt: order.packedAt?.toISOString(),
      assignedAt: order.assignedAt?.toISOString(),
      shippedAt: order.shippedAt?.toISOString(),
      deliveredAt: order.deliveredAt?.toISOString(),
      cancelledAt: order.cancelledAt?.toISOString(),
      createdAt: order.createdAt.toISOString(),
      updatedAt: order.updatedAt.toISOString(),
    };

    return {
      success: true,
      message: 'Order retrieved successfully',
      order: orderResponse,
    };
  } catch (error) {
    console.error('Error in GetOrderById service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to retrieve order',
    };
  }
};
