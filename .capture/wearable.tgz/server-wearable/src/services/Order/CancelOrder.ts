import { UpdateOrderStatus } from './UpdateOrderStatus';

export const CancelOrder = async (orderId: string): Promise<{
  success: boolean;
  message: string;
  order?: any;
}> => {
  try {
    return await UpdateOrderStatus(orderId, 'cancelled');
  } catch (error) {
    console.error('Error in CancelOrder service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to cancel order',
    };
  }
};
