import { Order } from '../../models/order.model';
import { OrderResponse } from '../../types/services.types';

export const GetOrders = async (options: {
  page?: number;
  limit?: number;
  orderStatus?: string;
  paymentStatus?: string;
}): Promise<{
  success: boolean;
  message: string;
  orders?: OrderResponse[];
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}> => {
  try {
    const page = options.page || 1;
    const limit = options.limit || 20;
    const skip = (page - 1) * limit;

    const query: any = {};

    if (options.orderStatus) {
      query.orderStatus = options.orderStatus;
    }

    if (options.paymentStatus) {
      query.paymentStatus = options.paymentStatus;
    }

    const total = await Order.countDocuments(query);

    const orders = await Order.find(query)
      .populate('productId', 'name description images category price')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();

    const ordersResponse: OrderResponse[] = orders.map((order: any) => {
        const product = order.productId;

        return {
          id: order._id.toString(),
          customerId: order.customerId ? order.customerId.toString() : undefined,
          customerName: order.customerName,
          customerEmail: order.customerEmail,
          customerPhone: order.customerPhone,
          product: product ? {
            id: product._id?.toString() || '',
            name: product.name || 'Unknown Product',
            description: product.description || '',
            images: product.images?.map((img: any) => img.url) || [],
            category: product.category || '',
            price: product.price || 0,
          } : {
            id: '', name: 'Unknown Product', description: '', images: [], category: '', price: 0
          },
          quantity: order.quantity,
          price: order.price,
          total: order.total,
          variants: order.variants,
          colors: order.colors,
          sizes: order.sizes,
          deliveryAddress: order.deliveryAddress,
          paymentMethod: order.paymentMethod,
          paymentStatus: order.paymentStatus,
          paymentReference: order.paymentReference,
          orderStatus: order.orderStatus,
          paymentConfirmedAt: order.paymentConfirmedAt?.toISOString(),
          packedAt: order.packedAt?.toISOString(),
          assignedAt: order.assignedAt?.toISOString(),
          shippedAt: order.shippedAt?.toISOString(),
          deliveredAt: order.deliveredAt?.toISOString(),
          cancelledAt: order.cancelledAt?.toISOString(),
          createdAt: order.createdAt.toISOString(),
          updatedAt: order.updatedAt.toISOString(),
        };
    });

    return {
      success: true,
      message: 'Orders retrieved successfully',
      orders: ordersResponse,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    console.error('Error in GetOrders service:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Failed to retrieve orders',
    };
  }
};
