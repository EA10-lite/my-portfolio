import mongoose from 'mongoose';
import { Order } from '../../models/order.model';
import { Product } from '../../models/product.model';
import { User } from '../../models/user.model';
import { ShippingFee } from '../../models/shippingFee.model';

interface OrderItem {
  productId: string;
  quantity: number;
  price: number;
  variants?: string[];
  colors?: string[];
  sizes?: string[];
}

interface CreateOrderData {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: {
    street: string;
    state: string;
    lga: string;
  };
  paymentMethod: string;
  paymentReference?: string;
  items: OrderItem[];
}

const calculateShippingFeeInternal = async (state: string, lga: string): Promise<number | null> => {
  if (lga) {
    const exactMatch = await ShippingFee.findOne({
      state: new RegExp(`^${state}$`, 'i'),
      lga: new RegExp(`^${lga}$`, 'i'),
      isActive: true,
    });
    if (exactMatch) return exactMatch.fee;
  }

  const stateMatch = await ShippingFee.findOne({
    state: new RegExp(`^${state}$`, 'i'),
    $or: [{ lga: { $exists: false } }, { lga: null }, { lga: '' }],
    isActive: true,
  });
  if (stateMatch) return stateMatch.fee;

  const defaultMatch = await ShippingFee.findOne({
    isDefault: true,
    isActive: true,
  });
  if (defaultMatch) return defaultMatch.fee;

  return null;
};

export const CreateOrder = async (
  orderData: CreateOrderData,
  customerId?: string
): Promise<{
  success: boolean;
  message: string;
  order?: any;
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    const {
      customerName,
      customerEmail,
      customerPhone,
      deliveryAddress,
      paymentMethod,
      paymentReference,
      items
    } = orderData;

    if (!items || items.length === 0) {
      return { success: false, message: 'Order must contain at least one item.' };
    }

    if (!deliveryAddress || !deliveryAddress.state || !deliveryAddress.lga) {
      return { success: false, message: 'Complete delivery address (state and LGA) is required.' };
    }

    const calculatedFee = await calculateShippingFeeInternal(deliveryAddress.state, deliveryAddress.lga);
    if (calculatedFee === null) {
      return { success: false, message: 'Shipping is not available for the selected location.' };
    }

    // Determine actual customerId (link to existing customer if email matches)
    let finalCustomerId = customerId;
    if (!finalCustomerId) {
      const existingUser = await User.findOne({ email: customerEmail.toLowerCase(), role: 'customer' });
      if (existingUser) {
        finalCustomerId = existingUser._id.toString();
      }
    }

    let totalExpectedAmount = 0;
    const validatedProducts = [];

    // Verify all products exist and have sufficient stock
    for (const item of items) {
      const product = await Product.findById(item.productId);
      if (!product) {
        return { success: false, message: `Product not found: ${item.productId}` };
      }

      if (product.stock < item.quantity) {
        return { success: false, message: `Insufficient stock for ${product.name}. Available: ${product.stock}` };
      }

      totalExpectedAmount += item.price * item.quantity;
      validatedProducts.push({ product, item });
    }

    // Determine initial status based on payment method and verify Paystack
    let paymentStatus = 'pending';

    // Distribute shipping fee across items, or just add it to the first item.
    // For simplicity, we add the full shipping fee to the first order record.
    const createdOrders = [];
    
    for (let i = 0; i < validatedProducts.length; i++) {
      const { product, item } = validatedProducts[i];
      const itemSubtotal = item.price * item.quantity;
      
      // Apply the shipping fee to the first order to avoid charging multiple times
      const appliedShippingFee = i === 0 ? calculatedFee : 0;
      const total = itemSubtotal + appliedShippingFee;

      const newOrder = new Order({
        customerId: finalCustomerId ? new mongoose.Types.ObjectId(finalCustomerId) : undefined,
        customerName,
        customerEmail: customerEmail.toLowerCase(),
        customerPhone,
        productId: new mongoose.Types.ObjectId(item.productId),
        quantity: item.quantity,
        price: item.price,
        shippingFee: appliedShippingFee,
        total,
        variants: item.variants || [],
        colors: item.colors || [],
        sizes: item.sizes || [],
        deliveryAddress,
        paymentMethod,
        paymentStatus,
        paymentReference,
        orderStatus: 'pending',
        paymentConfirmedAt: paymentStatus === 'paid' ? new Date() : undefined,
      });

      await newOrder.save();
      createdOrders.push(newOrder.toObject());

      // Update product stock and sales
      product.stock -= item.quantity;
      product.sales += item.quantity;
      
      if (product.stock <= 0) {
        product.stock = 0;
        product.status = 'out_of_stock';
      }
      
      await product.save();
    }

    return {
      success: true,
      message: 'Order created successfully',
      order: createdOrders,
    };
  } catch (error) {
    console.error('Error in CreateOrder service:', error);
    return { success: false, message: 'Failed to create order' };
  }
};
