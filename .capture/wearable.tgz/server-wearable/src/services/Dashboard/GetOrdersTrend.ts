import mongoose from 'mongoose';
import { Order } from '../../models/order.model';

export const GetOrdersTrend = async (): Promise<{
  success: boolean;
  message: string;
  data?: any[];
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    const now = new Date();
    const fourWeeksAgo = new Date(now);
    fourWeeksAgo.setDate(now.getDate() - 28);

    const data = await Order.aggregate([
      { 
        $match: { 
          createdAt: { $gte: fourWeeksAgo } 
        } 
      },
      {
        $group: {
          _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } },
          orders: { $sum: 1 }
        }
      },
      { $sort: { "_id": 1 } }
    ]);

    const formattedData = data.map(item => ({
      date: item._id,
      orders: item.orders
    }));

    return {
      success: true,
      message: 'Orders trend retrieved successfully',
      data: formattedData,
    };
  } catch (error) {
    console.error('Error in GetOrdersTrend service:', error);
    return { success: false, message: 'Failed to retrieve orders trend' };
  }
};
