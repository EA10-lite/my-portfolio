import mongoose from 'mongoose';
import { Order } from '../../models/order.model';

export const GetSalesData = async (timeFilter: string): Promise<{
  success: boolean;
  message: string;
  data?: any[];
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    const match: any = { orderStatus: { $ne: 'cancelled' } };
    const now = new Date();
    
    let groupBy: any = {};
    let sort: any = {};
    
    if (timeFilter === 'last7days') {
      const sevenDaysAgo = new Date(now);
      sevenDaysAgo.setDate(now.getDate() - 7);
      match.createdAt = { $gte: sevenDaysAgo };
      groupBy = { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } };
      sort = { "_id": 1 };
    } else if (timeFilter === 'last1month') {
      const oneMonthAgo = new Date(now);
      oneMonthAgo.setMonth(now.getMonth() - 1);
      match.createdAt = { $gte: oneMonthAgo };
      groupBy = { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } };
      sort = { "_id": 1 };
    } else { // last12months
      const twelveMonthsAgo = new Date(now);
      twelveMonthsAgo.setMonth(now.getMonth() - 12);
      match.createdAt = { $gte: twelveMonthsAgo };
      groupBy = { $dateToString: { format: "%Y-%m", date: "$createdAt" } };
      sort = { "_id": 1 };
    }

    const salesData = await Order.aggregate([
      { $match: match },
      {
        $group: {
          _id: groupBy,
          sales: { $sum: '$total' }
        }
      },
      { $sort: sort }
    ]);

    const formattedData = salesData.map(item => ({
      period: item._id,
      sales: item.sales
    }));

    return {
      success: true,
      message: 'Sales data retrieved successfully',
      data: formattedData,
    };
  } catch (error) {
    console.error('Error in GetSalesData service:', error);
    return { success: false, message: 'Failed to retrieve sales data' };
  }
};
