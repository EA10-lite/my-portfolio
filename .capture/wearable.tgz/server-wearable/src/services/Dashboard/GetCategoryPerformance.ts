import mongoose from 'mongoose';
import { Order } from '../../models/order.model';

export const GetCategoryPerformance = async (): Promise<{
  success: boolean;
  message: string;
  data?: any[];
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    const data = await Order.aggregate([
      { $match: { orderStatus: { $ne: 'cancelled' } } },
      {
        $lookup: {
          from: 'products',
          localField: 'productId',
          foreignField: '_id',
          as: 'product'
        }
      },
      { $unwind: '$product' },
      {
        $group: {
          _id: '$product.category',
          revenue: { $sum: '$total' },
          orderCount: { $sum: 1 }
        }
      },
      { $sort: { revenue: -1 } }
    ]);

    const formattedData = data.map(item => ({
      category: item._id,
      revenue: item.revenue,
      orderCount: item.orderCount
    }));

    return {
      success: true,
      message: 'Category performance retrieved successfully',
      data: formattedData,
    };
  } catch (error) {
    console.error('Error in GetCategoryPerformance service:', error);
    return { success: false, message: 'Failed to retrieve category performance' };
  }
};
