import mongoose from 'mongoose';
import { Order } from '../../models/order.model';
import { User } from '../../models/user.model';

export const GetDashboardStats = async (): Promise<{
  success: boolean;
  message: string;
  stats?: any;
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const [
      totalOrders,
      totalRevenueData,
      statusCounts,
      paymentCounts,
      totalCustomers,
      newCustomers,
    ] = await Promise.all([
      Order.countDocuments(),
      Order.aggregate([
        { $match: { orderStatus: { $ne: 'cancelled' } } },
        { $group: { _id: null, total: { $sum: '$total' } } }
      ]),
      Order.aggregate([
        { $group: { _id: '$orderStatus', count: { $sum: 1 } } }
      ]),
      Order.aggregate([
        { $group: { _id: '$paymentStatus', count: { $sum: 1 } } }
      ]),
      User.countDocuments({ role: 'customer' }),
      User.countDocuments({ role: 'customer', createdAt: { $gte: thirtyDaysAgo } })
    ]);

    const totalRevenue = totalRevenueData.length > 0 ? totalRevenueData[0].total : 0;

    const statsMap: Record<string, number> = {};
    statusCounts.forEach((status) => {
      statsMap[status._id] = status.count;
    });

    const paymentMap: Record<string, number> = {};
    paymentCounts.forEach((status) => {
      paymentMap[status._id] = status.count;
    });

    const stats = {
      totalOrders,
      totalRevenue,
      pendingOrders: statsMap['pending'] || 0,
      processingOrders: statsMap['processing'] || 0,
      deliveredOrders: statsMap['delivered'] || 0,
      cancelledOrders: statsMap['cancelled'] || 0,
      paidOrders: paymentMap['paid'] || 0,
      unpaidOrders: paymentMap['pending'] || 0,
      totalCustomers,
      newCustomers,
    };

    return {
      success: true,
      message: 'Dashboard stats retrieved successfully',
      stats,
    };
  } catch (error) {
    console.error('Error in GetDashboardStats service:', error);
    return { success: false, message: 'Failed to retrieve dashboard stats' };
  }
};
