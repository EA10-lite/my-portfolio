import mongoose from 'mongoose';
import { User } from '../../models/user.model';
import { Order } from '../../models/order.model';

export interface CustomerDetails {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  isVerified: boolean;
  isBlocked: boolean;
  createdAt: string;
  orders: any[]; // Detailed orders
  stats: {
    totalOrders: number;
    totalSpend: number;
    cancelledOrders: number;
  };
}

export const GetCustomerById = async (customerId: string): Promise<{
  success: boolean;
  message: string;
  customer?: CustomerDetails;
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return { success: false, message: 'Invalid customer ID format' };
    }

    // Find the user with role customer
    const user = await User.findOne({ _id: customerId, role: 'customer' }).lean();

    if (!user) {
      return { success: false, message: 'Customer not found' };
    }

    // Get all orders for this customer
    const orders = await Order.find({ customerId: user._id })
      .sort({ createdAt: -1 })
      .populate('productId', 'name images') // Populate basic product details if needed
      .lean();

    // Calculate stats
    let totalSpend = 0;
    let cancelledOrders = 0;

    const formattedOrders = orders.map((order: any) => {
      if (order.orderStatus !== 'cancelled') {
        totalSpend += order.total;
      } else {
        cancelledOrders++;
      }

      return {
        id: order._id.toString(),
        productId: order.productId?._id?.toString() || order.productId?.toString(),
        productName: order.productId?.name || 'Unknown Product',
        productImage: order.productId?.images?.[0]?.url || null,
        quantity: order.quantity,
        price: order.price,
        total: order.total,
        status: order.orderStatus,
        paymentStatus: order.paymentStatus,
        createdAt: order.createdAt.toISOString(),
      };
    });

    const customerDetails: CustomerDetails = {
      id: user._id.toString(),
      name: user.name || 'Unknown',
      email: user.email,
      phone: user.phone,
      address: user.address, // Added earlier
      isVerified: user.isVerified,
      isBlocked: user.isBlocked || false,
      createdAt: user.createdAt.toISOString(),
      orders: formattedOrders,
      stats: {
        totalOrders: orders.length,
        totalSpend,
        cancelledOrders,
      },
    };

    return {
      success: true,
      message: 'Customer details retrieved successfully',
      customer: customerDetails,
    };
  } catch (error) {
    console.error('Error in GetCustomerById service:', error);
    return { success: false, message: 'Failed to retrieve customer details' };
  }
};
