import mongoose from 'mongoose';
import { User } from '../../models/user.model';
import { Order } from '../../models/order.model';

export interface CustomerSummary {
  id: string;
  name: string;
  email: string;
  phone?: string;
  address?: string;
  isVerified: boolean;
  isBlocked: boolean;
  orderCount: number;
  totalSpend: number;
  createdAt: string;
}

interface GetCustomersOptions {
  page?: number;
  limit?: number;
  search?: string;
  status?: 'active' | 'blocked' | 'all';
}

export const GetCustomers = async (options: GetCustomersOptions = {}): Promise<{
  success: boolean;
  message: string;
  customers?: CustomerSummary[];
  pagination?: { page: number; limit: number; total: number; pages: number };
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    const page = options.page || 1;
    const limit = options.limit || 20;
    const skip = (page - 1) * limit;

    // Build customer query (users with role=customer)
    const query: Record<string, unknown> = { role: 'customer' };

    if (options.search?.trim()) {
      const term = options.search.trim();
      query.$or = [
        { email: { $regex: term, $options: 'i' } },
        { name: { $regex: term, $options: 'i' } },
      ];
    }

    if (options.status === 'active') query.isBlocked = false;
    else if (options.status === 'blocked') query.isBlocked = true;

    const [total, customers] = await Promise.all([
      User.countDocuments(query),
      User.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
    ]);

    // Aggregate order stats per customer in one query
    const customerIds = customers.map((c) => c._id);
    const orderStats = await Order.aggregate([
      { $match: { customerId: { $in: customerIds } } },
      {
        $group: {
          _id: '$customerId',
          orderCount: { $sum: 1 },
          totalSpend: { $sum: '$total' },
        },
      },
    ]);

    const statsMap = new Map(
      orderStats.map((s) => [s._id.toString(), { orderCount: s.orderCount, totalSpend: s.totalSpend }])
    );

    const customerList: CustomerSummary[] = customers.map((c) => {
      const stats = statsMap.get(c._id.toString()) || { orderCount: 0, totalSpend: 0 };
      return {
        id: c._id.toString(),
        name: c.name || 'Unknown',
        email: c.email,
        phone: c.phone,
        address: c.address,
        isVerified: c.isVerified,
        isBlocked: c.isBlocked || false,
        orderCount: stats.orderCount,
        totalSpend: stats.totalSpend,
        createdAt: c.createdAt.toISOString(),
      };
    });

    return {
      success: true,
      message: 'Customers retrieved successfully',
      customers: customerList,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    };
  } catch (error) {
    console.error('Error in GetCustomers service:', error);
    return { success: false, message: 'Failed to retrieve customers' };
  }
};
