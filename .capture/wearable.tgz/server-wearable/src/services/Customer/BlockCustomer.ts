import mongoose from 'mongoose';
import { User } from '../../models/user.model';

export const BlockCustomer = async (
  customerId: string,
  block: boolean
): Promise<{
  success: boolean;
  message: string;
}> => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return { success: false, message: 'Database connection not available.' };
    }

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return { success: false, message: 'Invalid customer ID format' };
    }

    // Find and update the user
    const user = await User.findOneAndUpdate(
      { _id: customerId, role: 'customer' },
      { $set: { isBlocked: block } },
      { new: true }
    );

    if (!user) {
      return { success: false, message: 'Customer not found' };
    }

    return {
      success: true,
      message: `Customer successfully ${block ? 'blocked' : 'unblocked'}`,
    };
  } catch (error) {
    console.error('Error in BlockCustomer service:', error);
    return {
      success: false,
      message: `Failed to ${block ? 'block' : 'unblock'} customer`,
    };
  }
};
