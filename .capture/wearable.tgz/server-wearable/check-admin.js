const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config({ path: './.env' });

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const db = mongoose.connection.useDb('wearable');
  const users = await mongoose.connection.collection('users').find({ email: 'admin@wearable.com' }).toArray();
  console.log('Admin user found:', users.length);
  if (users.length > 0) {
    console.log('Role:', users[0].role);
    console.log('Password hash:', users[0].password ? 'Exists' : 'Missing');
  }
  process.exit(0);
}).catch(err => {
  console.error(err);
  process.exit(1);
});
