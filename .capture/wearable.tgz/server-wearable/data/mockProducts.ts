// @ts-nocheck

import path from 'path';
import fs from 'fs';

/**
 * Mock Product Data Interface
 * Represents product data before upload to Cloudinary and MongoDB
 */
export interface MockProductData {
  name: string;
  description: string;
  category: string;
  subCategory?: string;
  colors: string[];
  sizes: string[];
  variants: string[];
  price: number;
  discountPrice: number;
  samePriceForAllSizes: boolean;
  variantsPrice: number[];
  stock: number;
  imagePath: string; // Local path to the image file
}

/**
 * Generate unique product name from image filename
 * @param filename - Image filename (e.g., "male-shirt-1.jpeg")
 * @param category - Product category (male, female, accessories, footwear)
 * @param subCategory - Product subcategory
 * @returns Unique, descriptive product name
 */
const generateProductName = (filename: string, category: string, subCategory?: string): string => {
  const nameWithoutExt = filename.replace(/\.(jpeg|jpg|png)$/i, '');
  const parts = nameWithoutExt.split('-');
  const productNumber = parseInt(parts[parts.length - 1]) || 1;
  
  // Name variations organized by category and subcategory
  const nameVariations: Record<string, Record<string, string[]>> = {
    male: {
      'shirt': [
        'Classic Oxford Button-Down Shirt',
        'Premium Cotton Dress Shirt',
        'Slim Fit Formal Shirt',
        'Casual Linen Shirt',
        'Denim Work Shirt',
        'Plaid Flannel Shirt',
        'Striped Business Shirt',
        'Short Sleeve Poplin Shirt',
        'Long Sleeve Chambray Shirt',
        'Relaxed Fit Comfort Shirt',
        'Tailored Fit Dress Shirt',
        'Vintage Style Shirt',
        'Modern Fit Cotton Shirt',
        'Classic White Dress Shirt',
        'Navy Blue Business Shirt',
        'Patterned Casual Shirt',
        'Breathable Summer Shirt',
        'Wrinkle-Free Professional Shirt',
        'Textured Fabric Shirt',
        'Contemporary Fit Shirt',
        'Heritage Style Shirt',
        'Premium Quality Shirt',
        'Elegant Formal Shirt',
        'Everyday Essential Shirt',
        'Sophisticated Dress Shirt',
        'Comfort Fit Shirt',
        'Professional Business Shirt',
        'Stylish Casual Shirt',
        'Refined Classic Shirt',
        'Modern Professional Shirt',
        'Timeless Design Shirt',
        'Premium Fabric Shirt',
      ],
      't-shirt': [
        'Classic Cotton T-Shirt',
        'Premium Soft T-Shirt',
        'V-Neck Comfort T-Shirt',
        'Crew Neck Basic T-Shirt',
        'Oversized Relaxed T-Shirt',
        'Slim Fit Modern T-Shirt',
        'Graphic Print T-Shirt',
        'Striped Pattern T-Shirt',
        'Solid Color Essential T-Shirt',
        'Pocket Detail T-Shirt',
        'Long Sleeve Classic T-Shirt',
        'Short Sleeve Casual T-Shirt',
        'Breathable Sport T-Shirt',
        'Moisture Wicking T-Shirt',
        'Organic Cotton T-Shirt',
        'Heavy Weight T-Shirt',
        'Lightweight Summer T-Shirt',
        'Fitted Style T-Shirt',
        'Relaxed Fit T-Shirt',
        'Ribbed Collar T-Shirt',
        'Tagless Comfort T-Shirt',
        'Pre-Shrunk T-Shirt',
        'Color Block T-Shirt',
        'Tie-Dye Pattern T-Shirt',
        'Minimalist Design T-Shirt',
        'Bold Statement T-Shirt',
        'Layering Essential T-Shirt',
        'Everyday Basic T-Shirt',
        'Premium Quality T-Shirt',
        'Eco-Friendly T-Shirt',
        'Performance Athletic T-Shirt',
        'Fashion Forward T-Shirt',
      ],
      'pant': [
        'Thick Baggy Jeans',
        'Light Skinned Denim Jeans',
        'Premium Slim Fit Denim Jeans',
        'Classic Straight Leg Jeans',
        'Vintage Wash Blue Jeans',
        'Modern Relaxed Fit Jeans',
        'Distressed Faded Jeans',
        'Stretch Comfort Fit Jeans',
        'Dark Wash Premium Jeans',
        'Light Blue Casual Jeans',
        'Black Denim Skinny Jeans',
        'Ripped Style Fashion Jeans',
        'High Waist Classic Jeans',
        'Low Rise Comfort Jeans',
        'Wide Leg Trendy Jeans',
        'Tapered Fit Modern Jeans',
        'Raw Denim Premium Jeans',
        'Acid Wash Vintage Jeans',
        'Stone Washed Classic Jeans',
        'Indigo Blue Premium Jeans',
        'Relaxed Fit Everyday Jeans',
        'Slim Straight Denim Jeans',
        'Bootcut Style Jeans',
        'Cropped Ankle Jeans',
        'Oversized Baggy Jeans',
        'Skinny Fit Stretch Jeans',
        'Regular Fit Classic Jeans',
        'Athletic Fit Comfort Jeans',
        'Cargo Pocket Utility Jeans',
        'Patchwork Design Jeans',
        'Faded Blue Vintage Jeans',
        'Deep Indigo Premium Jeans',
      ],
      'short': [
        'Classic Cargo Shorts',
        'Athletic Performance Shorts',
        'Casual Chino Shorts',
        'Denim Cut-Off Shorts',
        'Linen Summer Shorts',
        'Cotton Comfort Shorts',
        'Bermuda Style Shorts',
        'Swim Trunk Shorts',
        'Basketball Athletic Shorts',
        'Khaki Casual Shorts',
        'Navy Blue Classic Shorts',
        'Black Formal Shorts',
        'Camo Pattern Shorts',
        'Plaid Design Shorts',
        'Striped Beach Shorts',
        'Quick-Dry Sport Shorts',
        'Relaxed Fit Shorts',
        'Slim Fit Tailored Shorts',
        'Pocket Detail Shorts',
        'Elastic Waist Shorts',
        'Drawstring Athletic Shorts',
        'High Waist Shorts',
        'Low Rise Casual Shorts',
        'Knee Length Shorts',
        'Above Knee Shorts',
        'Wide Leg Shorts',
        'Tapered Fit Shorts',
        'Stretch Comfort Shorts',
        'Lightweight Summer Shorts',
        'Heavy Duty Work Shorts',
        'Fashion Forward Shorts',
        'Vintage Style Shorts',
      ],
    },
    female: {
      'dress': [
        'Elegant Floral Summer Dress',
        'Classic A-Line Dress',
        'Modern Midi Dress',
        'Casual Maxi Dress',
        'Formal Evening Dress',
        'Bohemian Style Dress',
        'Bodycon Fit Dress',
        'Wrap Style Dress',
        'Shift Dress',
        'Sundress',
        'Cocktail Dress',
        'Office Professional Dress',
        'Vintage Inspired Dress',
        'Contemporary Fit Dress',
        'Flowing Maxi Dress',
        'Structured Sheath Dress',
        'Ruffled Detail Dress',
        'Off-Shoulder Dress',
        'V-Neck Elegant Dress',
        'High-Low Hem Dress',
        'Printed Pattern Dress',
        'Solid Color Classic Dress',
        'Lace Detail Dress',
        'Chiffon Flowing Dress',
        'Cotton Casual Dress',
        'Silk Elegant Dress',
        'Knit Comfort Dress',
        'Denim Casual Dress',
        'Floral Print Dress',
        'Striped Pattern Dress',
        'Polka Dot Dress',
        'Geometric Print Dress',
      ],
      'skirt': [
        'Classic A-Line Skirt',
        'Pencil Fit Skirt',
        'Pleated Midi Skirt',
        'Flared Maxi Skirt',
        'Mini Skirt',
        'Wrap Style Skirt',
        'Denim Casual Skirt',
        'Formal Pencil Skirt',
        'Floral Print Skirt',
        'Solid Color Skirt',
        'High Waist Skirt',
        'Button Detail Skirt',
        'Ruffled Hem Skirt',
        'Tiered Skirt',
        'Asymmetric Hem Skirt',
        'Leather Style Skirt',
        'Cotton Comfort Skirt',
        'Chiffon Flowing Skirt',
        'Knit Stretch Skirt',
        'Patterned Skirt',
        'Classic Black Skirt',
        'Navy Blue Skirt',
        'Belted Waist Skirt',
        'Elastic Waist Skirt',
        'Zipper Detail Skirt',
        'Pocket Detail Skirt',
        'Lace Trim Skirt',
        'Ribbed Texture Skirt',
        'Satin Finish Skirt',
        'Casual Denim Skirt',
        'Formal Business Skirt',
        'Summer Floral Skirt',
      ],
      'leggings': [
        'High Waist Yoga Leggings',
        'Classic Black Leggings',
        'Athletic Performance Leggings',
        'Comfort Fit Leggings',
        'Compression Leggings',
        'Pocket Detail Leggings',
        'Patterned Leggings',
        'Solid Color Leggings',
        'Cropped Ankle Leggings',
        'Full Length Leggings',
        'Stretch Comfort Leggings',
        'Moisture Wicking Leggings',
        'Breathable Fabric Leggings',
        'Seamless Leggings',
        'Ribbed Texture Leggings',
        'Mesh Detail Leggings',
        'Printed Pattern Leggings',
        'Classic Fit Leggings',
        'Slim Fit Leggings',
        'Relaxed Fit Leggings',
        'Athletic Style Leggings',
        'Casual Everyday Leggings',
        'Premium Quality Leggings',
        'Eco-Friendly Leggings',
        'Performance Leggings',
        'Fashion Forward Leggings',
        'Comfort Stretch Leggings',
        'Versatile Leggings',
        'Classic Black Leggings',
        'Navy Blue Leggings',
        'Gray Comfort Leggings',
        'Patterned Style Leggings',
      ],
    },
    accessories: {
      'watch': [
        'Classic Leather Strap Watch',
        'Stainless Steel Watch',
        'Digital Sport Watch',
        'Elegant Dress Watch',
        'Chronograph Watch',
        'Minimalist Design Watch',
        'Luxury Timepiece',
        'Water Resistant Watch',
        'Smart Watch',
        'Vintage Style Watch',
        'Modern Contemporary Watch',
        'Rose Gold Watch',
        'Silver Tone Watch',
        'Black Dial Watch',
        'White Dial Watch',
        'Chronograph Function Watch',
        'Automatic Movement Watch',
        'Quartz Precision Watch',
        'Leather Band Watch',
        'Metal Band Watch',
        'Silicone Band Watch',
        'Mesh Band Watch',
        'Nylon Band Watch',
        'Classic Round Watch',
        'Square Face Watch',
        'Oversized Watch',
        'Slim Profile Watch',
        'Luminous Hands Watch',
        'Date Display Watch',
        'Multi-Function Watch',
        'Elegant Formal Watch',
        'Casual Everyday Watch',
      ],
      'jewelry': [
        'Sterling Silver Necklace',
        'Gold Plated Bracelet',
        'Pearl Drop Earrings',
        'Diamond Stud Earrings',
        'Rose Gold Ring',
        'Classic Chain Necklace',
        'Pendant Necklace',
        'Charm Bracelet',
        'Hoop Earrings',
        'Statement Necklace',
        'Delicate Anklet',
        'Tennis Bracelet',
        'Choker Necklace',
        'Layered Necklace',
        'Cuff Bracelet',
        'Bangle Set',
        'Ear Cuff',
        'Nose Ring',
        'Body Chain',
        'Anklet Chain',
        'Toe Ring',
        'Hair Accessory',
        'Brooch Pin',
        'Cameo Pendant',
        'Locket Necklace',
        'Cross Pendant',
        'Heart Pendant',
        'Initial Pendant',
        'Birthstone Ring',
        'Engagement Style Ring',
        'Wedding Band',
        'Promise Ring',
      ],
      'bag': [
        'Leather Crossbody Bag',
        'Classic Tote Bag',
        'Designer Handbag',
        'Shoulder Bag',
        'Backpack Style Bag',
        'Clutch Purse',
        'Messenger Bag',
        'Satchel Bag',
        'Hobo Bag',
        'Bucket Bag',
        'Saddle Bag',
        'Belt Bag',
        'Waist Bag',
        'Evening Clutch',
        'Beach Tote Bag',
        'Gym Bag',
        'Travel Bag',
        'Laptop Bag',
        'Briefcase Style Bag',
        'Duffel Bag',
        'Weekend Bag',
        'Cosmetic Bag',
        'Coin Purse',
        'Wallet',
        'Card Holder',
        'Phone Case Bag',
        'Mini Bag',
        'Oversized Tote',
        'Structured Handbag',
        'Soft Leather Bag',
        'Canvas Tote Bag',
        'Vegan Leather Bag',
      ],
    },
    footwear: {
      'shoe': [
        'Classic Leather Dress Shoes',
        'Casual Sneakers',
        'Running Athletic Shoes',
        'Comfort Walking Shoes',
        'Formal Oxford Shoes',
        'Loafers',
        'Boat Shoes',
        'Canvas Sneakers',
        'Leather Boots',
        'Ankle Boots',
        'High Top Sneakers',
        'Low Top Sneakers',
        'Slip-On Shoes',
        'Lace-Up Shoes',
        'Velcro Closure Shoes',
        'Platform Shoes',
        'Wedge Heel Shoes',
        'Flat Comfort Shoes',
        'Athletic Training Shoes',
        'Basketball Shoes',
        'Tennis Shoes',
        'Golf Shoes',
        'Hiking Boots',
        'Work Boots',
        'Fashion Sneakers',
        'Designer Shoes',
        'Casual Slip-Ons',
        'Formal Pumps',
        'Ballet Flats',
        'Mary Jane Shoes',
        'Espadrilles',
        'Moccasins',
      ],
      'boot': [
        'Classic Leather Boots',
        'Ankle Boots',
        'Knee High Boots',
        'Combat Boots',
        'Chelsea Boots',
        'Hiking Boots',
        'Work Boots',
        'Rain Boots',
        'Winter Boots',
        'Cowboy Boots',
        'Riding Boots',
        'Fashion Boots',
        'Lace-Up Boots',
        'Zipper Boots',
        'Pull-On Boots',
        'Steel Toe Boots',
        'Waterproof Boots',
        'Insulated Boots',
        'Hiking Style Boots',
        'Casual Boots',
        'Formal Boots',
        'Motorcycle Boots',
        'Combat Style Boots',
        'Desert Boots',
        'Chukka Boots',
        'Timberland Style Boots',
        'Fashion Forward Boots',
        'Classic Black Boots',
        'Brown Leather Boots',
        'Tan Boots',
        'Navy Blue Boots',
        'Gray Boots',
      ],
      'sandals': [
        'Classic Flip Flops',
        'Leather Sandals',
        'Sport Sandals',
        'Gladiator Sandals',
        'Slide Sandals',
        'Ankle Strap Sandals',
        'Toe Post Sandals',
        'Wedge Sandals',
        'Flat Sandals',
        'Platform Sandals',
        'Hiking Sandals',
        'Water Sandals',
        'Beach Sandals',
        'Casual Sandals',
        'Formal Sandals',
        'Elegant Sandals',
        'Comfort Sandals',
        'Orthopedic Sandals',
        'Fashion Sandals',
        'Designer Sandals',
        'Leather Strap Sandals',
        'Rubber Sole Sandals',
        'Cork Sole Sandals',
        'EVA Foam Sandals',
        'Adjustable Strap Sandals',
        'Buckle Closure Sandals',
        'Velcro Sandals',
        'Slip-On Sandals',
        'Thong Sandals',
        'Fisherman Sandals',
        'Roman Sandals',
        'Greek Style Sandals',
      ],
    },
  };
  
  // Get name variations for the category and subcategory
  const categoryVariations = nameVariations[category];
  if (!categoryVariations) {
    // Fallback if category not found
    const categoryDisplay = category.charAt(0).toUpperCase() + category.slice(1);
    return `${categoryDisplay} Product ${productNumber}`;
  }
  
  const subCategoryKey = subCategory || 'default';
  const variations = categoryVariations[subCategoryKey] || categoryVariations[Object.keys(categoryVariations)[0]];
  
  if (!variations || variations.length === 0) {
    // Fallback if no variations found
    const categoryDisplay = category.charAt(0).toUpperCase() + category.slice(1);
    const subCategoryDisplay = subCategory 
      ? subCategory.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
      : '';
    return subCategoryDisplay 
      ? `${categoryDisplay} ${subCategoryDisplay} ${productNumber}`
      : `${categoryDisplay} Product ${productNumber}`;
  }
  
  // Use product number to select a variation (cycle through if more products than variations)
  const selectedName = variations[(productNumber - 1) % variations.length];
  
  return selectedName;
};

/**
 * Generate unique product description based on category and product name
 * @param category - Product category
 * @param name - Product name
 * @param filename - Original filename to get product number
 * @param subCategory - Product subcategory
 * @returns Unique, detailed product description
 */
const generateDescription = (category: string, name: string, filename: string, subCategory?: string): string => {
  const nameWithoutExt = filename.replace(/\.(jpeg|jpg|png)$/i, '');
  const parts = nameWithoutExt.split('-');
  const productNumber = parseInt(parts[parts.length - 1]) || 1;
  
  // Generic description templates that work for all categories
  const genericTemplates: string[] = [
    `Experience ultimate comfort with this ${name}. Crafted from premium materials with attention to detail in every aspect. Features a modern design that combines style and functionality. The thoughtful construction ensures durability and comfort for everyday wear. Available in multiple colors and sizes to match your personal style.`,
    `Elevate your wardrobe with this ${name}. Made from high-quality materials that offer excellent durability and comfort. The versatile design transitions seamlessly from casual to semi-formal occasions. Perfect for those who value both style and substance in their fashion choices. Choose from various colors and sizes to find your perfect match.`,
    `Discover the perfect balance of style and comfort with this ${name}. Constructed from carefully selected materials that maintain their quality over time. The contemporary design offers a flattering fit while ensuring all-day comfort. Ideal for various settings and occasions. Multiple color and size options available.`,
    `Step up your fashion game with this ${name}. Featuring premium construction with attention to detail in every stitch. The comfortable fit adapts to your body, while the timeless design ensures it never goes out of style. Whether you're running errands or attending social events, this piece delivers. Available in an array of colors and sizes.`,
    `Indulge in premium quality with this ${name}. Made from carefully selected materials that offer both durability and comfort. The modern design incorporates current fashion trends while maintaining classic appeal. Perfect for those who value both style and substance in their wardrobe essentials. Select from multiple color and size combinations.`,
  ];
  
  // Use product number to select a description template (cycle through if more products than templates)
  const selectedDescription = genericTemplates[(productNumber - 1) % genericTemplates.length];
  
  return selectedDescription;
};

/**
 * Get subcategories for a given category
 * @param category - Main category (male, female, accessories, footwear)
 * @returns Array of subcategory options
 */
const getSubCategories = (category: string): string[] => {
  const subCategories: Record<string, string[]> = {
    male: ['shirt', 't-shirt', 'pant', 'short'],
    female: ['dress', 'skirt', 'leggings'],
    accessories: ['watch', 'jewelry', 'bag'],
    footwear: ['shoe', 'boot', 'sandals'],
  };
  
  return subCategories[category] || [];
};

/**
 * Get default product data based on category
 * Prices are in Nigerian Naira (NGN)
 * @param category - Product category (male, female, accessories, footwear)
 * @param subCategory - Product subcategory
 * @returns Default product configuration
 */
const getCategoryDefaults = (category: string, subCategory?: string) => {
  const defaults: Record<string, {
    colors: string[];
    sizes: string[];
    price: number;
    discountPrice: number;
  }> = {
    male: {
      colors: ['Blue', 'Black', 'Navy', 'Gray', 'White'],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      // Prices in Naira: ~80,000 - 150,000 NGN range
      price: 120000,
      discountPrice: 95000,
    },
    female: {
      colors: ['Black', 'Pink', 'White', 'Red', 'Blue'],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      // Prices in Naira: ~70,000 - 130,000 NGN range
      price: 100000,
      discountPrice: 80000,
    },
    accessories: {
      colors: ['Black', 'Silver', 'Gold', 'Brown', 'Gray'],
      sizes: ['One Size'], // Most accessories are one size
      // Prices in Naira: ~50,000 - 200,000 NGN range
      price: 85000,
      discountPrice: 65000,
    },
    footwear: {
      colors: ['Black', 'Brown', 'White', 'Navy', 'Gray'],
      sizes: ['38', '39', '40', '41', '42', '43', '44'],
      // Prices in Naira: ~100,000 - 250,000 NGN range
      price: 150000,
      discountPrice: 120000,
    },
  };
  
  return defaults[category] || {
    colors: ['Black', 'White', 'Gray'],
    sizes: ['S', 'M', 'L', 'XL'],
    price: 60000,
    discountPrice: 48000,
  };
};

/**
 * Generate mock product data from image files
 * @param productsDir - Path to the products directory
 * @returns Array of mock product data
 */
export const generateMockProducts = (productsDir: string): MockProductData[] => {
  const mockProducts: MockProductData[] = [];
  
  // Check if products directory exists
  if (!fs.existsSync(productsDir)) {
    throw new Error(`Products directory not found: ${productsDir}`);
  }
  
  // Read all files in the products directory
  const files = fs.readdirSync(productsDir);
  
  // Filter image files and group by category
  const imageFiles = files.filter(file => 
    /\.(jpeg|jpg|png)$/i.test(file)
  );
  
  // Process each image file
  imageFiles.forEach((file) => {
    const filePath = path.join(productsDir, file);
    const filenameWithoutExt = file.replace(/\.(jpeg|jpg|png)$/i, '');
    const parts = filenameWithoutExt.split('-');
    
    // Extract category (first part)
    let category = parts[0]?.toLowerCase();
    
    // Map old category names to new ones for backward compatibility
    const categoryMapping: Record<string, string> = {
      'jeans': 'male',      // Jeans are typically male category
      'short': 'male',      // Shorts are typically male category
      'tshirt': 'male',     // T-shirts are typically male category
      'shorts': 'male',     // Alternative spelling
      't-shirt': 'male',    // Alternative spelling
    };
    
    // Apply mapping if needed
    if (categoryMapping[category]) {
      category = categoryMapping[category];
    }
    
    // Skip if not a valid category
    if (!['male', 'female', 'accessories', 'footwear'].includes(category)) {
      console.warn(`Skipping file ${file}: Invalid category "${parts[0]}". Expected: male, female, accessories, or footwear`);
      return;
    }
    
    // Extract subcategory (second part) if available, otherwise map from old category names
    const subCategories = getSubCategories(category);
    let subCategory: string | undefined;
    
    // Map old category names to subcategories
    const oldCategoryToSubCategory: Record<string, string> = {
      'jeans': 'pant',      // Jeans map to pants subcategory
      'short': 'short',     // Shorts map to shorts subcategory
      'shorts': 'short',    // Alternative spelling
      'tshirt': 't-shirt',  // T-shirts map to t-shirt subcategory
      't-shirt': 't-shirt', // Alternative spelling
    };
    
    // Check if this is an old category name that needs mapping
    const originalCategory = parts[0]?.toLowerCase();
    if (oldCategoryToSubCategory[originalCategory]) {
      subCategory = oldCategoryToSubCategory[originalCategory];
    } else if (parts.length > 1 && parts[1]) {
      // Try to match the second part to a valid subcategory
      const potentialSubCategory = parts[1].toLowerCase();
      if (subCategories.some(sc => sc.toLowerCase() === potentialSubCategory)) {
        subCategory = potentialSubCategory;
      }
    }
    
    // If no valid subcategory found, assign one based on product number
    if (!subCategory && subCategories.length > 0) {
      const productNumber = parseInt(parts[parts.length - 1]) || 1;
      subCategory = subCategories[(productNumber - 1) % subCategories.length];
    }
    
    const name = generateProductName(file, category, subCategory);
    const description = generateDescription(category, name, file, subCategory);
    const defaults = getCategoryDefaults(category, subCategory);
    
    // Generate variants (color-size combinations)
    const variants: string[] = [];
    defaults.colors.forEach(color => {
      defaults.sizes.forEach(size => {
        variants.push(`${color}-${size}`);
      });
    });
    
    // Generate variant prices (same as base price for simplicity)
    const variantsPrice = variants.map(() => defaults.price);
    
    // Create mock product data
    const mockProduct: MockProductData = {
      name,
      description,
      category: category.toLowerCase(), // Store as lowercase: male, female, accessories, footwear
      subCategory: subCategory,
      colors: defaults.colors,
      sizes: defaults.sizes,
      variants,
      price: defaults.price,
      discountPrice: defaults.discountPrice,
      samePriceForAllSizes: true,
      variantsPrice,
      stock: Math.floor(Math.random() * 50) + 10, // Random stock between 10-60
      imagePath: filePath,
    };
    
    mockProducts.push(mockProduct);
  });
  
  return mockProducts;
};
