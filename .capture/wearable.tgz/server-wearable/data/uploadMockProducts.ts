// @ts-nocheck

// Load environment variables FIRST before importing modules that depend on them
import 'dotenv/config';

import path from 'path';
import fs from 'fs';
import mongoose from 'mongoose';
import cloudinary from '../src/config/cloudinary';
import { Product } from '../src/models/product.model';
import { generateMockProducts, MockProductData } from './mockProducts';
import { UploadApiResponse } from 'cloudinary';

/**
 * Upload a single image file to Cloudinary
 * @param imagePath - Local file path to the image
 * @param folder - Cloudinary folder path
 * @returns Promise with uploaded image URL and public ID
 */
const uploadImageFile = async (
  imagePath: string,
  folder: string = 'wearable/products'
): Promise<{ url: string; publicId: string }> => {
  return new Promise((resolve, reject) => {
    // Read the file as a buffer
    const fileBuffer = fs.readFileSync(imagePath);
    
    // Upload to Cloudinary using upload_stream
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder,
        resource_type: 'image',
        transformation: [
          { width: 1200, height: 1200, crop: 'limit', quality: 'auto' },
          { fetch_format: 'auto' },
        ],
      },
      (error, result: UploadApiResponse | undefined) => {
        if (error) {
          console.error(`Error uploading ${imagePath}:`, error);
          
          // Provide more helpful error messages based on error type
          let errorMessage = error.message || 'Unknown error';
          if (error.http_code === 401) {
            errorMessage = `Authentication failed: ${error.message}. Please verify your Cloudinary credentials (CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET) are correct and your account is active.`;
          } else if (error.http_code === 400) {
            errorMessage = `Invalid request: ${error.message}. Check that the image file is valid and Cloudinary settings are correct.`;
          }
          
          reject(new Error(`Failed to upload image ${imagePath}: ${errorMessage}`));
          return;
        }
        if (!result || !result.secure_url) {
          reject(new Error(`Failed to upload image ${imagePath}: No URL returned`));
          return;
        }
        resolve({
          url: result.secure_url,
          publicId: result.public_id,
        });
      }
    );

    // Write the buffer to the upload stream
    uploadStream.end(fileBuffer);
  });
};

/**
 * Upload mock products to Cloudinary and save to MongoDB
 * @param productsDir - Path to the products directory containing images
 * @param mongoUri - MongoDB connection URI
 * @returns Promise with upload results
 */
export const uploadMockProducts = async (
  productsDir?: string,
  mongoUri?: string
): Promise<{
  success: boolean;
  message: string;
  uploaded: number;
  failed: number;
  errors: string[];
}> => {
  const errors: string[] = [];
  let uploaded = 0;
  let failed = 0;

  try {
    // Validate Cloudinary configuration before proceeding
    const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
    const apiKey = process.env.CLOUDINARY_API_KEY;
    const apiSecret = process.env.CLOUDINARY_API_SECRET;

    if (!cloudName || !apiKey || !apiSecret) {
      throw new Error(
        'Cloudinary credentials are missing. Please ensure the following environment variables are set:\n' +
        '  - CLOUDINARY_CLOUD_NAME\n' +
        '  - CLOUDINARY_API_KEY\n' +
        '  - CLOUDINARY_API_SECRET\n' +
        `Current status: cloud_name=${cloudName ? '✓' : '✗'}, api_key=${apiKey ? '✓' : '✗'}, api_secret=${apiSecret ? '✓' : '✗'}`
      );
    }

    // Reconfigure Cloudinary to ensure it uses the loaded environment variables
    // (in case it was configured before env vars were loaded)
    cloudinary.config({
      cloud_name: cloudName,
      api_key: apiKey,
      api_secret: apiSecret,
      secure: true,
    });

    // Test Cloudinary connection with a simple API call
    console.log('Validating Cloudinary configuration...');
    try {
      await cloudinary.api.ping();
      console.log('✓ Cloudinary connection validated');
    } catch (cloudinaryError: any) {
      // Extract detailed error information
      const errorMsg = cloudinaryError?.message || cloudinaryError?.toString() || 'Unknown error';
      const httpCode = cloudinaryError?.http_code;
      const errorName = cloudinaryError?.name;
      
      // Build comprehensive error message
      let detailedError = `Cloudinary validation failed:\n`;
      detailedError += `  Error: ${errorMsg}\n`;
      if (httpCode) detailedError += `  HTTP Code: ${httpCode}\n`;
      if (errorName) detailedError += `  Error Type: ${errorName}\n`;
      detailedError += `  Cloud Name: ${cloudName}\n\n`;
      detailedError += 'Troubleshooting steps:\n';
      detailedError += '  1. Verify CLOUDINARY_CLOUD_NAME matches your Cloudinary dashboard\n';
      detailedError += '  2. Check CLOUDINARY_API_KEY and CLOUDINARY_API_SECRET are correct\n';
      detailedError += '  3. Ensure your Cloudinary account is active and not suspended\n';
      detailedError += '  4. Try regenerating API credentials in Cloudinary dashboard\n';
      
      // Log full error for debugging
      console.error('Full Cloudinary error:', JSON.stringify(cloudinaryError, null, 2));
      
      throw new Error(detailedError);
    }

    // Resolve products directory path
    // Default: ../products relative to server directory
    // When running with tsx, __dirname points to server/data (source location)
    const resolvedProductsDir = productsDir || path.resolve(__dirname, '..', '..', 'products');
    
    // Connect to MongoDB if URI is provided
    if (mongoUri) {
      await mongoose.connect(mongoUri);
      console.log('Connected to MongoDB');
    } else if (process.env.MONGODB_URI) {
      await mongoose.connect(process.env.MONGODB_URI);
      console.log('Connected to MongoDB');
    } else {
      throw new Error('MongoDB URI not provided. Set MONGODB_URI environment variable or pass it as parameter.');
    }

    // Generate mock product data from images
    console.log(`Generating mock products from: ${resolvedProductsDir}`);
    const mockProducts = generateMockProducts(resolvedProductsDir);
    console.log(`Found ${mockProducts.length} products to upload`);

    // Process each product
    for (let i = 0; i < mockProducts.length; i++) {
      const product = mockProducts[i];
      console.log(`\n[${i + 1}/${mockProducts.length}] Processing: ${product.name}`);

      try {
        // Check if image file exists
        if (!fs.existsSync(product.imagePath)) {
          throw new Error(`Image file not found: ${product.imagePath}`);
        }

        // Upload image to Cloudinary
        console.log(`  Uploading image to Cloudinary...`);
        const imageResult = await uploadImageFile(product.imagePath, 'wearable/products');
        console.log(`  ✓ Image uploaded: ${imageResult.url}`);

        // Check if product already exists (by name)
        const existingProduct = await Product.findOne({ name: product.name });
        if (existingProduct) {
          console.log(`  ⚠ Product "${product.name}" already exists, skipping...`);
          continue;
        }

        // Create product in MongoDB
        console.log(`  Saving product to MongoDB...`);
        const newProduct = await Product.create({
          name: product.name,
          description: product.description,
          category: product.category,
          subCategory: product.subCategory,
          colors: product.colors,
          sizes: product.sizes,
          variants: product.variants,
          price: product.price,
          discountPrice: product.discountPrice,
          samePriceForAllSizes: product.samePriceForAllSizes,
          variantsPrice: product.variantsPrice,
          stock: product.stock,
          images: [
            {
              url: imageResult.url,
              publicId: imageResult.publicId,
            },
          ],
          status: product.stock > 0 ? 'active' : 'out_of_stock',
          sales: 0,
        });

        console.log(`  ✓ Product saved with ID: ${newProduct._id}`);
        uploaded++;

        // Small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.error(`  ✗ Failed to process ${product.name}: ${errorMessage}`);
        errors.push(`${product.name}: ${errorMessage}`);
        failed++;
      }
    }

    // Disconnect from MongoDB
    await mongoose.disconnect();
    console.log('\nDisconnected from MongoDB');

    return {
      success: uploaded > 0,
      message: `Upload complete: ${uploaded} products uploaded, ${failed} failed`,
      uploaded,
      failed,
      errors,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Fatal error:', errorMessage);
    
    // Ensure MongoDB connection is closed
    if (mongoose.connection.readyState === 1) {
      await mongoose.disconnect();
    }

    return {
      success: false,
      message: `Upload failed: ${errorMessage}`,
      uploaded,
      failed,
      errors: [...errors, errorMessage],
    };
  }
};

/**
 * Main execution function (for use in scripts)
 */
if (require.main === module) {
  // Environment variables are already loaded at the top of the file

  // Allow custom products directory as command line argument
  // Default: ../products relative to server directory
  // Handle both source (server/data) and compiled (dist/data) locations
  // When running with tsx, __dirname points to server/data (source location)
  const productsDir = process.argv[2] || path.resolve(__dirname, '..', '..', 'products');
  const mongoUri = process.env.MONGODB_URI;

  uploadMockProducts(productsDir, mongoUri)
    .then((result) => {
      console.log('\n=== Upload Summary ===');
      console.log(`Success: ${result.success}`);
      console.log(`Message: ${result.message}`);
      console.log(`Uploaded: ${result.uploaded}`);
      console.log(`Failed: ${result.failed}`);
      if (result.errors.length > 0) {
        console.log('\nErrors:');
        result.errors.forEach((error) => console.log(`  - ${error}`));
      }
      process.exit(result.success ? 0 : 1);
    })
    .catch((error) => {
      console.error('Fatal error:', error);
      process.exit(1);
    });
}
