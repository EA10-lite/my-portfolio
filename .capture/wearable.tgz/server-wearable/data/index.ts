/**
 * Data utilities for generating and uploading mock products
 */

export { generateMockProducts, type MockProductData } from './mockProducts';
export { uploadMockProducts } from './uploadMockProducts';














