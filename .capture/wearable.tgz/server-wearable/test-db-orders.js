const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config({ path: './.env' });

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const db = mongoose.connection.useDb('wearable');
  
  const customer = await mongoose.connection.collection('users').findOne({ role: 'customer' });
  if (!customer) {
    console.log('No customer found');
    process.exit(1);
  }

  await mongoose.connection.collection('orders').insertOne({
    user: customer._id,
    orderItems: [],
    shippingAddress: {
      fullName: "Test Customer",
      address: "123 Test St",
      city: "Test City",
      postalCode: "12345",
      country: "Test Country",
      phone: "1234567890"
    },
    paymentMethod: "Paystack",
    paymentResult: {
      id: "123",
      status: "success",
      update_time: new Date().toISOString(),
      email_address: "test@test.com"
    },
    itemsPrice: 1000,
    shippingPrice: 100,
    taxPrice: 50,
    totalPrice: 1150,
    total: 1150,
    isPaid: true,
    paidAt: new Date(),
    orderStatus: "pending",
    paymentStatus: "paid",
    isDelivered: false,
    createdAt: new Date(),
    updatedAt: new Date()
  });
  console.log('Dummy order created.');
  process.exit(0);
}).catch(err => {
  console.error(err);
  process.exit(1);
});
