/**
 * Script to create an admin user in the database
 * 
 * This script creates an admin user with the specified credentials.
 * The password will be automatically hashed by the User model's pre-save hook.
 * 
 * Usage:
 *   npx tsx scripts/createAdmin.ts
 *   or
 *   npm run create-admin (if script is added to package.json)
 */

import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { User } from '../src/models/user.model';

// Load environment variables
dotenv.config();

/**
 * Admin user credentials
 */
const ADMIN_EMAIL = 'admin@wearable.com';
const ADMIN_PASSWORD = 'Wearable1234@#$&';
const ADMIN_NAME = 'Admin'; // Optional name field

/**
 * Main function to create admin user
 */
async function createAdminUser(): Promise<void> {
  try {
    // Validate required environment variables
    if (!process.env.MONGODB_URI) {
      console.error('❌ Error: MONGODB_URI is not defined in environment variables');
      process.exit(1);
    }

    // Connect to MongoDB
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB successfully');

    // Check if user already exists
    const existingUser = await User.findOne({
      email: ADMIN_EMAIL.toLowerCase().trim(),
    });

    let adminUser;

    if (existingUser) {
      // User exists - update to admin with new password
      console.log(`⚠️  User with email ${ADMIN_EMAIL} already exists.`);
      console.log(`   Current role: ${existingUser.role}`);
      console.log('   Updating to admin role and setting new password...');

      // Update user to admin role and set new password
      existingUser.role = 'admin';
      existingUser.password = ADMIN_PASSWORD; // Will be automatically hashed by pre-save hook
      existingUser.name = ADMIN_NAME;
      existingUser.isVerified = true;

      // Save the updated user (password will be hashed automatically)
      adminUser = await existingUser.save();

      console.log('✅ Admin user updated successfully!');
    } else {
      // Create new admin user
      console.log('👤 Creating admin user...');
      adminUser = new User({
        email: ADMIN_EMAIL.toLowerCase().trim(),
        password: ADMIN_PASSWORD, // Will be automatically hashed by pre-save hook
        role: 'admin',
        name: ADMIN_NAME,
        isVerified: true, // Set as verified since this is a manual creation
      });

      // Save the user (password will be hashed automatically)
      await adminUser.save();

      console.log('✅ Admin user created successfully!');
    }

    console.log('\n📋 Admin Credentials:');
    console.log(`   Email: ${ADMIN_EMAIL}`);
    console.log(`   Password: ${ADMIN_PASSWORD}`);
    console.log(`   Role: admin`);
    console.log(`   User ID: ${adminUser._id}`);
    console.log('\n🔐 You can now use these credentials to login to the admin dashboard.');

  } catch (error) {
    console.error('❌ Error creating admin user:', error);
    
    // Handle specific MongoDB errors
    if (error instanceof Error) {
      if (error.message.includes('E11000')) {
        console.error('   This email is already registered in the database.');
      } else {
        console.error(`   ${error.message}`);
      }
    }
    
    process.exit(1);
  } finally {
    // Close database connection
    await mongoose.disconnect();
    console.log('\n🔌 Disconnected from MongoDB');
  }
}

// Run the script
createAdminUser();
