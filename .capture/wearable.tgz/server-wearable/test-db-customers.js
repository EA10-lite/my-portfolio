const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config({ path: './.env' });

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const db = mongoose.connection.useDb('wearable');
  const customers = await mongoose.connection.collection('users').find({ role: 'customer' }).toArray();
  console.log('Total customers:', customers.length);
  if (customers.length === 0) {
    console.log('Creating a dummy customer...');
    await mongoose.connection.collection('users').insertOne({
      name: 'Test Customer',
      email: 'customer@wearable.com',
      password: 'hashedpassword',
      role: 'customer',
      isVerified: true,
      createdAt: new Date(),
      updatedAt: new Date()
    });
    console.log('Customer created.');
  }
  process.exit(0);
}).catch(err => {
  console.error(err);
  process.exit(1);
});
