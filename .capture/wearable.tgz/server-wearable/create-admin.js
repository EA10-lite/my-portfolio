const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const dotenv = require('dotenv');
dotenv.config({ path: './.env' });

mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const db = mongoose.connection.useDb('wearable');
  const password = await bcrypt.hash('Wearable1234@#$&', 10);
  await mongoose.connection.collection('users').insertOne({
    name: 'Admin User',
    email: 'admin@wearable.com',
    password: password,
    role: 'admin',
    isVerified: true,
    createdAt: new Date(),
    updatedAt: new Date()
  });
  console.log('Admin user created successfully!');
  process.exit(0);
}).catch(err => {
  console.error(err);
  process.exit(1);
});
