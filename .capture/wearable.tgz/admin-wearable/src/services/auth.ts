import client from "./client";

const login = async (email: string, password: string) => {
    const response = await client.post("/auth/login/admin", { email, password });
    return response.data;
}

export const authService = {
    login,
}