import type { AddProductFormValues } from "../utils/interfaces";
import client from "./client";

const getProducts = async () => {
    const response = await client.get("/products", { withCredentials: true});
    return response.data;
}

const getProductById = async (id: string) => {
    const response = await client.get(`/products/${id}`, { withCredentials: true});
    return response.data;
}

const addProduct = async (product: AddProductFormValues) => {
    const formData = new FormData();
    formData.append("name", product.name);
    formData.append("description", product.description);
    formData.append("category", product.category);
    formData.append("colors", product.colors.join(","));
    formData.append("sizes", product.sizes.join(","));
    formData.append("variants", product.variants.join(","));
    formData.append("price", product.price.toString());
    formData.append("discountPrice", product.discountPrice.toString());
    formData.append("samePriceForAllSizes", product.samePriceForAllSizes.toString());
    formData.append("stock", product.stock.toString());
    product.images?.forEach(image => {
        formData.append("images", image);
    });
    const response = await client.post("/products", formData, { withCredentials: true});
    console.log(response.data);
    return response.data;
}

const deleteProduct = async (id: string) => {
    const response = await client.delete(`/products/${id}`, { withCredentials: true});
    return response.data;
}

export const productService = {
    getProducts,
    getProductById,
    addProduct,
    deleteProduct,
}