import axios from "axios";
import { getAuthToken, removeAuthToken, COOKIE_NAMES } from '../utils/cookies';

// Use Vite's import.meta.env for environment variables
// Note: Environment variables must be prefixed with VITE_ to be exposed to the client
// axios.defaults.baseURL = "http://localhost:3000/api";
axios.defaults.baseURL = import.meta.env.VITE_BASE_API || "http://localhost:3000/api";

// Utility function to check if JWT token is expired
const isTokenExpired = (token: string): boolean => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const currentTime = Date.now() / 1000;
    return payload.exp < currentTime;
  } catch (error) {
    console.log("ERROR: ", error);
    return true; // If we can't decode the token, consider it expired
  }
};

// Utility function to decode JWT token and get user info
export const getTokenPayload = (token: string) => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload;
  } catch (error) {
    console.log("ERROR: ", error);
    return null;
  }
};

// Utility function to get current user info from stored token
export const getCurrentUser = () => {
  const token = getAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
  if (token && !isTokenExpired(token)) {
    return getTokenPayload(token);
  }
  return null;
};

// Utility function to check if user is authenticated
export const isAuthenticated = (): boolean => {
  const token = getAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
  return token ? !isTokenExpired(token) : false;
};

let isRefreshing = false;
let failedQueue: { resolve: (value?: unknown) => void; reject: (reason?: any) => void; }[] = [];

const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach(prom => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
};

axios.interceptors.request.use((config) => {
  config.headers["Accept"] = "application/json";
  config.headers["Content-Type"] = "application/json";
  config.withCredentials = true; // Required for refresh token cookie

  const accessToken = getAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
  if (accessToken) {
    config.headers["Authorization"] = `Bearer ${accessToken}`;
  }

  return config;
});

axios.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    // If 401 and we haven't already retried
    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(token => {
          originalRequest.headers['Authorization'] = 'Bearer ' + token;
          return axios(originalRequest);
        }).catch(err => {
          return Promise.reject(err);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const response = await axios.post('/auth/refresh-token', {}, { withCredentials: true });
        const newToken = response.data.token;
        
        // Update the token in cookies (the getAuthToken helper expects standard js-cookie behavior, or we can just set it manually, wait we need `setAuthToken`)
        // Let's assume the auth logic handles saving it. Actually, `client.ts` should import `setAuthToken`
        const { setAuthToken } = await import('../utils/cookies');
        setAuthToken(COOKIE_NAMES.ACCESS_TOKEN, newToken);

        axios.defaults.headers.common['Authorization'] = 'Bearer ' + newToken;
        originalRequest.headers['Authorization'] = 'Bearer ' + newToken;

        processQueue(null, newToken);
        return axios(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError, null);
        removeAuthToken(COOKIE_NAMES.ACCESS_TOKEN);
        if (typeof window !== 'undefined') {
          window.location.href = '/auth/login';
        }
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }
    
    return Promise.reject(error);
  }
);

export default axios;