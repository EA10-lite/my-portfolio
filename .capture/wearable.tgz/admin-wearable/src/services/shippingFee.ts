import client from "./client";

export const getShippingFees = async () => {
    const response = await client.get("/shipping-fees", { withCredentials: true });
    return response.data;
}

export const createShippingFee = async (data: any) => {
    const response = await client.post("/shipping-fees", data, { withCredentials: true });
    return response.data;
}

export const updateShippingFee = async ({ id, data }: { id: string, data: any }) => {
    const response = await client.patch(`/shipping-fees/${id}`, data, { withCredentials: true });
    return response.data;
}

export const deleteShippingFee = async (id: string) => {
    const response = await client.delete(`/shipping-fees/${id}`, { withCredentials: true });
    return response.data;
}

export const shippingFeeService = {
    getShippingFees,
    createShippingFee,
    updateShippingFee,
    deleteShippingFee,
}
