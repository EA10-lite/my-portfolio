

/**
 * Formats a number with "k" suffix for thousands
 * Examples:
 * - 2500 => "2.5k"
 * - 19874 => "19.8k"
 * - 500 => "500" (numbers less than 1000 are returned as-is)
 */
export const formatNumber = (value: number | undefined | null) => {
    if (value === undefined || value === null || isNaN(value)) return '0';
    if (value >= 1000) {
        const thousands = value / 1000;
        // Round to 1 decimal place, but remove trailing zero if it's a whole number
        const rounded = Math.round(thousands * 10) / 10;
        return rounded % 1 === 0 ? `${rounded}k` : `${rounded.toFixed(1)}k`;
    }
    return value.toString();
}

export const formatCurrency = (amount: number | undefined | null): string => {
    if (amount === undefined || amount === null || isNaN(amount)) return '₦0';
    return `₦${amount.toLocaleString('en-NG')}`;
};

export const formatFileSize = (size: number): string => {
    if (size < 1024) {
        return `${size} B`;
    }
    if (size < 1024 * 1024) {
        return `${(size / 1024).toFixed(2)} KB`;
    }
    return `${(size / 1024 / 1024).toFixed(2)} MB`;
};