import * as yup from "yup";

export const loginValidationSchema = yup.object().shape({
    email: yup.string().email("Invalid email address").trim().lowercase().required("Email is required"),
    password: yup.string().trim().required("Password is required"),
});


// Custom file validator for single files
const fileValidator = yup
    .mixed<File>()
    .test("file-required", "Please select a file", (value) => {
        return value !== null && value !== undefined;
    })
    .test("file-type", "Only JPEG, PNG, and PDF files are allowed", (value) => {
        if (!value) return true; // Let required test handle null/undefined
        const allowedTypes = ["image/jpeg", "image/png", "application/pdf"];
        return allowedTypes.includes(value.type);
    })
    .test("file-size", "File size must be less than 5MB", (value) => {
        if (!value) return true; // Let required test handle null/undefined
        const maxSize = 5 * 1024 * 1024; // 5MB in bytes
        return value.size <= maxSize;
    });

const fileArrayValidator = yup
    .array()
    .of(fileValidator)
    .min(1, "At least one file is required")
    .max(5, "Maximum 5 files allowed")
    .test("no-duplicates", "Duplicate files are not allowed", (files) => {
        if (!files || files.length <= 1) return true;

        const fileNames = files.map(file => `${file?.name}-${file?.size}`);
        const uniqueNames = new Set(fileNames);
        return uniqueNames.size === fileNames.length;
    });

export const addProductValidationSchema = yup.object().shape({
    name: yup.string().required("Name is required"),
    description: yup.string().required("Description is required"),
    category: yup.string().required("Category is required"),
    colors: yup.array().of(yup.string()).required("Colors are required"),
    sizes: yup.array().of(yup.string()).required("Sizes are required"),
    variants: yup.array().of(yup.string()).required("Variants are required"),
    price: yup.number().min(1, "Price must be greater than 0").required("Price is required"),
    discountPrice: yup.number().min(1, "Discount price must be greater than 0").required("Discount price is required"),
    samePriceForAllSizes: yup.boolean().required("Same price for all sizes is required"),
    variantsPrice: yup.array().of(yup.number()),
    stock: yup.number().min(1, "Stock must be greater than 0").required("Stock is required"),
    images: fileArrayValidator
});