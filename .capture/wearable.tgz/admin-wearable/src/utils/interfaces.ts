

export type ToastType = "confirmation" | "success" | "error" | "warning" | "info" | "danger";

export interface ToastDTO {
    message: string;
    type: ToastType | null;
    isVisible: boolean;
    showToast: (message: string, type: ToastType, position?: "top" | "bottom") => void;
    hideToast: () => void;
    position: "top" | "bottom";
}

export type ModalType = "confirmation" | "orderSummary" | "addProduct" | "editProduct" | "deleteProduct" | "productStat" | "assignCourier" | "shippingFeeForm" | "deleteShippingFee" | null;

// Modal data for different modal types
export interface ConfirmationModalData {
    title: string;
    message?: string;
    orderId?: string;
    order?: Order;
    onConfirm: () => void;
    confirmLabel?: string;
    cancelLabel?: string;
}

export interface OrderSummaryModalData {
    title: string;
    order?: Order;
}

type Stat = {
    label: string;
    value: number;
}
export interface ProductStatData {
    title: string;
    stats: Stat[] | null;
}

export interface ShippingFee {
    _id: string;
    state: string;
    lga?: string;
    fee: number;
    isDefault: boolean;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
}

// Union type for all modal data types (can be extended for other modal types)
export type ModalData = ConfirmationModalData | Order | OrderSummaryModalData | ProductStatData | Product | ShippingFee | null;

export interface ModalDTO {
    isOpen: boolean;
    type: ModalType;
    data: ModalData;
    openConfirmationModal: (data: ConfirmationModalData) => void;
    openOrderSummaryModal: (order: Order) => void;
    openAssignCourierModal: (order: Order) => void;
    openAddProductModal: () => void;
    openEditProductModal: (data: Product) => void;
    openDeleteProductModal: (data: Product) => void;
    openProductStatModal: (data: ProductStatData) => void;
    openShippingFeeFormModal: (data?: ShippingFee) => void;
    openDeleteShippingFeeModal: (data: ShippingFee) => void;
    closeModal: () => void;
}


export interface Order {
    id: string;
    customer: OrderCustomer;
    product: OrderProduct;
    items: number;
    amount: number;
    paymentStatus: string;
    variants?: string[];
    colors?: string[];
    sizes?: string[];
    orderStatus: string;
    createdAt: string;
    updatedAt: string;
}

type OrderCustomer = {
    id: string;
    name: string;
    email: string;
    phone: string;
    deliveryAddress: string;
    paymentMethod: string;
}

type OrderProduct = {
    id: string;
    name: string;
    description: string;
    images: string[];
    category: string;
    price: number;
}


export interface Customer {
    id: string | number;
    email: string;
    name: string;
    phone: string;
    totalOrders: number;
    totalAmount: number;
    status: string;
    createdAt: string;
    updatedAt: string;
}


export interface Product {
    id: string;
    name: string;
    description: string;
    category: string;
    price: number;
    stock: number;
    status: string;
    createdAt: string;
    updatedAt: string;
    sales: number;
    images?: any[];
}


export interface AddProductFormValues {
    name: string;
    description: string;
    category: string;
    subCategory?: string;
    colors: string[];
    sizes: string[];
    variants: string[];
    price: number | number[];
    discountPrice: number;
    samePriceForAllSizes: boolean;
    stock: number;
    images: File[] | null;
}

