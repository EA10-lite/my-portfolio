
import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { AppLayout, ProtectedRoute, PublicRoute } from './layouts'
import Dashboard from './pages/dashboard/Dashboard'
import Login from './pages/auth/Login'
import Products from './pages/product-managment/Products'
import Orders from './pages/order-management/Orders'
import Customers from './pages/customer-management/Customers'
import OrderDetails from './pages/order-management/[id]/OrderDetails'
import { Toast } from './components/general'
import CustomerDetails from './pages/customer-management/[id]/CustomerDetails'
import ShippingFees from './pages/shipping-fees/ShippingFees'

function App() {
  return (
    <BrowserRouter>
      <Toast />
      <Routes>
          <Route path="/auth/login" element={
            <PublicRoute>
              <Login />
            </PublicRoute>
          } />
          <Route path="/" element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }>
            <Route index element={<Dashboard />} />
            <Route path="/products" element={<Products />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/orders/:id" element={<OrderDetails />} />
            <Route path="/customers" element={<Customers />} />
            <Route path="/customers/:id" element={<CustomerDetails />} />
            <Route path="/shipping-fees" element={<ShippingFees />} />
          </Route>
        </Routes>
    </BrowserRouter>
  )
}

export default App
