import { useModalStore } from "../../stores/modalStore";
import { formatCurrency } from "../../utils/formatter";
import type { Order } from "../../utils/interfaces";
import { Button, ReusableModal, Text } from "../main";
import PageField from "./PageField";

type OrderSummaryProps = {
    handleClick: () => void;
    buttonTitle: string;
    buttonIcon?: React.ReactNode;
    href?: string;
}

const OrderSummary = ({ handleClick, buttonTitle, buttonIcon, href }: OrderSummaryProps) => {
    const { data, closeModal, type, isOpen} = useModalStore();

    if (type !== "orderSummary" || !data || !isOpen) {
        return null;
    }

    const order = data as Order;

    return (
        <ReusableModal
            onClose={closeModal}
            isOpen={isOpen}
            title={`Order Summary - #${order?.id}`}
        >
            <div className="space-y-6 flex flex-col gap-6">
                <div className="grow">
                    <div className="mb-6">
                        <Text
                            title="1-Order Summary"
                            type="h4"
                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                            letterSpacing={"-2%"}
                        />

                        <div className="flex flex-col gap-4">
                            <PageField label="Customer Name" value={order?.customer?.name} className="gap-2" />
                            <PageField label="Customer Email" value={order?.customer?.email} className="gap-2" />
                            <PageField label="Customer Phone" value={order?.customer?.phone} className="gap-2" />
                            <PageField label="Delivery Address" value={order?.customer?.deliveryAddress} className="gap-2" />
                            <PageField label="Payment Method" value={order?.customer?.paymentMethod} className="gap-2" />
                            <PageField label="Payment Status" value={order?.paymentStatus} className="gap-2" />
                            <PageField label="Date Ordered" value={order?.createdAt} className="gap-2" />
                        </div>

                    </div>
                    <div className="">
                        <Text
                            title="2-Items"
                            type="h4"
                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                            letterSpacing={"-2%"}
                        />

                        <div className="mb-4">
                            <Text
                                title="Product Image"
                                className="mb-2"
                                type="h4"
                            />

                            <div className="flex items-center gap-2 flex-wrap">
                                {order?.product?.images?.map((item, index) => (
                                    <div className="w-20 h-20 overflow-hidden" key={index}>
                                        <img
                                            src={"/images/hoodie.png"}
                                            alt={item}
                                            className="w-full h-full object-cover"
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="flex flex-col gap-4">
                            <PageField label="Name" value={order?.product?.name} />
                            <PageField label="Sizes" value={order?.sizes?.join(", ").toString() || ""} />
                            <ColorBox colors={order?.colors || []} />
                            <PageField label="Quantity" value={order?.items} />
                            <PageField label="Stock Status" value={""} />
                            <PageField label="Price" value={formatCurrency(order?.amount)} />
                        </div>

                    </div>
                </div>
                <div className="w-full">
                    <Button
                        title={buttonTitle}
                        icon={buttonIcon}
                        onClick={handleClick}
                        href={href}
                        className="w-full"
                    />
                </div>
            </div>
        </ReusableModal>
    )
}

const ColorBox = ({ colors }: { colors: string[] }) => {
    return (
        <div className="">
            <Text
                title={"Colors"}
                type="h4"
                letterSpacing={"-2%"}
            />

            <div className="flex items-center gap-2 flex-wrap">
                {colors.map((color, index) => (
                    <div
                        className="w-8 h-8"
                        style={{ backgroundColor: color }}
                        key={index}
                    />
                ))}
            </div>
        </div>
    )
}

export default OrderSummary;