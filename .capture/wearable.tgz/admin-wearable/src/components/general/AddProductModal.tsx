import { Formik } from "formik";
import { useModalStore } from "../../stores/modalStore";
import { Button, ReusableModal, Text } from "../main";
import {
    Checkbox,
    ColorPicker,
    Field,
    MultiSelect,
    Select,
    Submit,
    Textbox,
    ImagePicker,
} from "../forms";
import { useState, useRef } from "react";
import { ChevronDown } from "lucide-react";
import { addProductValidationSchema } from "../../utils/validations";
import type { AddProductFormValues } from "../../utils/interfaces";
import { PageField } from ".";
import { formatCurrency } from "../../utils/formatter";
import { FaRegTrashAlt } from "react-icons/fa";
import { useToastStore } from "../../stores/toastStore";

const getSubCategories = (category: string) => {
    if (category === "male") {
        return [
            { value: "shirt", label: "Shirt" },
            { value: "t-shirt", label: "T-Shirt" },
            { value: "pant", label: "Pant" },
            { value: "short", label: "Short" },
        ];
    }

    if (category === "female") {
        return [
            { value: "dress", label: "Dress" },
            { value: "skirt", label: "Skirt" },
            { value: "leggings", label: "Leggings" },
        ];
    }

    if (category === "accessories") {
        return [
            { value: "watch", label: "Watch" },
            { value: "jewelry", label: "Jewelry" },
            { value: "bag", label: "Bag" },
        ];
    }

    if (category === "footwear") {
        return [
            { value: "shoe", label: "Shoe" },
            { value: "boot", label: "Boot" },
            { value: "sandals", label: "Sandals" },
        ];
    }

    return [];
}


const AddProductModal = ({product}: {product?: AddProductFormValues }) => {
    const { closeModal, type, isOpen} = useModalStore();
    const { showToast } = useToastStore();

    const [step, setStep] = useState<number>(1);

    const [assignPriceToEachVariant, setAssignPriceToEachVariant] = useState<boolean>(false);

    const [loading, setLoading] = useState<boolean>(false);
    
    // Ref to store the Formik resetForm function so we can call it when modal closes
    const resetFormRef = useRef<(() => void) | null>(null);

    const handleSubmit = async (values: AddProductFormValues) => {
        try {
            setLoading(true);
            await new Promise(resolve => setTimeout(resolve, 1000));
            console.log(values);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false);
        }
    }


    if (type !== "addProduct" || !isOpen) {
        return null;
    }

    /**
     * Handles modal close event
     * Resets the form to initial values, resets step to 1, and closes the modal
     * This ensures a clean state when the modal is reopened
     */
    const handleClose = () => {
        // Reset the form if resetForm function is available
        if (resetFormRef.current) {
            resetFormRef.current();
        }
        closeModal();
        setStep(1);
        setAssignPriceToEachVariant(false);
    }


    return (
        <ReusableModal
            title={step === 1 ? product ? "Edit Product" : "Add Product" : "Preview"}
            onClose={handleClose}
            isOpen={isOpen}
            hasBackButton={step === 2}
            handleBack={() => setStep(1)}
        >
            <Formik
                initialValues={{
                    name: product?.name || "",
                    description: product?.description || "",
                    category: product?.category || "",
                    subCategory: product?.subCategory || "",
                    colors: product?.colors || ["black"],
                    sizes: product?.sizes || [],
                    variants: product?.variants || [],
                    price: product?.price || 0,
                    discountPrice: product?.discountPrice || 0,
                    samePriceForAllSizes: true,
                    stock: product?.stock || 0,
                    images: product?.images || [],
                }}

                onSubmit={handleSubmit}
                validationSchema={addProductValidationSchema}
            >
                {({ values, setFieldValue, resetForm, validateForm, setTouched })=> {
                    resetFormRef.current = resetForm;
                    const handleNextStep = async () => {
                        const validationErrors = await validateForm();
                        if (Object.keys(validationErrors).length > 0) {
                            const allFields = Object.keys(values);
                            const touchedFields: Record<string, boolean> = {};
                            allFields.forEach(field => {
                                touchedFields[field] = true;
                            });
                            setTouched(touchedFields);
                            return;
                        }
                        setStep(2);
                    };

                    return (
                        <div className="add-product-form">
                            { step ===1 && (
                                <div className="add-product">
                                    <div className="form-group mb-6">
                                        <Text
                                            title="1-Basic Information"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="form-fields">
                                            <Field
                                                name="name"
                                                label="Product Name"
                                                placeholder="Enter product name"
                                                type="text"
                                            />

                                            <Select
                                                name="category"
                                                label="Category"
                                                options={[
                                                    { value: "male", label: "Male" },
                                                    { value: "female", label: "Female" },
                                                    { value: "accessories", label: "Accessories" },
                                                    { value: "footwear", label: "Footwear" },
                                                ]}
                                            />

                                            {values["category"] && (
                                                <Select
                                                    name="subCategory"
                                                    label="Sub Category"
                                                    options={getSubCategories(values["category"])}
                                                />
                                            )}

                                            <Textbox
                                                name="description"
                                                label="Description"
                                            />

                                        </div>
                                    </div>

                                    <div className="form-group mb-6">
                                        <Text
                                            title="2-Variants"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="form-fields">
                                            <MultiSelect
                                                name="sizes"
                                                label="Sizes"
                                                options={[
                                                    { value: "small", label: "Small" },
                                                    { value: "medium", label: "Medium" },
                                                    { value: "large", label: "Large" },
                                                    { value: "extra large", label: "Extra Large" },
                                                    { value: "extra extra large", label: "Extra Extra Large" },
                                                ]}
                                            />

                                            <ColorPicker
                                                name="colors"
                                                label="Colors"
                                                options={[
                                                    { value: "black", label: "Black" },
                                                    { value: "gray", label: "Gray" },
                                                    { value: "brown", label: "Brown" },
                                                ]}
                                            />
                                        </div>
                                    </div>

                                    <div className="form-group mb-6">
                                        <Text
                                            title="3-Pricing"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="form-fields">
                                            <div className="mb-5">
                                                <Field
                                                    name="price"
                                                    label="Price"
                                                    placeholder="Enter price"
                                                    type="number"
                                                    className="mb-2"
                                                />

                                                {values.sizes?.length > 1 && (
                                                    <Checkbox
                                                        name="samePriceForAllSizes"
                                                        label="Same price for all sizes"
                                                    />
                                                )}
                                            </div>

                                            {!values.samePriceForAllSizes && (
                                                <div className="mb-5">
                                                    <div
                                                        className="flex items-center gap-2 justify-between cursor-pointer"
                                                        onClick={() => setAssignPriceToEachVariant(!assignPriceToEachVariant)}
                                                    >
                                                        <Text
                                                            title="Assign price to each variant"
                                                            type="p"
                                                            letterSpacing={"-2%"}
                                                        />

                                                        <ChevronDown
                                                            size={16}
                                                            className={assignPriceToEachVariant ? "rotate-180 transition-transform duration-300" : "transition-transform duration-300"} 
                                                        />
                                                    </div>

                                                    {assignPriceToEachVariant && (
                                                        <div className="form-fields mt-2">
                                                            {/* Size field */}
                                                            {/* Price field */}
                                                            {/* Plus icon */}
                                                        </div>
                                                    )}
                                                </div>
                                            )}

                                            <Field
                                                name="discountPrice"
                                                label="Discount Price"
                                                type="number"
                                            />
                                        </div>
                                    </div>

                                    <div className="form-group mb-6">
                                        <Text
                                            title="4-Inventory and Stock"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="form-fields">
                                            <Field
                                                name="stock"
                                                label="Quantity"
                                                type="number"
                                            />
                                        </div>
                                    </div>

                                    <div className="form-group mb-6">
                                        <Text
                                            title="5-Product Images"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="form-fields">
                                            <ImagePicker
                                                name="images"
                                                required
                                                multiple={true}
                                                maxFiles={5}
                                                acceptedTypes={["image/jpeg", "image/png", "image/jpg"]}
                                            />
                                        </div>
                                    </div>

                                    <Button
                                        title="Preview & Publish"
                                        onClick={handleNextStep}
                                        className="w-full"
                                    />
                                </div>
                            )}

                            { step === 2 && (
                                <div className="preview-product">
                                    <div className="preview-group mb-6">
                                        <Text
                                            title="1-Basic Information"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="preview-fields flex flex-col gap-5">
                                            <PageField
                                                label="Product Name"
                                                value={values.name}
                                                className="gap-2"
                                            />
                                            <PageField
                                                label="Category"
                                                value={values.category}
                                                className="gap-2"
                                            />
                                            <PageField
                                                label="Description"
                                                value={values.description}
                                                className="gap-2"
                                            />
                                        </div>

                                    </div>

                                    <div className="preview-group mb-6">
                                        <Text
                                            title="2-Variants"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="preview-fields flex flex-col gap-5">
                                            <PageField
                                                label="Sizes"
                                                value={values.sizes.join(", ")}
                                                className="gap-2"
                                            />

                                            <div className="flex flex-col gap-2">
                                                <Text
                                                    title="Color"
                                                    type="p"
                                                    letterSpacing={"-2%"}
                                                />
                                                <div className="flex items-center gap-2">
                                                    {values.colors.map((color) => (
                                                        <div
                                                            className="w-8 h-8"
                                                            style={{ backgroundColor: color }}
                                                        />
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="preview-group mb-6">
                                        <Text
                                            title="3-Stock and Inventory"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <PageField 
                                            label="Stock Quantity"
                                            value={values.stock}
                                            className="gap-2"
                                        />
                                    </div>

                                    <div className="preview-group mb-6">
                                        <Text
                                            title="4-Pricing"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <PageField
                                            label="Price"
                                            value={formatCurrency(values.price as number)}
                                            className="gap-2"
                                        />

                                        <div className="mt-4">
                                            {values.samePriceForAllSizes ? (
                                                <Text
                                                    title="same price assigned to all variants"
                                                    type="p"
                                                    letterSpacing={"-2%"}
                                                />
                                            ) : (
                                                <div className="">
                                                    <div className="table">
                                                        <div className="table-header">
                                                            <Text
                                                                title="Size"
                                                                type="p"
                                                                letterSpacing={"-2%"}
                                                            />
                                                            <Text
                                                                title="Price"
                                                                type="p"
                                                                letterSpacing={"-2%"}
                                                            />
                                                        </div>
                                                        <div className="table-body">
                                                        </div>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    <div className="preview-group mb-6">
                                        <Text
                                            title="5-Product Images"
                                            type="h4"
                                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                                            letterSpacing={"-2%"}
                                        />

                                        <div className="grid grid-cols-5 gap-2">
                                            {values["images"]?.map((image, index) => (
                                                <div key={index} className="w-full h-[80px] overflow-hidden">
                                                    <ImagePreview
                                                        image={image}
                                                        onDelete={()=> {
                                                            setFieldValue("images", values.images.filter((_, i) => i !== index));
                                                            showToast("Image deleted successfully", "success");
                                                        }}
                                                    />
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <Submit
                                        title="Publish"
                                        className="w-full bg-black text-white"
                                        loading={loading}
                                    />
                                </div>
                            )}

                        </div>
                    );
                }}
            </Formik>
        </ReusableModal>
    )
}

const ImagePreview = ({ image, onDelete }: { image: string | File, onDelete: () => void }) => {
    if (typeof image === "string") {
        return (
            <div className="w-full h-full overflow-hidden relative cursor-pointer">
                <div
                    className="w-full h-full absolute top-0 left-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black/50 z-99 opacity-0 hover:opacity-100 transition-opacity duration-300 ease-in-out"
                >
                    <button
                        className="text-white"
                        onClick={onDelete}
                    >
                        <FaRegTrashAlt />
                    </button>
                </div>
                <img src={image} alt="product image" className="w-full h-full object-cover" />
            </div>
        )
    }

    return (
        <div className="w-full h-full overflow-hidden relative cursor-pointer">
            <div
                className="w-full h-full absolute top-0 left-0 left-0 right-0 bottom-0 flex items-center justify-center bg-black/50 z-99 opacity-0 hover:opacity-100 transition-opacity duration-300 ease-in-out"
            >
                <button
                    className="text-white"
                    onClick={onDelete}
                >
                    <FaRegTrashAlt />
                </button>
            </div>
            <img src={URL.createObjectURL(image as File)} alt="product image" className="w-full h-full object-cover z-10" />
        </div>
    )
}

export default AddProductModal;