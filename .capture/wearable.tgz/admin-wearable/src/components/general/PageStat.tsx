import { LuPlus } from "react-icons/lu";
import { Button, Skeleton, Text } from "../main";
import { formatNumber } from "../../utils/formatter";
import AddProductModal from "./AddProductModal";
import { useModalStore } from "../../stores/modalStore";

type Stat = {
    label: string;
    value: number;
    isLoading?: boolean;
    hasViewAction?: boolean;
    viewAction?: () => void;
}

type PageStatProps = {
    title: string;
    subtitle?: string;
    stats: Stat[];
    isLoading?: boolean;
}

const PageStat = ({ title, subtitle, stats = [], isLoading = false }: PageStatProps) => {
    const { openAddProductModal } = useModalStore();
    /**
     * Map stats length to Tailwind grid column classes.
     * Tailwind's JIT compiler needs to see full class names at build time,
     * so we can't use template literals like `lg:grid-cols-${stats.length}`.
     * Instead, we map the length to explicit class names.
     */
    const getGridCols = (length: number): string => {
        const gridColMap: Record<number, string> = {
            1: "grid-cols-1 md:grid-cols-2 lg:grid-cols-1",
            2: "grid-cols-1 md:grid-cols-2 lg:grid-cols-2",
            3: "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
            4: "grid-cols-1 md:grid-cols-2 lg:grid-cols-4",
            5: "grid-cols-1 md:grid-cols-2 lg:grid-cols-5",
            6: "grid-cols-1 md:grid-cols-2 lg:grid-cols-6",
        };

        return gridColMap[length] || gridColMap[4];
    };

    const gridCols = getGridCols(stats.length);

    return (
        <div className="page-stat">
            <div className="flex items-center justify-between gap-4 flex-wrap mb-6">
                <div className="">
                    <Text
                        title={title}
                        type="h4"
                        className="text-xl font-chivo-regular font-normal uppercase"
                        letterSpacing={"-2%"}
                    />

                    {subtitle && (
                        <Text
                            title={subtitle}
                            type="p"
                            className="text-[#7C7C7C]"
                        />
                    )}
                </div>

                <Button
                    title="Add Product"
                    variant="black"
                    onClick={openAddProductModal}
                    icon={<LuPlus />}
                />
            </div>

            <div className={`grid ${gridCols} gap-4`}>
                {isLoading ? Array.from({ length: stats.length }).map((_i, index)=> (
                    <div className="flex flex-col gap-6 border border-[#0000001A] px-4 py-6 min-h-[120px] justify-center" key={index}>
                        <Skeleton className="w-1/3 h-4" />
                        <Skeleton className="w-3/4 h-4" />
                    </div>
                )) : stats.map((item, index)=> (
                    <div key={index}>
                        <Stat
                            label={item.label}
                            value={item.value}
                            hasViewAction={item.hasViewAction}
                            viewAction={item.viewAction}
                        />
                    </div>
                ))}
            </div>

            <AddProductModal />
        </div>
    )
}

const Stat = ({ label, value, hasViewAction, viewAction }: Stat) => {
    return (
        <div className={`stat border border-[#0000001A] px-4 py-6 flex flex-col gap-6 min-h-[120px]`}>
            <Text
                title={formatNumber(value)}
                type="p"
                className="text-2xl font-chivo-medium font-medium uppercase"
                letterSpacing={"-2%"}
            />

            <div className="flex items-center justify-between">
                <Text
                    title={label}
                    type="h3"
                    className="text-sm font-chivo-regular font-normal uppercase"
                    letterSpacing={"-2%"}
                />

                {hasViewAction && (
                    <span
                        className="text-sm font-chivo-regular font-normal uppercase underline text-primary cursor-pointer"
                        onClick={viewAction}
                    >View</span>
                )}
            </div>
        </div>
    )
}

export default PageStat