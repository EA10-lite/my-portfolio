import React, { useEffect, useRef } from "react";
import { useToastStore } from "../../stores/toastStore";

const Toast: React.FC = () => {
    const { message, type, isVisible, hideToast } = useToastStore();
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    useEffect(() => {
        if (isVisible && message) {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
            }

            timeoutRef.current = setTimeout(() => {
                hideToast();
            }, 3000);

            return () => {
                if (timeoutRef.current) {
                    clearTimeout(timeoutRef.current);
                }
            };
        }
    }, [isVisible, message, hideToast]);

    if (!isVisible || !message || !type) {
        return null;
    }

    const animationClasses = isVisible
        ? "translate-x-0 opacity-100"
        : "translate-x-full opacity-0";

    return (
        <div className={``}>
            <div
                className={`min-w-[343px] border transition-all duration-300 ease-out absolute z-99 top-5 right-5 ${animationClasses} bg-${type}-light border-${type} shadow-lg`}
            >
                <div className="h-4 w-full bg-black" />
                <div className="px-4 py-2 bg-white">
                    <h4 className="text-sm font-chivo-medium font-medium uppercase">{type}</h4>
                    <p className="text-sm font-chivo-regular font-normal uppercase text-[#909090]">{message}</p>
                </div>
            </div>
        </div>
    );
};

export default Toast;