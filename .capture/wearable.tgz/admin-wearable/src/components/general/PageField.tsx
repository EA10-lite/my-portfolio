import { Text } from "../main";


const Field = ({ label, value, className="" }: { label: string, value: string | number, className?: string }) => {
    return (
        <div className={`${className} field flex flex-col`}>
            <Text
                title={label}
                type="h4"
                letterSpacing={"-2%"}
            />

            <Text
                title={value.toString()}
                type="p"
                className="text-[#909090] text-sm"
                letterSpacing={"-2%"}
            />
        </div>
    )
}

export default Field;