import { cn } from "../../lib/utils";

/**
 * Column data structure for TableSkeleton
 * Matches the Column type from ReusableTable for consistency
 */
export type SkeletonColumn = {
    key: string;
    header: string;
    className?: string;
};

/**
 * Props for the TableSkeleton component
 */
export type TableSkeletonProps = {
    /**
     * Array of column data containing key, header, and optional className
     * Used to render the table header and determine column structure
     */
    columnData: SkeletonColumn[];

    /**
     * Number of columns to display in the skeleton
     * If provided, will override columnData length for rendering rows
     */
    numberOfColumns?: number;

    /**
     * Number of skeleton rows to display in the table body
     * Defaults to 5 if not provided
     */
    numberOfRows?: number;
};

/**
 * TableSkeleton Component
 *
 * Displays a loading skeleton that matches the layout and styling of ReusableTable.
 * Used to provide visual feedback while table data is being loaded.
 *
 * Features:
 * - Matches ReusableTable's exact layout and styling
 * - Animated pulse effect for loading indication
 * - Configurable number of rows and columns
 * - Responsive design matching the original table
 *
 * @param props - TableSkeletonProps containing columnData, numberOfColumns, and numberOfRows
 */
const TableSkeleton = ({
    columnData,
    numberOfColumns,
    numberOfRows = 5,
}: TableSkeletonProps) => {
    // Determine the number of columns to use
    // Priority: numberOfColumns prop > columnData length
    const columnsToRender = numberOfColumns ?? columnData.length;

    // Generate array of column indices for rendering
    const columnIndices = Array.from({ length: columnsToRender }, (_, i) => i);

    // Generate array of row indices for rendering
    const rowIndices = Array.from({ length: numberOfRows }, (_, i) => i);

    return (
        <div className="w-full">
            {/* Table Section - Matches ReusableTable structure */}
            <div className="border border-gray-200 bg-white">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        {/* Table Header - Matches ReusableTable header styling */}
                        <thead className="bg-[#00000008] border-b border-gray-200">
                            <tr>
                                {columnIndices.map((index) => {
                                    const column = columnData[index];
                                    return (
                                        <th
                                            key={column?.key || `skeleton-col-${index}`}
                                            className={cn(
                                                "px-6 py-4 text-left text-xs font-chivo-regular font-normal uppercase text-black",
                                                column?.className
                                            )}
                                        >
                                            {/* Skeleton header text with pulse animation */}
                                            <div className="h-4 bg-gray-200 rounded animate-pulse w-24" />
                                        </th>
                                    );
                                })}
                            </tr>
                        </thead>

                        {/* Table Body - Matches ReusableTable body styling */}
                        <tbody className="divide-y divide-gray-200">
                            {rowIndices.map((rowIndex) => (
                                <tr 
                                    key={`skeleton-row-${rowIndex}`} 
                                    className="hover:bg-[#00000008] transition-colors"
                                >
                                    {columnIndices.map((colIndex) => {
                                        const column = columnData[colIndex];
                                        return (
                                            <td
                                                key={`skeleton-cell-${rowIndex}-${colIndex}`}
                                                className={cn(
                                                    "px-6 py-4 text-sm font-chivo-regular text-gray-900 uppercase",
                                                    column?.className
                                                )}
                                            >
                                                {/* Skeleton cell content with pulse animation */}
                                                <div className="h-4 bg-gray-200 rounded animate-pulse w-3/4" />
                                            </td>
                                        );
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default TableSkeleton;

