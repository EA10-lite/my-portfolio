import { useRef, useState } from "react";
import { FiSearch } from "react-icons/fi";
import { cn } from "../../lib/utils";
import { ChevronDown } from "lucide-react";
import { PiExportLight } from "react-icons/pi";
import { useOutsideClick } from "../../hooks";

type TableHeaderProps = {
    title: string;
    search: string;
    handleSearch?: (query: string) => void;
    placeholder?: string;
    handleExport?: () => void;
    filters?: Array<{ label: string; value: string }>;
    handleFilters?: (filter: string) => void;
    activeFilter?: string;
    options?: Filters[];
}

type Filters = {
    options: Array<{ label: string; value: string }>;
    handleFilter: (filter: string) => void;
    activeFilter: string;
}

const TableHeader = ({
    title,
    search,
    placeholder="Search",
    handleSearch,
    handleExport,
    options,
} : TableHeaderProps) => {

    return (
        <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
            <h4 className="text-base font-chivo-medium font-medium uppercase">{title}</h4>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-wrap">
                <div className="relative flex-1 sm:flex-initial sm:min-w-[200px]">
                    <FiSearch
                        className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                        size={18}
                        onClick={()=>handleSearch?.(search)}
                    />

                    <input
                        type="text"
                        placeholder={placeholder}
                        value={search}
                        onChange={(e)=>handleSearch?.(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded text-sm font-chivo-regular font-normal uppercase focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
                    />
                </div>

                {options && options.length > 0 && options.map((option, index) => (
                    <FilterOption
                        key={index}
                        options={option.options}
                        handleFilter={option.handleFilter}
                        activeFilter={option.activeFilter}
                    />
                ))}

                {handleExport && (
                    <button
                        onClick={handleExport}
                        className="px-4 py-2.5 border border-gray-200 rounded text-sm font-chivo-regular font-normal uppercase bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent cursor-pointer flex items-center gap-2"
                    >
                        <PiExportLight size={16} />
                        <span className="text-sm font-chivo-regular font-normal uppercase">export</span>
                    </button>
                )}
            </div>
        </div>
    );
};

const FilterOption = ({
    options,
    handleFilter,
    activeFilter,
}: Filters) => {
    const filterRef = useRef<HTMLDivElement>(null);
    const [isFilterOpen, setIsFilterOpen] = useState<boolean>(false);

    const handleFilterClick = (filter: string) => {
        setIsFilterOpen(false);
        handleFilter?.(filter);
    }

    useOutsideClick(filterRef, () => {
        setIsFilterOpen(false);
    });

    return (
        <div className="relative" ref={filterRef}>
            <button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded text-sm font-chivo-regular font-normal uppercase bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
            >
                <span>{activeFilter !? activeFilter : "Status"}</span>
                <ChevronDown size={16} className={cn("transition-transform", isFilterOpen && "rotate-180")} />
            </button>

            {isFilterOpen && (
                <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-gray-200 rounded shadow-lg z-50">
                    <div className="py-1">
                        {options.map((option) => (
                            <button
                                key={option.value}
                                onClick={() => handleFilterClick(option.value)}
                                className={cn(
                                    "w-full text-left px-4 py-2 text-sm font-chivo-regular hover:bg-gray-100",
                                    activeFilter === option.value && "bg-gray-100"
                                )}
                            >
                                {option.label}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default TableHeader;