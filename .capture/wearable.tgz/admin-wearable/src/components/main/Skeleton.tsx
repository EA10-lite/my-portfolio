import { mergeClasses } from "../../lib/mergeclasses";

type SkeletonProps = {
    className?: string;
}

const Skeleton = ({
    className,
}: SkeletonProps) => {
    return (
        <div className={mergeClasses("skeleton bg-gray-200 rounded animate-pulse min-w-[120px]", className)}></div>
    );
};

export default Skeleton; 