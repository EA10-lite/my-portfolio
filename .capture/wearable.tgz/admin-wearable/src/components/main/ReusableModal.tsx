import type { PropsWithChildren } from "react";
import { useState } from "react";
import { mergeClasses } from "../../lib/mergeclasses";
import { MdClose } from "react-icons/md";
import { GoArrowLeft } from "react-icons/go";
import Text from "./Text";


type ModalProps = PropsWithChildren<{
    title?: string;
    onClose: () => void;
    isOpen: boolean;
    className?: string;
    hasBackButton?: boolean;
    handleBack?: () => void;
    bodyClassName?: string;
}>

const ReusableModal = ({
    children,
    title,
    onClose,
    isOpen,
    className,
    hasBackButton,
    handleBack,
    bodyClassName
} : ModalProps) => {
    const [isVisible, setIsVisible] = useState<boolean>(isOpen);

    const handleClose = () => {
        setIsVisible(false);
        onClose();
    }

    if (!isOpen) return null;

    const handleOverlayClick = (e: React.MouseEvent) => {
        if (e.target === e.currentTarget) {
            handleClose();
        }
    };

    return (
        <div
            className={`fixed inset-0 z-50  bg-[#00000066] transition-opacity duration-300 ${
                isVisible ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={handleOverlayClick}
        >
            <div
                className={mergeClasses(`modal-content bg-white min-w-84 mt-[6vh] max-h-[90vh] overflow-y-auto max-w-lg ml-auto my-6  mr-4 w-full transition-all duration-300 transform relative ${
                    isVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-4'
                }`, className)}
            >
                {title && (
                    <div className="modal-header p-4 bg-black flex items-center justify-between sticky top-0 z-50">
                        <div className="flex items-center gap-2">
                            {hasBackButton && (
                                <button
                                    className=""
                                    onClick={handleBack}
                                >
                                    <GoArrowLeft className="text-white" size={18} />
                                </button>
                            )}
                            <Text
                                title={title}
                                type="h4"
                                className="text-white"
                                letterSpacing={"-2%"} 
                            />
                        </div>

                        <button
                            className="w-8 h-8 bg-[#f2f2f2] flex items-center justify-center"
                            onClick={handleClose}
                        >
                            <MdClose />
                        </button>
                    </div>
                )}
                <div className={mergeClasses(`modal-body p-4`, bodyClassName)}>
                    {children}
                </div>
            </div>
        </div>
    )
}


export default ReusableModal;