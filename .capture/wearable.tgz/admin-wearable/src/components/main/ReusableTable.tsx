import { useState, useRef, useEffect } from "react";
import { MoreVertical } from "lucide-react";
import { cn } from "../../lib/utils";
import { useOutsideClick } from "../../hooks";
import { BsArrowLeft, BsArrowRight } from "react-icons/bs";

export type StatusConfig = {
    [key: string]: {
        label: string;
        className: string;
    };
};

export type ActionMenuItem<T = Record<string, unknown>> = {
    label: string;
    icon?: React.ReactNode;
    onClick: (row: T) => void;
    className?: string;
};

export type Column<T = Record<string, unknown>> = {
    key: string;
    header: string;
    render?: (row: T) => React.ReactNode;
    className?: string;
};

/**
 * Pagination information from server
 */
export type ServerPagination = {
    page: number;
    limit: number;
    total: number;
    pages: number;
};

/**
 * Props for the ReusableTable component
 */
export type ReusableTableProps<T = Record<string, unknown>> = {
    data: T[];
    columns: Column<T>[];
    statusConfig?: StatusConfig;

    statusKey?: string;
    actionItems?: ActionMenuItem<T>[] | ((row: T) => ActionMenuItem<T>[]);
    searchPlaceholder?: string;
    onSearch?: (query: string) => void;
    searchValue?: string;

    statusFilterOptions?: Array<{ label: string; value: string }>;
    onStatusFilter?: (status: string) => void;
    statusFilterValue?: string;

    rowsPerPage?: number;
    loading?: boolean;
    emptyMessage?: string;
    
    // Server-side pagination props
    pagination?: ServerPagination;
    onPageChange?: (page: number) => void;
};

const ReusableTable = <T extends Record<string, unknown>>({
    data,
    columns,
    statusConfig,
    statusKey = "status",
    actionItems,
    rowsPerPage = 10,
    loading = false,
    emptyMessage = "No data available",
    pagination,
    onPageChange,
}: ReusableTableProps<T>) => {
    const [openActionMenu, setOpenActionMenu] = useState<number | null>(null);
    // Use server pagination current page if provided, otherwise use local state
    const [clientCurrentPage, setClientCurrentPage] = useState(1);
    const [menuCoordinates, setMenuCoordinates] = useState<{ top: number; left: number; right: number } | null>(null);

    const actionMenuRef = useRef<HTMLDivElement>(null);
    const buttonRefs = useRef<Map<number, HTMLButtonElement>>(new Map());

    // Determine if using server-side pagination
    const isServerSidePagination = pagination !== undefined && onPageChange !== undefined;
    
    // Use server pagination data if available, otherwise calculate from client data
    const currentPage = isServerSidePagination ? pagination.page : clientCurrentPage;
    const totalPages = isServerSidePagination ? pagination.pages : Math.ceil(data.length / rowsPerPage);
    
    // For server-side pagination, use data as-is (already paginated by server)
    // For client-side pagination, slice the data
    const paginatedData = isServerSidePagination 
        ? data 
        : (() => {
            const startIndex = (currentPage - 1) * rowsPerPage;
            const endIndex = startIndex + rowsPerPage;
            return data.slice(startIndex, endIndex);
        })();

    const handlePageChange = (page: number) => {
        if (isServerSidePagination && onPageChange) {
            // Server-side pagination: call the callback to fetch new data
            onPageChange(page);
        } else {
            // Client-side pagination: update local state
            setClientCurrentPage(page);
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const toggleActionMenu = (index: number) => {
        if (openActionMenu === index) {
            setOpenActionMenu(null);
            setMenuCoordinates(null);
        } else {
            // Calculate menu position before opening
            const button = buttonRefs.current.get(index);
            if (button) {
                const buttonRect = button.getBoundingClientRect();
                const viewportHeight = window.innerHeight;
                const viewportWidth = window.innerWidth;
                
                const getActionItemsForRow = (row: T): ActionMenuItem<T>[] => {
                    if (!actionItems) return [];
                    if (typeof actionItems === 'function') {
                        return actionItems(row);
                    }
                    return actionItems;
                };
                
                const rowActionItems = getActionItemsForRow(paginatedData[index] || {} as T);
                
                const itemHeight = 40;
                const containerPadding = 24;
                const estimatedDropdownHeight = (rowActionItems.length || 0) * itemHeight + containerPadding;
                
                // Add a small buffer (20px) to ensure dropdown is fully visible
                const requiredSpace = estimatedDropdownHeight + 20;
                const spaceBelow = viewportHeight - buttonRect.bottom;
                const spaceAbove = buttonRect.top;

                // Determine if menu should open above or below
                const shouldOpenAbove = spaceBelow < requiredSpace && spaceAbove >= requiredSpace;

                // Calculate position for fixed positioning (relative to viewport)
                let top: number;
                if (shouldOpenAbove) {
                    top = buttonRect.top - estimatedDropdownHeight - 4; // mb-1 = 4px
                } else {
                    top = buttonRect.bottom + 4; // mt-1 = 4px
                }

                // Calculate right position (align to right edge of button)
                const right = viewportWidth - buttonRect.right;

                setMenuCoordinates({
                    top,
                    right,
                    left: buttonRect.left, // Keep for reference if needed
                });
            }
            setOpenActionMenu(index);
        }
    };

    // Handle clicks outside the action menu
    useOutsideClick(actionMenuRef, () => {
        setOpenActionMenu(null);
        setMenuCoordinates(null);
    });

    // Close menu on scroll to prevent misalignment
    useEffect(() => {
        if (openActionMenu !== null) {
            const handleScroll = () => {
                setOpenActionMenu(null);
                setMenuCoordinates(null);
            };

            window.addEventListener("scroll", handleScroll, true);
            return () => {
                window.removeEventListener("scroll", handleScroll, true);
            };
        }
    }, [openActionMenu]);

    // Render status badge
    const renderStatus = (row: T) => {
        const statusValue = row[statusKey];
        if (!statusValue || !statusConfig) return null;

        const status = typeof statusValue === 'string' ? statusValue.toLowerCase() : String(statusValue).toLowerCase();
        if (!status) return null;

        const config = statusConfig[status];
        if (!config) {
            const displayValue = typeof statusValue === 'string' ? statusValue : String(statusValue);
            return <span className="text-sm">{displayValue}</span>;
        }

        return (
            <span className={cn(
                "px-3 py-1 text-xs font-chivo-regular font-medium uppercase rounded",
                config.className
            )}>
                {config.label}
            </span>
        );
    };
    // Generate page numbers for pagination
    const getPageNumbers = () => {
        const pages: (number | string)[] = [];
        const maxVisible = 7;

        if (totalPages <= maxVisible) {
            // Show all pages if total is less than max visible
            for (let i = 1; i <= totalPages; i++) {
                pages.push(i);
            }
        } else {
            // Always show first page
            pages.push(1);

            if (currentPage > 3) {
                pages.push("...");
            }

            // Show pages around current page
            const start = Math.max(2, currentPage - 1);
            const end = Math.min(totalPages - 1, currentPage + 1);

            for (let i = start; i <= end; i++) {
                pages.push(i);
            }

            if (currentPage < totalPages - 2) {
                pages.push("...");
            }

            // Always show last page
            pages.push(totalPages);
        }

        return pages;
    };
    return (
        <div className="w-full">
            {/* Table Section */}
            <div className="border border-gray-200 bg-white">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-[#00000008] border-b border-gray-200">
                            <tr>
                                {columns.map((column) => (
                                    <th
                                        key={column.key}
                                        className={cn(
                                            "px-6 py-4 text-left text-xs font-chivo-regular font-normal uppercase text-black",
                                            column.className
                                        )}
                                    >
                                        {column.header}
                                    </th>
                                ))}
                                {statusConfig && (
                                    <th className="px-6 py-4 text-left text-xs font-chivo-regular font-normal uppercase text-black">
                                        STATUS
                                    </th>
                                )}
                                {actionItems && (
                                    <th className="px-6 py-4 text-left text-xs font-chivo-regular font-normal uppercase text-black">
                                        ACTION
                                    </th>
                                )}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {loading ? (
                                <tr>
                                    <td
                                        colSpan={columns.length + (statusConfig ? 1 : 0) + (actionItems && actionItems.length > 0 ? 1 : 0)}
                                        className="px-6 py-12 text-center text-sm text-gray-500"
                                    >
                                        Loading...
                                    </td>
                                </tr>
                            ) : paginatedData.length === 0 ? (
                                <tr>
                                    <td
                                        colSpan={columns.length + (statusConfig ? 1 : 0) + (actionItems && actionItems.length > 0 ? 1 : 0)}
                                        className="px-6 py-12 text-center text-sm text-gray-500"
                                    >
                                        {emptyMessage}
                                    </td>
                                </tr>
                            ) : (
                                paginatedData.map((row, rowIndex) => (
                                    <tr key={rowIndex} className="hover:bg-[#00000008] transition-colors">
                                        {columns.map((column) => (
                                            <td
                                                key={column.key}
                                                className={cn(
                                                    "px-6 py-4 text-sm font-chivo-regular text-gray-900 uppercase",
                                                    column.className
                                                )}
                                            >
                                                {column.render ? column.render(row) : String(row[column.key] ?? '')}
                                            </td>
                                        ))}
                                        {statusConfig && (
                                            <td className="px-6 py-4">
                                                {renderStatus(row)}
                                            </td>
                                        )}
                                        {actionItems && (() => {
                                            const getActionItemsForRow = (row: T): ActionMenuItem<T>[] => {
                                                if (!actionItems) return [];
                                                if (typeof actionItems === 'function') {
                                                    return actionItems(row);
                                                }
                                                return actionItems;
                                            };
                                            const rowActionItems = getActionItemsForRow(row);
                                            return rowActionItems.length > 0 ? (
                                                <td className="px-6 py-4">
                                                    <div className="relative" ref={rowIndex === openActionMenu ? actionMenuRef : null}>
                                                        <button
                                                            ref={(el) => {
                                                                if (el) {
                                                                    buttonRefs.current.set(rowIndex, el);
                                                                } else {
                                                                    buttonRefs.current.delete(rowIndex);
                                                                }
                                                            }}
                                                            onClick={() => toggleActionMenu(rowIndex)}
                                                            className="p-1 hover:bg-gray-100 rounded transition-colors"
                                                            aria-label="Actions"
                                                        >
                                                            <MoreVertical size={18} className="text-gray-600" />
                                                        </button>
                                                    </div>
                                                </td>
                                            ) : null;
                                        })()}
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
            {/* Pagination Section */}
            {totalPages > 1 && (
                <div className="flex items-center justify-between mt-6">
                    {/* Previous Button */}
                    <button
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                        className={cn(
                            "bg-[#0000000D] w-10 h-10 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                            currentPage === 1 && "cursor-not-allowed"
                        )}
                        aria-label="Previous page"
                    >
                        <BsArrowLeft size={18} />
                    </button>

                    {/* Page Numbers */}
                    <div className="flex items-center justify-center gap-1 grow">
                        {getPageNumbers().map((page, index) => (
                            <button
                                key={index}
                                onClick={() => typeof page === "number" && handlePageChange(page)}
                                disabled={typeof page !== "number"}
                                className={cn(
                                    "min-w-10 h-10 flex items-center justify-center text-sm font-chivo-regular transition-colors",
                                    typeof page === "number"
                                        ? page === currentPage
                                            ? "bg-black text-white border-black"
                                            : ""
                                        : ""
                                )}
                            >
                                {page}
                            </button>
                        ))}
                    </div>

                    {/* Next Button */}
                    <button
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                        className={cn(
                            "bg-[#0000000D] w-10 h-10 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                            currentPage === totalPages && "cursor-not-allowed"
                        )}
                        aria-label="Next page"
                    >
                        <BsArrowRight size={18} />
                    </button>
                </div>
            )}

            {/* Action Menu Dropdown - Rendered outside table to avoid clipping */}
            {openActionMenu !== null && menuCoordinates && paginatedData[openActionMenu] && (() => {
                const getActionItemsForRow = (row: T): ActionMenuItem<T>[] => {
                    if (!actionItems) return [];
                    if (typeof actionItems === 'function') {
                        return actionItems(row);
                    }
                    return actionItems;
                };
                const rowActionItems = getActionItemsForRow(paginatedData[openActionMenu]);
                
                return (
                    <div
                        ref={actionMenuRef}
                        className="fixed min-w-52 bg-white border border-gray-200 rounded shadow-lg z-50 p-3"
                        style={{
                            top: `${menuCoordinates.top}px`,
                            right: `${menuCoordinates.right}px`,
                        }}
                    >
                        <div className="flex flex-col gap-2">
                            {rowActionItems.map((item, itemIndex) => (
                                <button
                                    key={itemIndex}
                                    onClick={() => {
                                        item.onClick(paginatedData[openActionMenu]);
                                        setOpenActionMenu(null);
                                        setMenuCoordinates(null);
                                    }}
                                    className={cn(
                                        "w-full flex items-center gap-2 px-4 py-2 text-sm font-chivo-regular hover:bg-gray-100 text-left uppercase",
                                        item.className
                                    )}
                                    style={{
                                        letterSpacing: "-2%"
                                    }}
                                >
                                    {item.icon && <span className="flex-shrink-0">{item.icon}</span>}
                                    <span className="whitespace-nowrap">{item.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                );
            })()}
        </div>
    );
};

export default ReusableTable;