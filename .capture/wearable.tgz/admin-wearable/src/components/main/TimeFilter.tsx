import { useRef, useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "../../lib/utils";
import { useOutsideClick } from "../../hooks";
import type { TimeFilter } from "../../types/charts";
import { timeFilterOptions, getTimeFilterLabel } from "../../types/charts";

type TimeFilterProps = {
    activeFilter: TimeFilter;
    handleFilter: (filter: TimeFilter) => void;
}

const TimeFilterComponent = ({
    activeFilter,
    handleFilter,
}: TimeFilterProps) => {
    const filterRef = useRef<HTMLDivElement>(null);
    const [isFilterOpen, setIsFilterOpen] = useState<boolean>(false);

    const handleFilterClick = (filter: TimeFilter) => {
        setIsFilterOpen(false);
        handleFilter(filter);
    }

    useOutsideClick(filterRef, () => {
        setIsFilterOpen(false);
    });

    return (
        <div className="relative" ref={filterRef}>
            <button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded text-sm font-chivo-regular font-normal uppercase bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent"
            >
                <span>{getTimeFilterLabel(activeFilter)}</span>
                <ChevronDown size={16} className={cn("transition-transform", isFilterOpen && "rotate-180")} />
            </button>

            {isFilterOpen && (
                <div className="absolute top-full right-0 mt-1 w-48 bg-white border border-gray-200 rounded shadow-lg z-50">
                    <div className="py-1">
                        {timeFilterOptions.map((option) => (
                            <button
                                key={option.value}
                                onClick={() => handleFilterClick(option.value)}
                                className={cn(
                                    "w-full text-left px-4 py-2 text-sm font-chivo-regular hover:bg-gray-100",
                                    activeFilter === option.value && "bg-gray-100"
                                )}
                            >
                                {option.label}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default TimeFilterComponent;

