import { Link } from "react-router-dom";


type ButtonProps = {
    title: string;
    className?: string;
    disabled?: boolean;
    loading?: boolean;
    onClick?: () => void;
    href?: string;
    icon?: React.ReactNode;
    variant?: "black" | "white";
    type?: "button" | "submit" | "reset";
}

const Button = ({
    title,
    className,
    disabled,
    loading,
    onClick,
    href,
    icon,
    variant = "black",
    type = "button"
}: ButtonProps) => {

    const variantClasses = {
        black: "bg-black text-white",
        white: "bg-white text-black",
    }

    const baseClasses = "px-8 py-4 text-sm lg:text-base font-chivo-regular font-normal leading-[100%] uppercase w-fit cursor-pointer flex items-center gap-2 justify-center";

    if (href) {
        return (
            <Link
                to={href}
                className={`${baseClasses} ${variantClasses[variant]} ${className}`}
                style={{
                    letterSpacing: "-2%",
                }}
            >
                {icon && icon}
                <span>{title}</span>
            </Link>
        )
    }
    return (
        <button
            type={type}
            className={`${baseClasses} ${variantClasses[variant]} ${className}`}
            onClick={onClick}
            disabled={disabled}
            style={{
                opacity: loading ? 0.5 : 1,
                letterSpacing: "-2%",
            }}
        >
            <div className="flex items-center justify-center gap-2">
                {icon && icon}
                <span>{title}</span>
            </div>
        </button>
    )
}

export default Button