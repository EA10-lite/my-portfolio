import React, { useRef, useState, useCallback, useEffect, useMemo } from "react";
import { type FormikValues, useFormikContext } from "formik";
import Error from "./Error";
import { PiExportLight, PiFileJpg } from "react-icons/pi";
import { Text } from "../main";
import { LuTrash2 } from "react-icons/lu";
import { formatFileSize } from "../../utils/formatter";

interface ImagePickerProps {
    name: string;
    label?: string;
    required?: boolean;
    disabled?: boolean;
    acceptedTypes?: string[];
    maxSize?: number; // in MB
    placeholder?: string;
    multiple?: boolean; // Allow multiple file selection
    maxFiles?: number; // Maximum number of files when multiple is true
    customHandleChange?: (files: File[] | File | null) => void;
    icon?: boolean;
    showPreview?: boolean;
}

const ImagePicker: React.FC<ImagePickerProps> = ({
    name,
    disabled = false,
    acceptedTypes = ["image/jpeg", "image/png", "application/pdf"],
    placeholder,
    multiple = false,
    maxFiles = 5,
    customHandleChange,
    showPreview = true,
}) => {
    const { errors, touched, setFieldValue, values } = useFormikContext<FormikValues>();
    const [isDragOver, setIsDragOver] = useState(false);
    const [fileProgress, setFileProgress] = useState<{[key: string]: number}>({});
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Derive selectedFiles from Formik values instead of maintaining separate state
    const selectedFiles = useMemo(() => {
        const formikFiles = values[name];
        if (!formikFiles) return [];
        return Array.isArray(formikFiles) ? formikFiles : [formikFiles];
    }, [values, name]);

    // Clear file input when form is reset
    useEffect(() => {
        const formikFiles = values[name];
        if (!formikFiles || (Array.isArray(formikFiles) && formikFiles.length === 0)) {
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
            setFileProgress((prev) => {
                if (Object.keys(prev).length > 0) {
                    return {};
                }
                return prev;
            });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values[name]]);

    const simulateFileUpload = (file: File) => {
        const fileKey = `${file.name}-${file.size}`;
        setFileProgress(prev => ({ ...prev, [fileKey]: 0 }));

        const interval = setInterval(() => {
            setFileProgress(prev => {
                const currentProgress = prev[fileKey] || 0;
                if (currentProgress >= 100) {
                    clearInterval(interval);
                    return prev;
                }
                return { ...prev, [fileKey]: currentProgress + Math.random() * 15 };
            });
        }, 200);

        // Clean up after 3 seconds
        setTimeout(() => {
            clearInterval(interval);
            setFileProgress(prev => ({ ...prev, [fileKey]: 100 }));
        }, 3000);
    };


    const handleFileSelect = useCallback((files: File[]) => {
        // Get current files from Formik values
        const currentFiles = values[name];
        const existingFiles = Array.isArray(currentFiles) ? currentFiles : currentFiles ? [currentFiles] : [];
        const newFiles = [...existingFiles];

        files.forEach(file => {
            // Check if we've reached max files
            if (multiple && newFiles.length >= maxFiles) {
                return;
            }

            // Check for duplicate files
            const isDuplicate = newFiles.some(existingFile => 
                existingFile.name === file.name && existingFile.size === file.size
            );
            
            if (!isDuplicate) {
                newFiles.push(file);
                simulateFileUpload(file);
            }
        });
        
        // Update Formik directly - selectedFiles will be derived automatically
        setFieldValue(name, multiple ? newFiles : newFiles[0] || null);
        
        if (customHandleChange) {
            customHandleChange(multiple ? newFiles : newFiles[0] || null);
        }
        
        // Clear the file input to allow re-selecting the same files
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    }, [name, maxFiles, multiple, values, setFieldValue, customHandleChange]);

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragOver(false);
        
        if (disabled) return;

        const files = Array.from(e.dataTransfer.files);
        if (files.length > 0) {
            handleFileSelect(files);
        }
    }, [handleFileSelect, disabled]);

    const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        if (!disabled) {
            setIsDragOver(true);
        }
    }, [disabled]);

    const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        setIsDragOver(false);
    }, []);

    const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            handleFileSelect(Array.from(files));
        }
    };

    const handleBrowseClick = () => {
        if (!disabled && fileInputRef.current) {
            fileInputRef.current.click();
        }
    };

    const handleRemoveFile = (fileToRemove?: File) => {
        if (fileToRemove) {
            // Remove specific file
            const fileKey = `${fileToRemove.name}-${fileToRemove.size}`;
            setFileProgress(prev => {
                const newProgress = { ...prev };
                delete newProgress[fileKey];
                return newProgress;
            });

            const newFiles = selectedFiles.filter(file =>
                !(file.name === fileToRemove.name && file.size === fileToRemove.size)
            );
            // Update Formik directly - selectedFiles will be derived automatically
            setFieldValue(name, multiple ? newFiles : newFiles[0] || null);
            if (customHandleChange) {
                customHandleChange(multiple ? newFiles : newFiles[0] || null);
            }
        } else {
            // Remove all files (only when explicitly called without a specific file)
            setFileProgress({});
            setFieldValue(name, multiple ? [] : null);
            if (customHandleChange) {
                customHandleChange(multiple ? [] : null);
            }
        }
        
        // Always clear the file input to allow re-selecting files
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    return (
        <div className="form-field mb-5">

            <div className="relative">
                {/* Hidden file input */}
                <input
                    ref={fileInputRef}
                    type="file"
                    accept={acceptedTypes.join(',')}
                    onChange={handleFileInputChange}
                    className="hidden"
                    disabled={disabled}
                    multiple={multiple}
                />

                {/* Drop zone */}
                <div
                    className={`
                        relative bg-[#00000008] border-2 border-dashed p-8 text-center cursor-pointer transition-all duration-200
                        ${isDragOver
                            ? 'border-teal-500 bg-teal-50'
                            : 'border-gray-300 hover:border-gray-400'
                        }
                        ${disabled
                            ? 'opacity-50 cursor-not-allowed'
                            : 'hover:bg-gray-50'
                        }
                        ${errors?.[name] && touched?.[name]
                            ? 'border-red-500'
                            : ''
                        }
                    `}
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onClick={handleBrowseClick}
                >
                    {/* Always show upload area */}
                    <div className="space-y-4">
                        <div className="w-10 h-10 mx-auto bg-black flex items-center justify-center mb-3">
                            <PiExportLight className="text-white" />
                        </div>
                        <div className="flex flex-col items-center">
                            <p className="text-black text-center text-sm font-chivo-regular font-normal leading-base uppercase mb-1">
                                {placeholder || (multiple ? "Drag & drop or" : "Drag & drop or")}{" "}
                                <span className="underline cursor-pointer">Choose File</span>{" "}
                                to upload
                            </p>
                            <p className="text-[#909090] text-center text-sm font-chivo-regular font-[300] leading-base uppercase">
                                IMAGE FORMAT: JPEG, PNG 3MB MAX
                            </p>
                        </div>
                    </div>
                </div>

                {/* Selected files display - outside the upload box */}
                {selectedFiles.length > 0 && showPreview && (
                    <div className="mt-4 space-y-3">
                        <div className="space-y-2">
                            {selectedFiles.map((file, index) => {
                                const fileKey = `${file.name}-${file.size}`;
                                const progress = fileProgress[fileKey] || 0;

                                return (
                                    <div
                                    key={index}
                                    className="flex items-center gap-2"
                                >
                                    <div
                                        className="grow bg-[#00000008] border border-[#909090] p-3 flex items-center justify-between gap-2"
                                        style={{
                                            borderStyle: "dashed",
                                        }}
                                    >
                                        <PiFileJpg size={32} />
                                        <div className="grow flex flex-col gap-2">
                                            <div className="flex items-center justify-between">
                                                <Text
                                                    title={file.name}
                                                    type="p"
                                                />
                                                <Text
                                                    title={formatFileSize(file.size)}
                                                    type="p"
                                                />
                                            </div>
        
                                            <div className="progress-bar grow bg-[#0000001A] h-1.5 relative overflow-hidden rounded">
                                                <div
                                                    className="progress-bar-inner bg-black h-full transition-all duration-300 ease-out"
                                                    style={{
                                                        width: `${progress}%`,
                                                    }}
                                                />
                                            </div>
                                        </div>

                                        <p></p>
                                    </div>

                                    <LuTrash2
                                        className="text-red-600 cursor-pointer"
                                        onClick={() => handleRemoveFile(file)}
                                    />
                                </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Error message */}
                <Error
                    error={errors?.[name] as string | undefined}
                    visible={!!touched?.[name]}
                />
            </div>
        </div>
    );
};

export default ImagePicker;