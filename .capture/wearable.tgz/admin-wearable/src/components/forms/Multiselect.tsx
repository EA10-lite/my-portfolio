"use client";
import { useRef, useState } from "react";
import { useFormikContext, type FormikValues } from "formik";
import Label from "./Label";
import Error from "./Error";
import { ChevronDown } from "lucide-react";
import { cn } from "../../lib/utils";
import { useOutsideClick } from "../../hooks";
import { VscClose } from "react-icons/vsc";
import { BsCheck2 } from "react-icons/bs";

type MultiSelectProps = {
    name: string;
    label: string;
    options: { value: string; label: string }[];
    disabled?: boolean;
}

const MultiSelect = ({ name, label, options }: MultiSelectProps) => {
    const { errors, touched, setFieldValue, values } = useFormikContext<FormikValues>();
    const selectRef = useRef<HTMLDivElement>(null);

    const [isSelectOpen, setIsSelectOpen] = useState<boolean>(false);

    const selectedValues: string[] = Array.isArray(values[name]) ? values[name] : [];

    const handleOptionClick = (value: string) => {
        const isSelected = selectedValues.includes(value);

        if (isSelected) {
            const newSelection = selectedValues.filter((val) => val !== value);
            setFieldValue(name, newSelection);
        } else {
            const newSelection = [...selectedValues, value];
            setFieldValue(name, newSelection);
        }
    };

    useOutsideClick(selectRef, () => {
        setIsSelectOpen(false);
    });

    return (
        <div className="mb-5 form-multiselect">
            <Label
                name={name}
                label={label}
            />

            <div className="form-multiselect relative">
                <div className="relative" ref={selectRef}>
                    <button
                        onClick={() => setIsSelectOpen(!isSelectOpen)}
                        className="flex w-full items-center justify-between gap-2 px-3 border border-gray-200 text-sm font-chivo-regular font-normal uppercase bg-white hover:bg-gray-50 focus:outline-none h-11"
                    >
                        {/* Display selected option tags/badges above the dropdown */}
                        {selectedValues.length > 0 ? (
                            <div className="flex overflow-x-auto gap-2">
                                {options
                                    .filter((option) => selectedValues.includes(option.value))
                                    .map((option) => (
                                        <span
                                            key={option.value}
                                            className="inline-flex items-center gap-1 px-2 py-1 bg-black text-sm font-chivo-regular uppercase text-white min-w-fit"
                                        >
                                            {option.label}
                                            <button
                                                type="button"
                                                onClick={() => handleOptionClick(option.value)}
                                                className="text-base ml-1 hover:text-red-600 focus:outline-none"
                                                aria-label={`Remove ${option.label}`}
                                            >
                                                <VscClose />
                                            </button>
                                        </span>
                                    ))}
                            </div>
                        ) : (
                            <div className="" />
                        )}

                        <ChevronDown
                            size={16}
                            className={cn("transition-transform flex-shrink-0", isSelectOpen && "rotate-180")}
                        />
                    </button>

                    {isSelectOpen && (
                        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-200 rounded shadow-lg z-50 max-h-60 overflow-y-auto">
                            <div className="py-1">
                                {options.map((option) => {
                                    const isSelected = selectedValues.includes(option.value);
                                    return (
                                        <button
                                            key={option.value}
                                            onClick={() => handleOptionClick(option.value)}
                                            className={cn(
                                                "w-full text-left px-4 py-2 text-sm font-chivo-regular hover:bg-gray-100 transition-colors flex items-center justify-between uppercase",
                                                isSelected && "bg-gray-100 font-semibold"
                                            )}
                                        >
                                            <span className={cn(isSelected && "font-chivo-semibold")}>
                                                {option.label}
                                            </span>
                                            {isSelected && (
                                                <BsCheck2 />
                                            )}
                                        </button>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <Error
                error={errors?.[name] as string | undefined}
                visible={!!touched?.[name]}
            />
        </div>
    )
}

export default MultiSelect;