import { useFormikContext, type FormikValues } from "formik";
import Error from "./Error";
import Label from "./Label";


type ColorPickerProps = {
    name: string;
    label: string;
    options: { value: string; label: string }[];
}

const ColorPicker = ({ name, label, options }: ColorPickerProps) => {
    const { errors, touched, setFieldValue, values } = useFormikContext<FormikValues>();

    // Ensure the field value is always an array
    const selectedColors = Array.isArray(values[name]) ? values[name] as string[] : [];

    /**
     * Toggles a color selection on/off
     * If the color is already selected, it will be removed from the array
     * If the color is not selected, it will be added to the array
     */
    const handleColorToggle = (colorValue: string) => {
        const normalizedValue = colorValue.toLowerCase();
        const currentColors = selectedColors.map(c => c.toLowerCase());
        
        if (currentColors.includes(normalizedValue)) {
            // Remove color if already selected
            const updatedColors = selectedColors.filter(
                c => c.toLowerCase() !== normalizedValue
            );
            setFieldValue(name, updatedColors);
        } else {
            // Add color if not selected
            setFieldValue(name, [...selectedColors, colorValue]);
        }
    };

    /**
     * Checks if a color is currently selected
     * Performs case-insensitive comparison to handle variations
     */
    const isColorSelected = (colorValue: string): boolean => {
        return selectedColors.some(
            selectedColor => selectedColor.toLowerCase() === colorValue.toLowerCase()
        );
    };

    return (
        <div className="form-color-picker mb-5">
            <Label
                name={name}
                label={label}
            />

            <div className="form-color-picker-options">
                <div className="flex items-center gap-2">
                    {options.map((option) => {
                        const isSelected = isColorSelected(option.value);
                        return (
                            <div
                                key={option.value}
                                className="w-8 h-8 border border-black flex items-center justify-center cursor-pointer"
                                onClick={() => handleColorToggle(option.value)}
                            >
                                <div
                                    className="w-6 h-6 bg-black"
                                    style={{ 
                                        backgroundColor: isSelected ? option.value : "transparent" 
                                    }}
                                />
                            </div>
                        );
                    })}
                </div>
            </div>

            <Error
                error={errors?.[name] as string | undefined}
                visible={!!touched?.[name]}
            />
        </div>
    )
}

export default ColorPicker;