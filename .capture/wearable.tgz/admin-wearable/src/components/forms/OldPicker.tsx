import { useFormikContext, type FormikValues } from "formik";
import { useRef, useState, useEffect } from "react";
import { LuTrash2 } from "react-icons/lu";
import { PiExportLight, PiFileJpg } from "react-icons/pi";
import { Text } from "../main";
import { formatFileSize } from "../../utils/formatter";
import Error from "./Error";

const ImagePicker = ({ name }: { name: string }) => {
    const { values, setFieldValue, errors, touched } = useFormikContext<FormikValues>();

    const fileInputRef = useRef<HTMLInputElement>(null);
    const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});
    // Track intervals for cleanup
    const intervalsRef = useRef<Record<string, ReturnType<typeof setInterval>>>({});
    // Track which files have started simulation to avoid duplicate starts
    const simulationStartedRef = useRef<Set<string>>(new Set());

    const handleInputClick = () => fileInputRef?.current?.click();

    /**
     * Generates a unique key for each file based on name and size
     * This allows us to track progress even if files are reordered
     */
    const getFileKey = (file: File): string => {
        return `${file.name}-${file.size}-${file.lastModified}`;
    };

    /**
     * Simulates upload progress for a file from 0% to 100%
     * Progress increments with varying speeds to make it feel more realistic
     */
    const simulateProgress = (fileKey: string) => {
        // Mark that simulation has started for this file
        simulationStartedRef.current.add(fileKey);

        // Clear any existing interval for this file
        if (intervalsRef.current[fileKey]) {
            clearInterval(intervalsRef.current[fileKey]);
        }

        let currentProgress = 0;
        
        // Initialize progress at 0%
        setUploadProgress((prev) => ({
            ...prev,
            [fileKey]: 0,
        }));

        // Create interval that updates progress
        intervalsRef.current[fileKey] = setInterval(() => {
            currentProgress += Math.random() * 15 + 5; // Random increment between 5-20%

            if (currentProgress >= 100) {
                currentProgress = 100;
                setUploadProgress((prev) => ({
                    ...prev,
                    [fileKey]: 100,
                }));
                // Clear interval when complete
                if (intervalsRef.current[fileKey]) {
                    clearInterval(intervalsRef.current[fileKey]);
                    delete intervalsRef.current[fileKey];
                }
            } else {
                setUploadProgress((prev) => ({
                    ...prev,
                    [fileKey]: Math.floor(currentProgress),
                }));
            }
        }, 150); // Update every 150ms for smooth animation
    };

    /**
     * Handles file selection and triggers progress simulation
     * Appends new files to existing files array instead of replacing them
     */
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFiles = e.target.files;
        if (!selectedFiles) return;

        const newFilesArray = Array.from(selectedFiles);
        const existingFiles = (values[name] as File[]) || [];
        
        // Create a set of existing file keys to check for duplicates
        const existingFileKeys = new Set(existingFiles.map(getFileKey));
        
        // Filter out duplicates - only keep files that aren't already added
        const uniqueNewFiles = newFilesArray.filter((file) => {
            const fileKey = getFileKey(file);
            return !existingFileKeys.has(fileKey);
        });

        // Merge existing files with new unique files
        const allFiles = [...existingFiles, ...uniqueNewFiles];
        setFieldValue(name, allFiles);

        // Start progress simulation for newly added files only
        uniqueNewFiles.forEach((file) => {
            const fileKey = getFileKey(file);
            // Only simulate if not already started
            if (!simulationStartedRef.current.has(fileKey)) {
                simulateProgress(fileKey);
            }
        });

        // Reset the input so users can select the same file again if needed
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    /**
     * Removes a file and cleans up its progress tracking
     */
    const removeFile = (index: number) => {
        const updatedFiles = [...values[name]];
        const removedFile = updatedFiles[index];
        
        // Clean up interval if exists
        if (removedFile) {
            const fileKey = getFileKey(removedFile);
            if (intervalsRef.current[fileKey]) {
                clearInterval(intervalsRef.current[fileKey]);
                delete intervalsRef.current[fileKey];
            }
            // Remove from simulation tracking
            simulationStartedRef.current.delete(fileKey);
            // Remove progress tracking
            setUploadProgress((prev) => {
                const updated = { ...prev };
                delete updated[fileKey];
                return updated;
            });
        }

        updatedFiles.splice(index, 1);
        setFieldValue(name, updatedFiles);
    };

    /**
     * Effect to simulate progress for existing files that might not have progress yet
     * This handles cases where files were added before progress simulation was implemented
     */
    useEffect(() => {
        const files = (values[name] as File[]) || [];
        const currentFileKeys = new Set(files.map(getFileKey));

        // Start progress simulation for files that haven't started yet
        files.forEach((file) => {
            const fileKey = getFileKey(file);
            // Only simulate if we haven't started simulation for this file yet
            if (!simulationStartedRef.current.has(fileKey)) {
                simulateProgress(fileKey);
            }
        });

        // Cleanup: Remove progress tracking for files that no longer exist
        setUploadProgress((prev) => {
            const filesToRemove: string[] = [];
            
            // Find files that need to be removed
            Object.keys(prev).forEach((key) => {
                if (!currentFileKeys.has(key)) {
                    filesToRemove.push(key);
                }
            });

            // Clean up intervals and tracking for removed files
            filesToRemove.forEach((key) => {
                // Clean up interval
                if (intervalsRef.current[key]) {
                    clearInterval(intervalsRef.current[key]);
                    delete intervalsRef.current[key];
                }
                // Remove from simulation tracking
                simulationStartedRef.current.delete(key);
            });

            // Remove from progress state if any files were removed
            if (filesToRemove.length > 0) {
                const updated = { ...prev };
                filesToRemove.forEach((key) => {
                    delete updated[key];
                });
                return updated;
            }

            return prev;
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values[name]]);

    /**
     * Cleanup all intervals on unmount
     */
    useEffect(() => {
        return () => {
            Object.values(intervalsRef.current).forEach((interval) => {
                clearInterval(interval);
            });
            intervalsRef.current = {};
        };
    }, []);

    return (
        <div className="form-image-picker mb-5">
            <div className="form-image-picker-input">
                <div
                    className="bg-[#00000008] border border-[#909090] flex flex-col items-center justify-center min-h-44"
                    style={{
                        borderStyle: "dashed",
                        borderSpacing: 20,
                    }}
                >

                    <div className="w-10 h-10 bg-black flex items-center justify-center mb-3">
                        <PiExportLight className="text-white" />
                    </div>

                    <p className="text-black text-center text-sm font-chivo-regular font-normal leading-base uppercase mb-1">
                        Drag & drop or {" "}
                        <span
                            className="underline cursor-pointer"
                            onClick={handleInputClick}
                        > Choose File</span>
                        {" "}to upload
                    </p>
                    <p className="text-[#909090] text-center text-sm font-chivo-regular font-[300] leading-base uppercase">
                        IMAGE FORMAT: JPEG, PNG 3MB MAX
                    </p>
                    <input
                        type="file"
                        name="file"
                        className="w-0 h-0 file-input"
                        accept=".png,.jpg,.jpeg"
                        multiple
                        ref={fileInputRef}
                        onChange={handleFileChange}
                    />
                </div>
            </div>
            <div className="form-image-picker-preview mt-3 flex flex-col gap-3">
                {values[name]?.map((file: File, index: number) => {
                    const fileKey = getFileKey(file);
                    const progress = uploadProgress[fileKey] ?? 0;

                    return (
                        <div
                            key={index}
                            className="flex items-center gap-2"
                        >
                            <div
                                className="grow bg-[#00000008] border border-[#909090] p-3 flex items-center justify-between gap-2"
                                style={{
                                    borderStyle: "dashed",
                                }}
                            >
                                <PiFileJpg size={32} />

                                <div className="grow flex flex-col gap-2">
                                    <div className="flex items-center justify-between">
                                        <Text
                                            title={file.name}
                                            type="p"
                                        />
                                        <Text
                                            title={formatFileSize(file.size)}
                                            type="p"
                                        />
                                    </div>

                                    <div className="progress-bar grow bg-[#0000001A] h-1.5 relative overflow-hidden rounded">
                                        <div
                                            className="progress-bar-inner bg-black h-full transition-all duration-300 ease-out"
                                            style={{
                                                width: `${progress}%`,
                                            }}
                                        />
                                    </div>
                                </div>

                                <p></p>
                            </div>

                            <LuTrash2
                                className="text-red-600 cursor-pointer"
                                onClick={() => removeFile(index)}
                            />
                        </div>
                    );
                })}
            </div>

            {/* Error message */}
            <Error
                error={errors?.[name] as string | undefined}
                visible={!!touched?.[name]}
            />
        </div>
    )
}

export default ImagePicker;