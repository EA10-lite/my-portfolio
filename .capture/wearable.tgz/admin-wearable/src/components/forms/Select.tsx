"use client";
import { useRef, useState } from "react";
import { useFormikContext, type FormikValues } from "formik";
import Label from "./Label";
import Error from "./Error";
import { ChevronDown } from "lucide-react";
import { cn } from "../../lib/utils";
import { useOutsideClick } from "../../hooks";

type SelectProps = {
    name: string;
    label: string;
    options: { value: string; label: string }[];
    disabled?: boolean;
    placeholder?: string;
}

const Select = ({ name, label, options, placeholder }: SelectProps) => {
    const { errors, touched, handleChange, values } = useFormikContext<FormikValues>();
    const selectRef = useRef<HTMLDivElement>(null);

    const [isSelectOpen, setIsSelectOpen] = useState<boolean>(false);

    const handleSelectClick = (value: string) => {
        setIsSelectOpen(false);
        handleChange({ target: { name, value } } as React.ChangeEvent<HTMLSelectElement>);
    }


    useOutsideClick(selectRef, () => {
        setIsSelectOpen(false);
    });

    return (
        <div className="mb-5 form-select">
            <Label
                name={name}
                label={label}
            />

            <div className="form-select relative">
                <div className="relative" ref={selectRef}>
                    <button
                        onClick={() => setIsSelectOpen(!isSelectOpen)}
                        className={`flex w-full items-center justify-between gap-2 px-4 py-3 border text-sm font-chivo-regular font-normal uppercase bg-white hover:bg-gray-50 focus:outline-none ${errors?.[name] && touched?.[name] ? 'border-red-500' : 'border-[#D2D2D2]'}`}
                    >
                        <span>{placeholder ? placeholder : values[name]}</span>
                        <ChevronDown
                            size={16}
                            className={cn("transition-transform", isSelectOpen && "rotate-180")}
                        />
                    </button>

                    {isSelectOpen && (
                        <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-200 rounded shadow-lg z-50">
                            <div className="py-1">
                                {options.map((option) => (
                                    <button
                                        key={option.value}
                                        onClick={() => handleSelectClick(option.value)}
                                        className={cn(
                                            "w-full text-left px-4 py-2 text-sm font-chivo-regular uppercase hover:bg-gray-100",
                                            values[name] === option.value && "bg-gray-100"
                                        )}
                                    >
                                        {option.label}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <Error
                error={errors?.[name] as string | undefined}
                visible={!!touched?.[name]}
            />
        </div>
    )
}

export default Select;