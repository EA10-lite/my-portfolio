"use client";
import { useState, useRef } from "react";
import { useFormikContext, type FormikValues } from "formik";
import Label from "./Label";
import Error from "./Error";
import { Calendar, ChevronDown } from "lucide-react";
import { cn } from "../../lib/utils";
import ReusableModal from "../main/ReusableModal";

type DatePickerProps = {
    name: string;
    label: string;
    placeholder?: string;
    disabled?: boolean;
}

const DatePicker = ({ name, label, placeholder, disabled }: DatePickerProps) => {
    const { errors, touched, handleChange, values } = useFormikContext<FormikValues>();
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
    const datePickerRef = useRef<HTMLDivElement>(null);

    const selectedDate = values[name] || "";
    const displayValue = selectedDate 
        ? new Date(selectedDate).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        })
        : placeholder || "";

    const handleDateSelect = (date: Date) => {
        const formattedDate = date.toISOString().split('T')[0];
        handleChange({ target: { name, value: formattedDate } } as React.ChangeEvent<HTMLInputElement>);
        setIsModalOpen(false);
    };

    const handleButtonClick = () => {
        if (!disabled) {
            setIsModalOpen(true);
        }
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
    };

    return (
        <div className="mb-5 form-datepicker">
            <Label
                name={name}
                label={label}
            />

            <div className="form-datepicker relative" ref={datePickerRef}>
                <button
                    type="button"
                    onClick={handleButtonClick}
                    disabled={disabled}
                    className={cn(
                        "flex w-full items-center justify-between gap-2 px-4 py-3 border text-sm font-chivo-regular font-normal uppercase bg-white hover:bg-gray-50 focus:outline-none transition-colors",
                        errors?.[name] && touched?.[name] 
                            ? 'border-red-500' 
                            : 'border-[#D2D2D2]',
                        disabled && "opacity-50 cursor-not-allowed"
                    )}
                >
                    <span className={cn(!selectedDate && "text-gray-400")}>
                        {displayValue}
                    </span>
                    <Calendar size={16} className="flex-shrink-0" />
                </button>
            </div>

            <Error
                error={errors?.[name] as string | undefined}
                visible={!!touched?.[name]}
            />

            {isModalOpen && (
                <DatePickerModal
                    isOpen={isModalOpen}
                    onClose={handleCloseModal}
                    selectedDate={selectedDate}
                    onDateSelect={handleDateSelect}
                />
            )}
        </div>
    );
};

type DatePickerModalProps = {
    isOpen: boolean;
    onClose: () => void;
    selectedDate: string;
    onDateSelect: (date: Date) => void;
}

const DatePickerModal = ({ isOpen, onClose, selectedDate, onDateSelect }: DatePickerModalProps) => {
    const [currentMonth, setCurrentMonth] = useState<Date>(() => {
        if (selectedDate) {
            return new Date(selectedDate);
        }
        return new Date();
    });

    const today = new Date();
    const selected = selectedDate ? new Date(selectedDate) : null;

    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    const startingDayOfWeek = firstDayOfMonth.getDay();

    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    const handlePrevMonth = () => {
        setCurrentMonth(new Date(year, month - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentMonth(new Date(year, month + 1, 1));
    };

    const isToday = (day: number) => {
        const date = new Date(year, month, day);
        return date.toDateString() === today.toDateString();
    };

    const isSelected = (day: number) => {
        if (!selected) return false;
        const date = new Date(year, month, day);
        return date.toDateString() === selected.toDateString();
    };

    const handleDateClick = (day: number) => {
        const date = new Date(year, month, day);
        onDateSelect(date);
    };

    const isPastDate = (day: number) => {
        const date = new Date(year, month, day);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return date < today;
    };

    const renderCalendarDays = () => {
        const days = [];
        
        for (let i = 0; i < startingDayOfWeek; i++) {
            days.push(
                <div key={`empty-${i}`} className="w-full aspect-square" />
            );
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const pastDate = isPastDate(day);
            const dayIsToday = isToday(day);
            const dayIsSelected = isSelected(day);

            days.push(
                <button
                    key={day}
                    onClick={() => !pastDate && handleDateClick(day)}
                    disabled={pastDate}
                    className={cn(
                        "w-full aspect-square flex items-center justify-center text-sm font-chivo-regular font-normal rounded transition-colors",
                        pastDate && "opacity-30 cursor-not-allowed",
                        dayIsSelected && "bg-black text-white",
                        !dayIsSelected && !pastDate && "hover:bg-gray-100",
                        dayIsToday && !dayIsSelected && "border-2 border-black"
                    )}
                >
                    {day}
                </button>
            );
        }

        return days;
    };

    return (
        <ReusableModal
            title="Select Date"
            isOpen={isOpen}
            onClose={onClose}
            className="max-w-md"
        >
            <div className="date-picker-content">
                <div className="flex items-center justify-between mb-6">
                    <button
                        onClick={handlePrevMonth}
                        className="p-2 hover:bg-gray-100 rounded transition-colors"
                        aria-label="Previous month"
                    >
                        <ChevronDown size={20} className="rotate-90" />
                    </button>
                    
                    <h3 className="text-base font-chivo-medium font-medium uppercase">
                        {monthNames[month]} {year}
                    </h3>
                    
                    <button
                        onClick={handleNextMonth}
                        className="p-2 hover:bg-gray-100 rounded transition-colors"
                        aria-label="Next month"
                    >
                        <ChevronDown size={20} className="-rotate-90" />
                    </button>
                </div>

                <div className="grid grid-cols-7 gap-1 mb-4">
                    {weekDays.map((day) => (
                        <div
                            key={day}
                            className="text-center text-xs font-chivo-medium font-medium uppercase text-gray-500 py-2"
                        >
                            {day}
                        </div>
                    ))}
                </div>

                <div className="grid grid-cols-7 gap-1">
                    {renderCalendarDays()}
                </div>
            </div>
        </ReusableModal>
    );
};

export default DatePicker;

