export type TimeFilter = '7d' | '30d' | '90d' | '12m' | 'all';

export const timeFilterOptions: { label: string; value: TimeFilter }[] = [
    { label: 'Last 7 Days', value: '7d' },
    { label: 'Last 30 Days', value: '30d' },
    { label: 'Last 90 Days', value: '90d' },
    { label: 'Last 12 Months', value: '12m' },
    { label: 'All Time', value: 'all' },
];

export const getTimeFilterLabel = (value: TimeFilter): string => {
    const option = timeFilterOptions.find((opt) => opt.value === value);
    return option ? option.label : 'Select Time Filter';
};
