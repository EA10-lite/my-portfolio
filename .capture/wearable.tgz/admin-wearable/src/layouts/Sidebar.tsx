import { Link, useLocation } from "react-router-dom";
import { LuShoppingBag, LuLayoutDashboard, LuBox, LuLogOut, LuTruck } from "react-icons/lu";
import { PiUsersThree } from "react-icons/pi";
import { IoMdMenu } from "react-icons/io";
import { useAdminStore } from "../stores/adminStore";
interface SidebarProps {
    isSidebarOpen: boolean;
    onMenuClick: () => void;
}

const Sidebar = ({ isSidebarOpen, onMenuClick }: SidebarProps) => {
    const { logout } = useAdminStore();

    const menuItems = [
        {
            label: "Dashboard",
            path: "/",
            icon: <LuLayoutDashboard />
        },
        {
            label: "Product Management",
            path: "/products",
            icon: <LuBox />
        },
        {
            label: "Order Management",
            path: "/orders",
            icon: <LuShoppingBag />
        },
        {
            label: "Customer Management",
            path: "/customers",
            icon: <PiUsersThree />
        },
        {
            label: "Shipping Fees",
            path: "/shipping-fees",
            icon: <LuTruck />
        },
    ]

    return (
        <div className="h-screen bg-white border-r border-[#E6E6E6] lg:min-w-80">
            <div className="sidebar-container flex flex-col gap-4 p-4 h-full overflow-y-auto">
                <div className={`logo mb-12 lg:mb-16 flex ${!isSidebarOpen ? 'lg:block justify-center lg:justify-start' : 'justify-start'}`}>
                    <div className="lg:hidden">
                        {!isSidebarOpen ? (
                            <button
                                aria-controls="app-sidebar"
                                aria-expanded={isSidebarOpen}
                                aria-label="Toggle navigation menu"
                                className="flex items-center justify-center rounded-full p-2 hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary cursor-pointer"
                                onClick={onMenuClick}
                                type="button"
                            >
                                <IoMdMenu size={24} />
                            </button>
                        ) : (
                            <img 
                                src="/images/logo.svg" 
                                alt="Wearable" 
                            />
                        )}
                    </div>
                    {/* Desktop: Always show logo */}
                    <div className="hidden lg:block">
                        <img 
                            src="/images/logo.svg" 
                            alt="Wearable" 
                        />
                    </div>
                </div>

                <ul className="grow flex flex-col gap-2">
                    {menuItems.map((item) => (
                        <SidebarItem 
                            key={item.label} 
                            {...item}
                            isExpanded={isSidebarOpen}
                        />
                    ))}
                </ul>

                <div className="logout">
                    <button
                        className={`logout-button flex items-center gap-2 py-4 cursor-pointer ${!isSidebarOpen ? 'lg:px-8 px-4 justify-center lg:justify-start' : 'px-8'}`}
                        onClick={logout}
                    >
                        <LuLogOut />
                        <span className={`text-sm font-medium uppercase ${!isSidebarOpen ? 'lg:inline hidden' : 'inline'}`}>
                            Logout
                        </span>
                    </button>
                </div>
            </div>
        </div>
    )
}

type SidebarItemProps = {
    label: string;
    path: string;
    icon: React.ReactNode;
    isExpanded: boolean;
}
const SidebarItem = ({ label, path, icon, isExpanded }: SidebarItemProps) => {
    const { pathname } = useLocation();
    const isActive = path !== "/" && pathname.includes(path) || pathname === path;

    return (
        <div className="sidebar-item">
            <Link 
                to={path} 
                className={`flex items-center gap-2 py-4 ${isActive ? "text-white bg-black" : "text-black"} ${!isExpanded ? 'lg:px-8 px-4 justify-center lg:justify-start' : 'px-8'}`}
                title={!isExpanded ? label : undefined}
            >
                <div className="w-6 flex-shrink-0 flex items-center justify-center">
                    {icon}
                </div>

                <span 
                    className={`text-sm font-chivo-regular font-normal uppercase leading-base ${!isExpanded ? 'lg:inline hidden' : 'inline'}`}
                    style={{
                        letterSpacing: "-2%"
                    }}
                >
                    {label}
                </span>
            </Link>
        </div>
    )
}

export default Sidebar