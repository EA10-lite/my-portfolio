import { LuBell } from "react-icons/lu"
import { Text } from "../components"


const Navbar = () => {
    return (
        <div className="flex items-center justify-between p-4 bg-white border-b border-[#E6E6E6]">
            <div className="flex items-center justify-between gap-2 w-full">
                <h4 className="text-xl font-chivo-medium font-medium uppercase">Overview</h4>

                <div className="flex items-center gap-2">
                    <div className="flex items-center justify-center w-10 h-10 bg-[#0000000D] cursor-pointer">
                        <LuBell />
                    </div>
                    <div className="flex items-center justify-center w-10 h-10 bg-[#0000000D] cursor-pointer">
                        <Text
                            title="JD"
                            type="p"
                            className="text-base"
                            letterSpacing={"-2%"}
                        />
                    </div>

                    <div className="">
                        <Text
                            title="John Doe"
                            type="p"
                            className="text-base"
                            letterSpacing={"-2%"}
                        />
                        <Text
                            title="Super Admin"
                            type="p"
                            className="text-base text-[#7C7C7C]"
                            letterSpacing={"-2%"}
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Navbar