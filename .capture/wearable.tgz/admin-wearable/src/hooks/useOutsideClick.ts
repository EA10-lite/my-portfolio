import { useEffect, type RefObject } from "react";

/**
 * Custom hook to detect clicks outside of a referenced element
 * 
 * @param ref - React ref object pointing to the element to detect outside clicks for
 * @param handler - Callback function to execute when a click outside is detected
 * 
 * @example
 * ```tsx
 * const ref = useRef<HTMLDivElement>(null);
 * 
 * useOutsideClick(ref, () => {
 *   console.log('Clicked outside!');
 *   setIsOpen(false);
 * });
 * ```
 */
export const useOutsideClick = <T extends HTMLElement = HTMLElement>(
    ref: RefObject<T | null>,
    handler: (event: MouseEvent | TouchEvent) => void
): void => {
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent | TouchEvent) => {
            // Do nothing if clicking ref's element or descendent elements
            if (!ref.current || ref.current.contains(event.target as Node)) {
                return;
            }

            handler(event);
        };

        // Bind the event listener
        document.addEventListener("mousedown", handleClickOutside);
        document.addEventListener("touchstart", handleClickOutside);

        return () => {
            // Unbind the event listener on clean up
            document.removeEventListener("mousedown", handleClickOutside);
            document.removeEventListener("touchstart", handleClickOutside);
        };
    }, [ref, handler]);
};

