import { useQuery } from '@tanstack/react-query'
import axios from '../services/client'

interface UseGetOptions {
  enabled?: boolean
  staleTime?: number
  refetchOnWindowFocus?: boolean
}

export const useGet = <T = any>(
  queryKey: string[],
  url: string,
  options?: UseGetOptions
) => {
  return useQuery({
    queryKey,
    queryFn: async (): Promise<T> => {
      const response = await axios.get(url)
      return response.data
    },
    enabled: options?.enabled ?? true,
    staleTime: options?.staleTime,
    refetchOnWindowFocus: options?.refetchOnWindowFocus ?? false,
  })
}
