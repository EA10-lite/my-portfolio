import { useNavigate } from "react-router-dom";
import { ReusableTable, type Column, type ActionMenuItem, TableHeader, TableSkeleton, OrderSummary } from "../../../components";
import type { Order } from "../../../utils/interfaces";
import { Eye, XCircle, Package, Truck, Ship } from "lucide-react";
import { BsCheck2 } from "react-icons/bs";
import { useModalStore } from "../../../stores/modalStore";
import { useOrderStore } from "../../../stores/orderStore";
import { useToastStore } from "../../../stores/toastStore";
import { useQueryClient } from "@tanstack/react-query";
import AssignCourierModal from "./AssignCourierModal";
import { useState } from "react";


const formatCurrency = (amount: number | undefined | null): string => {
    if (amount === undefined || amount === null || isNaN(amount)) return '₦0';
    return `₦${amount.toLocaleString('en-NG')}`;
};

type OrderTableProps = {
    orders: Order[];
    setSearch: (search: string) => void;
    search: string;
    setStatusFilter: (status: string) => void;
    statusFilter: string;
    setPaymentStatusFilter: (paymentStatus: string) => void;
    paymentStatusFilter: string;
    isLoading?: boolean;
}

const statusFilterOptions = [
    { label: "All", value: "all" },
    { label: "Pending", value: "pending" },
    { label: "Confirmed", value: "confirmed" },
    { label: "Packed", value: "packed" },
    { label: "Assigned", value: "assigned" },
    { label: "Shipped", value: "shipped" },
    { label: "Delivered", value: "delivered" },
    { label: "Cancelled", value: "cancelled" },
];

const paymentStatusOptions = [
    { label: "All", value: "all" },
    { label: "Pending", value: "pending" },
    { label: "Paid", value: "paid" },
    { label: "Failed", value: "failed" },
];

type AssignCourierFormValues = {
    productId: string;
    pickupMethod: string;
    date: string;
}


const OrderTable = ({
    orders,
    setSearch,
    search,
    setStatusFilter,
    statusFilter,
    setPaymentStatusFilter,
    paymentStatusFilter,
    isLoading,
}: OrderTableProps) => {
    const navigate = useNavigate();
    const { openOrderSummaryModal, openAssignCourierModal, closeModal} = useModalStore();
    const { updateOrderStatus } = useOrderStore();
    const { showToast } = useToastStore();
    const queryClient = useQueryClient();

    const filterOptions = [
        {
            options: statusFilterOptions,
            handleFilter: setStatusFilter,
            activeFilter: statusFilter,
        },
        {
            options: paymentStatusOptions,
            handleFilter: setPaymentStatusFilter,
            activeFilter: paymentStatusFilter,
        },
    ]

    const columns: Column<Order>[] = [
        {
            key: "id",
            header: "ORDER ID",
            render: (order: Order) => (
                <span className="font-medium">#{order.id}</span>
            ),
        },
        {
            key: "customer",
            header: "CUSTOMER",
            render: (order: Order) => (
                <span>{order.customer.name}</span>
            ),
        },
        {
            key: "items",
            header: "ITEMS",
            render: (order: Order) => (
                <span className="font-medium">{order.items} items</span>
            ),
        },
        {
            key: "amount",
            header: "AMOUNT",
            render: (order: Order) => (
                <span className="font-medium">{formatCurrency(order.amount)}</span>
            ),
        },
        {
            key: "paymentStatus",
            header: "PAYMENT STATUS",
        },
        {
            key: "orderStatus",
            header: "ORDER STATUS",
            render: (order: Order) => (
                <span className="font-medium">{order.orderStatus}</span>
            ),
        },
        {
            key: "createdAt",
            header: "DATE",
        },
    ];


    const handleStatusUpdate = (order: Order, newStatus: string, successMessage: string) => {
        updateOrderStatus(order.id, newStatus);
        queryClient.setQueryData(['orders'], (oldData: Order[] | undefined) => {
            if (!oldData) return oldData;
            return oldData.map((o) => 
                o.id === order.id 
                    ? { ...o, orderStatus: newStatus, updatedAt: new Date().toISOString() }
                    : o
            );
        });
        showToast(successMessage, "success");
    };

    const handleConfirmPayment = (order: Order) => {
        openOrderSummaryModal(order);
    };

    const handleCancelOrder = (order: Order) => {
        handleStatusUpdate(order, "Cancelled", "Order cancelled successfully");
    };

    const [loading, setLoading] = useState<boolean>(false);
    const handleAssignCourier = async(values: AssignCourierFormValues, order: Order) => {
        try {
            setLoading(true);
            console.log(values);
            await new Promise(resolve => setTimeout(resolve, 1000));
            handleStatusUpdate(order, "Assigned", "Order assigned successfully");
            showToast("Order assigned successfully", "success");
            closeModal();
        } catch (error) {
            console.error(error);
            showToast("Error assigning courier", "error");
        } finally {
            setLoading(false);
            showToast("Error assigning courier", "error");
        }
    };

    const getActionItems = (order: Order): ActionMenuItem<Order>[] => {
        const status = order.orderStatus.toLowerCase();
        const actions: ActionMenuItem<Order>[] = [
            {
                label: "View Order",
                icon: <Eye size={16} />,
                onClick: (order: Order) => {
                    navigate(`/orders/${order.id}`);
                },
            },
        ];

        if (status === "cancelled") {
            return actions;
        }

        if (status === "pending") {
            actions.push(
                {
                    label: "Confirm Payment",
                    icon: <BsCheck2 size={16} />,
                    onClick: handleConfirmPayment,
                },
                {
                    label: "Cancel Order",
                    icon: <XCircle size={16} />,
                    onClick: handleCancelOrder,
                    className: "text-red-600 hover:bg-red-50",
                }
            );
        } else if (status === "confirmed") {
            actions.push(
                {
                    label: "Process Order",
                    icon: <BsCheck2 size={16} />,
                    onClick: (order: Order) => {
                        handleStatusUpdate(order, "processing", "Order marked as processing");
                    },
                },
                {
                    label: "Cancel Order",
                    icon: <XCircle size={16} />,
                    onClick: handleCancelOrder,
                    className: "text-red-600 hover:bg-red-50",
                }
            );
        } else if (status === "processing") {
            actions.push(
                {
                    label: "Pack Order",
                    icon: <Package size={16} />,
                    onClick: (order: Order) => {
                        handleStatusUpdate(order, "Packed", "Order packed successfully");
                    },
                },
                {
                    label: "Cancel Order",
                    icon: <XCircle size={16} />,
                    onClick: handleCancelOrder,
                    className: "text-red-600 hover:bg-red-50",
                }
            );
        } else if (status === "packed") {
            actions.push(
                {
                    label: "Assign Order",
                    icon: <Truck size={16} />,
                    onClick: (order: Order) => {
                        openAssignCourierModal(order);
                    },
                },
                {
                    label: "Cancel Order",
                    icon: <XCircle size={16} />,
                    onClick: handleCancelOrder,
                    className: "text-red-600 hover:bg-red-50",
                }
            );
        } else if (status === "assigned") {
            actions.push(
                {
                    label: "Mark as Shipped",
                    icon: <Ship size={16} />,
                    onClick: (order: Order) => {
                        handleStatusUpdate(order, "Shipped", "Order marked as shipped");
                    },
                },
                {
                    label: "Cancel Order",
                    icon: <XCircle size={16} />,
                    onClick: handleCancelOrder,
                    className: "text-red-600 hover:bg-red-50",
                }
            );
        } else if (status === "shipped") {
            actions.push(
                {
                    label: "Mark as Delivered",
                    icon: <Ship size={16} />,
                    onClick: (order: Order) => {
                        handleStatusUpdate(order, "Delivered", "Marked as delivered successfully");
                    },
                },
                {
                    label: "Cancel Order",
                    icon: <XCircle size={16} />,
                    onClick: handleCancelOrder,
                    className: "text-red-600 hover:bg-red-50",
                }
            );
        } else if (status === "delivered") {
            actions.push({
                label: "Delivered",
                icon: <BsCheck2 size={16} />,
                onClick: () => {},
                className: "cursor-not-allowed",
            });
        }

        return actions;
    };



    return (
        <div className="w-full">
            <div className="border border-[#E6E6E6] p-6">
                <TableHeader
                    title="orders"
                    search={search}
                    handleSearch={setSearch}
                    handleExport={() => {}}
                    options={filterOptions}
                />

                {isLoading ? (
                    <TableSkeleton
                        columnData={columns}
                        numberOfColumns={7}
                        numberOfRows={6}
                    />
                ) : (
                    <ReusableTable
                        data={orders as unknown as Record<string, unknown>[]}
                        columns={columns as unknown as Column<Record<string, unknown>>[]}
                        statusKey="orderStatus"
                        actionItems={(row) => getActionItems(row as unknown as Order) as unknown as ActionMenuItem<Record<string, unknown>>[]}
                        searchPlaceholder="SEARCH ORDERS"
                        statusFilterOptions={statusFilterOptions}
                        statusFilterValue={statusFilter}
                        emptyMessage="No orders found"
                    />
                )}
            </div>


            <OrderSummary
                buttonTitle="Confirm Payment"
                handleClick={() => {
                    const { data } = useModalStore.getState();
                    if (data && typeof data === 'object' && 'id' in data) {
                        const order = data as Order;
                        handleStatusUpdate(order, "processing", "Payment confirmed successfully");
                        useModalStore.getState().closeModal();
                    }
                }}
            />

            <AssignCourierModal
                handleSubmit={(values: AssignCourierFormValues) => {
                    const { data } = useModalStore.getState();
                    handleAssignCourier(values, data as Order);
                }}
                loading={loading}
            />
        </div>
    );
};

export default OrderTable;