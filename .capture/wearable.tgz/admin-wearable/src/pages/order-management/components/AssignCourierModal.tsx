import { Formik } from "formik";
import { Field, ReusableModal, Select, Submit } from "../../../components";
import { useModalStore } from "../../../stores/modalStore";


type AssignCourierFormValues = {
    productId: string;
    pickupMethod: string;
    date: string;
}

type AssignCourierModalProps = {
    handleSubmit: (values: AssignCourierFormValues) => void;
    loading: boolean;
}

const AssignCourierModal = ({ handleSubmit, loading }: AssignCourierModalProps) => {
    const { isOpen, closeModal, type } = useModalStore();

    if (type !== "assignCourier") return null;

    return (
        <ReusableModal
            title="Assign Courier"
            isOpen={isOpen}
            onClose={closeModal}
        >
            <Formik
                initialValues={{ productId: "", pickupMethod: "", date: "" }}
                onSubmit={handleSubmit}
            >
                {()=> (
                    <div className="assign-courier-form">
                        <Field
                            name="productId"
                            label="Product Name"
                        />

                        <Select
                            name="pickupMethod"
                            label="Pickup Method"
                            options={[
                                { label: "Pickup", value: "pickup" },
                                { label: "Delivery", value: "delivery" },
                            ]}
                        />

                        <Field
                            name="date"
                            label="Date"
                            placeholder="Pickup Date / Delivery Date"
                        />

                        <Submit
                            loading={loading}
                            title="Assign Courier"
                            className="w-full bg-black text-white"
                        />
                    </div>
                )}
            </Formik>
        </ReusableModal>
    )
}

export default AssignCourierModal;