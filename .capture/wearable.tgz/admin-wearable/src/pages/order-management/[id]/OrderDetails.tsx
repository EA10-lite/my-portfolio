import { BsArrowLeft, BsCheck2, BsX } from "react-icons/bs"
import { Button, PageField, Text } from "../../../components"
import { useNavigate, useParams } from "react-router-dom";
import { LuLoader } from "react-icons/lu";
import { PiExportLight } from "react-icons/pi";
import { useGet } from "../../../hooks";
import type { Order } from "../../../utils/interfaces";


const OrderDetails = () => {
    const navigate = useNavigate();
    const { id } = useParams();

    const { data: response, isLoading, error } = useGet<{ success: boolean; order: any }>(
        ['order', id as string],
        `/orders/${id}`,
        {
            staleTime: 5 * 60 * 1000,
        }
    );

    const order = response?.order as Order;

    // const { getUpdatedOrder } = useOrderStore();

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error: {error.message}</div>;
    if (!order) return <div>Order not found</div>;


    const getOrderStatus = (orderStatus: string, status: string) => {
        const statusOrder = ["pending", "confirmed", "processing", "packed", "assigned", "shipped", "delivered"];
        const statusIndex = statusOrder.indexOf(status);
        const orderStatusIndex = statusOrder.indexOf(orderStatus.toLowerCase());

        const newStatus = orderStatus.toLowerCase();
        if(newStatus === "cancelled") return "cancelled";

        if(orderStatusIndex > statusIndex) return "completed";
        if(orderStatusIndex < statusIndex) return "pending";

        return "completed";
    }

    return (
        <div className="order-details">
            <div className="order-details-header mb-6">
                <div className="flex items-center justify-between">
                    <div
                        className="flex items-center gap-2 cursor-pointer"
                        onClick={() => {
                            navigate(-1);
                        }}
                    >
                        <BsArrowLeft size={18} />
                        <Text
                            title="Order Details"
                            type="h4"
                            className="text-base font-chivo-regular font-normal uppercase"
                            letterSpacing={"-2%"}
                        />
                    </div>

                    <Button
                        title="Export"
                        onClick={() => {}}
                        icon={<PiExportLight size={18} />}
                    />
                </div>
            </div>

            <div className="order-details-content">
                <div className="border border-[#E6E6E6]">
                    <div className="flex flex-col lg:flex-row lg:items-stretch">
                        <div className="w-full flex flex-col lg:w-2/5 border-b lg:border-b-0 lg:border-r border-[#E6E6E6]">
                            <div className="border-b border-[#E6E6E6] p-6 flex flex-col gap-4">
                                <PageField label="Order ID" value={id as string} />
                                <PageField label="Date" value="2025-01-01" />
                            </div>

                            <div className="p-6 flex-1">
                                <h4 className="text-base font-chivo-medium font-medium uppercase mb-2">Customer Information</h4>

                                <div className="flex flex-col gap-4">
                                    <PageField label="Name" value={order?.customer?.name} />
                                    <PageField label="Email" value={order?.customer?.email} />
                                    <PageField label="Phone" value={order?.customer?.phone} />
                                    <PageField label="Address" value={order?.customer?.deliveryAddress} />
                                </div>
                            </div>

                            {order?.orderStatus === "pending" && (
                                <div className="p-6">
                                    <Button title="Assign Courier" onClick={() => {}} />
                                </div>
                            )}
                        </div>


                        <div className="w-full flex flex-col lg:w-3/5">
                            <div className="border-b border-[#E6E6E6] p-6 flex flex-col gap-4">
                                <Text
                                    title="Order Items Breakdown"
                                    type="h4"
                                    className="text-base font-chivo-medium font-medium uppercase mb-2"
                                    letterSpacing={"-2%"}
                                />

                                <div className="flex items-center justify-between mb-6">
                                    <PageField label="Product" value={order?.product?.name} />
                                    <PageField label="Variant" value="Size MD / Black" />
                                    <PageField label="Quantity" value={order?.items} className="text-center" />
                                </div>

                                <div className="flex items-center gap-x-12 gap-y-4 flex-wrap max-w-[406px]">
                                    <h4 className="text-sm font-chivo-regular font-normal uppercase">Subtotal - <span>$100</span></h4>
                                    <h4 className="text-sm font-chivo-regular font-normal uppercase">Shipping - <span className="text-[#909090]">Not Added</span></h4>
                                    <h4 className="text-sm font-chivo-regular font-normal uppercase">Payment Method: Bank Transfer</h4>
                                </div>
                            </div>

                            <div className="border-b border-[#E6E6E6] p-6 flex flex-col gap-4">
                                <h4 className="text-base font-chivo-medium font-medium uppercase">Payment Summary</h4>

                                <div className="flex items-center gap-x-12 gap-y-4 flex-wrap max-w-[406px]">
                                    <h4 className="text-sm font-chivo-regular font-normal uppercase">Status - Paid</h4>
                                    <h4 className="text-sm font-chivo-regular font-normal uppercase">Method - Bank Transfer</h4>
                                    <h4 className="text-sm font-chivo-regular font-normal uppercase">Reference: BANK/TRF/00922</h4>
                                </div>
                            </div>
                            <div className="p-6 flex flex-col gap-4">
                                <Text
                                    title="Order Progress Timeline"
                                    type="h4"
                                    className="text-base font-chivo-medium font-medium uppercase mb-2"
                                    letterSpacing={"-2%"}
                                />

                                <ProgressStatus
                                    title="Order Placed"
                                    status={getOrderStatus(order?.orderStatus, "pending")}
                                    date="2025-01-01"
                                />
                                <ProgressStatus
                                    title="Order Confirmed"
                                    status={getOrderStatus(order?.orderStatus, "confirmed")}
                                    date="2025-01-02"
                                />
                                <ProgressStatus
                                    title="Order Processing"
                                    status={getOrderStatus(order?.orderStatus, "processing")}
                                    date="2025-01-02"
                                />
                                <ProgressStatus
                                    title="Order Packed"
                                    status={getOrderStatus(order?.orderStatus, "packed")}
                                />
                                <ProgressStatus
                                    title="Order Assigned"
                                    status={getOrderStatus(order?.orderStatus, "assigned")}
                                />
                                <ProgressStatus
                                    title="Order Out for Delivery"
                                    status={getOrderStatus(order?.orderStatus, "shipped")}
                                />
                                <ProgressStatus
                                    title="Order Delivered"
                                    status={getOrderStatus(order?.orderStatus, "delivered")}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}


type ProgressStatusProps = {
    title: string;
    status: "pending" | "completed" | "cancelled";
    date?: string;
}

const ProgressStatus = ({ title, status, date }: ProgressStatusProps) => {
    return (
        <div className="progress-status">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 flex items-center justify-center bg-[#F2F2F2]">
                    {status === "completed" ? <BsCheck2 /> : status === "pending" ? <LuLoader className="animate-spin" /> : <BsX />}
                </div>

                <Text
                    title={`${title} ${status === "completed" ? date ? ` - ${date}` : "" : status === "pending" ? " - Pending" : " - Cancelled"}`}
                    type="p"
                    letterSpacing={"-2%"}
                />
            </div>
        </div>
    )
}

export default OrderDetails