import { useMemo, useState } from "react"
import { PageStat } from "../../components"
import OrderTable from "./components/OrderTable"
import type { Order } from "../../utils/interfaces"
import { useGet } from "../../hooks"
import { useOrderStore } from "../../stores/orderStore"



const Orders = () => {
    const [search, setSearch] = useState<string>("");
    const [statusFilter, setStatusFilter] = useState<string>("all");
    const [paymentStatusFilter, setPaymentStatusFilter] = useState<string>("paid");

    const { data: statsData } = useGet<{ success: boolean; stats?: any }>(
        ['dashboard', 'stats', 'orders'],
        '/dashboard/stats',
        { staleTime: 5 * 60 * 1000 }
    );

    const stats = [
        { label: "Total Orders", value: statsData?.stats?.totalOrders ?? 0 },
        { label: "Pending Orders", value: statsData?.stats?.pendingOrders ?? 0 },
        { label: "Processing Orders", value: statsData?.stats?.processingOrders ?? 0 },
        { label: "Delivered Orders", value: statsData?.stats?.deliveredOrders ?? 0 },
        { label: "Cancelled Orders", value: statsData?.stats?.cancelledOrders ?? 0 },
    ];

    const { data: response, isLoading, error } = useGet<{ success: boolean; orders: any[]; pagination: any }>(
        ['orders'],
        '/orders',
        {
            staleTime: 5 * 60 * 1000,
        }
    );
    const { getUpdatedOrder } = useOrderStore();

    const filteredOrders = useMemo(() => {
        const orderList = response?.orders || [];
        let filtered = orderList.map((order: any) => {
            // Map the backend order format to the frontend Order format
            const mappedOrder: Order = {
                id: order.id,
                customer: {
                    name: order.customerName || 'Unknown',
                    email: order.customerEmail || '',
                    phone: order.customerPhone || '',
                    address: order.deliveryAddress || ''
                },
                items: order.quantity || 1,
                amount: order.total || order.price || 0,
                paymentStatus: order.paymentStatus || 'pending',
                orderStatus: order.orderStatus || 'pending',
                createdAt: order.createdAt || new Date().toISOString(),
                updatedAt: order.updatedAt || new Date().toISOString(),
                ...order
            };
            return getUpdatedOrder(mappedOrder.id, mappedOrder);
        });

        // Filter by search term
        if (search.trim()) {
            const searchTerm = search.toLowerCase().trim();
            filtered = filtered.filter((order: Order) => {
                const orderId = order.id.toString();
                const customerName = order.customer.name.toLowerCase();

                return (
                    orderId.includes(searchTerm) ||
                    customerName.includes(searchTerm)
                );
            });
        }

        // Filter by order status
        if (statusFilter && statusFilter.toLowerCase() !== "all") {
            filtered = filtered.filter((order: Order) => order.orderStatus.toLowerCase() === statusFilter.toLowerCase());
        }

        // Filter by payment status
        if (paymentStatusFilter && paymentStatusFilter.toLowerCase() !== "all") {
            filtered = filtered.filter((order: Order) => order.paymentStatus.toLowerCase() === paymentStatusFilter.toLowerCase());
        }

        return filtered;
    }, [search, statusFilter, paymentStatusFilter, response?.orders, getUpdatedOrder]);

    if (error) {
        return <div>Error: {error.message}</div>
    }

    return (
        <div className="orders">
            <div className="heading mb-6">
                <PageStat
                    title="Order Management"
                    stats={stats}
                    isLoading={isLoading}
                />
            </div>

            <div className="w-full">
                <OrderTable
                    orders={filteredOrders}
                    setSearch={setSearch}
                    search={search}
                    setStatusFilter={setStatusFilter}
                    statusFilter={statusFilter}
                    setPaymentStatusFilter={setPaymentStatusFilter}
                    paymentStatusFilter={paymentStatusFilter}
                    isLoading={isLoading}
                />
            </div>
        </div>
    )
}

export default Orders