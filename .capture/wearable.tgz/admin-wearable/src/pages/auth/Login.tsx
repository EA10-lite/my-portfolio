import { Formik } from "formik"
import { Field, Submit } from "../../components"
import { useState } from "react";
import { useAdminStore } from "../../stores/adminStore";
import { loginValidationSchema } from "../../utils/validations";
import { useToastStore } from "../../stores/toastStore";
import { authService } from "../../services/auth";
import { isAxiosError } from "axios";
import { setAuthToken } from "../../utils/cookies";
import { useNavigate } from "react-router-dom";

type LoginFormValues = {
    email: string;
    password: string;
}

const Login = () => {
    const { login } = useAdminStore();
    const { showToast } = useToastStore();
    const navigate = useNavigate();

    const [loading, setLoading] = useState<boolean>(false)
    const handleSubmit = async (values: LoginFormValues) => {
        try {
            setLoading(true);
            const response = await authService.login(values.email, values.password);

            // Check if login was successful based on response structure
            if (response.success && response.token && response.user) {
                // Securely store the token in cookies
                setAuthToken(response.token);

                // Update admin store with user information
                login({
                    id: response.user.id,
                    email: response.user.email,
                    name: response.user.name || response.user.email.split('@')[0], // Fallback to email prefix if name not provided
                    role: response.user.role
                });

                // Show success message
                showToast(response.message || "Login successful", "success", "top");

                // Redirect to dashboard after successful login
                navigate('/');
            } else {
                showToast("Invalid response from server", "error", "top");
            }
        } catch (error) {
            console.log(error)
            if (isAxiosError(error)) {
                const errorMessage = error.response?.data?.message || "Login failed. Please try again.";
                showToast(errorMessage, "error", "top");
            } else {
                showToast("An unexpected error occurred during login", "error", "top");
            }
        } finally {
            setLoading(false)
        }
    }
    return (
        <div className="login flex flex-col items-center justify-center h-screen">
            <div className="w-[95%] sm:w-[320px] md:w-[480px] bg-black mx-auto p-6">
                <div className="mb-4">
                    <div className="flex items-center justify-center mb-12">
                        <img src="/images/logo-alt.svg" alt="logo" />
                    </div>

                    <h2 className="text-2xl font-chivo-medium font-medium uppercase text-white">Login</h2>
                </div>

                <Formik
                    initialValues={{ email: "", password: "" }}
                    onSubmit={handleSubmit}
                    validationSchema={loginValidationSchema}
                >
                    {()=> (
                        <div className="">
                            <Field 
                                name="email"
                                label="Email Address"
                                placeholder="Enter your email"
                                type="email"
                            />
                            <Field
                                name="password"
                                label="Password"
                                placeholder="Enter your password"
                                type="password"
                            />

                            <Submit
                                title="Login"
                                loading={loading}
                                className="w-full"
                            />
                        </div>
                    )}
                </Formik>
            </div>
        </div>
    )
}

export default Login