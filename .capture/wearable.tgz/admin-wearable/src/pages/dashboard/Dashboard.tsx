import { PageStat, Skeleton } from "../../components"
import CategoryPerformanceChart from "./components/CategoryPerformanceChart"
import OrdersTrendChart from "./components/OrdersTrendChart"
import SalesChart from "./components/SalesChart"
import { useGet } from "../../hooks/useGet"
// Skeleton is imported from ../../components above


const Dashboard = () => {
    const { data, isLoading } = useGet<{
        success: boolean;
        message: string;
        stats?: any;
    }>(['dashboard', 'stats'], '/dashboard/stats');

    const statsData = data?.stats || {
        totalOrders: 0,
        unpaidOrders: 0,
        processingOrders: 0,
        deliveredOrders: 0,
        totalRevenue: 0,
    };

    const displayStats = [
        {
            label: "Total Orders",
            value: statsData.totalOrders,
        },
        {
            label: "Pending Payments",
            value: statsData.unpaidOrders,
        },
        {
            label: "Processing Orders",
            value: statsData.processingOrders,
        },
        {
            label: "Delivered Orders",
            value: statsData.deliveredOrders,
        },
        {
            label: "Total Revenue",
            value: statsData.totalRevenue,
            isCurrency: true,
        },
    ];

    return (
        <div className="products">
            <div className="heading mb-6">
                {isLoading ? (
                    <div className="space-y-4">
                        <Skeleton className="h-10 w-64" />
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                            {Array.from({ length: 5 }).map((_, i) => (
                                <Skeleton key={i} className="h-24 w-full" />
                            ))}
                        </div>
                    </div>
                ) : (
                    <PageStat
                        title="Hello Admin"
                        subtitle="How are you doing today?"
                        stats={displayStats}
                    />
                )}
            </div>

            <div className="body">
                <div className="sales-chart mb-6">
                    <SalesChart />
                </div>

                <div className="flex flex-col lg:flex-row gap-4 justify-between mb-6">
                    <div className="w-full lg:w-[36%] lg:items-stretch">
                        <CategoryPerformanceChart />
                    </div>
                    <div className="w-full lg:w-[62%] lg:items-stretch">
                        <OrdersTrendChart />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Dashboard