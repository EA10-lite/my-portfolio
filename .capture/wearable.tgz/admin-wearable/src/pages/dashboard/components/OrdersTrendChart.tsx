import { Text } from "../../../components";
import { Bar, BarChart, CartesianGrid, XAxis } from "recharts";
import {
  type ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "../../../components/ui/chart"
import { useGet } from "../../../hooks/useGet";

const chartConfig = {
  orders: {
    label: "Orders",
    color: "#000000",
  },
} satisfies ChartConfig;

const OrdersTrendChart = () => {
    const { data, isLoading } = useGet<{
        success: boolean;
        data?: { date: string; orders: number }[];
    }>(['dashboard', 'orders-trend'], '/dashboard/orders-trend', {
        staleTime: 5 * 60 * 1000,
    });

    const chartData = (data?.data || []).map(d => ({
        month: d.date.slice(5), // Show MM-DD
        orders: d.orders,
    }));

    return (
        <div className="border border-[#E6E6E6] p-6 h-full">
            <div className="flex items-center justify-between mb-6">
                <Text
                    title="Orders Trend (Last 28 Days)"
                    type="h2"
                    className="text-base font-chivo-medium font-medium"
                    letterSpacing={"-2%"}
                />
            </div>

            {isLoading ? (
                <div className="h-[245px] flex items-center justify-center">
                    <p className="text-sm font-chivo-regular text-[#6C6C6C]">Loading...</p>
                </div>
            ) : chartData.length === 0 ? (
                <div className="h-[245px] flex items-center justify-center">
                    <p className="text-sm font-chivo-regular text-[#6C6C6C]">No orders in the last 28 days</p>
                </div>
            ) : (
                <ChartContainer config={chartConfig} className="max-h-[245px] w-full">
                    <BarChart accessibilityLayer data={chartData}>
                        <CartesianGrid vertical={false} />
                        <XAxis
                            dataKey="month"
                            tickLine={false}
                            tickMargin={10}
                            axisLine={false}
                            className="text-sm uppercase text-[#909090] font-chivo-regular font-normal leading-base"
                        />
                        <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dashed" />} />
                        <Bar dataKey="orders" fill="#000000" barSize={12} />
                    </BarChart>
                </ChartContainer>
            )}
        </div>
    )
}

export default OrdersTrendChart;