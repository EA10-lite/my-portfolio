import { useState, useMemo } from "react";
import { Text } from "../../../components";
import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts"
import {
  type ChartConfig,
  ChartContainer,
  ChartTooltip,
} from "../../../components/ui/chart"
import TimeFilterComponent from "../../../components/main/TimeFilter";
import type { TimeFilter } from "../../../types/charts";
import { useGet } from "../../../hooks/useGet";

const formatCurrency = (value: number | undefined | null): string => {
    if (value === undefined || value === null || isNaN(value)) return '₦0';
    if (value >= 1000000) return `₦${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `₦${(value / 1000).toFixed(0)}k`;
    return `₦${value.toLocaleString('en-NG')}`;
};

const chartConfig = {
  sales: { label: "Sales", color: "#000000" },
} satisfies ChartConfig;

const formatXAxisLabel = (value: string, timeFilter: TimeFilter): string => {
    if (timeFilter === "7d" || timeFilter === "30d") return value.slice(5);
    return value.slice(0, 7);
};

const SalesChart = () => {
    const [timeFilter, setTimeFilter] = useState<TimeFilter>("12m");

    const { data, isLoading } = useGet<{
        success: boolean;
        data?: { period: string; sales: number }[];
    }>(['dashboard', 'sales', timeFilter], `/dashboard/sales?timeFilter=${timeFilter}`, {
        staleTime: 5 * 60 * 1000,
    });

    const chartData = useMemo(() => {
        return (data?.data || []).map(d => ({ month: d.period, sales: d.sales }));
    }, [data]);

    return (
        <div className="border border-[#E6E6E6] p-6">
            <div className="flex items-center justify-between">
                <Text
                    title="Sales Breakdown"
                    type="h2"
                    className="text-base font-chivo-medium font-medium mb-6"
                    letterSpacing={"-2%"}
                />
                <TimeFilterComponent activeFilter={timeFilter} handleFilter={setTimeFilter} />
            </div>

            <div>
                {isLoading ? (
                    <div className="h-[265px] flex items-center justify-center">
                        <p className="text-sm font-chivo-regular text-[#6C6C6C]">Loading sales data...</p>
                    </div>
                ) : (
                    <ChartContainer config={chartConfig} className="max-h-[265px] w-full">
                        <LineChart
                            accessibilityLayer
                            data={chartData}
                            margin={{ left: 50, right: 12, top: 12, bottom: 12 }}
                        >
                            <CartesianGrid vertical={false} />
                            <YAxis
                                type="number"
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tickFormatter={formatCurrency}
                                className="text-sm text-[#909090] font-chivo-regular font-normal leading-base"
                            />
                            <XAxis
                                dataKey="month"
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tickFormatter={(value) => formatXAxisLabel(value, timeFilter)}
                                className="text-sm uppercase text-[#909090] font-chivo-regular font-normal leading-base"
                            />
                            <ChartTooltip
                                cursor={false}
                                content={({ payload }) => {
                                    const period = payload?.[0]?.payload?.month;
                                    const sales = payload?.[0]?.payload?.sales;
                                    return (
                                        <div className="bg-white p-4 shadow-md border border-[#E6E6E6]">
                                            <p className="text-xs font-chivo-regular text-[#909090] mb-1">Period: {period}</p>
                                            <p className="text-xs font-chivo-medium">{formatCurrency(sales)}</p>
                                        </div>
                                    );
                                }}
                            />
                            <Line dataKey="sales" type="linear" stroke="#000000" strokeWidth={2} dot={false} />
                        </LineChart>
                    </ChartContainer>
                )}
            </div>
        </div>
    )
}

export default SalesChart;