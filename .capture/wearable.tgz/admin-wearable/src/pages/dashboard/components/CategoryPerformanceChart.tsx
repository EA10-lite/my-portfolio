import { Bar, BarChart, XAxis, YAxis } from "recharts"
import { Text } from "../../../components";
import {
    type ChartConfig,
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
} from "../../../components/ui/chart"
import { useGet } from "../../../hooks/useGet";

const chartConfig = {
    orderCount: { label: "Orders", color: "#000000" },
} satisfies ChartConfig;

const CategoryPerformanceChart = () => {
    const { data, isLoading } = useGet<{
        success: boolean;
        data?: { category: string; revenue: number; orderCount: number }[];
    }>(['dashboard', 'category-performance'], '/dashboard/category-performance', {
        staleTime: 10 * 60 * 1000,
    });

    const chartData = (data?.data || []).map(d => ({
        category: d.category,
        sales: d.orderCount,
        revenue: d.revenue,
    }));

    const longestCategoryLength = chartData.length > 0
        ? Math.max(...chartData.map(item => item.category.length))
        : 10;

    const yAxisWidth = Math.min(Math.max(longestCategoryLength * 10, 80), 200);

    return (
        <div className="border border-[#E6E6E6] p-6 h-full">
            <Text
                title="Category Performance"
                type="h2"
                className="text-base font-chivo-medium font-medium mb-6"
                letterSpacing={"-2%"}
            />

            {isLoading ? (
                <div className="h-[200px] flex items-center justify-center">
                    <p className="text-sm font-chivo-regular text-[#6C6C6C]">Loading...</p>
                </div>
            ) : chartData.length === 0 ? (
                <div className="h-[200px] flex items-center justify-center">
                    <p className="text-sm font-chivo-regular text-[#6C6C6C]">No data available yet</p>
                </div>
            ) : (
                <ChartContainer config={chartConfig} className="w-full">
                    <BarChart accessibilityLayer data={chartData} layout="vertical">
                        <XAxis type="number" dataKey="sales" hide />
                        <YAxis
                            dataKey="category"
                            type="category"
                            tickLine={false}
                            tickMargin={10}
                            axisLine={false}
                            width={yAxisWidth}
                            textAnchor="end"
                            className="text-left text-sm font-chivo-regular font-normal uppercase leading-base text-[#909090]"
                        />
                        <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                        <Bar dataKey="sales" fill="#000000" radius={0} barSize={18} />
                    </BarChart>
                </ChartContainer>
            )}
        </div>
    )
}

export default CategoryPerformanceChart;