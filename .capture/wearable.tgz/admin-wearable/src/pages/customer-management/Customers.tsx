import { useMemo, useState } from "react";
import { PageStat } from "../../components"
import type { Customer } from "../../utils/interfaces";
import CustomerTable from "./components/CustomerTable";
import { useGet } from "../../hooks";



const Customers = () => {
    const [search, setSearch] = useState<string>("");
    const [statusFilter, setStatusFilter] = useState<string>("all");

    const { data: statsData } = useGet<{ success: boolean; stats?: any }>(
        ['dashboard', 'stats', 'customers'],
        '/dashboard/stats',
        { staleTime: 5 * 60 * 1000 }
    );

    const stats = [
        { label: "Total Customers", value: statsData?.stats?.totalCustomers ?? 0 },
        { label: "New Customers (30d)", value: statsData?.stats?.newCustomers ?? 0 },
    ];

    const { data: customersResponse, isLoading, error } = useGet(
        ['customers'],
        '/customers',
        {
            staleTime: 5 * 60 * 1000,
        }
    );

    const customers = (customersResponse as any)?.customers || [];

    const filteredCustomers = useMemo(() => {
        let filtered = customers || [];

        // Filter by search term
        if (search.trim()) {
            const searchTerm = search.toLowerCase().trim();
            filtered = filtered.filter((customer: Customer) => {
                const customerId = customer.id.toString();
                const customerName = customer.name.toLowerCase();

                return (
                    customerId.includes(searchTerm) ||
                    customerName.includes(searchTerm)
                );
            });
        }

        // Filter by status
        if (statusFilter) {
            if(statusFilter.toLowerCase() === "all") {
                return filtered;
            }

            filtered = filtered.filter((customer: Customer) => customer.status.toLowerCase() === statusFilter.toLowerCase());
        }

        return filtered;
    }, [search, statusFilter, customers]);

    if (error) {
        return <div>Error: {error.message}</div>
    }

    return (
        <div className="orders">
            <div className="heading mb-6">
                <PageStat
                    title="Customer Management"
                    stats={stats}
                    isLoading={isLoading}
                />
            </div>

            <div className="w-full">
                <CustomerTable
                    customers={filteredCustomers}
                    setSearch={setSearch}
                    search={search}
                    setStatusFilter={setStatusFilter}
                    statusFilter={statusFilter}
                    isLoading={isLoading}
                />
            </div>
        </div>
    )
}

export default Customers