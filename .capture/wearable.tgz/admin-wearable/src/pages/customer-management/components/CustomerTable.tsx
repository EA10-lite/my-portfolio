import { useNavigate } from "react-router-dom";
import { ReusableTable, type Column, type ActionMenuItem, TableHeader, TableSkeleton } from "../../../components";
import type { Customer } from "../../../utils/interfaces";
import { Eye, XCircle } from "lucide-react";
import axios from "axios";
import { useQueryClient } from "@tanstack/react-query";
import { useToastStore } from "../../../stores/toastStore";


const formatCurrency = (amount: number | undefined | null): string => {
    if (amount === undefined || amount === null || isNaN(amount)) return '₦0';
    return `₦${amount.toLocaleString('en-NG')}`;
};

type OrderTableProps = {
    customers: Customer[];
    setSearch: (search: string) => void;
    search: string;
    setStatusFilter: (status: string) => void;
    statusFilter: string;
    isLoading: boolean;
}

const statusFilterOptions = [
    { label: "All", value: "all" },
    { label: "Active", value: "active" },
    { label: "New", value: "new" },
    { label: "Top Buyer", value: "top-buyer" },
    { label: "Blocked", value: "blocked" },
];


const CustomerTable = ({
    customers,
    setSearch,
    search,
    setStatusFilter,
    statusFilter,
    isLoading,
}: OrderTableProps) => {
    const navigate = useNavigate();

    const filterOptions = [
        {
            options: statusFilterOptions,
            handleFilter: setStatusFilter,
            activeFilter: statusFilter,
        },
    ]

    const columns: Column<Customer>[] = [
        {
            key: "customer",
            header: "CUSTOMER",
            render: (customer: Customer) => (
                <span>{customer.name}</span>
            ),
        },
        {
            key: "email",
            header: "EMAIL",
            render: (customer: Customer) => (
                <span>{customer.email}</span>
            ),
        },
        {
            key: "phone",
            header: "PHONE",
            render: (customer: Customer) => (
                <span className="font-medium">{customer.phone}</span>
            ),
        },
        {
            key: "totalOrders",
            header: "TOTAL ORDERS",
            render: (customer: Customer) => (
                <span className="font-medium text-center block">{customer.totalOrders}</span>
            ),
        },
        {
            key: "totalAmount",
            header: "TOTAL AMOUNT",
            render: (customer: Customer) => (
                <span className="font-medium">{formatCurrency(customer.totalAmount)}</span>
            ),
        },
        {
            key: "status",
            header: "STATUS",
            render: (customer: Customer) => (
                <span className="font-medium">{customer.status}</span>
            ),
        },
    ];


    const queryClient = useQueryClient();
    const { showToast } = useToastStore();

    const handleBlockToggle = async (customer: Customer) => {
        try {
            const isBlocked = customer.status === "blocked";
            await axios.put(`http://localhost:3001/api/customers/${customer.id}/block`, {
                block: !isBlocked
            }, {
                withCredentials: true,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('adminToken')}`
                }
            });
            showToast(`Customer ${isBlocked ? "unblocked" : "blocked"} successfully`, "success");
            queryClient.invalidateQueries({ queryKey: ["customers"] });
        } catch (error: any) {
            console.error("Error toggling block status:", error);
            showToast(error?.response?.data?.message || "Failed to update customer status", "error");
        }
    };

    const actionItems: ActionMenuItem<Customer>[] = [
        {
            label: "View customer",
            icon: <Eye size={16} />,
            onClick: (customer: Customer) => {
                navigate(`/customers/${customer.id}`);
            },
        },
        {
            label: "Toggle block status",
            icon: <XCircle size={16} />,
            onClick: handleBlockToggle,
            className: "text-red-600 hover:bg-red-50",
        },
    ];



    return (
        <div className="w-full">
            <div className="border border-[#E6E6E6] p-6">
                <TableHeader
                    title="Customers"
                    search={search}
                    handleSearch={setSearch}
                    handleExport={() => {}}
                    options={filterOptions}
                />

                {isLoading ? (
                    <TableSkeleton
                        columnData={columns}
                        numberOfColumns={7}
                        numberOfRows={6}
                    />
                ) : (
                    <ReusableTable
                        data={customers as unknown as Record<string, unknown>[]}
                        columns={columns as unknown as Column<Record<string, unknown>>[]}
                        statusKey="status"
                        actionItems={actionItems as unknown as ActionMenuItem<Record<string, unknown>>[]}
                        searchPlaceholder="SEARCH CUSTOMERS"
                        statusFilterOptions={statusFilterOptions}
                        statusFilterValue={statusFilter}
                        emptyMessage="No customers found"
                    />
                )}
            </div>
        </div>
    );
};

export default CustomerTable;