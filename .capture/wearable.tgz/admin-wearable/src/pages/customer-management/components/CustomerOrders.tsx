import { ReusableTable, type Column, type ActionMenuItem, OrderSummary } from "../../../components";
import { useModalStore } from "../../../stores/modalStore";
import type { Order } from "../../../utils/interfaces";
import { Eye } from "lucide-react";


const formatCurrency = (amount: number | undefined | null): string => {
    if (amount === undefined || amount === null || isNaN(amount)) return '₦0';
    return `₦${amount.toLocaleString('en-NG')}`;
};

type OrderTableProps = {
    orders: Order[];
}

const CustomerOrders = ({
    orders,
}: OrderTableProps) => {

    const { openOrderSummaryModal, data } = useModalStore();

    const columns: Column<Order>[] = [
        {
            key: "id",
            header: "ORDER ID",
            render: (order: Order) => (
                <span className="font-medium">#{order.id}</span>
            ),
        },
        {
            key: "createdAt",
            header: "DATE",
        },
        {
            key: "items",
            header: "ITEMS",
            render: (order: Order) => (
                <span className="font-medium">{order.items} items</span>
            ),
        },
        {
            key: "amount",
            header: "AMOUNT",
            render: (order: Order) => (
                <span className="font-medium">{formatCurrency(order.amount)}</span>
            ),
        },
        {
            key: "paymentStatus",
            header: "PAYMENT STATUS",
        },
        {
            key: "orderStatus",
            header: "ORDER STATUS",
            render: (order: Order) => (
                <span className="font-medium">{order.orderStatus}</span>
            ),
        },
    ];


    const actionItems: ActionMenuItem<Order>[] = [
        {
            label: "View Order",
            icon: <Eye size={16} />,
            onClick: (order: Order) => {
                openOrderSummaryModal(order);
            },
        },
    ];



    return (
        <div className="w-full">
            <ReusableTable
                data={orders as unknown as Record<string, unknown>[]}
                columns={columns as unknown as Column<Record<string, unknown>>[]}
                statusKey="orderStatus"
                actionItems={actionItems as unknown as ActionMenuItem<Record<string, unknown>>[]}
                emptyMessage="No orders found"
            />


            <OrderSummary
                buttonTitle="Open order in order management"
                href={`/orders/${(data as Order)?.id}`}
                handleClick={() => {
                    console.log("opening order in order management:");
                }}
            />
        </div>
    );
};

export default CustomerOrders;