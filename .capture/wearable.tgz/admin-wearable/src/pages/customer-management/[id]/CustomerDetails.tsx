import { BsArrowLeft } from "react-icons/bs";
import { useNavigate, useParams } from "react-router-dom";
import { Button, PageField, Text, Skeleton } from "../../../components";
import CustomerOrders from "../components/CustomerOrders";
import { PiExportLight } from "react-icons/pi";
import { useGet } from "../../../hooks/useGet";
// Skeleton is imported from ../../../components above

const CustomerDetails = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>();

    const { data, isLoading, error } = useGet<{
        success: boolean;
        message: string;
        customer?: {
            id: string;
            name: string;
            email: string;
            phone?: string;
            address?: string;
            isVerified: boolean;
            isBlocked: boolean;
            createdAt: string;
            orders: any[];
            stats: { totalOrders: number; totalSpend: number; cancelledOrders: number };
        };
    }>(['customer', id || ''], `/customers/${id}`, {
        enabled: !!id,
        staleTime: 2 * 60 * 1000,
    });

    const customer = data?.customer;

    return (
        <div className="customer-details">
            <div className="customer-details-header mb-6">
                <div className="flex items-center justify-between">
                    <div
                        className="flex items-center gap-2 cursor-pointer"
                        onClick={() => navigate(-1)}
                    >
                        <BsArrowLeft size={18} />
                        <Text
                            title="Customer Details"
                            type="h4"
                            className="text-base font-chivo-regular font-normal uppercase"
                            letterSpacing={"-2%"}
                        />
                    </div>

                    <Button title="Export" onClick={() => {}} icon={<PiExportLight size={18} />} />
                </div>
            </div>

            <div className="customer-details-content">
                <div className="border border-[#E6E6E6]">
                    <div className="details p-6 border-b border-[#E6E6E6]">
                        <div className="max-w-md">
                            <Text
                                title="Customer Information"
                                type="h4"
                                className="text-base font-chivo-medium font-medium uppercase mb-4"
                                letterSpacing={"-2%"}
                            />

                            {isLoading ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {Array.from({ length: 6 }).map((_, i) => (
                                        <div key={i}>
                                            <Skeleton className="h-3 w-24 mb-2" />
                                            <Skeleton className="h-5 w-40" />
                                        </div>
                                    ))}
                                </div>
                            ) : error || !customer ? (
                                <p className="text-sm font-chivo-regular text-red-500">
                                    {error ? "Failed to load customer details" : "Customer not found"}
                                </p>
                            ) : (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <PageField label="Customer Name" value={customer.name} />
                                    <PageField label="Email Address" value={customer.email} />
                                    <PageField label="Phone Number" value={customer.phone || "Not provided"} />
                                    <PageField label="Delivery Address" value={customer.address || "Not provided"} />
                                    <PageField label="Account Created" value={new Date(customer.createdAt).toLocaleDateString()} />
                                    <PageField label="Status" value={customer.isBlocked ? "Blocked" : customer.isVerified ? "Verified" : "Active"} />
                                    <PageField label="Total Orders" value={String(customer.stats.totalOrders)} />
                                    <PageField label="Total Spend" value={`₦${(customer.stats?.totalSpend || 0).toLocaleString('en-NG')}`} />
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="orders p-6">
                        <Text
                            title="Order History"
                            type="h4"
                            className="text-base font-chivo-medium font-medium uppercase mb-4"
                            letterSpacing={"-2%"}
                        />

                        {isLoading ? (
                            <div className="space-y-3">
                                {Array.from({ length: 4 }).map((_, i) => (
                                    <Skeleton key={i} className="h-12 w-full" />
                                ))}
                            </div>
                        ) : customer?.orders && customer.orders.length > 0 ? (
                            <CustomerOrders orders={customer.orders} />
                        ) : (
                            <p className="text-sm font-chivo-regular text-[#6C6C6C]">No orders found for this customer.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CustomerDetails;