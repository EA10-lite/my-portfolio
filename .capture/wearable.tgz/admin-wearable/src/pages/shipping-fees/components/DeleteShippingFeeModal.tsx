import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ReusableModal, Button } from "../../../../components";
import { useModalStore } from "../../../../stores/modalStore";
import { shippingFeeService } from "../../../../services/shippingFee";
import { useToastStore } from "../../../../stores/toastStore";

const DeleteShippingFeeModal = () => {
    const { isOpen, type, data, closeModal } = useModalStore();
    const queryClient = useQueryClient();
    const { showToast } = useToastStore();

    const isModalOpen = isOpen && type === "deleteShippingFee";
    const feeData = data as any;

    const deleteMutation = useMutation({
        mutationFn: shippingFeeService.deleteShippingFee,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['shippingFees'] });
            showToast("Shipping fee deleted successfully", "success");
            closeModal();
        },
        onError: (error: any) => {
            showToast(error?.response?.data?.message || "Failed to delete shipping fee", "error");
        }
    });

    const handleDelete = () => {
        if (feeData?._id) {
            deleteMutation.mutate(feeData._id);
        }
    };

    return (
        <ReusableModal
            isOpen={isModalOpen}
            onClose={closeModal}
            title="Delete Shipping Fee"
        >
            <div className="mt-4">
                <p className="text-sm text-gray-600 mb-6">
                    Are you sure you want to delete the shipping fee for <strong>{feeData?.state} {feeData?.lga ? `(${feeData.lga})` : '(All LGAs)'}</strong>? This action cannot be undone.
                </p>

                <div className="flex justify-end gap-4">
                    <Button
                        title="Cancel"
                        onClick={closeModal}
                        className="bg-gray-100 text-black hover:bg-gray-200"
                    />
                    <Button
                        title={deleteMutation.isPending ? "Deleting..." : "Delete"}
                        onClick={handleDelete}
                        className="bg-red-600 text-white hover:bg-red-700"
                        disabled={deleteMutation.isPending}
                    />
                </div>
            </div>
        </ReusableModal>
    );
};

export default DeleteShippingFeeModal;
