import { GrEdit } from "react-icons/gr";
import { ReusableTable, type Column, type ActionMenuItem, TableHeader, TableSkeleton } from "../../../../components";
import type { ShippingFee } from "../../../../utils/interfaces";
import { XCircle, CheckCircle } from "lucide-react";
import { formatCurrency } from "../../../../utils/formatter";
import { useModalStore } from "../../../../stores/modalStore";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { shippingFeeService } from "../../../../services/shippingFee";
import { useToastStore } from "../../../../stores/toastStore";

type ShippingFeeTableProps = {
    shippingFees: ShippingFee[];
    setSearch: (search: string) => void;
    search: string;
    isLoading?: boolean;
}

const ShippingFeeTable = ({
    shippingFees,
    setSearch,
    search,
    isLoading,
}: ShippingFeeTableProps) => {
    const { openShippingFeeFormModal, openDeleteShippingFeeModal } = useModalStore();
    const queryClient = useQueryClient();
    const { showToast } = useToastStore();

    const toggleStatusMutation = useMutation({
        mutationFn: ({ id, isActive }: { id: string, isActive: boolean }) =>
            shippingFeeService.updateShippingFee({ id, data: { isActive } }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['shippingFees'] });
            showToast("Shipping fee status updated", "success");
        },
        onError: (error: any) => {
            showToast(error?.response?.data?.message || "Failed to update status", "error");
        }
    });

    const setAsDefaultMutation = useMutation({
        mutationFn: ({ id }: { id: string }) =>
            shippingFeeService.updateShippingFee({ id, data: { isDefault: true } }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['shippingFees'] });
            showToast("Shipping fee set as default", "success");
        },
        onError: (error: any) => {
            showToast(error?.response?.data?.message || "Failed to set default", "error");
        }
    });

    const columns: Column<ShippingFee>[] = [
        {
            key: "state",
            header: "State",
        },
        {
            key: "lga",
            header: "LGA",
            render: (fee: ShippingFee) => (
                <span>{fee.lga || "All LGAs"}</span>
            ),
        },
        {
            key: "fee",
            header: "Fee",
            render: (fee: ShippingFee) => (
                <span className="font-medium">{formatCurrency(fee.fee)}</span>
            ),
        },
        {
            key: "isDefault",
            header: "Default",
            render: (fee: ShippingFee) => (
                <span className={`px-2 py-1 text-xs rounded-full ${fee.isDefault ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}`}>
                    {fee.isDefault ? "Yes" : "No"}
                </span>
            ),
        },
        {
            key: "isActive",
            header: "Status",
            render: (fee: ShippingFee) => (
                <span className={`px-2 py-1 text-xs rounded-full ${fee.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {fee.isActive ? "Active" : "Inactive"}
                </span>
            ),
        },
    ];

    const actionItems: ActionMenuItem<ShippingFee>[] = [
        {
            label: "Edit",
            icon: <GrEdit size={16} />,
            onClick: (fee: ShippingFee) => {
                openShippingFeeFormModal(fee);
            },
        },
        {
            label: "Set as Default",
            icon: <CheckCircle size={16} />,
            onClick: (fee: ShippingFee) => {
                if (!fee.isDefault) {
                    setAsDefaultMutation.mutate({ id: fee._id });
                }
            },
        },
        {
            label: "Toggle Status",
            icon: <CheckCircle size={16} />,
            onClick: (fee: ShippingFee) => {
                toggleStatusMutation.mutate({ id: fee._id, isActive: !fee.isActive });
            },
        },
        {
            label: "Remove",
            icon: <XCircle size={16} />,
            onClick: (fee: ShippingFee) => {
                openDeleteShippingFeeModal(fee);
            },
            className: "text-red-600 hover:bg-red-50",
        },
    ];

    return (
        <div className="w-full">
            <div className="border border-[#E6E6E6] p-6">
                <TableHeader
                    title="Shipping Fees"
                    search={search}
                    handleSearch={setSearch}
                    handleExport={() => {}}
                />

                {isLoading ? (
                    <TableSkeleton
                        columnData={columns}
                        numberOfColumns={6}
                        numberOfRows={6}
                    />
                ) : (
                    <ReusableTable
                        data={shippingFees as unknown as Record<string, unknown>[]}
                        columns={columns as unknown as Column<Record<string, unknown>>[]}
                        statusKey="isActive"
                        actionItems={actionItems as unknown as ActionMenuItem<Record<string, unknown>>[]}
                        searchPlaceholder="SEARCH FEES"
                        emptyMessage="No shipping fees found"
                    />
                )}
            </div>
        </div>
    );
};

export default ShippingFeeTable;
