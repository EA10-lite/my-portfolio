import { useEffect, useState } from "react";
import { ReusableModal, Button, Field } from "../../../../components";
import { useModalStore } from "../../../../stores/modalStore";
import { Formik, Form } from "formik";
import * as Yup from "yup";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { shippingFeeService } from "../../../../services/shippingFee";
import { useToastStore } from "../../../../stores/toastStore";
import naija from "naija-state-local-government";

const validationSchema = Yup.object().shape({
    state: Yup.string().required("State is required"),
    lga: Yup.string().nullable(),
    fee: Yup.number().min(0, "Fee cannot be negative").required("Fee is required"),
});

const ShippingFeeFormModal = () => {
    const { isOpen, type, data, closeModal } = useModalStore();
    const queryClient = useQueryClient();
    const { showToast } = useToastStore();

    const [availableLgas, setAvailableLgas] = useState<string[]>([]);
    
    const isEditMode = Boolean(data && (data as any)._id);
    const initialValues = isEditMode
        ? {
            state: (data as any).state || "",
            lga: (data as any).lga || "",
            fee: (data as any).fee || 0,
            isDefault: (data as any).isDefault || false,
            isActive: (data as any).isActive ?? true,
        }
        : {
            state: "",
            lga: "",
            fee: 0,
            isDefault: false,
            isActive: true,
        };

    const isModalOpen = isOpen && type === "shippingFeeForm";

    const createMutation = useMutation({
        mutationFn: shippingFeeService.createShippingFee,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['shippingFees'] });
            showToast("Shipping fee created successfully", "success");
            closeModal();
        },
        onError: (error: any) => {
            showToast(error?.response?.data?.message || "Failed to create shipping fee", "error");
        }
    });

    const updateMutation = useMutation({
        mutationFn: shippingFeeService.updateShippingFee,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['shippingFees'] });
            showToast("Shipping fee updated successfully", "success");
            closeModal();
        },
        onError: (error: any) => {
            showToast(error?.response?.data?.message || "Failed to update shipping fee", "error");
        }
    });

    const handleSubmit = (values: typeof initialValues) => {
        if (isEditMode) {
            updateMutation.mutate({ id: (data as any)._id, data: values });
        } else {
            createMutation.mutate(values);
        }
    };

    const states = naija.states();

    return (
        <ReusableModal
            isOpen={isModalOpen}
            onClose={closeModal}
            title={isEditMode ? "Edit Shipping Fee" : "Add Shipping Fee"}
        >
            <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
                enableReinitialize
            >
                {({ values, setFieldValue, isSubmitting }) => {
                    useEffect(() => {
                        if (values.state) {
                            try {
                                const stateData = naija.lgas(values.state);
                                setAvailableLgas(stateData ? stateData.lgas : []);
                            } catch (error) {
                                setAvailableLgas([]);
                            }
                        } else {
                            setAvailableLgas([]);
                        }
                    }, [values.state]);

                    return (
                        <Form className="flex flex-col gap-4 mt-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                                <select
                                    name="state"
                                    value={values.state}
                                    onChange={(e) => {
                                        setFieldValue("state", e.target.value);
                                        setFieldValue("lga", "");
                                    }}
                                    className="w-full p-3 border border-gray-300 bg-white text-sm"
                                >
                                    <option value="">Select a state</option>
                                    {states.map((state: string) => (
                                        <option key={state} value={state}>{state}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">LGA (Optional)</label>
                                <select
                                    name="lga"
                                    value={values.lga}
                                    onChange={(e) => setFieldValue("lga", e.target.value)}
                                    className="w-full p-3 border border-gray-300 bg-white text-sm"
                                    disabled={!values.state || availableLgas.length === 0}
                                >
                                    <option value="">All LGAs (State-wide)</option>
                                    {availableLgas.map((lga: string) => (
                                        <option key={lga} value={lga}>{lga}</option>
                                    ))}
                                </select>
                            </div>

                            <Field
                                name="fee"
                                type="number"
                                label="Fee (NGN)"
                                placeholder="Enter fee amount"
                            />

                            <div className="flex items-center gap-2 mt-2">
                                <input
                                    type="checkbox"
                                    id="isDefault"
                                    name="isDefault"
                                    checked={values.isDefault}
                                    onChange={(e) => setFieldValue("isDefault", e.target.checked)}
                                    className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                                />
                                <label htmlFor="isDefault" className="text-sm text-gray-700">
                                    Set as default shipping fee
                                </label>
                            </div>

                            <div className="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    id="isActive"
                                    name="isActive"
                                    checked={values.isActive}
                                    onChange={(e) => setFieldValue("isActive", e.target.checked)}
                                    className="w-4 h-4 text-black border-gray-300 rounded focus:ring-black"
                                />
                                <label htmlFor="isActive" className="text-sm text-gray-700">
                                    Active
                                </label>
                            </div>

                            <div className="flex justify-end gap-4 mt-6">
                                <Button
                                    title="Cancel"
                                    onClick={closeModal}
                                    className="bg-gray-100 text-black hover:bg-gray-200"
                                    type="button"
                                />
                                <Button
                                    title={isSubmitting || createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save"}
                                    type="submit"
                                    className="bg-black text-white hover:bg-gray-800"
                                    disabled={isSubmitting || createMutation.isPending || updateMutation.isPending}
                                />
                            </div>
                        </Form>
                    );
                }}
            </Formik>
        </ReusableModal>
    );
};

export default ShippingFeeFormModal;
