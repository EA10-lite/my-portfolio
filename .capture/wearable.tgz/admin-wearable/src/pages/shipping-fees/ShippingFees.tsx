import { useMemo, useState } from "react";
import { PageStat } from "../../../components"
import type { ShippingFee } from "../../../utils/interfaces";
import ShippingFeeTable from "./components/ShippingFeeTable";
import { useGet } from "../../../hooks";
import { useModalStore } from "../../../stores/modalStore";
import ShippingFeeFormModal from "./components/ShippingFeeFormModal";
import DeleteShippingFeeModal from "./components/DeleteShippingFeeModal";
import { Button } from "../../../components";

const ShippingFees = () => {
    const { openShippingFeeFormModal } = useModalStore();
    const [search, setSearch] = useState<string>("");

    const { data: responseData, isLoading, error } = useGet<{
        success: boolean;
        message: string;
        data?: ShippingFee[];
    }>(
        ['shippingFees', 'admin'],
        `/shipping-fees`,
        {
            staleTime: 5 * 60 * 1000,
            refetchOnWindowFocus: false,
        }
    );

    const shippingFees = useMemo(() => responseData?.data || [], [responseData?.data]);

    const stats = useMemo(() => [
        {
            label: "Total Fees Configured",
            value: shippingFees.length,
        },
        {
            label: "Active Fees",
            value: shippingFees.filter(f => f.isActive).length,
        },
        {
            label: "Default Fee Set",
            value: shippingFees.some(f => f.isDefault) ? 1 : 0,
        },
    ], [shippingFees]);

    const filteredFees = useMemo(() => {
        let filtered = shippingFees || [];

        if (search.trim()) {
            const searchTerm = search.toLowerCase().trim();
            filtered = filtered.filter((fee: ShippingFee) => {
                return (
                    fee.state.toLowerCase().includes(searchTerm) ||
                    (fee.lga && fee.lga.toLowerCase().includes(searchTerm))
                );
            });
        }

        return filtered;
    }, [search, shippingFees]);

    if (error) {
        return <div>Error: {error.message}</div>
    }

    return (
        <div className="shipping-fees">
            <div className="heading mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <PageStat
                    title="Shipping Fees"
                    stats={stats}
                    isLoading={isLoading}
                />
                <Button 
                    title="Add Shipping Fee" 
                    onClick={() => openShippingFeeFormModal()}
                    className="bg-black text-white hover:bg-gray-800 whitespace-nowrap"
                />
            </div>

            <div className="w-full">
                <ShippingFeeTable
                    shippingFees={filteredFees}
                    setSearch={setSearch}
                    search={search}
                    isLoading={isLoading}
                />
            </div>

            <ShippingFeeFormModal />
            <DeleteShippingFeeModal />
        </div>
    )
}

export default ShippingFees;
