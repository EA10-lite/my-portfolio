import { Skeleton, Text } from "../../../components";
import { Pie, PieChart } from "recharts"
import {
    type ChartConfig,
    ChartContainer,
    ChartTooltip,
    ChartTooltipContent,
  } from "../../../components/ui/chart";

interface CategoryDataPoint {
    category: string;
    sales: number;
}

interface CategoryChartProps {
    categoryData?: CategoryDataPoint[];
    isLoading?: boolean;
}

const CategoryChart = ({ categoryData, isLoading}: CategoryChartProps) => {
    return (
        <div className="border border-[#E6E6E6] p-6 w-full h-full flex flex-col">
            <Text
                title="Category Breakdown"
                type="h2"
                className="text-base font-chivo-medium font-medium mb-6"
                letterSpacing={"-2%"}
            />
            {isLoading ? (
                <div className="h-[250px]">
                    <Skeleton
                        className="border-[25px] rounded-full h-[200px] w-[200px] bg-white border-[#E6E6E6] mx-auto"
                    />
                </div>
            ) : (
                <div className="grow">
                    <ChartPieDonut categoryData={categoryData} />
                </div>
            )}
            <div className="flex flex-wrap items-center gap-4">
                {categoryData && categoryData.length > 0 ? (
                    categoryData.map(item => (
                        <Highlight
                            key={item.category}
                            title={item.category}
                            color={categoryColors[item.category] || "#CCCCCC"}
                        />
                    ))
                ) : (
                    <>
                        <Highlight title="Male" color="#000000" />
                        <Highlight title="Female" color="#0050FD" />
                        <Highlight title="Accessories" color="#F9751D" />
                        <Highlight title="Footwear" color="#13B7F3" />
                    </>
                )}
            </div>
        </div>
    )
}

export const description = "A donut chart"

// Color mapping for categories
const categoryColors: Record<string, string> = {
    male: "#000000",
    female: "#0050FD",
    accessories: "#F9751D",
    footwear: "#13B7F3",
};

// Generate chart data from backend or use empty array
const getChartData = (categoryData?: CategoryDataPoint[]) => {
    if (!categoryData || categoryData.length === 0) {
        return [];
    }

    // If there's only one category, force it to show a full donut
    if (categoryData.length === 1) {
        const item = categoryData[0];
        return [
            {
                category: item.category,
                sales: item.sales === 0 ? 1 : item.sales, // force full donut slice
                fill: categoryColors[item.category.toLowerCase()] || "#CCCCCC",
            },
        ];
    }

    // Case 2: More than one category BUT all sales = 0
    const totalSales = categoryData.reduce((sum, item) => sum + item.sales, 0);
    if (totalSales === 0) {
        // Give each category an equal slice
        return categoryData.map(item => ({
            category: item.category,
            sales: 1,  // equal slice
            fill: categoryColors[item.category.toLowerCase()] || "#CCCCCC",
        }));
    }

    // Case 3: Normal multi-category handling
    return categoryData.map(item => ({
        category: item.category,
        sales: item.sales,
        fill: categoryColors[item.category.toLowerCase()] || "#CCCCCC",
    }));
};


export function ChartPieDonut({ categoryData }: { categoryData?: CategoryDataPoint[] }) {
    const chartData = getChartData(categoryData);
    // Update chart config dynamically based on available categories
    const dynamicChartConfig = chartData.reduce((acc, item) => {
        const key = item.category.toLowerCase();
        acc[key] = {
            label: item.category,
            color: item.fill || categoryColors[item.category.toLowerCase()] || "#CCCCCC",
        };
        return acc;
    }, {} as ChartConfig);
    
    if (chartData.length === 0) {
        return (
            <div className="flex items-center justify-center h-full">
                <Text title="No category data available" type="p" />
            </div>
        );
    }
    
    return (
        <ChartContainer
            config={dynamicChartConfig}
            className="mx-auto aspect-square max-h-[250px]"
        >
            <PieChart>
                <ChartTooltip
                    cursor={false}
                    content={(
                        <ChartTooltipContent
                            hideLabel
                            className="text-sm font-chivo-regular font-normal uppercase leading-[100%] text-white"
                            style={{
                                letterSpacing: "-2%",
                            }}
                        />
                    )}
                />
                <Pie
                    data={chartData}
                    dataKey="sales"
                    nameKey="category"
                    innerRadius={70}
                />
            </PieChart>
        </ChartContainer>
    )
}


const Highlight = ({ color, title} : { color: string, title: string }) => {
    return (
        <div className="flex items-center justify-between gap-1">
            <div className="w-3 h-[1px]" style={{ backgroundColor: color }} />
            <Text title={title} />
        </div>
    )
}


export default CategoryChart;