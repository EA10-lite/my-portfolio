

import { GrEdit } from "react-icons/gr";
import { ReusableTable, type Column, type ActionMenuItem, type ServerPagination, TableHeader, TableSkeleton } from "../../../components";
import type { Product } from "../../../utils/interfaces";
import { XCircle } from "lucide-react";
import { formatCurrency } from "../../../utils/formatter";
import { useModalStore } from "../../../stores/modalStore";


type ProductTableProps = {
    products: Product[];
    setSearch: (search: string) => void;
    search: string;
    setCategoryFilter: (category: string) => void;
    categoryFilter: string;
    isLoading?: boolean;
    pagination?: ServerPagination;
    onPageChange?: (page: number) => void;
}

const categoryFilterOptions = [
    { label: "Male", value: "male" },
    { label: "Female", value: "female" },
    { label: "Accessories", value: "accessories" },
    { label: "Footwear", value: "footwear" },
];


const ProductTable = ({
    products,
    setSearch,
    search,
    setCategoryFilter,
    categoryFilter,
    isLoading,
    pagination,
    onPageChange,
}: ProductTableProps) => {
    const filterOptions = [
        {
            options: categoryFilterOptions,
            handleFilter: setCategoryFilter,
            activeFilter: categoryFilter,
        },
    ]

    const columns: Column<Product>[] = [
        {
            key: "name",
            header: "Product Name",
        },
        {
            key: "category",
            header: "Category",
        },
        {
            key: "price",
            header: "Price",
            render: (product: Product) => (
                <span className="font-medium">{formatCurrency(product.price)}</span>
            ),
        },
        {
            key: "stock",
            header: "Stock",
        },
        {
            key: "status",
            header: "Status",
        },
        {
            key: "sales",
            header: "Sales",
        },
        {
            key: "updatedAt",
            header: "Last Updated",
        },
    ];


    const { openEditProductModal, openDeleteProductModal } = useModalStore();

    const actionItems: ActionMenuItem<Product>[] = [
        {
            label: "Edit",
            icon: <GrEdit size={16} />,
            onClick: (product: Product) => {
                openEditProductModal(product);
            },
        },
        {
            label: "Remove",
            icon: <XCircle size={16} />,
            onClick: (product: Product) => {
                openDeleteProductModal(product);
            },
            className: "text-red-600 hover:bg-red-50",
        },
    ];



    return (
        <div className="w-full">
            <div className="border border-[#E6E6E6] p-6">
                <TableHeader
                    title="Products"
                    search={search}
                    handleSearch={setSearch}
                    handleExport={() => {}}
                    options={filterOptions}
                />

                {isLoading ? (
                    <TableSkeleton
                        columnData={columns}
                        numberOfColumns={7}
                        numberOfRows={6}
                    />
                ) : (
                    <ReusableTable
                        data={products as unknown as Record<string, unknown>[]}
                        columns={columns as unknown as Column<Record<string, unknown>>[]}
                        statusKey="orderStatus"
                        actionItems={actionItems as unknown as ActionMenuItem<Record<string, unknown>>[]}
                        searchPlaceholder="SEARCH ORDERS"
                        statusFilterOptions={categoryFilterOptions}
                        statusFilterValue={categoryFilter}
                        emptyMessage="No orders found"
                        pagination={pagination}
                        onPageChange={onPageChange}
                    />
                )}
            </div>
        </div>
    );
};

export default ProductTable;