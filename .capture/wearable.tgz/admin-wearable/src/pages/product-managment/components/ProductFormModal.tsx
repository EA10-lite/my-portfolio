import { useState, useEffect } from "react";
import { useModalStore } from "../../../stores/modalStore";
import { ReusableModal, Button } from "../../../components";
import { useToastStore } from "../../../stores/toastStore";
import { useQueryClient } from "@tanstack/react-query";
import type { Product } from "../../../utils/interfaces";
import axios from "axios";

const ProductFormModal = () => {
    const { isOpen, type, data, closeModal } = useModalStore();
    const { showToast } = useToastStore();
    const queryClient = useQueryClient();
    const [loading, setLoading] = useState(false);

    const isEdit = type === "editProduct";
    const isModalOpen = isOpen && (type === "addProduct" || isEdit);
    const productData = data as Product | null;

    const [formData, setFormData] = useState({
        name: "",
        description: "",
        category: "",
        price: "",
        discountPrice: "0",
        stock: "",
    });
    
    // Arrays encoded as comma-separated strings for simple input
    const [colors, setColors] = useState("");
    const [sizes, setSizes] = useState("");
    const [variants, setVariants] = useState("");

    const [imageFiles, setImageFiles] = useState<File[]>([]);
    
    useEffect(() => {
        if (isModalOpen) {
            if (isEdit && productData) {
                setFormData({
                    name: productData.name || "",
                    description: productData.description || "",
                    category: productData.category || "",
                    price: productData.price.toString(),
                    discountPrice: "0", // Add if available
                    stock: productData.stock.toString(),
                });
                // If the product object had these fields we would set them
                setColors("");
                setSizes("");
                setVariants("");
                setImageFiles([]);
            } else {
                setFormData({
                    name: "", description: "", category: "", price: "", discountPrice: "0", stock: ""
                });
                setColors(""); setSizes(""); setVariants("");
                setImageFiles([]);
            }
        }
    }, [isModalOpen, isEdit, productData]);

    if (!isModalOpen) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            setImageFiles(Array.from(e.target.files));
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            setLoading(true);

            const formPayload = new FormData();
            formPayload.append("name", formData.name);
            formPayload.append("description", formData.description);
            formPayload.append("category", formData.category);
            formPayload.append("price", formData.price);
            formPayload.append("discountPrice", formData.discountPrice);
            formPayload.append("stock", formData.stock);
            formPayload.append("samePriceForAllSizes", "true");

            if (colors) colors.split(",").forEach(c => formPayload.append("colors[]", c.trim()));
            if (sizes) sizes.split(",").forEach(s => formPayload.append("sizes[]", s.trim()));
            if (variants) variants.split(",").forEach(v => formPayload.append("variants[]", v.trim()));

            imageFiles.forEach(file => {
                formPayload.append("images", file);
            });

            const token = localStorage.getItem("adminToken");
            
            if (isEdit && productData) {
                // If editing and no new images, we keep all old images
                // The API expects 'imagesToKeep[]' if we are passing new images but want to keep old ones
                // Or we just send 'imagesToKeep[]' to retain them
                productData.images?.forEach((img: any) => {
                    if (img.publicId) {
                        formPayload.append("imagesToKeep[]", img.publicId);
                    }
                });

                await axios.put(`http://localhost:3001/api/products/${productData.id}`, formPayload, {
                    withCredentials: true,
                    headers: {
                        "Content-Type": "multipart/form-data",
                        Authorization: `Bearer ${token}`,
                    },
                });
                showToast("Product updated successfully", "success");
            } else {
                if (imageFiles.length === 0) {
                    showToast("At least one image is required", "error");
                    setLoading(false);
                    return;
                }
                await axios.post(`http://localhost:3001/api/products`, formPayload, {
                    withCredentials: true,
                    headers: {
                        "Content-Type": "multipart/form-data",
                        Authorization: `Bearer ${token}`,
                    },
                });
                showToast("Product created successfully", "success");
            }

            queryClient.invalidateQueries({ queryKey: ["products"] });
            closeModal();
        } catch (error: any) {
            console.error("Error saving product:", error);
            showToast(error?.response?.data?.message || "Failed to save product", "error");
        } finally {
            setLoading(false);
        }
    };

    return (
        <ReusableModal
            isOpen={isModalOpen}
            onClose={closeModal}
            title={isEdit ? "Edit Product" : "Add Product"}
            className="max-w-2xl"
        >
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1">
                        <label className="text-sm font-medium">Name *</label>
                        <input required name="name" value={formData.name} onChange={handleChange} className="border p-2 rounded" />
                    </div>
                    <div className="flex flex-col gap-1">
                        <label className="text-sm font-medium">Category *</label>
                        <input required name="category" value={formData.category} onChange={handleChange} className="border p-2 rounded" />
                    </div>
                    <div className="flex flex-col gap-1">
                        <label className="text-sm font-medium">Price *</label>
                        <input required type="number" name="price" value={formData.price} onChange={handleChange} className="border p-2 rounded" />
                    </div>
                    <div className="flex flex-col gap-1">
                        <label className="text-sm font-medium">Stock *</label>
                        <input required type="number" name="stock" value={formData.stock} onChange={handleChange} className="border p-2 rounded" />
                    </div>
                    <div className="flex flex-col gap-1">
                        <label className="text-sm font-medium">Colors (comma separated)</label>
                        <input name="colors" value={colors} onChange={(e) => setColors(e.target.value)} className="border p-2 rounded" />
                    </div>
                    <div className="flex flex-col gap-1">
                        <label className="text-sm font-medium">Sizes (comma separated)</label>
                        <input name="sizes" value={sizes} onChange={(e) => setSizes(e.target.value)} className="border p-2 rounded" />
                    </div>
                </div>

                <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium">Description</label>
                    <textarea name="description" value={formData.description} onChange={handleChange} className="border p-2 rounded" rows={3} />
                </div>

                <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium">Images {isEdit ? "(Select new to override)" : "*"}</label>
                    <input type="file" multiple accept="image/*" onChange={handleFileChange} className="border p-2 rounded" />
                </div>

                <div className="flex justify-end gap-4 mt-4">
                    <Button type="button" title="Cancel" onClick={closeModal} className="bg-white border text-black hover:bg-gray-50" />
                    <Button type="submit" title={loading ? "Saving..." : "Save Product"} disabled={loading} className="bg-black text-white hover:bg-gray-800" />
                </div>
            </form>
        </ReusableModal>
    );
};

export default ProductFormModal;
