import { ReusableTable, TableSkeleton, Text, type Column } from "../../../components";
import { formatCurrency } from "../../../utils/formatter";


type BestSellingProduct = {
    id: string;
    name: string;
    category: string;
    sales: number;
    price: number;
    units: number;
}


const BestSellingProductTable = ({ products, isLoading }: { products: BestSellingProduct[], isLoading?: boolean }) => {
    const columns: Column<BestSellingProduct>[] = [
        {
            key: "name",
            header: "Product Name",
        },
        {
            key: "category",
            header: "Category",
        },
        {
            key: "price",
            header: "Revenue Generated",
            render: (product: BestSellingProduct) => (
                <span className="font-medium text-center block">{formatCurrency(product.price)}</span>
            ),
        },
        {
            key: "units",
            header: "Unit Sold",
            render: (product: BestSellingProduct) => (
                <span className="font-medium text-center block">{product.sales}</span>
            ),
        },
    ];

    if (isLoading && products.length === 0) {
        return (
            <div className="flex items-center justify-center h-full">
                <TableSkeleton
                    columnData={columns}
                    numberOfColumns={columns.length}
                    numberOfRows={5}
                />
            </div>
        );
    }


    return (
        <div className="border border-[#E6E6E6] p-6">
            <Text
                title="Best Selling Products (Top 5)"
                type="h2"
                className="text-base font-chivo-medium font-medium mb-6"
                letterSpacing={"-2%"}
            />

            <ReusableTable
                data={products as unknown as Record<string, unknown>[]}
                columns={columns as unknown as Column<Record<string, unknown>>[]}
                statusKey="status"
                actionItems={[]}
            />
        </div>
    )
}

export default BestSellingProductTable;