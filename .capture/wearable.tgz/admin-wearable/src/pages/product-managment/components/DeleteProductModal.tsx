import { useModalStore } from "../../../stores/modalStore";
import { ReusableModal, Button, Text } from "../../../components";
import { useToastStore } from "../../../stores/toastStore";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import type { Product } from "../../../utils/interfaces";
import axios from "axios";

const DeleteProductModal = () => {
    const { isOpen, type, data, closeModal } = useModalStore();
    const { showToast } = useToastStore();
    const [loading, setLoading] = useState(false);
    const queryClient = useQueryClient();

    const isModalOpen = isOpen && type === "deleteProduct";
    const product = data as Product | null;

    if (!isModalOpen || !product) return null;

    const handleDelete = async () => {
        try {
            setLoading(true);
            await axios.delete(`/products/${product.id}`, {
                baseURL: "http://localhost:3001/api",
                withCredentials: true,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('adminToken')}`
                }
            });
            
            showToast("Product deleted successfully", "success");
            queryClient.invalidateQueries({ queryKey: ['products'] });
            closeModal();
        } catch (error: any) {
            console.error("Error deleting product:", error);
            showToast(error?.response?.data?.message || "Failed to delete product", "error");
        } finally {
            setLoading(false);
        }
    };

    return (
        <ReusableModal
            isOpen={isModalOpen}
            onClose={closeModal}
            title="Delete Product"
            className="max-w-md"
        >
            <div className="flex flex-col gap-6">
                <Text
                    title={`Are you sure you want to delete ${product.name}?`}
                    type="p"
                    className="text-gray-600"
                />
                
                <div className="flex justify-end gap-4 mt-2">
                    <Button
                        title="Cancel"
                        onClick={closeModal}
                        disabled={loading}
                        className="bg-white border border-gray-300 text-black hover:bg-gray-50 flex-1 lg:flex-none"
                    />
                    <Button
                        title={loading ? "Deleting..." : "Delete Product"}
                        onClick={handleDelete}
                        disabled={loading}
                        className="bg-red-600 hover:bg-red-700 text-white flex-1 lg:flex-none"
                    />
                </div>
            </div>
        </ReusableModal>
    );
};

export default DeleteProductModal;
