import { ReusableModal, Text } from "../../../components"
import { useModalStore } from "../../../stores/modalStore";
import type { ProductStatData } from "../../../utils/interfaces";


const ProductStatModal = () => {
    const { data, closeModal, type, isOpen} = useModalStore();

    if (type !== "productStat" || !data || !isOpen) {
        return null;
    }

    const productStat = data as ProductStatData;

    return (
        <ReusableModal
            onClose={closeModal}
            isOpen={isOpen}
            title={productStat?.title}
            bodyClassName="p-0"
        >
            <div className="py-4">
                <div className="flex items-center justify-between bg-[#F7F7F7] py-4 px-4">
                    <div className="w-4/5">
                        <Text
                            title={"Product Name"}
                            letterSpacing={"-2%"}
                        />
                    </div>
                    <div className="w-1/5">
                        <Text
                            title={"Stock"}
                            letterSpacing={"-2%"}
                            className="text-center"
                        />
                    </div>
                </div>
                <div className="px-4">
                    {productStat?.stats?.map((stat, index) => (
                        <div
                            key={index}
                            className="flex items-center justify-between py-4 border-b border-[#00000033] last:border-b-0"
                        >
                            <div className="w-4/5">
                                <Text
                                    title={stat.label}
                                    letterSpacing={"-2%"}
                                />
                            </div>
                            <div className="w-1/5">
                                <Text
                                    title={stat.value?.toString()}
                                    letterSpacing={"-2%"}
                                    className="text-center"
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </ReusableModal>
    )
}

export default ProductStatModal