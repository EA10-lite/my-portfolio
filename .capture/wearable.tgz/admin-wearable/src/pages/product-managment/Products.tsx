import { useMemo, useState } from "react";
import { PageStat } from "../../components"
import type { Product } from "../../utils/interfaces";
import ProductTable from "./components/ProductTable";
import BestSellingProductTable from "./components/BestSellingProductTable";
import CategoryChart from "./components/CategoryChart";
import { useGet } from "../../hooks";
import { useModalStore } from "../../stores/modalStore";
import ProductStatModal from "./components/ProductStatModal";
import ProductFormModal from "./components/ProductFormModal";
import DeleteProductModal from "./components/DeleteProductModal";
import { Button } from "../../components";


const Products = () => {
    const { openProductStatModal, openAddProductModal } = useModalStore();

    const [search, setSearch] = useState<string>("");
    const [categoryFilter, setCategoryFilter] = useState<string>("all");
    const [currentPage, setCurrentPage] = useState<number>(1);
    const itemsPerPage = 10; // Fixed to 10 items per page

    // Fetch products with stats from backend
    // Include pagination parameters: page and limit
    const { data: productsData, isLoading, error } = useGet<{
        success: boolean;
        message: string;
        products?: Product[];
        pagination?: {
            page: number;
            limit: number;
            total: number;
            pages: number;
        };
        stats?: {
            totalProducts: number;
            lowStockProducts: number;
            outOfStockProducts: number;
            lowStockProductsList: Array<{ name: string; stock: number }>;
            outOfStockProductsList: Array<{ name: string; stock: number }>;
            bestSellingProducts: Array<{
                id: string;
                name: string;
                sales: number;
                revenue: number;
                category: string;
            }>;
            categoryBreakdown: Array<{
                category: string;
                sales: number;
            }>;
        };
    }>(
        ['products', 'admin', currentPage.toString()],
        `/products/admin/all?include=stats&page=${currentPage}&limit=${itemsPerPage}`,
        {
            staleTime: 5 * 60 * 1000, // Cache for 5 minutes
            refetchOnWindowFocus: false,
        }
    );

    const products = useMemo(() => productsData?.products || [], [productsData?.products]);
    const statsData = productsData?.stats;

    // Build stats from backend data
    const stats = useMemo(() => [
        {
            label: "Total Products",
            value: statsData?.totalProducts || 0,
        },
        {
            label: "Low Stock Products",
            value: statsData?.lowStockProducts || 0,
            hasViewAction: (statsData?.lowStockProducts || 0) > 0,
            viewAction: () => openProductStatModal({
                title: "Low Stock Products",
                stats: (statsData?.lowStockProductsList || []).map(item => ({
                    label: item.name,
                    value: item.stock,
                })),
            }),
        },
        {
            label: "Out of Stock Products",
            value: statsData?.outOfStockProducts || 0,
            hasViewAction: (statsData?.outOfStockProducts || 0) > 0,
            viewAction: () => openProductStatModal({
                title: "Out of Stock Products",
                stats: (statsData?.outOfStockProductsList || []).map(item => ({
                    label: item.name,
                    value: item.stock,
                })),
            }),
        },
    ], [statsData, openProductStatModal]);

    // Note: For server-side pagination, filtering should ideally be done on the backend
    // For now, we'll apply client-side filtering but this should be moved to backend for better performance
    const filteredProducts = useMemo(() => {
        let filtered = products || [];

        // Filter by search term
        if (search.trim()) {
            const searchTerm = search.toLowerCase().trim();
            filtered = filtered.filter((product: Product) => {
                const productId = product.id.toString();
                const productName = product.name.toLowerCase();

                return (
                    productId.includes(searchTerm) ||
                    productName.includes(searchTerm)
                );
            });
        }

        // Filter by Category
        if (categoryFilter) {
            if (categoryFilter.toLowerCase() === "all") {
                return filtered;
            }

            filtered = filtered.filter((product: Product) => product.category.toLowerCase() === categoryFilter.toLowerCase());
        }

        return filtered;
    }, [search, categoryFilter, products]);

    /**
     * Handle page change for server-side pagination
     */
    const handlePageChange = (page: number) => {
        setCurrentPage(page);
    };

    /**
     * Handle search change and reset to page 1
     */
    const handleSearchChange = (newSearch: string) => {
        setSearch(newSearch);
        if (currentPage !== 1) {
            setCurrentPage(1);
        }
    };

    /**
     * Handle category filter change and reset to page 1
     */
    const handleCategoryFilterChange = (newCategory: string) => {
        setCategoryFilter(newCategory);
        if (currentPage !== 1) {
            setCurrentPage(1);
        }
    };


    /**
     * Get best selling products from backend stats
     */
    const bestSellingProducts = useMemo(() => {
        if (!statsData?.bestSellingProducts) return [];
        // Map backend best selling products to the format expected by BestSellingProductTable
        return statsData.bestSellingProducts.map(item => ({
            id: item.id,
            name: item.name,
            sales: item.sales,
            price: item.revenue, // Use revenue as price for display
            units: item.sales, // Use sales count as units
            category: item.category,
        }));
    }, [statsData]);


    if (error) {
        return <div>Error: {error.message}</div>
    }

    return (
        <div className="products">
            <div className="heading mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <PageStat
                    title="Product Management"
                    stats={stats}
                    isLoading={isLoading}
                />
            </div>

            <div className="flex flex-col lg:flex-row gap-4 justify-between mb-6">
                <div className="w-full lg:w-[36%] lg:items-stretch">
                    <CategoryChart
                        categoryData={statsData?.categoryBreakdown}
                        isLoading={isLoading}
                    />
                </div>
                <div className="w-full lg:w-[62%] lg:items-stretch">
                    <BestSellingProductTable
                        products={bestSellingProducts}
                        isLoading={isLoading}
                    />
                </div>
            </div>

            <div className="w-full">
                <ProductTable
                    products={filteredProducts}
                    setSearch={handleSearchChange}
                    search={search}
                    setCategoryFilter={handleCategoryFilterChange}
                    categoryFilter={categoryFilter}
                    isLoading={isLoading}
                    pagination={productsData?.pagination}
                    onPageChange={handlePageChange}
                />
            </div>

            <ProductStatModal />
            <ProductFormModal />
            <DeleteProductModal />
        </div>
    )
}

export default Products