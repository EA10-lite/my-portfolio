import { create } from "zustand";
import type { ModalDTO, ConfirmationModalData, Order, ProductStatData } from "../utils/interfaces";

/**
 * Modal Store
 *
 * Manages global modal state for the application.
 * Supports different modal types (currently confirmation modal).
 *
 * Usage:
 * - openConfirmationModal: Opens a confirmation modal with provided data
 * - closeModal: Closes any open modal and resets state
 *
 * Future modal types can be added by:
 * 1. Adding the type to ModalType in interfaces.ts
 * 2. Adding the data interface in interfaces.ts
 * 3. Adding an open method for that modal type
 */
export const useModalStore = create<ModalDTO>((set) => ({
    isOpen: false,
    type: null,
    data: null,


    openOrderSummaryModal: (data: Order) =>
        set({
            isOpen: true,
            type: "orderSummary",
            data,
        }),

    openConfirmationModal: (data: ConfirmationModalData) =>
        set({
            isOpen: true,
            type: "confirmation",
            data,
        }),

    openAddProductModal: () =>
        set({
            isOpen: true,
            type: "addProduct",
            data: null,
        }),

    openEditProductModal: (data: any) =>
        set({
            isOpen: true,
            type: "editProduct",
            data,
        }),

    openDeleteProductModal: (data: any) =>
        set({
            isOpen: true,
            type: "deleteProduct",
            data,
        }),

    openProductStatModal: (data: ProductStatData) =>
        set({
            isOpen: true,
            type: "productStat",
            data,
        }),

    openShippingFeeFormModal: (data?: any) =>
        set({
            isOpen: true,
            type: "shippingFeeForm",
            data,
        }),

    openDeleteShippingFeeModal: (data: any) =>
        set({
            isOpen: true,
            type: "deleteShippingFee",
            data,
        }),

    openAssignCourierModal: (data: Order) =>
        set({
            isOpen: true,
            type: "assignCourier",
            data,
        }),

    closeModal: () =>
        set({
            isOpen: false,
            type: null,
            data: null,
        }),
}));



