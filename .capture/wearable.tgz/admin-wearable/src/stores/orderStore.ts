import { create } from "zustand";
import type { Order } from "../utils/interfaces";

interface OrderState {
  updatedOrders: Map<string, Order>;
  updateOrderStatus: (orderId: string, newStatus: string) => void;
  getUpdatedOrder: (orderId: string, originalOrder: Order) => Order;
  resetOrder: (orderId: string) => void;
}

export const useOrderStore = create<OrderState>((set, get) => ({
  updatedOrders: new Map(),

  updateOrderStatus: (orderId: string, newStatus: string) => {
    set((state) => {
      const updated = new Map(state.updatedOrders);
      const existingOrder = updated.get(orderId);

      if (existingOrder) {
        updated.set(orderId, {
          ...existingOrder,
          orderStatus: newStatus,
          updatedAt: new Date().toISOString(),
        });
      } else {
        updated.set(orderId, {
          id: orderId,
          orderStatus: newStatus,
          updatedAt: new Date().toISOString(),
        } as Order);
      }

      return { updatedOrders: updated };
    });
  },

  getUpdatedOrder: (orderId: string, originalOrder: Order) => {
    const { updatedOrders } = get();
    const updated = updatedOrders.get(orderId);

    if (updated && updated.orderStatus) {
      return {
        ...originalOrder,
        orderStatus: updated.orderStatus,
        updatedAt: updated.updatedAt || originalOrder.updatedAt,
      };
    }

    return originalOrder;
  },

  resetOrder: (orderId: string) => {
    set((state) => {
      const updated = new Map(state.updatedOrders);
      updated.delete(orderId);
      return { updatedOrders: updated };
    });
  },
}));

