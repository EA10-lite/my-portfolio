import { create } from "zustand";
import type { ToastDTO, ToastType } from "../utils/interfaces";

export const useToastStore = create<ToastDTO>((set) => ({
    message: "",
    type: null,
    isVisible: false,
    // Show a toast with a message and type. Position defaults to bottom
    // so that existing usages without position continue to work as-is.
    showToast: (message: string, type: ToastType, position = "bottom") =>
        set({ message, type, position, isVisible: true }),
    hideToast: () => set({ isVisible: false }),
    position: "bottom",
}));
