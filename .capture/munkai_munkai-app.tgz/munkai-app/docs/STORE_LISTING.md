# Store listing: App Store & Google Play

Draft answers for everything the stores ask, based on what the app does today. Items marked **❓** need a decision from the Munkai team; they're collected in [Open questions](#open-questions) at the end.

Artwork is in [`assets/store/`](../assets/store). Nothing in the app imports it, so it isn't bundled into the app:

| File | Use |
|---|---|
| `assets/store/icons/app-store-icon-1024.png` | App Store icon (1024×1024, no transparency). The app icon in `assets/icon.png` is the same design. |
| `assets/store/icons/play-store-icon-512.png` | Play Store hi-res icon (512×512) |
| `assets/store/icons/play-feature-graphic-1024x500.png` | Play feature graphic |
| `assets/store/screenshots/ios-6.9/*.png` | iPhone 6.9" (1320×2868). App Store Connect scales these down for smaller iPhones. |
| `assets/store/screenshots/android-phone/*.png` | Play phone screenshots (1080×1920) |
| `assets/store/screenshots/raw/*.png` | The same screens without captions, in case the design team wants to make its own frames |

> **Screenshots use sample content** (demo titles, covers and user "Kemi"). Before submitting, recapture them against real publications you have the rights to show. Run the app, open the same six screens, and replace the files in `assets/store/screenshots/raw/`.

Screenshot order and captions:

| # | Screen | Caption |
|---|---|---|
| 1 | Home | **Stories, comics & poems**. New chapters from independent creators, every day |
| 2 | Publication | **Collect the chapters you love**. Follow a series, unlock chapters and support the creator |
| 3 | Reader | **A reader that gets out of your way**. Themes, text sizes and ambient sound for long reads |
| 4 | Explore | **Find your next obsession**. Browse by type and genre, or search the whole catalogue |
| 5 | Downloads | **Read offline, anywhere**. Download the chapters you own for flights and bad signal |
| 6 | Creator Studio | **Publish from your phone**. Creators write, schedule and manage chapters on the go |

The Wallet screen is deliberately **not** in the screenshots, because its Add funds and Withdraw buttons link out to the website (see [Payments & review risk](#payments--review-risk)).

---

## Listing copy

| Field | Value | Limit |
|---|---|---|
| App name | **Munkai** | 30 |
| iOS subtitle | Read, collect & create stories | 30 (uses 30) |
| Play short description | Read comics, novels and poems from independent creators, or publish your own. | 80 |
| iOS keywords | `comics,manga,webtoon,novels,poetry,short stories,read,writers,creators,fan translation,ebooks,serial` | 100 (uses 100) |
| iOS primary / secondary category | Books / Entertainment | |
| Play category | Books & Reference ❓ (alternative: Comics) | |
| Marketing URL | https://munkai.art | |
| Support URL | ❓ a public support page, e.g. https://munkai.art/company/contact | |
| Privacy policy URL | https://munkai.art/privacy-policy | |
| Price | Free | |
| Copyright | ❓ e.g. "© 2026 Munkai" + legal entity name | |

### iOS promotional text (170)

> New: read offline. Download the chapters you own and read them anywhere — plus a brand-new Creator Studio for publishing from your phone.

### Full description (≤ 4000)

> Munkai is a home for stories: comics, manga, novels, short stories and poetry from independent creators and fan translators.
>
> READ YOUR WAY
> • A clean reader for prose, with dark, sepia and paper themes, adjustable text size and fonts, and optional ambient sound.
> • Full-width page viewing for comics and manga.
> • Pick up exactly where you left off, on every chapter.
>
> DISCOVER
> • Featured series, Munkai Picks, trending titles and new chapters every day.
> • Browse by type (comics, books, stories, poems, articles) and genre, or search everything.
> • Follow the creators you love and see what they publish next.
>
> COLLECT AND SUPPORT CREATORS
> • Many chapters are free. Others can be collected with Munkai tokens, and the money goes to the people who made them.
> • Your collection lives in your Library, with everything you've saved for later.
>
> READ OFFLINE
> • Download the chapters you own and read them on a plane, underground, or anywhere the signal drops.
>
> FOR CREATORS
> • Creator Studio lets you publish new series, write chapters with formatting, upload comic pages or PDFs, set prices, schedule releases and reorder chapters, right from your phone.
> • Apply to become a creator in the app.
>
> JOIN THE CONVERSATION
> • Comment on chapters, like and reply, and report anything that breaks the rules.
>
> Munkai tokens are bought and withdrawn on munkai.art.

❓ Adjust that last line once the payment decision (below) is final.

### Play Store "What's new" (first release)

> The first release of Munkai for Android: read, collect, download for offline, and publish with Creator Studio.

---

## Apple: App Privacy ("nutrition label")

The app has **no analytics, advertising or tracking SDKs**. Answer **"No"** to "Do you or your third-party partners use data for tracking?"

Everything below is **linked to the user's identity**, **not used for tracking**, and collected **for App Functionality** (plus Customer Support where noted).

| Apple data type | Collected? | Where it comes from |
|---|---|---|
| Contact Info → Name | Yes | Account (first and last name), contact form |
| Contact Info → Email Address | Yes | Account, contact form (also Customer Support) |
| User Content → Photos or Videos | Yes | Profile photo and banner, publication covers, comic pages |
| User Content → Customer Support | Yes | Contact form messages and attachments |
| User Content → Other User Content | Yes | Comments, publications, chapters, reports |
| Identifiers → User ID | Yes | Account ID and username |
| Purchases → Purchase History | Yes | Token transactions and collected chapters |
| Financial Info → Other Financial Info | Yes | Munkai wallet address and token balance |
| Other Data → Other Data Types | Yes | Government ID (PDF), **only** when applying to become a creator ❓ confirm how long it's kept |
| Location, Health, Contacts, Browsing/Search history, Usage Data, Diagnostics | **No** | None of these are collected by the app. ❓ Confirm the backend doesn't log them in an identifiable way. |

Not collected by the app: reading progress, reading history, reader settings and downloads. They stay on the device.

## Google Play: Data safety

- **Is data encrypted in transit?** Yes (HTTPS only).
- **Can users request deletion?** Yes, in the app: Profile → Account → Delete account. Play also needs a public web page for deletion requests ❓ (e.g. munkai.art/delete-account).
- **Is data shared with third parties?** No. ❓ Confirm the payment provider (e.g. Flutterwave) only sees data on the website, not from the app.

| Play category → type | Collected | Optional? | Purpose |
|---|---|---|---|
| Personal info → Name | Yes | Required | Account management, App functionality |
| Personal info → Email address | Yes | Required | Account management, Communications |
| Personal info → User IDs | Yes | Required | Account management |
| Personal info → Other info (government ID) | Yes | Optional (creators only) | Fraud prevention, Account management |
| Financial info → Purchase history | Yes | Required | App functionality |
| Financial info → Other financial info (wallet address) | Yes | Required | App functionality |
| Photos and videos → Photos | Yes | Optional | App functionality |
| Files and docs | Yes | Optional | App functionality (chapter PDFs, contact attachments, ID) |
| App activity → Other user-generated content | Yes | Optional | App functionality |
| Messages → Other in-app messages | Yes (support form) | Optional | Customer support |
| Location, Contacts, Calendar, Health, Audio, Web browsing, App info & performance, Device IDs | No | | |

## Age rating

The final answer depends on what creators are allowed to publish. Munkai hosts user-generated fiction with genres like Horror, Romance, Harem, BL/GL and Dark Fantasy.

### Apple age-rating questionnaire (draft)

| Question | Draft answer |
|---|---|
| Cartoon or fantasy violence | Infrequent/Mild ❓ |
| Realistic violence | Infrequent/Mild ❓ |
| Sexual content or nudity | ❓ Depends on content rules. If explicit content is banned: None / Infrequent (mild) |
| Profanity or crude humor | Infrequent/Mild |
| Mature or suggestive themes | Infrequent/Mild ❓ |
| Horror / fear themes | Infrequent/Mild |
| Alcohol, tobacco, drugs; simulated gambling; medical info | None |
| **User-generated content** | **Yes** (publications and comments) |
| **Messaging and chat** | No (comments are public, not private messages) |
| Unrestricted web access | No (links open specific munkai.art pages only) |
| Contests | No |

Likely result: **13+**. If mature content is allowed, it would be 16+ or 18+. ❓

### Google Play content rating (IARC), draft

- **Category:** Reference, News or Educational? No. Use **"All Other App Types"**.
- **Violence / sexuality / language / controlled substances:** as in the Apple answers above.
- **Users can interact / exchange content:** Yes.
- **Shares user location:** No.
- **Allows purchase of digital goods:** Yes (collecting chapters with tokens) ❓ this depends on the payment decision.
- **Gambling:** No.

### Also required for user-generated content (Apple guideline 1.2, Google UGC policy)

| Requirement | Status |
|---|---|
| Report objectionable content | ✅ Report publication, chapter, comment and creator |
| Filter / moderation process | ❓ describe the backend moderation process in the review notes |
| **Block abusive users** | ❌ Not in the app or the web API. Apple usually requires it for UGC apps. |
| Published contact info | ✅ Contact form in the app |
| Terms users must agree to | ✅ Terms accepted at sign-up |

---

## App Review / Play review notes (draft)

> Munkai is a reading and publishing platform. Readers browse and read stories, comics and poetry. Creators can publish in Creator Studio (Profile → Creator Studio).
>
> **Demo accounts**
> • Reader: ❓ email / password (with some tokens and at least one collected chapter)
> • Creator: ❓ email / password (approved creator with a publication)
>
> **Payments.** Munkai tokens are bought and withdrawn only on our website (munkai.art). The app has no in-app purchase flow. ❓ Update once the payment decision is final.
>
> **Offline.** Chapters the user owns can be downloaded (download icon on a publication page) and read without a connection from Library → Downloads.
>
> **Content moderation.** Users can report publications, chapters, comments and creators. Reports are reviewed by our team within ❓ hours.

### Export compliance (Apple)

The app only uses standard HTTPS encryption. `app.json` sets `ios.config.usesNonExemptEncryption: false`, so App Store Connect won't ask on each build.

### Permissions shown to users

| Permission | Text | When |
|---|---|---|
| Photos (iOS) | "Munkai uses your photos so you can set a profile picture and banner, add publication covers and upload comic pages." | Edit profile, Creator Studio, contact attachments |
| Camera (iOS) | "Munkai uses your camera so you can take a profile picture." | Edit profile |
| Microphone | Not requested (disabled in the `expo-audio` config) | |
| Notifications | Not requested yet (push isn't built) | |

---

## Payments & review risk

Today's flow:
- Deposits and withdrawals open munkai.art, so they happen outside the app.
- Transfers happen in the app.
- Collecting chapters spends an existing token balance in the app.

Both stores restrict unlocking digital content inside an app with a currency bought outside it:
- **Apple 3.1.1:** digital content and features must use In-App Purchase. The "reader app" exception (3.1.3(a)) covers content purchased elsewhere, not buying new content in the app.
- **Google Play Payments policy:** similar rule for digital goods.

Options, from lowest to highest review risk:
1. **Reader-app model.** The app only reads what you already own. The "Collect" and "Unlock all" buttons open the chapter on munkai.art, and the app refreshes when you return. The Wallet shows the balance and history, with no Add funds / Withdraw buttons on iOS.
2. **Current model.** Collect with tokens in the app, and buy tokens on the web. Likely to be questioned in review.
3. **Add In-App Purchase for tokens.** Apple and Google take a 15–30% commission.

❓ Pick one before submitting. This isn't legal advice; check it with whoever handles your store accounts.

---

## Open questions

Blockers for submission:
1. **Account deletion endpoint.** The in-app flow is built (Profile → Account → Delete account). It calls a placeholder endpoint, `DELETE /api/users/profile` with `{ password, reason }`, set in `ACCOUNT_DELETE` in `src/services/profile.ts`. Until the backend ships it, the app falls back to sending a deletion request through Contact. To finish it:
   - The backend needs to add the endpoint. If it has a different path or body, change `ACCOUNT_DELETE`.
   - Google Play also needs a public web page where people can request deletion.
2. **Block users.** Needed for a UGC app on the App Store. Can the backend add block/unblock (and hide blocked users' comments)?
3. **Payment model.** Which option from [Payments & review risk](#payments--review-risk)?
4. **Demo accounts** for reviewers: one reader and one creator.
5. **Content rules / age rating.** Is explicit sexual content allowed? That decides 13+ vs 16+/18+.

Also needed:

6. Support URL and support email to publish on the listing.
7. Legal entity / seller name and the copyright line. Apple needs a D-U-N-S number for an organisation account.
8. Countries and regions to launch in.
9. How long creator ID documents are kept, for the privacy answers.
10. Moderation turnaround time, for the review notes.
11. Real content for the screenshots: which titles we can show.
12. Icon sign-off: the new icon puts the white-and-blue "M" on the navy app background. The old navy-on-white version is in git history if you prefer it.
