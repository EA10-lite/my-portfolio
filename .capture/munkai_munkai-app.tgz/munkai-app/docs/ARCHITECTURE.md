# Architecture

How the Munkai app is put together. The README has setup; this is for someone changing the code.

## Principles

1. **The web app is the source of truth.** Every screen calls the same endpoints as `munkai-frontend` and applies the same rules (edit limits, price rules, validation). File headers say which web file a screen mirrors.
2. **Native patterns over web layouts.** The app uses bottom sheets, pushed stacks, swipe-back, a floating tab bar and thumb-sized targets. Filters, menus and pickers are sheets, not dropdowns.
3. **No admin features.** Nothing that only admins can do exists in the app.
4. **Money stays on the web.** Deposit, withdraw and top-up open `munkai.art` in the phone's own browser, outside the app (`lib/links.ts → openExternal`, via `Linking.openURL`), never an in-app web view. The wallet refreshes when the user comes back. In-app token movement is limited to Transfer, and spending an existing balance to collect chapters.

## Navigation (Expo Router, `src/app`)

```
_layout.tsx            Root stack; loads fonts, hydrates session + offline index, theme, toasts
index.tsx              Splash → onboarding / login / tabs
onboarding.tsx
(auth)/                Presented as a full-screen sheet
  login · register · forgot-password · reset-password · restore-account
auth/reset-password    Universal-link target (munkai.art/auth/reset-password?code=…) → (auth)/reset-password
(tabs)/                Floating glass tab bar (components/navigation/TabBar.tsx)
  home · explore · downloads · wallet · profile   (Collections / Saved + referrals live on profile)
publication/[id]       Details, chapter list, collect / unlock-all sheets, download for offline
read/[id]?v&pub        Reader (text · page images · PDF), settings, comments
creator/[id]           Public creator page (id = username or user id)
search                 Fade-in search screen
chapters · top-creators · browse/[kind]   "See all" lists
notifications · wallet-history · referrals · edit-profile
settings               Preferences, account, support, legal, log out (gear on the profile banner)
faq · contact?subject&message&type · legal?doc=terms|refund · about · delete-account
become-creator         Apply → in review → approved / not approved
studio/                Creator Studio (creators only)
  index                Overview + your publications
  [id]                 Manage a publication (chapters, publish state, reorder)
  publication-form?id  New / edit publication
  chapter?pub&chapter  New / edit chapter (full-screen editor + publish sheet)
  reorder/[id]         Drag to reorder chapters
```

## Data layer

| Piece | File | Notes |
|---|---|---|
| HTTP client | `lib/api.ts` | axios. Bearer token from SecureStore. Camelizes every response (keys under `genreSpotlights` stay as-is). Emits "session invalid" on 401 → sign out. `fetchPage` / `fetchAllPages` for `{ data, pagination: { nextCursor } }` lists. |
| Reads | `lib/useFetch.ts` | `useFetch(key, fn)`: in-memory cache keyed by string, stale-while-revalidate, `refetch` / `reload`, `invalidate(key)`. Keys for shared data are in `lib/queryKeys.ts`. |
| Lists | `lib/useInfinite.ts` | Cursor pagination for long lists (Explore, chapters, notifications). |
| Services | `services/*.ts` | One object per area. They return plain typed data (`services/types.ts`). |

### Endpoint map

| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/{login,register,logout,migrate}` · `/password-reset/{forgot,reset}` · `/verify-email/resend` |
| Profile & social | `GET/PATCH /api/users/profile` · `POST /api/users/account/delete` · `/api/users/followers` · `/following` · `GET/POST/DELETE /api/users/follow/:username` |
| Content | `GET /api/landing` · `/api/publications` (paged, filters) · `/api/publications/:idOrSlug` · `/related` · `/creator/:idOrUsername` · `POST/DELETE /api/publications/saved` · `GET /api/creators/top` · `GET /api/chapters` (newest, paged) |
| Reading | `GET /api/chapters/list?publicationId` · `/api/chapters/read?chapterId&v` · `POST /api/chapters/collect` · `GET/POST /api/chapters/collect-all` |
| Comments & reports | `/api/comments` (+ `/:id`, `/:id/replies`, `/:id/like`) · `POST /api/reports` |
| Notifications | `GET/PATCH /api/notifications` · `PATCH /api/notifications/:id` |
| Wallet | `GET /api/payments/history` · `/transfer-history` · `POST /api/payments/transfer` |
| Creator | `GET /api/creators/requests` · `POST /api/creators/apply` · `POST/PATCH /api/publications(/:id)` · `PATCH /:id/complete` · `PATCH /:id/publish` · `GET /api/chapters/next-number` · `POST /api/chapters` · `PATCH /api/chapters/:id` · `PATCH /:id/publish` · `PATCH /api/chapters/reorder` |
| Support | `POST /api/contacts/submit` |
| App updates | `GET /api/app/version?platform&version` (public) → `components/UpdateSheet.tsx`, once per new store version |

Uploads use React Native `FormData` file parts `{ uri, name, type }`, with the field names the web sends (`coverPhoto`, `validId`, `pdf`, repeated `pages`, repeated `genre`).

## State (`src/store`)

- **`session.ts`**: the signed-in user and token. `hydrate()` is idempotent and runs in the root layout, so deep links work too. `refreshProfile()` re-reads `/api/users/profile`. `signOut()` clears the token, caches, reading history and offline downloads.
- **`saved.ts`**: optimistic saved/unsaved on top of the profile.
- **`offline.ts`**: downloaded chapters (see below).
- On-device only: reading history and progress (`lib/readingHistory.ts`, AsyncStorage), reader preferences (`lib/readerPrefs.ts`), theme preference.

## Reader (`app/read/[id].tsx`)

`parseChapterContent()` decides the format from the `content` string, as the web does:
- **HTML text:** rendered natively with `htmlparser2` → `components/reader/HtmlContent.tsx`, using reader themes, sizes and fonts.
- **Page images:** a JSON array of URLs → `ComicContent`.
- **PDF:** a single URL → `PdfContent` (WebView). iOS renders PDFs natively; Android goes through Google's embedded viewer.

Other behaviour:
- Bars hide as you scroll down.
- Scroll position is saved per chapter.
- Ambient sound uses `expo-audio`.
- Comments are in a sheet.
- A locked next chapter sends you to the collect sheet on the publication page.

## Offline reading (`store/offline.ts`)

- **Where files live:** `<documents>/offline/<chapterId>-<stamp>/`. Each folder holds `content.json` (the `/api/chapters/read` response plus the *file names* of the downloaded pages or PDF) and the files themselves. `offline/index.json` lists what's saved and which folder is current.
- **Why file names, not full paths:** iOS changes the app's container path on updates, so full paths go stale. `readOffline()` rebuilds the paths when a chapter is opened.
- **Safe updates:** a re-download goes into a new folder and replaces the old one only once it has fully succeeded. Downloads of the same chapter are de-duplicated. A generation counter stops in-flight downloads from writing themselves back after a removal or sign-out.
- **What can be saved:** chapters you can read, meaning owned, collected or free. Creators can also save their own chapters.
- **How the reader chooses a copy:**
  - It uses the saved copy straight away when the link asks for that exact version (`?v=` equals the saved `editCount`).
  - Otherwise it goes to the network, and falls back to the saved copy when there's no connection.
  - A saved chapter that changed upstream is re-downloaded in the background.
- **Where it shows up:**
  - Publication page: a download button in the action bar, with progress and a way to cancel or remove.
  - Chapter rows: a "Saved" marker.
  - Reader menu: download or remove this chapter.
  - Downloads tab: every downloaded chapter listed under its publication, with sizes and remove / remove all.
  - Home, when the feed can't load, offers "Read downloads".
- **Offline mode** (`lib/network.ts`, expo-network): with no internet the tab bar shows only Downloads and the app
  switches to it (after 2 s, so a flaky signal doesn't flip it); a cold start with no internet opens Downloads.
  The reader is left alone. When the connection returns, all tabs come back with a "You're back online" toast.
- **Limits:**
  - PDFs aren't saved on Android, because Android has no offline PDF viewer. They're remembered as "unsupported", so a publication still shows as fully downloaded.
  - Downloads are removed on sign-out.
  - Offline is disabled on web.

## Creator Studio (`app/studio`, `services/creator.ts`)

The Studio mirrors the web's `create-publication`, `upload-chapter`, `publishStatePicker` and `become-a-creator` flows.

- **Who gets it:** creators, where `role` is `Creator` (see `isCreatorRole`). Readers are sent to `become-creator`.
- **Publications:**
  - Type and fiction/non-fiction can only be set at creation.
  - The short summary is at most 30 words.
  - Covers must be PNG or JPG, 5 MB max.
  - Fan-translation fields are required for fanfics.
  - Genres come from the web's hard-coded list, in `services/creator.ts`.
- **Chapter content:**
  - Text is written in `components/studio/RichEditor.tsx`, a `contentEditable` page inside a WebView with a native toolbar. It produces TipTap-compatible HTML (`p`, `h2`, `strong`, `em`, `u`, `s`, `blockquote`, alignment).
  - New text chapters autosave on the device (AsyncStorage) until they're published.
  - Comics are page images (JPG, PNG or WebP, up to 300, drag to reorder) or a single PDF (10 MB).
- **Publishing:** `PublishSheet` sets the price (0 = free) and the timing: Now, Schedule (next 14 days, in 30-minute steps) or Draft.
- **Edits:** originals get 2 edits per live chapter; fan translations are unlimited. The app hides Edit once none are left.
- **Reordering:** `components/studio/DragSort.tsx`, long-press drag built on PanResponder, with accessibility actions for moving up and down.
- **Not in the app (or on the web either):** deleting publications or chapters, and the feature, verification and subscription pages. Importing a `.docx` file isn't built yet.

## Theming

- `theme/colors.ts` holds the light and dark palettes, and dark is the default.
- `useTheme()` returns tokens and `useThemedStyles(makeStyles)` memoizes styles per theme.
- Fonts are Grandstander (display) and Space Grotesk (body), bundled in `assets/fonts`.
- The signature cut corners come from `components/ui/CutShape.tsx`.

## Deep links

| Link | Opens |
|---|---|
| `munkai://…` | The app scheme |
| `https://munkai.art/auth/reset-password?code=…` | The reset-password screen |

For the reset link, `app.json` already declares `associatedDomains` and an Android `intentFilter`. The **website still needs to serve** `/.well-known/apple-app-site-association` and `/.well-known/assetlinks.json` for bundle / package `art.munkai.app`.

## Not built yet

- Push notifications. They need a backend endpoint to register device tokens; web VAPID push doesn't apply to native.
- Google sign-in. It needs the OAuth client IDs and the Android SHA-1.
- EAS build and submit config.
