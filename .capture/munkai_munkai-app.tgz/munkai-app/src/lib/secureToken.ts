import * as SecureStore from 'expo-secure-store';

/**
 * The auth token lives in the OS keychain / keystore (never AsyncStorage).
 * Cached in memory so the API client can attach it synchronously.
 */
const KEY = 'munkai_auth_token';
let cached: string | null = null;

export async function loadToken(): Promise<string | null> {
  try {
    cached = await SecureStore.getItemAsync(KEY);
  } catch {
    cached = null;
  }
  return cached;
}

export function getToken(): string | null {
  return cached;
}

export async function saveToken(token: string): Promise<void> {
  cached = token;
  try {
    await SecureStore.setItemAsync(KEY, token);
  } catch {
    // Keychain unavailable: keep the in-memory copy for this session.
  }
}

export async function clearToken(): Promise<void> {
  cached = null;
  try {
    await SecureStore.deleteItemAsync(KEY);
  } catch {
    // ignore
  }
}
