import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';

import type { UploadFile } from '@/services/creator';

const extOf = (mime: string) => (mime.split('/')[1] ?? 'jpg').replace('jpeg', 'jpg').replace('svg+xml', 'svg');

/** Photo library → upload parts. Returns [] when cancelled; throws 'permission' when denied. */
export async function pickImages(opts: { multiple?: boolean; aspect?: [number, number]; limit?: number } = {}): Promise<UploadFile[]> {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('permission');
  const res = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    quality: 0.9,
    allowsMultipleSelection: !!opts.multiple,
    selectionLimit: opts.multiple ? (opts.limit ?? 0) : 1,
    orderedSelection: !!opts.multiple,
    allowsEditing: !opts.multiple && !!opts.aspect,
    aspect: opts.aspect,
  });
  if (res.canceled) return [];
  return res.assets.map((a, i) => {
    const mime = a.mimeType ?? (a.uri.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg');
    return { uri: a.uri, type: mime, size: a.fileSize, name: a.fileName ?? `image-${Date.now()}-${i}.${extOf(mime)}` };
  });
}

/** Files app → a single PDF. */
export async function pickPdf(): Promise<UploadFile | null> {
  const res = await DocumentPicker.getDocumentAsync({ type: 'application/pdf', copyToCacheDirectory: true });
  const a = res.canceled ? null : res.assets?.[0];
  if (!a) return null;
  return { uri: a.uri, name: a.name, type: a.mimeType ?? 'application/pdf', size: a.size };
}

export const MB = 1024 * 1024;
export const formatSize = (bytes?: number) =>
  bytes == null ? '' : bytes >= MB ? `${(bytes / MB).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;

/** Web natural sort for comic page file names ("2.jpg" before "10.jpg"). */
export const naturalByName = (a: UploadFile, b: UploadFile) =>
  a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
