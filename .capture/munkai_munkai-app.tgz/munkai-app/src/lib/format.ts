/** Formatters ported from munkai-frontend/src/lib/utils.ts. */

/** 1200 → "1.2k" (web formatNumber). */
export function formatCompact(num: unknown): string {
  const n = Number(num) || 0;
  if (n >= 1e9) return `${parseFloat((n / 1e9).toFixed(1))}b`;
  if (n >= 1e6) return `${parseFloat((n / 1e6).toFixed(1))}m`;
  if (n >= 1e3) return `${parseFloat((n / 1e3).toFixed(1))}k`;
  return String(n);
}

/**
 * MUNK balance. The web shows 3 decimals everywhere; on a phone stat tile we drop
 * trailing zeros so "4,250.000" reads as "4,250" but "12.5" stays "12.5".
 */
export function formatBalance(num: unknown): string {
  const n = Number(num) || 0;
  return n.toLocaleString('en-US', { maximumFractionDigits: 3 });
}

/** "Feb 2026" (web formatMonthYear). */
export function formatMonthYear(date?: string | null, month: 'short' | 'long' = 'short'): string | null {
  if (!date) return null;
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString('en-US', { month, year: 'numeric' });
}

export function initials(first?: string | null, last?: string | null, fallback = '?'): string {
  const a = (first ?? '').trim()[0] ?? '';
  const b = (last ?? '').trim()[0] ?? '';
  return (a + b).toUpperCase() || fallback;
}

/** Role label shown on the profile tag. */
export function roleLabel(user: { role?: string; creatorDetails?: { isTranslator?: boolean } }): string {
  if (user.creatorDetails?.isTranslator) return 'Translator';
  const r = (user.role ?? '').toLowerCase();
  if (r === 'creator') return 'Creator';
  return 'Reader';
}
