import { useCallback, useEffect, useRef, useState } from 'react';

type Page<T> = { items: T[]; nextCursor: string | null; total: number | null };

/** Cursor pagination (munkai-frontend hooks/useInfiniteList). Session-cached per key. */
const cache = new Map<string, { items: unknown[]; cursor: string | null; total: number | null; done: boolean }>();

export function clearInfiniteCache() {
  cache.clear();
}

export function useInfinite<T>(key: string, fetchPage: (cursor?: string) => Promise<Page<T>>) {
  const cached = cache.get(key);
  const [items, setItems] = useState<T[]>((cached?.items as T[]) ?? []);
  const [total, setTotal] = useState<number | null>(cached?.total ?? null);
  const [loading, setLoading] = useState(!cached);
  const [loadingMore, setLoadingMore] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const cursor = useRef<string | null>(cached?.cursor ?? null);
  const done = useRef(cached?.done ?? false);
  const busy = useRef(false);
  const fn = useRef(fetchPage);
  fn.current = fetchPage;

  const load = useCallback(
    async (reset: boolean) => {
      if (busy.current) return;
      if (!reset && done.current) return;
      busy.current = true;
      try {
        const page = await fn.current(reset ? undefined : (cursor.current ?? undefined));
        const next = reset ? page.items : [...((cache.get(key)?.items as T[]) ?? []), ...page.items];
        cursor.current = page.nextCursor;
        done.current = !page.nextCursor;
        cache.set(key, { items: next, cursor: page.nextCursor, total: page.total, done: done.current });
        setItems(next);
        setTotal(page.total);
        setError(null);
      } catch (e) {
        setError(e);
      } finally {
        busy.current = false;
        setLoading(false);
        setLoadingMore(false);
        setRefreshing(false);
      }
    },
    [key],
  );

  useEffect(() => {
    if (!cache.has(key)) load(true);
  }, [key, load]);

  return {
    items,
    total,
    error,
    loading: loading && items.length === 0,
    loadingMore,
    refreshing,
    canLoadMore: !done.current,
    loadMore: () => {
      if (done.current || busy.current) return;
      setLoadingMore(true);
      load(false);
    },
    refresh: () => {
      setRefreshing(true);
      load(true);
    },
  };
}
