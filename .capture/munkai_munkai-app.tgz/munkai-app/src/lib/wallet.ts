import { WEB_URL } from './config';

/** Web rate shown on the deposit form: $1.00 = ጠ100. */
export const TOKENS_PER_USD = 100;

/** Deposits and withdrawals are completed on the website. */
export const WALLET_WEB_URL = `${WEB_URL}/auth/payments`;

export function shortAddress(a?: string | null) {
  if (!a) return '';
  return a.length > 14 ? `${a.slice(0, 6)}…${a.slice(-4)}` : a;
}

export function toUsd(tokens: number) {
  return (tokens / TOKENS_PER_USD).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
