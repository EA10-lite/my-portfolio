/** Cache keys for useFetch. */
export const QK = {
  landing: 'landing',
  publications: 'publications',
  paymentHistory: 'payments/history',
  transfers: 'payments/transfers',
  notifications: 'notifications',
  searchPublications: 'search/publications',
  searchCreators: 'search/creators',
} as const;
