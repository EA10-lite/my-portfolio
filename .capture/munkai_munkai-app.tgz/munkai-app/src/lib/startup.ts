import { isOfflineNow } from '@/lib/network';
import { useSession } from '@/store/session';

export type StartupDestination = '/login' | '/home' | '/downloads';

/**
 * Where the app goes after the splash (call after the session has been hydrated):
 *  - Logged in  → Home (no internet → Downloads, offline mode)
 *  - Logged out → Auth (Login)
 *
 * Onboarding is not in the flow yet; it will slot in before Login on first install
 * once its screen is designed.
 */
export function resolveStartupDestination(): StartupDestination {
  if (!useSession.getState().isAuthenticated) return '/login';
  return isOfflineNow() ? '/downloads' : '/home';
}
