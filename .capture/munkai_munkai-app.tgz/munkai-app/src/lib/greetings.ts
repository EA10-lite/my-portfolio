/**
 * Custom greetings — same lines and rules as the web (munkai-frontend src/lib/greetings.ts + hooks/useGreeting.ts).
 * One line is picked at random per time-of-day bucket, kept for the rest of that bucket today (stored on the
 * phone), so it doesn't change on every render or app open.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';

export type GreetingAudience = 'reader' | 'creator';
type BucketId = 'morning' | 'afternoon' | 'evening' | 'lateNight';

const HOURS: { id: BucketId; startHour: number; endHour: number }[] = [
  { id: 'morning', startHour: 5, endHour: 11 },
  { id: 'afternoon', startHour: 12, endHour: 16 },
  { id: 'evening', startHour: 17, endHour: 23 },
  { id: 'lateNight', startHour: 0, endHour: 4 },
];

const LINES: Record<GreetingAudience, Record<BucketId, string[]>> = {
  reader: {
    morning: [
      'Fresh Chapters',
      'Your Shelf Awaits',
      'Bookmark Removed',
      'Something New Dropped',
      'Start a World',
      'Unread & Waiting',
      'Coffee, Then Chapters',
      'Pick Up Where You Left',
      'One Before Work?',
      'The Story Resumes',
      'New Arc, Who Dis',
      'First Read of the Day',
    ],
    afternoon: [
      'Sneak a Chapter',
      'Midday Escape',
      'Work Can Wait',
      'Just One More',
      'Reading Break',
      'Back to the Story',
      'Where Were We?',
      'Chapter Break',
      'Still on That Arc?',
      'Lunch & Lore',
      'Five Minutes, Tops',
    ],
    evening: [
      'Time to Binge',
      'One More Chapter?',
      'Cliffhanger Hours',
      'Your Couch Awaits',
      'Turn the Page',
      'Wind Down, Read Up',
      'Tonight’s Chapter',
      'Escape Reality',
      'Snacks & Chapters 🍿',
      'The Good Part',
      'No Spoilers',
      'Settle In',
    ],
    lateNight: [
      'Just This Chapter',
      'You Said One More',
      'The Plot Won’t Wait',
      'Still Reading?',
      'Sleep Is a Plot Device',
      'Cliffhanger Casualty',
      '3AM and Invested',
      'Nocturnal Reader',
      'Tomorrow You Will Regret',
      'One Eye Open',
      'The Widow Is Awake 🕯️',
    ],
  },
  creator: {
    morning: [
      'Fresh Page',
      'The Page Is Blank',
      'First Draft Energy',
      'Ink’s Not Dry',
      'Open the Doc',
      'New Arc Begins',
      'Your Muse Called',
      'Warm Up the Hands',
      'Coffee, Then Words',
      'Make It Canon',
      'Today’s Word Count',
      'Build a World',
    ],
    afternoon: [
      'Midday Draft',
      'Word Count Check',
      'One More Paragraph',
      'Break the Block',
      'Scene Change',
      'Revise & Repeat',
      'Plot Hole Patrol',
      'The Edit Pass',
      'Kill Your Darlings',
      'Say It Better',
      'Mid-Arc Energy',
    ],
    evening: [
      'Golden Hour Words',
      'Write the Scene',
      'End the Chapter',
      'Give Them a Twist',
      'Ink & Quiet',
      'Finish the Thought',
      'One Good Line',
      'Shape the Ending',
      'The Quiet Hours',
      'Set the Scene',
      'Your Readers Wait',
    ],
    lateNight: [
      'Ink & Insomnia 🖋️',
      'The 3AM Draft',
      'Midnight Manuscript',
      'The Muse Never Sleeps',
      'Save Your Work 💾',
      'Write Now, Edit Later',
      'Still Drafting?',
      'Burning the Oil 🕯️',
      'Unfinished Business',
      'One More Line',
      'Ghostwriter Hours 👻',
    ],
  },
};

function bucketFor(hour: number) {
  return HOURS.find((b) => hour >= b.startHour && hour <= b.endHour) ?? HOURS[0];
}

function todayKey(audience: GreetingAudience, bucket: BucketId) {
  const d = new Date();
  const ymd = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  return `munkai_greeting_${audience}_${ymd}_${bucket}`;
}

/** The day's greeting for this time of day ('' until it's read from storage — a frame or two). */
export function useGreeting(audience: GreetingAudience = 'reader') {
  const [greeting, setGreeting] = useState('');

  useEffect(() => {
    let alive = true;
    const bucket = bucketFor(new Date().getHours());
    const key = todayKey(audience, bucket.id);
    const lines = LINES[audience][bucket.id];
    AsyncStorage.getItem(key)
      .catch(() => null)
      .then((stored) => {
        const pick = stored ?? lines[Math.floor(Math.random() * lines.length)];
        if (!stored) AsyncStorage.setItem(key, pick).catch(() => {});
        if (alive) setGreeting(pick);
      });
    return () => {
      alive = false;
    };
  }, [audience]);

  return greeting;
}
