/**
 * App configuration. Set EXPO_PUBLIC_API_URL in `.env` (Expo only exposes
 * variables prefixed with EXPO_PUBLIC_). Falls back to production.
 */
export const API_URL = (process.env.EXPO_PUBLIC_API_URL || 'https://api.munkai.art').replace(/\/$/, '');

/** Public website — used for legal pages and flows that still finish on the web. */
export const WEB_URL = 'https://munkai.art';

export const LINKS = {
  terms: `${WEB_URL}/privacy-policy`,
  privacy: `${WEB_URL}/privacy-policy`,
  refund: `${WEB_URL}/refund-policy`,
} as const;

// Printed once in the Metro terminal so it's obvious which backend the app is talking to.
if (__DEV__) {
  console.log(
    `[Munkai] API: ${API_URL}${process.env.EXPO_PUBLIC_API_URL ? '' : '  (EXPO_PUBLIC_API_URL not set — using production default)'}`,
  );
}
