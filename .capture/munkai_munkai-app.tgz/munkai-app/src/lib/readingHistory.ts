import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';

/**
 * "Continue reading" — the web doesn't track progress, so the app remembers it on the device.
 * The reader screen (not built yet) calls `recordReading` as the user reads.
 */
export type ReadingEntry = {
  publicationId: string;
  publicationName: string;
  coverPhoto?: string | null;
  chapterId: string;
  chapterNumber: number;
  chapterName?: string | null;
  /** 0–1 */
  progress: number;
  updatedAt: number;
};

const KEY = 'munkai_reading_history';
const MAX = 12;
const subs = new Set<(list: ReadingEntry[]) => void>();

export async function getReadingHistory(): Promise<ReadingEntry[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    const list = raw ? (JSON.parse(raw) as ReadingEntry[]) : [];
    return Array.isArray(list) ? list.sort((a, b) => b.updatedAt - a.updatedAt) : [];
  } catch {
    return [];
  }
}

export async function recordReading(entry: Omit<ReadingEntry, 'updatedAt'>) {
  const list = (await getReadingHistory()).filter((e) => e.publicationId !== entry.publicationId);
  const next = [{ ...entry, updatedAt: Date.now() }, ...list].slice(0, MAX);
  await AsyncStorage.setItem(KEY, JSON.stringify(next)).catch(() => {});
  subs.forEach((s) => s(next));
}

export async function clearReadingHistory() {
  await AsyncStorage.removeItem(KEY).catch(() => {});
  subs.forEach((s) => s([]));
}

export function useReadingHistory() {
  const [list, setList] = useState<ReadingEntry[]>([]);
  useEffect(() => {
    let alive = true;
    getReadingHistory().then((l) => alive && setList(l));
    subs.add(setList);
    return () => {
      alive = false;
      subs.delete(setList);
    };
  }, []);
  return list;
}
