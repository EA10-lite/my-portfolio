import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import Constants from 'expo-constants';
import { Alert, Platform } from 'react-native';

/**
 * Release builds close the app on an uncaught JavaScript error, with no message for the user.
 * This keeps the error on the device and shows it on the next launch (with "Copy"), so a
 * tester can send it to us without adb. Native crashes don't reach here — if nothing shows up
 * after a crash, the crash was native and `adb logcat` is needed.
 */
const KEY = 'munkai_last_crash';
type ErrorUtilsT = {
  getGlobalHandler: () => (e: unknown, fatal?: boolean) => void;
  setGlobalHandler: (h: (e: unknown, fatal?: boolean) => void) => void;
};

export function installCrashReporter() {
  const EU = (globalThis as unknown as { ErrorUtils?: ErrorUtilsT }).ErrorUtils;
  if (!EU) return;
  const previous = EU.getGlobalHandler();
  EU.setGlobalHandler((error, isFatal) => {
    try {
      const e = error as { message?: string; stack?: string; name?: string };
      const report = {
        at: new Date().toISOString(),
        fatal: !!isFatal,
        message: `${e?.name ?? 'Error'}: ${e?.message ?? String(error)}`,
        stack: String(e?.stack ?? '').slice(0, 3000),
        platform: `${Platform.OS} ${Platform.Version}`,
        version: Constants.expoConfig?.version ?? '',
      };
      // Fire-and-forget: the process may die right after this.
      AsyncStorage.setItem(KEY, JSON.stringify(report)).catch(() => {});
    } catch {
      // never throw from the handler
    }
    previous(error, isFatal);
  });
}

export async function showLastCrash() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return;
    await AsyncStorage.removeItem(KEY);
    const r = JSON.parse(raw) as { at: string; message: string; stack: string; platform: string; version: string };
    const text = `Munkai ${r.version} · ${r.platform} · ${r.at}\n${r.message}\n\n${r.stack}`;
    Alert.alert('The app closed unexpectedly last time', `${r.message}\n\nCopy the details and send them to the Munkai team.`, [
      { text: 'Dismiss', style: 'cancel' },
      { text: 'Copy details', onPress: () => Clipboard.setStringAsync(text).catch(() => {}) },
    ]);
  } catch {
    // ignore
  }
}
