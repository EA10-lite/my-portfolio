import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Tiny stale-while-revalidate fetcher (no react-query in the app yet).
 * Results are cached per key for the session, so switching tabs shows data instantly
 * and refreshes quietly in the background.
 */
const cache = new Map<string, { data: unknown; at: number }>();
const inflight = new Map<string, Promise<unknown>>();
const listeners = new Map<string, Set<() => void>>();

const STALE_MS = 60_000;

function load<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const running = inflight.get(key);
  if (running) return running as Promise<T>;
  const p = fn()
    .then((data) => {
      cache.set(key, { data, at: Date.now() });
      listeners.get(key)?.forEach((l) => l());
      return data;
    })
    .finally(() => inflight.delete(key));
  inflight.set(key, p);
  return p;
}

/** Forget everything (sign-out) so the next account never sees the previous one's data. */
export function clearFetchCache() {
  cache.clear();
}

/** Drop a cached key (e.g. after a transfer) — mounted screens refetch. */
export function invalidate(key: string) {
  cache.delete(key);
  listeners.get(key)?.forEach((l) => l());
}

export function useFetch<T>(key: string | null, fn: () => Promise<T>) {
  const cached = key ? (cache.get(key)?.data as T | undefined) : undefined;
  const [data, setData] = useState<T | undefined>(cached);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(!cached && !!key);
  const [refreshing, setRefreshing] = useState(false);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  const run = useCallback(
    async (mode: 'initial' | 'refresh' | 'silent') => {
      if (!key) return;
      if (mode === 'refresh') setRefreshing(true);
      if (mode === 'initial' && !cache.has(key)) setLoading(true);
      try {
        const d = await load(key, () => fnRef.current());
        setData(d);
        setError(null);
      } catch (e) {
        setError(e);
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [key],
  );

  useEffect(() => {
    if (!key) return;
    const set = listeners.get(key) ?? new Set();
    const onChange = () => {
      const c = cache.get(key);
      if (c) setData(c.data as T);
      else run('silent');
    };
    set.add(onChange);
    listeners.set(key, set);
    const c = cache.get(key);
    if (!c) run('initial');
    else if (Date.now() - c.at > STALE_MS) run('silent');
    return () => {
      set.delete(onChange);
    };
  }, [key, run]);

  return {
    data,
    error,
    /** True only when there is nothing to show yet → render skeletons. */
    loading: loading && data === undefined,
    refreshing,
    refetch: () => run('refresh'),
    reload: () => run('silent'),
  };
}
