import type { ChapterIndexEntry } from '@/services/types';

export const studioKeys = {
  pub: (id: string | number) => `studio/pub/${id}`,
  chapters: (id: string | number) => `studio/chapters/${id}`,
};

export function chapterStateOf(ch: Pick<ChapterIndexEntry, 'state' | 'publishAt'>): 'live' | 'draft' | 'scheduled' {
  if (ch.state) return ch.state;
  if (ch.publishAt && new Date(ch.publishAt).getTime() > Date.now()) return 'scheduled';
  return 'live';
}
