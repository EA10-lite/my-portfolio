import AsyncStorage from '@react-native-async-storage/async-storage';

/** Keys for small persisted app flags. (The auth token lives in SecureStore — see secureToken.ts.) */
export const StorageKeys = {
  onboardingSeen: 'munkai_onboarding_seen',
} as const;

export async function getOnboardingSeen(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(StorageKeys.onboardingSeen)) === '1';
  } catch {
    return false;
  }
}

export async function setOnboardingSeen(seen: boolean): Promise<void> {
  try {
    if (seen) await AsyncStorage.setItem(StorageKeys.onboardingSeen, '1');
    else await AsyncStorage.removeItem(StorageKeys.onboardingSeen);
  } catch {
    // Non-critical: worst case onboarding shows again.
  }
}
