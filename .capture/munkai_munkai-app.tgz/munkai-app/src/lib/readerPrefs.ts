import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { create } from 'zustand';

/** Reader settings — same options as the web ReaderSettingsSheet, remembered on the device. */
export const READER_THEMES = {
  Midnight: { bg: '#00002B', text: '#C9CCD6', heading: '#F2F2F2', dark: true },
  Paper: { bg: '#F4F1EA', text: '#2C2C2C', heading: '#1A1A1A', dark: false },
  Sepia: { bg: '#FFF9F0', text: '#3E362E', heading: '#2A231C', dark: false },
  Pristine: { bg: '#FFFFFF', text: '#1F2937', heading: '#111827', dark: false },
  Onyx: { bg: '#0A0A0A', text: '#E0E0E0', heading: '#FFFFFF', dark: true },
} as const;
export type ReaderThemeName = keyof typeof READER_THEMES;

export const TEXT_SIZES = [15, 17, 19, 21, 24] as const;

export const READER_FONTS = {
  Default: { regular: 'SpaceGrotesk-Regular', bold: 'SpaceGrotesk-Bold', weight: undefined },
  Serif: { regular: Platform.select({ ios: 'Georgia', default: 'serif' })!, bold: Platform.select({ ios: 'Georgia-Bold', default: 'serif' })!, weight: '700' as const },
  Playful: { regular: 'Grandstander-Regular', bold: 'Grandstander-Bold', weight: undefined },
} as const;
export type ReaderFontName = keyof typeof READER_FONTS;

export const AMBIENT_TRACKS = {
  Off: null,
  Thunder: 'https://munkai-storage.s3.us-east-1.amazonaws.com/tracks/ThunderSounds.mp3',
  Lofi: 'https://munkai-storage.s3.us-east-1.amazonaws.com/tracks/Lofi-One.mp3',
  Piano: 'https://munkai-storage.s3.us-east-1.amazonaws.com/tracks/Piano-One.mp3',
} as const;
export type AmbientName = keyof typeof AMBIENT_TRACKS;

type Prefs = { theme: ReaderThemeName; size: number; font: ReaderFontName; ambient: AmbientName };
const KEY = 'munkai_reader_prefs';
const DEFAULTS: Prefs = { theme: 'Midnight', size: 2, font: 'Default', ambient: 'Off' };

export const useReaderPrefs = create<Prefs & { set: (p: Partial<Prefs>) => void; loaded: boolean }>((set, get) => ({
  ...DEFAULTS,
  loaded: false,
  set: (p) => {
    set(p);
    const { theme, size, font, ambient } = { ...get(), ...p };
    AsyncStorage.setItem(KEY, JSON.stringify({ theme, size, font, ambient })).catch(() => {});
  },
}));

AsyncStorage.getItem(KEY)
  .then((raw) => {
    const saved = raw ? (JSON.parse(raw) as Partial<Prefs>) : {};
    useReaderPrefs.setState({
      theme: saved.theme && saved.theme in READER_THEMES ? saved.theme : DEFAULTS.theme,
      size: typeof saved.size === 'number' ? Math.min(Math.max(saved.size, 0), TEXT_SIZES.length - 1) : DEFAULTS.size,
      font: saved.font && saved.font in READER_FONTS ? saved.font : DEFAULTS.font,
      // Sound always starts off — never surprise someone with audio on open.
      ambient: 'Off',
      loaded: true,
    });
  })
  .catch(() => useReaderPrefs.setState({ loaded: true }));
