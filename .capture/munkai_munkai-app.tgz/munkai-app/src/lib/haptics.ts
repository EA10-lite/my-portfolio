import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

/**
 * Haptics policy (native feel without buzzing on every tap):
 * - Plain taps (buttons, chips, tabs) never vibrate.
 * - `select` / `impact` — small confirmations (toggles, drag pick-up, save). iOS only:
 *   Android users expect silence here, and its motors feel much heavier than the Taptic Engine.
 * - `success` / `error` / `warning` — outcomes of an action (sent, failed). Both platforms.
 */
const ios = Platform.OS === 'ios';
const quiet = () => Promise.resolve();

export const haptic = {
  select: () => (ios ? Haptics.selectionAsync() : quiet()),
  impact: (style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => (ios ? Haptics.impactAsync(style) : quiet()),
  success: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success),
  error: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error),
  warning: () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning),
};
export const ImpactStyle = Haptics.ImpactFeedbackStyle;
