import { router } from 'expo-router';

import { toast } from '@/components/ui/Toast';
import { apiErrorMessage } from '@/lib/api';
import { chaptersApi } from '@/services/chapters';

import type { Publication, RecentChapter, TopCreator } from '@/services/types';

export const PUBLICATION_TYPES = [
  { value: 'comic', label: 'Comics' },
  { value: 'book', label: 'Books' },
  { value: 'poem', label: 'Poems' },
  { value: 'story', label: 'Stories' },
  { value: 'article', label: 'Articles' },
] as const;
export type PublicationTypeValue = (typeof PUBLICATION_TYPES)[number]['value'];

/** "COMIC" / "Comic" → "Comic" */
export function typeLabel(type?: string | null) {
  if (!type) return '';
  const t = type.toLowerCase();
  return t.charAt(0).toUpperCase() + t.slice(1);
}

export function genres(pub: Pick<Publication, 'genre'>): string[] {
  if (Array.isArray(pub.genre)) return pub.genre.filter(Boolean);
  if (typeof pub.genre === 'string' && pub.genre)
    return pub.genre
      .split(',')
      .map((g) => g.trim())
      .filter(Boolean);
  return [];
}

export function authorHandle(pub: Publication): string | null {
  const u = pub.username ?? pub.author?.username ?? pub.users?.username;
  return u ? `@${u}` : null;
}

/** "Comic · @tobi_ink" */
export function pubMeta(pub: Publication) {
  return [typeLabel(pub.publicationType), authorHandle(pub)].filter(Boolean).join(' · ');
}

export function title(s?: string | null) {
  return (s ?? '').trim();
}

export function creatorWorks(c: TopCreator) {
  return c.totalPublications ?? c.totalPublications ?? 0;
}

export function timeAgo(date?: string | null) {
  if (!date) return '';
  const ms = Date.now() - new Date(date).getTime();
  if (Number.isNaN(ms)) return '';
  const m = Math.round(ms / 60000);
  if (m < 60) return `${Math.max(m, 1)}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.round(h / 24);
  if (d < 30) return `${d}d ago`;
  return new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

/** Open the publication details screen. */
export function openPublication(pub: Pick<Publication, 'id'> & { name?: string }) {
  router.push({ pathname: '/publication/[id]', params: { id: String(pub.id) } });
}

type OpenableChapter = {
  id: string | number;
  editCount?: number;
  publicationId?: string | number;
  isCollected?: boolean;
  canRead?: boolean;
  price?: number | null;
};

// Price must be known (feeds without a price fall through to the normal flow).
const isFreeUnowned = (ch: OpenableChapter) => ch.price != null && !Number(ch.price) && ch.isCollected !== true && ch.canRead !== true;

function pushReader(ch: OpenableChapter) {
  router.push({
    pathname: '/read/[id]',
    params: {
      id: String(ch.id),
      ...(ch.editCount != null ? { v: String(ch.editCount) } : {}),
      ...(ch.publicationId != null ? { pub: String(ch.publicationId) } : {}),
    },
  });
}

/**
 * Free chapter → collect it in the background (the API still needs a 0-token collect, like the web)
 * and open the reader straight away. "Already collected" is treated as success.
 */
export async function readFreeChapter(ch: OpenableChapter, mode: 'push' | 'replace' = 'push') {
  try {
    await chaptersApi.collect(ch.id);
  } catch (err) {
    const msg = apiErrorMessage(err, '').toLowerCase();
    if (!/already/.test(msg)) {
      toast.error('Couldn’t open chapter', apiErrorMessage(err));
      return false;
    }
  }
  if (mode === 'replace') {
    router.replace({
      pathname: '/read/[id]',
      params: {
        id: String(ch.id),
        ...(ch.editCount != null ? { v: String(ch.editCount) } : {}),
        ...(ch.publicationId != null ? { pub: String(ch.publicationId) } : {}),
      },
    });
  } else pushReader(ch);
  return true;
}

/** True when a chapter should show READ (free and not collected yet). */
export const showsReadButton = isFreeUnowned;

/** Open a chapter in the reader (the reader handles locked chapters). */
export function openChapter(ch: OpenableChapter) {
  // Free and not collected yet → collect + open, no detour through the publication page.
  if (isFreeUnowned(ch)) {
    void readFreeChapter(ch);
    return;
  }
  // A paid chapter we know isn't owned yet → publication page with the Collect sheet open.
  if (ch.publicationId != null && ch.canRead === undefined && ch.isCollected === false) {
    router.push({ pathname: '/publication/[id]', params: { id: String(ch.publicationId), collect: String(ch.id) } });
    return;
  }
  pushReader(ch);
}

/** Creator page — the API accepts a username or user id (web: /creator/[id]). */
export function openCreator(c: Pick<TopCreator, 'username'>) {
  router.push({ pathname: '/creator/[id]', params: { id: c.username } });
}

export function chapterTitle(ch: { name?: string | null; chapterNumber: number }) {
  return ch.name?.trim() || `Chapter ${ch.chapterNumber}`;
}
