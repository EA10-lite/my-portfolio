/**
 * Field rules — identical to the zod schemas in munkai-frontend
 * (components/forms/signIn.tsx, signUp.tsx, forgot-password.tsx, modals/accountMigration.tsx).
 * Each returns an error message, or undefined when valid.
 */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const isEmail = (v: string) => EMAIL_RE.test(v.trim());

export const rules = {
  loginId: (v: string) => (v.trim().length > 0 ? undefined : 'Enter a valid email or username'),
  loginPassword: (v: string) =>
    v.length < 4 ? 'Password must be at least 4 characters' : v.length > 15 ? 'Password must not exceed 15 characters' : undefined,

  firstName: (v: string) =>
    !v.trim() ? 'First name is required' : v.length > 30 ? "First name can't exceed 30 characters" : undefined,
  lastName: (v: string) =>
    !v.trim() ? 'Last name is required' : v.length > 30 ? "Last name can't exceed 30 characters" : undefined,

  username: (v: string) =>
    v.length < 4
      ? 'Username must have at least 4 characters'
      : v.length > 20
        ? "Username can't exceed 20 characters"
        : !/^[a-z0-9_]+$/.test(v)
          ? 'Only lowercase letters, numbers and underscores'
          : undefined,

  email: (v: string) => (isEmail(v) ? undefined : 'Invalid email address'),
  code: (v: string) => (/^\d{6}$/.test(v) ? undefined : 'Code must be 6 digits'),

  password: (v: string) => {
    if (v.length < 8) return 'Password must be at least 8 characters long';
    if (v.length > 15) return 'Password must not exceed 15 characters';
    if (!/[A-Z]/.test(v)) return 'Password must include at least one uppercase letter';
    if (!/[0-9]/.test(v)) return 'Password must include at least one number';
    if (!/[\W_]/.test(v)) return 'Password must include at least one special character';
    return undefined;
  },
  confirm: (pw: string, confirm: string) => (confirm && pw === confirm ? undefined : 'Passwords do not match'),
};

/** Individual checks for the live password checklist. */
export const passwordChecks = (v: string) => ({
  length: v.length >= 8 && v.length <= 15,
  upper: /[A-Z]/.test(v),
  number: /[0-9]/.test(v),
  symbol: /[\W_]/.test(v),
});
