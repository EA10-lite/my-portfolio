/**
 * Connection state for offline mode (Netflix-style: no internet → only Downloads).
 * expo-network listener; native only (web is always "online").
 *  - The first reading applies at once, so a cold start with no internet opens Downloads.
 *  - Going offline later waits 2 s, so a flaky signal doesn't flip the app back and forth.
 *  - Coming back online applies at once.
 *  - Unknown (undefined / null) counts as online.
 */
import * as Network from 'expo-network';
import { Platform } from 'react-native';
import { create } from 'zustand';

const NATIVE = Platform.OS === 'ios' || Platform.OS === 'android';
const OFFLINE_DELAY_MS = 2000;

type NetState = { offline: boolean; known: boolean };
export const useNetwork = create<NetState>(() => ({ offline: false, known: !NATIVE }));

const isOffline = (s: Network.NetworkState) => s.isConnected === false || s.isInternetReachable === false;

let started = false;
let timer: ReturnType<typeof setTimeout> | null = null;

function apply(next: boolean, immediate: boolean) {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  if (!next || immediate) {
    useNetwork.setState({ offline: next, known: true });
    return;
  }
  timer = setTimeout(() => useNetwork.setState({ offline: true, known: true }), OFFLINE_DELAY_MS);
}

/** Start listening (idempotent). Resolves once the first reading is in. */
export function startNetworkWatch(): Promise<void> {
  if (!NATIVE || started) return Promise.resolve();
  started = true;
  Network.addNetworkStateListener((s) => apply(isOffline(s), false));
  return Network.getNetworkStateAsync()
    .then((s) => apply(isOffline(s), true))
    .catch(() => useNetwork.setState({ known: true }));
}

export const useIsOffline = () => useNetwork((s) => s.offline);
export const isOfflineNow = () => useNetwork.getState().offline;
