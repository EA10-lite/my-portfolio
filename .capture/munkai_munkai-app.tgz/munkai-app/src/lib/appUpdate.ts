/**
 * "An update is ready" — canvas variant B (dismissible sheet).
 * Checks GET /api/app/version on launch and when the app returns after 6+ hours.
 * Shows once per new store version: "Later" remembers that version on this phone.
 * Any error, timeout or missing field → nothing is shown.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';

import { appVersionApi, type AppVersionInfo } from '@/services/appVersion';

const DISMISSED_KEY = 'munkai_update_dismissed';
const RECHECK_MS = 6 * 60 * 60 * 1000;

export const installedVersion = () => Constants.expoConfig?.version ?? '0.0.0';

/** Numeric semver compare: -1 if a < b, 0 if equal, 1 if a > b. Invalid input → null. */
export function compareVersions(a: string, b: string): -1 | 0 | 1 | null {
  const parse = (v: string) => {
    const m = /^v?(\d+)\.(\d+)\.(\d+)/.exec(v.trim());
    return m ? m.slice(1, 4).map(Number) : null;
  };
  const x = parse(a);
  const y = parse(b);
  if (!x || !y) return null;
  for (let i = 0; i < 3; i++) {
    if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  }
  return 0;
}

export function useAppUpdate() {
  const [update, setUpdate] = useState<AppVersionInfo | null>(null);
  const lastCheck = useRef(0);

  const check = useCallback(async () => {
    if (Platform.OS !== 'ios' && Platform.OS !== 'android') return;
    lastCheck.current = Date.now();
    try {
      const current = installedVersion();
      const info = await appVersionApi.get(Platform.OS, current);
      if (!info?.latestVersion || !info.storeUrl) return;
      if (compareVersions(current, info.latestVersion) !== -1) return;
      const dismissed = await AsyncStorage.getItem(DISMISSED_KEY).catch(() => null);
      if (dismissed === info.latestVersion) return;
      setUpdate(info);
    } catch {
      // No endpoint yet, offline or slow: say nothing.
    }
  }, []);

  useEffect(() => {
    check();
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active' && Date.now() - lastCheck.current > RECHECK_MS) check();
    });
    return () => sub.remove();
  }, [check]);

  /** "Later": hide until a newer version than this one is published. */
  const dismiss = useCallback(() => {
    if (update) AsyncStorage.setItem(DISMISSED_KEY, update.latestVersion).catch(() => {});
    setUpdate(null);
  }, [update]);

  return { update, dismiss, close: () => setUpdate(null) };
}
