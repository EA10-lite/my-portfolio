import axios, { AxiosError } from 'axios';

import { API_URL } from './config';
import { getToken } from './secureToken';

/**
 * Shared HTTP client — mirrors munkai-frontend/src/lib/api-client.ts:
 * Bearer token on every request (unless `skipAuth`), and a session-invalid
 * signal on 401 / "invalid token" responses.
 */
export const api = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true,
});

declare module 'axios' {
  interface AxiosRequestConfig {
    /** Don't send the Authorization header (login, register, etc.). */
    skipAuth?: boolean;
  }
}

api.interceptors.request.use((config) => {
  const token = getToken();
  if (!config.skipAuth && token) {
    config.headers.Authorization = `Bearer ${token}`;
  } else {
    delete config.headers.Authorization;
  }
  return config;
});

type Listener = () => void;
const unauthorizedListeners = new Set<Listener>();

/** Subscribe to "session is no longer valid" events. Returns an unsubscribe fn. */
export function onUnauthorized(listener: Listener) {
  unauthorizedListeners.add(listener);
  return () => {
    unauthorizedListeners.delete(listener);
  };
}

/**
 * The backend moved to camelCase; a few endpoints (and cached data) still send
 * snake_case. Normalise every response to camelCase so the app has one shape.
 * Keys under genreSpotlights are genre names, not fields — left alone.
 */
const KEEP_KEYS_UNDER = new Set(['genreSpotlights']);
const camel = (k: string) => (k.includes('_') ? k.replace(/_([a-z0-9])/g, (_, c: string) => c.toUpperCase()) : k);
export function camelize<T = unknown>(value: unknown, keepKeys = false): T {
  if (Array.isArray(value)) return value.map((v) => camelize(v)) as T;
  if (value && typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      const key = keepKeys ? k : camel(k);
      out[key] = camelize(v, KEEP_KEYS_UNDER.has(key));
    }
    return out as T;
  }
  return value as T;
}

api.interceptors.response.use(
  (response) => {
    response.data = camelize(response.data);
    return response;
  },
  (error: AxiosError<{ message?: string }>) => {
    const status = error.response?.status;
    const message = error.response?.data?.message;
    const sessionInvalid =
      !error.config?.skipAuth &&
      (status === 401 ||
        (message === 'Invalid or expired token' && status !== 500) ||
        message === 'Session expired or logged out from this device' ||
        message === 'Unauthorized');
    // Listeners decide whether a session was actually active.
    if (sessionInvalid) unauthorizedListeners.forEach((l) => l());
    return Promise.reject(error);
  },
);

/** Best human-readable message from an API error (web: getApiErrorMessage). */
export function apiErrorMessage(error: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (axios.isAxiosError(error)) {
    const msg = (error.response?.data as { message?: unknown } | undefined)?.message;
    if (typeof msg === 'string' && msg.trim()) return msg;
    if (!error.response) return 'No connection. Check your internet and try again.';
  }
  return fallback;
}

export function apiErrorStatus(error: unknown): number | undefined {
  return axios.isAxiosError(error) ? error.response?.status : undefined;
}

/** munkai-frontend lib/paginated.ts — `{ data: T[], pagination: { nextCursor, total } }`. */
export async function fetchPage<T>(url: string, params: Record<string, string | number | boolean | undefined> = {}) {
  const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== undefined && v !== ''));
  const body = (await api.get(url, { params: clean })).data as
    | T[]
    | { data?: T[] | { items?: T[] }; pagination?: { nextCursor?: string | null; total?: number | null } };
  const raw = Array.isArray(body) ? body : Array.isArray(body?.data) ? body.data : (body?.data as { items?: T[] })?.items;
  const pagination = Array.isArray(body) ? undefined : body?.pagination;
  return {
    items: (Array.isArray(raw) ? raw : []) as T[],
    nextCursor: pagination?.nextCursor ?? null,
    total: pagination?.total ?? null,
  };
}

export async function fetchAllPages<T>(url: string, params: Record<string, string | number | boolean | undefined> = {}, maxRequests = 20) {
  const all: T[] = [];
  let cursor: string | undefined;
  for (let i = 0; i < maxRequests; i++) {
    const page = await fetchPage<T>(url, { ...params, cursor });
    all.push(...page.items);
    if (!page.nextCursor) break;
    cursor = page.nextCursor;
  }
  return all;
}
