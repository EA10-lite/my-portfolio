import { AppState, Linking } from 'react-native';

/**
 * Opens a URL in the phone's default browser (Safari / Chrome) — outside the app, never an
 * in-app web view. `onReturn` runs once when the user comes back to the app (e.g. refresh the
 * balance after paying on munkai.art).
 */
export async function openExternal(url: string, onReturn?: () => void) {
  if (onReturn) {
    let left = false;
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'background' || state === 'inactive') left = true;
      else if (state === 'active' && left) {
        sub.remove();
        onReturn();
      }
    });
    // Don't keep listening forever if the browser never opened.
    setTimeout(() => sub.remove(), 30 * 60 * 1000);
  }
  await Linking.openURL(url);
}
