export type LegalBlock =
  | { type: 'heading'; text: string }
  | { type: 'subheading'; text: string }
  | { type: 'paragraph'; text: string; emphasis?: boolean }
  | { type: 'bullets'; items: string[] }
  | { type: 'facts'; items: { label: string; value: string }[] }
  | { type: 'callout'; title: string; text: string; email?: string; note?: string };

export type LegalDoc = {
  id: 'terms' | 'refund';
  /** Short tab label. */
  tab?: string;
  title: string;
  badge: string;
  lead: string;
  blocks: LegalBlock[];
};
