/**
 * Terms of Service — generated from munkai-frontend/src/app/privacy-policy/page.tsx.
 * Keep in sync with the web page when the legal text changes.
 */
import type { LegalDoc } from './types';

export const terms: LegalDoc = {
  id: 'terms',
  title: 'Terms of Service',
  badge: 'Legal details',
  lead: 'Please read these terms carefully before ensuring compliance with our platform policies.',
  blocks: [
  {
    "type": "paragraph",
    "text": "By clicking the box that states your acceptance of these terms and conditions, you have expressly agreed to these terms and conditions of usage. If you do not agree to these terms and conditions, please do not use this website as we may suspend or terminate your account and block your access to the site for non-compliance with these terms and conditions."
  },
  {
    "type": "heading",
    "text": "1. Creation of Account"
  },
  {
    "type": "paragraph",
    "text": "It is expected that a reader and creator (hereinafter referred to as a \"User\") create an account to participate in activities on the app. As a User, you agree to provide and update true, correct recent, and complete required information about yourself as a registration requirement. A User shall not impersonate any person, corporation, or engage in the misrepresentation of identity or use/provide another person's identity information. You agree that we may take steps to verify the correctness of information provided by you and to promptly notify us via our email and social media platform of any breach of security involving your account or that of another."
  },
  {
    "type": "paragraph",
    "text": "Users are responsible for updating personal information and providing us with their current email addresses. In the event that the last email address that you provided us is no longer valid, or for any other reason is not capable of delivering to you the notice described above, our dispatch of the email containing such notice will nonetheless constitute effective notice of the changes, modifications, additions, or deletions described in the notice."
  },
  {
    "type": "heading",
    "text": "2. Munkai Service Overview"
  },
  {
    "type": "paragraph",
    "text": "Munkai operates and maintains an online literature platform which provides online reading services, literature content generation services, and comics content distribution services."
  },
  {
    "type": "heading",
    "text": "3. Eligibility"
  },
  {
    "type": "paragraph",
    "text": "You must be at least 13 years of age to use the Service. By agreeing to these Terms, you represent and warrant to us that:"
  },
  {
    "type": "paragraph",
    "text": "(a) you are at least 13 years of age;"
  },
  {
    "type": "paragraph",
    "text": "(b) you have not previously been suspended or removed from the Service; and"
  },
  {
    "type": "paragraph",
    "text": "(c) your registration and your use of the Service is in compliance with all applicable laws and regulations. If you are using the Service on behalf of an entity, organization, or company, you represent and warrant that you have the authority to bind that organization to these Terms and you agree to be bound by these Terms on behalf of that organization."
  },
  {
    "type": "heading",
    "text": "4. Accounts and Registration"
  },
  {
    "type": "paragraph",
    "text": "To access most features of the Service, you must register for an account. When you register for an account, you may be required to provide us with some information about yourself, such as your email address or other contact information. You agree that the information you provide to us is accurate and that you will keep it accurate and up-to-date at all times. When you register, you will be asked to provide a password. You are solely responsible for maintaining the confidentiality of your account and password, and you accept responsibility for all activities that occur under your account. If you have reason to believe that your account is no longer secure, then you must immediately notify us at here ."
  },
  {
    "type": "heading",
    "text": "5. Payment Terms"
  },
  {
    "type": "paragraph",
    "text": "Certain features of the Service may require you to purchase publications. Before you pay any payment, you will have an opportunity to review and accept any fees that you will be charged. All fees are in U.S. Dollars and are non-refundable."
  },
  {
    "type": "subheading",
    "text": "5.2. Authorization"
  },
  {
    "type": "paragraph",
    "text": "Munkai reserves the right to charge the payment method you specify at the time of purchase. You authorize Munkai to charge to that payment method all sums for orders that you make and any level of Service you select as described in these Terms or published by the Company. If you pay any fees with a credit card, Munkai may seek pre-authorization of your credit card account prior to your purchase to verify that the credit card is valid and has the necessary funds or credit available to cover your purchase. Payment processing services are provided by the third-party service through which the purchase is made (e.g., Apple In-App Purchases, Google Play, PayPal)."
  },
  {
    "type": "heading",
    "text": "6. Licenses"
  },
  {
    "type": "subheading",
    "text": "6.1. Limited Licenses"
  },
  {
    "type": "paragraph",
    "text": "Subject to your complete and ongoing compliance with these Terms, Munkai grants you, solely for your personal, non-commercial use, a limited, non-exclusive, non-transferable, non-sublicensable, revocable license to:"
  },
  {
    "type": "paragraph",
    "text": "(a) install and use one object code copy of any mobile application associated with the Service obtained from a legitimate marketplace (whether installed by you or pre-installed on your mobile device by the device manufacturer) on a mobile device that you own or control; and"
  },
  {
    "type": "paragraph",
    "text": "(b) access and use the Service."
  },
  {
    "type": "subheading",
    "text": "6.2. Licenses Restrictions"
  },
  {
    "type": "paragraph",
    "text": "Except and solely to the extent such a restriction is impermissible under applicable law, you may not:"
  },
  {
    "type": "paragraph",
    "text": "(a) reproduce, distribute, publicly display, or publicly perform the Service;"
  },
  {
    "type": "paragraph",
    "text": "(b) make modifications to the Service; or"
  },
  {
    "type": "paragraph",
    "text": "(c) interfere with or circumvent any feature of the Service, including any security or access control mechanism. If you are prohibited under applicable law from using the Service, you may not use it."
  },
  {
    "type": "heading",
    "text": "7. Publications"
  },
  {
    "type": "paragraph",
    "text": "Without prior notice or consent from any user, it is within our discretion to screen, decline, delete and refuse to post any submission that fails to comply with these terms and conditions. However, if we have questions about your submission(s) including, without limitation, the copyright, we may contact you for further information including, to verify that you own the copyright or otherwise obtained permission before submitting such work."
  },
  {
    "type": "heading",
    "text": "8. User Content"
  },
  {
    "type": "subheading",
    "text": "8.1. User Content Generally"
  },
  {
    "type": "paragraph",
    "text": "Certain features of the Service may permit users to upload content to the Service, including original literary works (such as fictions, short stories, essays, etc.), suggestions, messages, comments, reviews, photos, video, images, folders, data, text, and other types of works (“User Content”) and to publish User Content on the Service. You retain copyright and any other proprietary rights that you may hold in the User Content that you post to the Service."
  },
  {
    "type": "subheading",
    "text": "8.2 Limited License Grant to Munkai"
  },
  {
    "type": "paragraph",
    "text": "By posting or publishing User Content, you grant Munkai a worldwide and non-exclusive right and license (with the right to sublicense to Munkai affiliates solely in connection with their provision of the Services) to host, store, transfer, display, perform, reproduce, transmit, broadcast, modify (which is made solely for the purpose of formatting for display), and distribute your User Content, in whole or in part, in any media formats only through our Services."
  },
  {
    "type": "subheading",
    "text": "8.3. Limited License Grant to Other Users"
  },
  {
    "type": "paragraph",
    "text": "By posting or sharing User Content with other users of the Service, you grant those users a non-exclusive license to access and use that User Content as permitted by these Terms and the functionality of the Service."
  },
  {
    "type": "subheading",
    "text": "8.4. User Content Representation and Warranties"
  },
  {
    "type": "paragraph",
    "text": "You are solely responsible for any User Content that you post or publish on the Service, and you are responsible for the consequences of posting or publishing such User Content. By posting or publishing User Content, you affirm, represent, and warrant that:"
  },
  {
    "type": "paragraph",
    "text": "(a) You are the creator or owner of the User Content, or have the necessary licenses, rights, consents, and permissions to authorize Munkai and users of the Service to use and distribute your User Content as necessary to exercise the licenses granted by you in this section, in the manner contemplated by Munkai, the Service, and these Terms;"
  },
  {
    "type": "paragraph",
    "text": "(b) Your User Content, and the use of your User Content as contemplated by these Terms, does not and will not:"
  },
  {
    "type": "paragraph",
    "text": "(i) infringe, violate, or misappropriate any third-party right, including any copyright, trademark, patent, trade secret, moral right, privacy right, right of publicity, or any other intellectual property or proprietary right;"
  },
  {
    "type": "paragraph",
    "text": "(ii) slander, defame, libel, or invade the right of privacy, publicity or other property rights of any other person; or"
  },
  {
    "type": "paragraph",
    "text": "(iii) any other Munkai policies or guidelines to which your User Content is subject;"
  },
  {
    "type": "paragraph",
    "text": "(iv) cause Munkai to violate any law or regulation."
  },
  {
    "type": "subheading",
    "text": "8.5. User Content Disclaimer"
  },
  {
    "type": "paragraph",
    "text": "We are under no obligation to edit or control User Content that you or other users post or publish, and will not be in any way responsible or liable for User Content. Munkai may, however, at any time and without prior notice, screen, remove, edit, or block any User Content that in our sole judgment violates these Terms or is otherwise objectionable. You understand that when using the Service, you will be exposed to User Content from a variety of sources and acknowledge that User Content may be inaccurate, offensive, indecent, or objectionable. Munkai does not endorse any User Content or any opinion, recommendation, or advice expressed in any User Content. You agree to waive, and do waive, any legal or equitable right or remedy you have or may have against Munkai with respect to User Content. We expressly disclaim any and all liability in connection with User Content. If notified by a user or content owner that User Content allegedly does not conform to these Terms, we may investigate the allegation and determine in our sole discretion whether to remove the User Content, which we reserve the right to do at any time and without notice. For clarity, Munkai does not permit copyright-infringing activities on the Service."
  },
  {
    "type": "heading",
    "text": "9. Digital Millennium Copyright Act"
  },
  {
    "type": "subheading",
    "text": "9.1. DMCA Notification"
  },
  {
    "type": "paragraph",
    "text": "We comply with the provisions of the Digital Millennium Copyright Act applicable to Internet service providers (17 U.S.C. §512, as amended). If you have an intellectual property rights-related complaint about material posted on the Service, you may contact our Designated Agent at the following address:"
  },
  {
    "type": "paragraph",
    "text": "Abound Consult\nATTN: Legal Department (Copyright Notification)\nPlot 659, NO 9, Kenei Street, Dawaki Offjohid, Katampe, Abuja, Nigeria\nEmail: munkailegal@gmail.com"
  },
  {
    "type": "paragraph",
    "text": "Any notice alleging that materials hosted by or distributed through the Service infringe intellectual property rights must include the following information:"
  },
  {
    "type": "paragraph",
    "text": "(a) An electronic or physical signature of the person authorized to act on behalf of the owner of the copyright or other right being infringed;"
  },
  {
    "type": "paragraph",
    "text": "(b) A description of the copyright-protected work or other intellectual property right that you claim has been infringed;"
  },
  {
    "type": "paragraph",
    "text": "(c) A description of the material that you claim is infringing and where it is located on the Service;"
  },
  {
    "type": "paragraph",
    "text": "(d) your address, telephone number, and email address;"
  },
  {
    "type": "paragraph",
    "text": "(e) A statement by you that you have a good faith belief that the use of those materials on the Service is not authorized by the copyright owner, its agent, or the law;"
  },
  {
    "type": "paragraph",
    "text": "(f) A statement by you that the above information in your notice is accurate and that, under penalty of perjury, you are the copyright or intellectual property owner or authorized to act on the copyright or intellectual property owner’s behalf."
  },
  {
    "type": "subheading",
    "text": "9.2 Repeat Infringers"
  },
  {
    "type": "paragraph",
    "text": "Munkai will promptly terminate without notice the accounts of users that are determined by Munkai to be “Repeat Infringers.” A Repeat Infringer is a user who has been notified of infringing activity or has had User Content removed from the Service at least twice."
  },
  {
    "type": "heading",
    "text": "10. Confidentiality of Personal & Account Information"
  },
  {
    "type": "paragraph",
    "text": "Every user is responsible for ensuring the confidentiality of his/her username, password, and any other information whether sensitive or not, including activities that take place in your account. You hereby agree to indemnify, defend, and hold us, our agents, legal representative(s), and other authorized users, harmless from and against any, and all losses, damages, liabilities, claims, penalties, fines, expenses arising out of any breach by you of these terms and conditions or the use of this app."
  },
  {
    "type": "subheading",
    "text": "10.1. Disclosure of Information for Legal Compliance"
  },
  {
    "type": "paragraph",
    "text": "If a user is found to have plagiarized or stolen someone else’s work, and law enforcement agencies require their information for legal action, Munkai will cooperate fully and provide the necessary details to assist in the investigation, in compliance with applicable laws."
  },
  {
    "type": "heading",
    "text": "11. The Chatroom"
  },
  {
    "type": "paragraph",
    "text": "The chatroom is a feature that enables users to communicate and share their views. Personal and sensitive information such as (telephone, e-mail, or home address) should not be disclosed in the chatroom. Disclosure of personal information through the chatroom can expose a user's information to be available and used by individuals with malign intentions and such disclosure of the information is at your own risk as the security or privacy of any information you choose to disclose in the chatroom is not guaranteed. You are and shall remain solely responsible for the information you make available on and through the app."
  },
  {
    "type": "paragraph",
    "text": "By using the Munkai platform, you acknowledge that the use of any information, recommendations, and advice posted in the chatroom are done at your own risk as we do not endorse any comments and we specifically disclaim any liability in connection therewith. Information given in the chatroom may not be reliable, and we strongly advise that users should not make any investment decisions based on such information. We shall not be liable for the inaccuracy of any information contained in a chatroom or any of our platforms that is not provided by us."
  },
  {
    "type": "heading",
    "text": "12. Rules of Conduct"
  },
  {
    "type": "paragraph",
    "text": "By using this app, you acknowledge and agree not to post or upload on the app, any of the following:"
  },
  {
    "type": "paragraph",
    "text": "(a) Materials that are defamatory, abusive, harassing, threatening, or an invasion of a right of privacy of another person;"
  },
  {
    "type": "paragraph",
    "text": "(b) Materials that contain hate speech, racially, religiously offensive, and otherwise;"
  },
  {
    "type": "paragraph",
    "text": "(c) Materials that portray violence, vulgar, obscene, pornographic, or otherwise sexually explicit content;"
  },
  {
    "type": "paragraph",
    "text": "(d) Materials that can otherwise harm any person or corporation;"
  },
  {
    "type": "paragraph",
    "text": "(e) Materials that promote child pornography, stalking, sexual assault, fraud, trafficking, drug dealing and/or drug abuse, harassment, theft, or conspiracy to commit any criminal activity;"
  },
  {
    "type": "paragraph",
    "text": "(f) Materials that are antisocial, disruptive, or destructive;"
  },
  {
    "type": "paragraph",
    "text": "(g) Materials that are illegal or encourages or advocates illegal activity;"
  },
  {
    "type": "paragraph",
    "text": "(h) Materials that infringes or violates any right of a third party such as copyright, patent, trademark, trade secret, or other intellectual, proprietary, or contractual rights;"
  },
  {
    "type": "paragraph",
    "text": "(i) Materials that infringe the right of privacy of another person or user;"
  },
  {
    "type": "paragraph",
    "text": "(j) Materials that suggests illegal solicitation of funds from others;"
  },
  {
    "type": "paragraph",
    "text": "(k) Materials that contain a virus, malware, worm, trojan, ransomware, and other harmful codes and component which tampers with, impair, or damages the app and our computer and or otherwise interrupt the use of the responsibility platform by other users."
  },
  {
    "type": "heading",
    "text": "13. Termination"
  },
  {
    "type": "paragraph",
    "text": "The Terms and Conditions are binding on users until terminated."
  },
  {
    "type": "paragraph",
    "text": "13.1.1. These Terms and Conditions are no longer binding once a user terminates the use of MUNKAI and all its platform and thereafter closes all his accounts with MUNKAI"
  },
  {
    "type": "paragraph",
    "text": "13.1.2. We shall immediately terminate a user's account including removing access to all Munkai apps without prior notice if he/she is found to have breached any of the terms and conditions and continuously or persistently engage in the infringement of copyrights, involvement in any fraudulent, abusive or illegal activity and may be reported to and through an appropriate sanctioning body."
  },
  {
    "type": "heading",
    "text": "14. Third-party Services and Linked Websites"
  },
  {
    "type": "paragraph",
    "text": "Munkai may provide tools through the Service that enable you to export information, including User Content, to third party services, including through features that allow you to link your account on Munkai with an account on the third-party service, such as Twitter or Facebook, or through our implementation of third-party buttons (such as “like” or “share” buttons). By using one of these tools, you agree that we may transfer that information to the applicable third-party service. Third party services are not under our control, and we are not responsible for any third-party service’s use of your exported information. The Service may also contain links to third-party websites. Linked websites are not under our control, and we are not responsible for their content."
  },
  {
    "type": "heading",
    "text": "15. Termination of Use"
  },
  {
    "type": "paragraph",
    "text": "Discontinuation and Modification of the Service. You may terminate your account at any time by contacting customer service . If you terminate your account, you remain obligated to pay all outstanding fees, if any, incurred prior to termination relating to your use of the Service. If you violate any provision of these Terms, your permission from us to use the Service will terminate automatically. In addition, Munkai may in its sole discretion terminate your user account on the Service or suspend or terminate your access to the Service at any time for any reason or no reason, with or without notice. We also reserve the right to modify or discontinue the Service at any time (including by limiting or discontinuing certain features of the Service), temporarily or permanently, without notice to you. We will have no liability whatsoever on account of any change to the Service or any suspension or termination of your access to or use of the Service."
  },
  {
    "type": "heading",
    "text": "16. Fee/commission"
  },
  {
    "type": "paragraph",
    "text": "Sales Commission:"
  },
  {
    "type": "paragraph",
    "text": "25% of each sale will be charged as a service fee/commission on Munkai."
  },
  {
    "type": "heading",
    "text": "17. Privacy Policy; Additional Terms"
  },
  {
    "type": "subheading",
    "text": "17.1. Privacy Policy"
  },
  {
    "type": "paragraph",
    "text": "Please read the Munkai Privacy Policy carefully for information relating to our collection, use, storage and disclosure of your personal information. The Munkai Privacy Policy is incorporated by this reference into, and made a part of, these Terms."
  },
  {
    "type": "subheading",
    "text": "17.2. Additional Terms"
  },
  {
    "type": "paragraph",
    "text": "Your use of the Service is subject to all additional terms, policies, rules, or guidelines applicable to the Service or certain features of the Service that we may post on or link to from the Service (the “Additional Terms”), such as end-user license agreements for any downloadable software applications, or rules that applicable to a particular feature or content on the Service, subject to Section 12. All Additional Terms are incorporated by this reference into, and made a part of, these Terms."
  },
  {
    "type": "heading",
    "text": "18. Modification of These Terms"
  },
  {
    "type": "paragraph",
    "text": "We reserve the right, at our discretion, to change these Terms on a going-forward basis at any time. Please check these Terms periodically for changes. Material modifications are effective upon your acceptance of the modified Terms. Immaterial modifications are effective upon publication. Disputes arising under these Terms will be resolved in accordance with the version of these Terms that was in effect at the time the dispute arose."
  },
  {
    "type": "heading",
    "text": "19. Owneership; Proprietary Rights"
  },
  {
    "type": "paragraph",
    "text": "The Service is owned and operated by Munkai. The visual interfaces, graphics, design, compilation, information, data, computer code (including source code or object code), products, software, services, and all other elements of the Service (“Materials”) provided by Munkai are protected by intellectual property and other laws. All Materials included in the Service are the property of Munkai or our third-party licensors. Except as expressly authorized by Munkai, you may not make use of the Materials. Munkai reserves all rights to the Materials not granted expressly in these Terms."
  },
  {
    "type": "heading",
    "text": "20. Feedback"
  },
  {
    "type": "paragraph",
    "text": "If you choose to provide input and suggestions regarding problems with or proposed modifications or improvements to the Service (“Feedback”), then you hereby grant Munkai an unrestricted, perpetual, irrevocable, non-exclusive, fully-paid, royalty-free right to exploit the Feedback in any manner and for any purpose, including to improve the Service and create other products and services."
  },
  {
    "type": "heading",
    "text": "21. Indemnity"
  },
  {
    "type": "paragraph",
    "text": "You are responsible for your use of the Service, and you will defend and indemnify Munkai and its officers, directors, employees, consultants, affiliates, subsidiaries and agents (together, the “Munkai Entities”) from and against every claim, liability, damage, loss, and expense, including reasonable attorneys' fees and costs, arising out of or in any way connected with:"
  },
  {
    "type": "paragraph",
    "text": "(a) your access to, use of, or alleged use of, the Service;"
  },
  {
    "type": "paragraph",
    "text": "(b) your violation of any portion of these Terms, any representation, warranty, or agreement referenced in these Terms, or any applicable law or regulation;"
  },
  {
    "type": "paragraph",
    "text": "(c) your violation of any third-party right, including any intellectual property right or publicity, confidentiality, other property, or privacy right; or"
  },
  {
    "type": "paragraph",
    "text": "(d) any dispute or issue between you and any third party. We reserve the right, at our own expense, to assume the exclusive defense and control of any matter otherwise subject to indemnification by you (without limiting your indemnification obligations with respect to that matter), and in that case, you agree to cooperate with our defense of that claim."
  },
  {
    "type": "heading",
    "text": "22. Disclaimers; No Warranties"
  },
  {
    "type": "paragraph",
    "text": "THE SERVICE AND ALL MATERIALS AND CONTENT AVAILABLE THROUGH THE SERVICE ARE PROVIDED “AS IS” AND ON AN “AS AVAILABLE” BASIS, WITHOUT WARRANTY OR CONDITION OF ANY KIND, EITHER EXPRESS OR IMPLIED. THE MUNKAI ENTITIES DISCLAIM ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, RELATING TO THE SERVICE AND ALL MATERIALS AND CONTENT AVAILABLE THROUGH THE SERVICE, INCLUDING:"
  },
  {
    "type": "paragraph",
    "text": "(a) ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, QUIET ENJOYMENT, OR NON-INFRINGEMENT; AND"
  },
  {
    "type": "paragraph",
    "text": "(b) ANY WARRANTY ARISING OUT OF COURSE OF DEALING, USAGE, OR TRADE. THE MUNKAI ENTITIES DO NOT WARRANT THAT THE SERVICE OR ANY PORTION OF THE SERVICE, OR ANY MATERIALS OR CONTENT OFFERED THROUGH THE SERVICE, WILL BE UNINTERRUPTED, SECURE, OR FREE OF ERRORS, VIRUSES, OR OTHER HARMFUL COMPONENTS, AND DO NOT WARRANT THAT ANY OF THOSE ISSUES WILL BE CORRECTED."
  },
  {
    "type": "paragraph",
    "text": "NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM THE SERVICE OR ANY MATERIALS OR CONTENT AVAILABLE THROUGH THE SERVICE WILL CREATE ANY WARRANTY REGARDING ANY OF THE MUNKAI ENTITIES OR THE SERVICE THAT IS NOT EXPRESSLY STATED IN THESE TERMS. YOU ASSUME ALL RISK FOR ANY DAMAGE THAT MAY RESULT FROM YOUR USE OF OR ACCESS TO THE SERVICE, YOUR DEALING WITH ANY OTHER SERVICE USER, AND ANY MATERIALS OR CONTENT AVAILABLE THROUGH THE SERVICE. YOU UNDERSTAND AND AGREE THAT YOU USE THE SERVICE, AND USE, ACCESS, DOWNLOAD, OR OTHERWISE OBTAIN MATERIALS OR CONTENT THROUGH THE SERVICE AND ANY ASSOCIATED SITES OR SERVICES, AT YOUR OWN DISCRETION AND RISK, AND THAT YOU ARE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR PROPERTY (INCLUDING YOUR COMPUTER SYSTEM OR MOBILE DEVICE USED IN CONNECTION WITH THE SERVICE), OR THE LOSS OF DATA THAT RESULTS FROM THE USE OF THE SERVICE OR THE DOWNLOAD OR USE OF THAT MATERIAL OR CONTENT."
  },
  {
    "type": "paragraph",
    "text": "SOME JURISDICTIONS MAY PROHIBIT A DISCLAIMER OF WARRANTIES AND YOU MAY HAVE OTHER RIGHTS THAT VARY FROM JURISDICTION TO JURISDICTION."
  },
  {
    "type": "heading",
    "text": "23. Limitation of Liability"
  },
  {
    "type": "paragraph",
    "text": "IN NO EVENT WILL THE MUNKAI ENTITIES BE LIABLE TO YOU FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL OR PUNITIVE DAMAGES (INCLUDING DAMAGES FOR LOSS OF PROFITS, GOODWILL, OR ANY OTHER INTANGIBLE LOSS) ARISING OUT OF OR RELATING TO YOUR ACCESS TO OR USE OF, OR YOUR INABILITY TO ACCESS OR USE, THE SERVICE OR ANY MATERIALS OR CONTENT ON THE SERVICE, WHETHER BASED ON WARRANTY, CONTRACT, TORT (INCLUDING NEGLIGENCE), STATUTE, OR ANY OTHER LEGAL THEORY, AND WHETHER OR NOT ANY MUNKAI ENTITY HAS BEEN INFORMED OF THE POSSIBILITY OF DAMAGE."
  },
  {
    "type": "paragraph",
    "text": "EXCEPT AS PROVIDED IN SECTION 20.4(iii), THE AGGREGATE LIABILITY OF THE MUNKAI ENTITIES TO YOU FOR ALL CLAIMS ARISING OUT OF OR RELATING TO THE USE OF OR ANY INABILITY TO USE ANY PORTION OF THE SERVICE OR OTHERWISE UNDER THESE TERMS, WHETHER IN CONTRACT, TORT, OR OTHERWISE, IS LIMITED TO THE GREATER OF:"
  },
  {
    "type": "paragraph",
    "text": "(a) THE AMOUNT YOU HAVE PAID TO MUNKAI FOR ACCESS TO AND USE OF THE SERVICE IN THE 12 MONTHS PRIOR TO THE EVENT(S) OR CIRCUMSTANCES GIVING RISE TO CLAIM; OR"
  },
  {
    "type": "paragraph",
    "text": "(b) $100."
  },
  {
    "type": "paragraph",
    "text": "SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES. ACCORDINGLY, THE ABOVE LIMITATION MAY NOT APPLY TO YOU."
  },
  {
    "type": "paragraph",
    "text": "EACH PROVISION OF THESE TERMS THAT PROVIDES FOR A LIMITATION OF LIABILITY, DISCLAIMER OF WARRANTIES, OR EXCLUSION OF DAMAGES IS INTENDED TO AND DOES ALLOCATE THE RISKS BETWEEN THE PARTIES UNDER THESE TERMS. THIS ALLOCATION IS AN ESSENTIAL ELEMENT OF THE BASIS OF THE BARGAIN BETWEEN THE PARTIES. EACH OF THESE PROVISIONS IS SEVERABLE AND INDEPENDENT OF ALL OTHER PROVISIONS OF THESE TERMS. THE LIMITATIONS IN THIS SECTION 17 WILL APPLY EVEN IF ANY LIMITED REMEDY FAILS OF ITS ESSENTIAL PURPOSE."
  },
  {
    "type": "heading",
    "text": "24. Governing Law"
  },
  {
    "type": "paragraph",
    "text": "These Terms and Conditions and any action related thereto will be governed by the laws of the jurisdiction in which we are established without regard to its conflict of laws provisions."
  },
  {
    "type": "heading",
    "text": "25. Dispute Resolution"
  },
  {
    "type": "paragraph",
    "text": "Any dispute, controversy, or claim arising out of or relating to these Terms and Conditions or the breach, termination, or invalidity thereof, shall be settled by arbitration in accordance with the arbitration rules of the jurisdiction in which we are established."
  },
  {
    "type": "heading",
    "text": "26. General"
  },
  {
    "type": "paragraph",
    "text": "These Terms, together with the Privacy Policy and any other agreements expressly incorporated by reference into these Terms, are the entire and exclusive understanding and agreement between you and Munkai regarding your use of the Service. Except as expressly permitted above, these Terms may be amended only by a written agreement signed by authorized representatives of all parties to these Terms. You may not assign or transfer these Terms or your rights under these Terms, in whole or in part, by operation of law or otherwise, without our prior written consent. We may assign these Terms at any time without notice or consent. The failure to require performance of any provision will not affect our right to require performance at any other time after that, nor will a waiver by us of any breach or default of these Terms, or any provision of these Terms, be a waiver of any subsequent breach or default or a waiver of the provision itself. Use of section headers in these Terms is for convenience only and will not have any impact on the interpretation of any provision. If any part of these Terms is held to be invalid or unenforceable, the unenforceable part will be given effect to the greatest extent possible, and the remaining parts will remain in full force and effect."
  },
  {
    "type": "heading",
    "text": "27. Dispute Resolution and Arbitration"
  },
  {
    "type": "subheading",
    "text": "27.1. Generally"
  },
  {
    "type": "paragraph",
    "text": "In the interest of resolving disputes between you and Munkai in the most expedient and cost-effective manner, you and Munkai agree that every dispute arising in connection with these Terms will be resolved by binding arbitration. Arbitration is less formal than a lawsuit in court. Arbitration uses a neutral arbitrator instead of a judge or jury, may allow for more limited discovery than in court, and can be subject to very limited review by courts. Arbitrators can award the same damages and relief that a court can award. This agreement to arbitrate disputes includes all claims arising out of or relating to any aspect of these Terms, whether based in contract, tort, statute, fraud, misrepresentation, or any other legal theory, and regardless of whether a claim arises during or after the termination of these Terms. YOU UNDERSTAND AND AGREE THAT, BY ENTERING INTO THESE TERMS, YOU AND MUNKAI ARE EACH WAIVING THE RIGHT TO A TRIAL BY JURY OR TO PARTICIPATE IN A CLASS ACTION."
  },
  {
    "type": "subheading",
    "text": "27.2. Exceptions"
  },
  {
    "type": "paragraph",
    "text": "Despite the provisions of Section 27.1, nothing in these Terms will be deemed to waive, preclude, or otherwise limit the right of either party to:"
  },
  {
    "type": "paragraph",
    "text": "(a) bring an individual action in small claims court;"
  },
  {
    "type": "paragraph",
    "text": "(b) pursue an enforcement action through the applicable federal, state, or local agency if that action is available;"
  },
  {
    "type": "paragraph",
    "text": "(c) seek injunctive relief in a court of law; or"
  },
  {
    "type": "paragraph",
    "text": "(d) to file suit in a court of law to address an intellectual property infringement claim."
  },
  {
    "type": "subheading",
    "text": "27.3. Arbitrator"
  },
  {
    "type": "paragraph",
    "text": "Any arbitration between you and Munkai will be resolved under the laws of the Federal Republic of Nigeria."
  },
  {
    "type": "subheading",
    "text": "27.4. Notice; Process"
  },
  {
    "type": "paragraph",
    "text": "A party who intends to seek arbitration must first send a written notice of the dispute to the other party by certified mail or by international express courier services (signature required) or, only if such other party has not provided a current physical address, then by electronic mail (“Notice”). Munkai’s address for Notice is: Abound consult 6 , OLUSOJI STREET, OGBA, LAGOS STATE, NIGERIA. The Notice must:"
  },
  {
    "type": "paragraph",
    "text": "(a) describe the nature and basis of the claim or dispute; and"
  },
  {
    "type": "paragraph",
    "text": "(b) set forth the specific relief sought (“Demand”). The parties will make good faith efforts to resolve the claim directly, but if the parties do not reach an agreement to do so within 30 days after the Notice is received, you or Munkai may commence an arbitration proceeding."
  },
  {
    "type": "subheading",
    "text": "27.5. Modification to This Arbitration Provision"
  },
  {
    "type": "paragraph",
    "text": "If Munkai makes any future change to this arbitration provision, other than a change to Munkai’s address for Notice, you may reject the change by sending us written notice within 30 days of the change to Munkai’s address for Notice, in which case your account with Munkai will be immediately terminated and this arbitration provision, as in effect immediately prior to the changes you rejected will survive."
  },
  {
    "type": "subheading",
    "text": "27.6. Enforceability"
  },
  {
    "type": "paragraph",
    "text": "If Section 27.6 is found to be unenforceable or if the entirety of this Section 27 is found to be unenforceable, then the entirety of this Section 27 will be null and void and, in that case, the parties agree that the exclusive jurisdiction and venue described in Section 24 will govern any action arising out of or related to these Terms."
  },
  {
    "type": "heading",
    "text": "28. Consent to Electronic Communications"
  },
  {
    "type": "paragraph",
    "text": "By using the Service, you consent to receiving certain electronic communications from us as further described in our Privacy Policy. Please read our Privacy Policy to learn more about our electronic communications practices. You agree that any notices, agreements, disclosures, or other communications that we send to you electronically will satisfy any legal communication requirements, including that those communications be in writing."
  },
  {
    "type": "heading",
    "text": "29. Contact Information"
  },
  {
    "type": "paragraph",
    "text": "The Service is offered by Abound consult, located at 6, OLUSOJI STREET, OGBA, LAGOS STATE, NIGERIA. You may contact us by sending correspondence to that address or by emailing us at munkailegal@gmail.com."
  },
  {
    "type": "heading",
    "text": "30. Notice Regarding Apple"
  },
  {
    "type": "paragraph",
    "text": "If you are using our mobile applications on an iOS device, the terms of this Section 23 apply. You acknowledge that these Terms are between you and Munkai only, not with Apple, and Apple is not responsible for the Service or its content. Apple has no obligation to furnish any maintenance or support services with respect to the Service. If the Service fails to conform to any applicable warranty, you may notify Apple and Apple will refund any applicable purchase price for the mobile application to you; and, to the maximum extent permitted by applicable law, Apple has no other warranty obligation with respect to the Service. Apple is not responsible for addressing any claim by you or any third party relating to the Service or your possession or use of the Service, including:"
  },
  {
    "type": "paragraph",
    "text": "(a) product liability claims;"
  },
  {
    "type": "paragraph",
    "text": "(b) any claim that the Service fails to conform to any applicable legal or regulatory requirement; and"
  },
  {
    "type": "paragraph",
    "text": "(c) claims arising under consumer protection or similar legislation. Apple is not responsible for the investigation, defense, settlement or discharge of any third-party claim that the Service or your possession and use of the mobile application infringe that third party’s intellectual property rights. You agree to comply with any applicable third-party terms when using the Service. Apple and Apple’s subsidiaries are third party beneficiaries of these Terms, and upon your acceptance of these Terms, Apple will have the right (and will be deemed to have accepted the right) to enforce these Terms against you. You hereby represent and warrant that:"
  },
  {
    "type": "paragraph",
    "text": "(i) you are not located in a country that is subject to a U.S. Government embargo, or that has been designated by the U.S. Government as a “terrorist supporting” country; and"
  },
  {
    "type": "paragraph",
    "text": "(ii) you are not listed on any U.S. Government list of prohibited or restricted parties."
  },
  {
    "type": "heading",
    "text": "31. Miscellaneous"
  },
  {
    "type": "paragraph",
    "text": "If any provision of these Terms and Conditions is found to be invalid or unenforceable by any court of competent jurisdiction, such provision shall be deemed modified to the extent necessary to make it valid and enforceable, and the remaining provisions shall remain in full force and effect."
  },
  {
    "type": "paragraph",
    "text": "These Terms and Conditions constitute the entire agreement between us and the user with respect to the subject matter hereof and supersede all prior or contemporaneous understandings, agreements, or communications, whether written or oral, regarding such subject matter."
  }
],
};
