/** From munkai-frontend/src/app/company/faq/page.tsx. */
import { BookOpen, Coins, DollarSign, Megaphone, Star, Wallet, type LucideIcon } from 'lucide-react-native';

export type FaqItem = { id: string; icon: LucideIcon; question: string; answer: string };

export const FAQ: FaqItem[] = [
  {
    id: 'what-is-munkai',
    icon: BookOpen,
    question: 'What is Munkai?',
    answer:
      'Munkai is a social reading and publishing platform that rewards both writers and readers. Creators can publish stories, while readers earn rewards for reading and engaging with content.',
  },
  {
    id: 'earning',
    icon: DollarSign,
    question: 'How do I earn on Munkai?',
    answer:
      'Readers earn tokens by reading and interacting with content. Creators earn based on the engagement their content receives. All rewards go into a built-in wallet.',
  },
  {
    id: 'funding',
    icon: Wallet,
    question: 'How can I fund my wallet?',
    answer:
      'Currently, you can fund your wallet using Naira through supported local methods. Support for international currencies like USD, GBP, and EUR is coming soon.',
  },
  {
    id: 'withdraw',
    icon: Coins,
    question: 'How do I withdraw my earnings?',
    answer:
      'Withdrawals will be available soon. You’ll be able to cash out from your wallet directly once the feature is live. Stay tuned!',
  },
  {
    id: 'difference',
    icon: Star,
    question: 'What makes Munkai different?',
    answer:
      'Munkai rewards both readers and creators — no subscriptions or tiers needed. Readers earn by reading, creators earn by publishing. It’s simple, engaging, and built to grow organically without pressure.',
  },
  {
    id: 'promotion',
    icon: Megaphone,
    question: 'Can Munkai help promote my work?',
    answer:
      'Yes! Munkai regularly features creators, highlights top content, and includes fun tools like polls and reading challenges to help grow your reach and engage your readers.',
  },
];
