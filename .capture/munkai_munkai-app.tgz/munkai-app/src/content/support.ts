/** Company contact details — from munkai-frontend/src/app/company/contact/page.tsx. */
export const SUPPORT = {
  email: 'munkailegal@gmail.com',
  phone: '+234 813 054 7087',
  phoneDial: '+2348130547087',
  address: 'Plot 659, No 9, Kenei Street, Dawaki Offjohid, Katampe, Abuja, Nigeria',
  responseTime: 'We typically respond within 24–48 hours.',
} as const;
