/** Refund & Withdrawal Policy — from munkai-frontend/src/app/refund-policy/page.tsx. */
import { SUPPORT } from './support';
import type { LegalDoc } from './types';

export const refund: LegalDoc = {
  id: 'refund',
  title: 'Refund & Withdrawal Policy',
  badge: 'Legal',
  lead: 'Transparent and fair policies to ensure your peace of mind.',
  blocks: [
    {
      type: 'paragraph',
      emphasis: true,
      text: 'At Munkai, we value our users and want to ensure a smooth experience. If you encounter any issues with your purchase or funding, this policy outlines your options for refunds and withdrawals.',
    },
    { type: 'heading', text: 'Refunds' },
    { type: 'paragraph', text: 'Refunds may be considered in the following situations:' },
    {
      type: 'bullets',
      items: [
        'You were charged but did not receive access to your tokens.',
        'You were charged incorrectly due to a technical or processing error.',
        'The service delivered was materially different from what was advertised.',
      ],
    },
    { type: 'heading', text: 'Non-Refundable Cases' },
    { type: 'paragraph', text: 'Refunds will not be issued for:' },
    {
      type: 'bullets',
      items: [
        'Change of mind after funding your wallet.',
        'Tokens already used or spent within the platform.',
        'Discounted or promotional purchases, unless faulty or inaccessible.',
      ],
    },
    { type: 'heading', text: 'Withdrawals' },
    {
      type: 'paragraph',
      text: 'Instead of waiting for a refund, users who have funded their wallet with Munk tokens can withdraw their balance directly.',
    },
    {
      type: 'facts',
      items: [
        { label: 'Minimum amount', value: '$1.00' },
        { label: 'Processing time', value: 'Fast processing' },
      ],
    },
    {
      type: 'bullets',
      items: [
        'If you already have tokens in your balance, we recommend making a withdrawal for faster processing.',
        'Withdrawals are processed faster than refunds, which may take 7–14 business days.',
        'A 15% VAT fee applies to withdrawals for amounts below $50, and a 10% VAT fee for amounts $50 and above.',
      ],
    },
    { type: 'heading', text: 'Processing Time' },
    { type: 'subheading', text: 'Refunds' },
    {
      type: 'paragraph',
      text: 'Approved refunds will be processed within 7–14 business days, and the amount will be returned via the original payment method.',
    },
    { type: 'subheading', text: 'Withdrawals' },
    {
      type: 'paragraph',
      text: 'Approved withdrawals are processed faster, subject to our minimum withdrawal requirement of $1.',
    },
    {
      type: 'callout',
      title: 'Need assistance?',
      text: 'To request a refund or withdrawal, or for any questions, please contact our legal team.',
      email: SUPPORT.email,
      note: 'Include your full name, registered email and transaction ID.',
    },
  ],
};
