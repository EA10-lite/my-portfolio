import { Globe } from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';

import { Button, Sheet, Text } from '@/components/ui';
import { PUBLICATION_TYPES, type PublicationTypeValue } from '@/lib/publication';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

export type ExploreFilters = {
  category: 'all' | 'fiction' | 'non-fiction';
  type: 'all' | PublicationTypeValue;
  origin: 'all' | 'original' | 'fan';
  language: string;
  sort: 'desc' | 'asc';
};

export const DEFAULT_FILTERS: ExploreFilters = { category: 'all', type: 'all', origin: 'all', language: '', sort: 'desc' };

export function activeFilterCount(f: ExploreFilters) {
  return (
    (f.category !== 'all' ? 1 : 0) +
    (f.type !== 'all' ? 1 : 0) +
    (f.origin !== 'all' ? 1 : 0) +
    (f.language.trim() ? 1 : 0) +
    (f.sort !== 'desc' ? 1 : 0)
  );
}

/** Approved mock "Explore · Filters sheet" + category and type (moved here from the screen). */
export function ExploreFilterSheet({
  visible,
  onClose,
  value,
  onApply,
  countFor,
}: {
  visible: boolean;
  onClose: () => void;
  value: ExploreFilters;
  onApply: (f: ExploreFilters) => void;
  countFor: (f: ExploreFilters) => number;
}) {
  const t = useTheme();
  const [draft, setDraft] = useState(value);
  useEffect(() => {
    if (visible) setDraft(value);
  }, [visible, value]);

  const set = <K extends keyof ExploreFilters>(k: K, v: ExploreFilters[K]) => {
    haptic.select().catch(() => {});
    setDraft((d) => ({ ...d, [k]: v }));
  };
  const n = countFor(draft);

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Filters"
      titleAccessory={
        <Pressable onPress={() => setDraft(DEFAULT_FILTERS)} hitSlop={10} accessibilityRole="button">
          <Text variant="subtitle" color="primary" style={styles.reset}>
            Reset
          </Text>
        </Pressable>
      }
    >
      <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.body}>
        <Group label="Category">
          <Segments
            options={[
              { value: 'all', label: 'All' },
              { value: 'fiction', label: 'Fiction' },
              { value: 'non-fiction', label: 'Non-fiction' },
            ]}
            value={draft.category}
            onChange={(v) => set('category', v)}
          />
        </Group>
        <Group label="Type">
          <View style={styles.wrap}>
            {[{ value: 'all' as const, label: 'All types' }, ...PUBLICATION_TYPES].map((o) => (
              <Chip key={o.value} label={o.label} on={draft.type === o.value} onPress={() => set('type', o.value)} />
            ))}
          </View>
        </Group>
        <Group label="Sort by">
          <Segments
            options={[
              { value: 'desc', label: 'Newest' },
              { value: 'asc', label: 'Oldest' },
            ]}
            value={draft.sort}
            onChange={(v) => set('sort', v)}
          />
        </Group>
        <Group label="Origin">
          <Segments
            options={[
              { value: 'all', label: 'All' },
              { value: 'original', label: 'Original' },
              { value: 'fan', label: 'Translated' },
            ]}
            value={draft.origin}
            onChange={(v) => set('origin', v)}
          />
        </Group>
        <Group label="Original language">
          <View style={[styles.input, { borderColor: withAlpha(t.colors.primary, 0.18), backgroundColor: t.colors.inputBackground }]}>
            <Globe size={18} color={t.colors.mutedForeground} strokeWidth={2} />
            <TextInput
              value={draft.language}
              onChangeText={(v) => setDraft((d) => ({ ...d, language: v }))}
              placeholder="e.g. Japanese, Yoruba"
              placeholderTextColor={t.colors.mutedForeground}
              selectionColor={t.colors.primary}
              autoCorrect={false}
              style={[styles.inputText, { color: t.colors.foreground, fontFamily: t.fonts.body }]}
              accessibilityLabel="Original language"
            />
          </View>
        </Group>
        <Button
          title={n === 0 ? 'No results' : `Show ${n} ${n === 1 ? 'result' : 'results'}`}
          disabled={n === 0}
          onPress={() => {
            onApply(draft);
            onClose();
          }}
          style={styles.apply}
        />
      </ScrollView>
    </Sheet>
  );
}

function Group({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={styles.group}>
      <Text variant="label">{label}</Text>
      {children}
    </View>
  );
}

function Segments<V extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: V; label: string }[];
  value: V;
  onChange: (v: V) => void;
}) {
  return (
    <View style={styles.segments} accessibilityRole="radiogroup">
      {options.map((o) => (
        <Chip key={o.value} label={o.label} on={o.value === value} onPress={() => onChange(o.value)} flex />
      ))}
    </View>
  );
}

function Chip({ label, on, onPress, flex }: { label: string; on: boolean; onPress: () => void; flex?: boolean }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ selected: on }}
      style={[
        styles.chip,
        flex && styles.flex,
        on ? { backgroundColor: t.colors.primary } : { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
      ]}
    >
      <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} numberOfLines={1} style={styles.chipText}>
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  reset: { fontSize: 14 },
  body: { gap: 18, paddingBottom: 8 },
  group: { gap: 8 },
  segments: { flexDirection: 'row', gap: 8 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { height: 40, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center' },
  chipText: { fontSize: 13, lineHeight: 18 },
  input: { height: 48, paddingHorizontal: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  inputText: { flex: 1, height: '100%', fontSize: 15 },
  apply: { marginTop: 4 },
});
