import React, { useId, useState } from 'react';
import { Image, StyleSheet, useWindowDimensions, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { useTheme } from '@/theme';

/** The web's default banner (munkai-frontend public/images/beach.jpeg), resized for phones. */
const DEFAULT_BANNER = require('../../../assets/images/banner-default.jpg');

/**
 * Banner: the user's banner image, or the web's default (beach.jpeg) when none is set or it fails to load.
 * Like the web (from-black/20 … to-background/90), it darkens slightly at the top and fades into the page
 * colour at the bottom so the avatar overlaps cleanly.
 */
export function ProfileBanner({ uri, height = 200 }: { uri?: string | null; height?: number }) {
  const t = useTheme();
  const { width } = useWindowDimensions();
  const [failed, setFailed] = useState(false);
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const custom = !!uri && !failed;

  return (
    <View style={{ height, width, overflow: 'hidden' }}>
      <Image
        source={custom ? { uri: uri! } : DEFAULT_BANNER}
        style={[styles.image, { width, height }]}
        resizeMode="cover"
        onError={() => setFailed(true)}
      />
      <Svg width={width} height={height} style={styles.overlay}>
        <Defs>
          <LinearGradient id={`bnFade${uid}`} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0" stopColor="#000000" stopOpacity={0.2} />
            <Stop offset="0.45" stopColor="#000000" stopOpacity={0} />
            <Stop offset="1" stopColor={t.colors.pageBackground} stopOpacity={0.9} />
          </LinearGradient>
        </Defs>
        <Rect width={width} height={height} fill={`url(#bnFade${uid})`} />
      </Svg>
    </View>
  );
}

const styles = StyleSheet.create({
  image: { position: 'absolute', top: 0, left: 0 },
  overlay: { position: 'absolute', left: 0, top: 0 },
});
