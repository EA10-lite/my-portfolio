import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, useWindowDimensions, View } from 'react-native';

import { Avatar, Button, Sheet, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { roleLabel } from '@/lib/format';
import { profileApi } from '@/services/profile';
import type { User } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, withAlpha } from '@/theme';
import { haptic, ImpactStyle } from '@/lib/haptics';

type Mode = 'following' | 'followers';

/**
 * Approved mock "Following sheet". Readers see who they follow (with Following/Follow
 * toggle); creators can also open it in "followers" mode from the Followers stat.
 */
export function PeopleSheet({ visible, onClose, mode }: { visible: boolean; onClose: () => void; mode: Mode }) {
  const t = useTheme();
  const toast = useToast();
  const { height } = useWindowDimensions();
  const refreshProfile = useSession((s) => s.refreshProfile);

  const [people, setPeople] = useState<User[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  /** username → currently following? (only tracked in "following" mode) */
  const [following, setFollowing] = useState<Record<string, boolean>>({});
  const [pending, setPending] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    setPeople(null);
    try {
      const list = mode === 'following' ? await profileApi.following() : await profileApi.followers();
      setPeople(list);
      if (mode === 'following') setFollowing(Object.fromEntries(list.map((u) => [u.username, true])));
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load this list.'));
    }
  }, [mode]);

  useEffect(() => {
    if (visible) load();
  }, [visible, load]);

  const toggle = async (username: string) => {
    const isFollowing = following[username];
    setPending(username);
    haptic.impact(ImpactStyle.Light).catch(() => {});
    try {
      if (isFollowing) await profileApi.unfollow(username);
      else await profileApi.follow(username);
      setFollowing((f) => ({ ...f, [username]: !isFollowing }));
      refreshProfile();
    } catch (err) {
      toast.error(isFollowing ? 'Unfollow failed' : 'Follow failed', apiErrorMessage(err));
    } finally {
      setPending(null);
    }
  };

  const title = mode === 'following' ? 'Following' : 'Followers';
  const count = people?.length;

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title={title}
      height={Math.min(560, height * 0.72)}
      titleAccessory={
        count !== undefined ? (
          <View style={[styles.pill, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}>
            <Text variant="subtitle" color="primary" style={styles.pillText}>
              {count}
            </Text>
          </View>
        ) : null
      }
      contentStyle={styles.content}
    >
      {error ? (
        <View style={styles.state}>
          <Text variant="body" color="mutedForeground" align="center">
            {error}
          </Text>
          <Button title="Try again" variant="outline" onPress={load} />
        </View>
      ) : people === null ? (
        <View style={styles.state}>
          <ActivityIndicator color={t.colors.primary} />
        </View>
      ) : people.length === 0 ? (
        <View style={styles.state}>
          <Text variant="heading" align="center">
            {mode === 'following' ? 'No creators yet' : 'No followers yet'}
          </Text>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            {mode === 'following'
              ? 'Follow creators from their pages to see them here.'
              : 'Share your work — readers who follow you appear here.'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={people}
          keyExtractor={(u) => String(u.id ?? u.username)}
          ItemSeparatorComponent={() => <View style={[styles.sep, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]} />}
          renderItem={({ item }) => {
            const role = roleLabel(item);
            const isOn = following[item.username];
            return (
              <View style={styles.row}>
                {/* Row body opens the creator page; the follow button is a separate target. */}
                <Pressable
                  onPress={() => toast.info('Coming soon', 'Creator pages are on their way to the app.')}
                  accessibilityRole="button"
                  accessibilityLabel={`${item.firstName} ${item.lastName}, @${item.username}`}
                  style={({ pressed }) => [styles.rowMain, pressed && { opacity: 0.7 }]}
                >
                  <Avatar uri={item.profileImage} firstName={item.firstName} lastName={item.lastName} seed={item.username} size={44} />
                  <View style={styles.flex}>
                    <View style={styles.nameRow}>
                      <Text variant="subtitle" numberOfLines={1} style={styles.shrink}>
                        {item.firstName} {item.lastName}
                      </Text>
                      {role !== 'Reader' ? (
                        <View style={[styles.tag, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}>
                          <Text variant="caption" color="primary" style={styles.tagText}>
                            {role}
                          </Text>
                        </View>
                      ) : null}
                    </View>
                    <Text variant="bodySmall" color="primary" style={styles.handle}>
                      @{item.username}
                    </Text>
                  </View>
                </Pressable>
                {mode === 'following' ? (
                  <Button
                    title={isOn ? 'Following' : 'Follow'}
                    size="sm"
                    variant={isOn ? 'outline' : 'primary'}
                    loading={pending === item.username}
                    onPress={() => toggle(item.username)}
                    style={styles.followBtn}
                  />
                ) : null}
              </View>
            );
          }}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </Sheet>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  shrink: { flexShrink: 1 },
  content: { paddingHorizontal: 0 },
  pill: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999 },
  pillText: { fontSize: 13, lineHeight: 18 },
  state: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 32 },
  list: { paddingHorizontal: 20, paddingBottom: 12 },
  sep: { height: 1 },
  row: { minHeight: 68, flexDirection: 'row', alignItems: 'center', gap: 12 },
  rowMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 68 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  tag: { paddingHorizontal: 5, paddingVertical: 2 },
  tagText: { fontSize: 9 },
  handle: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 12, lineHeight: 16 },
  followBtn: { width: 108 },
});
