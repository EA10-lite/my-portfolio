/**
 * Profile → Library: Collections / Saved, filtered by type, as a 3-column cover grid.
 * Web: the shelf at the bottom of components/profiles/{userProfile,creatorProfile}.tsx
 * (Collections / Archived + type tabs). Data: the profile (collectedPublications | collectedChapters,
 * savedPublications) plus on-device reading history for "Pick up where you left off".
 */
import { router } from 'expo-router';
import { BookOpen, Library as LibraryIcon } from 'lucide-react-native';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native';

import { PublicationCard, PublicationCardSkeleton } from '@/components/content/cards';
import { Cover } from '@/components/content/Cover';
import { Button, CutShape, Text } from '@/components/ui';
import { PUBLICATION_TYPES, openChapter, openPublication, typeLabel } from '@/lib/publication';
import { useReadingHistory } from '@/lib/readingHistory';
import type { CollectedChapter, Publication, User } from '@/services/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

type Tab = 'collections' | 'saved';
type Group = {
  key: string;
  publicationId?: string | number;
  name: string;
  type: string;
  cover?: string | null;
  chapters: number[];
};

/** origin/main profile: collectedPublications (one row each). */
function fromPublications(pubs: Publication[]): Group[] {
  return pubs.map((p) => ({
    key: String(p.id),
    publicationId: p.id,
    name: p.name,
    type: (p.publicationType ?? '').toLowerCase(),
    cover: p.coverPhoto,
    chapters: [],
  }));
}

/** Collected chapters → one entry per publication (the web reads nested or flat fields). */
function groupCollected(items: CollectedChapter[]): Group[] {
  const map = new Map<string, Group>();
  for (const item of items) {
    const pub = item.chapters?.publications ?? item.publications;
    const name = pub?.name ?? item.publicationName ?? 'Untitled';
    const pubId = pub?.id ?? item.chapters?.publicationId ?? item.publicationId;
    const key = String(pubId ?? name);
    const num = item.chapters?.chapterNumber ?? item.chapterNumber;
    const g =
      map.get(key) ??
      ({
        key,
        publicationId: pubId,
        name,
        type: (pub?.publicationType ?? item.publicationType ?? '').toLowerCase(),
        cover: pub?.coverPhoto ?? item.coverPhoto,
        chapters: [],
      } as Group);
    if (typeof num === 'number') g.chapters.push(num);
    map.set(key, g);
  }
  return [...map.values()].map((g) => ({ ...g, chapters: g.chapters.sort((a, b) => a - b) }));
}

function chapterRange(nums: number[]) {
  if (nums.length === 0) return '';
  if (nums.length === 1) return `Ch. ${nums[0]}`;
  return `Ch. ${nums[0]}–${nums[nums.length - 1]}`;
}

export function ProfileLibrary({ user, loading }: { user: User; loading: boolean }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const { width } = useWindowDimensions();
  const history = useReadingHistory();
  const [tab, setTab] = useState<Tab>('collections');
  const [type, setType] = useState('all');

  const collected = useMemo(
    () => (user.collectedPublications ? fromPublications(user.collectedPublications) : groupCollected(user.collectedChapters ?? [])),
    [user.collectedPublications, user.collectedChapters],
  );
  const saved = useMemo(() => user.savedPublications ?? [], [user.savedPublications]);

  const typesPresent = useMemo(() => {
    const src = tab === 'collections' ? collected.map((g) => g.type) : saved.map((p) => (p.publicationType ?? '').toLowerCase());
    return PUBLICATION_TYPES.filter((pt) => src.includes(pt.value));
  }, [tab, collected, saved]);
  const activeType = type !== 'all' && typesPresent.some((p) => p.value === type) ? type : 'all';
  const collectedShown = activeType === 'all' ? collected : collected.filter((g) => g.type === activeType);
  const savedShown = activeType === 'all' ? saved : saved.filter((p) => (p.publicationType ?? '').toLowerCase() === activeType);

  const collectedCount = user.collectedPublicationsCount ?? user.collectedPublications?.length ?? collected.length;
  const savedCount = user.savedPublicationsCount ?? saved.length;

  const cols = 3;
  const cardW = Math.floor((width - 40 - 12 * (cols - 1)) / cols);
  const cardH = Math.round(cardW * 1.45);
  const resume = history[0];
  const shown = tab === 'collections' ? collectedShown.length : savedShown.length;

  return (
    <View style={styles.wrap}>
      <Text variant="caption" color="primary" style={styles.sectionTitle}>
        Your Library
      </Text>

      <View style={[styles.segment, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]} accessibilityRole="tablist">
        {(
          [
            ['collections', 'Collections', collectedCount],
            ['saved', 'Saved', savedCount],
          ] as const
        ).map(([key, label, n]) => {
          const on = tab === key;
          return (
            <Pressable
              key={key}
              onPress={() => {
                setTab(key);
                setType('all');
              }}
              accessibilityRole="tab"
              accessibilityState={{ selected: on }}
              style={[styles.segItem, on && { backgroundColor: t.colors.primary }]}
            >
              <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.segText}>
                {label}
              </Text>
              <Text variant="bodySmall" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.segCount}>
                {n}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {typesPresent.length > 1 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipsScroll} contentContainerStyle={styles.chips}>
          {[{ value: 'all', label: 'All' }, ...typesPresent].map((o) => {
            const on = activeType === o.value;
            return (
              <Pressable
                key={o.value}
                onPress={() => setType(o.value)}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                style={[
                  styles.chip,
                  on ? { backgroundColor: t.colors.primary } : { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
                ]}
              >
                <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.chipText}>
                  {o.label}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      ) : null}

      {tab === 'collections' && resume ? (
        <Pressable
          onPress={() => openChapter({ id: resume.chapterId, publicationId: resume.publicationId })}
          accessibilityRole="button"
          accessibilityLabel={`Continue ${resume.publicationName}, chapter ${resume.chapterNumber}`}
        >
          <CutShape
            cuts={t.cuts.card}
            fill={withAlpha(t.colors.primary, 0.07)}
            stroke={withAlpha(t.colors.primary, 0.16)}
            style={styles.resume}
          >
            <Cover uri={resume.coverPhoto} width={64} height={88} />
            <View style={styles.flex}>
              <Text variant="caption" color="primary">
                Pick up where you left off
              </Text>
              <Text variant="subtitle" numberOfLines={1} style={styles.resumeTitle}>
                {resume.publicationName}
              </Text>
              <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.meta}>
                Chapter {resume.chapterNumber}
                {resume.chapterName ? ` · ${resume.chapterName}` : ''}
              </Text>
              <View style={styles.progressRow}>
                <View style={[styles.track, { backgroundColor: withAlpha(t.colors.primary, 0.15) }]}>
                  <View style={[styles.fill, { width: `${Math.round(resume.progress * 100)}%`, backgroundColor: t.colors.primary }]} />
                </View>
                <Text variant="subtitle" color="primary" style={styles.pct}>
                  {Math.round(resume.progress * 100)}%
                </Text>
              </View>
            </View>
          </CutShape>
        </Pressable>
      ) : null}

      {loading ? (
        <View style={styles.grid}>
          {Array.from({ length: 6 }, (_, i) => (
            <PublicationCardSkeleton key={i} width={cardW} />
          ))}
        </View>
      ) : shown === 0 ? (
        <View style={styles.empty}>
          <View style={[styles.emptyIcon, { borderColor: withAlpha(t.colors.primary, 0.3) }]}>
            {tab === 'collections' ? <LibraryIcon size={22} color={t.colors.primary} /> : <BookOpen size={22} color={t.colors.primary} />}
          </View>
          <Text variant="heading" align="center">
            Nothing here yet
          </Text>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            {tab === 'collections' ? 'Chapters you collect show up here.' : 'Save publications to read them later.'}
          </Text>
          <Button title="Explore" variant="outline" onPress={() => router.navigate('/explore')} />
        </View>
      ) : tab === 'collections' ? (
        <View style={styles.grid}>
          {collectedShown.map((g) => (
            <Pressable
              key={g.key}
              onPress={() => g.publicationId !== undefined && openPublication({ id: g.publicationId, name: g.name })}
              accessibilityRole="button"
              accessibilityLabel={g.chapters.length ? `${g.name}, ${g.chapters.length} chapters collected` : g.name}
              style={({ pressed }) => [{ width: cardW }, pressed && { opacity: 0.75 }]}
            >
              <Cover uri={g.cover} width={cardW} height={cardH} />
              <Text variant="subtitle" numberOfLines={1} style={styles.cardTitle}>
                {g.name}
              </Text>
              <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.meta}>
                {[typeLabel(g.type), chapterRange(g.chapters)].filter(Boolean).join(' · ')}
              </Text>
            </Pressable>
          ))}
        </View>
      ) : (
        <View style={styles.grid}>
          {savedShown.map((p: Publication) => (
            <PublicationCard key={String(p.id)} pub={p} width={cardW} saved />
          ))}
        </View>
      )}
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    flex: { flex: 1 },
    wrap: { paddingHorizontal: 20, paddingTop: 16, gap: 12 },
    sectionTitle: { letterSpacing: 1.6, fontSize: 11, marginTop: 10 },
    segment: { height: 40, padding: 3, borderRadius: 20, flexDirection: 'row' },
    segItem: { flex: 1, borderRadius: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
    segText: { fontSize: 13, lineHeight: 18 },
    segCount: { fontSize: 11, lineHeight: 14, opacity: 0.85 },
    chipsScroll: { marginHorizontal: -20 },
    chips: { paddingHorizontal: 20, gap: 8 },
    chip: { height: 34, paddingHorizontal: 14, justifyContent: 'center' },
    chipText: { fontSize: 13, lineHeight: 18 },
    resume: { padding: 12, flexDirection: 'row', gap: 12 },
    resumeTitle: { fontSize: 16, marginTop: 2 },
    meta: { fontSize: 12, lineHeight: 16, marginTop: 2 },
    progressRow: { marginTop: 'auto', flexDirection: 'row', alignItems: 'center', gap: 8 },
    track: { flex: 1, height: 4, borderRadius: 2, overflow: 'hidden' },
    fill: { height: 4, borderRadius: 2 },
    pct: { fontSize: 11, lineHeight: 14 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', columnGap: 12, rowGap: 18, paddingTop: 4 },
    cardTitle: { fontSize: 13, lineHeight: 18, marginTop: 8 },
    empty: { alignItems: 'center', gap: 10, paddingHorizontal: 12, paddingVertical: 24 },
    emptyIcon: {
      width: 52,
      height: 52,
      borderRadius: 26,
      borderWidth: 2,
      borderStyle: 'dashed',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });
