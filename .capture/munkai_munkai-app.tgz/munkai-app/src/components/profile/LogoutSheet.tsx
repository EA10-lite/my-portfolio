import { LogOut } from 'lucide-react-native';
import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { Button, Sheet, Text } from '@/components/ui';
import { useTheme, withAlpha } from '@/theme';

/** Approved mock "Log out confirmation". */
export function LogoutSheet({
  visible,
  onClose,
  onConfirm,
}: {
  visible: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void>;
}) {
  const t = useTheme();
  const [busy, setBusy] = useState(false);

  return (
    <Sheet visible={visible} onClose={onClose} accessibilityLabel="Log out" contentStyle={styles.content}>
      <View style={[styles.icon, { backgroundColor: withAlpha(t.colors.danger, 0.12) }]}>
        <LogOut size={26} color={t.colors.danger} strokeWidth={2} />
      </View>
      <Text variant="heading" align="center" style={styles.title}>
        Log out of Munkai?
      </Text>
      <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.body}>
        You&apos;ll need to log in again to read your collected chapters and use your wallet.
      </Text>
      <View style={styles.actions}>
        <Button
          title="Log out"
          variant="destructive"
          fullWidth
          loading={busy}
          onPress={async () => {
            setBusy(true);
            try {
              await onConfirm();
            } finally {
              setBusy(false);
            }
          }}
        />
        <Button title="Cancel" variant="ghost" fullWidth onPress={onClose} />
      </View>
    </Sheet>
  );
}

const styles = StyleSheet.create({
  content: { alignItems: 'center', gap: 12 },
  icon: { width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', marginTop: 6 },
  title: { fontSize: 22, lineHeight: 28 },
  body: { fontSize: 14, lineHeight: 20 },
  actions: { alignSelf: 'stretch', gap: 6, marginTop: 8 },
});
