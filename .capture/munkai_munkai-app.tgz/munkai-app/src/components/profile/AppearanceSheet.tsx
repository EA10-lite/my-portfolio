import { Moon, Smartphone, Sun, type LucideIcon } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Sheet, Text } from '@/components/ui';
import { useTheme, useThemePreference, withAlpha, type ThemePreference } from '@/theme';
import { haptic } from '@/lib/haptics';

const OPTIONS: { value: ThemePreference; label: string; icon: LucideIcon }[] = [
  { value: 'light', label: 'Light', icon: Sun },
  { value: 'dark', label: 'Dark', icon: Moon },
  { value: 'system', label: 'System', icon: Smartphone },
];

/** Approved mock "Appearance sheet (Dark = default)". */
export function AppearanceSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const t = useTheme();
  const { preference, setPreference } = useThemePreference();

  return (
    <Sheet visible={visible} onClose={onClose} title="Appearance">
      <View style={styles.grid}>
        {OPTIONS.map(({ value, label, icon: Icon }) => {
          const selected = preference === value;
          return (
            <Pressable
              key={value}
              onPress={() => {
                haptic.select().catch(() => {});
                setPreference(value);
              }}
              accessibilityRole="radio"
              accessibilityState={{ selected }}
              accessibilityLabel={label}
              style={[
                styles.option,
                {
                  borderColor: selected ? t.colors.primary : withAlpha(t.colors.primary, 0.15),
                  borderWidth: selected ? 2 : 1,
                  backgroundColor: selected ? withAlpha(t.colors.primary, 0.1) : 'transparent',
                },
              ]}
            >
              <Preview kind={value} />
              <View style={styles.optionLabel}>
                <Icon size={16} color={selected ? t.colors.primary : t.colors.foreground} strokeWidth={2} />
                <Text variant="subtitle" color={selected ? 'primary' : 'foreground'} style={styles.labelText}>
                  {label}
                </Text>
              </View>
            </Pressable>
          );
        })}
      </View>
      <Text variant="bodySmall" color="mutedForeground" style={styles.note}>
        Dark is the default. System follows your phone&apos;s light or dark setting.
      </Text>
    </Sheet>
  );
}

function Preview({ kind }: { kind: ThemePreference }) {
  if (kind === 'system') {
    return (
      <View style={[styles.preview, styles.split]}>
        <View style={[styles.flex, { backgroundColor: '#DAEAF7' }]} />
        <View style={[styles.flex, { backgroundColor: '#00002B' }]} />
      </View>
    );
  }
  const light = kind === 'light';
  return (
    <View style={[styles.preview, { backgroundColor: light ? '#DAEAF7' : '#00002B' }]}>
      <View style={[styles.line, { width: '70%', height: 6, backgroundColor: light ? '#006097' : '#87CEEB' }]} />
      <View style={[styles.line, { width: '90%', backgroundColor: light ? '#9FB4C6' : '#3A3F5C' }]} />
      <View style={[styles.line, { width: '60%', backgroundColor: light ? '#9FB4C6' : '#3A3F5C' }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  grid: { flexDirection: 'row', gap: 10 },
  option: { flex: 1, alignItems: 'center', gap: 10, paddingVertical: 12, paddingHorizontal: 8 },
  optionLabel: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  labelText: { fontSize: 14 },
  preview: {
    width: 64,
    height: 96,
    borderRadius: 10,
    padding: 8,
    gap: 5,
    borderWidth: 1,
    borderColor: 'rgba(128,128,128,0.25)',
    overflow: 'hidden',
  },
  split: { flexDirection: 'row', padding: 0, gap: 0 },
  line: { height: 4 },
  note: { marginTop: 14 },
});
