import { Search, X } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, TextInput, View, type StyleProp, type TextInputProps, type ViewStyle } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

/**
 * In-page search input (Chapters, Top creators, "See all" lists): magnifier, text, clear ✕.
 * Rectangular with the shared `radius.search` corners — never a pill.
 */
export function SearchField({
  value,
  onChangeText,
  placeholder = 'Search',
  style,
  ...rest
}: { value: string; onChangeText: (v: string) => void; placeholder?: string; style?: StyleProp<ViewStyle> } & Omit<
  TextInputProps,
  'value' | 'onChangeText' | 'placeholder' | 'style'
>) {
  const t = useTheme();
  return (
    <View
      style={[
        styles.field,
        { borderRadius: t.radius.search, backgroundColor: t.colors.inputBackground, borderColor: withAlpha(t.colors.primary, 0.18) },
        style,
      ]}
    >
      <Search size={18} color={t.colors.mutedForeground} style={styles.icon} />
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={t.colors.mutedForeground}
        selectionColor={t.colors.primary}
        autoCorrect={false}
        autoCapitalize="none"
        returnKeyType="search"
        clearButtonMode="never"
        accessibilityLabel={placeholder}
        style={[styles.input, { color: t.colors.foreground, fontFamily: t.fonts.body }]}
        {...rest}
      />
      {value ? (
        <Pressable onPress={() => onChangeText('')} hitSlop={10} accessibilityRole="button" accessibilityLabel="Clear search">
          <X size={16} color={t.colors.mutedForeground} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  field: { height: 44, borderWidth: 1, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  icon: { flexShrink: 0 },
  input: { flex: 1, minWidth: 0, height: '100%', fontSize: 15, paddingVertical: 0 },
});
