import React, { forwardRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View, type StyleProp, type TextInputProps, type ViewStyle } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

import { Text } from './Text';

export type InputProps = TextInputProps & {
  label?: string;
  required?: boolean;
  error?: string;
  hint?: string;
  leftIcon?: React.ReactNode;
  /** Element on the right inside the field (e.g. eye toggle). */
  rightAccessory?: React.ReactNode;
  containerStyle?: StyleProp<ViewStyle>;
};

/**
 * Mirrors the web auth inputs: 48px tall, square corners, secondary fill (card in dark),
 * 1px input border that turns primary on focus, soft primary shadow, uppercase label in primary.
 */
export const Input = forwardRef<TextInput, InputProps>(function Input(
  { label, required, error, hint, leftIcon, rightAccessory, containerStyle, style, onFocus, onBlur, ...rest },
  ref,
) {
  const t = useTheme();
  const [focused, setFocused] = useState(false);

  const borderColor = error ? t.colors.destructive : focused ? t.colors.ring : t.colors.input;

  return (
    <View style={[styles.container, containerStyle]}>
      {label ? (
        <Text variant="label" style={styles.label}>
          {label}
          {required ? <Text variant="label" color="danger"> *</Text> : null}
        </Text>
      ) : null}

      <View
        style={[
          styles.field,
          {
            height: rest.multiline ? undefined : t.sizes.inputHeight,
            minHeight: rest.multiline ? 132 : undefined,
            alignItems: rest.multiline ? 'flex-start' : 'center',
            backgroundColor: t.colors.inputBackground,
            borderColor,
            shadowColor: t.colors.primary,
          },
          focused && { shadowOpacity: 0.35 },
        ]}
      >
        {leftIcon ? <View style={styles.left}>{leftIcon}</View> : null}
        <TextInput
          ref={ref}
          placeholderTextColor={t.colors.mutedForeground}
          selectionColor={t.colors.primary}
          style={[
            styles.input,
            { color: t.colors.foreground, fontFamily: t.fonts.body },
            !leftIcon && { paddingLeft: t.spacing.lg },
            rest.multiline && styles.multiline,
            style,
          ]}
          onFocus={(e) => {
            setFocused(true);
            onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            onBlur?.(e);
          }}
          {...rest}
        />
        {rightAccessory ? <View style={styles.right}>{rightAccessory}</View> : null}
      </View>

      {error ? (
        <Text variant="bodySmall" color="destructive" style={styles.message}>
          {error}
        </Text>
      ) : hint ? (
        <Text variant="caption" style={styles.message}>
          {hint}
        </Text>
      ) : null}
    </View>
  );
});

/** Pressable wrapper for icons placed in `rightAccessory` (eye toggle etc.). */
export function InputAccessoryButton({ onPress, children, label }: { onPress: () => void; children: React.ReactNode; label: string }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={8}
      style={({ pressed }) => [styles.accessory, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.1) }]}
    >
      {children}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { gap: 8 },
  label: {},
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 0,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
    elevation: 1,
  },
  left: { paddingLeft: 12, paddingRight: 8 },
  right: { paddingRight: 8 },
  input: { flex: 1, height: '100%', fontSize: 16, paddingRight: 12 },
  multiline: { height: undefined, minHeight: 132, paddingTop: 14, paddingBottom: 14, textAlignVertical: 'top' },
  message: { marginTop: -2 },
  accessory: { padding: 6, borderRadius: 4 },
});
