import { ArrowDownWideNarrow } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet } from 'react-native';

import { haptic } from '@/lib/haptics';
import { useTheme, withAlpha } from '@/theme';

import { Text } from './Text';

/** Two-way sort button that sits beside a SearchField (Top creators, creator pages). */
export function SortToggle<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: [{ value: T; label: string }, { value: T; label: string }];
  onChange: (v: T) => void;
}) {
  const t = useTheme();
  const current = options.find((o) => o.value === value) ?? options[0];
  const next = options.find((o) => o.value !== value) ?? options[1];
  return (
    <Pressable
      onPress={() => {
        haptic.select().catch(() => {});
        onChange(next.value);
      }}
      accessibilityRole="button"
      accessibilityLabel={`Sorted by ${current.label}. Tap to sort by ${next.label}`}
      style={({ pressed }) => [
        styles.btn,
        { borderRadius: t.radius.search, backgroundColor: withAlpha(t.colors.primary, pressed ? 0.16 : 0.08) },
      ]}
    >
      <ArrowDownWideNarrow size={16} color={t.colors.foreground} />
      <Text variant="subtitle" style={styles.text}>
        {current.label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: { height: 44, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 6 },
  text: { fontSize: 13, lineHeight: 18 },
});
