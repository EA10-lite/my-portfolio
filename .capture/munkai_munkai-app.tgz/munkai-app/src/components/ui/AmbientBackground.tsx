/**
 * The web's moving background (munkai-frontend components/ui/particle-background.tsx + .gloss-overlay):
 *  - a thin diagonal streak of light that sweeps across the screen every 20 s, forever;
 *  - 30 small glowing stars that drift slowly and pulse brighter / dimmer.
 * The web also draws faint lines between nearby stars; those are left out — they'd need per-frame JS
 * drawing, and this has to stay light.
 *
 * Performance: every animation is an Animated loop on the native driver (transform / opacity only), so
 * nothing runs on the JS thread per frame. No shadows (the glow is a static soft halo). Reduce Motion →
 * still stars, no streak.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AccessibilityInfo, Animated, Easing, StyleSheet, useWindowDimensions, View } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { useTheme } from '@/theme';

const STAR_COUNT = 30; // web: 30 below 768px wide
const DARK_COLORS = ['rgb(4,255,255)', 'rgb(188,19,254)', 'rgb(255,20,147)'];
const LIGHT_COLORS = ['rgb(100,149,237)', 'rgb(0,191,255)', 'rgb(70,130,180)'];
const SWEEP_MS = 20000;

type Star = { x: number; y: number; dx: number; dy: number; size: number; color: number; drift: number; pulse: number; delay: number };

function makeStars(w: number, h: number): Star[] {
  return Array.from({ length: STAR_COUNT }, () => {
    const angle = Math.random() * Math.PI * 2;
    const dist = 30 + Math.random() * 70; // how far it wanders before turning back
    return {
      x: Math.random() * w,
      y: Math.random() * h,
      dx: Math.cos(angle) * dist,
      dy: Math.sin(angle) * dist,
      size: Math.random() * 2 + 1, // web: 1–3 px
      color: Math.floor(Math.random() * 3),
      drift: (dist / 15) * 1000, // ~15 px/s, the web's average speed
      pulse: 1800 + Math.random() * 1600,
      delay: Math.random() * 2000,
    };
  });
}

export function AmbientBackground() {
  const t = useTheme();
  const { width, height } = useWindowDimensions();
  const [still, setStill] = useState(false);
  const stars = useMemo(() => makeStars(width, height), [width, height]);
  const colors = t.isDark ? DARK_COLORS : LIGHT_COLORS;

  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled()
      .then(setStill)
      .catch(() => {});
    const sub = AccessibilityInfo.addEventListener('reduceMotionChanged', setStill);
    return () => sub.remove();
  }, []);

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      {stars.map((s, i) => (
        <StarDot key={i} star={s} color={colors[s.color]} glow={t.isDark} still={still} />
      ))}
      {still ? null : <Sweep width={width} height={height} />}
    </View>
  );
}

function StarDot({ star: s, color, glow, still }: { star: Star; color: string; glow: boolean; still: boolean }) {
  const move = useRef(new Animated.Value(0)).current;
  const fade = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (still) return;
    const drift = Animated.loop(
      Animated.sequence([
        Animated.timing(move, { toValue: 1, duration: s.drift, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(move, { toValue: 0, duration: s.drift, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]),
    );
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.delay(s.delay),
        Animated.timing(fade, { toValue: 1, duration: s.pulse, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(fade, { toValue: 0, duration: s.pulse, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ]),
    );
    drift.start();
    pulse.start();
    return () => {
      drift.stop();
      pulse.stop();
    };
  }, [still, move, fade, s.drift, s.pulse, s.delay]);

  const halo = s.size * 5;
  return (
    <Animated.View
      style={{
        position: 'absolute',
        left: s.x - halo / 2,
        top: s.y - halo / 2,
        width: halo,
        height: halo,
        alignItems: 'center',
        justifyContent: 'center',
        opacity: still ? 0.5 : fade.interpolate({ inputRange: [0, 1], outputRange: [0.2, 0.8] }),
        transform: [
          { translateX: move.interpolate({ inputRange: [0, 1], outputRange: [0, s.dx] }) },
          { translateY: move.interpolate({ inputRange: [0, 1], outputRange: [0, s.dy] }) },
        ],
      }}
    >
      {glow ? (
        <View style={{ position: 'absolute', width: halo, height: halo, borderRadius: halo / 2, backgroundColor: color, opacity: 0.18 }} />
      ) : null}
      <View style={{ width: s.size * 2, height: s.size * 2, borderRadius: s.size, backgroundColor: color }} />
    </Animated.View>
  );
}

/** web .gloss-overlay: a 110° band of light blue, 200% wide, sweeping right → left over 20 s. */
function Sweep({ width, height }: { width: number; height: number }) {
  const x = useRef(new Animated.Value(0)).current;
  const bandW = width * 1.2;

  useEffect(() => {
    const loop = Animated.loop(Animated.timing(x, { toValue: 1, duration: SWEEP_MS, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [x]);

  return (
    <Animated.View
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: bandW,
        height,
        transform: [{ translateX: x.interpolate({ inputRange: [0, 1], outputRange: [width * 1.1, -bandW - width * 0.1] }) }],
      }}
    >
      <Svg width={bandW} height={height}>
        <Defs>
          {/* CSS 110°: the gradient runs right and 20° downward, so the band itself leans like the web's. */}
          <LinearGradient
            id="sweep"
            gradientUnits="userSpaceOnUse"
            x1={bandW / 2 - 0.47 * bandW}
            y1={height / 2 - 0.17 * bandW}
            x2={bandW / 2 + 0.47 * bandW}
            y2={height / 2 + 0.17 * bandW}
          >
            <Stop offset="0" stopColor="#87CEEB" stopOpacity="0" />
            <Stop offset="0.42" stopColor="#FFFFFF" stopOpacity="0.03" />
            <Stop offset="0.5" stopColor="#87CEEB" stopOpacity="0.2" />
            <Stop offset="0.58" stopColor="#FFFFFF" stopOpacity="0.03" />
            <Stop offset="1" stopColor="#87CEEB" stopOpacity="0" />
          </LinearGradient>
        </Defs>
        <Rect width={bandW} height={height} fill="url(#sweep)" />
      </Svg>
    </Animated.View>
  );
}
