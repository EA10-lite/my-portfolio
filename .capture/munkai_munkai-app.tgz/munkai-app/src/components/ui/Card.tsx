import React from 'react';
import { View, type StyleProp, type ViewStyle } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

import { CutShape } from './CutShape';

type CardProps = {
  children?: React.ReactNode;
  /**
   * - `gamified` (default): 8px cuts top-left + bottom-right, faint primary border (web `.clip-path-gamified`)
   * - `rounded`: 16px radius glassy card used by the auth forms (web `rounded-2xl bg-card/10 border-primary/10`)
   */
  shape?: 'gamified' | 'rounded';
  padding?: number;
  style?: StyleProp<ViewStyle>;
};

export function Card({ children, shape = 'gamified', padding, style }: CardProps) {
  const t = useTheme();
  const pad = padding ?? t.spacing.xl;
  const border = withAlpha(t.colors.primary, 0.12);

  if (shape === 'rounded') {
    return (
      <View
        style={[
          {
            padding: pad,
            borderRadius: t.radius.xl,
            borderWidth: 1,
            borderColor: border,
            backgroundColor: withAlpha(t.isDark ? t.colors.card : t.colors.background, t.isDark ? 0.6 : 0.7),
          },
          style,
        ]}
      >
        {children}
      </View>
    );
  }

  return (
    <CutShape
      cuts={t.cuts.card}
      fill={withAlpha(t.colors.primary, t.isDark ? 0.06 : 0.04)}
      stroke={border}
      style={[{ padding: pad }, style]}
    >
      {children}
    </CutShape>
  );
}
