import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Animated,
  Pressable,
  StyleSheet,
  View,
  type PressableProps,
  type StyleProp,
  type ViewStyle,
} from 'react-native';

import { useTheme } from '@/theme';

import { CutShape } from './CutShape';
import { Text } from './Text';
import { haptic as haptics, ImpactStyle } from '@/lib/haptics';

/**
 * Variants mirror munkai-frontend/src/components/ui/button.tsx:
 *  - primary  → `default`: solid primary, square edges, 12px cut bottom-right
 *  - outline  → `outline2`: 2px primary border, transparent, primary text
 *  - ghost    → `transparent`: no border, primary text, tinted when pressed
 *  - destructive → solid destructive with the same corner cut
 *
 * Native feel: 0.97 press-scale (no haptic by default — opt in with `haptic`); min height 48pt (36pt + hitSlop for small).
 */
export type ButtonVariant = 'primary' | 'outline' | 'ghost' | 'destructive';
export type ButtonSize = 'md' | 'sm';

export type ButtonProps = Omit<PressableProps, 'style' | 'children'> & {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  fullWidth?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  /** Light haptic tap on press (iOS only, default false). */
  haptic?: boolean;
  /** Full height but tighter padding and text — for buttons that sit beside an input. */
  dense?: boolean;
};

export function Button({
  title,
  variant = 'primary',
  size = 'md',
  loading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  disabled,
  style,
  haptic = false,
  dense = false,
  onPressIn,
  onPressOut,
  ...rest
}: ButtonProps) {
  const t = useTheme();
  const scale = useRef(new Animated.Value(1)).current;

  const animateTo = (toValue: number) => Animated.spring(scale, { toValue, useNativeDriver: true, speed: 40, bounciness: 0 }).start();
  const isDisabled = disabled || loading;
  const height = size === 'sm' ? t.sizes.buttonHeightSmall : t.sizes.buttonHeight;

  const solid = variant === 'primary' || variant === 'destructive';
  const fill = variant === 'primary' ? t.colors.primary : variant === 'destructive' ? t.colors.destructive : undefined;
  const textColor =
    variant === 'primary' ? t.colors.onPrimary : variant === 'destructive' ? t.colors.destructiveForeground : t.colors.primary;

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!isDisabled, busy: loading }}
      disabled={isDisabled}
      hitSlop={size === 'sm' ? 6 : 0}
      style={[fullWidth && styles.fullWidth, style]}
      onPressIn={(e) => {
        animateTo(0.97);
        if (haptic) haptics.impact(ImpactStyle.Light).catch(() => {});
        onPressIn?.(e);
      }}
      onPressOut={(e) => {
        animateTo(1);
        onPressOut?.(e);
      }}
      {...rest}
    >
      {({ pressed }) => {
        const content = (
          <View style={[styles.content, { height, paddingHorizontal: size === 'sm' || dense ? t.spacing.md : t.spacing.xl }]}>
            {loading ? (
              <ActivityIndicator size="small" color={textColor} />
            ) : (
              <>
                {leftIcon}
                <Text variant="button" color={textColor} style={(size === 'sm' || dense) && styles.smallText} numberOfLines={1}>
                  {title}
                </Text>
                {rightIcon}
              </>
            )}
          </View>
        );

        const opacity = isDisabled ? 0.5 : pressed && solid ? 0.9 : 1;

        const body = solid ? (
          <CutShape cuts={t.cuts.button} fill={fill} style={{ opacity }}>
            {content}
          </CutShape>
        ) : (
          <View
            style={[
              variant === 'outline' && { borderWidth: 2, borderColor: t.colors.primary },
              pressed && { backgroundColor: t.colors.hover },
              { opacity },
            ]}
          >
            {content}
          </View>
        );

        return <Animated.View style={{ transform: [{ scale }] }}>{body}</Animated.View>;
      }}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  fullWidth: { alignSelf: 'stretch' },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  smallText: { fontSize: 12, letterSpacing: 1.2 },
});
