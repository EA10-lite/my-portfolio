import { CircleAlert, CircleCheck, Info } from 'lucide-react-native';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme, withAlpha } from '@/theme';

import { Text } from './Text';
import { haptic } from '@/lib/haptics';

export type ToastKind = 'success' | 'error' | 'info';
type ToastData = { id: number; kind: ToastKind; title: string; description?: string };

type ToastApi = {
  show: (kind: ToastKind, title: string, description?: string) => void;
  success: (title: string, description?: string) => void;
  error: (title: string, description?: string) => void;
  info: (title: string, description?: string) => void;
};

const ToastContext = createContext<ToastApi | null>(null);

/** Module-level handle so non-React code (e.g. session invalidation) can toast. */
let globalToast: ToastApi | null = null;
export const toast: ToastApi = {
  show: (...a) => globalToast?.show(...a),
  success: (...a) => globalToast?.success(...a),
  error: (...a) => globalToast?.error(...a),
  info: (...a) => globalToast?.info(...a),
};

/**
 * Top banner toasts — native take on the web's sonner toasts (top-center,
 * uppercase titles, neon edge). Slide down, auto-dismiss after 3.2s, tap to dismiss,
 * haptic matching the kind.
 */
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [current, setCurrent] = useState<ToastData | null>(null);
  const counter = useRef(0);

  const show = useCallback((kind: ToastKind, title: string, description?: string) => {
    counter.current += 1;
    setCurrent({ id: counter.current, kind, title, description });
    // Only failures buzz from here; screens add a success haptic where it's earned.
    if (kind === 'error') haptic.error().catch(() => {});
  }, []);

  const apiValue = useMemo<ToastApi>(
    () => ({
      show,
      success: (t, d) => show('success', t, d),
      error: (t, d) => show('error', t, d),
      info: (t, d) => show('info', t, d),
    }),
    [show],
  );

  useEffect(() => {
    globalToast = apiValue;
    return () => {
      if (globalToast === apiValue) globalToast = null;
    };
  }, [apiValue]);

  return (
    <ToastContext.Provider value={apiValue}>
      {children}
      {current && <ToastBanner key={current.id} toast={current} onDone={() => setCurrent(null)} />}
    </ToastContext.Provider>
  );
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used inside <ToastProvider>');
  return ctx;
}

function ToastBanner({ toast: data, onDone }: { toast: ToastData; onDone: () => void }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const anim = useRef(new Animated.Value(0)).current;

  const hide = useCallback(() => {
    Animated.timing(anim, { toValue: 0, duration: 180, easing: Easing.in(Easing.cubic), useNativeDriver: true }).start(onDone);
  }, [anim, onDone]);

  useEffect(() => {
    Animated.spring(anim, { toValue: 1, useNativeDriver: true, speed: 16, bounciness: 6 }).start();
    const timer = setTimeout(hide, 3200);
    return () => clearTimeout(timer);
  }, [anim, hide]);

  const accent = data.kind === 'success' ? t.colors.success : data.kind === 'error' ? t.colors.danger : t.colors.primary;
  const Icon = data.kind === 'success' ? CircleCheck : data.kind === 'error' ? CircleAlert : Info;

  return (
    <Animated.View
      pointerEvents="box-none"
      style={[
        styles.wrap,
        {
          top: insets.top + 8,
          opacity: anim,
          transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [-24, 0] }) }],
        },
      ]}
    >
      <Pressable
        onPress={hide}
        accessibilityRole="alert"
        accessibilityLiveRegion="polite"
        style={[
          styles.card,
          {
            backgroundColor: t.isDark ? t.colors.card : t.colors.background,
            borderColor: withAlpha(accent, 0.45),
            shadowColor: accent,
          },
        ]}
      >
        <View style={[styles.bar, { backgroundColor: accent }]} />
        <Icon size={20} color={accent} strokeWidth={2.2} />
        <View style={styles.textCol}>
          <Text variant="label" color={t.colors.foreground} style={styles.title} numberOfLines={2}>
            {data.title}
          </Text>
          {data.description ? (
            <Text variant="bodySmall" color="mutedForeground" numberOfLines={3}>
              {data.description}
            </Text>
          ) : null}
        </View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', left: 16, right: 16, zIndex: 1000, elevation: 20 },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    paddingLeft: 18,
    paddingRight: 16,
    borderWidth: 1,
    borderRadius: 14,
    overflow: 'hidden',
    shadowOpacity: 0.35,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  bar: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 4 },
  textCol: { flex: 1, gap: 2 },
  title: { letterSpacing: 1 },
});
