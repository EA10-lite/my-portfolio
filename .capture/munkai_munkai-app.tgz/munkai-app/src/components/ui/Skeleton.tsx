import React, { createContext, useContext, useEffect, useRef } from 'react';
import { Animated, Easing, type StyleProp, type ViewStyle } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

/** One shared pulse so every placeholder on screen breathes in sync. */
const PulseContext = createContext<Animated.Value | null>(null);

export function SkeletonGroup({ children }: { children: React.ReactNode }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(v, { toValue: 1, duration: 750, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(v, { toValue: 0, duration: 750, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [v]);
  return <PulseContext.Provider value={v}>{children}</PulseContext.Provider>;
}

/** Placeholder block shown while a card's data loads. */
export function Skeleton({ width, height, radius = 0, style }: { width?: number | `${number}%`; height: number; radius?: number; style?: StyleProp<ViewStyle> }) {
  const t = useTheme();
  const shared = useContext(PulseContext);
  const own = useRef(new Animated.Value(0)).current;
  const v = shared ?? own;

  useEffect(() => {
    if (shared) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(own, { toValue: 1, duration: 750, useNativeDriver: true }),
        Animated.timing(own, { toValue: 0, duration: 750, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [shared, own]);

  return (
    <Animated.View
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      style={[
        {
          width,
          height,
          borderRadius: radius,
          backgroundColor: withAlpha(t.colors.primary, t.isDark ? 0.1 : 0.12),
          opacity: v.interpolate({ inputRange: [0, 1], outputRange: [0.55, 1] }),
        },
        style,
      ]}
    />
  );
}
