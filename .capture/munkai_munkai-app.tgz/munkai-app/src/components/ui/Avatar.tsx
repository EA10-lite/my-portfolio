import React, { useState } from 'react';
import { Image, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

/**
 * No-photo avatars — the web's two ghosts (munkai-frontend/public/images):
 *  - dark  = creepy-ghost.png   (navbar, creators, everyone else)
 *  - light = profile-picture.png (your own profile page)
 */
const GHOST_DARK = require('../../../assets/images/ghost-dark.png');
const GHOST_LIGHT = require('../../../assets/images/ghost-light.png');

type Props = {
  uri?: string | null;
  /** Kept for callers (accessibility / future use); the fallback no longer draws initials. */
  firstName?: string | null;
  lastName?: string | null;
  seed?: string;
  size?: number;
  /** Which ghost to show when there's no photo. Default: dark. */
  ghost?: 'dark' | 'light';
  style?: StyleProp<ViewStyle>;
};

/** Round avatar: the user's photo, or a ghost if none / it fails to load. */
export function Avatar({ uri, size = 40, ghost = 'dark', style }: Props) {
  const t = useTheme();
  const [failed, setFailed] = useState(false);
  const photo = !!uri && !failed;

  return (
    <View
      style={[
        { width: size, height: size, borderRadius: size / 2, overflow: 'hidden' },
        !photo && ghost === 'dark' && { backgroundColor: withAlpha(t.colors.primary, 0.14) },
        style,
      ]}
    >
      {photo ? (
        <Image source={{ uri: uri! }} style={{ width: size, height: size }} onError={() => setFailed(true)} />
      ) : (
        <Image
          source={ghost === 'light' ? GHOST_LIGHT : GHOST_DARK}
          style={
            ghost === 'light'
              ? [styles.lightGhost, { width: size, height: size }]
              : [styles.darkGhost, { width: size * 1.12, height: size * 1.12 }]
          }
          resizeMode="contain"
          accessibilityIgnoresInvertColors
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  // The dark ghost has its own glow and transparent edges: scale it up a touch to fill the circle.
  darkGhost: { position: 'absolute', top: '-6%', left: '-6%' },
  lightGhost: { position: 'absolute', top: 0, left: 0 },
});
