import React from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

import { Text } from './Text';

/**
 * "Read" for free chapters — the web's outline button (chapterPayment.tsx: Button variant "outline2",
 * h-7, text-[10px] uppercase bold, border, rounded-none): primary border + text, transparent fill.
 * `onImage` adds a dark backing so it stays readable on a cover.
 */
export function ReadTag({ onImage, style }: { onImage?: boolean; style?: StyleProp<ViewStyle> }) {
  const t = useTheme();
  return (
    <View
      style={[
        styles.tag,
        { borderColor: t.colors.primary },
        onImage && { backgroundColor: withAlpha(t.colors.pageBackground, 0.78) },
        style,
      ]}
    >
      <Text style={[styles.text, { color: t.colors.primary }]}>Read</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  tag: { height: 28, paddingHorizontal: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  text: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 10, lineHeight: 13, letterSpacing: 0.8, textTransform: 'uppercase' },
});
