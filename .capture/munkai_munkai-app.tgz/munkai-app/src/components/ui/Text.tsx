import React from 'react';
import { Text as RNText, type TextProps as RNTextProps } from 'react-native';

import { useTheme, type ColorTokens, type TextVariant } from '@/theme';

export type TextProps = RNTextProps & {
  variant?: TextVariant;
  /** A theme color key (e.g. 'primary', 'mutedForeground') or any raw color string. */
  color?: keyof ColorTokens | (string & {});
  align?: 'auto' | 'left' | 'right' | 'center' | 'justify';
};

/**
 * Themed text. Defaults: body variant in the foreground color.
 * Labels default to the primary color, matching the web's form labels / kickers.
 */
export function Text({ variant = 'body', color, align, style, ...rest }: TextProps) {
  const theme = useTheme();

  const defaultColor: keyof ColorTokens =
    variant === 'label' ? 'primary' : variant === 'caption' ? 'mutedForeground' : 'foreground';

  const key = (color ?? defaultColor) as string;
  const resolvedColor =
    key in theme.colors ? (theme.colors[key as keyof ColorTokens] as string) : key;

  return (
    <RNText
      {...rest}
      style={[theme.text[variant], { color: resolvedColor }, align ? { textAlign: align } : null, style]}
    />
  );
}
