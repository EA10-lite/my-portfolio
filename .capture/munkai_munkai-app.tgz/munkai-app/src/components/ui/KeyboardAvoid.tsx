import React from 'react';
import { Animated, type StyleProp, type ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useKeyboardInset } from '@/hooks/useKeyboardInset';

/**
 * Drop-in for KeyboardAvoidingView that behaves the same on iOS and on Android edge-to-edge.
 * Children usually end with a footer that already pads `insets.bottom`; this lifts the whole
 * area by the part of the keyboard that sits above that inset, so the footer lands just on top.
 */
export function KeyboardAvoid({ style, children }: { style?: StyleProp<ViewStyle>; children: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  const keyboard = useKeyboardInset(insets.bottom);
  const lift = keyboard.interpolate({
    inputRange: [0, insets.bottom, insets.bottom + 10000],
    outputRange: [0, 0, 10000],
    extrapolate: 'clamp',
  });
  return <Animated.View style={[{ flex: 1, paddingBottom: lift }, style]}>{children}</Animated.View>;
}
