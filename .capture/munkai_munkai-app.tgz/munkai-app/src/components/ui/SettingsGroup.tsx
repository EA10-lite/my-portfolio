import { ChevronRight, type LucideIcon } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { useTheme, withAlpha } from '@/theme';

import { Text } from './Text';
import { haptic } from '@/lib/haptics';

/** Grouped list container (iOS-style settings group, approved Profile mock). */
export function SettingsGroup({ title, children }: { title?: string; children: React.ReactNode }) {
  const t = useTheme();
  const rows = React.Children.toArray(children).filter(Boolean);
  return (
    <View style={styles.wrap}>
      {title ? (
        <Text variant="caption" color="primary" style={styles.title}>
          {title}
        </Text>
      ) : null}
      <View
        style={[
          styles.group,
          {
            backgroundColor: t.isDark ? withAlpha(t.colors.card, 0.9) : withAlpha(t.colors.background, 0.8),
            borderColor: withAlpha(t.colors.primary, 0.1),
          },
        ]}
      >
        {rows.map((row, i) => (
          <View key={i} style={i > 0 ? [styles.divider, { borderTopColor: withAlpha(t.colors.primary, 0.08) }] : null}>
            {row}
          </View>
        ))}
      </View>
    </View>
  );
}

type RowProps = {
  icon: LucideIcon;
  label: string;
  value?: string;
  /** Shows a small "SOON" pill and no chevron. */
  soon?: boolean;
  onPress?: () => void;
  accessibilityHint?: string;
};

export function SettingsRow({ icon: Icon, label, value, soon, onPress, accessibilityHint }: RowProps) {
  const t = useTheme();
  return (
    <Pressable
      onPress={() => {
        haptic.select().catch(() => {});
        onPress?.();
      }}
      accessibilityRole="button"
      accessibilityLabel={soon ? `${label}, coming soon` : value ? `${label}, ${value}` : label}
      accessibilityHint={accessibilityHint}
      style={({ pressed }) => [styles.row, pressed && { backgroundColor: t.colors.hover }]}
    >
      <Icon size={20} color={t.colors.primary} strokeWidth={2} />
      <Text variant="body" style={styles.label} numberOfLines={1}>
        {label}
      </Text>
      {value ? (
        <Text variant="bodySmall" color="mutedForeground">
          {value}
        </Text>
      ) : null}
      {soon ? (
        <View style={[styles.soon, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]}>
          <Text variant="caption" color="primary" style={styles.soonText}>
            Soon
          </Text>
        </View>
      ) : (
        <ChevronRight size={18} color={withAlpha(t.colors.mutedForeground, 0.7)} strokeWidth={2} />
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 10 },
  title: { letterSpacing: 1.6, fontSize: 11 },
  group: { borderRadius: 14, borderWidth: 1, overflow: 'hidden' },
  divider: { borderTopWidth: 1 },
  row: { minHeight: 54, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 14 },
  label: { flex: 1, fontSize: 15 },
  soon: { paddingHorizontal: 6, paddingVertical: 3 },
  soonText: { fontSize: 9 },
});
