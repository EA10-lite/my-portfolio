import React, { useState } from 'react';
import { StyleSheet, View, type LayoutChangeEvent, type StyleProp, type ViewStyle } from 'react-native';
import Svg, { Polygon } from 'react-native-svg';

export type Cuts = { tl?: number; tr?: number; br?: number; bl?: number };

type Props = {
  cuts: Cuts;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
};

/** Build the polygon for a w×h box with diagonal corner cuts, inset by `inset` for strokes. */
function polygonPoints(w: number, h: number, c: Cuts, inset: number): string {
  const { tl = 0, tr = 0, br = 0, bl = 0 } = c;
  const i = inset;
  const pts: [number, number][] = [
    [i + tl, i],
    [w - i - tr, i],
    [w - i, i + tr],
    [w - i, h - i - br],
    [w - i - br, h - i],
    [i + bl, h - i],
    [i, h - i - bl],
    [i, i + tl],
  ];
  return pts.map(([x, y]) => `${x},${y}`).join(' ');
}

/**
 * A container whose background (and optional border) is drawn as a polygon with
 * diagonal corner cuts — the native equivalent of the web's `.cut-corner` and
 * `.clip-path-gamified` clip-paths. Children render on top, unclipped.
 */
export function CutShape({ cuts, fill = 'transparent', stroke, strokeWidth = 1, style, children }: Props) {
  const [size, setSize] = useState({ w: 0, h: 0 });

  const onLayout = (e: LayoutChangeEvent) => {
    const { width, height } = e.nativeEvent.layout;
    if (width !== size.w || height !== size.h) setSize({ w: width, h: height });
  };

  const inset = stroke ? strokeWidth / 2 : 0;

  return (
    <View style={style} onLayout={onLayout}>
      {size.w > 0 && size.h > 0 && (
        <Svg width={size.w} height={size.h} style={StyleSheet.absoluteFill} pointerEvents="none">
          <Polygon
            points={polygonPoints(size.w, size.h, cuts, inset)}
            fill={fill}
            stroke={stroke}
            strokeWidth={stroke ? strokeWidth : 0}
          />
        </Svg>
      )}
      {children}
    </View>
  );
}
