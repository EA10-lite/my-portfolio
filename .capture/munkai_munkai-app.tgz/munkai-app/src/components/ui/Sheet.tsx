import React, { useEffect, useRef, useState } from 'react';
import {
  Animated,
  Easing,
  Keyboard,
  Modal,
  Platform,
  PanResponder,
  Pressable,
  StyleSheet,
  useWindowDimensions,
  View,
  type StyleProp,
  type ViewStyle,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme, withAlpha } from '@/theme';

import { Text } from './Text';

type SheetProps = {
  visible: boolean;
  onClose: () => void;
  title?: string;
  /** Right side of the title row (e.g. a count pill). */
  titleAccessory?: React.ReactNode;
  children: React.ReactNode;
  /** Fixed height (for scrolling lists). Omit to size to content. */
  height?: number;
  contentStyle?: StyleProp<ViewStyle>;
  accessibilityLabel?: string;
};

/**
 * Native bottom sheet (approved mocks: Appearance, Following, Log out, Change photo).
 * Slides up over a dimmed backdrop; tap the backdrop or drag the handle down to close.
 * Built on RN Modal + Animated, so no extra native dependency.
 */
export function Sheet({ visible, onClose, title, titleAccessory, children, height, contentStyle, accessibilityLabel }: SheetProps) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { height: screenH } = useWindowDimensions();
  const [mounted, setMounted] = useState(visible);
  const progress = useRef(new Animated.Value(0)).current;
  const drag = useRef(new Animated.Value(0)).current;
  // Lift the sheet above the keyboard (Modal content isn't resized by the OS).
  const [keyboard, setKeyboard] = useState(0);
  useEffect(() => {
    if (!mounted) return;
    const show = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow', (e) =>
      setKeyboard(e.endCoordinates.height),
    );
    const hide = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', () => setKeyboard(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, [mounted]);

  useEffect(() => {
    if (visible) {
      setMounted(true);
      drag.setValue(0);
      Animated.timing(progress, { toValue: 1, duration: 260, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    } else if (mounted) {
      Animated.timing(progress, { toValue: 0, duration: 200, easing: Easing.in(Easing.cubic), useNativeDriver: true }).start(
        () => setMounted(false),
      );
    }
  }, [visible, mounted, progress, drag]);

  // Keep the latest onClose for the (once-created) pan responder.
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  // Drag the handle / title area down to dismiss.
  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, g) => Math.abs(g.dy) > 4 && Math.abs(g.dy) > Math.abs(g.dx),
      // Win over a Pressable in the title row (e.g. "Reset") once the finger clearly moves down.
      onMoveShouldSetPanResponderCapture: (_, g) => g.dy > 8 && Math.abs(g.dy) > Math.abs(g.dx),
      onPanResponderTerminationRequest: () => false,
      onPanResponderMove: (_, g) => drag.setValue(Math.max(0, g.dy)),
      onPanResponderRelease: (_, g) => {
        if (g.dy > 90 || (g.dy > 20 && g.vy > 0.8)) {
          Animated.timing(drag, { toValue: screenH, duration: 180, easing: Easing.in(Easing.quad), useNativeDriver: true }).start();
          onCloseRef.current();
        } else {
          Animated.spring(drag, { toValue: 0, useNativeDriver: true, bounciness: 4 }).start();
        }
      },
      onPanResponderTerminate: () => Animated.spring(drag, { toValue: 0, useNativeDriver: true, bounciness: 4 }).start(),
    }),
  ).current;

  if (!mounted) return null;

  const translateY = Animated.add(
    progress.interpolate({ inputRange: [0, 1], outputRange: [screenH * 0.6, 0] }),
    drag,
  );

  return (
    <Modal transparent visible animationType="none" onRequestClose={onClose} statusBarTranslucent navigationBarTranslucent>
      <Animated.View style={[StyleSheet.absoluteFill, styles.backdrop, { opacity: progress }]}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} accessibilityLabel="Close" />
      </Animated.View>

      <Animated.View
        accessibilityViewIsModal
        accessibilityLabel={accessibilityLabel ?? title}
        style={[
          styles.sheet,
          {
            height,
            maxHeight: screenH - insets.top - 24 - keyboard,
            bottom: keyboard,
            paddingBottom: keyboard ? 16 : Math.max(insets.bottom, 16) + 16,
            backgroundColor: t.isDark ? t.colors.card : t.colors.background,
            borderColor: withAlpha(t.colors.primary, 0.25),
            shadowColor: t.colors.primary,
            transform: [{ translateY }],
          },
        ]}
      >
        <View {...pan.panHandlers} style={styles.handleArea} accessibilityHint="Drag down to close">
          <View style={[styles.handle, { backgroundColor: withAlpha(t.colors.foreground, 0.25) }]} />
          {title ? (
            <View style={styles.titleRow}>
              <Text variant="heading" style={styles.title}>
                {title}
              </Text>
              {titleAccessory}
            </View>
          ) : null}
        </View>
        <View style={[styles.content, height ? styles.flex : styles.shrink, contentStyle]}>{children}</View>
      </Animated.View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  shrink: { flexShrink: 1 },
  backdrop: { backgroundColor: 'rgba(0,0,10,0.62)' },
  sheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    borderTopWidth: 1,
    shadowOpacity: 0.18,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: -8 },
    elevation: 24,
  },
  handleArea: { paddingTop: 10, paddingHorizontal: 20, minHeight: 36 },
  handle: { alignSelf: 'center', width: 40, height: 5, borderRadius: 3 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingTop: 14, paddingBottom: 6 },
  title: { flex: 1, fontSize: 22, lineHeight: 28 },
  content: { paddingHorizontal: 20, paddingTop: 8 },
});
