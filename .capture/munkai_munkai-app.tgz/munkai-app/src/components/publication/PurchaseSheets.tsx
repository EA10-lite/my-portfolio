import { Eye } from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, View } from 'react-native';

import { Cover } from '@/components/content/Cover';
import { Button, Sheet, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatBalance, formatCompact } from '@/lib/format';
import { chapterTitle } from '@/lib/publication';
import { openExternal } from '@/lib/links';
import { WALLET_WEB_URL } from '@/lib/wallet';
import { chaptersApi } from '@/services/chapters';
import type { ChapterIndexEntry, UncollectedInfo } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

function openWallet(onDone: () => void) {
  openExternal(WALLET_WEB_URL, onDone).catch(() => {});
}

/** Approved mock "Tap a locked chapter → Collect sheet". POST /api/chapters/collect. */
export function CollectSheet({
  chapter,
  publicationName,
  cover,
  onClose,
  onCollected,
}: {
  chapter: ChapterIndexEntry | null;
  publicationName: string;
  cover?: string | null;
  onClose: () => void;
  onCollected: (ch: ChapterIndexEntry) => void;
}) {
  const t = useTheme();
  const toast = useToast();
  const balance = Number(useSession((s) => s.user?.balance) ?? 0);
  const refreshProfile = useSession((s) => s.refreshProfile);
  const [busy, setBusy] = useState(false);
  const [last, setLast] = useState(chapter);
  useEffect(() => {
    if (chapter) setLast(chapter);
  }, [chapter]);
  const ch = chapter ?? last;
  if (!ch) return null;
  const short = balance < ch.price;

  const collect = async () => {
    setBusy(true);
    try {
      await chaptersApi.collect(ch.id);
      haptic.success().catch(() => {});
      refreshProfile();
      onCollected(ch);
    } catch (err) {
      toast.error('Couldn’t collect chapter', apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet visible={!!chapter} onClose={busy ? () => {} : onClose}>
      <View style={styles.head}>
        <Cover uri={cover} width={72} height={100} />
        <View style={styles.flex}>
          <Text variant="caption" color="primary" numberOfLines={1}>
            {publicationName} · Ch. {ch.chapterNumber}
          </Text>
          <Text variant="heading" numberOfLines={2} style={styles.title}>
            {chapterTitle(ch)}
          </Text>
          <View style={styles.row}>
            <Eye size={13} color={t.colors.mutedForeground} />
            <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
              {formatCompact(ch.collectCount ?? 0)} collected
            </Text>
          </View>
        </View>
      </View>
      <View style={[styles.box, { backgroundColor: withAlpha(t.colors.primary, 0.06), borderColor: withAlpha(t.colors.primary, 0.12) }]}>
        <View style={styles.flex}>
          <Text variant="caption" color="mutedForeground">
            Price
          </Text>
          <Text style={[styles.price, { color: t.colors.primary }]}>{ch.price ? `ጠ ${formatBalance(ch.price)}` : 'Free'}</Text>
        </View>
        <View style={styles.right}>
          <Text variant="caption" color="mutedForeground">
            Balance
          </Text>
          <Text variant="subtitle" style={short ? { color: t.colors.danger } : undefined}>
            ጠ {formatBalance(balance)}
          </Text>
        </View>
      </View>
      {short ? (
        <>
          <Text variant="bodySmall" color="mutedForeground" style={styles.note}>
            You need ጠ{formatBalance(ch.price - balance)} more to collect this chapter.
          </Text>
          <Button title="Add funds on munkai.art" onPress={() => openWallet(refreshProfile)} />
        </>
      ) : (
        <Button title={ch.price ? 'Collect & read' : 'Collect for free'} onPress={collect} loading={busy} disabled={busy} />
      )}
      <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.foot}>
        Collected chapters stay in your Library.
      </Text>
    </Sheet>
  );
}

/** Approved mock "Unlock all chapters sheet". GET + POST /api/chapters/collect-all. */
export function UnlockAllSheet({
  publicationId,
  visible,
  onClose,
  onDone,
}: {
  publicationId: string | number;
  visible: boolean;
  onClose: () => void;
  onDone: () => void;
}) {
  const t = useTheme();
  const toast = useToast();
  const balance = Number(useSession((s) => s.user?.balance) ?? 0);
  const refreshProfile = useSession((s) => s.refreshProfile);
  const [info, setInfo] = useState<UncollectedInfo | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!visible) return;
    setInfo(null);
    chaptersApi
      .uncollected(publicationId)
      .then(setInfo)
      .catch((e) => {
        toast.error('Couldn’t load chapters', apiErrorMessage(e));
        onClose();
      });
  }, [visible, publicationId]); // eslint-disable-line react-hooks/exhaustive-deps

  const total = info?.totalPrice ?? 0;
  const short = balance < total;

  const unlock = async () => {
    setBusy(true);
    try {
      const res = await chaptersApi.collectAll(publicationId);
      haptic.success().catch(() => {});
      toast.success('Chapters unlocked', res?.totalAmountPaid ? `Paid ጠ${formatBalance(res.totalAmountPaid)}` : undefined);
      refreshProfile();
      onDone();
      onClose();
    } catch (err) {
      toast.error('Unlock failed', apiErrorMessage(err, 'Failed to collect chapters'));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet visible={visible} onClose={busy ? () => {} : onClose} title="Unlock all chapters">
      {!info ? (
        <View style={styles.loading}>
          <ActivityIndicator color={t.colors.primary} />
        </View>
      ) : info.uncollectedCount === 0 ? (
        <Text variant="body" color="mutedForeground" style={styles.note}>
          All available chapters are already in your collection.
        </Text>
      ) : (
        <>
          <Text variant="bodySmall" color="mutedForeground" style={styles.note}>
            Collect every chapter you don’t own yet in one go.
          </Text>
          <ScrollView
            style={[styles.list, { borderColor: withAlpha(t.colors.primary, 0.12), backgroundColor: withAlpha(t.colors.primary, 0.05) }]}
          >
            {info.chapters.map((c, i) => (
              <View key={c.id} style={[styles.item, i > 0 && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }]}>
                <Text variant="subtitle" color="primary" style={styles.itemNum}>
                  Ch. {c.chapterNumber}
                </Text>
                <Text variant="bodySmall" numberOfLines={1} style={styles.flex}>
                  {chapterTitle(c)}
                </Text>
                <Text variant="subtitle" style={styles.small}>
                  {c.price ? `ጠ ${formatCompact(c.price)}` : 'Free'}
                </Text>
              </View>
            ))}
          </ScrollView>
          <View style={styles.totalRow}>
            <Text variant="caption" color="mutedForeground" style={styles.flex}>
              Total · {info.uncollectedCount} {info.uncollectedCount === 1 ? 'chapter' : 'chapters'}
            </Text>
            <Text style={[styles.price, { color: t.colors.primary }]}>{total ? `ጠ ${formatBalance(total)}` : 'Free'}</Text>
          </View>
          <View style={styles.balanceRow}>
            <Text variant="bodySmall" color="mutedForeground" style={styles.flex}>
              Your balance
            </Text>
            <Text variant="bodySmall" color={short ? 'danger' : 'mutedForeground'}>
              ጠ {formatBalance(balance)}
              {short ? '' : `  →  ጠ ${formatBalance(balance - total)}`}
            </Text>
          </View>
          {short ? (
            <Button title="Add funds on munkai.art" onPress={() => openWallet(refreshProfile)} />
          ) : (
            <Button
              title={`Unlock ${info.uncollectedCount} · ${total ? `ጠ${formatBalance(total)}` : 'Free'}`}
              onPress={unlock}
              loading={busy}
              disabled={busy}
            />
          )}
        </>
      )}
    </Sheet>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, minWidth: 0 },
  head: { flexDirection: 'row', gap: 14, paddingVertical: 8, marginBottom: 12 },
  title: { fontSize: 20, lineHeight: 25, marginTop: 4 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  small: { fontSize: 12, lineHeight: 16 },
  box: { flexDirection: 'row', alignItems: 'center', padding: 14, borderWidth: 1, marginBottom: 16 },
  right: { alignItems: 'flex-end', gap: 2 },
  price: { fontFamily: 'Grandstander-Bold', fontSize: 24, lineHeight: 30 },
  note: { marginBottom: 12 },
  foot: { marginTop: 12, fontSize: 12 },
  loading: { paddingVertical: 40 },
  list: { maxHeight: 220, borderWidth: 1, paddingHorizontal: 12 },
  item: { height: 44, flexDirection: 'row', alignItems: 'center', gap: 8 },
  itemNum: { width: 56, fontSize: 13 },
  totalRow: { flexDirection: 'row', alignItems: 'baseline', paddingTop: 14, paddingBottom: 4 },
  balanceRow: { flexDirection: 'row', paddingBottom: 16 },
});
