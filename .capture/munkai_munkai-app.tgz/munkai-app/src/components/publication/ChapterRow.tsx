import { ArrowDownToLine, Check, Eye, Lock } from 'lucide-react-native';
import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native';

import { CutShape, ReadTag, Skeleton, Text } from '@/components/ui';
import { formatCompact } from '@/lib/format';
import { chapterTitle, timeAgo } from '@/lib/publication';
import type { ChapterIndexEntry } from '@/services/types';
import { useChapterBusy, useSavedChapter } from '@/store/offline';
import { useTheme, withAlpha } from '@/theme';

export type ChapterState = 'owned' | 'reading' | 'free' | 'price' | 'early';

/** Same rules as the web PubChapterCard: canRead → owned; fan translation + price → locked early. */
export function chapterState(ch: ChapterIndexEntry, isFanfic: boolean, readingId?: number | string): ChapterState {
  if (readingId != null && String(readingId) === String(ch.id) && (ch.canRead || ch.isCollected)) return 'reading';
  if (ch.canRead || ch.isCollected) return 'owned';
  if (!ch.price) return 'free';
  return isFanfic ? 'early' : 'price';
}

export function ChapterRow({
  ch,
  state,
  onPress,
  busy,
  divider,
}: {
  ch: ChapterIndexEntry;
  state: ChapterState;
  onPress: () => void;
  busy?: boolean;
  divider?: boolean;
}) {
  const t = useTheme();
  const saved = useSavedChapter(ch.id);
  const downloading = useChapterBusy(ch.id);
  const label = `Chapter ${ch.chapterNumber}, ${chapterTitle(ch)}, ${
    state === 'owned' ? 'owned' : state === 'reading' ? 'reading now' : state === 'free' ? 'free, read now' : `${ch.price} tokens`
  }`;
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [
        styles.row,
        divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
        pressed && { backgroundColor: withAlpha(t.colors.primary, 0.05) },
        state === 'early' && { opacity: 0.8 },
      ]}
    >
      <CutShape cuts={{ tl: 6, br: 6 }} fill={withAlpha(t.colors.primary, 0.1)} style={styles.num}>
        <Text style={[styles.numText, { color: t.colors.primary }]}>{ch.chapterNumber}</Text>
      </CutShape>
      <View style={styles.flex}>
        <Text variant="subtitle" numberOfLines={1} style={styles.title}>
          {chapterTitle(ch)}
        </Text>
        <View style={styles.meta}>
          <Eye size={13} color={t.colors.mutedForeground} strokeWidth={2} />
          <Text variant="bodySmall" color="mutedForeground" style={styles.metaText}>
            {formatCompact(ch.collectCount ?? 0)} · {timeAgo(ch.createdAt)}
          </Text>
          {saved || downloading ? (
            <View style={styles.saved} accessibilityLabel={downloading ? 'Downloading' : 'Downloaded'}>
              {downloading ? (
                <ActivityIndicator size="small" color={t.colors.primary} style={styles.spin} />
              ) : (
                <ArrowDownToLine size={12} color={t.colors.primary} strokeWidth={2.4} />
              )}
              <Text style={[styles.savedText, { color: t.colors.primary }]}>{downloading ? 'Saving' : 'Saved'}</Text>
            </View>
          ) : null}
        </View>
      </View>
      {busy ? (
        <ActivityIndicator size="small" color={t.colors.primary} />
      ) : state === 'owned' ? (
        <View style={styles.owned}>
          <Check size={14} color={t.colors.success} strokeWidth={2.6} />
          <Text style={[styles.tag, { color: t.colors.success }]}>Owned</Text>
        </View>
      ) : state === 'reading' ? (
        <View style={[styles.pill, { backgroundColor: withAlpha(t.colors.primary, 0.16) }]}>
          <Text style={[styles.tag, { color: t.colors.primary }]}>Reading</Text>
        </View>
      ) : state === 'free' ? (
        // Free + not collected: one tap collects it and opens the reader.
        <ReadTag />
      ) : state === 'early' ? (
        <View style={[styles.pill, styles.early, { borderColor: withAlpha(t.colors.primary, 0.3) }]}>
          <Lock size={12} color={t.colors.mutedForeground} strokeWidth={2.2} />
          <Text style={[styles.tag, { color: t.colors.mutedForeground }]}>Early · ጠ{formatCompact(ch.price)}</Text>
        </View>
      ) : (
        <View style={[styles.pill, styles.early, { backgroundColor: t.colors.primary }]}>
          <Lock size={12} color={t.colors.onPrimary} strokeWidth={2.4} />
          <Text style={[styles.tag, { color: t.colors.onPrimary }]}>ጠ{formatCompact(ch.price)}</Text>
        </View>
      )}
    </Pressable>
  );
}

export function ChapterRowSkeleton({ divider }: { divider?: boolean }) {
  const t = useTheme();
  return (
    <View style={[styles.row, divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }]}>
      <Skeleton width={40} height={40} />
      <View style={[styles.flex, { gap: 6 }]}>
        <Skeleton width="60%" height={12} radius={3} />
        <Skeleton width="35%" height={10} radius={3} />
      </View>
      <Skeleton width={52} height={18} />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, minWidth: 0 },
  row: { minHeight: 64, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 14 },
  num: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  numText: { fontFamily: 'Grandstander-Bold', fontSize: 17, lineHeight: 22 },
  title: { fontSize: 15, lineHeight: 20 },
  meta: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
  metaText: { fontSize: 12, lineHeight: 16 },
  saved: { flexDirection: 'row', alignItems: 'center', gap: 3, marginLeft: 6 },
  savedText: { fontSize: 11, fontWeight: '700' },
  spin: { transform: [{ scale: 0.6 }], width: 12, height: 12 },
  owned: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  pill: { paddingHorizontal: 7, paddingVertical: 3 },
  early: { flexDirection: 'row', alignItems: 'center', gap: 4, borderWidth: 1, borderColor: 'transparent' },
  tag: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 10, lineHeight: 13, letterSpacing: 0.8, textTransform: 'uppercase' },
});
