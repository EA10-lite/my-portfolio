import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Button, Input, Sheet, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { reportsApi, type ReportType } from '@/services/social';
import { useTheme, withAlpha } from '@/theme';

const QUICK = ['Spam or scam', 'Stolen / copyrighted work', 'Hate or harassment', 'Sexual content', 'Something else'];

/** POST /api/reports { type, targetId, reason } — web: components/modals/report.tsx. */
export function ReportSheet({
  target,
  onClose,
}: {
  target: { type: ReportType; id: number; label: string } | null;
  onClose: () => void;
}) {
  const t = useTheme();
  const toast = useToast();
  const [reason, setReason] = useState('');
  const [picked, setPicked] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (target) {
      setReason('');
      setPicked(null);
    }
  }, [target]);

  const text = picked && picked !== 'Something else' ? [picked, reason.trim()].filter(Boolean).join(' — ') : reason.trim();

  const send = async () => {
    if (!target || !text) return;
    setBusy(true);
    try {
      await reportsApi.report(target.type, target.id, text);
      toast.success('Report sent', 'Thanks — our team will review it.');
      onClose();
    } catch (err) {
      toast.error('Couldn’t send report', apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet visible={!!target} onClose={busy ? () => {} : onClose} title={`Report ${target?.label ?? ''}`}>
      <View style={styles.chips}>
        {QUICK.map((q) => {
          const on = picked === q;
          return (
            <Pressable
              key={q}
              onPress={() => setPicked(on ? null : q)}
              accessibilityRole="radio"
              accessibilityState={{ selected: on }}
              style={[styles.chip, on ? { backgroundColor: t.colors.primary } : { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) }]}
            >
              <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.chipText}>
                {q}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <Input label="Details" value={reason} onChangeText={setReason} placeholder="Tell us what’s wrong…" multiline maxLength={500} />
      <Button title="Send report" onPress={send} loading={busy} disabled={busy || !text} style={styles.cta} />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  chip: { height: 36, paddingHorizontal: 12, justifyContent: 'center' },
  chipText: { fontSize: 12, lineHeight: 16 },
  cta: { marginTop: 14 },
});
