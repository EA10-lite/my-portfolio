import { setAudioModeAsync, useAudioPlayer } from 'expo-audio';
import { useEffect } from 'react';

import { AMBIENT_TRACKS, useReaderPrefs } from '@/lib/readerPrefs';

/** Loops the chosen ambient track while the reader is open (web: PersistentAmbientAudio). */
export function useAmbient() {
  const ambient = useReaderPrefs((s) => s.ambient);
  const player = useAudioPlayer(null);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, interruptionMode: 'mixWithOthers' }).catch(() => {});
  }, []);

  useEffect(() => {
    const url = AMBIENT_TRACKS[ambient];
    try {
      if (!url) {
        player.pause();
        return;
      }
      player.replace({ uri: url });
      player.loop = true;
      player.volume = 0.5;
      player.play();
    } catch {
      // Audio is a nice-to-have; never break reading over it.
    }
  }, [ambient, player]);

  // Stop when leaving the reader.
  useEffect(
    () => () => {
      useReaderPrefs.setState({ ambient: 'Off' });
    },
    [],
  );
}
