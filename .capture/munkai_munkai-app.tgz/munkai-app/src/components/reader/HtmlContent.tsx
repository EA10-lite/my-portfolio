/**
 * Renders the chapter's Tiptap HTML natively (p, headings, lists, quotes, images,
 * bold/italic/underline/strike, links, code, hr). Not selectable — the web blocks copying too.
 */
import { Image } from 'expo-image';
import { parseDocument } from 'htmlparser2';
import React, { useMemo, useState } from 'react';
import { Linking, StyleSheet, Text, View, useWindowDimensions, type TextStyle } from 'react-native';

import { READER_FONTS, type ReaderFontName } from '@/lib/readerPrefs';

type Node = { type: string; name?: string; data?: string; attribs?: Record<string, string>; children?: Node[] };

const BLOCK = new Set(['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'ul', 'ol', 'li', 'hr', 'img', 'pre', 'figure', 'section', 'article', 'table']);

export type HtmlStyle = { size: number; font: ReaderFontName; text: string; heading: string; accent: string; muted: string };

export function HtmlContent({ html, style }: { html: string; style: HtmlStyle }) {
  const doc = useMemo(() => parseDocument(html, { decodeEntities: true }) as unknown as Node, [html]);
  return <View>{renderBlocks(doc.children ?? [], style, 'r')}</View>;
}

function isBlock(n: Node) {
  return n.type === 'tag' && !!n.name && BLOCK.has(n.name);
}

/** Split children into runs of inline nodes (→ one <Text>) and block nodes. */
function renderBlocks(nodes: Node[], s: HtmlStyle, key: string, list?: { ordered: boolean }): React.ReactNode[] {
  const out: React.ReactNode[] = [];
  let run: Node[] = [];
  let i = 0;
  const flush = () => {
    const meaningful = run.some((n) => n.type !== 'text' || (n.data ?? '').trim());
    if (meaningful) out.push(<Para key={`${key}-t${i++}`} nodes={run} s={s} />);
    run = [];
  };
  nodes.forEach((n, idx) => {
    if (isBlock(n)) {
      flush();
      out.push(<Block key={`${key}-b${idx}`} node={n} s={s} k={`${key}-${idx}`} index={idx} list={list} />);
    } else run.push(n);
  });
  flush();
  return out;
}

function baseText(s: HtmlStyle): TextStyle {
  const f = READER_FONTS[s.font];
  return { fontFamily: f.regular, fontSize: s.size, lineHeight: Math.round(s.size * 1.7), color: s.text };
}

function Para({ nodes, s, style }: { nodes: Node[]; s: HtmlStyle; style?: TextStyle }) {
  return <Text style={[baseText(s), styles.para, style]}>{renderInline(nodes, s, {})}</Text>;
}

function renderInline(nodes: Node[], s: HtmlStyle, marks: { b?: boolean; i?: boolean; u?: boolean; strike?: boolean; code?: boolean; href?: string }): React.ReactNode[] {
  const f = READER_FONTS[s.font];
  return nodes.map((n, idx) => {
    if (n.type === 'text') {
      const st: TextStyle = {};
      if (marks.b) {
        st.fontFamily = f.bold;
        if (f.weight) st.fontWeight = f.weight;
      }
      if (marks.i) st.fontStyle = 'italic';
      const deco = [marks.u || marks.href ? 'underline' : '', marks.strike ? 'line-through' : ''].filter(Boolean).join(' ');
      if (deco) st.textDecorationLine = deco as TextStyle['textDecorationLine'];
      if (marks.code) {
        st.fontFamily = 'SpaceGrotesk-Medium';
        st.backgroundColor = 'rgba(135,206,235,0.14)';
      }
      if (marks.href) st.color = s.accent;
      const text = (n.data ?? '').replace(/\s+/g, ' ');
      return marks.href ? (
        <Text key={idx} style={st} onPress={() => Linking.openURL(marks.href!).catch(() => {})} accessibilityRole="link">
          {text}
        </Text>
      ) : (
        <Text key={idx} style={st}>
          {text}
        </Text>
      );
    }
    if (n.type !== 'tag') return null;
    const name = n.name;
    if (name === 'br') return <Text key={idx}>{'\n'}</Text>;
    const next = { ...marks };
    if (name === 'strong' || name === 'b') next.b = true;
    if (name === 'em' || name === 'i') next.i = true;
    if (name === 'u') next.u = true;
    if (name === 's' || name === 'del' || name === 'strike') next.strike = true;
    if (name === 'code') next.code = true;
    if (name === 'a' && n.attribs?.href?.startsWith('http')) next.href = n.attribs.href;
    return <React.Fragment key={idx}>{renderInline(n.children ?? [], s, next)}</React.Fragment>;
  });
}

function Block({ node, s, k, index, list }: { node: Node; s: HtmlStyle; k: string; index: number; list?: { ordered: boolean } }) {
  const name = node.name!;
  const kids = node.children ?? [];
  const f = READER_FONTS[s.font];
  if (/^h[1-6]$/.test(name)) {
    const scale = { h1: 1.6, h2: 1.4, h3: 1.25, h4: 1.1, h5: 1, h6: 0.95 }[name as 'h1'] ?? 1.2;
    const size = Math.round(s.size * scale);
    return (
      <Para
        nodes={kids}
        s={s}
        style={{ fontFamily: f.bold, fontWeight: f.weight, fontSize: size, lineHeight: Math.round(size * 1.3), color: s.heading, marginTop: 10 }}
      />
    );
  }
  if (name === 'hr') return <View style={[styles.hr, { backgroundColor: s.muted }]} />;
  if (name === 'img') return <HtmlImage src={node.attribs?.src} />;
  if (name === 'blockquote') {
    return <View style={[styles.quote, { borderLeftColor: s.accent }]}>{renderBlocks(kids, { ...s, text: s.heading }, k)}</View>;
  }
  if (name === 'ul' || name === 'ol') {
    return <View style={styles.list}>{renderBlocks(kids.filter((c) => c.type === 'tag'), s, k, { ordered: name === 'ol' })}</View>;
  }
  if (name === 'li') {
    const n = (node as Node & { parent?: Node }).parent?.children?.filter((c) => c.type === 'tag').indexOf(node) ?? index;
    return (
      <View style={styles.li}>
        <Text style={[baseText(s), styles.bullet, { color: s.accent }]}>{list?.ordered ? `${n + 1}.` : '•'}</Text>
        <View style={styles.flex}>{renderBlocks(kids, s, k)}</View>
      </View>
    );
  }
  // p, div, pre, section… — inline content wrapped as a paragraph; nested blocks recurse.
  const hasBlock = kids.some(isBlock);
  if (!hasBlock) {
    const align = /text-align:\s*(center|right|justify)/.exec(node.attribs?.style ?? '')?.[1] as TextStyle['textAlign'] | undefined;
    const empty = !kids.some((c) => c.type !== 'text' || (c.data ?? '').trim());
    if (empty) return <View style={{ height: Math.round(s.size * 0.6) }} />;
    return <Para nodes={kids} s={s} style={align ? { textAlign: align } : undefined} />;
  }
  return <View>{renderBlocks(kids, s, k)}</View>;
}

function HtmlImage({ src }: { src?: string }) {
  const { width } = useWindowDimensions();
  const [ratio, setRatio] = useState(1.5);
  if (!src) return null;
  const w = width - 48;
  return (
    <Image
      source={{ uri: src }}
      style={{ width: w, height: w / ratio, marginVertical: 12 }}
      contentFit="contain"
      onLoad={(e) => e.source.width && e.source.height && setRatio(e.source.width / e.source.height)}
    />
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  para: { marginBottom: 16 },
  hr: { height: 1, marginVertical: 20, opacity: 0.4 },
  quote: { borderLeftWidth: 3, paddingLeft: 14, marginVertical: 6 },
  list: { marginBottom: 8 },
  li: { flexDirection: 'row', gap: 8 },
  bullet: { width: 22 },
});
