/**
 * Comments — approved mock "Comments sheet"; web (origin/main) CommentThread/CommentItem.
 * GET/POST /api/comments, likes, replies, delete own, report others.
 */
import { Flag, Heart, Send, Trash2, X } from 'lucide-react-native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, TextInput, useWindowDimensions, View } from 'react-native';

import { ReportSheet } from '@/components/publication/ReportSheet';
import { Avatar, Sheet, Skeleton, SkeletonGroup, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { timeAgo } from '@/lib/publication';
import { commentsApi } from '@/services/social';
import type { Comment } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, withAlpha } from '@/theme';
import { haptic, ImpactStyle } from '@/lib/haptics';

type Target = { parentId: number; userId: number; username: string } | null;

export function useComments(chapterId?: string | number) {
  const [items, setItems] = useState<Comment[] | null>(null);
  const [error, setError] = useState<unknown>(null);
  const load = useCallback(async () => {
    if (chapterId == null) return;
    try {
      setItems(await commentsApi.list(chapterId));
      setError(null);
    } catch (e) {
      setError(e);
      setItems((i) => i ?? []);
    }
  }, [chapterId]);
  useEffect(() => {
    setItems(null);
    load();
  }, [load]);
  const total = (items ?? []).reduce((n, c) => n + 1 + (c.replyCount ?? c.replies?.length ?? 0), 0);
  return { items, error, reload: load, setItems, total };
}

export function CommentsSheet({
  visible,
  onClose,
  chapterId,
  comments,
}: {
  visible: boolean;
  onClose: () => void;
  chapterId: string | number;
  comments: ReturnType<typeof useComments>;
}) {
  const t = useTheme();
  const toast = useToast();
  const { height } = useWindowDimensions();
  const me = useSession((s) => s.user);
  const [text, setText] = useState('');
  const [target, setTarget] = useState<Target>(null);
  const [sending, setSending] = useState(false);
  const [report, setReport] = useState<number | null>(null);
  const input = useRef<TextInput>(null);

  const send = async () => {
    const content = text.trim();
    if (!content) return;
    setSending(true);
    try {
      await commentsApi.create({
        content,
        chapterId,
        ...(target ? { parentCommentId: target.parentId, replyingToUserId: target.userId } : {}),
      });
      setText('');
      setTarget(null);
      haptic.success().catch(() => {});
      comments.reload();
    } catch (err) {
      toast.error('Couldn’t post comment', apiErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  const reply = (c: Comment, parentId: number) => {
    setTarget({ parentId, userId: c.userId, username: c.username });
    setTimeout(() => input.current?.focus(), 50);
  };

  return (
    <>
      <Sheet
        visible={visible}
        onClose={onClose}
        title="Comments"
        height={Math.min(640, height * 0.8)}
        titleAccessory={
          <View style={[styles.count, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}>
            <Text variant="subtitle" color="primary" style={styles.countText}>
              {comments.total}
            </Text>
          </View>
        }
      >
        {comments.items === null ? (
          <SkeletonGroup>
            {[0, 1, 2, 3].map((i) => (
              <View key={i} style={styles.row}>
                <Skeleton width={36} height={36} radius={18} />
                <View style={{ flex: 1, gap: 6 }}>
                  <Skeleton width="40%" height={11} radius={3} />
                  <Skeleton width="85%" height={12} radius={3} />
                </View>
              </View>
            ))}
          </SkeletonGroup>
        ) : (
          <FlatList
            data={comments.items}
            keyExtractor={(c) => String(c.id)}
            renderItem={({ item, index }) => (
              <Thread
                c={item}
                divider={index > 0}
                meId={me?.id}
                onReply={reply}
                onReport={(id) => setReport(id)}
                onChanged={comments.reload}
              />
            )}
            ListEmptyComponent={
              <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.empty}>
                {comments.error ? apiErrorMessage(comments.error) : 'No comments yet — start the conversation.'}
              </Text>
            }
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            style={styles.list}
          />
        )}
        {target ? (
          <View style={[styles.replying, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]}>
            <Text variant="bodySmall" color="mutedForeground" style={styles.flex}>
              Replying to{' '}
              <Text variant="bodySmall" color="primary">
                @{target.username}
              </Text>
            </Text>
            <Pressable onPress={() => setTarget(null)} hitSlop={10} accessibilityLabel="Cancel reply">
              <X size={16} color={t.colors.mutedForeground} />
            </Pressable>
          </View>
        ) : null}
        <View style={[styles.composer, { borderTopColor: withAlpha(t.colors.primary, 0.12) }]}>
          <Avatar uri={me?.profileImage} firstName={me?.firstName} lastName={me?.lastName} seed={me?.username} size={34} />
          <TextInput
            ref={input}
            value={text}
            onChangeText={setText}
            placeholder={target ? `Reply to @${target.username}…` : 'Add a comment…'}
            placeholderTextColor={t.colors.mutedForeground}
            selectionColor={t.colors.primary}
            multiline
            maxLength={1000}
            style={[
              styles.input,
              {
                color: t.colors.foreground,
                backgroundColor: t.colors.inputBackground,
                borderColor: withAlpha(t.colors.primary, 0.18),
                fontFamily: t.fonts.body,
              },
            ]}
          />
          <Pressable
            onPress={send}
            disabled={!text.trim() || sending}
            accessibilityRole="button"
            accessibilityLabel="Post comment"
            style={[styles.send, { backgroundColor: text.trim() ? t.colors.primary : withAlpha(t.colors.primary, 0.14) }]}
          >
            {sending ? (
              <ActivityIndicator size="small" color={t.colors.onPrimary} />
            ) : (
              <Send size={18} color={text.trim() ? t.colors.onPrimary : t.colors.primary} />
            )}
          </Pressable>
        </View>
      </Sheet>
      <ReportSheet target={report != null ? { type: 'comment', id: report, label: 'comment' } : null} onClose={() => setReport(null)} />
    </>
  );
}

function Thread({
  c,
  divider,
  meId,
  onReply,
  onReport,
  onChanged,
}: {
  c: Comment;
  divider?: boolean;
  meId?: string | number;
  onReply: (c: Comment, parentId: number) => void;
  onReport: (id: number) => void;
  onChanged: () => void;
}) {
  const t = useTheme();
  const [replies, setReplies] = useState<Comment[] | null>(c.replies?.length ? c.replies : null);
  const [loading, setLoading] = useState(false);
  const count = c.replyCount ?? c.replies?.length ?? 0;
  const shown = replies?.length ?? 0;

  const loadReplies = async () => {
    setLoading(true);
    try {
      setReplies((await commentsApi.replies(c.id)).items);
    } catch {
      // keep what we have
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={divider ? { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) } : undefined}>
      <Item c={c} meId={meId} onReply={() => onReply(c, c.id)} onReport={onReport} onChanged={onChanged} />
      {replies?.map((r) => (
        <View key={r.id} style={styles.replyIndent}>
          <Item c={r} small meId={meId} onReply={() => onReply(r, c.id)} onReport={onReport} onChanged={onChanged} />
        </View>
      ))}
      {count > shown ? (
        <Pressable onPress={loadReplies} style={styles.more} accessibilityRole="button">
          {loading ? (
            <ActivityIndicator size="small" color={t.colors.primary} />
          ) : (
            <Text variant="subtitle" color="primary" style={styles.moreText}>
              View {count - shown} {count - shown === 1 ? 'reply' : 'replies'}
            </Text>
          )}
        </Pressable>
      ) : null}
    </View>
  );
}

function Item({
  c,
  small,
  meId,
  onReply,
  onReport,
  onChanged,
}: {
  c: Comment;
  small?: boolean;
  meId?: string | number;
  onReply: () => void;
  onReport: (id: number) => void;
  onChanged: () => void;
}) {
  const t = useTheme();
  const toast = useToast();
  const mine = meId != null && String(meId) === String(c.userId);
  const [liked, setLiked] = useState(!!c.likedByMe);
  const [likes, setLikes] = useState(c.likes ?? 0);

  const like = async () => {
    haptic.impact(ImpactStyle.Light).catch(() => {});
    setLiked((l) => !l);
    setLikes((n) => n + (liked ? -1 : 1));
    try {
      const r = await commentsApi.toggleLike(c.id);
      if (typeof r?.liked === 'boolean') setLiked(r.liked);
      if (typeof r?.likes === 'number') setLikes(r.likes);
    } catch {
      setLiked(liked);
      setLikes(c.likes ?? 0);
    }
  };

  const remove = async () => {
    try {
      await commentsApi.remove(c.id);
      toast.success('Comment deleted');
      onChanged();
    } catch (err) {
      toast.error('Couldn’t delete', apiErrorMessage(err));
    }
  };

  if (c.isDeleted) {
    return (
      <View style={styles.row}>
        <Text variant="bodySmall" color="mutedForeground" style={styles.deleted}>
          Comment deleted
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.row}>
      <Avatar uri={c.profileImage} firstName={c.username} seed={c.username} size={small ? 28 : 36} />
      <View style={styles.flex}>
        <Text variant="bodySmall" style={styles.meta}>
          <Text variant="subtitle" style={styles.name}>
            @{c.username}
          </Text>
          <Text variant="bodySmall" color="mutedForeground">
            {'  '}
            {timeAgo(c.createdAt)}
            {c.modifiedAt ? ' · edited' : ''}
          </Text>
        </Text>
        <Text variant="bodySmall" style={[styles.body, { color: t.isDark ? '#C9CCD6' : t.colors.foreground }]}>
          {c.replyingToUsername ? (
            <Text variant="bodySmall" color="primary">
              @{c.replyingToUsername}{' '}
            </Text>
          ) : null}
          {c.content}
        </Text>
        <View style={styles.actions}>
          <Pressable
            onPress={like}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel={liked ? 'Unlike' : 'Like'}
            style={styles.action}
          >
            <Heart size={15} color={liked ? '#FF4D6D' : t.colors.mutedForeground} fill={liked ? '#FF4D6D' : 'transparent'} />
            {likes ? (
              <Text variant="bodySmall" color="mutedForeground" style={styles.actionText}>
                {likes}
              </Text>
            ) : null}
          </Pressable>
          <Pressable onPress={onReply} hitSlop={8} accessibilityRole="button" style={styles.action}>
            <Text variant="subtitle" color="mutedForeground" style={styles.actionText}>
              Reply
            </Text>
          </Pressable>
        </View>
      </View>
      <Pressable
        onPress={mine ? remove : () => onReport(c.id)}
        hitSlop={10}
        accessibilityRole="button"
        accessibilityLabel={mine ? 'Delete comment' : 'Report comment'}
        style={styles.corner}
      >
        {mine ? <Trash2 size={16} color={t.colors.mutedForeground} /> : <Flag size={16} color={t.colors.mutedForeground} />}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, minWidth: 0 },
  count: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999 },
  countText: { fontSize: 13, lineHeight: 18 },
  list: { flex: 1 },
  row: { flexDirection: 'row', gap: 12, paddingVertical: 12 },
  replyIndent: { paddingLeft: 48 },
  meta: { fontSize: 13 },
  name: { fontSize: 13 },
  body: { fontSize: 14, lineHeight: 20, marginTop: 2 },
  deleted: { fontStyle: 'italic' },
  actions: { flexDirection: 'row', gap: 18, marginTop: 6 },
  action: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionText: { fontSize: 12, lineHeight: 16 },
  corner: { paddingTop: 2 },
  more: { paddingLeft: 48, paddingBottom: 10, alignItems: 'flex-start' },
  moreText: { fontSize: 12 },
  empty: { paddingVertical: 32 },
  replying: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 8, marginBottom: 6 },
  composer: { flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingTop: 12, borderTopWidth: 1 },
  input: { flex: 1, minHeight: 44, maxHeight: 110, paddingHorizontal: 14, paddingTop: 12, paddingBottom: 12, borderWidth: 1, fontSize: 15 },
  send: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
});
