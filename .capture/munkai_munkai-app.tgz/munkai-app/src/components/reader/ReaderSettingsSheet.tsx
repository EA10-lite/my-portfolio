import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Sheet, Text } from '@/components/ui';
import {
  AMBIENT_TRACKS,
  READER_FONTS,
  READER_THEMES,
  TEXT_SIZES,
  useReaderPrefs,
  type AmbientName,
  type ReaderFontName,
  type ReaderThemeName,
} from '@/lib/readerPrefs';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

/** Approved mock "Reading settings". */
export function ReaderSettingsSheet({ visible, onClose, showText = true }: { visible: boolean; onClose: () => void; showText?: boolean }) {
  const t = useTheme();
  const prefs = useReaderPrefs();
  const tap = () => haptic.select().catch(() => {});

  return (
    <Sheet visible={visible} onClose={onClose} title="Reading settings">
      <View style={styles.body}>
        {showText ? (
          <>
            <Group label="Text size">
              <View style={styles.sizeRow}>
                <Text variant="subtitle" color="mutedForeground" style={{ fontSize: 14 }}>
                  A
                </Text>
                <View style={styles.steps}>
                  {TEXT_SIZES.map((_, i) => {
                    const on = i === prefs.size;
                    return (
                      <Pressable
                        key={i}
                        onPress={() => {
                          tap();
                          prefs.set({ size: i });
                        }}
                        accessibilityRole="adjustable"
                        accessibilityLabel={`Text size ${i + 1} of ${TEXT_SIZES.length}`}
                        hitSlop={8}
                        style={styles.stepHit}
                      >
                        <View
                          style={[
                            on ? styles.knob : styles.dot,
                            { backgroundColor: on ? '#FFFFFF' : i < prefs.size ? t.colors.primary : withAlpha(t.colors.primary, 0.35) },
                          ]}
                        />
                      </Pressable>
                    );
                  })}
                  <View style={[styles.track, { backgroundColor: withAlpha(t.colors.primary, 0.2) }]} pointerEvents="none">
                    <View
                      style={{
                        width: `${(prefs.size / (TEXT_SIZES.length - 1)) * 100}%`,
                        height: '100%',
                        backgroundColor: t.colors.primary,
                      }}
                    />
                  </View>
                </View>
                <Text variant="subtitle" color="mutedForeground" style={{ fontSize: 22 }}>
                  A
                </Text>
              </View>
            </Group>
            <Group label="Font">
              <View style={styles.row}>
                {(Object.keys(READER_FONTS) as ReaderFontName[]).map((f) => (
                  <Chip
                    key={f}
                    label={f}
                    on={prefs.font === f}
                    font={READER_FONTS[f].regular}
                    onPress={() => {
                      tap();
                      prefs.set({ font: f });
                    }}
                    flex
                  />
                ))}
              </View>
            </Group>
          </>
        ) : null}
        <Group label="Theme">
          <View style={styles.themes}>
            {(Object.keys(READER_THEMES) as ReaderThemeName[]).map((n) => {
              const th = READER_THEMES[n];
              const on = prefs.theme === n;
              return (
                <Pressable
                  key={n}
                  onPress={() => {
                    tap();
                    prefs.set({ theme: n });
                  }}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: on }}
                  accessibilityLabel={`${n} theme`}
                  style={styles.theme}
                >
                  <View
                    style={[
                      styles.swatch,
                      { backgroundColor: th.bg, borderColor: on ? t.colors.primary : 'rgba(128,128,128,0.35)', borderWidth: on ? 3 : 1 },
                    ]}
                  >
                    <Text style={{ fontFamily: 'Georgia', fontSize: 16, color: th.text }}>Aa</Text>
                  </View>
                  <Text variant="bodySmall" color={on ? 'primary' : 'mutedForeground'} style={styles.themeLabel}>
                    {n}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </Group>
        <Group label="Ambient sound">
          <View style={styles.wrap}>
            {(Object.keys(AMBIENT_TRACKS) as AmbientName[]).map((a) => (
              <Chip
                key={a}
                label={a}
                on={prefs.ambient === a}
                onPress={() => {
                  tap();
                  prefs.set({ ambient: a });
                }}
              />
            ))}
          </View>
        </Group>
      </View>
    </Sheet>
  );
}

function Group({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={styles.group}>
      <Text variant="label">{label}</Text>
      {children}
    </View>
  );
}

function Chip({ label, on, onPress, flex, font }: { label: string; on: boolean; onPress: () => void; flex?: boolean; font?: string }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ selected: on }}
      style={[
        styles.chip,
        flex && styles.flex,
        on ? { backgroundColor: t.colors.primary } : { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
      ]}
    >
      <Text
        style={[styles.chipText, { color: on ? t.colors.onPrimary : t.colors.mutedForeground, fontFamily: font ?? 'SpaceGrotesk-Bold' }]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  body: { gap: 18, paddingBottom: 4 },
  group: { gap: 10 },
  flex: { flex: 1 },
  row: { flexDirection: 'row', gap: 8 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  sizeRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  steps: { flex: 1, height: 32, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  stepHit: { width: 28, height: 32, alignItems: 'center', justifyContent: 'center', zIndex: 2 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  knob: {
    width: 24,
    height: 24,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 3,
  },
  track: { position: 'absolute', left: 14, right: 14, height: 4, borderRadius: 2, overflow: 'hidden' },
  themes: { flexDirection: 'row', justifyContent: 'space-between' },
  theme: { alignItems: 'center', gap: 6 },
  swatch: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  themeLabel: { fontSize: 11, lineHeight: 14 },
  chip: { height: 42, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center' },
  chipText: { fontSize: 14, lineHeight: 18 },
});
