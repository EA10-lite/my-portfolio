import { Image } from 'expo-image';
import React, { useState } from 'react';
import { ActivityIndicator, Platform, StyleSheet, useWindowDimensions, View } from 'react-native';
import { WebView } from 'react-native-webview';

/** One comic page, full width, height from the image's own aspect ratio. */
export function ComicPage({ uri, onPress }: { uri: string; onPress?: () => void }) {
  const { width } = useWindowDimensions();
  const [ratio, setRatio] = useState<number | null>(null);
  return (
    <View onTouchEnd={onPress} style={{ width, height: width / (ratio ?? 0.7), backgroundColor: '#000' }}>
      <Image
        source={{ uri }}
        style={StyleSheet.absoluteFill}
        contentFit="contain"
        transition={150}
        cachePolicy="memory-disk"
        onLoad={(e) => e.source.width && e.source.height && setRatio(e.source.width / e.source.height)}
        accessibilityIgnoresInvertColors
      />
      {ratio === null ? <ActivityIndicator style={StyleSheet.absoluteFill} color="#87CEEB" /> : null}
    </View>
  );
}

/**
 * PDF chapters. iOS renders PDFs natively in WKWebView (scroll + pinch zoom);
 * Android's WebView can't, so it goes through Google's embedded viewer.
 */
export function PdfContent({ url, height }: { url: string; height: number }) {
  const local = url.startsWith('file:');
  // Downloaded PDFs (iOS only — see store/offline.ts) are read straight from disk.
  const src = Platform.OS === 'android' && !local ? `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(url)}` : url;
  return (
    <View style={{ height, backgroundColor: '#000' }}>
      <WebView
        source={{ uri: src }}
        style={styles.web}
        startInLoadingState
        renderLoading={() => <ActivityIndicator style={StyleSheet.absoluteFill} color="#87CEEB" />}
        allowsInlineMediaPlayback={false}
        setSupportMultipleWindows={false}
        originWhitelist={local ? ['file://*'] : ['https://*']}
        allowingReadAccessToURL={local ? url.replace(/[^/]+$/, '') : undefined}
        allowFileAccess={local}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  web: { flex: 1, backgroundColor: '#000' },
});
