import React, { useEffect, useMemo, useRef } from 'react';
import { Animated, Easing, StyleSheet, useWindowDimensions, View } from 'react-native';

import { useTheme } from '@/theme';

type Particle = {
  x: number;
  y: number;
  size: number;
  color: string;
  alpha: number;
  dx: number;
  dy: number;
  duration: number;
};

type Props = {
  count?: number;
  /** When false, particles render still (reduce motion). */
  animate?: boolean;
};

/**
 * Ambient drifting particles — native take on the web's canvas ParticleBackground
 * (1–3px dots, 10–60% opacity, theme-specific colours, slow drift).
 */
export function ParticleField({ count = 24, animate = true }: Props) {
  const t = useTheme();
  const { width, height } = useWindowDimensions();

  const particles = useMemo<Particle[]>(
    () =>
      Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 2 + 1,
        color: t.colors.particles[Math.floor(Math.random() * t.colors.particles.length)],
        alpha: Math.random() * 0.5 + 0.1,
        dx: (Math.random() - 0.5) * 40,
        dy: (Math.random() - 0.5) * 40,
        duration: 6000 + Math.random() * 6000,
      })),
    // Re-seed only when the palette or screen size changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [count, width, height, t.scheme],
  );

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {particles.map((p, i) => (
        <Dot key={i} particle={p} animate={animate} />
      ))}
    </View>
  );
}

function Dot({ particle: p, animate }: { particle: Particle; animate: boolean }) {
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!animate) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(progress, {
          toValue: 1,
          duration: p.duration,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(progress, {
          toValue: 0,
          duration: p.duration,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [animate, p.duration, progress]);

  const translateX = progress.interpolate({ inputRange: [0, 1], outputRange: [0, p.dx] });
  const translateY = progress.interpolate({ inputRange: [0, 1], outputRange: [0, p.dy] });

  return (
    <Animated.View
      style={{
        position: 'absolute',
        left: p.x,
        top: p.y,
        width: p.size,
        height: p.size,
        borderRadius: p.size / 2,
        backgroundColor: p.color,
        opacity: p.alpha,
        transform: [{ translateX }, { translateY }],
      }}
    />
  );
}
