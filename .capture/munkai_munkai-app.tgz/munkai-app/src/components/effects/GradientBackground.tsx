import React, { useId } from 'react';
import { StyleSheet, useWindowDimensions } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { useTheme } from '@/theme';

/**
 * Full-bleed brand gradient — the web's `--bg-gradient` (135deg, three stops).
 * Drawn with react-native-svg so no extra gradient dependency is needed.
 */
export function GradientBackground() {
  const t = useTheme();
  const { width, height } = useWindowDimensions();
  const [a, b, c] = t.colors.pageGradient;
  const id = `pg${useId().replace(/[^a-zA-Z0-9]/g, '')}`;

  return (
    <Svg width={width} height={height} style={StyleSheet.absoluteFill} pointerEvents="none">
      <Defs>
        <LinearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={a} />
          <Stop offset="0.5" stopColor={b} />
          <Stop offset="1" stopColor={c} />
        </LinearGradient>
      </Defs>
      <Rect x="0" y="0" width={width} height={height} fill={`url(#${id})`} />
    </Svg>
  );
}
