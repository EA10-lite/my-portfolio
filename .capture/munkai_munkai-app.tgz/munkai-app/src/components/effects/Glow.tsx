import React, { useId } from 'react';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';

type Props = {
  size: number;
  color: string;
  /** Opacity at the centre; fades to 0 at the edge. */
  intensity?: number;
};

/** Soft radial glow — replaces the web's `blur-[120px]` coloured blobs. */
export function Glow({ size, color, intensity = 0.35 }: Props) {
  const id = `gl${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  return (
    <Svg width={size} height={size} pointerEvents="none">
      <Defs>
        <RadialGradient id={id} cx="50%" cy="50%" r="50%">
          <Stop offset="0" stopColor={color} stopOpacity={intensity} />
          <Stop offset="0.45" stopColor={color} stopOpacity={intensity * 0.45} />
          <Stop offset="1" stopColor={color} stopOpacity={0} />
        </RadialGradient>
      </Defs>
      <Circle cx={size / 2} cy={size / 2} r={size / 2} fill={`url(#${id})`} />
    </Svg>
  );
}
