import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet, View, type ImageSourcePropType } from 'react-native';

/** Cover art bundled from munkai-frontend/public/images (the web login screen's marquee). */
const COVERS: ImageSourcePropType[] = [
  require('../../../assets/splash/cover-1.jpg'),
  require('../../../assets/splash/cover-2.jpg'),
  require('../../../assets/splash/cover-3.jpg'),
  require('../../../assets/splash/cover-4.jpg'),
  require('../../../assets/splash/cover-5.jpg'),
  require('../../../assets/splash/cover-6.jpg'),
];

/** Same column arrangement as the approved canvas mock. */
const COLUMNS: { order: number[]; offset: number; dir: 1 | -1 }[] = [
  { order: [0, 3, 5, 1, 2], offset: -40, dir: 1 },
  { order: [2, 4, 0, 3, 5, 1], offset: -150, dir: -1 },
  { order: [1, 5, 2, 4, 0], offset: -70, dir: 1 },
  { order: [4, 0, 3, 2, 5, 1], offset: -190, dir: -1 },
];

const TILE_W = 150;
const TILE_H = 225;
const GAP = 12;
const DRIFT = 60;

/**
 * Tilted wall of covers whose columns drift slowly in opposite directions —
 * the native version of the web auth screen's marquee rows.
 */
export function CoverWall({ animate = true }: { animate?: boolean }) {
  return (
    <View style={styles.clip} pointerEvents="none">
      <View style={styles.wall}>
        {COLUMNS.map((col, i) => (
          <Column key={i} {...col} animate={animate} />
        ))}
      </View>
    </View>
  );
}

function Column({ order, offset, dir, animate }: (typeof COLUMNS)[number] & { animate: boolean }) {
  const drift = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!animate) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(drift, { toValue: 1, duration: 9000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(drift, { toValue: 0, duration: 9000, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [animate, drift]);

  const translateY = drift.interpolate({ inputRange: [0, 1], outputRange: [0, dir * DRIFT] });

  return (
    <Animated.View style={[styles.column, { marginTop: offset, transform: [{ translateY }] }]}>
      {order.map((idx, i) => (
        <Image key={i} source={COVERS[idx]} style={styles.tile} resizeMode="cover" fadeDuration={0} />
      ))}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  clip: { ...StyleSheet.absoluteFill, overflow: 'hidden' },
  wall: {
    position: 'absolute',
    left: -150,
    top: -170,
    width: 690,
    height: 1400,
    flexDirection: 'row',
    gap: GAP,
    transform: [{ rotate: '-12deg' }],
  },
  column: { gap: GAP },
  tile: {
    width: TILE_W,
    height: TILE_H,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.08)',
  },
});
