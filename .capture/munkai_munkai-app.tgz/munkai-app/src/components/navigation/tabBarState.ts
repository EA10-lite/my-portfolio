import { useCallback, useRef } from 'react';
import { Animated, Easing, type NativeScrollEvent, type NativeSyntheticEvent } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

/** Floating tab bar geometry (approved mock "Floating tab bar · A"). */
export const TAB_BAR_HEIGHT = 64;
export const TAB_BAR_SIDE = 16;

export function useTabBarBottom() {
  const insets = useSafeAreaInsets();
  return Math.max(insets.bottom, 16);
}

/** Bottom padding a tab screen's scroll content needs so nothing hides behind the bar. */
export function useTabBarSpace() {
  return useTabBarBottom() + TAB_BAR_HEIGHT + 20;
}

/** 0 = shown, 1 = tucked away. Shared by the bar and every tab screen. */
export const tabBarHidden = new Animated.Value(0);
let hidden = false;

export function setTabBarHidden(next: boolean) {
  if (next === hidden) return;
  hidden = next;
  Animated.timing(tabBarHidden, {
    toValue: next ? 1 : 0,
    duration: next ? 220 : 260,
    easing: next ? Easing.in(Easing.cubic) : Easing.out(Easing.cubic),
    useNativeDriver: true,
  }).start();
}

/** Scroll handler: tuck the bar away on scroll down, bring it back on scroll up / near the top. */
export function useTabBarScroll(extra?: (e: NativeSyntheticEvent<NativeScrollEvent>) => void) {
  const last = useRef(0);
  return useCallback(
    (e: NativeSyntheticEvent<NativeScrollEvent>) => {
      const { contentOffset, contentSize, layoutMeasurement } = e.nativeEvent;
      const y = contentOffset.y;
      const dy = y - last.current;
      const atBottom = y + layoutMeasurement.height >= contentSize.height - 40;
      if (y < 60 || atBottom) setTabBarHidden(false);
      else if (dy > 8) setTabBarHidden(true);
      else if (dy < -8) setTabBarHidden(false);
      last.current = y;
      extra?.(e);
    },
    [extra],
  );
}
