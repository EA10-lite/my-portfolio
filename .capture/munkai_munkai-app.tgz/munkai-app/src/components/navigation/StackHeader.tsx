import { router } from 'expo-router';
import { ChevronLeft } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Text } from '@/components/ui';
import { useTheme, withAlpha } from '@/theme';

/** Top bar for pushed screens (Referrals, FAQ, Contact, Legal): back chevron, title, optional right slot. */
export function StackHeader({ title, right, onBack }: { title: string; right?: React.ReactNode; onBack?: () => void }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const back = onBack ?? (() => (router.canGoBack() ? router.back() : router.replace('/profile')));
  return (
    <View style={[styles.bar, { paddingTop: insets.top + 4, borderBottomColor: withAlpha(t.colors.primary, 0.1) }]}>
      <Pressable onPress={back} accessibilityRole="button" accessibilityLabel="Back" hitSlop={6} style={styles.back}>
        <ChevronLeft size={26} color={t.colors.foreground} strokeWidth={2} />
      </Pressable>
      <Text variant="heading" style={styles.title} numberOfLines={1} accessibilityRole="header">
        {title}
      </Text>
      {right ?? <View style={styles.spacer} />}
    </View>
  );
}

/** Square 44pt icon button for the header's right slot. */
export function HeaderIconButton({ onPress, label, children }: { onPress: () => void; label: string; children: React.ReactNode }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={4}
      style={({ pressed }) => [styles.icon, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.1) }]}
    >
      {children}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingBottom: 10, borderBottomWidth: 1 },
  back: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  title: { flex: 1, fontSize: 20 },
  spacer: { width: 44 },
  icon: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center', borderRadius: 22 },
});
