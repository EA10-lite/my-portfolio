import { BlurView } from 'expo-blur';
import { ArrowDownToLine, Compass, House, User, Wallet, type LucideIcon } from 'lucide-react-native';
import React, { useEffect } from 'react';
import { Animated, LayoutAnimation, Platform, Pressable, StyleSheet, View } from 'react-native';

import { Text } from '@/components/ui';
import { useTheme, withAlpha } from '@/theme';

import { setTabBarHidden, TAB_BAR_HEIGHT, TAB_BAR_SIDE, tabBarHidden, useTabBarBottom } from './tabBarState';
import { haptic } from '@/lib/haptics';
import { useIsOffline } from '@/lib/network';

const ICONS: Record<string, LucideIcon> = { home: House, explore: Compass, downloads: ArrowDownToLine, wallet: Wallet, profile: User };
const LABELS: Record<string, string> = { home: 'Home', explore: 'Explore', downloads: 'Downloads', wallet: 'Wallet', profile: 'Profile' };

type TabBarProps = {
  state: { index: number; routes: { key: string; name: string }[] };
  navigation: {
    emit: (e: { type: 'tabPress'; target: string; canPreventDefault: true }) => { defaultPrevented: boolean };
    navigate: (name: string) => void;
  };
};

/**
 * Floating glass tab bar (approved mock "A · Glass pill"): floats above the content,
 * the active tab grows into a labelled capsule, and it tucks away while scrolling down.
 */
export function TabBar({ state, navigation }: TabBarProps) {
  const t = useTheme();
  const bottom = useTabBarBottom();
  // Offline mode: only Downloads works without internet, so it's the only tab.
  const offline = useIsOffline();
  // Fade the bar out / back in when the connection drops / returns.
  useEffect(() => {
    LayoutAnimation.configureNext(LayoutAnimation.create(260, 'easeInEaseOut', 'opacity'));
  }, [offline]);

  // Every tab switch brings the bar back.
  useEffect(() => {
    setTabBarHidden(false);
  }, [state.index]);

  // Offline mode: no tab bar at all — Downloads is the only screen.
  if (offline) return null;

  const translateY = tabBarHidden.interpolate({ inputRange: [0, 1], outputRange: [0, TAB_BAR_HEIGHT + bottom + 12] });
  const glass = Platform.OS === 'ios';

  return (
    <Animated.View pointerEvents="box-none" style={[styles.wrap, { bottom, shadowColor: '#000', transform: [{ translateY }] }]}>
      <View
        style={[
          styles.bar,
          {
            borderColor: withAlpha(t.colors.primary, t.isDark ? 0.18 : 0.3),
            backgroundColor: glass
              ? withAlpha(t.isDark ? t.colors.card : t.colors.background, t.isDark ? 0.55 : 0.6)
              : withAlpha(t.isDark ? t.colors.card : t.colors.background, 0.97),
          },
        ]}
      >
        {glass ? <BlurView intensity={40} tint={t.isDark ? 'dark' : 'light'} style={StyleSheet.absoluteFill} /> : null}
        {state.routes.map((route, index) => {
          const focused = state.index === index;
          const Icon = ICONS[route.name] ?? House;
          const label = LABELS[route.name] ?? route.name;
          const onPress = () => {
            const event = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
            if (!focused && !event.defaultPrevented) {
              haptic.select().catch(() => {});
              LayoutAnimation.configureNext(LayoutAnimation.create(220, 'easeInEaseOut', 'opacity'));
              navigation.navigate(route.name);
            }
          };
          return (
            <Pressable
              key={route.key}
              onPress={onPress}
              accessibilityRole="tab"
              accessibilityState={{ selected: focused }}
              accessibilityLabel={label}
              hitSlop={4}
              style={[styles.item, focused && [styles.itemOn, { backgroundColor: t.colors.primary, shadowColor: t.colors.primary }]]}
            >
              <Icon
                size={focused ? 20 : 22}
                color={focused ? t.colors.onPrimary : withAlpha(t.colors.mutedForeground, t.isDark ? 0.9 : 1)}
                strokeWidth={focused ? 2.2 : 2}
              />
              {focused ? (
                <Text numberOfLines={1} style={[styles.label, { color: t.colors.onPrimary }]}>
                  {label}
                </Text>
              ) : null}
            </Pressable>
          );
        })}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: TAB_BAR_SIDE,
    right: TAB_BAR_SIDE,
    borderRadius: TAB_BAR_HEIGHT / 2,
    shadowOpacity: 0.4,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 12,
  },
  bar: {
    height: TAB_BAR_HEIGHT,
    borderRadius: TAB_BAR_HEIGHT / 2,
    borderWidth: 1,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    overflow: 'hidden',
  },
  item: { height: 44, minWidth: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' },
  itemOn: {
    paddingLeft: 14,
    paddingRight: 16,
    gap: 8,
    shadowOpacity: 0.55,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
  },
  label: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 13, lineHeight: 17 },
});
