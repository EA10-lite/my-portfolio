/** Downloads tab: what's saved for offline reading, with per-chapter and per-publication removal. */
import { router } from 'expo-router';
import { ArrowDownToLine, BookOpen, ChevronRight, Trash2 } from 'lucide-react-native';
import React, { useMemo } from 'react';
import { Alert, Pressable, StyleSheet, View } from 'react-native';

import { Cover } from '@/components/content/Cover';
import { Text } from '@/components/ui';
import { formatSize } from '@/lib/pickers';
import { typeLabel } from '@/lib/publication';
import { removeAllOffline, removeChapter, removePublication, useOffline, type SavedChapter, type SavedPublication } from '@/store/offline';
import { useTheme, withAlpha } from '@/theme';

export type DownloadGroup = { pub: SavedPublication; chapters: SavedChapter[]; bytes: number };

export function useDownloadGroups(): DownloadGroup[] {
  const chapters = useOffline((s) => s.chapters);
  const publications = useOffline((s) => s.publications);
  return useMemo(() => {
    const map = new Map<string, DownloadGroup>();
    for (const c of Object.values(chapters)) {
      const pub = publications[c.publicationId] ?? { id: c.publicationId, name: 'Untitled' };
      const g = map.get(c.publicationId) ?? { pub, chapters: [], bytes: 0 };
      g.chapters.push(c);
      g.bytes += c.bytes;
      map.set(c.publicationId, g);
    }
    return [...map.values()]
      .map((g) => ({ ...g, chapters: g.chapters.sort((a, b) => a.chapterNumber - b.chapterNumber) }))
      .sort((a, b) => Math.max(...b.chapters.map((c) => c.savedAt)) - Math.max(...a.chapters.map((c) => c.savedAt)));
  }, [chapters, publications]);
}

export const openSaved = (c: SavedChapter) =>
  router.push({ pathname: '/read/[id]', params: { id: c.chapterId, v: String(c.editCount), pub: c.publicationId } });

/** One downloaded publication on the Downloads page: cover, name, type · chapters · size. Tap → its chapters. */
export function DownloadPublicationRow({ group, first }: { group: DownloadGroup; first: boolean }) {
  const t = useTheme();
  const n = group.chapters.length;
  return (
    <Pressable
      onPress={() => router.push({ pathname: '/downloaded/[id]', params: { id: group.pub.id } })}
      accessibilityRole="button"
      accessibilityLabel={`${group.pub.name}, ${n} chapter${n === 1 ? '' : 's'} downloaded, ${formatSize(group.bytes)}`}
      accessibilityHint="Shows the downloaded chapters"
      style={({ pressed }) => [
        styles.pubRow,
        !first && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.1) },
        pressed && { opacity: 0.7 },
      ]}
    >
      <Cover uri={group.pub.coverPhoto} width={54} height={76} />
      <View style={styles.flex}>
        <Text variant="subtitle" numberOfLines={1} style={styles.title}>
          {group.pub.name}
        </Text>
        <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
          {[typeLabel(group.pub.publicationType), `${n} chapter${n === 1 ? '' : 's'} downloaded`].filter(Boolean).join(' · ')}
        </Text>
        <View style={styles.inline}>
          <ArrowDownToLine size={12} color={t.colors.primary} strokeWidth={2.4} />
          <Text variant="subtitle" color="primary" style={styles.small}>
            Available offline · {formatSize(group.bytes)}
          </Text>
        </View>
      </View>
      <ChevronRight size={18} color={t.colors.mutedForeground} />
    </Pressable>
  );
}

/** "Remove all" for one publication, with a confirm. */
export function confirmRemovePublication(group: DownloadGroup, onDone?: () => void) {
  const n = group.chapters.length;
  Alert.alert(`Remove ${group.pub.name}?`, `All ${n} downloaded chapter${n === 1 ? '' : 's'} will be deleted from this device.`, [
    { text: 'Cancel', style: 'cancel' },
    {
      text: 'Remove',
      style: 'destructive',
      onPress: () => {
        removePublication(group.pub.id);
        onDone?.();
      },
    },
  ]);
}

/** One downloaded chapter under its publication: tap to read offline, trash to remove. */
export function DownloadChapterRow({ chapter: c, last }: { chapter: SavedChapter; last: boolean }) {
  const t = useTheme();
  const line = withAlpha(t.colors.primary, 0.1);
  return (
    <View
      style={[
        styles.chRow,
        { backgroundColor: withAlpha(t.colors.primary, t.isDark ? 0.05 : 0.04), borderColor: line },
        last && styles.chRowLast,
      ]}
    >
      <Pressable
        onPress={() => openSaved(c)}
        accessibilityRole="button"
        accessibilityLabel={`Read chapter ${c.chapterNumber}${c.name ? `, ${c.name}` : ''}`}
        style={({ pressed }) => [styles.chMain, pressed && { opacity: 0.7 }]}
      >
        <BookOpen size={18} color={t.colors.primary} />
        <View style={styles.flex}>
          <Text variant="subtitle" numberOfLines={1} style={styles.chTitle}>
            Ch. {c.chapterNumber}
            {c.name ? ` · ${c.name}` : ''}
          </Text>
          <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
            {formatSize(c.bytes)}
          </Text>
        </View>
      </Pressable>
      <Pressable
        onPress={() => removeChapter(c.chapterId)}
        accessibilityRole="button"
        accessibilityLabel={`Remove chapter ${c.chapterNumber} download`}
        hitSlop={8}
        style={styles.trash}
      >
        <Trash2 size={18} color={t.colors.mutedForeground} />
      </Pressable>
    </View>
  );
}

export function DownloadsFooter({ groups }: { groups: DownloadGroup[] }) {
  const t = useTheme();
  if (!groups.length) return null;
  const total = groups.reduce((n, g) => n + g.bytes, 0);
  return (
    <View style={styles.footer}>
      <Text variant="bodySmall" color="mutedForeground" align="center">
        Using {formatSize(total)} on this device
      </Text>
      <Pressable
        onPress={() =>
          Alert.alert('Remove all downloads?', 'Everything saved for offline reading will be deleted from this device.', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Remove all', style: 'destructive', onPress: removeAllOffline },
          ])
        }
        accessibilityRole="button"
        hitSlop={8}
        style={styles.inline}
      >
        <Trash2 size={14} color={t.colors.destructive} />
        <Text variant="subtitle" style={[styles.small, { color: t.colors.destructive }]}>
          Remove all downloads
        </Text>
      </Pressable>
    </View>
  );
}

export function DownloadsEmpty() {
  const t = useTheme();
  return (
    <View style={styles.empty}>
      <View style={[styles.emptyIcon, { borderColor: withAlpha(t.colors.primary, 0.3) }]}>
        <ArrowDownToLine size={22} color={t.colors.primary} />
      </View>
      <Text variant="heading" align="center">
        Nothing downloaded
      </Text>
      <Text variant="bodySmall" color="mutedForeground" align="center">
        Tap the download button on a publication to save the chapters you own. They’ll open here without internet.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  pubRow: { minHeight: 96, marginHorizontal: 20, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 14 },
  title: { fontSize: 16 },
  small: { fontSize: 12, lineHeight: 17 },
  inline: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  footer: { alignItems: 'center', gap: 12, paddingVertical: 24 },
  empty: { alignItems: 'center', gap: 10, paddingHorizontal: 36, paddingTop: 40 },
  emptyIcon: { width: 56, height: 56, borderRadius: 28, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  chRow: {
    marginHorizontal: 20,
    minHeight: 56,
    paddingLeft: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderBottomWidth: 0,
  },
  chRowLast: { borderBottomWidth: 1 },
  chMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8 },
  chTitle: { fontSize: 15 },
  trash: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
});
