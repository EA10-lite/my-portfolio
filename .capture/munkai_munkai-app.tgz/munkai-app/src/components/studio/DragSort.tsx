/**
 * Long-press-and-drag reordering without extra native deps (PanResponder + Animated).
 * Works as a vertical list (fixed row height) or a grid (fixed cell size).
 * The parent ScrollView should pass `onDragStateChange` → setScrollEnabled(!dragging).
 */
import React, { useMemo, useRef, useState } from 'react';
import { Animated, PanResponder, Pressable, View } from 'react-native';
import { haptic, ImpactStyle } from '@/lib/haptics';

type Layout = { kind: 'list'; rowHeight: number } | { kind: 'grid'; columns: number; cellWidth: number; cellHeight: number; gap: number };

type Props<T> = {
  items: T[];
  keyOf: (item: T) => string;
  onChange: (next: T[]) => void;
  renderItem: (item: T, index: number, active: boolean) => React.ReactNode;
  layout: Layout;
  onDragStateChange?: (dragging: boolean) => void;
  /** Accessibility: move one step (used by the a11y actions on each item). */
  itemLabel?: (item: T, index: number) => string;
  /** Rendered on top of each item, outside its press target (e.g. a remove button). */
  renderOverlay?: (item: T, index: number) => React.ReactNode;
};

export function DragSort<T>({ items, keyOf, onChange, renderItem, layout, onDragStateChange, itemLabel, renderOverlay }: Props<T>) {
  const [active, setActive] = useState<number | null>(null);
  const pan = useRef(new Animated.ValueXY()).current;
  const state = useRef({ active: null as number | null, start: 0, current: 0, items });
  state.current.items = items;

  const pos = (i: number) => {
    if (layout.kind === 'list') return { x: 0, y: i * layout.rowHeight };
    const col = i % layout.columns;
    const row = Math.floor(i / layout.columns);
    return { x: col * (layout.cellWidth + layout.gap), y: row * (layout.cellHeight + layout.gap) };
  };
  const indexAt = (x: number, y: number) => {
    const n = state.current.items.length;
    if (layout.kind === 'list') return Math.max(0, Math.min(n - 1, Math.round(y / layout.rowHeight)));
    const col = Math.max(0, Math.min(layout.columns - 1, Math.round(x / (layout.cellWidth + layout.gap))));
    const row = Math.max(0, Math.round(y / (layout.cellHeight + layout.gap)));
    return Math.max(0, Math.min(n - 1, row * layout.columns + col));
  };

  const finish = () => {
    state.current.active = null;
    setActive(null);
    pan.setValue({ x: 0, y: 0 });
    onDragStateChange?.(false);
  };

  const responder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => state.current.active !== null,
        onMoveShouldSetPanResponder: () => state.current.active !== null,
        onMoveShouldSetPanResponderCapture: () => state.current.active !== null,
        onPanResponderTerminationRequest: () => false,
        onPanResponderMove: (_, g) => {
          const s = state.current;
          if (s.active === null) return;
          const origin = pos(s.start);
          const target = indexAt(origin.x + g.dx, origin.y + g.dy);
          if (target !== s.current) {
            const next = [...s.items];
            const [moved] = next.splice(s.current, 1);
            next.splice(target, 0, moved);
            s.current = target;
            s.active = target;
            setActive(target);
            haptic.select().catch(() => {});
            onChange(next);
          }
          const now = pos(s.current);
          pan.setValue({ x: origin.x + g.dx - now.x, y: origin.y + g.dy - now.y });
        },
        onPanResponderRelease: finish,
        onPanResponderTerminate: finish,
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [layout, onChange],
  );

  const begin = (i: number) => {
    state.current = { ...state.current, active: i, start: i, current: i };
    setActive(i);
    pan.setValue({ x: 0, y: 0 });
    onDragStateChange?.(true);
    haptic.impact(ImpactStyle.Medium).catch(() => {});
  };

  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= items.length) return;
    const next = [...items];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };

  const rows = layout.kind === 'list' ? items.length : Math.ceil(items.length / layout.columns);
  const height = layout.kind === 'list' ? rows * layout.rowHeight : rows * layout.cellHeight + Math.max(0, rows - 1) * layout.gap;

  return (
    <View style={{ height, position: 'relative' }} {...responder.panHandlers}>
      {items.map((item, i) => {
        const p = pos(i);
        const isActive = active === i;
        const w = layout.kind === 'list' ? undefined : layout.cellWidth;
        const h = layout.kind === 'list' ? layout.rowHeight : layout.cellHeight;
        return (
          <Animated.View
            key={keyOf(item)}
            style={[
              {
                position: 'absolute',
                left: layout.kind === 'list' ? 0 : p.x,
                right: layout.kind === 'list' ? 0 : undefined,
                top: p.y,
                width: w,
                height: h,
              },
              isActive && { zIndex: 10, elevation: 10, transform: [...pan.getTranslateTransform(), { scale: 1.04 }] },
            ]}
          >
            <Pressable
              onLongPress={() => begin(i)}
              delayLongPress={220}
              style={{ flex: 1 }}
              accessibilityLabel={itemLabel?.(item, i)}
              accessibilityHint="Hold and drag to reorder"
              accessibilityActions={[
                { name: 'increment', label: 'Move down' },
                { name: 'decrement', label: 'Move up' },
              ]}
              onAccessibilityAction={(e) => move(i, e.nativeEvent.actionName === 'increment' ? 1 : -1)}
            >
              {renderItem(item, i, isActive)}
            </Pressable>
            {renderOverlay?.(item, i)}
          </Animated.View>
        );
      })}
    </View>
  );
}
