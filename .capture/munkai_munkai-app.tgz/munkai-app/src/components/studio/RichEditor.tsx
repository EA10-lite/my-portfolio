/**
 * Chapter text editor — approved mock "New chapter · Write".
 * A contentEditable page inside a WebView (no extra native deps) that produces the same HTML the web's
 * TipTap editor does: <p>, <h1–h3>, <strong>, <em>, <u>, <s>, <blockquote>, text-align.
 * The formatting bar is native and sits above the keyboard.
 */
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  Bold,
  Heading2,
  Italic,
  Quote,
  Redo2,
  Strikethrough,
  Underline,
  Undo2,
  type LucideIcon,
} from 'lucide-react-native';
import React, { forwardRef, useImperativeHandle, useMemo, useRef } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';

import { useTheme, withAlpha } from '@/theme';

export type EditorState = { bold: boolean; italic: boolean; underline: boolean; strike: boolean; block: string; align: string };
export type RichEditorHandle = { focus: () => void; blur: () => void; getHtml: () => string; exec: (cmd: string, value?: string) => void };

type Props = {
  initialHtml: string;
  placeholder?: string;
  onChange: (html: string) => void;
  onFocusChange?: (focused: boolean) => void;
  onStateChange?: (state: EditorState) => void;
};

function page(html: string, placeholder: string, c: { fg: string; muted: string; accent: string; bg: string; quote: string }) {
  return `<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<style>
html,body{margin:0;background:${c.bg};color:${c.fg};-webkit-text-size-adjust:100%}
#ed{min-height:100vh;box-sizing:border-box;padding:4px 20px 120px;outline:none;font-family:Georgia,'Times New Roman',serif;font-size:18px;line-height:1.65;caret-color:${c.accent};word-wrap:break-word}
#ed:empty:before{content:attr(data-ph);color:${c.muted}}
#ed p{margin:0 0 14px}
#ed h1,#ed h2,#ed h3{font-family:-apple-system,system-ui,sans-serif;line-height:1.25;margin:22px 0 10px}
#ed h2{font-size:22px}
#ed blockquote{margin:0 0 14px;padding:4px 0 4px 14px;border-left:3px solid ${c.accent};color:${c.quote};font-style:italic}
</style></head><body>
<div id="ed" contenteditable="true" data-ph="${placeholder.replace(/"/g, '&quot;')}"></div>
<script>
(function(){
  var ed=document.getElementById('ed');
  ed.innerHTML=${JSON.stringify(html)};
  try{document.execCommand('defaultParagraphSeparator',false,'p');}catch(e){}
  function post(o){window.ReactNativeWebView&&window.ReactNativeWebView.postMessage(JSON.stringify(o));}
  function clean(){var h=ed.innerHTML; if(ed.textContent.trim()===''&&!ed.querySelector('img'))h=''; return h.replace(/<div>/g,'<p>').replace(/<\\/div>/g,'</p>');}
  var t=null;
  function changed(){clearTimeout(t);t=setTimeout(function(){post({type:'change',html:clean()});},250);state();}
  function block(){var s=window.getSelection();if(!s.rangeCount)return 'p';var n=s.anchorNode;while(n&&n!==ed){if(n.nodeType===1&&/^(H1|H2|H3|BLOCKQUOTE|P)$/.test(n.nodeName))return n.nodeName.toLowerCase();n=n.parentNode;}return 'p';}
  function state(){try{post({type:'state',bold:document.queryCommandState('bold'),italic:document.queryCommandState('italic'),underline:document.queryCommandState('underline'),strike:document.queryCommandState('strikeThrough'),block:block(),align:document.queryCommandState('justifyCenter')?'center':document.queryCommandState('justifyRight')?'right':'left'});}catch(e){}}
  ed.addEventListener('input',changed);
  ed.addEventListener('focus',function(){post({type:'focus',value:true});});
  ed.addEventListener('blur',function(){post({type:'focus',value:false});});
  document.addEventListener('selectionchange',state);
  ed.addEventListener('paste',function(e){e.preventDefault();var txt=(e.clipboardData||window.clipboardData).getData('text/plain');document.execCommand('insertText',false,txt);});
  window.__cmd=function(c,v){ed.focus();
    if(c==='block'){var cur=block();document.execCommand('formatBlock',false,cur===v?'p':v);}
    else if(c==='align'){document.execCommand(v==='center'?'justifyCenter':v==='right'?'justifyRight':'justifyLeft');}
    else document.execCommand(c,false,v||null);
    changed();};
  window.__focus=function(){ed.focus();var r=document.createRange();r.selectNodeContents(ed);r.collapse(false);var s=window.getSelection();s.removeAllRanges();s.addRange(r);};
  window.__blur=function(){ed.blur();};
  post({type:'ready'});
})();
</script></body></html>`;
}

export const RichEditor = forwardRef<RichEditorHandle, Props>(function RichEditor(
  { initialHtml, placeholder = 'Start writing…', onChange, onFocusChange, onStateChange },
  ref,
) {
  const t = useTheme();
  const web = useRef<WebView>(null);
  const htmlRef = useRef(initialHtml);

  // The page is built once; later edits live inside the WebView.
  const source = useMemo(
    () => ({
      html: page(initialHtml, placeholder, {
        fg: t.colors.foreground,
        muted: t.colors.mutedForeground,
        accent: t.colors.primary,
        bg: t.colors.pageBackground,
        quote: withAlpha(t.colors.foreground, 0.8),
      }),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [],
  );

  const run = (js: string) => web.current?.injectJavaScript(`${js};true;`);
  useImperativeHandle(ref, () => ({
    focus: () => run('window.__focus&&window.__focus()'),
    blur: () => run('window.__blur&&window.__blur()'),
    getHtml: () => htmlRef.current,
    exec: (c, v) => run(`window.__cmd&&window.__cmd(${JSON.stringify(c)},${JSON.stringify(v ?? null)})`),
  }));

  const onMessage = (e: WebViewMessageEvent) => {
    try {
      const m = JSON.parse(e.nativeEvent.data);
      if (m.type === 'change') {
        htmlRef.current = m.html;
        onChange(m.html);
      } else if (m.type === 'state') onStateChange?.(m);
      else if (m.type === 'focus') onFocusChange?.(!!m.value);
    } catch {
      // ignore
    }
  };

  return (
    <WebView
      ref={web}
      originWhitelist={['*']}
      source={source}
      onMessage={onMessage}
      style={{ flex: 1, backgroundColor: t.colors.pageBackground }}
      containerStyle={{ backgroundColor: t.colors.pageBackground }}
      hideKeyboardAccessoryView
      keyboardDisplayRequiresUserAction={false}
      scrollEnabled
      showsVerticalScrollIndicator={false}
      javaScriptEnabled
      setSupportMultipleWindows={false}
      automaticallyAdjustContentInsets={false}
      {...(Platform.OS === 'ios' ? { contentInsetAdjustmentBehavior: 'never' as const } : {})}
      testID="rich-editor"
      accessibilityLabel="Chapter text"
    />
  );
});

export const EMPTY_STATE: EditorState = { bold: false, italic: false, underline: false, strike: false, block: 'p', align: 'left' };

export function EditorToolbar({ onCommand, state }: { onCommand: (cmd: string, value?: string) => void; state: EditorState }) {
  const t = useTheme();
  const cmd = onCommand;
  const nextAlign = state.align === 'left' ? 'center' : state.align === 'center' ? 'right' : 'left';
  const AlignIcon = state.align === 'center' ? AlignCenter : state.align === 'right' ? AlignRight : AlignLeft;
  const items: { icon: LucideIcon; label: string; on?: boolean; press: () => void }[] = [
    { icon: Bold, label: 'Bold', on: state.bold, press: () => cmd('bold') },
    { icon: Italic, label: 'Italic', on: state.italic, press: () => cmd('italic') },
    { icon: Underline, label: 'Underline', on: state.underline, press: () => cmd('underline') },
    { icon: Strikethrough, label: 'Strikethrough', on: state.strike, press: () => cmd('strikeThrough') },
    { icon: Heading2, label: 'Heading', on: state.block === 'h2', press: () => cmd('block', 'h2') },
    { icon: Quote, label: 'Quote', on: state.block === 'blockquote', press: () => cmd('block', 'blockquote') },
    { icon: AlignIcon, label: `Align ${nextAlign}`, press: () => cmd('align', nextAlign) },
    { icon: Undo2, label: 'Undo', press: () => cmd('undo') },
    { icon: Redo2, label: 'Redo', press: () => cmd('redo') },
  ];
  return (
    <View style={[styles.bar, { backgroundColor: t.colors.card, borderTopColor: withAlpha(t.colors.primary, 0.18) }]}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        keyboardShouldPersistTaps="always"
        contentContainerStyle={styles.barContent}
      >
        {items.map(({ icon: Icon, label, on, press }) => (
          <Pressable
            key={label}
            onPress={press}
            accessibilityRole="button"
            accessibilityLabel={label}
            accessibilityState={{ selected: !!on }}
            style={({ pressed }) => [styles.btn, (on || pressed) && { backgroundColor: withAlpha(t.colors.primary, on ? 0.2 : 0.1) }]}
          >
            <Icon size={18} color={on ? t.colors.primary : t.colors.foreground} strokeWidth={2.2} />
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: { height: 48, borderTopWidth: 1 },
  barContent: { alignItems: 'center', paddingHorizontal: 6, gap: 2 },
  btn: { width: 42, height: 40, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
});
