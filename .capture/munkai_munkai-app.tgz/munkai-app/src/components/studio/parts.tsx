/** Small building blocks shared by the Creator Studio screens (approved mocks "Creator Studio …"). */
import { Check, type LucideIcon } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { Text } from '@/components/ui';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

export function FieldLabel({ children, right }: { children: string; right?: React.ReactNode }) {
  return (
    <View style={styles.labelRow}>
      <Text variant="label" style={styles.flex}>
        {children}
      </Text>
      {right}
    </View>
  );
}

export function Chip({
  label,
  selected,
  onPress,
  icon: Icon,
  disabled,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  icon?: LucideIcon;
  disabled?: boolean;
}) {
  const t = useTheme();
  return (
    <Pressable
      onPress={() => {
        haptic.select().catch(() => {});
        onPress?.();
      }}
      disabled={disabled || !onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected, disabled: !!disabled }}
      style={({ pressed }) => [
        styles.chip,
        selected ? { backgroundColor: t.colors.primary } : { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
        (pressed || disabled) && { opacity: disabled ? 0.4 : 0.8 },
      ]}
    >
      {Icon ? <Icon size={15} color={selected ? t.colors.onPrimary : t.colors.mutedForeground} strokeWidth={2} /> : null}
      <Text variant="subtitle" color={selected ? t.colors.onPrimary : 'mutedForeground'} style={styles.chipText}>
        {label}
      </Text>
    </Pressable>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string; icon?: LucideIcon }[];
  value: T;
  onChange: (v: T) => void;
}) {
  const t = useTheme();
  return (
    <View
      style={[styles.seg, { backgroundColor: t.colors.card, borderColor: withAlpha(t.colors.primary, 0.14) }]}
      accessibilityRole="tablist"
    >
      {options.map(({ value: v, label, icon: Icon }) => {
        const on = v === value;
        return (
          <Pressable
            key={v}
            onPress={() => {
              if (on) return;
              haptic.select().catch(() => {});
              onChange(v);
            }}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
            style={[styles.segItem, on && { backgroundColor: t.colors.primary }]}
          >
            {Icon ? <Icon size={15} color={on ? t.colors.onPrimary : t.colors.mutedForeground} strokeWidth={2} /> : null}
            <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.chipText}>
              {label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const TONES = {
  live: { fg: '#22C55E', bg: 'rgba(34,197,94,0.14)' },
  draft: { fg: '#FFC400', bg: 'rgba(255,196,0,0.14)' },
  scheduled: { fg: '#87CEEB', bg: 'rgba(135,206,235,0.14)' },
  done: { fg: '#22C55E', bg: 'rgba(34,197,94,0.14)' },
  fan: { fg: '#04FFFF', bg: 'rgba(4,255,255,0.12)' },
  danger: { fg: '#FF4D6D', bg: 'rgba(255,77,109,0.12)' },
};
export function StateBadge({ label, tone }: { label: string; tone: keyof typeof TONES }) {
  const c = TONES[tone];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]}>
      <Text style={[styles.badgeText, { color: c.fg }]}>{label.toUpperCase()}</Text>
    </View>
  );
}

export function Checkbox({ checked, onChange, children }: { checked: boolean; onChange: (v: boolean) => void; children: React.ReactNode }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={() => onChange(!checked)}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      style={styles.checkRow}
      hitSlop={6}
    >
      <View
        style={[
          styles.check,
          checked ? { backgroundColor: t.colors.primary } : { borderWidth: 2, borderColor: withAlpha(t.colors.primary, 0.5) },
        ]}
      >
        {checked ? <Check size={15} color={t.colors.onPrimary} strokeWidth={3} /> : null}
      </View>
      <View style={styles.flex}>{children}</View>
    </Pressable>
  );
}

export function InfoNote({ icon: Icon, children, style }: { icon: LucideIcon; children: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  const t = useTheme();
  return (
    <View style={[styles.note, { backgroundColor: withAlpha(t.colors.primary, 0.06) }, style]}>
      <Icon size={16} color={t.colors.primary} strokeWidth={2} />
      <Text variant="bodySmall" color="mutedForeground" style={[styles.flex, styles.noteText]}>
        {children}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  labelRow: { flexDirection: 'row', alignItems: 'center' },
  chip: { height: 36, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 6 },
  chipText: { fontSize: 13, lineHeight: 18 },
  seg: { flexDirection: 'row', padding: 4, borderRadius: 12, borderWidth: 1 },
  segItem: { flex: 1, height: 40, borderRadius: 9, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  badge: { paddingHorizontal: 6, paddingVertical: 2, alignSelf: 'flex-start' },
  badgeText: { fontSize: 9, lineHeight: 12, fontWeight: '700', letterSpacing: 1 },
  checkRow: { flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  check: { width: 22, height: 22, alignItems: 'center', justifyContent: 'center', marginTop: 1 },
  note: { flexDirection: 'row', gap: 10, padding: 12, alignItems: 'flex-start' },
  noteText: { fontSize: 12, lineHeight: 17 },
});
