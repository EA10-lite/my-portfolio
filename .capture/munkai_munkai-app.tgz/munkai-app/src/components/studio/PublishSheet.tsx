/**
 * Publish settings — approved mock "New chapter · Publish settings".
 * Price (0 = free) and Now / Schedule / Draft (web publishStatePicker.tsx). Edits only change the price.
 */
import { CalendarClock, FileText, Info, Send } from 'lucide-react-native';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';

import { Button, Input, Sheet, Text } from '@/components/ui';
import { TOKENS_PER_USD } from '@/lib/wallet';
import type { PublishMode } from '@/services/creator';

import { Chip, FieldLabel, InfoNote, Segmented } from './parts';

const PRICES = [0, 20, 50, 100];

function days(n = 14) {
  const out: Date[] = [];
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  for (let i = 0; i < n; i++) out.push(new Date(d.getTime() + i * 86400000));
  return out;
}
const TIMES = Array.from({ length: 48 }, (_, i) => ({ h: Math.floor(i / 2), m: (i % 2) * 30 }));
const dayLabel = (d: Date, i: number) =>
  i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
const timeLabel = (h: number, m: number) =>
  new Date(2000, 0, 1, h, m).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

export type PublishSettings = { price: number; mode: PublishMode; publishAt: Date | null };

export function PublishSheet({
  visible,
  editing,
  initialPrice,
  saving,
  onClose,
  onSubmit,
}: {
  visible: boolean;
  editing: boolean;
  initialPrice: number;
  saving: boolean;
  onClose: () => void;
  onSubmit: (s: PublishSettings) => void;
}) {
  const [price, setPrice] = useState(initialPrice);
  const [custom, setCustom] = useState(!PRICES.includes(initialPrice));
  const [customText, setCustomText] = useState(PRICES.includes(initialPrice) ? '' : String(initialPrice));
  const [mode, setMode] = useState<PublishMode>('now');
  const dates = useMemo(() => days(), []);
  const [day, setDay] = useState(1);
  const [time, setTime] = useState(18); // 9:00
  const timesRef = useRef<ScrollView>(null);

  useEffect(() => {
    if (visible) {
      setPrice(initialPrice);
      setCustom(!PRICES.includes(initialPrice));
      setCustomText(PRICES.includes(initialPrice) ? '' : String(initialPrice));
    }
  }, [visible, initialPrice]);

  const at = useMemo(() => {
    const d = new Date(dates[day]);
    d.setHours(TIMES[time].h, TIMES[time].m, 0, 0);
    return d;
  }, [dates, day, time]);
  const past = mode === 'schedule' && at.getTime() <= Date.now();
  const effectivePrice = custom ? Math.max(0, Number(customText.replace(/[^0-9.]/g, '')) || 0) : price;
  const cta = editing ? 'Save changes' : mode === 'schedule' ? 'Schedule chapter' : mode === 'draft' ? 'Save draft' : 'Publish chapter';

  return (
    <Sheet visible={visible} onClose={onClose} title={editing ? 'Save chapter' : 'Publish settings'}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">
        <View style={styles.block}>
          <FieldLabel>Price</FieldLabel>
          <View style={styles.wrap}>
            {PRICES.map((p) => (
              <Chip
                key={p}
                label={p === 0 ? 'Free' : `ጠ ${p}`}
                selected={!custom && price === p}
                onPress={() => {
                  setCustom(false);
                  setPrice(p);
                }}
              />
            ))}
            <Chip label="Other…" selected={custom} onPress={() => setCustom(true)} />
          </View>
          {custom ? (
            <Input
              value={customText}
              onChangeText={setCustomText}
              keyboardType="decimal-pad"
              placeholder="Tokens, e.g. 35"
              leftIcon={<Text variant="subtitle">ጠ</Text>}
              autoFocus
            />
          ) : null}
          <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
            {effectivePrice === 0 ? 'Anyone can read it for free.' : `≈ $${(effectivePrice / TOKENS_PER_USD).toFixed(2)} per reader.`}
          </Text>
        </View>

        {!editing ? (
          <View style={styles.block}>
            <FieldLabel>When</FieldLabel>
            <Segmented
              value={mode}
              onChange={setMode}
              options={[
                { value: 'now', label: 'Now', icon: Send },
                { value: 'schedule', label: 'Schedule', icon: CalendarClock },
                { value: 'draft', label: 'Draft', icon: FileText },
              ]}
            />
            {mode === 'schedule' ? (
              <View style={styles.schedule}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row}>
                  {dates.map((d, i) => (
                    <Chip key={d.toISOString()} label={dayLabel(d, i)} selected={day === i} onPress={() => setDay(i)} />
                  ))}
                </ScrollView>
                <ScrollView
                  ref={timesRef}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.row}
                  onLayout={() => timesRef.current?.scrollTo({ x: Math.max(0, time - 1) * 96, animated: false })}
                >
                  {TIMES.map((x, i) => (
                    <Chip key={i} label={timeLabel(x.h, x.m)} selected={time === i} onPress={() => setTime(i)} />
                  ))}
                </ScrollView>
                <Text variant="bodySmall" color={past ? 'destructive' : 'mutedForeground'} style={styles.small}>
                  {past
                    ? 'That time has passed — it will go live immediately.'
                    : `Goes live ${at.toLocaleString(undefined, { weekday: 'long', day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })} (your time). Followers are notified then.`}
                </Text>
              </View>
            ) : mode === 'draft' ? (
              <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                Only you can see drafts. Publish it later from your studio.
              </Text>
            ) : null}
          </View>
        ) : null}

        <InfoNote icon={Info}>
          {editing
            ? 'Saving uses one of this chapter’s edits (originals get 2; fan translations are unlimited).'
            : 'After publishing, original works can be edited twice per chapter. Chapter numbers are set automatically.'}
        </InfoNote>
      </ScrollView>
      <Button
        title={cta}
        fullWidth
        loading={saving}
        onPress={() => onSubmit({ price: effectivePrice, mode: editing ? 'now' : mode, publishAt: mode === 'schedule' ? at : null })}
        style={[styles.cta, { marginBottom: 8 }]}
      />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  scroll: { flexShrink: 1 },
  body: { gap: 20, paddingTop: 6, paddingBottom: 4 },
  block: { gap: 10 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  row: { gap: 8 },
  schedule: { gap: 10 },
  small: { fontSize: 12, lineHeight: 17 },
  cta: { marginTop: 14 },
});
