/** Genre picker sheet — approved mock "Genre picker sheet". Genres are the web's hard-coded list. */
import { Check, Search, X } from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';

import { Button, Sheet, Text } from '@/components/ui';
import { FICTION_GENRES, NON_FICTION_GENRES } from '@/services/creator';
import { radius, useTheme, withAlpha } from '@/theme';

import { Chip } from './parts';

export function GenreSheet({
  visible,
  value,
  fiction,
  onClose,
  onDone,
}: {
  visible: boolean;
  value: string[];
  fiction: boolean;
  onClose: () => void;
  onDone: (genres: string[]) => void;
}) {
  const t = useTheme();
  const [sel, setSel] = useState<string[]>(value);
  const [q, setQ] = useState('');
  useEffect(() => {
    if (visible) {
      setSel(value);
      setQ('');
    }
  }, [visible, value]);

  // Web lists fiction + non-fiction together; show the matching group first.
  const groups = fiction
    ? [
        { title: 'Fiction', list: FICTION_GENRES },
        { title: 'Non-fiction', list: NON_FICTION_GENRES },
      ]
    : [
        { title: 'Non-fiction', list: NON_FICTION_GENRES },
        { title: 'Fiction', list: FICTION_GENRES },
      ];
  const match = (g: string) => g.toLowerCase().includes(q.trim().toLowerCase());
  const toggle = (g: string) => setSel((s) => (s.includes(g) ? s.filter((x) => x !== g) : [...s, g]));

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Genres"
      height={640}
      titleAccessory={
        <Pressable onPress={() => setSel([])} disabled={!sel.length} accessibilityRole="button" hitSlop={8}>
          <Text variant="subtitle" color={sel.length ? 'primary' : 'mutedForeground'} style={styles.clear}>
            Clear
          </Text>
        </Pressable>
      }
    >
      <View style={[styles.search, { backgroundColor: t.colors.pageBackground, borderColor: withAlpha(t.colors.primary, 0.18) }]}>
        <Search size={18} color={t.colors.mutedForeground} />
        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder="Search genres"
          placeholderTextColor={t.colors.mutedForeground}
          style={[styles.input, { color: t.colors.foreground }]}
          autoCorrect={false}
        />
        {q ? (
          <Pressable onPress={() => setQ('')} hitSlop={10} accessibilityLabel="Clear search">
            <X size={16} color={t.colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        {groups.map(({ title, list }) => {
          const items = list.filter(match);
          if (!items.length) return null;
          return (
            <View key={title} style={styles.group}>
              <Text variant="label">{title}</Text>
              <View style={styles.wrap}>
                {items.map((g) => (
                  <Chip
                    key={`${title}-${g}`}
                    label={g}
                    selected={sel.includes(g)}
                    icon={sel.includes(g) ? Check : undefined}
                    onPress={() => toggle(g)}
                  />
                ))}
              </View>
            </View>
          );
        })}
      </ScrollView>
      <Button title={sel.length ? `Done · ${sel.length} selected` : 'Done'} fullWidth onPress={() => onDone(sel)} style={styles.done} />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  clear: { fontSize: 13 },
  search: {
    height: 44,
    borderRadius: radius.search,
    borderWidth: 1,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 4,
  },
  input: { flex: 1, fontSize: 15, height: '100%' },
  scroll: { flexShrink: 1, marginTop: 12 },
  scrollContent: { gap: 16, paddingBottom: 8 },
  group: { gap: 10 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  done: { marginTop: 12, marginBottom: 8 },
});
