import { Check, Eye, EyeOff } from 'lucide-react-native';
import React, { forwardRef, useRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View, type TextInputProps } from 'react-native';

import { Input, InputAccessoryButton, Text, type InputProps } from '@/components/ui';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

/* ─────────────────────────── Password field ─────────────────────────── */

export const PasswordInput = forwardRef<TextInput, InputProps>(function PasswordInput(props, ref) {
  const t = useTheme();
  const [visible, setVisible] = useState(false);
  return (
    <Input
      ref={ref}
      {...props}
      secureTextEntry={!visible}
      autoCapitalize="none"
      autoCorrect={false}
      rightAccessory={
        <InputAccessoryButton label={visible ? 'Hide password' : 'Show password'} onPress={() => setVisible((v) => !v)}>
          {visible ? (
            <EyeOff size={20} color={t.colors.primary} strokeWidth={2} />
          ) : (
            <Eye size={20} color={t.colors.primary} strokeWidth={2} />
          )}
        </InputAccessoryButton>
      }
    />
  );
});

/* ─────────────────────────── "OR CONTINUE WITH" ─────────────────────── */

export function OrDivider({ label }: { label: string }) {
  const t = useTheme();
  const line = { backgroundColor: withAlpha(t.colors.primary, 0.15) };
  return (
    <View style={styles.divider}>
      <View style={[styles.dividerLine, line]} />
      <Text variant="caption" style={styles.dividerText}>
        {label}
      </Text>
      <View style={[styles.dividerLine, line]} />
    </View>
  );
}

/* ─────────────────────────── Google (coming soon) ───────────────────── */

export function GoogleButton({ label, onPress }: { label: string; onPress: () => void }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${label}, coming soon`}
      style={({ pressed }) => [
        styles.google,
        {
          borderColor: withAlpha(t.colors.primary, t.isDark ? 0.55 : 0.45),
          backgroundColor: pressed ? t.colors.hover : t.isDark ? 'transparent' : withAlpha('#FFFFFF', 0.6),
        },
      ]}
    >
      <View style={[styles.gBadge, !t.isDark && styles.gBadgeLight]}>
        <Text style={styles.gLetter} color="#1F2937">
          G
        </Text>
      </View>
      <Text variant="subtitle" style={styles.googleText}>
        {label}
      </Text>
      <View style={[styles.soon, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]}>
        <Text variant="caption" color="primary" style={styles.soonText}>
          Soon
        </Text>
      </View>
    </Pressable>
  );
}

/* ─────────────────────────── Step progress ──────────────────────────── */

export function StepProgress({ step, total }: { step: number; total: number }) {
  const t = useTheme();
  return (
    <View style={styles.progressRow} accessibilityLabel={`Step ${step} of ${total}`}>
      <View style={styles.progressBars}>
        {Array.from({ length: total }, (_, i) => {
          const done = i < step;
          const current = i === step - 1;
          return (
            <View
              key={i}
              style={[
                styles.progressBar,
                { backgroundColor: done ? t.colors.primary : withAlpha(t.colors.primary, 0.15) },
                current && { shadowColor: t.colors.primary, shadowOpacity: 0.8, shadowRadius: 6, shadowOffset: { width: 0, height: 0 } },
              ]}
            />
          );
        })}
      </View>
      <Text variant="caption" style={styles.progressText}>
        {step}/{total}
      </Text>
    </View>
  );
}

/* ─────────────────────────── Rule checklist ─────────────────────────── */

export function Rule({ ok, label }: { ok: boolean; label: string }) {
  const t = useTheme();
  const color = ok ? t.colors.success : t.colors.mutedForeground;
  return (
    <View style={styles.rule}>
      {ok ? <Check size={13} color={color} strokeWidth={3} /> : <View style={[styles.ruleDot, { borderColor: color }]} />}
      <Text variant="bodySmall" color={color} style={styles.ruleText}>
        {label}
      </Text>
    </View>
  );
}

/* ─────────────────────────── Password strength ──────────────────────── */

/** Same thresholds as the web signup form. */
export function passwordStrength(pw: string): { level: 0 | 1 | 2 | 3; label: string } {
  if (!pw) return { level: 0, label: '' };
  const special = /[!@#$%^&*(),.?":{}|<>_\-\\[\]/+=~`';]/.test(pw);
  const num = /\d/.test(pw);
  if (pw.length < 8) return { level: 1, label: 'Weak' };
  if (special && num) return { level: 3, label: 'Strong' };
  if (special || num) return { level: 2, label: 'Moderate' };
  return { level: 1, label: 'Weak' };
}

export function StrengthMeter({ password }: { password: string }) {
  const t = useTheme();
  const { level, label } = passwordStrength(password);
  if (!level) return null;
  const color = level === 3 ? t.colors.success : level === 2 ? '#EAB308' : t.colors.danger;
  return (
    <View style={styles.strength}>
      <View style={[styles.strengthTrack, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]}>
        <View style={{ width: `${(level / 3) * 100}%`, height: 4, backgroundColor: color }} />
      </View>
      <Text variant="caption" color={color} style={styles.strengthLabel}>
        {label}
      </Text>
    </View>
  );
}

/* ─────────────────────────── Checkbox row ───────────────────────────── */

export function CheckboxRow({
  checked,
  onToggle,
  children,
  accessibilityLabel,
}: {
  checked: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  accessibilityLabel: string;
}) {
  const t = useTheme();
  return (
    <Pressable
      onPress={() => {
        haptic.select().catch(() => {});
        onToggle();
      }}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      accessibilityLabel={accessibilityLabel}
      style={styles.checkRow}
    >
      <View
        style={[
          styles.checkbox,
          { borderColor: checked ? t.colors.primary : withAlpha(t.colors.primary, 0.5) },
          checked && { backgroundColor: t.colors.primary },
        ]}
      >
        {checked ? <Check size={15} color={t.colors.onPrimary} strokeWidth={3} /> : null}
      </View>
      <View style={styles.flex}>{children}</View>
    </Pressable>
  );
}

/* ─────────────────────────── 6-digit code entry ─────────────────────── */

type OtpProps = {
  value: string;
  onChange: (v: string) => void;
  length?: number;
  error?: boolean;
} & Pick<TextInputProps, 'onSubmitEditing' | 'autoFocus'>;

/**
 * One hidden TextInput drives six display boxes — keeps paste, SMS/email
 * autofill (oneTimeCode) and backspace behaving natively.
 */
export function OtpInput({ value, onChange, length = 6, error, onSubmitEditing, autoFocus }: OtpProps) {
  const t = useTheme();
  const ref = useRef<TextInput>(null);
  const [focused, setFocused] = useState(false);
  const digits = value.split('');
  const activeIndex = Math.min(value.length, length - 1);

  return (
    <Pressable onPress={() => ref.current?.focus()} accessibilityLabel="Verification code" style={styles.otpRow}>
      {Array.from({ length }, (_, i) => {
        const isActive = focused && i === activeIndex;
        const filled = !!digits[i];
        return (
          <View
            key={i}
            style={[
              styles.otpBox,
              {
                backgroundColor: t.colors.inputBackground,
                borderColor: error
                  ? t.colors.destructive
                  : isActive
                    ? t.colors.primary
                    : filled
                      ? withAlpha(t.colors.primary, 0.4)
                      : t.colors.input,
                borderWidth: isActive ? 2 : 1,
              },
              isActive && { shadowColor: t.colors.primary, shadowOpacity: 0.45, shadowRadius: 8, shadowOffset: { width: 0, height: 0 } },
            ]}
          >
            <Text style={[t.text.stat, styles.otpDigit]}>{digits[i] ?? ''}</Text>
          </View>
        );
      })}
      <TextInput
        ref={ref}
        value={value}
        onChangeText={(v) => onChange(v.replace(/\D/g, '').slice(0, length))}
        keyboardType="number-pad"
        textContentType="oneTimeCode"
        autoComplete="one-time-code"
        maxLength={length}
        autoFocus={autoFocus}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onSubmitEditing={onSubmitEditing}
        style={styles.otpHidden}
        caretHidden
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { letterSpacing: 1.6 },
  google: {
    height: 52,
    borderWidth: 1.5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  gBadge: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#FFFFFF', alignItems: 'center', justifyContent: 'center' },
  gBadgeLight: { borderWidth: 1, borderColor: '#D5DEE6' },
  gLetter: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 14, lineHeight: 18 },
  googleText: { fontSize: 15 },
  soon: { paddingHorizontal: 6, paddingVertical: 3 },
  soonText: { fontSize: 9 },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  progressBars: { flex: 1, flexDirection: 'row', gap: 6 },
  progressBar: { flex: 1, height: 4 },
  progressText: { letterSpacing: 1 },
  rule: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  ruleDot: { width: 12, height: 12, borderRadius: 6, borderWidth: 1.5 },
  ruleText: { fontSize: 12, lineHeight: 16 },
  strength: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  strengthTrack: { flex: 1, height: 4, overflow: 'hidden' },
  strengthLabel: { letterSpacing: 1 },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 44 },
  checkbox: { width: 22, height: 22, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  otpRow: { flexDirection: 'row', gap: 8 },
  otpBox: { flex: 1, height: 60, alignItems: 'center', justifyContent: 'center' },
  otpDigit: { fontSize: 26, lineHeight: 32 },
  otpHidden: { position: 'absolute', width: 1, height: 1, opacity: 0 },
});
