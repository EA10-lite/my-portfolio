import { router, useNavigation } from 'expo-router';
import { ChevronLeft, X } from 'lucide-react-native';
import React from 'react';
import { Animated, Keyboard, Platform, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { GradientBackground } from '@/components/effects/GradientBackground';
import { ParticleField } from '@/components/effects/ParticleField';
import { Text } from '@/components/ui';
import { useKeyboardInset } from '@/hooks/useKeyboardInset';
import { useReduceMotion } from '@/hooks/useReduceMotion';
import { useTheme } from '@/theme';

type Props = {
  /** 'close' dismisses the whole auth sheet; 'back' pops one screen. */
  leading?: 'close' | 'back' | 'none';
  onLeadingPress?: () => void;
  /** Extra content in the top bar (e.g. step progress). */
  headerAccessory?: React.ReactNode;
  /** Above the title (e.g. the M mark). */
  eyebrow?: React.ReactNode;
  title?: string;
  caption?: string;
  children: React.ReactNode;
  /** Pinned to the bottom, above the keyboard. */
  footer?: React.ReactNode;
};

/**
 * Shared frame for every auth screen (approved mock): brand gradient + particles,
 * 44pt close/back target, Grandstander title + uppercase caption, scrollable form,
 * primary action pinned above the keyboard.
 */
export function AuthLayout({ leading = 'back', onLeadingPress, headerAccessory, eyebrow, title, caption, children, footer }: Props) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const reduceMotion = useReduceMotion();
  const keyboard = useKeyboardInset(insets.bottom);
  const closeAuth = useCloseAuth();
  const navigation = useNavigation();

  const handleLeading = () => {
    if (onLeadingPress) return onLeadingPress();
    if (leading === 'close') return closeAuth();
    if (navigation.canGoBack()) navigation.goBack();
    else closeAuth();
  };

  return (
    <View style={[styles.root, { backgroundColor: t.colors.pageBackground }]}>
      <GradientBackground />
      <ParticleField count={10} animate={reduceMotion === false} />

      <View style={styles.flex}>
        <View style={[styles.topBar, { paddingTop: insets.top + 6 }]}>
          {leading !== 'none' ? (
            <Pressable
              onPress={handleLeading}
              accessibilityRole="button"
              accessibilityLabel={leading === 'close' ? 'Close' : 'Back'}
              hitSlop={6}
              style={({ pressed }) => [styles.iconBtn, pressed && { backgroundColor: t.colors.hover }]}
            >
              {leading === 'close' ? (
                <X size={22} color={t.colors.foreground} strokeWidth={2} />
              ) : (
                <ChevronLeft size={26} color={t.colors.foreground} strokeWidth={2} />
              )}
            </Pressable>
          ) : (
            <View style={styles.iconBtn} />
          )}
          <View style={styles.accessory}>{headerAccessory}</View>
        </View>

        <ScrollView
          style={styles.flex}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {(eyebrow || title || caption) && (
            <View style={styles.heading}>
              {eyebrow}
              {title ? (
                <Text variant="display" style={[styles.title, eyebrow ? { marginTop: 14 } : null]}>
                  {title}
                </Text>
              ) : null}
              {caption ? (
                <Text variant="caption" style={styles.caption}>
                  {caption}
                </Text>
              ) : null}
            </View>
          )}
          {children}
        </ScrollView>

        {footer ? (
          // Pinned primary action: rides on top of the keyboard (12pt gap) and sits above the
          // home indicator / nav bar when the keyboard is closed.
          <Animated.View
            style={[
              styles.footer,
              {
                paddingBottom: keyboard.interpolate({
                  inputRange: [0, 1, 10000],
                  outputRange: [Math.max(insets.bottom, 16) + 8, 13, 10012],
                }),
              },
            ]}
          >
            {footer}
          </Animated.View>
        ) : null}
        {!footer ? <Animated.View style={{ height: keyboard }} /> : null}
      </View>
    </View>
  );
}

/** Dismiss the entire auth sheet and return to wherever the user came from. */
export function useCloseAuth() {
  const navigation = useNavigation();
  return () => {
    // Android: leaving the auth modal while the keyboard is up and a password field is focused
    // (autofill "save password" session in flight) can crash the native view tree. Drop focus and
    // the keyboard first, then navigate on the next frames.
    Keyboard.dismiss();
    const go = () => {
      const parent = navigation.getParent();
      // Opened on top of the app (e.g. from a paid action) → just dismiss the sheet.
      if (parent?.canGoBack()) parent.goBack();
      // Auth is the app's entry point (logged-out launch) → continue into the app.
      else router.replace('/home');
    };
    if (Platform.OS === 'android') setTimeout(() => requestAnimationFrame(go), 250);
    else go();
  };
}

/** True when auth was opened on top of the app and can be dismissed (shows the ✕). */
export function useAuthIsDismissible() {
  const navigation = useNavigation();
  return !!navigation.getParent()?.canGoBack();
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1 },
  topBar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, gap: 8 },
  iconBtn: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  accessory: { flex: 1, paddingRight: 12 },
  scrollContent: { paddingHorizontal: 24, paddingTop: 8, paddingBottom: 24 },
  heading: { marginBottom: 28, gap: 6 },
  title: { fontSize: 32, lineHeight: 36 },
  caption: { fontSize: 11, letterSpacing: 1.6, lineHeight: 16 },
  footer: { paddingHorizontal: 24, paddingTop: 12, gap: 14 },
});
