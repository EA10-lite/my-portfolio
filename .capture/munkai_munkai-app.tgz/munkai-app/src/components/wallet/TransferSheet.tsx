import * as Clipboard from 'expo-clipboard';
import { ArrowLeft } from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View } from 'react-native';

import { Button, Input, Sheet, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatBalance } from '@/lib/format';
import { shortAddress, toUsd } from '@/lib/wallet';
import { paymentsApi } from '@/services/payments';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

const MIN = 10; // web: "Amount cannot be less than 10", whole numbers only

/** Approved mock "Wallet · Transfer (in-app)": form → review → send (POST /api/payments/transfer). */
export function TransferSheet({
  visible,
  onClose,
  balance,
  onSent,
}: {
  visible: boolean;
  onClose: () => void;
  balance: number;
  onSent: () => void;
}) {
  const t = useTheme();
  const toast = useToast();
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [step, setStep] = useState<'form' | 'review'>('form');
  const [errors, setErrors] = useState<{ address?: string; amount?: string }>({});
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (visible) {
      setStep('form');
      setErrors({});
    } else if (!sending) {
      setAddress('');
      setAmount('');
    }
  }, [visible, sending]);

  const n = Number(amount);

  const review = () => {
    const a = address.trim();
    const next = {
      address: a.length < 8 ? 'Address is too short' : a.length > 128 ? 'Address is too long' : undefined,
      amount: !amount
        ? 'Enter an amount'
        : !Number.isInteger(n)
          ? 'Amount must be a whole number'
          : n < MIN
            ? `Amount cannot be less than ${MIN}`
            : n > balance
              ? 'That’s more than your balance'
              : undefined,
    };
    setErrors(next);
    if (next.address || next.amount) {
      haptic.error().catch(() => {});
      return;
    }
    setStep('review');
  };

  const send = async () => {
    setSending(true);
    try {
      await paymentsApi.transfer(address, n);
      haptic.success().catch(() => {});
      toast.success('Tokens sent', `ጠ${formatBalance(n)} to ${shortAddress(address.trim())}`);
      onSent();
      onClose();
      setAddress('');
      setAmount('');
    } catch (err) {
      toast.error('Transfer failed', apiErrorMessage(err, 'Unable to complete transfer'));
      setStep('form');
    } finally {
      setSending(false);
    }
  };

  const paste = async () => {
    const text = (await Clipboard.getStringAsync()).trim();
    if (text) {
      setAddress(text);
      setErrors((e) => ({ ...e, address: undefined }));
    }
  };

  return (
    <Sheet visible={visible} onClose={sending ? () => {} : onClose} title={step === 'form' ? 'Send tokens' : 'Review transfer'}>
      {step === 'form' ? (
        <View style={styles.body}>
          <Input
            label="Recipient address"
            value={address}
            onChangeText={(v) => {
              setAddress(v);
              if (errors.address) setErrors((e) => ({ ...e, address: undefined }));
            }}
            placeholder="0x…"
            autoCapitalize="none"
            autoCorrect={false}
            error={errors.address}
            rightAccessory={
              <Pressable
                onPress={paste}
                accessibilityRole="button"
                accessibilityLabel="Paste address"
                style={[styles.paste, { borderColor: withAlpha(t.colors.primary, 0.3) }]}
              >
                <Text variant="caption" color="primary">
                  Paste
                </Text>
              </Pressable>
            }
          />
          <View style={styles.amountHead}>
            <Text variant="label">Amount</Text>
            <Text variant="bodySmall" color="mutedForeground" style={styles.avail}>
              Available ጠ{formatBalance(balance)} ·{' '}
              <Text variant="bodySmall" color="primary" style={styles.bold} onPress={() => setAmount(String(Math.floor(balance)))}>
                Max
              </Text>
            </Text>
          </View>
          <View
            style={[
              styles.amountBox,
              {
                backgroundColor: t.colors.inputBackground,
                borderColor: errors.amount ? t.colors.destructive : withAlpha(t.colors.primary, 0.4),
              },
            ]}
          >
            <Text style={[styles.big, { color: t.colors.primary }]}>ጠ</Text>
            <TextInput
              value={amount}
              onChangeText={(v) => {
                setAmount(v.replace(/[^0-9]/g, ''));
                if (errors.amount) setErrors((e) => ({ ...e, amount: undefined }));
              }}
              placeholder="0"
              placeholderTextColor={t.colors.mutedForeground}
              keyboardType="number-pad"
              selectionColor={t.colors.primary}
              style={[styles.big, styles.amountInput, { color: t.colors.foreground }]}
              accessibilityLabel="Amount in Munk tokens"
            />
            <Text variant="bodySmall" color="mutedForeground">
              ≈ ${toUsd(n || 0)}
            </Text>
          </View>
          {errors.amount ? (
            <Text variant="bodySmall" color="destructive" style={styles.err}>
              {errors.amount}
            </Text>
          ) : null}
          <Button title="Review transfer" onPress={review} style={styles.cta} />
        </View>
      ) : (
        <View style={styles.body}>
          <View
            style={[styles.summary, { borderColor: withAlpha(t.colors.primary, 0.14), backgroundColor: withAlpha(t.colors.primary, 0.06) }]}
          >
            <Row label="To" value={address.trim()} mono />
            <Row label="Amount" value={`ጠ${formatBalance(n)}  (≈ $${toUsd(n)})`} />
            <Row label="Balance after" value={`ጠ${formatBalance(balance - n)}`} />
          </View>
          <Text variant="bodySmall" color="mutedForeground">
            Transfers can’t be reversed. Double-check the address before sending.
          </Text>
          <Button title={`Send ጠ${formatBalance(n)}`} onPress={send} loading={sending} disabled={sending} style={styles.cta} />
          <Button
            title="Back"
            variant="ghost"
            onPress={() => setStep('form')}
            disabled={sending}
            leftIcon={<ArrowLeft size={16} color={t.colors.primary} strokeWidth={2.2} />}
          />
        </View>
      )}
    </Sheet>
  );
}

function Row({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <View style={styles.row}>
      <Text variant="caption" color="mutedForeground">
        {label}
      </Text>
      <Text variant="subtitle" selectable style={[styles.rowValue, mono && styles.mono]}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  body: { gap: 12 },
  paste: { height: 32, paddingHorizontal: 10, borderWidth: 1, justifyContent: 'center' },
  amountHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 4 },
  avail: { fontSize: 12, lineHeight: 16 },
  bold: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 12 },
  amountBox: { height: 64, paddingHorizontal: 16, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  big: { fontFamily: 'Grandstander-Bold', fontSize: 28, lineHeight: 34 },
  amountInput: { flex: 1, height: '100%', paddingVertical: 0 },
  err: { marginTop: -6 },
  cta: { marginTop: 6 },
  summary: { padding: 14, gap: 12, borderWidth: 1 },
  row: { gap: 3 },
  rowValue: { fontSize: 15, lineHeight: 20 },
  mono: { fontFamily: 'SpaceGrotesk-Medium', fontSize: 13 },
});
