import { ArrowDown, ArrowDownLeft, Plus, Send } from 'lucide-react-native';
import React from 'react';
import { StyleSheet, View } from 'react-native';

import { Skeleton, Text } from '@/components/ui';
import { formatBalance } from '@/lib/format';
import type { WalletActivity } from '@/services/payments';
import { useTheme, withAlpha } from '@/theme';

const TITLE: Record<WalletActivity['kind'], string> = {
  deposit: 'Deposit',
  withdrawal: 'Withdrawal',
  sent: 'Sent',
  received: 'Received',
};

function when(date: string) {
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return '';
  const today = new Date();
  const y = new Date();
  y.setDate(today.getDate() - 1);
  const time = d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  if (d.toDateString() === today.toDateString()) return `Today, ${time}`;
  if (d.toDateString() === y.toDateString()) return `Yesterday, ${time}`;
  return d.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: d.getFullYear() === today.getFullYear() ? undefined : 'numeric' });
}

export function ActivityRow({ item, divider }: { item: WalletActivity; divider?: boolean }) {
  const t = useTheme();
  const incoming = item.kind === 'deposit' || item.kind === 'received';
  const failed = item.status === 'failed';
  const Icon = item.kind === 'deposit' ? Plus : item.kind === 'withdrawal' ? ArrowDown : item.kind === 'sent' ? Send : ArrowDownLeft;
  const title =
    item.kind === 'sent' && item.detail ? `Sent to ${item.detail}` : item.kind === 'received' && item.detail ? `From ${item.detail}` : TITLE[item.kind];
  const sub = [item.kind === 'deposit' || item.kind === 'withdrawal' ? capital(item.detail) : 'Transfer', when(item.createdAt)].filter(Boolean).join(' · ');
  const statusColor = item.status === 'failed' ? t.colors.danger : item.status === 'pending' ? t.colors.warning : t.colors.success;

  return (
    <View
      style={[styles.row, divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }]}
      accessible
      accessibilityLabel={`${title}, ${incoming ? 'plus' : 'minus'} ${formatBalance(item.amount)} tokens${item.status ? `, ${item.status}` : ''}, ${when(item.createdAt)}`}
    >
      <View style={[styles.icon, { backgroundColor: withAlpha(t.colors.primary, 0.1) }]}>
        <Icon size={18} color={t.colors.primary} strokeWidth={2} />
      </View>
      <View style={styles.flex}>
        <Text variant="subtitle" numberOfLines={1} style={styles.title}>
          {title}
        </Text>
        <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.sub}>
          {sub}
        </Text>
      </View>
      <View style={styles.right}>
        <Text
          variant="subtitle"
          style={[
            styles.amount,
            { color: incoming && !failed ? t.colors.success : t.colors.foreground },
            failed && { textDecorationLine: 'line-through', opacity: 0.6 },
          ]}
        >
          {incoming ? '+' : '−'} ጠ{formatBalance(item.amount)}
        </Text>
        {item.status ? (
          <Text style={[styles.status, { color: statusColor }]}>{item.status}</Text>
        ) : null}
      </View>
    </View>
  );
}

export function ActivityRowSkeleton({ divider }: { divider?: boolean }) {
  const t = useTheme();
  return (
    <View style={[styles.row, divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }]}>
      <Skeleton width={38} height={38} radius={19} />
      <View style={[styles.flex, { gap: 6 }]}>
        <Skeleton width="55%" height={12} radius={3} />
        <Skeleton width="40%" height={10} radius={3} />
      </View>
      <Skeleton width={64} height={12} radius={3} />
    </View>
  );
}

function capital(s: string) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  row: { minHeight: 66, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12 },
  icon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 14, lineHeight: 19 },
  sub: { fontSize: 12, lineHeight: 16, marginTop: 2 },
  right: { alignItems: 'flex-end', gap: 2 },
  amount: { fontSize: 14, lineHeight: 19 },
  status: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 10, lineHeight: 13, letterSpacing: 0.8, textTransform: 'uppercase' },
});
