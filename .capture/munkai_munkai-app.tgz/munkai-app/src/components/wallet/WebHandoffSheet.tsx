import { ArrowUpRight, Check, Globe, Lock } from 'lucide-react-native';
import React from 'react';
import { Image, StyleSheet, View } from 'react-native';

import { Button, Sheet, Text, useToast } from '@/components/ui';
import { openExternal } from '@/lib/links';
import { WALLET_WEB_URL } from '@/lib/wallet';
import { useTheme, withAlpha } from '@/theme';

export type HandoffKind = 'deposit' | 'withdraw';

/**
 * Approved mock "Wallet · Add funds / Withdraw → website". Opens munkai.art in the phone's
 * browser (outside the app) and refreshes the wallet when the user comes back.
 */
export function WebHandoffSheet({ kind, onClose, onReturn }: { kind: HandoffKind | null; onClose: () => void; onReturn: () => void }) {
  const t = useTheme();
  const toast = useToast();
  const deposit = kind !== 'withdraw';

  const go = async () => {
    onClose();
    try {
      // Let the sheet finish closing before presenting the browser.
      await new Promise((r) => setTimeout(r, 300));
      await openExternal(WALLET_WEB_URL, onReturn);
    } catch {
      toast.error('Could not open munkai.art', 'Please try again.');
    }
  };

  const points = [
    { icon: Globe, text: 'Opens munkai.art in your browser.' },
    { icon: Lock, text: 'Sign in with the same Munkai account if asked.' },
    { icon: Check, text: 'Come back to the app when you’re done — your balance refreshes automatically.' },
  ];

  return (
    <Sheet visible={kind !== null} onClose={onClose}>
      <View style={styles.head}>
        <Image source={require('../../../assets/images/munk-coin.png')} style={styles.coin} />
        <View style={styles.flex}>
          <Text variant="heading" style={styles.title}>
            {deposit ? 'Add funds on munkai.art' : 'Withdraw on munkai.art'}
          </Text>
          <Text variant="bodySmall" color="mutedForeground">
            {deposit ? 'Payments are handled on our website.' : 'Payouts to your bank are handled on our website.'}
          </Text>
        </View>
      </View>
      <View style={[styles.box, { backgroundColor: withAlpha(t.colors.primary, 0.06), borderColor: withAlpha(t.colors.primary, 0.12) }]}>
        {points.map(({ icon: Icon, text }) => (
          <View key={text} style={styles.point}>
            <Icon size={18} color={t.colors.primary} strokeWidth={2} />
            <Text variant="bodySmall" style={styles.flex}>
              {text}
            </Text>
          </View>
        ))}
        {!deposit ? (
          <Text variant="bodySmall" color="mutedForeground" style={styles.tip}>
            On the website, open the Withdraw tab.
          </Text>
        ) : null}
      </View>
      <Button
        title="Continue to website"
        onPress={go}
        rightIcon={<ArrowUpRight size={16} color={t.colors.onPrimary} strokeWidth={2.4} />}
      />
      <Button title="Not now" variant="ghost" onPress={onClose} />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 16 },
  coin: { width: 56, height: 56 },
  title: { fontSize: 20, lineHeight: 26 },
  box: { padding: 14, gap: 10, borderWidth: 1, marginBottom: 16 },
  point: { flexDirection: 'row', gap: 10 },
  tip: { marginTop: 2, fontSize: 12 },
});
