import React from 'react';
import Svg, { Polygon } from 'react-native-svg';

import { useTheme } from '@/theme';

/** Brand blue of the "M" mark's right stem (from munkai-frontend/public/favicon.svg). */
export const MARK_ACCENT = '#4FA5D8';
/** Deep navy of the mark in the PWA icon (munkai-512x512.png). */
export const MARK_NAVY = '#01002A';

type Props = {
  size?: number;
  /** Override the main body color. Defaults to navy in light mode, white in dark mode. */
  color?: string;
  accentColor?: string;
};

/**
 * The Munkai "M" mark, vector-traced from the web favicon (viewBox 0 0 32 32).
 */
export function MunkaiMark({ size = 96, color, accentColor = MARK_ACCENT }: Props) {
  const t = useTheme();
  const body = color ?? (t.isDark ? '#FFFFFF' : MARK_NAVY);

  return (
    <Svg width={size} height={size} viewBox="1.8 2.2 28.4 27.5">
      <Polygon
        fill={body}
        points="30.2,2.2 23.4,2.2 16,9.6 8.6,2.2 1.8,2.2 1.8,22.6 8.9,29.7 8.9,12.6 16,19.7 23.1,12.6 23.1,12.7 30.2,5.6"
      />
      <Polygon fill={accentColor} points="23.1,12.6 23.1,29.7 30.2,22.5 30.2,5.6" />
    </Svg>
  );
}
