import { ArrowRight, ChevronRight, type LucideIcon } from 'lucide-react-native';
import React from 'react';
import { FlatList, Pressable, StyleSheet, View } from 'react-native';

import { Text } from '@/components/ui';
import { useTheme } from '@/theme';
import { fonts } from '@/theme/typography';
import { withAlpha } from '@/theme/colors';

type HeaderProps = {
  title: string;
  icon?: LucideIcon;
  onSeeAll?: () => void;
  /**
   * Kicker line above the title. When set, the header uses the web landing-page style
   * (`components/landingPage/*`: `flex-col items-end` below `md`): kicker, title and link
   * stacked and right-aligned over a thin primary rule.
   */
  eyebrow?: string;
  /** Tail of `title` drawn in the primary colour (web: `<span className="text-primary">`). Defaults to the last word. */
  accent?: string;
  /** Link text in the web style, e.g. "Discover More". */
  linkLabel?: string;
  /** Fill the kicker icon (web: `fill-primary` on Star / Zap / Flame). */
  iconFilled?: boolean;
};

export function SectionHeader(props: HeaderProps) {
  if (props.eyebrow) return <LandingHeader {...props} eyebrow={props.eyebrow} />;
  const { title, icon: Icon, onSeeAll } = props;
  const t = useTheme();
  return (
    <View style={styles.head}>
      {Icon ? <Icon size={18} color={t.colors.primary} strokeWidth={2} /> : null}
      <Text variant="heading" style={styles.title} accessibilityRole="header">
        {title}
      </Text>
      {onSeeAll ? (
        <Pressable onPress={onSeeAll} hitSlop={10} accessibilityRole="button" accessibilityLabel={`See all ${title}`} style={styles.seeAll}>
          <Text variant="subtitle" color="primary" style={styles.seeAllText}>
            See all
          </Text>
          <ChevronRight size={16} color={t.colors.primary} strokeWidth={2.2} />
        </Pressable>
      ) : null}
    </View>
  );
}

function LandingHeader({
  title,
  icon: Icon,
  onSeeAll,
  eyebrow,
  accent,
  linkLabel = 'Discover More',
  iconFilled,
}: HeaderProps & { eyebrow: string }) {
  const t = useTheme();
  const tail = accent && title.endsWith(accent) ? accent : title.split(' ').slice(-1)[0];
  const lead = title.slice(0, title.length - tail.length).trimEnd();
  return (
    <View style={[styles.lHead, { borderBottomColor: withAlpha(t.colors.primary, 0.2) }]}>
      <View style={styles.kicker}>
        {Icon ? <Icon size={12} color={t.colors.primary} fill={iconFilled ? t.colors.primary : 'none'} strokeWidth={2.4} /> : null}
        <Text variant="label" color="primary" style={styles.kickerText}>
          {eyebrow}
        </Text>
      </View>
      <Text variant="title" align="right" style={styles.lTitle} accessibilityRole="header">
        {lead ? `${lead} ` : ''}
        <Text variant="title" color="primary" style={styles.lAccent}>
          {tail}
        </Text>
      </Text>
      {onSeeAll ? (
        <Pressable
          onPress={onSeeAll}
          hitSlop={10}
          accessibilityRole="button"
          accessibilityLabel={`${linkLabel}, ${title}`}
          style={({ pressed }) => [styles.lLink, pressed && { opacity: 0.7 }]}
        >
          <Text color="primary" style={styles.lLinkText}>
            {linkLabel}
          </Text>
          <ArrowRight size={16} color={t.colors.primary} strokeWidth={2.2} />
        </Pressable>
      ) : null}
    </View>
  );
}

/**
 * Horizontal shelf: header + swipeable row. Shows `skeletonCount` placeholders while
 * loading, and hides itself entirely if the section comes back empty.
 */
export function Shelf<T>({
  title,
  icon,
  onSeeAll,
  eyebrow,
  accent,
  linkLabel,
  iconFilled,
  loading,
  data,
  renderItem,
  renderSkeleton,
  keyOf,
  skeletonCount = 4,
  gap = 12,
  header,
}: {
  title: string;
  icon?: LucideIcon;
  onSeeAll?: () => void;
  eyebrow?: string;
  accent?: string;
  linkLabel?: string;
  iconFilled?: boolean;
  loading: boolean;
  data: T[] | undefined;
  renderItem: (item: T, index: number) => React.ReactElement;
  renderSkeleton: (index: number) => React.ReactElement;
  keyOf: (item: T, index: number) => string;
  skeletonCount?: number;
  gap?: number;
  /** Extra content between the title and the row (e.g. genre chips). */
  header?: React.ReactNode;
}) {
  if (!loading && (!data || data.length === 0)) return null;
  return (
    <View>
      <SectionHeader
        title={title}
        icon={icon}
        onSeeAll={loading ? undefined : onSeeAll}
        eyebrow={eyebrow}
        accent={accent}
        linkLabel={linkLabel}
        iconFilled={iconFilled}
      />
      {header}
      {loading ? (
        <View style={[styles.row, { gap }]}>
          {Array.from({ length: skeletonCount }, (_, i) => (
            <React.Fragment key={i}>{renderSkeleton(i)}</React.Fragment>
          ))}
        </View>
      ) : (
        <FlatList
          horizontal
          data={data}
          keyExtractor={keyOf}
          renderItem={({ item, index }) => renderItem(item, index)}
          ItemSeparatorComponent={() => <View style={{ width: gap }} />}
          contentContainerStyle={styles.list}
          showsHorizontalScrollIndicator={false}
          decelerationRate="fast"
          initialNumToRender={4}
          windowSize={5}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  head: { paddingTop: 28, paddingBottom: 12, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 8 },
  title: { flex: 1, fontSize: 20, lineHeight: 26 },
  seeAll: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  seeAllText: { fontSize: 13, lineHeight: 18 },
  // Web landing header (below md): flex-col items-end, gap-4, pb-4, mb-6, border-b border-primary/20.
  lHead: { marginTop: 28, marginBottom: 16, marginHorizontal: 20, paddingBottom: 14, alignItems: 'flex-end', borderBottomWidth: 1 },
  kicker: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  kickerText: { textAlign: 'right' },
  lTitle: { fontSize: 28, lineHeight: 34, marginTop: 4 },
  lAccent: { fontSize: 28, lineHeight: 34 },
  lLink: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12 },
  lLinkText: { fontFamily: fonts.bodySemiBold, fontSize: 14, lineHeight: 18, letterSpacing: 0.7, textTransform: 'uppercase' },
  row: { flexDirection: 'row', paddingHorizontal: 20, overflow: 'hidden' },
  list: { paddingHorizontal: 20 },
});
