import { Bookmark, BookmarkCheck } from 'lucide-react-native';
import { Image } from 'expo-image';
import React, { useId, useRef, useState } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, useWindowDimensions, View, type ViewToken } from 'react-native';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { Button, Skeleton, Text } from '@/components/ui';
import { genres, openPublication, typeLabel } from '@/lib/publication';
import type { Publication } from '@/services/types';
import { toggleSaved, useIsSaved } from '@/store/saved';
import { useTheme, withAlpha } from '@/theme';

import { Badge } from './cards';
import { Cover } from './Cover';

const HEIGHT = 470;

/** Featured publications, swipe between them (approved mock: Home hero). */
export function HeroCarousel({ items }: { items: Publication[] }) {
  const t = useTheme();
  const { width } = useWindowDimensions();
  const cardW = width - 40;
  const [index, setIndex] = useState(0);
  const onViewable = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    const first = viewableItems[0];
    if (first?.index != null) setIndex(first.index);
  }).current;

  return (
    <View>
      <FlatList
        horizontal
        data={items}
        keyExtractor={(p) => String(p.id)}
        renderItem={({ item }) => <HeroCard pub={item} width={cardW} />}
        ItemSeparatorComponent={() => <View style={{ width: 12 }} />}
        contentContainerStyle={styles.list}
        showsHorizontalScrollIndicator={false}
        snapToInterval={cardW + 12}
        decelerationRate="fast"
        onViewableItemsChanged={onViewable}
        viewabilityConfig={{ itemVisiblePercentThreshold: 60 }}
      />
      {items.length > 1 ? (
        <View style={styles.dots} accessibilityLabel={`Featured ${index + 1} of ${items.length}`}>
          {items.slice(0, 8).map((p, i) => (
            <View
              key={String(p.id)}
              style={[
                styles.dot,
                {
                  backgroundColor: i === index ? t.colors.primary : withAlpha(t.colors.primary, 0.3),
                },
                i === index && styles.dotOn,
              ]}
            />
          ))}
        </View>
      ) : null}
    </View>
  );
}

function HeroCard({ pub, width }: { pub: Publication; width: number }) {
  const t = useTheme();
  const saved = useIsSaved(pub);
  const tags = [typeLabel(pub.publicationType), ...genres(pub).slice(0, 1)].filter(Boolean);
  const coverW = 152;
  // Unique per mounted card — duplicate SVG gradient ids render blank on native.
  const gid = `hg${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const uri = pub.coverPhoto || undefined;
  const logError = (e: { error?: string }) => {
    if (__DEV__) console.warn(`[Munkai] featured cover failed: ${uri} — ${e?.error ?? ''}`);
  };
  return (
    <View style={[styles.card, { width }]}>
      {/* Blurred art behind everything */}
      {uri ? (
        <Image
          source={{ uri }}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          blurRadius={Platform.OS === 'android' ? 16 : 28}
          cachePolicy="memory-disk"
          onError={logError}
        />
      ) : null}
      <View style={[StyleSheet.absoluteFill, { backgroundColor: withAlpha('#00002B', 0.4) }]} />
      <Svg width={width} height={HEIGHT} style={StyleSheet.absoluteFill} pointerEvents="none">
        <Defs>
          <LinearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0.35" stopColor="#00002B" stopOpacity={0} />
            <Stop offset="1" stopColor="#00002B" stopOpacity={0.96} />
          </LinearGradient>
        </Defs>
        <Rect x="0" y="0" width={width} height={HEIGHT} fill={`url(#${gid})`} />
      </Svg>

      {/* Whole card opens the publication; the buttons below sit on top of this. */}
      <Pressable
        onPress={() => openPublication(pub)}
        accessibilityRole="button"
        accessibilityLabel={`Featured: ${pub.name}`}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.kicker} pointerEvents="none">
        <Badge label="Featured" />
      </View>
      <View style={[styles.cover, { left: (width - coverW) / 2, width: coverW }]} pointerEvents="none">
        {uri ? (
          <Image source={{ uri }} style={styles.coverImg} contentFit="cover" transition={200} cachePolicy="memory-disk" onError={logError} />
        ) : (
          <Cover width={coverW} height={214} />
        )}
      </View>
      <View style={styles.body} pointerEvents="box-none">
        <View style={styles.bodyText} pointerEvents="none">
          <View style={styles.tags}>
            {tags.map((g) => (
              <View key={g} style={[styles.tag, { backgroundColor: withAlpha(t.colors.primary, 0.18) }]}>
                <Text style={[styles.tagText, { color: '#87CEEB' }]}>{g}</Text>
              </View>
            ))}
            {pub.isCompleted === false ? (
              <View style={[styles.tag, { backgroundColor: withAlpha('#FFC400', 0.16) }]}>
                <Text style={[styles.tagText, { color: '#FFC400' }]}>Ongoing</Text>
              </View>
            ) : null}
          </View>
          <Text variant="title" numberOfLines={2} style={styles.title}>
            {pub.name}
          </Text>
          {pub.shortSummary || pub.summary ? (
            <Text variant="bodySmall" numberOfLines={2} style={styles.summary}>
              {pub.shortSummary || pub.summary}
            </Text>
          ) : null}
        </View>
        <View style={styles.actions}>
          <Button title="Read now" onPress={() => openPublication(pub)} style={styles.flex} />
          <Pressable
            onPress={() => toggleSaved(pub, saved)}
            accessibilityRole="button"
            accessibilityLabel={saved ? 'Remove from saved' : 'Save'}
            accessibilityState={{ selected: saved }}
            style={({ pressed }) => [styles.save, { borderColor: withAlpha('#87CEEB', 0.5) }, pressed && { opacity: 0.7 }]}
          >
            {saved ? <BookmarkCheck size={20} color="#87CEEB" strokeWidth={2.2} /> : <Bookmark size={20} color="#87CEEB" strokeWidth={2} />}
          </Pressable>
        </View>
      </View>
    </View>
  );
}

export function HeroCarouselSkeleton() {
  const { width } = useWindowDimensions();
  return (
    <View style={styles.list}>
      <Skeleton width={width - 40} height={HEIGHT} />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  list: { paddingHorizontal: 20 },
  card: { height: HEIGHT, overflow: 'hidden', backgroundColor: '#121637' },
  coverImg: { width: 152, height: 214, backgroundColor: '#1B2147' },
  kicker: { position: 'absolute', top: 16, left: 16 },
  cover: {
    position: 'absolute',
    top: 34,
    height: 214,
    backgroundColor: '#1B2147',
    shadowColor: '#000',
    shadowOpacity: 0.6,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 14 },
    elevation: 10,
  },
  body: { position: 'absolute', left: 18, right: 18, bottom: 18, gap: 12 },
  bodyText: { gap: 8 },
  tags: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  tag: { paddingHorizontal: 6, paddingVertical: 2 },
  tagText: {
    fontFamily: 'SpaceGrotesk-Bold',
    fontSize: 9,
    lineHeight: 13,
    letterSpacing: 0.9,
    textTransform: 'uppercase',
  },
  title: { fontSize: 26, lineHeight: 30, color: '#F2F2F2' },
  summary: { color: '#C9CCD6', fontSize: 13, lineHeight: 18 },
  actions: { flexDirection: 'row', gap: 10, marginTop: 4 },
  save: {
    width: 54,
    height: 54,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    paddingTop: 12,
  },
  dot: { width: 6, height: 6, borderRadius: 3 },
  dotOn: { width: 18 },
});
