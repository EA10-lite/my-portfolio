import { Image } from 'expo-image';
import React, { useState } from 'react';
import { StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';

import { MunkaiMark } from '@/components/brand/MunkaiMark';
import { useTheme, withAlpha } from '@/theme';

/** Publication / chapter cover art. Cached, fades in, and falls back to the brand mark. */
export function Cover({
  uri,
  width,
  height,
  style,
  blur,
  children,
}: {
  uri?: string | null;
  width?: number | `${number}%`;
  height?: number;
  style?: StyleProp<ViewStyle>;
  blur?: number;
  children?: React.ReactNode;
}) {
  const t = useTheme();
  const [failed, setFailed] = useState(false);
  const showImage = !!uri && !failed;
  return (
    <View style={[styles.box, { width, height, backgroundColor: withAlpha(t.colors.primary, t.isDark ? 0.1 : 0.14) }, style]}>
      {showImage ? (
        <Image
          source={{ uri }}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          transition={200}
          cachePolicy="memory-disk"
          recyclingKey={uri}
          blurRadius={blur}
          onError={(e) => {
            if (__DEV__) console.warn(`[Munkai] cover failed: ${uri} — ${e?.error ?? ''}`);
            setFailed(true);
          }}
          accessibilityIgnoresInvertColors
        />
      ) : (
        <View style={styles.fallback}>
          <MunkaiMark size={28} color={withAlpha(t.colors.foreground, 0.35)} accentColor={withAlpha(t.colors.primary, 0.5)} />
        </View>
      )}
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  box: { overflow: 'hidden' },
  fallback: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
});
