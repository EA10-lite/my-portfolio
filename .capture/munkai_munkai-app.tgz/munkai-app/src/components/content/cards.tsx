/**
 * Feed cards shared by Home, Explore and Library — each with a matching skeleton
 * so every section keeps its shape while loading.
 */
import { BookmarkCheck } from 'lucide-react-native';
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';

import { Avatar, ReadTag, Skeleton, Text } from '@/components/ui';
import { formatCompact } from '@/lib/format';
import { creatorWorks, openChapter, openCreator, openPublication, pubMeta, timeAgo, typeLabel } from '@/lib/publication';
import type { Publication, RecentChapter, TopCreator } from '@/services/types';
import { useTheme, withAlpha } from '@/theme';

import { Cover } from './Cover';

const RATIO = 1.43; // 2:3-ish, matches the web's aspect-2/3 covers

/* ---------------------------------- badges --------------------------------- */

export function Badge({ label, tone = 'primary' }: { label: string; tone?: 'primary' | 'free' | 'done' | 'dark' | 'fan' }) {
  const t = useTheme();
  const map = {
    primary: { bg: t.colors.primary, fg: t.colors.onPrimary },
    free: { bg: t.colors.success, fg: '#00210E' },
    done: { bg: withAlpha('#00002B', 0.8), fg: t.colors.success },
    dark: { bg: withAlpha('#00002B', 0.8), fg: '#F2F2F2' },
    fan: { bg: t.colors.neonCyan, fg: '#00002B' },
  }[tone];
  return (
    <View style={[styles.badge, { backgroundColor: map.bg }]}>
      <Text style={[styles.badgeText, { color: map.fg }]}>{label}</Text>
    </View>
  );
}

/* ------------------------------- publication -------------------------------- */

export function PublicationCard({
  pub,
  width,
  free,
  saved,
  showMeta = true,
}: {
  pub: Publication;
  width: number;
  free?: boolean;
  saved?: boolean;
  showMeta?: boolean;
}) {
  const t = useTheme();
  const fan = !!pub.isFanfic;
  return (
    <Pressable
      onPress={() => openPublication(pub)}
      accessibilityRole="button"
      accessibilityLabel={[pub.name, typeLabel(pub.publicationType)].filter(Boolean).join(', ')}
      style={({ pressed }) => [{ width }, pressed && styles.pressed]}
    >
      <Cover uri={pub.coverPhoto} width={width} height={Math.round(width * RATIO)}>
        {fan ? (
          <View style={styles.tl}>
            <Badge label="Fan TL" tone="fan" />
          </View>
        ) : null}
        {saved ? (
          <View style={[styles.tr, styles.savedIcon]}>
            <BookmarkCheck size={14} color={t.colors.primary} strokeWidth={2.2} />
          </View>
        ) : pub.isCompleted ? (
          <View style={styles.tr}>
            <Badge label="Done" tone="done" />
          </View>
        ) : null}
        {free ? (
          <View style={styles.bl}>
            <Badge label="Free" tone="free" />
          </View>
        ) : null}
      </Cover>
      <Text variant="subtitle" numberOfLines={2} style={styles.cardTitle}>
        {pub.name}
      </Text>
      {showMeta ? (
        <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.meta}>
          {pubMeta(pub)}
        </Text>
      ) : null}
    </Pressable>
  );
}

export function PublicationCardSkeleton({ width, meta = true }: { width: number; meta?: boolean }) {
  return (
    <View style={{ width, gap: 6 }}>
      <Skeleton width={width} height={Math.round(width * RATIO)} />
      <Skeleton width={width * 0.85} height={12} radius={3} />
      {meta ? <Skeleton width={width * 0.55} height={10} radius={3} /> : null}
    </View>
  );
}

/* --------------------------------- chapter ---------------------------------- */

export function ChapterCard({ ch, width = 140 }: { ch: RecentChapter; width?: number }) {
  const free = !Number(ch.price);
  const owned = !!ch.isCollected;
  return (
    <Pressable
      onPress={() => openChapter(ch)}
      accessibilityRole="button"
      accessibilityLabel={`${ch.publicationName}, chapter ${ch.chapterNumber}${owned ? ', owned' : free ? ', free — read now' : `, ${ch.price} tokens`}`}
      style={({ pressed }) => [{ width }, pressed && styles.pressed]}
    >
      <Cover uri={ch.coverPhoto} width={width} height={Math.round(width * 1.36)}>
        <View style={styles.tl}>
          <Badge label={`Ch. ${ch.chapterNumber}`} tone="dark" />
        </View>
        <View style={styles.br}>
          {free && !owned ? (
            <ReadTag onImage />
          ) : (
            <Badge label={owned ? 'Owned' : `ጠ ${formatCompact(ch.price)}`} tone={owned ? 'dark' : 'primary'} />
          )}
        </View>
      </Cover>
      <Text variant="subtitle" numberOfLines={1} style={styles.cardTitle}>
        {ch.publicationName}
      </Text>
      <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.meta}>
        {[ch.username ? `@${ch.username}` : null, timeAgo(ch.createdAt)].filter(Boolean).join(' · ')}
      </Text>
    </Pressable>
  );
}

export function ChapterCardSkeleton({ width = 140 }: { width?: number }) {
  return (
    <View style={{ width, gap: 6 }}>
      <Skeleton width={width} height={Math.round(width * 1.36)} />
      <Skeleton width={width * 0.8} height={12} radius={3} />
      <Skeleton width={width * 0.55} height={10} radius={3} />
    </View>
  );
}

/* --------------------------------- creator ---------------------------------- */

export function CreatorCard({ c }: { c: TopCreator }) {
  const t = useTheme();
  const works = creatorWorks(c);
  return (
    <Pressable
      onPress={() => openCreator(c)}
      accessibilityRole="button"
      accessibilityLabel={`${c.firstName} ${c.lastName}, ${works} works`}
      style={({ pressed }) => [styles.creator, pressed && styles.pressed]}
    >
      <View style={[styles.creatorRing, { borderColor: withAlpha(t.colors.primary, 0.4) }]}>
        <Avatar uri={c.profileImage} firstName={c.firstName} lastName={c.lastName} seed={c.username} size={64} />
      </View>
      <Text variant="subtitle" numberOfLines={2} align="center" style={styles.creatorName}>
        {`${c.firstName} ${c.lastName}`.trim() || c.username}
      </Text>
      <Text variant="bodySmall" color="mutedForeground" style={styles.meta}>
        {works} {works === 1 ? 'work' : 'works'}
      </Text>
    </Pressable>
  );
}

export function CreatorCardSkeleton() {
  return (
    <View style={[styles.creator, { gap: 8 }]}>
      <Skeleton width={70} height={70} radius={35} />
      <Skeleton width={60} height={11} radius={3} />
      <Skeleton width={40} height={9} radius={3} />
    </View>
  );
}

/* --------------------------------- trending --------------------------------- */

const RANK = ['#FFC400', '#C0C8D6', '#E3945A'];

export function TrendingRow({ pub, rank, divider }: { pub: Publication; rank: number; divider?: boolean }) {
  const t = useTheme();
  const color = RANK[rank - 1] ?? t.colors.mutedForeground;
  return (
    <Pressable
      onPress={() => openPublication(pub)}
      accessibilityRole="button"
      accessibilityLabel={`Number ${rank}, ${pub.name}`}
      style={({ pressed }) => [
        styles.trend,
        divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
        pressed && { backgroundColor: withAlpha(t.colors.primary, 0.05) },
      ]}
    >
      <Text style={[styles.rank, { color, textShadowColor: withAlpha(color, 0.45) }]}>{rank}</Text>
      <Cover uri={pub.coverPhoto} width={48} height={66} />
      <View style={styles.flex}>
        <Text variant="subtitle" numberOfLines={1} style={styles.trendTitle}>
          {pub.name}
        </Text>
        <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.meta}>
          {pubMeta(pub)}
        </Text>
        {pub.shortSummary ? (
          <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={[styles.meta, { opacity: 0.8 }]}>
            {pub.shortSummary}
          </Text>
        ) : null}
      </View>
    </Pressable>
  );
}

export function TrendingRowSkeleton({ divider }: { divider?: boolean }) {
  const t = useTheme();
  return (
    <View style={[styles.trend, divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }]}>
      <Skeleton width={22} height={28} radius={4} />
      <Skeleton width={48} height={66} />
      <View style={[styles.flex, { gap: 6 }]}>
        <Skeleton width="70%" height={12} radius={3} />
        <Skeleton width="45%" height={10} radius={3} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
  badge: { paddingHorizontal: 6, paddingVertical: 2 },
  badgeText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 9, lineHeight: 13, letterSpacing: 0.9, textTransform: 'uppercase' },
  tl: { position: 'absolute', top: 6, left: 6 },
  tr: { position: 'absolute', top: 6, right: 6 },
  bl: { position: 'absolute', bottom: 6, left: 6 },
  br: { position: 'absolute', bottom: 6, right: 6 },
  savedIcon: { width: 26, height: 26, backgroundColor: 'rgba(0,0,43,0.75)', alignItems: 'center', justifyContent: 'center' },
  cardTitle: { fontSize: 13, lineHeight: 17, marginTop: 7 },
  meta: { fontSize: 11, lineHeight: 15, marginTop: 1 },
  creator: { width: 80, alignItems: 'center' },
  creatorRing: { padding: 2, borderRadius: 36, borderWidth: 1.5 },
  creatorName: { fontSize: 12, lineHeight: 15, marginTop: 6 },
  trend: { minHeight: 88, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 14 },
  rank: {
    width: 24,
    fontFamily: 'Grandstander-Bold',
    fontSize: 30,
    lineHeight: 36,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 12,
  },
  trendTitle: { fontSize: 15, lineHeight: 20 },
});
