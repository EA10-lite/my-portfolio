/**
 * "An update is ready" sheet — canvas variant B (Update · Available, dismissible).
 * Mounted once over the main tabs; driven by lib/appUpdate (GET /api/app/version).
 */
import { Check, Download } from 'lucide-react-native';
import React from 'react';
import { Linking, StyleSheet, View } from 'react-native';

import { MunkaiMark } from '@/components/brand/MunkaiMark';
import { Button, CutShape, Sheet, Text } from '@/components/ui';
import { useAppUpdate } from '@/lib/appUpdate';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

export function UpdateSheet() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const { update, dismiss, close } = useAppUpdate();
  const notes = (update?.releaseNotes ?? []).filter(Boolean).slice(0, 3);

  const open = () => {
    if (update?.storeUrl) Linking.openURL(update.storeUrl).catch(() => {});
    // Keep it out of the way for this session; it comes back next launch if they didn't update.
    close();
  };

  return (
    <Sheet visible={!!update} onClose={dismiss} accessibilityLabel="An update is ready">
      <View style={styles.body}>
        <View style={styles.head}>
          <View style={[styles.logo, { borderColor: withAlpha(t.colors.primary, 0.3) }]}>
            <MunkaiMark size={28} color={t.colors.foreground} />
          </View>
          <View style={styles.flex}>
            <Text variant="label" color="primary" style={styles.kicker}>
              New version · {update?.latestVersion}
            </Text>
            <Text variant="heading" style={styles.title} accessibilityRole="header">
              An update is ready
            </Text>
          </View>
        </View>

        <Text variant="bodySmall" color="mutedForeground" style={styles.lead}>
          Get the latest Munkai from the store. It only takes a moment and you’ll stay signed in.
        </Text>

        {notes.length ? (
          <CutShape
            cuts={t.cuts.card}
            fill={withAlpha(t.colors.primary, 0.06)}
            stroke={withAlpha(t.colors.primary, 0.12)}
            style={styles.notes}
          >
            <Text variant="caption" color="mutedForeground" style={styles.notesTitle}>
              What’s new
            </Text>
            {notes.map((n) => (
              <View key={n} style={styles.note}>
                <Check size={16} color={t.colors.primary} strokeWidth={2.4} style={styles.noteIcon} />
                <Text variant="bodySmall" style={styles.flex}>
                  {n}
                </Text>
              </View>
            ))}
          </CutShape>
        ) : null}

        <Button title="Update" fullWidth leftIcon={<Download size={16} color={t.colors.onPrimary} strokeWidth={2.4} />} onPress={open} />
        <Button title="Later" variant="ghost" fullWidth onPress={dismiss} />
      </View>
    </Sheet>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    flex: { flex: 1 },
    body: { gap: 14, paddingTop: 4 },
    head: { flexDirection: 'row', alignItems: 'center', gap: 14 },
    logo: {
      width: 56,
      height: 56,
      borderRadius: 16,
      borderWidth: 1,
      backgroundColor: t.colors.pageBackground,
      alignItems: 'center',
      justifyContent: 'center',
    },
    kicker: { fontSize: 11, letterSpacing: 1.6 },
    title: { fontSize: 22, lineHeight: 26, marginTop: 2 },
    lead: { lineHeight: 21 },
    notes: { paddingVertical: 14, paddingHorizontal: 16, gap: 10 },
    notesTitle: { letterSpacing: 1.6 },
    note: { flexDirection: 'row', gap: 10 },
    noteIcon: { marginTop: 2 },
  });
