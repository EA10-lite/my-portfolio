import { useEffect, useRef } from 'react';
import { Animated, Easing, Keyboard, Platform, type KeyboardEvent } from 'react-native';

/**
 * How far the keyboard covers the bottom of the screen, as an Animated value (0 when hidden).
 * Use it as paddingBottom on a footer pinned to the bottom, so the footer sits exactly on top
 * of the keyboard.
 *
 * Why not KeyboardAvoidingView: with Android edge-to-edge (default since SDK 54) the window no
 * longer resizes, and `behavior="height"` mis-measures by the navigation bar height — that's what
 * left the auth button half under / half over the keyboard. On Android, RN reports the keyboard
 * height *without* the nav bar, so we add the bottom inset back.
 */
export function useKeyboardInset(bottomInset: number) {
  const value = useRef(new Animated.Value(0)).current;
  const inset = useRef(bottomInset);
  inset.current = bottomInset;

  useEffect(() => {
    const ios = Platform.OS === 'ios';
    const animate = (to: number, e?: KeyboardEvent) =>
      Animated.timing(value, {
        toValue: to,
        duration: ios ? (e?.duration ?? 250) : 160,
        easing: ios ? Easing.bezier(0.17, 0.59, 0.4, 0.77) : Easing.out(Easing.quad),
        useNativeDriver: false,
      }).start();
    const show = Keyboard.addListener(ios ? 'keyboardWillShow' : 'keyboardDidShow', (e) =>
      animate(ios ? e.endCoordinates.height : e.endCoordinates.height + inset.current, e),
    );
    const hide = Keyboard.addListener(ios ? 'keyboardWillHide' : 'keyboardDidHide', (e) => animate(0, e));
    return () => {
      show.remove();
      hide.remove();
    };
  }, [value]);

  return value;
}
