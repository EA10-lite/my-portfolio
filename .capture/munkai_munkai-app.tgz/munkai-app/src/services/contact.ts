import { api } from '@/lib/api';

import type { ApiEnvelope } from './types';

/** Same values the web form sends. */
export type ContactType = 'Inquiry' | 'Feedback' | 'Complaint';

export type ContactAttachment = { uri: string; name: string; type: string; size?: number };

export type ContactInput = {
  name: string;
  email: string;
  type: ContactType;
  subject: string;
  message: string;
  attachment?: ContactAttachment | null;
};

/** Matches munkai-frontend/src/services/api/contacts.ts. */
export const contactApi = {
  /** POST /api/contacts/submit (multipart). Attachment: image or PDF, max 10MB. */
  submit: async (input: ContactInput) => {
    const form = new FormData();
    form.append('name', input.name);
    form.append('email', input.email);
    form.append('type', input.type);
    form.append('subject', input.subject);
    form.append('message', input.message);
    // React Native's FormData accepts { uri, name, type } file parts.
    if (input.attachment) {
      const { uri, name, type } = input.attachment;
      form.append('attachment', { uri, name, type } as unknown as Blob);
    }
    const res = await api.post<ApiEnvelope<unknown>>('/api/contacts/submit', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 60000,
    });
    return res.data;
  },
};
