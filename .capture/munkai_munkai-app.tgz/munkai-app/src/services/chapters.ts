import { api, fetchAllPages } from '@/lib/api';

import type { ChapterContent, ChapterIndexEntry, UncollectedInfo } from './types';

function unwrap<T>(body: unknown): T {
  if (body && typeof body === 'object' && !Array.isArray(body) && 'data' in body) return (body as { data: T }).data;
  return body as T;
}

/** Endpoints match munkai-frontend origin/main src/services/api/chapters.ts. */
export const chaptersApi = {
  /** GET /api/chapters/list?publicationId&order — whole index (paged under the hood). */
  index: (publicationId: string | number, order: 'asc' | 'desc' = 'desc') =>
    fetchAllPages<ChapterIndexEntry>('/api/chapters/list', { publicationId, order, limit: 200 }, 20),

  /** GET /api/chapters/read?chapterId&v */
  read: async (chapterId: string | number, version?: number) =>
    unwrap<ChapterContent>((await api.get('/api/chapters/read', { params: { chapterId, v: version } })).data),

  /** POST /api/chapters/collect */
  collect: async (chapterId: string | number) => (await api.post('/api/chapters/collect', { chapterId: String(chapterId) })).data,

  /** GET /api/chapters/collect-all?publicationId */
  uncollected: async (publicationId: string | number) => {
    const d = unwrap<Partial<UncollectedInfo>>((await api.get('/api/chapters/collect-all', { params: { publicationId } })).data) ?? {};
    return { uncollectedCount: d.uncollectedCount ?? 0, totalPrice: d.totalPrice ?? 0, chapters: d.chapters ?? [] } as UncollectedInfo;
  },

  /** POST /api/chapters/collect-all */
  collectAll: async (publicationId: string | number) =>
    unwrap<{ totalAmountPaid?: number }>((await api.post('/api/chapters/collect-all', { publicationId: String(publicationId) })).data),
};

/** munkai-frontend lib/chapter-content.ts — prose, a PDF link, or a JSON list of page images. */
export type ParsedContent = { kind: 'text'; html: string } | { kind: 'pdf'; url: string } | { kind: 'images'; pages: string[] };

export function parseChapterContent(content: string | null | undefined): ParsedContent {
  const raw = (content ?? '').trim();
  if (!raw) return { kind: 'text', html: '' };
  if (raw.startsWith('[')) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed.every((p) => typeof p === 'string' && /^(https?|file):/.test(p))) {
        return { kind: 'images', pages: parsed };
      }
    } catch {
      // not JSON
    }
  }
  if (/^(https?|file):/.test(raw)) return { kind: 'pdf', url: raw };
  return { kind: 'text', html: raw };
}
