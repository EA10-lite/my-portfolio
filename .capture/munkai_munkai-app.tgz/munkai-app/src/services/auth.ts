import { api } from '@/lib/api';

import type { ApiEnvelope, AuthPayload, User } from './types';

/** Endpoints and payloads match munkai-frontend/src/services/api/auth.ts exactly. */

export type LoginInput = { emailOrUsername: string; password: string };

export type RegisterInput = {
  firstName: string;
  lastName: string;
  email: string;
  username: string;
  password: string;
  confirmPassword: string;
  code: string;
  referralCode?: string;
};

export type MigrateInput = {
  emailOrUsername: string;
  newEmail: string;
  password: string;
  confirmPassword: string;
  code: string;
};

export const authApi = {
  login: async (input: LoginInput) =>
    (await api.post<AuthPayload>('/api/auth/login', input, { skipAuth: true })).data,

  register: async (input: RegisterInput) =>
    (await api.post<AuthPayload>('/api/auth/register', input, { skipAuth: true })).data,

  /** Sends the 6-digit email verification code (also used by Restore Account). */
  sendVerificationCode: async (email: string) =>
    (await api.post('/api/auth/verify-email/resend', { email }, { skipAuth: true })).data,

  forgotPassword: async (email: string) =>
    (await api.post('/api/auth/password-reset/forgot', { email }, { skipAuth: true })).data,

  migrate: async (input: MigrateInput) =>
    (await api.post<AuthPayload>('/api/auth/migrate', input, { skipAuth: true })).data,

  /** POST /api/auth/password-reset/reset — `code` comes from the emailed link. */
  resetPassword: async (input: { password: string; confirmPassword: string; code: string }) =>
    (await api.post('/api/auth/password-reset/reset', input, { skipAuth: true })).data,

  logout: async () => (await api.post('/api/auth/logout')).data,

  profile: async () => (await api.get<ApiEnvelope<User>>('/api/users/profile')).data.data,
};
