import { api, fetchAllPages, fetchPage } from '@/lib/api';

import type { CreatorDetails, LandingData, Publication, RecentChapter, TopCreator } from './types';

/** Unwrap `{ data: X }`, `{ data: { data: X } }` or a bare X — the backend isn't consistent. */
function unwrap<T>(body: unknown): T {
  let cur: unknown = body;
  for (let i = 0; i < 2; i++) {
    if (cur && typeof cur === 'object' && !Array.isArray(cur) && 'data' in (cur as object)) {
      cur = (cur as { data: unknown }).data;
    } else break;
  }
  return cur as T;
}

const arr = <T>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);

/** Endpoints match munkai-frontend/src/services/api/{landing,publications}.ts. */
export const contentApi = {
  /** GET /api/landing — everything the Home feed shows. */
  landing: async (): Promise<LandingData> => {
    const res = await api.get('/api/landing');
    // Web: `response.data?.data ? response.data : response` then reads `.data.<field>`.
    const d = unwrap<Partial<LandingData>>(res.data) ?? {};
    return {
      freePublications: arr(d.freePublications),
      munkaiPicks: arr(d.munkaiPicks),
      featuredPublications: arr(d.featuredPublications),
      topCreators: arr(d.topCreators),
      recentChapters: arr(d.recentChapters),
      trendingPublications: arr(d.trendingPublications),
      // origin/main renamed fanTranslations → fanfics; accept either.
      fanfics: arr(d.fanfics ?? (d as { fanTranslations?: unknown }).fanTranslations),
      completedPublications: arr(d.completedPublications),
      genreSpotlights: d.genreSpotlights && typeof d.genreSpotlights === 'object' ? d.genreSpotlights : {},
      stats: d.stats,
    };
  },

  /** GET /api/publications (cursor-paginated) — one page, for infinite lists. */
  publicationsPage: (params: { cursor?: string; limit?: number; featured?: boolean; munkaipick?: boolean; free?: boolean; type?: string; genre?: string } = {}) =>
    fetchPage<Publication>('/api/publications', { limit: 30, ...params }),

  /** Every publication (search screen filters the whole catalogue, like the web). */
  allPublications: () => fetchAllPages<Publication>('/api/publications', { limit: 100 }, 10),

  /** GET /api/publications/:idOrSlug */
  publication: async (idOrSlug: string | number): Promise<Publication> => unwrap<Publication>((await api.get(`/api/publications/${idOrSlug}`)).data),

  /** GET /api/publications/related */
  related: async (publicationId: string | number, limit = 8) =>
    arr<Publication>(unwrap((await api.get('/api/publications/related', { params: { publicationId, limit } })).data)),

  /** GET /api/publications/creator/:idOrUsername → { creatorDetails, publications } */
  creator: async (idOrUsername: string | number) => {
    const d = unwrap<{ creatorDetails?: CreatorDetails; publications?: Publication[] }>(
      (await api.get(`/api/publications/creator/${idOrUsername}`)).data,
    );
    return { creator: d?.creatorDetails ?? null, publications: arr<Publication>(d?.publications) };
  },

  /** GET /api/chapters (cursor-paginated) — newest chapters across the platform. */
  chaptersPage: (cursor?: string) => fetchPage<RecentChapter>('/api/chapters', { limit: 30, cursor }),

  /** GET /api/creators/top (paginated) */
  topCreators: () => fetchAllPages<TopCreator>('/api/creators/top', { limit: 100 }, 3),

  /** POST /api/publications/saved */
  save: async (publicationId: string | number) => (await api.post('/api/publications/saved', { publicationId })).data,

  /** DELETE /api/publications/saved */
  unsave: async (publicationId: string | number) =>
    (await api.delete('/api/publications/saved', { data: { publicationId } })).data,
};
