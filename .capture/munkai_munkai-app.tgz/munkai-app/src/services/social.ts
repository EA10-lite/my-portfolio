import { api, fetchPage } from '@/lib/api';

import type { AppNotification, Comment } from './types';

function unwrap<T>(body: unknown): T {
  if (body && typeof body === 'object' && !Array.isArray(body) && 'data' in body) return (body as { data: T }).data;
  return body as T;
}

/** Endpoints match munkai-frontend origin/main comments.ts, notifications.ts, reports.ts. */
export const commentsApi = {
  list: async (chapterId: string | number): Promise<Comment[]> => {
    const d = unwrap<Comment[] | { items?: Comment[] }>((await api.get('/api/comments', { params: { chapterId } })).data);
    return Array.isArray(d) ? d : (d?.items ?? []);
  },
  replies: (commentId: number, cursor?: string) => fetchPage<Comment>(`/api/comments/${commentId}/replies`, { limit: 20, cursor }),
  create: async (input: { content: string; chapterId: string | number; parentCommentId?: number; replyingToUserId?: number }) =>
    (await api.post('/api/comments', { ...input, chapterId: Number(input.chapterId) })).data,
  remove: async (id: number) => (await api.delete(`/api/comments/${id}`)).data,
  toggleLike: async (id: number) => unwrap<{ liked?: boolean; likes?: number }>((await api.post(`/api/comments/${id}/like`)).data),
};

export type ReportType = 'comment' | 'publication' | 'chapter' | 'creator';
export const reportsApi = {
  report: async (type: ReportType, targetId: number, reason: string) => (await api.post('/api/reports', { type, targetId, reason })).data,
};

export type NotificationPage = { items: AppNotification[]; unreadCount: number; total: number; page: number; totalPages: number };

export const notificationsApi = {
  page: async (page = 1, limit = 30): Promise<NotificationPage> => {
    const body = (await api.get('/api/notifications', { params: { page, limit } })).data as {
      data?: { data?: AppNotification[]; pagination?: { total?: number; unreadCount?: number; page?: number; totalPages?: number } } | AppNotification[];
    };
    const inner = body?.data;
    const items = Array.isArray(inner) ? inner : (inner?.data ?? []);
    const p = Array.isArray(inner) ? undefined : inner?.pagination;
    return {
      items,
      unreadCount: p?.unreadCount ?? items.filter((n) => !n.isRead).length,
      total: p?.total ?? items.length,
      page: p?.page ?? page,
      totalPages: p?.totalPages ?? 1,
    };
  },
  markAllRead: async () => (await api.patch('/api/notifications')).data,
  markRead: async (id: number) => (await api.patch(`/api/notifications/${id}`)).data,
};
