/**
 * API shapes — mirror munkai-frontend origin/main `src/services/interfaces/interface.ts`.
 * The backend now speaks camelCase; `src/lib/api.ts` also camelizes any legacy
 * snake_case keys, so everything the app reads is camelCase.
 */

export interface User {
  id: string | number;
  firstName: string;
  lastName: string;
  emailAddress: string;
  username: string;
  role: string;
  status: string;
  profileImage?: string | null;
  bannerImage?: string | null;
  isAdmin: boolean;
  createdAt: string;
  walletAddress?: string;
  balance?: number;
  collectedChaptersCount?: number;
  collectedPublicationsCount?: number;
  publicationsCount?: number;
  savedPublicationsCount?: number;
  followedCreators?: number;
  creatorDetails?: {
    ownedPublications?: Publication[];
    ownedPublicationsCount?: number;
    followersCount?: number;
    isTranslator?: boolean;
  };
  savedPublications?: Publication[];
  collectedPublications?: Publication[];
  collectedChapters?: CollectedChapter[];
  isTranslator?: boolean;
  referralDetails?: {
    myReferralCode: string;
    referredBy?: {
      firstName: string;
      lastName: string;
      username: string;
      profileImage: string | null;
    } | null;
    referrals: unknown[];
    referralsCount: number;
  };
}

export interface Publication {
  id: string | number;
  userId?: string | number;
  name: string;
  slug?: string | null;
  summary?: string;
  shortSummary?: string;
  publicationType?: string;
  genre?: string[] | string;
  coverPhoto?: string | null;
  createdAt?: string;
  isCompleted?: boolean;
  isFiction?: boolean;
  isSaved?: boolean;
  isCollected?: boolean;
  isFanfic?: boolean | null;
  originalWorkTitle?: string | null;
  originalAuthor?: string | null;
  originalLanguage?: string | null;
  originalSourceUrl?: string | null;
  username?: string;
  firstName?: string;
  lastName?: string;
  profileImage?: string | null;
  author?: { firstName?: string; lastName?: string; username?: string; profileImage?: string | null };
  users?: { firstName?: string; lastName?: string; username?: string; profileImage?: string | null };
  featuredPublications?: unknown;
  munkaiPicks?: unknown;
  freePublications?: unknown;
  totalChapters?: number;
  /** false = draft publication (owner only). */
  isPublished?: boolean;
  isDeleted?: boolean;
  count?: number;
  collectCount?: number;
}

/** /api/landing → recentChapters */
export interface RecentChapter {
  id: number | string;
  publicationId: number | string;
  name?: string | null;
  chapterNumber: number;
  price: number;
  createdAt?: string;
  count?: number;
  editCount?: number;
  coverPhoto?: string | null;
  publicationType?: string;
  username?: string;
  publicationName: string;
  publicationSlug?: string | null;
  collectCount?: number;
  isCollected?: boolean;
  isFanfic?: boolean;
}

/** /api/landing → topCreators, /api/creators/top */
export interface TopCreator {
  id: string | number;
  firstName: string;
  lastName: string;
  username: string;
  profileImage?: string | null;
  role?: string;
  totalPublications?: number;
  bannerImage?: string | null;
  userId?: string | number;
}

export interface LandingData {
  freePublications: Publication[];
  munkaiPicks: Publication[];
  featuredPublications: Publication[];
  topCreators: TopCreator[];
  recentChapters: RecentChapter[];
  trendingPublications: Publication[];
  fanfics: Publication[];
  completedPublications: Publication[];
  genreSpotlights: Record<string, Publication[]>;
  stats?: { totalCreators: number; totalPublications: number; totalReaders: number };
}

/** GET /api/chapters/list → items */
export interface ChapterIndexEntry {
  id: number;
  publicationId: number;
  chapterNumber: number;
  name: string | null;
  slug?: string | null;
  price: number;
  editCount: number;
  createdAt: string;
  collectCount: number;
  isCollected: boolean;
  canRead: boolean;
  isDeleted?: boolean;
  /** Owner-only publish state. */
  state?: 'draft' | 'scheduled' | 'live';
  publishAt?: string | null;
  count?: number;
}

/** GET /api/publications/creator/:id → creatorDetails */
export interface CreatorDetails {
  id?: string | number;
  userId?: string | number;
  firstName: string;
  lastName: string;
  username: string;
  profileImage?: string | null;
  bannerImage?: string | null;
  role?: string;
  createdAt?: string;
  totalPublications?: number;
  totalChapters?: number;
  totalFollowers?: number;
  isTranslator?: boolean;
}

/** Neighbour chapter embedded in a read response. */
export interface ChapterNeighbour {
  id: number;
  name?: string | null;
  chapterNumber: number;
  price?: number;
  editCount?: number;
  isCollected?: boolean;
  canRead?: boolean;
  collectCount?: number;
  slug?: string | null;
}

/** GET /api/chapters/read */
export interface ChapterContent {
  chapterId?: number;
  id?: number;
  name?: string | null;
  chapterNumber: number;
  username?: string;
  userId?: number;
  publicationName?: string;
  publicationType?: string;
  pubId?: number;
  publicationId?: number;
  content: string;
  coverPhoto?: string | null;
  prevChapter?: ChapterNeighbour | null;
  nextChapter?: ChapterNeighbour | null;
  isCompleted?: boolean;
  isFanfic?: boolean;
  editCount?: number;
  price?: number;
  state?: 'draft' | 'scheduled' | 'live';
  publishAt?: string | null;
}

/** GET /api/chapters/collect-all */
export interface UncollectedInfo {
  uncollectedCount: number;
  totalPrice: number;
  chapters: { id: number; name?: string | null; chapterNumber: number; price: number }[];
}

export interface Comment {
  id: number;
  content: string;
  userId: number;
  username: string;
  profileImage?: string | null;
  createdAt: string;
  modifiedAt?: string | null;
  chapterId?: number;
  likes?: number;
  likedByMe?: boolean;
  isDeleted?: boolean;
  replyCount?: number;
  replies?: Comment[];
  replyingToUsername?: string | null;
}

export interface AppNotification {
  id: number;
  notificationType: string;
  title: string;
  message: string;
  linkUrl?: string | null;
  metadata?: Record<string, unknown> | null;
  isRead: boolean;
  createdAt: string;
}

/** Legacy shape kept for profiles that still send collected chapters. */
export interface CollectedChapter {
  id: string | number;
  chapterId?: string | number;
  name?: string;
  chapterNumber?: number;
  price?: number;
  createdAt?: string;
  publicationId?: string | number;
  publicationName?: string;
  publicationType?: string;
  coverPhoto?: string;
  publications?: Publication;
  chapters?: {
    id?: string | number;
    name?: string;
    chapterNumber?: number;
    price?: number;
    publicationId?: string | number;
    publications?: Publication;
  };
}

export interface ApiEnvelope<T> {
  success: boolean;
  message: string;
  data: T;
}

export type AuthPayload = ApiEnvelope<{ user: User; token?: string }>;

/** Paginated list envelope (munkai-frontend lib/paginated.ts). */
export interface ListPage<T> {
  items: T[];
  nextCursor: string | null;
  total: number | null;
}
