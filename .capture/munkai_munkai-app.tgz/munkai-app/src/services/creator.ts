/**
 * Creator tools — mirrors munkai-frontend origin/main:
 * services/api/{creator,publications,chapters}.ts and forms/{create-publication,upload-chapter,become-a-creator}.tsx.
 */
import { api } from '@/lib/api';

import type { Publication } from './types';

/** React Native FormData file part. */
export type UploadFile = { uri: string; name: string; type: string; size?: number };

function unwrap<T>(body: unknown): T {
  let cur: unknown = body;
  for (let i = 0; i < 2; i++) {
    if (cur && typeof cur === 'object' && !Array.isArray(cur) && 'data' in (cur as object)) cur = (cur as { data: unknown }).data;
    else break;
  }
  return cur as T;
}

const multipart = { headers: { 'Content-Type': 'multipart/form-data' }, timeout: 180000 } as const;
const filePart = (f: UploadFile) => ({ uri: f.uri, name: f.name, type: f.type }) as unknown as Blob;

/* ------------------------------ become a creator ------------------------------ */

export type CreatorRequest = {
  id?: number;
  status?: string; // "Pending" | "Rejected" | …
  createdAt?: string;
  nextRequestTime?: string | null;
  reasonRejected?: string | null;
};

export type CreatorApplication = {
  twitterUrl: string;
  linkedinUrl: string;
  telegramUrl: string;
  portfolioUrl: string;
  validId: UploadFile;
};

/* -------------------------------- publications -------------------------------- */

/** Web values (create-publication.tsx) — sent Capitalised as `type`. */
export const PUB_TYPES = [
  { value: 'Comic', label: 'Comic / Manga' },
  { value: 'Book', label: 'Novel / Book' },
  { value: 'Story', label: 'Short story' },
  { value: 'Poem', label: 'Poetry' },
  { value: 'Article', label: 'Article' },
] as const;
export type PubType = (typeof PUB_TYPES)[number]['value'];

/** lib/constants/genres.ts */
export const FICTION_GENRES = [
  'Action',
  'Adventure',
  'BL',
  'Comedy',
  'Crime',
  'Cyberpunk',
  'Dark Fantasy',
  'Drama',
  'Fantasy',
  'GL',
  'Harem',
  'Historical',
  'Horror',
  'Isekai',
  'LGBTQ+',
  'Magic',
  'Martial Arts',
  'Mecha',
  'Mystery',
  'Post-Apocalyptic',
  'Psychological',
  'Regression',
  'Reverse Harem',
  'Romance',
  'Romantic Comedy',
  'Sci-Fi',
  'Slice of Life',
  'Sports',
  'Steampunk',
  'Supernatural',
  'System',
  'Thriller',
  'Tragedy',
  'Transmigration',
  'Urban Fantasy',
  'Villainess',
  'Wuxia',
  'Xianxia',
];
export const NON_FICTION_GENRES = ['Biography', 'Essays', 'History', 'Memoir', 'Poetry', 'Self-Help', 'True Crime'];

export type PublicationInput = {
  name: string;
  genre: string[];
  type?: PubType; // create only
  isFiction?: boolean; // create only
  shortSummary: string;
  summary: string;
  isFanfic: boolean;
  originalWorkTitle: string;
  originalAuthor: string;
  originalLanguage?: string; // edit only (web)
  originalSourceUrl: string;
  coverPhoto?: UploadFile | null;
};

function publicationForm(input: PublicationInput, mode: 'create' | 'edit') {
  const form = new FormData();
  form.append('name', input.name.trim());
  input.genre.forEach((g) => form.append('genre', g));
  if (mode === 'create') {
    form.append('type', input.type ?? 'Book');
    form.append('isFiction', String(input.isFiction ?? true));
  }
  form.append('shortSummary', input.shortSummary.trim());
  form.append('summary', input.summary.trim());
  const fan = !!input.isFanfic && input.isFiction !== false;
  form.append('isFanfic', String(fan));
  form.append('originalWorkTitle', fan ? input.originalWorkTitle.trim() : '');
  form.append('originalAuthor', fan ? input.originalAuthor.trim() : '');
  form.append('originalSourceUrl', fan ? input.originalSourceUrl.trim() : '');
  if (mode === 'edit' && input.originalLanguage !== undefined) form.append('originalLanguage', fan ? input.originalLanguage.trim() : '');
  if (input.coverPhoto) form.append('coverPhoto', filePart(input.coverPhoto));
  return form;
}

/* ---------------------------------- chapters ---------------------------------- */

export type PublishMode = 'now' | 'schedule' | 'draft';

export type ChapterInput = {
  publicationId: number | string;
  chapterNumber: number;
  name?: string;
  price: number;
  mode: PublishMode;
  publishAt?: Date | null;
  /** Text chapters: HTML. */
  html?: string;
  /** Comics: a single PDF … */
  pdf?: UploadFile | null;
  /** … or page images, in order. */
  pages?: UploadFile[];
};

function publishFields(mode: PublishMode, at?: Date | null) {
  if (mode === 'draft') return { isPublished: false, publishAt: null as string | null };
  if (mode === 'schedule' && at) return { isPublished: true, publishAt: at.toISOString() };
  return { isPublished: true, publishAt: null as string | null };
}

export const creatorApi = {
  /** GET /api/creators/requests → latest application (or null). */
  request: async (): Promise<CreatorRequest | null> => {
    const d = unwrap<CreatorRequest | CreatorRequest[] | null>((await api.get('/api/creators/requests')).data);
    if (Array.isArray(d)) return d[0] ?? null;
    return d && typeof d === 'object' ? d : null;
  },

  /** POST /api/creators/apply (multipart) */
  apply: async (input: CreatorApplication) => {
    const form = new FormData();
    form.append('twitterUrl', input.twitterUrl.trim());
    form.append('linkedinUrl', input.linkedinUrl.trim());
    form.append('telegramUrl', input.telegramUrl.trim());
    form.append('portfolioUrl', input.portfolioUrl.trim());
    form.append('validId', filePart(input.validId));
    return (await api.post('/api/creators/apply', form, multipart)).data;
  },

  /** POST /api/publications (multipart) */
  createPublication: async (input: PublicationInput) =>
    unwrap<Publication | boolean>((await api.post('/api/publications', publicationForm(input, 'create'), multipart)).data),

  /** PATCH /api/publications/:id (multipart) */
  updatePublication: async (id: number | string, input: PublicationInput) =>
    (await api.patch(`/api/publications/${id}`, publicationForm(input, 'edit'), multipart)).data,

  /** PATCH /api/publications/:id/complete */
  markComplete: async (id: number | string) => (await api.patch(`/api/publications/${id}/complete`)).data,

  /** PATCH /api/publications/:id/publish */
  setPublicationPublished: async (id: number | string, isPublished: boolean) =>
    (await api.patch(`/api/publications/${id}/publish`, { isPublished })).data,

  /** GET /api/chapters/next-number?publicationId */
  nextChapterNumber: async (publicationId: number | string): Promise<number> => {
    const d = unwrap<{ nextChapterNumber?: number }>((await api.get('/api/chapters/next-number', { params: { publicationId } })).data);
    return Number(d?.nextChapterNumber) || 1;
  },

  /** POST /api/chapters (multipart) */
  createChapter: async (input: ChapterInput) => {
    const form = new FormData();
    const pub = publishFields(input.mode, input.publishAt);
    form.append('publicationId', String(input.publicationId));
    form.append('chapterNumber', String(input.chapterNumber));
    if (input.name?.trim()) form.append('name', input.name.trim());
    form.append('price', String(Math.max(0, input.price)));
    form.append('isPublished', String(pub.isPublished));
    if (pub.publishAt) form.append('publishAt', pub.publishAt);
    if (input.html !== undefined) {
      form.append('content', input.html);
      form.append('text', input.html);
    }
    if (input.pdf) form.append('pdf', filePart(input.pdf));
    input.pages?.forEach((p) => form.append('pages', filePart(p)));
    return unwrap<{ id?: number }>((await api.post('/api/chapters', form, multipart)).data);
  },

  /** PATCH /api/chapters/:id (multipart). Pages are sent too (the web drops them — a bug). */
  updateChapter: async (
    id: number | string,
    input: { name?: string; price: number; html?: string; pdf?: UploadFile | null; pages?: UploadFile[] },
  ) => {
    const form = new FormData();
    form.append('name', input.name?.trim() ?? '');
    form.append('price', String(Math.max(0, input.price)));
    if (input.html !== undefined) form.append('content', input.html);
    if (input.pdf) form.append('pdf', filePart(input.pdf));
    input.pages?.forEach((p) => form.append('pages', filePart(p)));
    return (await api.patch(`/api/chapters/${id}`, form, multipart)).data;
  },

  /** PATCH /api/chapters/:id/publish */
  setChapterPublished: async (id: number | string, mode: PublishMode, at?: Date | null) =>
    (await api.patch(`/api/chapters/${id}/publish`, publishFields(mode, at))).data,

  /** PATCH /api/chapters/reorder */
  reorder: async (publicationId: number | string, chapterIds: number[]) =>
    (await api.patch('/api/chapters/reorder', { publicationId: Number(publicationId), chapterIds })).data,
};

/** Web rule: originals get 2 edits per chapter, fan translations unlimited. */
export const MAX_EDITS = 2;
export function editsLeft(editCount: number | undefined, isFanfic?: boolean | null) {
  if (isFanfic) return Infinity;
  return Math.max(0, MAX_EDITS - (Number(editCount) || 0));
}

export const isCreatorRole = (role?: string | null) => (role ?? '').toUpperCase() === 'CREATOR' || (role ?? '').toUpperCase() === 'ADMIN';
