import { api } from '@/lib/api';

/** GET /api/app/version — see "Munkai — App Version Endpoint Spec". Public: no token, never signs anyone out. */
export type AppVersionInfo = {
  platform: 'ios' | 'android';
  latestVersion: string;
  minimumVersion?: string;
  storeUrl?: string;
  releaseNotes?: string[];
  releasedAt?: string;
  updateAvailable?: boolean;
  updateRequired?: boolean;
};

export const appVersionApi = {
  get: async (platform: 'ios' | 'android', version: string) =>
    (
      await api.get<{ success: boolean; data: AppVersionInfo }>('/api/app/version', {
        params: { platform, version },
        skipAuth: true,
        timeout: 5000,
      })
    ).data.data,
};
