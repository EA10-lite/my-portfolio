import { api } from '@/lib/api';

import type { ApiEnvelope, User } from './types';

/** Endpoints match munkai-frontend/src/services/api/user-profile.ts + follow.ts. */

export type LocalImage = { uri: string; name: string; type: string };

export type UpdateProfileInput = {
  firstName?: string;
  lastName?: string;
  username?: string;
  profileImage?: LocalImage;
  bannerImage?: LocalImage;
};

/** Some endpoints return a bare array, some an envelope — accept both. */
function unwrapList<T>(data: T[] | ApiEnvelope<T[]> | undefined): T[] {
  if (Array.isArray(data)) return data;
  if (data && Array.isArray((data as ApiEnvelope<T[]>).data)) return (data as ApiEnvelope<T[]>).data;
  return [];
}

/**
 * Account deletion — required by the App Store (5.1.1(v)) and Google Play.
 * POST /api/users/account/delete { reason, details? } → { data: { permanentDeletionAt } }.
 * The account is deactivated at once (every session ends), and permanently deleted after 30 days.
 * `details` is required when reason is "other" (max 500 chars).
 */
export const DELETE_REASONS = [
  { value: 'not_using', label: 'I don’t use Munkai anymore' },
  { value: 'found_alternative', label: 'I found another platform I prefer' },
  { value: 'no_content', label: 'I can’t find content I enjoy' },
  { value: 'too_expensive', label: 'It costs too much' },
  { value: 'too_many_notifications', label: 'Too many emails or notifications' },
  { value: 'technical_issues', label: 'The app has too many bugs or problems' },
  { value: 'privacy', label: 'I have privacy concerns' },
  { value: 'bad_experience', label: 'I had a bad experience with the community' },
  { value: 'duplicate_account', label: 'I have another Munkai account' },
  { value: 'other', label: 'Other' },
] as const;
export type DeleteReason = (typeof DELETE_REASONS)[number]['value'];
export const DELETE_DETAILS_MAX = 500;

export const profileApi = {
  /** Deactivate the signed-in account now; it is permanently deleted after 30 days. */
  deleteAccount: async (input: { reason: DeleteReason; details?: string }) =>
    (await api.post<{ success: boolean; message?: string; data?: { permanentDeletionAt?: string } }>('/api/users/account/delete', input))
      .data,

  /** PATCH /api/users (multipart) — same field names as the web edit sheet. */
  update: async (input: UpdateProfileInput) => {
    const form = new FormData();
    if (input.firstName !== undefined) form.append('firstName', input.firstName);
    if (input.lastName !== undefined) form.append('lastName', input.lastName);
    if (input.username !== undefined) form.append('username', input.username);
    // React Native's FormData accepts { uri, name, type } file parts.
    if (input.profileImage) form.append('profileImage', input.profileImage as unknown as Blob);
    if (input.bannerImage) form.append('bannerImage', input.bannerImage as unknown as Blob);
    const res = await api.patch<ApiEnvelope<User>>('/api/users', form, {
      headers: { 'Content-Type': 'multipart/form-data' },
      timeout: 60000,
    });
    return res.data;
  },

  following: async () => unwrapList<User>((await api.get('/api/users/following')).data),
  followers: async () => unwrapList<User>((await api.get('/api/users/followers')).data),

  /** GET /api/users/follow/:username → { isFollowing } */
  isFollowing: async (username: string) => {
    const d = (await api.get(`/api/users/follow/${username}`)).data as { data?: { isFollowing?: boolean } };
    return !!d?.data?.isFollowing;
  },
  follow: async (username: string) => (await api.post(`/api/users/follow/${username}`)).data,
  unfollow: async (username: string) => (await api.delete(`/api/users/follow/${username}`)).data,
};
