import { api } from '@/lib/api';

/** Normalised rows for the wallet's activity list (web: app/auth/payments/history). */
export type WalletActivity = {
  id: string;
  kind: 'deposit' | 'withdrawal' | 'sent' | 'received';
  amount: number;
  status: 'completed' | 'failed' | 'pending' | null;
  createdAt: string;
  /** Provider for deposits/withdrawals, the other username for transfers. */
  detail: string;
};

function list(body: unknown): Record<string, unknown>[] {
  let raw: unknown = body;
  if (raw && typeof raw === 'object' && !Array.isArray(raw) && 'data' in raw) raw = (raw as { data: unknown }).data;
  if (Array.isArray(raw)) return raw as Record<string, unknown>[];
  if (raw && typeof raw === 'object') {
    const o = raw as Record<string, unknown>;
    for (const k of ['data', 'transactions', 'transfers', 'items']) if (Array.isArray(o[k])) return o[k] as Record<string, unknown>[];
  }
  return [];
}

const str = (v: unknown) => (v === undefined || v === null ? '' : String(v));

/** Endpoints match munkai-frontend/src/services/api/payments.ts. */
export const paymentsApi = {
  /** GET /api/payments/history — deposits and withdrawals. */
  history: async (): Promise<WalletActivity[]> => {
    const res = await api.get('/api/payments/history');
    return list(res.data)
      .map((tx): WalletActivity | null => {
        const type = str(tx.transactionType ?? tx.transactionType ?? tx.type).toLowerCase();
        const kind = type.includes('deposit') ? 'deposit' : type.includes('withdraw') ? 'withdrawal' : null;
        if (!kind) return null;
        const rawStatus = str(tx.status).toLowerCase();
        const status: WalletActivity['status'] = rawStatus
          ? rawStatus.includes('fail')
            ? 'failed'
            : rawStatus.includes('pend')
              ? 'pending'
              : 'completed'
          : tx.verified
            ? 'completed'
            : 'failed';
        return {
          id: `p-${str(tx.id)}`,
          kind,
          amount: Number(tx.amount) || 0,
          status,
          createdAt: str(tx.createdAt ?? tx.createdAt) || new Date().toISOString(),
          detail: str(tx.provider) || 'flutterwave',
        };
      })
      .filter((x): x is WalletActivity => !!x);
  },

  /** GET /api/payments/transfer-history */
  transfers: async (): Promise<WalletActivity[]> => {
    const res = await api.get('/api/payments/transfer-history');
    return list(res.data).map((tr) => {
      const sent = str(tr.direction) === 'sent';
      const other = (sent ? tr.receiver : tr.sender) as { username?: string; walletAddress?: string } | undefined;
      return {
        id: `t-${str(tr.id)}`,
        kind: sent ? 'sent' : 'received',
        amount: Number(tr.amount) || 0,
        status: null,
        createdAt: str(tr.createdAt ?? tr.createdAt) || new Date().toISOString(),
        detail: other?.username ? `@${other.username}` : other?.walletAddress ?? '',
      };
    });
  },

  /** POST /api/payments/transfer — same payload the web sends (walletAddress doubles as recipientId). */
  transfer: async (walletAddress: string, amount: number) => {
    const address = walletAddress.trim();
    return (await api.post('/api/payments/transfer', { amount, walletAddress: address, recipientId: address })).data;
  },
};
