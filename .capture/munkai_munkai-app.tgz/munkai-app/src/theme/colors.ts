/**
 * Munkai color tokens — ported 1:1 from munkai-frontend/src/app/globals.css
 * (:root = light, .dark = dark). Effective values only (later overrides win).
 */

export type ColorTokens = {
  /** Page background behind everything (web `--bg`, used on <body>) */
  pageBackground: string;
  /** Three-stop brand gradient (web `--bg-gradient`, 135deg) */
  pageGradient: [string, string, string];
  /** Surface (web `--background`) */
  background: string;
  foreground: string;

  card: string;
  cardForeground: string;
  popover: string;
  popoverForeground: string;

  primary: string;
  primaryForeground: string;
  /** Text/icons on solid primary fills (buttons). Light mode uses white for contrast. */
  onPrimary: string;
  secondary: string;
  secondaryForeground: string;
  muted: string;
  mutedForeground: string;
  accent: string;
  accentForeground: string;
  destructive: string;
  destructiveForeground: string;

  border: string;
  /** Border color for inputs */
  input: string;
  /** Fill color for inputs (web: bg-secondary, dark:bg-card) */
  inputBackground: string;
  ring: string;

  /** Web `--hoverbg` — sky blue at 20%, used for pressed/selected tints */
  hover: string;
  opac: string;
  yellow: string;
  yellowForeground: string;

  /** Neon glow colors (web `--neon-*`) as hex */
  neonCyan: string;
  neonPurple: string;
  neonPink: string;

  /** Status colors used across web (green/amber/red-500 etc.) */
  success: string;
  warning: string;
  danger: string;
  info: string;

  /** Particle colors for the ambient background */
  particles: [string, string, string];
};

export const lightColors: ColorTokens = {
  pageBackground: '#DAEAF7',
  pageGradient: ['#FFFFFF', '#E6F4F8', '#DAEAF7'],
  background: '#FFFFFF',
  foreground: '#020618',

  card: '#FBFDFF',
  cardForeground: '#0A0A0A',
  popover: '#FFFFFF',
  popoverForeground: '#0A0A0A',

  primary: '#006097',
  primaryForeground: '#87CEEB',
  onPrimary: '#FFFFFF',
  secondary: '#DAEAF7',
  secondaryForeground: '#1A1A1A',
  muted: '#F2F2F2',
  // Web uses #787878; darkened for AA contrast on the pale-blue page background.
  mutedForeground: '#5E6A75',
  accent: '#F2F2F2',
  accentForeground: '#1A1A1A',
  destructive: '#E53935',
  destructiveForeground: '#FAFAFA',

  border: '#E5E5E5',
  input: '#C9D9E6',
  // Web uses bg-secondary (#DAEAF7), which disappears on the page background on a phone.
  inputBackground: '#FFFFFF',
  ring: '#006097',

  hover: 'rgba(135, 206, 235, 0.2)',
  opac: '#E6F4F8',
  yellow: '#FFC400',
  yellowForeground: '#1E2023',

  neonCyan: '#00BFFF',
  neonPurple: '#9370DB',
  neonPink: '#FF69B4',

  success: '#22C55E',
  warning: '#F59E0B',
  danger: '#EF4444',
  info: '#06B6D4',

  particles: ['#6495ED', '#00BFFF', '#4682B4'],
};

export const darkColors: ColorTokens = {
  pageBackground: '#00002B',
  pageGradient: ['#181A37', '#262E31', '#00002B'],
  background: '#181A37',
  foreground: '#F2F2F2',

  card: '#0F172B',
  cardForeground: '#F8FAFC',
  popover: '#171717',
  popoverForeground: '#F2F2F2',

  primary: '#87CEEB',
  primaryForeground: '#006097',
  onPrimary: '#006097',
  secondary: '#00002B',
  secondaryForeground: '#FAFAFA',
  muted: '#262626',
  mutedForeground: '#A3A3A3',
  accent: '#402020',
  accentForeground: '#FAFAFA',
  destructive: '#993333',
  destructiveForeground: '#FFE5E5',

  border: '#292929',
  input: '#292929',
  inputBackground: '#0F172B',
  ring: '#87CEEB',

  hover: 'rgba(135, 206, 235, 0.2)',
  opac: '#262E31',
  yellow: '#FFC400',
  yellowForeground: '#1E2023',

  neonCyan: '#00FFFF',
  neonPurple: '#BC13FE',
  neonPink: '#FF1493',

  success: '#22C55E',
  warning: '#F59E0B',
  danger: '#EF4444',
  info: '#22D3EE',

  particles: ['#04FFFF', '#BC13FE', '#FF1493'],
};

/** Web `.tier-*` gradient text stops (same in both modes) */
export const tierGradients = {
  bronze: ['#CD7F32', '#C471ED', '#12C2E9'],
  silver: ['#C0C0C0', '#C471ED', '#12C2E9'],
  gold: ['#FFD700', '#C471ED', '#12C2E9'],
} as const;

/**
 * Apply an alpha to a hex color: withAlpha('#006097', 0.1) → 'rgba(0, 96, 151, 0.1)'.
 * Mirrors Tailwind's `bg-primary/10` style used everywhere on the web.
 */
export function withAlpha(hex: string, alpha: number): string {
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
