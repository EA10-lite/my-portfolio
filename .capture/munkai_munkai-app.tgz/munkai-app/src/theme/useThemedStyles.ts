import { useMemo } from 'react';
import { StyleSheet } from 'react-native';

import { useTheme, type Theme } from './ThemeProvider';

/**
 * Define styles as a function of the theme, get a memoised StyleSheet back.
 *
 *   const makeStyles = (t: Theme) => StyleSheet.create({ box: { backgroundColor: t.colors.card } });
 *   const styles = useThemedStyles(makeStyles);
 *
 * Declare `makeStyles` outside the component so it stays referentially stable.
 */
export function useThemedStyles<T extends StyleSheet.NamedStyles<T>>(
  factory: (theme: Theme) => T,
): T {
  const theme = useTheme();
  return useMemo(() => factory(theme), [factory, theme]);
}
