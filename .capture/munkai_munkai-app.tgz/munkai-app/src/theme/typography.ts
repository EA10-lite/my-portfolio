import type { TextStyle } from 'react-native';

/**
 * Font families. Keys are the names registered with expo-font in the root layout.
 * Web: Grandstander = display/brand (`font-grandstander`),
 *      Space Grotesk = body (`font-space-grotesk`, the <body> default).
 */
export const fontFiles = {
  'Grandstander-Regular': require('../../assets/fonts/Grandstander_400Regular.ttf'),
  'Grandstander-Bold': require('../../assets/fonts/Grandstander_700Bold.ttf'),
  'Grandstander-Black': require('../../assets/fonts/Grandstander_900Black.ttf'),
  'SpaceGrotesk-Regular': require('../../assets/fonts/SpaceGrotesk_400Regular.ttf'),
  'SpaceGrotesk-Medium': require('../../assets/fonts/SpaceGrotesk_500Medium.ttf'),
  'SpaceGrotesk-SemiBold': require('../../assets/fonts/SpaceGrotesk_600SemiBold.ttf'),
  'SpaceGrotesk-Bold': require('../../assets/fonts/SpaceGrotesk_700Bold.ttf'),
} as const;

export const fonts = {
  display: 'Grandstander-Regular',
  displayBold: 'Grandstander-Bold',
  displayBlack: 'Grandstander-Black',
  body: 'SpaceGrotesk-Regular',
  bodyMedium: 'SpaceGrotesk-Medium',
  bodySemiBold: 'SpaceGrotesk-SemiBold',
  bodyBold: 'SpaceGrotesk-Bold',
} as const;

/**
 * Text variants, mapped from the recurring Tailwind combos on the web.
 * letterSpacing values convert Tailwind's em-based tracking at the given size:
 *   tracking-widest = 0.1em, tracking-[0.2em] = 0.2em, tracking-tight = -0.025em.
 */
export const textVariants = {
  /** Hero / page titles — `font-grandstander font-black text-4xl uppercase` */
  display: { fontFamily: fonts.displayBlack, fontSize: 34, lineHeight: 38, letterSpacing: -0.5 },
  /** Section titles — `text-3xl font-bold font-grandstander` */
  title: { fontFamily: fonts.displayBold, fontSize: 28, lineHeight: 32 },
  /** Card / screen headings — `text-xl font-grandstander font-bold` */
  heading: { fontFamily: fonts.displayBold, fontSize: 20, lineHeight: 26 },
  /** Emphasised body — `font-bold text-base` */
  subtitle: { fontFamily: fonts.bodyBold, fontSize: 16, lineHeight: 22 },
  /** Default body — `text-base` */
  body: { fontFamily: fonts.body, fontSize: 16, lineHeight: 24 },
  /** Secondary body — `text-sm` */
  bodySmall: { fontFamily: fonts.body, fontSize: 14, lineHeight: 20 },
  /** Form labels & kickers — `font-bold text-xs uppercase tracking-widest text-primary` */
  label: {
    fontFamily: fonts.bodyBold,
    fontSize: 12,
    lineHeight: 16,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  /** Tiny meta text — `text-[10px] font-bold uppercase tracking-widest` */
  caption: {
    fontFamily: fonts.bodyBold,
    fontSize: 10,
    lineHeight: 14,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  /** Button text — `font-bold uppercase tracking-widest text-sm` */
  button: {
    fontFamily: fonts.bodyBold,
    fontSize: 14,
    lineHeight: 18,
    letterSpacing: 1.4,
    textTransform: 'uppercase',
  },
  /** Big numbers / stats — `text-3xl font-grandstander font-bold` */
  stat: { fontFamily: fonts.displayBold, fontSize: 28, lineHeight: 32 },
  /** Brand wordmark — `font-grandstander font-bold uppercase text-primary` */
  wordmark: {
    fontFamily: fonts.displayBold,
    fontSize: 28,
    lineHeight: 34,
    textTransform: 'uppercase',
  },
} satisfies Record<string, TextStyle>;

export type TextVariant = keyof typeof textVariants;
