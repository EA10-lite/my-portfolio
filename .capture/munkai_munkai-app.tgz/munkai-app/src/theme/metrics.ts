/**
 * Spacing, radius and shape tokens.
 * Spacing follows Tailwind's 4px scale used throughout munkai-frontend.
 */
export const spacing = {
  none: 0,
  xxs: 2,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16, // default screen gutter (web px-4)
  xl: 24, // card padding (web p-6)
  xxl: 32, // web p-8
  xxxl: 48,
  section: 64, // gap between home sections (web space-y-20 scaled for mobile)
} as const;

/** Web `--radius: 0.75rem` and derived radii */
export const radius = {
  none: 0,
  sm: 8,
  md: 10,
  lg: 12,
  xl: 16,
  xxl: 20,
  full: 9999,
  /** Search inputs: rectangular with a subtle radius (not pills). */
  search: 8,
} as const;

/**
 * Signature Munkai corner cuts (web utility classes):
 *  - `.cut-corner`          → 12px diagonal on bottom-right (primary buttons)
 *  - `.clip-path-gamified`  → 8px diagonals on top-left + bottom-right (cards, tags)
 */
export const cuts = {
  button: { br: 12 },
  card: { tl: 8, br: 8 },
} as const;

/** Standard control heights */
export const sizes = {
  inputHeight: 52,
  buttonHeight: 54,
  buttonHeightSmall: 36,
  iconButton: 40,
} as const;
