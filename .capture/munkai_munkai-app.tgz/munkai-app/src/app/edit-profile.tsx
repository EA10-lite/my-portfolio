/**
 * Edit Profile — approved mocks "Edit profile" + "Change photo sheet".
 * Web: munkai-frontend/src/components/sheets/editProfileSheet.tsx (same fields, same
 * PATCH /api/users multipart request, same 5MB / png-jpeg rules).
 */
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { Camera, Image as ImageIcon, Info } from 'lucide-react-native';
import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Image, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { ProfileBanner } from '@/components/profile/ProfileBanner';
import { Avatar, Button, Input, Sheet, Text, useToast, KeyboardAvoid } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { rules } from '@/lib/validation';
import { profileApi, type LocalImage } from '@/services/profile';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

const MAX_BYTES = 5 * 1024 * 1024;
type Target = 'avatar' | 'banner';

export default function EditProfile() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { user, refreshProfile } = useSession();

  const [firstName, setFirstName] = useState(user?.firstName ?? '');
  const [lastName, setLastName] = useState(user?.lastName ?? '');
  const [username, setUsername] = useState(user?.username ?? '');
  const [avatar, setAvatar] = useState<LocalImage | null>(null);
  const [banner, setBanner] = useState<LocalImage | null>(null);
  const [errors, setErrors] = useState<{ firstName?: string; lastName?: string; username?: string }>({});
  const [pickerFor, setPickerFor] = useState<Target | null>(null);
  const [saving, setSaving] = useState(false);

  const dirty = useMemo(
    () => !!user && (firstName !== user.firstName || lastName !== user.lastName || username !== user.username || !!avatar || !!banner),
    [user, firstName, lastName, username, avatar, banner],
  );

  if (!user) return null;

  const pick = async (target: Target, source: 'camera' | 'library') => {
    setPickerFor(null);
    try {
      const perm =
        source === 'camera' ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        toast.error('Permission needed', `Allow ${source === 'camera' ? 'camera' : 'photo'} access in Settings to continue.`);
        return;
      }
      const options: ImagePicker.ImagePickerOptions = {
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: target === 'avatar' ? [1, 1] : [3, 1],
        quality: 0.85,
      };
      const result =
        source === 'camera' ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
      if (result.canceled || !result.assets?.[0]) return;

      const asset = result.assets[0];
      const type = asset.mimeType ?? (asset.uri.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg');
      if (!['image/png', 'image/jpeg', 'image/jpg'].includes(type)) {
        toast.error('Unsupported image', 'Photos must be PNG or JPEG.');
        return;
      }
      if (asset.fileSize && asset.fileSize > MAX_BYTES) {
        toast.error('Image too large', 'Please choose a photo under 5MB.');
        return;
      }
      const file: LocalImage = {
        uri: asset.uri,
        type,
        name: asset.fileName ?? `${target}-${Date.now()}.${type === 'image/png' ? 'png' : 'jpg'}`,
      };
      haptic.select().catch(() => {});
      if (target === 'avatar') setAvatar(file);
      else setBanner(file);
    } catch {
      toast.error('Could not open photos', 'Please try again.');
    }
  };

  const save = async () => {
    const next = {
      firstName: rules.firstName(firstName),
      lastName: rules.lastName(lastName),
      username: rules.username(username),
    };
    setErrors(next);
    if (next.firstName || next.lastName || next.username) {
      haptic.error().catch(() => {});
      return;
    }
    setSaving(true);
    try {
      await profileApi.update({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        username,
        profileImage: avatar ?? undefined,
        bannerImage: banner ?? undefined,
      });
      await refreshProfile();
      toast.success('Profile synchronized', 'Your changes are live across the multiverse.');
      router.back();
    } catch (err) {
      const msg = apiErrorMessage(err, 'Could not save your profile.');
      if (/username/i.test(msg)) setErrors((e) => ({ ...e, username: 'This username is already claimed' }));
      toast.error('Update failed', msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.root}>
      {/* Top bar: Cancel · Edit Profile · Save */}
      <View style={[styles.header, { paddingTop: insets.top + 4 }]}>
        <Pressable onPress={() => router.back()} hitSlop={8} accessibilityRole="button" style={styles.headerBtn}>
          <Text variant="body" color="mutedForeground">
            Cancel
          </Text>
        </Pressable>
        <Text variant="heading" style={styles.headerTitle}>
          Edit Profile
        </Text>
        <Pressable
          onPress={save}
          disabled={!dirty || saving}
          hitSlop={8}
          accessibilityRole="button"
          accessibilityState={{ disabled: !dirty || saving }}
          style={[styles.headerBtn, styles.headerRight]}
        >
          {saving ? (
            <ActivityIndicator size="small" color={t.colors.primary} />
          ) : (
            <Text variant="subtitle" color={dirty ? 'primary' : withAlpha(t.colors.primary, 0.4)}>
              Save
            </Text>
          )}
        </Pressable>
      </View>

      <KeyboardAvoid>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {/* Banner */}
          <View>
            {banner ? (
              <Image source={{ uri: banner.uri }} style={styles.bannerImg} resizeMode="cover" />
            ) : (
              <ProfileBanner uri={user.bannerImage} height={150} />
            )}
            <Pressable
              onPress={() => setPickerFor('banner')}
              accessibilityRole="button"
              accessibilityLabel="Change banner"
              style={({ pressed }) => [styles.bannerPill, pressed && { opacity: 0.8 }]}
            >
              <Camera size={16} color={t.colors.foreground} strokeWidth={2} />
              <Text variant="bodySmall" style={styles.bold}>
                Change banner
              </Text>
            </Pressable>
          </View>

          {/* Avatar */}
          <View style={styles.avatarWrap}>
            <Pressable
              onPress={() => setPickerFor('avatar')}
              accessibilityRole="button"
              accessibilityLabel="Change profile photo"
              style={styles.avatarRing}
            >
              <Avatar
                uri={avatar?.uri ?? user.profileImage}
                firstName={firstName || user.firstName}
                lastName={lastName || user.lastName}
                seed={user.username}
                size={96}
                ghost="light"
              />
              <View style={styles.cameraBadge}>
                <Camera size={16} color={t.colors.onPrimary} strokeWidth={2.4} />
              </View>
            </Pressable>
          </View>

          {/* Fields */}
          <View style={styles.form}>
            <View style={styles.row}>
              <Input
                containerStyle={styles.flex}
                label="First name"
                value={firstName}
                onChangeText={(v) => {
                  setFirstName(v);
                  setErrors((e) => ({ ...e, firstName: undefined }));
                }}
                error={errors.firstName}
                maxLength={30}
                textContentType="givenName"
              />
              <Input
                containerStyle={styles.flex}
                label="Last name"
                value={lastName}
                onChangeText={(v) => {
                  setLastName(v);
                  setErrors((e) => ({ ...e, lastName: undefined }));
                }}
                error={errors.lastName}
                maxLength={30}
                textContentType="familyName"
              />
            </View>
            <Input
              label="Username"
              leftIcon={
                <Text variant="subtitle" color="primary">
                  @
                </Text>
              }
              value={username}
              onChangeText={(v) => {
                setUsername(v.toLowerCase().replace(/\s/g, ''));
                setErrors((e) => ({ ...e, username: undefined }));
              }}
              error={errors.username}
              hint="4–20 characters · lowercase letters, numbers and _"
              autoCapitalize="none"
              autoCorrect={false}
              maxLength={20}
            />
            <View style={styles.infoBox}>
              <Info size={18} color={t.colors.primary} strokeWidth={2} />
              <Text variant="bodySmall" color="mutedForeground" style={styles.flex}>
                Photos must be PNG or JPEG and under 5MB. You can crop after choosing.
              </Text>
            </View>
            <Button title={saving ? 'Synchronizing…' : 'Save changes'} loading={saving} disabled={!dirty} fullWidth onPress={save} />
          </View>
        </ScrollView>
      </KeyboardAvoid>

      {/* Change photo / banner sheet */}
      <Sheet visible={pickerFor !== null} onClose={() => setPickerFor(null)} title={pickerFor === 'banner' ? 'Banner' : 'Profile photo'}>
        <PickerOption
          icon={<Camera size={20} color={t.colors.primary} strokeWidth={2} />}
          label="Take photo"
          onPress={() => pickerFor && pick(pickerFor, 'camera')}
        />
        <View style={[styles.sep, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]} />
        <PickerOption
          icon={<ImageIcon size={20} color={t.colors.primary} strokeWidth={2} />}
          label="Choose from library"
          onPress={() => pickerFor && pick(pickerFor, 'library')}
        />
        <Text variant="bodySmall" color="mutedForeground" style={styles.sheetNote}>
          {pickerFor === 'banner' ? 'Wide 3:1 crop.' : 'Square crop.'} PNG or JPEG, under 5MB.
        </Text>
        <Button title="Cancel" variant="ghost" fullWidth onPress={() => setPickerFor(null)} />
      </Sheet>
    </View>
  );
}

function PickerOption({ icon, label, onPress }: { icon: React.ReactNode; label: string; onPress: () => void }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [pickerStyles.row, pressed && { backgroundColor: t.colors.hover }]}
    >
      <View style={[pickerStyles.icon, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]}>{icon}</View>
      <Text variant="body">{label}</Text>
    </Pressable>
  );
}

const pickerStyles = StyleSheet.create({
  row: { minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 4 },
  icon: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
});

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    bold: { fontFamily: t.fonts.bodyBold },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 8,
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: withAlpha(t.colors.primary, 0.1),
    },
    headerBtn: { minWidth: 72, height: 44, paddingHorizontal: 8, justifyContent: 'center' },
    headerRight: { alignItems: 'flex-end' },
    headerTitle: { flex: 1, textAlign: 'center', fontSize: 18 },
    scroll: { paddingBottom: 40 },
    bannerImg: { width: '100%', height: 150 },
    bannerPill: {
      position: 'absolute',
      right: 16,
      bottom: 14,
      height: 36,
      paddingHorizontal: 14,
      borderRadius: 18,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: withAlpha(t.colors.pageBackground, 0.7),
      borderWidth: 1,
      borderColor: withAlpha(t.colors.foreground, 0.2),
    },
    avatarWrap: { paddingHorizontal: 24, marginTop: -48 },
    avatarRing: {
      alignSelf: 'flex-start',
      padding: 3,
      borderRadius: 51,
      backgroundColor: t.colors.pageBackground,
      borderWidth: 2,
      borderColor: t.colors.primary,
    },
    cameraBadge: {
      position: 'absolute',
      right: -2,
      bottom: 0,
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor: t.colors.primary,
      borderWidth: 3,
      borderColor: t.colors.pageBackground,
      alignItems: 'center',
      justifyContent: 'center',
    },
    form: { paddingHorizontal: 24, paddingTop: 24, gap: 18 },
    row: { flexDirection: 'row', gap: 12 },
    infoBox: {
      flexDirection: 'row',
      gap: 10,
      padding: 12,
      backgroundColor: withAlpha(t.colors.primary, 0.06),
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.12),
    },
    sep: { height: 1 },
    sheetNote: { marginTop: 10, marginBottom: 4 },
  });
