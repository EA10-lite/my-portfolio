/**
 * Notifications — approved mock "Notifications". Web (origin/main): app/notifications.
 * GET /api/notifications, PATCH /api/notifications (all read), PATCH /api/notifications/:id.
 */
import { router, useFocusEffect } from 'expo-router';
import {
  AlertTriangle,
  Bell,
  BookOpen,
  CheckCheck,
  CheckCircle2,
  Coins,
  Crown,
  Gem,
  Gift,
  Library,
  Megaphone,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Target,
  Trophy,
  UserPlus,
  Wallet,
  type LucideIcon,
} from 'lucide-react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { Pressable, RefreshControl, SectionList, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { Button, Skeleton, SkeletonGroup, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { timeAgo } from '@/lib/publication';
import { QK } from '@/lib/queryKeys';
import { useFetch } from '@/lib/useFetch';
import { notificationsApi } from '@/services/social';
import type { AppNotification } from '@/services/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const ICON: Record<string, [LucideIcon, string]> = {
  newchapter: [BookOpen, '#87CEEB'],
  newpublication: [Library, '#87CEEB'],
  newfollower: [UserPlus, '#D78CFF'],
  achievementunlocked: [Trophy, '#FFC400'],
  challengecomplete: [CheckCircle2, '#22C55E'],
  predictionresult: [Target, '#FF6FB5'],
  votingwinner: [Crown, '#FFC400'],
  referralreward: [Gift, '#FF6FB5'],
  subscriptionexpiring: [AlertTriangle, '#F59E0B'],
  reportaction: [ShieldCheck, '#87CEEB'],
  commentreply: [MessageCircle, '#87CEEB'],
  publicationfeatured: [Sparkles, '#FFC400'],
  publicationpicked: [Gem, '#FFC400'],
  announcement: [Megaphone, '#04FFFF'],
  walletcredit: [Coins, '#22C55E'],
  walletdebit: [Wallet, '#F59E0B'],
};

/** Web notifications link to website paths — map them to app screens. */
function destination(n: AppNotification): (() => void) | null {
  const meta = (n.metadata ?? {}) as Record<string, unknown>;
  const chapterId = meta.chapterId ?? meta.chapter_id;
  const pubId = meta.publicationId ?? meta.publication_id;
  if (chapterId != null) return () => router.push({ pathname: '/read/[id]', params: { id: String(chapterId), ...(pubId != null ? { pub: String(pubId) } : {}) } });
  const url = n.linkUrl ?? '';
  const qid = /[?&]id=([^&]+)/.exec(url)?.[1];
  if (url.includes('/publications/read')) {
    if (qid) return () => router.push({ pathname: '/read/[id]', params: { id: qid } });
    if (pubId != null) return () => router.push({ pathname: '/publication/[id]', params: { id: String(pubId) } });
    const seg = /\/publications\/read\/([^/?]+)/.exec(url)?.[1];
    if (seg) return () => router.push({ pathname: '/publication/[id]', params: { id: decodeURIComponent(seg) } });
  }
  const pub = /\/publications\/([^/?]+)/.exec(url)?.[1];
  if (pub && !['chapters', 'collectibles', 'featured-publications', 'free-publications', 'munkai-picks', 'top-creators'].includes(pub)) {
    return () => router.push({ pathname: '/publication/[id]', params: { id: qid ?? decodeURIComponent(pub) } });
  }
  if (pubId != null) return () => router.push({ pathname: '/publication/[id]', params: { id: String(pubId) } });
  if (url.includes('/payments') || n.notificationType.toLowerCase().startsWith('wallet')) return () => router.navigate('/wallet');
  if (url.includes('/profile')) return () => router.navigate('/profile');
  return null;
}

function sectionOf(date: string) {
  const d = new Date(date);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return 'Earlier';
}

export default function Notifications() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const [tab, setTab] = useState<'all' | 'unread'>('all');
  const q = useFetch(QK.notifications, () => notificationsApi.page(1, 50));
  const [readIds, setReadIds] = useState<Set<number>>(new Set());
  const [allRead, setAllRead] = useState(false);

  useFocusEffect(
    useCallback(() => {
      q.reload();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  const isRead = (n: AppNotification) => allRead || n.isRead || readIds.has(n.id);
  const items = q.data?.items ?? [];
  const unread = items.filter((n) => !isRead(n)).length;
  const shown = tab === 'unread' ? items.filter((n) => !isRead(n)) : items;

  const sections = useMemo(() => {
    const map = new Map<string, AppNotification[]>();
    for (const n of shown) {
      const k = sectionOf(n.createdAt);
      map.set(k, [...(map.get(k) ?? []), n]);
    }
    return ['Today', 'Yesterday', 'Earlier'].filter((k) => map.has(k)).map((k) => ({ title: k, data: map.get(k)! }));
  }, [shown]);

  const markAll = async () => {
    setAllRead(true);
    try {
      await notificationsApi.markAllRead();
      toast.success('All notifications marked as read');
      q.reload();
    } catch (err) {
      setAllRead(false);
      toast.error('Couldn’t mark as read', apiErrorMessage(err));
    }
  };

  const openItem = (n: AppNotification) => {
    if (!isRead(n)) {
      setReadIds((s) => new Set(s).add(n.id));
      notificationsApi.markRead(n.id).catch(() => {});
    }
    destination(n)?.();
  };

  return (
    <View style={styles.root}>
      <StackHeader
        title="Notifications"
        right={
          <Pressable onPress={markAll} disabled={unread === 0} accessibilityRole="button" style={[styles.markAll, unread === 0 && { opacity: 0.4 }]}>
            <CheckCheck size={16} color={t.colors.primary} />
            <Text variant="subtitle" color="primary" style={styles.markAllText}>
              Mark all read
            </Text>
          </Pressable>
        }
      />
      <View style={[styles.segment, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]} accessibilityRole="tablist">
        {(['all', 'unread'] as const).map((k) => {
          const on = tab === k;
          return (
            <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: on }} style={[styles.segItem, on && { backgroundColor: t.colors.primary }]}>
              <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.segText}>
                {k === 'all' ? 'All' : 'Unread'}
              </Text>
              {k === 'unread' && unread > 0 ? (
                <View style={[styles.badge, { backgroundColor: on ? t.colors.onPrimary : t.colors.primary }]}>
                  <Text style={[styles.badgeText, { color: on ? t.colors.primary : t.colors.onPrimary }]}>{unread}</Text>
                </View>
              ) : null}
            </Pressable>
          );
        })}
      </View>

      {q.loading ? (
        <SkeletonGroup>
          {[0, 1, 2, 3, 4].map((i) => (
            <View key={i} style={styles.row}>
              <Skeleton width={44} height={44} radius={22} />
              <View style={{ flex: 1, gap: 6 }}>
                <Skeleton width="70%" height={13} radius={3} />
                <Skeleton width="90%" height={11} radius={3} />
                <Skeleton width="20%" height={9} radius={3} />
              </View>
            </View>
          ))}
        </SkeletonGroup>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(n) => String(n.id)}
          stickySectionHeadersEnabled={false}
          renderSectionHeader={({ section }) => (
            <Text variant="caption" color="mutedForeground" style={styles.section}>
              {section.title}
            </Text>
          )}
          renderItem={({ item, index }) => {
            const read = isRead(item);
            const [Icon, color] = ICON[item.notificationType?.toLowerCase()] ?? [Bell, t.colors.primary];
            return (
              <Pressable
                onPress={() => openItem(item)}
                accessibilityRole="button"
                accessibilityLabel={`${read ? '' : 'Unread. '}${item.title}. ${item.message}`}
                style={({ pressed }) => [
                  styles.row,
                  !read && { backgroundColor: withAlpha(t.colors.primary, 0.05) },
                  index > 0 && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.07) },
                  pressed && { backgroundColor: withAlpha(t.colors.primary, 0.1) },
                ]}
              >
                <View style={[styles.icon, { backgroundColor: withAlpha(color, 0.14) }]}>
                  <Icon size={20} color={color} />
                </View>
                <View style={styles.flex}>
                  <Text variant="subtitle" style={[styles.title, read && { fontFamily: t.fonts.bodyMedium, opacity: 0.85 }]}>
                    {item.title}
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" style={styles.msg}>
                    {item.message}
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" style={styles.when}>
                    {timeAgo(item.createdAt)}
                  </Text>
                </View>
                {!read ? <View style={[styles.dot, { backgroundColor: t.colors.primary, shadowColor: t.colors.primary }]} /> : <View style={styles.dotSpace} />}
              </Pressable>
            );
          }}
          ListEmptyComponent={
            q.error ? (
              <View style={styles.empty}>
                <Text variant="bodySmall" color="mutedForeground" align="center">
                  {apiErrorMessage(q.error)}
                </Text>
                <Button title="Try again" variant="outline" onPress={q.refetch} />
              </View>
            ) : (
              <View style={styles.empty}>
                <View style={[styles.emptyIcon, { borderColor: withAlpha(t.colors.primary, 0.3) }]}>
                  <Bell size={22} color={t.colors.primary} />
                </View>
                <Text variant="heading" align="center">
                  {tab === 'unread' ? 'You’re all caught up' : 'No notifications yet'}
                </Text>
                <Text variant="bodySmall" color="mutedForeground" align="center">
                  New chapters, replies and wallet updates show up here.
                </Text>
              </View>
            )
          }
          contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
          refreshControl={<RefreshControl refreshing={q.refreshing} onRefresh={q.refetch} tintColor={t.colors.primary} colors={[t.colors.primary]} />}
        />
      )}
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1, minWidth: 0 },
    markAll: { height: 36, paddingHorizontal: 10, marginRight: 4, flexDirection: 'row', alignItems: 'center', gap: 6 },
    markAllText: { fontSize: 12 },
    segment: { marginHorizontal: 20, marginTop: 12, marginBottom: 4, height: 40, padding: 3, borderRadius: 20, flexDirection: 'row' },
    segItem: { flex: 1, borderRadius: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
    segText: { fontSize: 13, lineHeight: 18 },
    badge: { minWidth: 20, height: 18, borderRadius: 9, paddingHorizontal: 5, alignItems: 'center', justifyContent: 'center' },
    badgeText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 11, lineHeight: 14 },
    section: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 6 },
    row: { flexDirection: 'row', gap: 14, paddingHorizontal: 20, paddingVertical: 14 },
    icon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
    title: { fontSize: 14, lineHeight: 19 },
    msg: { fontSize: 13, lineHeight: 18, marginTop: 2 },
    when: { fontSize: 11, lineHeight: 15, marginTop: 4, opacity: 0.8 },
    dot: { width: 9, height: 9, borderRadius: 5, marginTop: 6, shadowOpacity: 0.9, shadowRadius: 6, shadowOffset: { width: 0, height: 0 } },
    dotSpace: { width: 9 },
    empty: { alignItems: 'center', gap: 10, paddingTop: 60, paddingHorizontal: 32 },
    emptyIcon: { width: 52, height: 52, borderRadius: 26, borderWidth: 2, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center' },
  });
