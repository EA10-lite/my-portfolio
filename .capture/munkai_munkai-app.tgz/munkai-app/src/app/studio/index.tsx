/**
 * Creator Studio — approved mock "Creator Studio".
 * Data: GET /api/users/profile → creatorDetails.ownedPublications (includes drafts), same as the web /profile.
 */
import { Image } from 'expo-image';
import { router, useFocusEffect } from 'expo-router';
import { ChevronRight, Eye, Plus } from 'lucide-react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Cover } from '@/components/content/Cover';
import { HeaderIconButton, StackHeader } from '@/components/navigation/StackHeader';
import { Chip, StateBadge } from '@/components/studio/parts';
import { Button, CutShape, Text } from '@/components/ui';
import { formatBalance, formatCompact } from '@/lib/format';
import { openCreator, typeLabel } from '@/lib/publication';
import { TOKENS_PER_USD } from '@/lib/wallet';
import { isCreatorRole } from '@/services/creator';
import type { Publication } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

type Filter = 'all' | 'live' | 'drafts' | 'completed';
const FILTERS: { value: Filter; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'live', label: 'Live' },
  { value: 'drafts', label: 'Drafts' },
  { value: 'completed', label: 'Completed' },
];

export default function Studio() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const user = useSession((s) => s.user);
  const refreshProfile = useSession((s) => s.refreshProfile);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<Filter>('all');

  useFocusEffect(
    useCallback(() => {
      refreshProfile().catch(() => {});
    }, [refreshProfile]),
  );

  const pubs = useMemo(() => (user?.creatorDetails?.ownedPublications ?? []).filter((p) => !p.isDeleted), [user]);
  const shown = pubs.filter((p) =>
    filter === 'live'
      ? p.isPublished !== false
      : filter === 'drafts'
        ? p.isPublished === false
        : filter === 'completed'
          ? !!p.isCompleted
          : true,
  );

  if (user && !isCreatorRole(user.role)) {
    return (
      <View style={styles.root}>
        <StackHeader title="Creator Studio" />
        <View style={styles.empty}>
          <Text variant="heading" align="center">
            Become a creator first
          </Text>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            Apply once and, when you’re approved, your studio opens here.
          </Text>
          <Button title="Apply to create" onPress={() => router.replace('/become-creator')} />
        </View>
      </View>
    );
  }

  const chapters = pubs.reduce((n, p) => n + (Number(p.totalChapters) || 0), 0);
  const collects = pubs.reduce((n, p) => n + (Number(p.collectCount) || 0), 0);
  const hasCollects = pubs.some((p) => p.collectCount != null);
  const balance = Number(user?.balance) || 0;
  const tiles = [
    { value: formatCompact(user?.creatorDetails?.ownedPublicationsCount ?? pubs.length), label: 'Publications' },
    { value: formatCompact(user?.creatorDetails?.followersCount ?? 0), label: 'Followers' },
    { value: formatCompact(chapters), label: 'Chapters' },
    hasCollects
      ? { value: formatCompact(collects), label: 'Collects' }
      : { value: formatCompact(user?.followedCreators ?? 0), label: 'Following' },
  ];

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshProfile().catch(() => {});
    setRefreshing(false);
  };

  const header = (
    <View>
      <Pressable
        onPress={() => router.push('/wallet')}
        accessibilityRole="button"
        accessibilityLabel={`Balance ${formatBalance(balance)} tokens`}
        style={({ pressed }) => [pressed && { opacity: 0.85 }]}
      >
        <CutShape cuts={t.cuts.card} fill={t.colors.card} stroke="rgba(255,196,0,0.3)" style={styles.balance}>
          <Image source={require('../../../assets/images/munk-coin.png')} style={styles.coin} />
          <View style={styles.flex}>
            <Text style={styles.balanceLabel}>BALANCE</Text>
            <Text variant="display" style={styles.balanceValue}>
              {formatBalance(balance)}{' '}
              <Text variant="bodySmall" color="mutedForeground">
                ≈ ${(balance / TOKENS_PER_USD).toFixed(2)}
              </Text>
            </Text>
          </View>
          <ChevronRight size={18} color={t.colors.mutedForeground} />
        </CutShape>
      </Pressable>
      <View style={styles.tiles}>
        {tiles.map((x) => (
          <CutShape key={x.label} cuts={t.cuts.card} fill={t.colors.card} stroke={withAlpha(t.colors.primary, 0.1)} style={styles.tile}>
            <Text variant="display" color="primary" style={styles.tileValue}>
              {x.value}
            </Text>
            <Text style={styles.tileLabel}>{x.label.toUpperCase()}</Text>
          </CutShape>
        ))}
      </View>
      <Button
        title="New publication"
        fullWidth
        leftIcon={<Plus size={18} color={t.colors.onPrimary} strokeWidth={2.6} />}
        onPress={() => router.push('/studio/publication-form')}
        style={styles.newBtn}
      />
      <View style={styles.sectionHead}>
        <Text variant="title" style={styles.sectionTitle}>
          Your publications
        </Text>
        <Text variant="bodySmall" color="mutedForeground">
          {pubs.length}
        </Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
        {FILTERS.map((f) => (
          <Chip key={f.value} label={f.label} selected={filter === f.value} onPress={() => setFilter(f.value)} />
        ))}
      </ScrollView>
    </View>
  );

  return (
    <View style={styles.root}>
      <StackHeader
        title="Creator Studio"
        right={
          user ? (
            <HeaderIconButton label="View your public page" onPress={() => openCreator({ username: user.username })}>
              <Eye size={22} color={t.colors.foreground} />
            </HeaderIconButton>
          ) : undefined
        }
      />
      <FlatList
        data={shown}
        keyExtractor={(p) => String(p.id)}
        ListHeaderComponent={header}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 28 }]}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={t.colors.primary} colors={[t.colors.primary]} />
        }
        renderItem={({ item, index }) => <PubRow pub={item} divider={index > 0} />}
        ListEmptyComponent={
          <View style={styles.emptyList}>
            <Text variant="bodySmall" color="mutedForeground" align="center">
              {pubs.length ? 'Nothing here with this filter.' : 'You haven’t published anything yet. Start with a new publication.'}
            </Text>
          </View>
        }
      />
    </View>
  );
}

function PubRow({ pub, divider }: { pub: Publication; divider: boolean }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const n = Number(pub.totalChapters) || 0;
  return (
    <View style={[styles.row, divider && styles.divider]}>
      <Pressable
        onPress={() => router.push({ pathname: '/studio/[id]', params: { id: String(pub.id) } })}
        accessibilityRole="button"
        accessibilityLabel={`Manage ${pub.name}`}
        style={({ pressed }) => [styles.rowMain, pressed && { opacity: 0.8 }]}
      >
        <Cover uri={pub.coverPhoto} width={56} height={78} />
        <View style={styles.rowText}>
          <View style={styles.badges}>
            {pub.isPublished === false ? <StateBadge label="Draft" tone="draft" /> : null}
            {pub.isCompleted ? <StateBadge label="Completed" tone="done" /> : null}
            {pub.isFanfic ? <StateBadge label="Fan TL" tone="fan" /> : null}
          </View>
          <Text variant="subtitle" numberOfLines={1} style={styles.rowTitle}>
            {pub.name}
          </Text>
          <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.small}>
            {[typeLabel(pub.publicationType), `${n} chapter${n === 1 ? '' : 's'}`].filter(Boolean).join(' · ')}
          </Text>
        </View>
      </Pressable>
      <Pressable
        onPress={() => router.push({ pathname: '/studio/chapter', params: { pub: String(pub.id) } })}
        accessibilityRole="button"
        accessibilityLabel={`Add a chapter to ${pub.name}`}
        style={({ pressed }) => [styles.add, { backgroundColor: withAlpha(t.colors.primary, pressed ? 0.2 : 0.1) }]}
      >
        <Plus size={20} color={t.colors.primary} strokeWidth={2.4} />
      </Pressable>
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    list: { paddingHorizontal: 20, paddingTop: 16 },
    balance: { padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12 },
    coin: { width: 40, height: 40 },
    balanceLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 1.4, color: '#FFC400' },
    balanceValue: { fontSize: 26, lineHeight: 32 },
    tiles: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 10 },
    tile: { width: '48%', flexGrow: 1, padding: 14, gap: 2 },
    tileValue: { fontSize: 22, lineHeight: 28 },
    tileLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.2, color: t.colors.mutedForeground },
    newBtn: { marginTop: 16 },
    sectionHead: { flexDirection: 'row', alignItems: 'center', marginTop: 26, marginBottom: 10 },
    sectionTitle: { flex: 1, fontSize: 20 },
    chips: { gap: 8, paddingBottom: 12 },
    row: { minHeight: 96, flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10 },
    divider: { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.1) },
    rowMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 14 },
    rowText: { flex: 1, minWidth: 0, gap: 4 },
    badges: { flexDirection: 'row', gap: 6 },
    rowTitle: { fontSize: 16 },
    small: { fontSize: 12, lineHeight: 16 },
    add: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
    empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 32 },
    emptyList: { paddingVertical: 32 },
  });
