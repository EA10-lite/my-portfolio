/**
 * New / edit publication — approved mock "New / edit publication".
 * Create: POST /api/publications · Edit: PATCH /api/publications/:id (web create-publication.tsx / PubEditSheet).
 * Type and fiction are fixed after creation (same as the web edit sheet).
 */
import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';
import { ChevronRight, ImagePlus, X } from 'lucide-react-native';
import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { GenreSheet } from '@/components/studio/GenreSheet';
import { Chip, FieldLabel, Segmented } from '@/components/studio/parts';
import { Button, CutShape, Input, Skeleton, Text, useToast, KeyboardAvoid } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatSize, MB, pickImages } from '@/lib/pickers';
import { genres as genresOf } from '@/lib/publication';
import { studioKeys } from '@/lib/studio';
import { invalidate, useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import { creatorApi, PUB_TYPES, type PubType, type UploadFile } from '@/services/creator';
import type { Publication } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

const COVER_TYPES = ['image/png', 'image/jpeg', 'image/jpg', 'image/svg+xml'];
const words = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;

type Errors = Partial<Record<'cover' | 'name' | 'genre' | 'shortSummary' | 'summary' | 'originalWorkTitle' | 'originalAuthor', string>>;

export default function PublicationForm() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const editing = !!id;
  const existing = useFetch(editing ? studioKeys.pub(id!) : null, () => contentApi.publication(id!));
  if (editing && !existing.data) return <FormLoading error={existing.error} retry={existing.refetch} />;
  return <Form key={String(existing.data?.id ?? 'new')} existing={editing ? existing.data : undefined} />;
}

function FormLoading({ error, retry }: { error: unknown; retry: () => void }) {
  const styles = useThemedStyles(makeStyles);
  return (
    <View style={styles.root}>
      <StackHeader title="Edit publication" />
      {error ? (
        <View style={styles.center}>
          <Text variant="heading">Couldn’t load it</Text>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            {apiErrorMessage(error)}
          </Text>
          <Button title="Try again" variant="outline" onPress={retry} />
        </View>
      ) : (
        <View style={styles.scroll}>
          <Skeleton width={120} height={168} />
          <Skeleton width="100%" height={52} />
          <Skeleton width="100%" height={52} />
        </View>
      )}
    </View>
  );
}

function Form({ existing }: { existing?: Publication }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const refreshProfile = useSession((s) => s.refreshProfile);
  const editing = !!existing;

  const initialType = useMemo<PubType>(() => {
    const v = (existing?.publicationType ?? '').toLowerCase();
    return (PUB_TYPES.find((x) => x.value.toLowerCase() === v)?.value ?? 'Comic') as PubType;
  }, [existing]);

  const [cover, setCover] = useState<UploadFile | null>(null);
  const [name, setName] = useState(existing?.name ?? '');
  const [type, setType] = useState<PubType>(initialType);
  const [fiction, setFiction] = useState(existing?.isFiction !== false);
  const [genre, setGenre] = useState<string[]>(existing ? genresOf(existing) : []);
  const [shortSummary, setShortSummary] = useState(existing?.shortSummary ?? '');
  const [summary, setSummary] = useState(existing?.summary ?? '');
  const [fanfic, setFanfic] = useState(!!existing?.isFanfic);
  const [origTitle, setOrigTitle] = useState(existing?.originalWorkTitle ?? '');
  const [origAuthor, setOrigAuthor] = useState(existing?.originalAuthor ?? '');
  const [origLang, setOrigLang] = useState(existing?.originalLanguage ?? '');
  const [origUrl, setOrigUrl] = useState(existing?.originalSourceUrl ?? '');
  const [genreSheet, setGenreSheet] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!fiction) setFanfic(false);
  }, [fiction]);

  const coverUri = cover?.uri ?? existing?.coverPhoto ?? null;
  const shortWords = words(shortSummary);

  const pickCover = async () => {
    try {
      const [img] = await pickImages({ aspect: [3, 4] });
      if (!img) return;
      if (!COVER_TYPES.includes(img.type.toLowerCase())) {
        setErrors((e) => ({ ...e, cover: 'Use a PNG or JPG image.' }));
        return;
      }
      if (img.size && img.size > 5 * MB) {
        setErrors((e) => ({ ...e, cover: `That image is ${formatSize(img.size)} — the limit is 5 MB.` }));
        return;
      }
      setCover(img);
      setErrors((e) => ({ ...e, cover: undefined }));
    } catch (err) {
      toast.error((err as Error).message === 'permission' ? 'Allow photo access in Settings to add a cover.' : 'Couldn’t open your photos');
    }
  };

  const validate = (): Errors => {
    const e: Errors = {};
    if (!editing && !cover) e.cover = 'Add a cover image.';
    if (!name.trim()) e.name = 'Give it a title.';
    if (!genre.length) e.genre = 'Pick at least one genre.';
    if (!shortSummary.trim()) e.shortSummary = 'Write a short summary.';
    else if (shortWords > 30) e.shortSummary = `Keep it to 30 words (now ${shortWords}).`;
    if (!summary.trim()) e.summary = 'Write the full summary.';
    if (fanfic && !editing) {
      if (!origTitle.trim()) e.originalWorkTitle = 'Required for a fan translation.';
      if (!origAuthor.trim()) e.originalAuthor = 'Required for a fan translation.';
    }
    return e;
  };

  const submit = async () => {
    const e = validate();
    setErrors(e);
    if (Object.values(e).some(Boolean)) {
      haptic.error().catch(() => {});
      toast.error('Check the highlighted fields');
      return;
    }
    setSaving(true);
    const input = {
      name,
      genre,
      type,
      isFiction: fiction,
      shortSummary,
      summary,
      isFanfic: fanfic,
      originalWorkTitle: origTitle,
      originalAuthor: origAuthor,
      originalLanguage: editing ? origLang : undefined,
      originalSourceUrl: origUrl,
      coverPhoto: cover,
    };
    try {
      if (editing) {
        await creatorApi.updatePublication(existing!.id, input);
        invalidate(studioKeys.pub(existing!.id));
        invalidate(`publication/${existing!.id}`);
        toast.success('Publication updated');
        await refreshProfile().catch(() => {});
        router.back();
      } else {
        const created = await creatorApi.createPublication(input);
        haptic.success().catch(() => {});
        toast.success('Publication created', 'Now add your first chapter.');
        await refreshProfile().catch(() => {});
        const newId = created && typeof created === 'object' ? (created as Publication).id : undefined;
        if (newId != null) router.replace({ pathname: '/studio/[id]', params: { id: String(newId) } });
        else router.back();
      }
    } catch (err) {
      toast.error(editing ? 'Couldn’t save changes' : 'Couldn’t create publication', apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.root}>
      <StackHeader title={editing ? 'Edit publication' : 'New publication'} />
      <KeyboardAvoid>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive">
          {/* Cover */}
          <View style={styles.coverRow}>
            <Pressable
              onPress={pickCover}
              accessibilityRole="button"
              accessibilityLabel={coverUri ? 'Change cover image' : 'Add cover image'}
              style={({ pressed }) => [
                styles.cover,
                !coverUri && {
                  borderWidth: 2,
                  borderStyle: 'dashed',
                  borderColor: errors.cover ? t.colors.destructive : withAlpha(t.colors.primary, 0.4),
                },
                pressed && { opacity: 0.8 },
              ]}
            >
              {coverUri ? (
                <Image source={{ uri: coverUri }} style={StyleSheet.absoluteFill} contentFit="cover" />
              ) : (
                <>
                  <ImagePlus size={28} color={t.colors.primary} />
                  <Text variant="subtitle" color="primary" style={styles.coverText}>
                    Add cover
                  </Text>
                </>
              )}
            </Pressable>
            <View style={styles.coverInfo}>
              <Text variant="subtitle">Cover art</Text>
              <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                Portrait works best (3:4). PNG or JPG, up to 5 MB.
              </Text>
              <Pressable onPress={pickCover} accessibilityRole="button" hitSlop={8}>
                <Text variant="subtitle" color="primary" style={styles.small}>
                  {coverUri ? 'Change image' : 'Choose from photos'}
                </Text>
              </Pressable>
              {errors.cover ? (
                <Text variant="bodySmall" color="destructive" style={styles.small}>
                  {errors.cover}
                </Text>
              ) : null}
            </View>
          </View>

          <Input label="Title" value={name} onChangeText={setName} error={errors.name} placeholder="What’s it called?" maxLength={120} />

          {!editing ? (
            <>
              <View style={styles.block}>
                <FieldLabel>Type</FieldLabel>
                <View style={styles.wrap}>
                  {PUB_TYPES.map((x) => (
                    <Chip key={x.value} label={x.label} selected={type === x.value} onPress={() => setType(x.value)} />
                  ))}
                </View>
              </View>
              <View style={styles.block}>
                <FieldLabel>Kind</FieldLabel>
                <Segmented
                  options={[
                    { value: 'fiction', label: 'Fiction' },
                    { value: 'non', label: 'Non-fiction' },
                  ]}
                  value={fiction ? 'fiction' : 'non'}
                  onChange={(v) => setFiction(v === 'fiction')}
                />
              </View>
            </>
          ) : (
            <Text variant="bodySmall" color="mutedForeground">
              {PUB_TYPES.find((x) => x.value === type)?.label} · {fiction ? 'Fiction' : 'Non-fiction'} — these can’t change after
              publishing.
            </Text>
          )}

          <View style={styles.block}>
            <FieldLabel>Genres</FieldLabel>
            <Pressable
              onPress={() => setGenreSheet(true)}
              accessibilityRole="button"
              accessibilityLabel={genre.length ? `Genres: ${genre.join(', ')}. Change` : 'Pick genres'}
              style={[styles.genreField, { borderColor: errors.genre ? t.colors.destructive : withAlpha(t.colors.primary, 0.18) }]}
            >
              <View style={styles.genreChips}>
                {genre.length ? (
                  genre.map((g) => (
                    <Pressable
                      key={g}
                      onPress={() => setGenre((s) => s.filter((x) => x !== g))}
                      accessibilityLabel={`Remove ${g}`}
                      style={[styles.genreChip, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}
                    >
                      <Text variant="subtitle" color="primary" style={styles.genreChipText}>
                        {g}
                      </Text>
                      <X size={12} color={t.colors.primary} strokeWidth={2.6} />
                    </Pressable>
                  ))
                ) : (
                  <Text variant="body" color="mutedForeground" style={styles.placeholder}>
                    Pick one or more
                  </Text>
                )}
              </View>
              <ChevronRight size={18} color={t.colors.mutedForeground} />
            </Pressable>
            {errors.genre ? (
              <Text variant="bodySmall" color="destructive">
                {errors.genre}
              </Text>
            ) : null}
          </View>

          <View style={styles.block}>
            <Input
              label="Short summary"
              value={shortSummary}
              onChangeText={setShortSummary}
              multiline
              error={errors.shortSummary}
              hint="Shown on cards and in search."
              placeholder="One or two lines that hook a reader"
              style={styles.shortInput}
            />
            <Text variant="caption" style={[styles.counter, shortWords > 30 && { color: t.colors.destructive }]}>
              {shortWords} / 30 words
            </Text>
          </View>

          <Input
            label="Full summary"
            value={summary}
            onChangeText={setSummary}
            multiline
            error={errors.summary}
            placeholder="What’s the story about?"
          />

          {fiction ? (
            <CutShape cuts={t.cuts.card} fill={t.colors.card} stroke="rgba(4,255,255,0.25)" style={styles.fan}>
              <View style={styles.fanHead}>
                <View style={styles.flex}>
                  <Text variant="subtitle">Fan translation</Text>
                  <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                    This is a translation of someone else’s work
                  </Text>
                </View>
                <Switch
                  value={fanfic}
                  onValueChange={setFanfic}
                  trackColor={{ true: t.colors.primary, false: withAlpha(t.colors.foreground, 0.2) }}
                  thumbColor={fanfic ? t.colors.onPrimary : '#C9CCD6'}
                  accessibilityLabel="Fan translation"
                />
              </View>
              {fanfic ? (
                <>
                  <Input label="Original title" value={origTitle} onChangeText={setOrigTitle} error={errors.originalWorkTitle} />
                  <Input label="Original author" value={origAuthor} onChangeText={setOrigAuthor} error={errors.originalAuthor} />
                  {editing ? (
                    <Input label="Original language" value={origLang} onChangeText={setOrigLang} placeholder="e.g. Korean" />
                  ) : null}
                  <Input
                    label="Source link (optional)"
                    value={origUrl}
                    onChangeText={setOrigUrl}
                    placeholder="https://"
                    autoCapitalize="none"
                    keyboardType="url"
                  />
                </>
              ) : null}
            </CutShape>
          ) : null}
        </ScrollView>
        <View style={[styles.footer, { paddingBottom: insets.bottom + 14 }]}>
          <Button title={editing ? 'Save changes' : 'Create publication'} fullWidth loading={saving} onPress={submit} />
        </View>
      </KeyboardAvoid>

      <GenreSheet
        visible={genreSheet}
        value={genre}
        fiction={fiction}
        onClose={() => setGenreSheet(false)}
        onDone={(g) => {
          setGenre(g);
          setGenreSheet(false);
          if (g.length) setErrors((e) => ({ ...e, genre: undefined }));
        }}
      />
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, padding: 32 },
    scroll: { padding: 20, paddingBottom: 40, gap: 22 },
    coverRow: { flexDirection: 'row', gap: 16, alignItems: 'flex-end' },
    cover: {
      width: 120,
      height: 168,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      overflow: 'hidden',
      backgroundColor: withAlpha(t.colors.primary, 0.05),
    },
    coverText: { fontSize: 12 },
    coverInfo: { flex: 1, gap: 6 },
    small: { fontSize: 12, lineHeight: 17 },
    block: { gap: 8 },
    wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    genreField: {
      minHeight: 52,
      paddingVertical: 8,
      paddingLeft: 8,
      paddingRight: 12,
      borderWidth: 1,
      backgroundColor: t.colors.card,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
    },
    genreChips: { flex: 1, flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
    genreChip: { height: 30, paddingHorizontal: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
    genreChipText: { fontSize: 12 },
    placeholder: { paddingLeft: 8 },
    shortInput: { minHeight: 80 },
    counter: { position: 'absolute', right: 0, top: 0 },
    fan: { padding: 16, gap: 16 },
    fanHead: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    footer: {
      paddingHorizontal: 20,
      paddingTop: 12,
      borderTopWidth: 1,
      borderTopColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: t.colors.pageBackground,
    },
  });
