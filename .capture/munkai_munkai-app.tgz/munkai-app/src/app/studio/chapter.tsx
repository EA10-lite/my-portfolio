/**
 * New / edit chapter — approved mocks "New chapter · Write", "· Comic pages", "· Publish settings".
 * New: GET /api/chapters/next-number → POST /api/chapters (multipart).
 * Edit: GET /api/chapters/read?chapterId → PATCH /api/chapters/:id (name, content, price, pdf/pages).
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';
import { FileText, ImagePlus, Images, Plus, RefreshCw, X } from 'lucide-react-native';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Alert, Pressable, ScrollView, StyleSheet, TextInput, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useKeyboardInset } from '@/hooks/useKeyboardInset';
import { DragSort } from '@/components/studio/DragSort';
import { PublishSheet, type PublishSettings } from '@/components/studio/PublishSheet';
import { EditorToolbar, EMPTY_STATE, RichEditor, type EditorState, type RichEditorHandle } from '@/components/studio/RichEditor';
import { Segmented } from '@/components/studio/parts';
import { Button, CutShape, Skeleton, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatSize, MB, naturalByName, pickImages, pickPdf } from '@/lib/pickers';
import { chapterStateOf, studioKeys } from '@/lib/studio';
import { invalidate, useFetch } from '@/lib/useFetch';
import { chaptersApi, parseChapterContent } from '@/services/chapters';
import { contentApi } from '@/services/content';
import { creatorApi, editsLeft, type UploadFile } from '@/services/creator';
import type { ChapterContent } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

const PAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_PAGES = 300;
const draftKey = (pub: string) => `munkai_chapter_draft_${pub}`;
const plain = (html: string) =>
  html
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .trim();

export default function ChapterScreen() {
  const { pub, chapter } = useLocalSearchParams<{ pub: string; chapter?: string }>();
  const publication = useFetch(studioKeys.pub(pub), () => contentApi.publication(pub));
  const existing = useFetch(chapter ? `studio/chapter/${chapter}` : null, () => chaptersApi.read(chapter!));
  const next = useFetch(chapter ? null : `studio/next/${pub}`, () => creatorApi.nextChapterNumber(pub));
  const [draft, setDraft] = useState<{ name?: string; html?: string } | null | undefined>(chapter ? null : undefined);

  useEffect(() => {
    if (chapter) return;
    AsyncStorage.getItem(draftKey(pub))
      .then((s) => setDraft(s ? JSON.parse(s) : null))
      .catch(() => setDraft(null));
  }, [pub, chapter]);

  const error = publication.error || existing.error || next.error;
  const ready = publication.data && (chapter ? existing.data : next.data != null) && draft !== undefined;
  if (!ready) return <Loading error={error} retry={() => (publication.refetch(), existing.refetch(), next.refetch())} />;
  return (
    <Editor
      pubId={publication.data!.id}
      pubName={publication.data!.name}
      isComic={(publication.data!.publicationType ?? '').toLowerCase() === 'comic'}
      isFanfic={!!publication.data!.isFanfic}
      chapterId={chapter}
      existing={existing.data ?? undefined}
      chapterNumber={chapter ? (existing.data?.chapterNumber ?? 0) : next.data!}
      draft={draft ?? null}
    />
  );
}

function Loading({ error, retry }: { error: unknown; retry: () => void }) {
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.root, { paddingTop: insets.top + 60 }]}>
      {error ? (
        <View style={styles.center}>
          <Text variant="heading">Couldn’t open the editor</Text>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            {apiErrorMessage(error)}
          </Text>
          <Button title="Try again" variant="outline" onPress={retry} />
          <Button title="Close" variant="ghost" onPress={() => router.back()} />
        </View>
      ) : (
        <View style={styles.pad}>
          <Skeleton width="60%" height={28} />
          <Skeleton width="100%" height={16} />
          <Skeleton width="90%" height={16} />
          <Skeleton width="95%" height={16} />
        </View>
      )}
    </View>
  );
}

type ExistingChapter = ChapterContent;

function Editor({
  pubId,
  pubName,
  isComic,
  isFanfic,
  chapterId,
  existing,
  chapterNumber,
  draft,
}: {
  pubId: string | number;
  pubName: string;
  isComic: boolean;
  isFanfic: boolean;
  chapterId?: string;
  existing?: ExistingChapter;
  chapterNumber: number;
  draft: { name?: string; html?: string } | null;
}) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { width } = useWindowDimensions();
  const refreshProfile = useSession((s) => s.refreshProfile);
  const editing = !!chapterId;

  const parsed = useMemo(() => parseChapterContent(existing?.content), [existing]);
  const [name, setName] = useState(existing?.name ?? draft?.name ?? '');
  const [html, setHtml] = useState(parsed.kind === 'text' ? parsed.html : (draft?.html ?? ''));
  const initialHtml = useRef(editing ? (parsed.kind === 'text' ? parsed.html : '') : (draft?.html ?? '')).current;
  const [comicMode, setComicMode] = useState<'pages' | 'pdf'>(parsed.kind === 'pdf' ? 'pdf' : 'pages');
  const [pages, setPages] = useState<UploadFile[]>([]);
  const [pdf, setPdf] = useState<UploadFile | null>(null);
  const remotePages = parsed.kind === 'images' ? parsed.pages : [];
  const remotePdf = parsed.kind === 'pdf' ? parsed.url : null;
  const [replacePages, setReplacePages] = useState(!editing || remotePages.length === 0);
  const [scroll, setScroll] = useState(true);
  const [fmt, setFmt] = useState<EditorState>(EMPTY_STATE);
  const [sheet, setSheet] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(draft ? Date.now() : null);
  const editor = useRef<RichEditorHandle>(null);
  const keyboard = useKeyboardInset(insets.bottom);
  const dirty = useRef(false);

  // Autosave new text chapters on the device, like a notes app.
  useEffect(() => {
    if (editing || isComic) return;
    const id = setTimeout(() => {
      if (!plain(html) && !name.trim()) return;
      AsyncStorage.setItem(draftKey(String(pubId)), JSON.stringify({ name, html }))
        .then(() => setSavedAt(Date.now()))
        .catch(() => {});
    }, 800);
    return () => clearTimeout(id);
  }, [html, name, editing, isComic, pubId]);

  const state = existing ? chapterStateOf({ state: existing.state, publishAt: existing.publishAt }) : 'draft';
  const left = editsLeft(existing?.editCount, isFanfic);
  const locked = editing && state === 'live' && left === 0;

  const close = () => {
    const leave = () => (router.canGoBack() ? router.back() : router.replace('/studio'));
    if (!dirty.current || (!editing && !isComic)) return leave(); // new text chapters are autosaved
    Alert.alert('Discard changes?', 'Your changes to this chapter won’t be saved.', [
      { text: 'Keep editing', style: 'cancel' },
      { text: 'Discard', style: 'destructive', onPress: leave },
    ]);
  };

  const addPages = async () => {
    try {
      const picked = await pickImages({ multiple: true, limit: MAX_PAGES - pages.length });
      const ok = picked.filter((p) => PAGE_TYPES.includes(p.type.toLowerCase()));
      if (ok.length < picked.length) toast.info('Some files were skipped', 'Pages must be JPG, PNG or WebP.');
      if (!ok.length) return;
      dirty.current = true;
      setPages((cur) => [...cur, ...ok.sort(naturalByName)].slice(0, MAX_PAGES));
    } catch (err) {
      toast.error((err as Error).message === 'permission' ? 'Allow photo access in Settings to add pages.' : 'Couldn’t open your photos');
    }
  };

  const choosePdf = async () => {
    const f = await pickPdf().catch(() => null);
    if (!f) return;
    if (f.size && f.size > 10 * MB) {
      toast.error('That PDF is too big', `It’s ${formatSize(f.size)} — the limit is 10 MB.`);
      return;
    }
    dirty.current = true;
    setPdf(f);
  };

  const onNext = () => {
    if (isComic) {
      const hasContent =
        comicMode === 'pdf' ? !!pdf || (editing && !!remotePdf) : pages.length > 0 || (editing && !replacePages && remotePages.length > 0);
      if (!hasContent) {
        haptic.error().catch(() => {});
        toast.error(comicMode === 'pdf' ? 'Choose a PDF for this chapter' : 'Add at least one page');
        return;
      }
    } else if (!plain(editor.current?.getHtml() ?? html)) {
      haptic.error().catch(() => {});
      toast.error('Write something first');
      return;
    }
    editor.current?.blur();
    setSheet(true);
  };

  const submit = async (s: PublishSettings) => {
    const text = isComic ? undefined : (editor.current?.getHtml() ?? html);
    const media = isComic && comicMode === 'pdf' ? { pdf: pdf ?? undefined } : isComic && (replacePages || !editing) ? { pages } : {};
    setSaving(true);
    try {
      if (editing) {
        await creatorApi.updateChapter(chapterId!, { name, price: s.price, html: text, ...media });
        invalidate(`studio/chapter/${chapterId}`);
        toast.success('Chapter updated');
      } else {
        await creatorApi.createChapter({
          publicationId: pubId,
          chapterNumber,
          name,
          price: s.price,
          mode: s.mode,
          publishAt: s.publishAt,
          html: text,
          ...media,
        });
        AsyncStorage.removeItem(draftKey(String(pubId))).catch(() => {});
        haptic.success().catch(() => {});
        toast.success(s.mode === 'draft' ? 'Draft saved' : s.mode === 'schedule' ? 'Chapter scheduled' : 'Chapter published');
      }
      invalidate(studioKeys.chapters(pubId));
      invalidate(`chapters/${pubId}`);
      refreshProfile().catch(() => {});
      setSheet(false);
      router.back();
    } catch (err) {
      toast.error(editing ? 'Couldn’t save the chapter' : 'Couldn’t publish the chapter', apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const cols = 3;
  const gap = 10;
  const cellW = Math.floor((width - 40 - gap * (cols - 1)) / cols);
  const cellH = Math.round(cellW * 1.38);

  const status = editing
    ? isFanfic
      ? 'Editing'
      : state === 'live'
        ? `${left} edit${left === 1 ? '' : 's'} left`
        : 'Editing'
    : isComic
      ? 'New'
      : savedAt
        ? 'Saved'
        : 'New';

  const header = (
    <View style={[styles.header, { paddingTop: insets.top + 4 }]}>
      <Pressable onPress={close} accessibilityRole="button" accessibilityLabel="Close" style={styles.headerBtn} hitSlop={6}>
        <X size={24} color={t.colors.foreground} />
      </Pressable>
      <View style={styles.headerMid}>
        <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.headerSub}>
          {pubName}
        </Text>
        <Text variant="subtitle" numberOfLines={1}>
          Chapter {chapterNumber}
          <Text variant="subtitle" color="mutedForeground" style={styles.headerStatus}>{` · ${status}`}</Text>
        </Text>
      </View>
      <Button title="Next" size="sm" onPress={onNext} disabled={locked} style={styles.next} />
    </View>
  );

  if (locked) {
    return (
      <View style={styles.root}>
        {header}
        <View style={styles.center}>
          <Text variant="heading" align="center">
            No edits left
          </Text>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            Original works can be edited twice per chapter, and this one has used both.
          </Text>
        </View>
      </View>
    );
  }

  const titleInput = (
    <TextInput
      value={name}
      onChangeText={(v) => {
        dirty.current = true;
        setName(v);
      }}
      placeholder="Chapter title (optional)"
      placeholderTextColor={withAlpha(t.colors.mutedForeground, 0.7)}
      style={[styles.title, { color: t.colors.foreground }]}
      maxLength={120}
      returnKeyType="next"
      onSubmitEditing={() => editor.current?.focus()}
      accessibilityLabel="Chapter title"
    />
  );

  if (!isComic) {
    return (
      <View style={styles.root}>
        {header}
        <Animated.View style={{ flex: 1, paddingBottom: keyboard }}>
          <View style={styles.titleWrap}>{titleInput}</View>
          <RichEditor
            ref={editor}
            initialHtml={initialHtml}
            placeholder="Start writing your chapter…"
            onChange={(h) => {
              dirty.current = true;
              setHtml(h);
            }}
            onStateChange={setFmt}
          />
          {/* Formatting bar sits right on the keyboard; above the home indicator when it's closed. */}
          <EditorToolbar onCommand={(c, v) => editor.current?.exec(c, v)} state={fmt} />
          <Animated.View
            style={{
              height: keyboard.interpolate({ inputRange: [0, 1], outputRange: [insets.bottom, 0], extrapolate: 'clamp' }),
              backgroundColor: t.colors.card,
            }}
          />
        </Animated.View>
        <PublishSheet
          visible={sheet}
          editing={editing}
          initialPrice={Number(existing?.price) || 0}
          saving={saving}
          onClose={() => setSheet(false)}
          onSubmit={submit}
        />
      </View>
    );
  }

  return (
    <View style={styles.root}>
      {header}
      <ScrollView
        scrollEnabled={scroll}
        contentContainerStyle={[styles.pad, { paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
      >
        {titleInput}
        <Segmented
          value={comicMode}
          onChange={(m) => {
            dirty.current = true;
            setComicMode(m);
          }}
          options={[
            { value: 'pages', label: 'Page images', icon: Images },
            { value: 'pdf', label: 'Single PDF', icon: FileText },
          ]}
        />

        {comicMode === 'pdf' ? (
          <View style={styles.block}>
            {pdf || remotePdf ? (
              <CutShape cuts={t.cuts.card} fill={t.colors.card} stroke={withAlpha(t.colors.primary, 0.25)} style={styles.pdf}>
                <FileText size={24} color={t.colors.primary} />
                <View style={styles.flex}>
                  <Text variant="subtitle" numberOfLines={1}>
                    {pdf?.name ?? 'Current PDF'}
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                    {pdf ? formatSize(pdf.size) || 'PDF' : 'Keeps the current file unless you replace it'}
                  </Text>
                </View>
                <Pressable onPress={choosePdf} accessibilityRole="button" hitSlop={8}>
                  <Text variant="subtitle" color="primary" style={styles.small}>
                    Replace
                  </Text>
                </Pressable>
              </CutShape>
            ) : (
              <Pressable
                onPress={choosePdf}
                accessibilityRole="button"
                style={({ pressed }) => [styles.drop, { borderColor: withAlpha(t.colors.primary, 0.4) }, pressed && { opacity: 0.8 }]}
              >
                <FileText size={28} color={t.colors.primary} />
                <Text variant="subtitle" color="primary">
                  Choose a PDF
                </Text>
                <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                  Up to 10 MB
                </Text>
              </Pressable>
            )}
          </View>
        ) : editing && !replacePages ? (
          <View style={styles.block}>
            <View style={styles.pagesHead}>
              <Text variant="subtitle" style={styles.flex}>
                {remotePages.length} pages
              </Text>
              <Pressable
                onPress={() => {
                  dirty.current = true;
                  setReplacePages(true);
                }}
                accessibilityRole="button"
                hitSlop={8}
                style={styles.inline}
              >
                <RefreshCw size={14} color={t.colors.primary} />
                <Text variant="subtitle" color="primary" style={styles.small}>
                  Replace pages
                </Text>
              </Pressable>
            </View>
            <View style={styles.grid}>
              {remotePages.map((uri, i) => (
                <View key={uri + i} style={{ width: cellW, height: cellH }}>
                  <Image source={{ uri }} style={StyleSheet.absoluteFill} contentFit="cover" />
                  <PageNum n={i + 1} />
                </View>
              ))}
            </View>
          </View>
        ) : (
          <View style={styles.block}>
            <View style={styles.pagesHead}>
              <Text variant="subtitle" style={styles.flex}>
                {pages.length} page{pages.length === 1 ? '' : 's'}
                <Text variant="bodySmall" color="mutedForeground">
                  {pages.length > 1 ? ' · sorted by file name' : ''}
                </Text>
              </Text>
              {pages.length ? (
                <Pressable onPress={() => setPages([])} accessibilityRole="button" hitSlop={8}>
                  <Text variant="subtitle" style={[styles.small, { color: t.colors.destructive }]}>
                    Clear all
                  </Text>
                </Pressable>
              ) : null}
            </View>
            {pages.length ? (
              <DragSort
                items={pages}
                keyOf={(p) => p.uri}
                onChange={setPages}
                onDragStateChange={(d) => setScroll(!d)}
                layout={{ kind: 'grid', columns: cols, cellWidth: cellW, cellHeight: cellH, gap }}
                itemLabel={(p, i) => `Page ${i + 1}`}
                renderItem={(p, i, active) => (
                  <View style={[styles.cell, active && { borderColor: t.colors.primary, borderWidth: 2 }]}>
                    <Image source={{ uri: p.uri }} style={StyleSheet.absoluteFill} contentFit="cover" />
                    <PageNum n={i + 1} />
                  </View>
                )}
                renderOverlay={(p) => (
                  <Pressable
                    onPress={() => setPages((cur) => cur.filter((x) => x.uri !== p.uri))}
                    accessibilityRole="button"
                    accessibilityLabel="Remove page"
                    hitSlop={8}
                    style={styles.remove}
                  >
                    <X size={13} color="#F2F2F2" strokeWidth={2.6} />
                  </Pressable>
                )}
              />
            ) : null}
            <Pressable
              onPress={addPages}
              accessibilityRole="button"
              style={({ pressed }) => [
                pages.length ? styles.addMore : styles.drop,
                { borderColor: withAlpha(t.colors.primary, 0.4) },
                pressed && { opacity: 0.8 },
              ]}
            >
              {pages.length ? <Plus size={20} color={t.colors.primary} /> : <ImagePlus size={28} color={t.colors.primary} />}
              <Text variant="subtitle" color="primary">
                {pages.length ? 'Add more pages' : 'Add pages'}
              </Text>
              {!pages.length ? (
                <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                  JPG, PNG or WebP · up to 300
                </Text>
              ) : null}
            </Pressable>
            {pages.length > 1 ? (
              <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                Hold a page, then drag it to reorder.
              </Text>
            ) : null}
          </View>
        )}
      </ScrollView>
      <PublishSheet
        visible={sheet}
        editing={editing}
        initialPrice={Number(existing?.price) || 0}
        saving={saving}
        onClose={() => setSheet(false)}
        onSubmit={submit}
      />
    </View>
  );
}

function PageNum({ n }: { n: number }) {
  return (
    <View style={pageStyles.num}>
      <Text style={pageStyles.numText}>{n}</Text>
    </View>
  );
}
const pageStyles = StyleSheet.create({
  num: {
    position: 'absolute',
    left: 6,
    top: 6,
    minWidth: 22,
    height: 22,
    paddingHorizontal: 5,
    backgroundColor: 'rgba(0,0,43,0.85)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  numText: { color: '#F2F2F2', fontSize: 11, fontWeight: '700' },
});

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, padding: 32 },
    pad: { padding: 20, gap: 16 },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      paddingHorizontal: 8,
      paddingBottom: 8,
      borderBottomWidth: 1,
      borderBottomColor: withAlpha(t.colors.primary, 0.1),
    },
    headerBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
    headerMid: { flex: 1, alignItems: 'center' },
    headerSub: { fontSize: 12, lineHeight: 16 },
    headerStatus: { fontWeight: '500' },
    next: { marginRight: 8, minWidth: 72 },
    titleWrap: { paddingHorizontal: 20, paddingTop: 14 },
    title: { fontSize: 24, lineHeight: 30, fontFamily: t.fonts.displayBold, paddingVertical: 6 },
    block: { gap: 12 },
    small: { fontSize: 12, lineHeight: 17 },
    pagesHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    inline: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
    cell: { flex: 1, overflow: 'hidden', backgroundColor: withAlpha(t.colors.primary, 0.08) },
    remove: {
      position: 'absolute',
      right: 6,
      top: 6,
      width: 26,
      height: 26,
      borderRadius: 13,
      backgroundColor: 'rgba(0,0,43,0.85)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    drop: { height: 170, borderWidth: 2, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', gap: 6 },
    addMore: {
      height: 52,
      borderWidth: 2,
      borderStyle: 'dashed',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
    },
    pdf: { padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12 },
  });
