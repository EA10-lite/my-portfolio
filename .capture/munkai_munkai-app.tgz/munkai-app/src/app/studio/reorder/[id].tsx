/**
 * Reorder chapters — approved mock "Reorder chapters (drag)".
 * PATCH /api/chapters/reorder { publicationId, chapterIds } (web ManageChaptersSheet).
 */
import { router, useLocalSearchParams } from 'expo-router';
import { GripVertical } from 'lucide-react-native';
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { DragSort } from '@/components/studio/DragSort';
import { StateBadge } from '@/components/studio/parts';
import { Button, Skeleton, SkeletonGroup, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { chapterStateOf, studioKeys } from '@/lib/studio';
import { invalidate, useFetch } from '@/lib/useFetch';
import { chaptersApi } from '@/services/chapters';
import { creatorApi } from '@/services/creator';
import type { ChapterIndexEntry } from '@/services/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const ROW = 62;

export default function ReorderChapters() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { id } = useLocalSearchParams<{ id: string }>();
  const q = useFetch(`studio/reorder/${id}`, () => chaptersApi.index(id, 'asc'));
  const [items, setItems] = useState<ChapterIndexEntry[] | null>(null);
  const [scroll, setScroll] = useState(true);
  const [saving, setSaving] = useState(false);

  const original = React.useMemo(
    () => (q.data ?? []).filter((c) => !c.isDeleted).sort((a, b) => a.chapterNumber - b.chapterNumber),
    [q.data],
  );
  useEffect(() => {
    if (q.data && !items) setItems(original);
  }, [q.data, items, original]);

  const dirty = !!items && items.some((c, i) => c.id !== original[i]?.id);

  const save = async () => {
    if (!items) return;
    setSaving(true);
    try {
      await creatorApi.reorder(
        id,
        items.map((c) => c.id),
      );
      invalidate(studioKeys.chapters(id));
      invalidate(`chapters/${id}`);
      toast.success('Order saved');
      router.back();
    } catch (err) {
      toast.error('Couldn’t save the order', apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.root}>
      <StackHeader
        title="Reorder chapters"
        right={
          <Pressable onPress={() => setItems(original)} disabled={!dirty} accessibilityRole="button" style={styles.reset} hitSlop={6}>
            <Text variant="subtitle" color={dirty ? 'primary' : 'mutedForeground'} style={styles.resetText}>
              Reset
            </Text>
          </Pressable>
        }
      />
      <ScrollView scrollEnabled={scroll} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 110 }}>
        <Text variant="bodySmall" color="mutedForeground" style={styles.hint}>
          Hold a chapter, then drag it. Numbers update when you save.
        </Text>
        {!items ? (
          <SkeletonGroup>
            {[0, 1, 2, 3, 4].map((i) => (
              <View key={i} style={styles.row}>
                <Skeleton width={24} height={16} />
                <Skeleton width="60%" height={16} />
              </View>
            ))}
          </SkeletonGroup>
        ) : (
          <DragSort
            items={items}
            keyOf={(c) => String(c.id)}
            onChange={setItems}
            onDragStateChange={(d) => setScroll(!d)}
            layout={{ kind: 'list', rowHeight: ROW }}
            itemLabel={(c, i) => `${i + 1}. ${c.name || `Chapter ${c.chapterNumber}`}`}
            renderItem={(c, i, active) => {
              const state = chapterStateOf(c);
              return (
                <View
                  style={[
                    styles.row,
                    active && {
                      backgroundColor: t.colors.card,
                      borderColor: t.colors.primary,
                      borderWidth: 1,
                      shadowColor: '#000',
                      shadowOpacity: 0.5,
                      shadowRadius: 16,
                      shadowOffset: { width: 0, height: 10 },
                    },
                  ]}
                >
                  <Text variant="display" style={[styles.num, { color: active ? t.colors.primary : t.colors.mutedForeground }]}>
                    {i + 1}
                  </Text>
                  <Text variant="subtitle" numberOfLines={1} style={styles.name}>
                    {c.name || `Chapter ${c.chapterNumber}`}
                  </Text>
                  {state !== 'live' ? <StateBadge label={state} tone={state === 'draft' ? 'draft' : 'scheduled'} /> : null}
                  <GripVertical size={20} color={active ? t.colors.primary : t.colors.mutedForeground} />
                </View>
              );
            }}
          />
        )}
      </ScrollView>
      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <Button title="Save order" fullWidth loading={saving} disabled={!dirty} onPress={save} />
      </View>
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    reset: { minWidth: 44, height: 44, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center' },
    resetText: { fontSize: 13 },
    hint: { marginTop: 14, marginBottom: 6 },
    row: {
      height: ROW,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingHorizontal: 10,
      borderTopWidth: 1,
      borderTopColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: t.colors.pageBackground,
    },
    num: { width: 28, fontSize: 17, lineHeight: 22 },
    name: { flex: 1, fontSize: 15 },
    footer: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      paddingHorizontal: 20,
      paddingTop: 12,
      backgroundColor: t.colors.pageBackground,
    },
  });
