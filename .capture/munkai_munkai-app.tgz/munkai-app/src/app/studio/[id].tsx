/**
 * Studio · Manage publication — approved mocks "Studio · Manage publication" + "Publication actions sheet".
 * GET /api/publications/:id, GET /api/chapters/list (owners also get drafts/scheduled with `state`).
 * Actions: PATCH /api/publications/:id/complete, /publish; PATCH /api/chapters/:id/publish.
 */
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import {
  ArrowDownWideNarrow,
  ArrowUpNarrowWide,
  ArrowUpDown,
  BookOpen,
  Check,
  ChevronLeft,
  Eye,
  EyeOff,
  Info,
  MoreHorizontal,
  Pencil,
  Plus,
  Send,
  Share2,
  type LucideIcon,
} from 'lucide-react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, Share, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { Cover } from '@/components/content/Cover';
import { InfoNote, StateBadge } from '@/components/studio/parts';
import { Button, Sheet, Skeleton, SkeletonGroup, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { WEB_URL } from '@/lib/config';
import { formatCompact } from '@/lib/format';
import { genres, openPublication, timeAgo, typeLabel } from '@/lib/publication';
import { invalidate, useFetch } from '@/lib/useFetch';
import { chaptersApi } from '@/services/chapters';
import { contentApi } from '@/services/content';
import { creatorApi, editsLeft } from '@/services/creator';
import { chapterStateOf, studioKeys } from '@/lib/studio';
import type { ChapterIndexEntry } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

function when(ch: ChapterIndexEntry, state: string) {
  if (state === 'scheduled' && ch.publishAt) {
    return new Date(ch.publishAt).toLocaleString(undefined, {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      hour: 'numeric',
      minute: '2-digit',
    });
  }
  return state === 'draft' ? 'Draft' : timeAgo(ch.createdAt);
}

export default function StudioPublication() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { id } = useLocalSearchParams<{ id: string }>();
  const refreshProfile = useSession((s) => s.refreshProfile);

  const pub = useFetch(studioKeys.pub(id), () => contentApi.publication(id));
  const pubId = pub.data?.id ?? id;
  const chapters = useFetch(studioKeys.chapters(id), () => chaptersApi.index(pubId, 'desc'));
  const [order, setOrder] = useState<'desc' | 'asc'>('desc');
  const [menu, setMenu] = useState(false);
  const [chapterMenu, setChapterMenu] = useState<ChapterIndexEntry | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      pub.reload();
      chapters.reload();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  const list = useMemo(() => {
    const all = (chapters.data ?? []).filter((c) => !c.isDeleted);
    const sorted = [...all].sort((a, b) => a.chapterNumber - b.chapterNumber);
    return order === 'desc' ? sorted.reverse() : sorted;
  }, [chapters.data, order]);

  const p = pub.data;
  const totalCollects = list.reduce((n, c) => n + (Number(c.collectCount) || 0), 0);
  const totalViews = list.reduce((n, c) => n + (Number(c.count) || 0), 0);
  const published = p?.isPublished !== false;

  const run = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try {
      await fn();
      toast.success(ok);
      pub.refetch();
      chapters.refetch();
      invalidate(`publication/${id}`);
      refreshProfile().catch(() => {});
    } catch (err) {
      toast.error('Couldn’t update', apiErrorMessage(err));
    } finally {
      setBusy(null);
      setMenu(false);
      setChapterMenu(null);
    }
  };

  const share = () => {
    if (!p) return;
    const path = p.slug ? `/publications/${p.slug}` : `/publications/${encodeURIComponent(p.name)}?id=${p.id}`;
    Share.share({ message: `${p.name} on Munkai — ${WEB_URL}${path}` }).catch(() => {});
    setMenu(false);
  };

  const gid = 'studiohero';
  const header = (
    <View>
      <View style={[styles.hero, { paddingTop: insets.top + 56 }]}>
        {p?.coverPhoto ? (
          <Cover uri={p.coverPhoto} width="100%" height={260 + insets.top} blur={24} style={StyleSheet.absoluteFill} />
        ) : null}
        <Svg style={StyleSheet.absoluteFill} width="100%" height={260 + insets.top} pointerEvents="none">
          <Defs>
            <LinearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={t.colors.pageBackground} stopOpacity={0.45} />
              <Stop offset="1" stopColor={t.colors.pageBackground} stopOpacity={1} />
            </LinearGradient>
          </Defs>
          <Rect x="0" y="0" width="100%" height={260 + insets.top} fill={`url(#${gid})`} />
        </Svg>
        <SkeletonGroup>
          <View style={styles.heroRow}>
            {p ? <Cover uri={p.coverPhoto} width={88} height={124} /> : <Skeleton width={88} height={124} />}
            <View style={styles.heroText}>
              {p ? (
                <>
                  <View style={styles.badges}>
                    {published ? <StateBadge label="Live" tone="live" /> : <StateBadge label="Draft" tone="draft" />}
                    {p.isCompleted ? <StateBadge label="Completed" tone="done" /> : null}
                    {p.isFanfic ? <StateBadge label="Fan TL" tone="fan" /> : null}
                  </View>
                  <Text variant="display" numberOfLines={2} style={styles.title}>
                    {p.name}
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" numberOfLines={1}>
                    {[typeLabel(p.publicationType), genres(p).slice(0, 2).join(', '), p.isCompleted ? 'Completed' : 'Ongoing']
                      .filter(Boolean)
                      .join(' · ')}
                  </Text>
                </>
              ) : (
                <>
                  <Skeleton width={80} height={14} />
                  <Skeleton width="90%" height={26} />
                  <Skeleton width="60%" height={12} />
                </>
              )}
            </View>
          </View>
        </SkeletonGroup>
      </View>

      <View style={styles.stats}>
        {[
          [formatCompact(list.length), 'Chapters'],
          [formatCompact(totalCollects), 'Collects'],
          [formatCompact(totalViews), 'Views'],
        ].map(([v, l], i) => (
          <View key={l} style={[styles.stat, i > 0 && styles.statDivider]}>
            <Text variant="display" color="primary" style={styles.statValue}>
              {chapters.loading && !chapters.data ? '–' : v}
            </Text>
            <Text style={styles.statLabel}>{l.toUpperCase()}</Text>
          </View>
        ))}
      </View>

      <View style={styles.actions}>
        <Button
          title="Add chapter"
          leftIcon={<Plus size={17} color={t.colors.onPrimary} strokeWidth={2.6} />}
          onPress={() => router.push({ pathname: '/studio/chapter', params: { pub: String(pubId) } })}
          style={styles.addBtn}
          disabled={!p}
        />
        <ActionTile
          icon={Pencil}
          label="Details"
          onPress={() => router.push({ pathname: '/studio/publication-form', params: { id: String(pubId) } })}
        />
        <ActionTile
          icon={ArrowUpDown}
          label="Reorder"
          disabled={list.length < 2}
          onPress={() => router.push({ pathname: '/studio/reorder/[id]', params: { id: String(pubId) } })}
        />
      </View>

      <View style={styles.sectionHead}>
        <Text variant="title" style={styles.sectionTitle}>
          Chapters
        </Text>
        <Pressable
          onPress={() => setOrder((o) => (o === 'desc' ? 'asc' : 'desc'))}
          accessibilityRole="button"
          hitSlop={8}
          style={styles.sort}
        >
          {order === 'desc' ? (
            <ArrowDownWideNarrow size={16} color={t.colors.primary} />
          ) : (
            <ArrowUpNarrowWide size={16} color={t.colors.primary} />
          )}
          <Text variant="subtitle" color="primary" style={styles.sortText}>
            {order === 'desc' ? 'Newest' : 'Oldest'}
          </Text>
        </Pressable>
      </View>
    </View>
  );

  if (pub.error && !p) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text variant="heading">Couldn’t load this publication</Text>
        <Text variant="bodySmall" color="mutedForeground" align="center">
          {apiErrorMessage(pub.error)}
        </Text>
        <Button title="Try again" variant="outline" onPress={pub.refetch} />
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <FlatList
        data={chapters.loading && !chapters.data ? [] : list}
        keyExtractor={(c) => String(c.id)}
        ListHeaderComponent={header}
        contentContainerStyle={{ paddingBottom: insets.bottom + 28 }}
        refreshControl={
          <RefreshControl
            refreshing={pub.refreshing || chapters.refreshing}
            onRefresh={() => {
              pub.refetch();
              chapters.refetch();
            }}
            tintColor={t.colors.primary}
            colors={[t.colors.primary]}
          />
        }
        renderItem={({ item, index }) => (
          <ChapterItem ch={item} divider={index > 0} fanfic={!!p?.isFanfic} onPress={() => setChapterMenu(item)} />
        )}
        ListEmptyComponent={
          chapters.loading ? (
            <SkeletonGroup>
              {[0, 1, 2, 3].map((i) => (
                <View key={i} style={[styles.row, i > 0 && styles.divider]}>
                  <Skeleton width={28} height={18} />
                  <View style={styles.rowText}>
                    <Skeleton width="60%" height={15} />
                    <Skeleton width="40%" height={11} />
                  </View>
                </View>
              ))}
            </SkeletonGroup>
          ) : (
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                No chapters yet. Add your first one — readers can’t open a publication without chapters.
              </Text>
            </View>
          )
        }
        ListFooterComponent={
          list.length ? (
            <InfoNote icon={Info} style={styles.footNote}>
              {p?.isFanfic
                ? 'Fan translations can be edited as often as you like.'
                : 'Original works can be edited twice per chapter. Readers who collected a chapter keep the version they bought.'}
            </InfoNote>
          ) : null
        }
      />

      {/* Floating top buttons */}
      <View style={[styles.topBar, { top: insets.top + 6 }]} pointerEvents="box-none">
        <GlassButton icon={ChevronLeft} label="Back" onPress={() => (router.canGoBack() ? router.back() : router.replace('/studio'))} />
        <View style={styles.flex} />
        <GlassButton icon={Eye} label="View as a reader" onPress={() => p && openPublication(p)} />
        <GlassButton icon={MoreHorizontal} label="More actions" onPress={() => setMenu(true)} />
      </View>

      <Sheet visible={menu} onClose={() => setMenu(false)} title={p?.name ?? 'Publication'}>
        {!p?.isCompleted ? (
          <SheetRow
            icon={Check}
            title="Mark as completed"
            sub="Readers see “Completed”. You can still add chapters."
            busy={busy === 'complete'}
            onPress={() => run('complete', () => creatorApi.markComplete(pubId), 'Marked as completed')}
          />
        ) : null}
        <SheetRow
          icon={published ? EyeOff : Send}
          title={published ? 'Unpublish publication' : 'Publish publication'}
          sub={published ? 'Hide it from Explore and search. Chapters stay saved.' : 'Make it visible to readers again.'}
          busy={busy === 'publish'}
          onPress={() =>
            run('publish', () => creatorApi.setPublicationPublished(pubId, !published), published ? 'Unpublished' : 'Published')
          }
        />
        <SheetRow icon={Share2} title="Share" sub="Send the public link" onPress={share} />
        <SheetRow
          icon={Eye}
          title="View as a reader"
          sub="Open the public page"
          onPress={() => {
            setMenu(false);
            if (p) openPublication(p);
          }}
        />
      </Sheet>

      <ChapterSheet
        ch={chapterMenu}
        fanfic={!!p?.isFanfic}
        busy={busy}
        onClose={() => setChapterMenu(null)}
        onEdit={(ch) => {
          setChapterMenu(null);
          router.push({ pathname: '/studio/chapter', params: { pub: String(pubId), chapter: String(ch.id) } });
        }}
        onRead={(ch) => {
          setChapterMenu(null);
          router.push({ pathname: '/read/[id]', params: { id: String(ch.id), pub: String(pubId), v: String(ch.editCount ?? 0) } });
        }}
        onPublish={(ch, publish) =>
          run(
            `ch${ch.id}`,
            () => creatorApi.setChapterPublished(ch.id, publish ? 'now' : 'draft'),
            publish ? 'Chapter is live' : 'Chapter unpublished',
          )
        }
      />
    </View>
  );
}

function ChapterItem({ ch, divider, fanfic, onPress }: { ch: ChapterIndexEntry; divider: boolean; fanfic: boolean; onPress: () => void }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const state = chapterStateOf(ch);
  const left = editsLeft(ch.editCount, fanfic);
  const free = !Number(ch.price);
  const editsText = fanfic ? null : left === 0 ? 'No edits left' : `${left} edit${left === 1 ? '' : 's'} left`;
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`Chapter ${ch.chapterNumber}${ch.name ? `, ${ch.name}` : ''}, ${state}`}
      style={({ pressed }) => [styles.row, divider && styles.divider, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.05) }]}
    >
      <Text variant="display" style={[styles.num, { color: t.colors.mutedForeground }]}>
        {ch.chapterNumber}
      </Text>
      <View style={styles.rowText}>
        <View style={styles.rowTitleLine}>
          <Text variant="subtitle" numberOfLines={1} style={styles.rowTitle}>
            {ch.name || `Chapter ${ch.chapterNumber}`}
          </Text>
          {state === 'draft' ? (
            <StateBadge label="Draft" tone="draft" />
          ) : state === 'scheduled' ? (
            <StateBadge label="Scheduled" tone="scheduled" />
          ) : null}
        </View>
        <Text variant="bodySmall" color="mutedForeground" numberOfLines={2} style={styles.small}>
          {when(ch, state)} ·{' '}
          <Text variant="bodySmall" style={[styles.small, free && { color: '#22C55E' }]}>
            {free ? 'FREE' : `ጠ ${formatCompact(ch.price)}`}
          </Text>
          {state === 'live' && ch.collectCount ? ` · ${formatCompact(ch.collectCount)} collects` : ''}
          {state === 'live' && editsText ? (
            <Text
              variant="bodySmall"
              style={[styles.small, { color: left === 0 ? '#FF4D6D' : t.colors.mutedForeground }]}
            >{` · ${editsText}`}</Text>
          ) : null}
        </Text>
      </View>
      <MoreHorizontal size={18} color={t.colors.mutedForeground} />
    </Pressable>
  );
}

function ChapterSheet({
  ch,
  fanfic,
  busy,
  onClose,
  onEdit,
  onRead,
  onPublish,
}: {
  ch: ChapterIndexEntry | null;
  fanfic: boolean;
  busy: string | null;
  onClose: () => void;
  onEdit: (ch: ChapterIndexEntry) => void;
  onRead: (ch: ChapterIndexEntry) => void;
  onPublish: (ch: ChapterIndexEntry, publish: boolean) => void;
}) {
  const [last, setLast] = useState<ChapterIndexEntry | null>(null);
  if (ch && ch !== last) setLast(ch);
  const c = ch ?? last;
  if (!c) return null;
  const state = chapterStateOf(c);
  const left = editsLeft(c.editCount, fanfic);
  const canEdit = state !== 'live' || left > 0;
  return (
    <Sheet visible={!!ch} onClose={onClose} title={c.name || `Chapter ${c.chapterNumber}`}>
      <SheetRow
        icon={Pencil}
        title="Edit chapter"
        sub={
          state !== 'live'
            ? 'Change the text, pages or price.'
            : fanfic
              ? 'Fan translations have no edit limit.'
              : left > 0
                ? `${left} edit${left === 1 ? '' : 's'} left for this chapter.`
                : 'You’ve used both edits for this chapter.'
        }
        disabled={!canEdit}
        onPress={() => onEdit(c)}
      />
      {state === 'live' ? (
        <SheetRow
          icon={EyeOff}
          title="Unpublish"
          sub="Move it back to drafts."
          busy={busy === `ch${c.id}`}
          onPress={() => onPublish(c, false)}
        />
      ) : (
        <SheetRow
          icon={Send}
          title="Publish now"
          sub={state === 'scheduled' ? 'Skip the schedule and go live now.' : 'Readers and followers can see it right away.'}
          busy={busy === `ch${c.id}`}
          onPress={() => onPublish(c, true)}
        />
      )}
      <SheetRow icon={BookOpen} title="Read" sub="Open it in the reader" onPress={() => onRead(c)} />
    </Sheet>
  );
}

function SheetRow({
  icon: Icon,
  title,
  sub,
  onPress,
  busy,
  disabled,
}: {
  icon: LucideIcon;
  title: string;
  sub: string;
  onPress: () => void;
  busy?: boolean;
  disabled?: boolean;
}) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      disabled={busy || disabled}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled, busy: !!busy }}
      style={({ pressed }) => [sheetStyles.row, (pressed || busy) && { opacity: 0.6 }, disabled && { opacity: 0.4 }]}
    >
      <View style={[sheetStyles.icon, { backgroundColor: withAlpha(t.colors.primary, 0.1) }]}>
        <Icon size={19} color={t.colors.foreground} strokeWidth={2} />
      </View>
      <View style={sheetStyles.text}>
        <Text variant="subtitle" style={sheetStyles.title}>
          {busy ? 'Working…' : title}
        </Text>
        <Text variant="bodySmall" color="mutedForeground" style={sheetStyles.sub}>
          {sub}
        </Text>
      </View>
    </Pressable>
  );
}

function ActionTile({
  icon: Icon,
  label,
  onPress,
  disabled,
}: {
  icon: LucideIcon;
  label: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!disabled }}
      style={({ pressed }) => [
        styles.tile,
        pressed && { backgroundColor: withAlpha(t.colors.primary, 0.08) },
        disabled && { opacity: 0.4 },
      ]}
    >
      <Icon size={16} color={t.colors.foreground} />
      <Text variant="subtitle" style={styles.tileText}>
        {label}
      </Text>
    </Pressable>
  );
}

function GlassButton({ icon: Icon, label, onPress }: { icon: LucideIcon; label: string; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={4}
      style={({ pressed }) => [sheetStyles.glass, pressed && { opacity: 0.7 }]}
    >
      <Icon size={20} color="#F2F2F2" />
    </Pressable>
  );
}

const sheetStyles = StyleSheet.create({
  row: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 8 },
  icon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  text: { flex: 1, gap: 2 },
  title: { fontSize: 15 },
  sub: { fontSize: 12, lineHeight: 16 },
  glass: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,43,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
  },
});

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    center: { alignItems: 'center', justifyContent: 'center', gap: 10, padding: 32 },
    flex: { flex: 1 },
    hero: { paddingHorizontal: 20, paddingBottom: 10, overflow: 'hidden' },
    heroRow: { flexDirection: 'row', gap: 14, alignItems: 'flex-end', marginTop: 20 },
    heroText: { flex: 1, gap: 6, paddingBottom: 4 },
    badges: { flexDirection: 'row', gap: 6 },
    title: { fontSize: 24, lineHeight: 28 },
    stats: {
      flexDirection: 'row',
      marginHorizontal: 20,
      marginTop: 16,
      paddingVertical: 12,
      borderTopWidth: 1,
      borderBottomWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
    },
    stat: { flex: 1, alignItems: 'center' },
    statDivider: { borderLeftWidth: 1, borderLeftColor: withAlpha(t.colors.primary, 0.12) },
    statValue: { fontSize: 20, lineHeight: 26 },
    statLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.2, color: t.colors.mutedForeground },
    actions: { flexDirection: 'row', gap: 8, marginHorizontal: 20, marginTop: 16 },
    addBtn: { flex: 1 },
    tile: {
      width: 76,
      height: 54,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.3),
      alignItems: 'center',
      justifyContent: 'center',
      gap: 2,
    },
    tileText: { fontSize: 11, lineHeight: 14 },
    sectionHead: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, marginTop: 24, marginBottom: 6 },
    sectionTitle: { flex: 1, fontSize: 20 },
    sort: { flexDirection: 'row', alignItems: 'center', gap: 4, minHeight: 44 },
    sortText: { fontSize: 13 },
    row: { minHeight: 72, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, marginHorizontal: 20 },
    divider: { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.1) },
    num: { width: 34, fontSize: 18, lineHeight: 24, textAlign: 'center' },
    rowText: { flex: 1, minWidth: 0, gap: 4 },
    rowTitleLine: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    rowTitle: { fontSize: 15, flexShrink: 1 },
    small: { fontSize: 12, lineHeight: 16 },
    empty: { paddingHorizontal: 32, paddingVertical: 28 },
    footNote: { marginHorizontal: 20, marginTop: 14 },
    topBar: { position: 'absolute', left: 12, right: 12, flexDirection: 'row', gap: 8 },
  });
