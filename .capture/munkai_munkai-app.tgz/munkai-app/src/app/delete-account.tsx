/**
 * Delete account — App Store guideline 5.1.1(v) / Google Play account-deletion policy.
 * Profile → Settings → Account → Delete account.
 * Backend contract (account-deletion-mobile.txt): POST /api/users/account/delete { reason, details? }.
 *   1. Explain the consequences (logged out everywhere, permanent after 30 days, only support can restore).
 *   2. Pick a reason (text box required for "Other").
 *   3. Type your username to enable Delete.
 *   4. On 200: clear the token and all local data, go to the logged-out screen.
 */
import { router } from 'expo-router';
import { AlertTriangle, Clock, Coins, LifeBuoy, LogOut, type LucideIcon } from 'lucide-react-native';
import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { FieldLabel } from '@/components/studio/parts';
import { Button, CutShape, Input, KeyboardAvoid, Text, useToast } from '@/components/ui';
import { apiErrorMessage, apiErrorStatus } from '@/lib/api';
import { formatBalance } from '@/lib/format';
import { haptic } from '@/lib/haptics';
import { openExternal } from '@/lib/links';
import { WALLET_WEB_URL } from '@/lib/wallet';
import { DELETE_DETAILS_MAX, DELETE_REASONS, profileApi, type DeleteReason } from '@/services/profile';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const normalize = (v: string) => v.trim().replace(/^@/, '').toLowerCase();

function formatDay(iso?: string) {
  if (!iso) return undefined;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? undefined : d.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
}

export default function DeleteAccount() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const user = useSession((s) => s.user);
  const signOut = useSession((s) => s.signOut);

  const [reason, setReason] = useState<DeleteReason | null>(null);
  const [details, setDetails] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>();

  const username = user?.username ?? '';
  const balance = Number(user?.balance) || 0;
  const needsDetails = reason === 'other';
  const detailsOk = !needsDetails || details.trim().length > 0;
  const confirmed = !!username && normalize(confirm) === username.toLowerCase();
  const canDelete = !!reason && detailsOk && confirmed && !busy;

  const consequences: { icon: LucideIcon; text: string }[] = [
    { icon: LogOut, text: 'You’ll be logged out on every device right away, on the web and in the app.' },
    { icon: Clock, text: 'After 30 days your account and personal data are permanently deleted.' },
    { icon: LifeBuoy, text: 'Until then, only Munkai support can restore it. You can’t undo this yourself.' },
    ...(balance > 0
      ? [{ icon: Coins, text: `You still have ጠ ${formatBalance(balance)} in your wallet. Withdraw it on munkai.art first.` }]
      : []),
  ];

  const submit = async () => {
    if (!reason) return setError('Choose a reason.');
    if (!detailsOk) return setError('Tell us a little more.');
    if (!confirmed) return setError('Type your username to confirm.');
    setBusy(true);
    setError(undefined);
    try {
      const res = await profileApi.deleteAccount({ reason, details: details.trim() || undefined });
      haptic.success().catch(() => {});
      // The token is already dead on the server: clear everything locally without calling logout.
      await signOut({ remote: false });
      const day = formatDay(res?.data?.permanentDeletionAt);
      toast.success('Your account was deleted', day ? `It will be permanently removed on ${day}.` : 'Sorry to see you go.');
      router.replace('/login');
    } catch (err) {
      if (apiErrorStatus(err) === 400) setError(apiErrorMessage(err, 'Check your reason and try again.'));
      else toast.error('Couldn’t delete your account', apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.root}>
      <StackHeader title="Delete account" />
      <KeyboardAvoid>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive">
          {/* 1 · Consequences */}
          <CutShape
            cuts={t.cuts.card}
            fill={withAlpha(t.colors.destructive, 0.08)}
            stroke={withAlpha(t.colors.destructive, 0.35)}
            style={styles.warn}
          >
            <AlertTriangle size={24} color={t.colors.destructive} />
            <Text variant="heading" style={styles.warnTitle}>
              Before you go
            </Text>
            <Text variant="bodySmall" color="mutedForeground" style={styles.lh}>
              Deleting {username ? `@${username}` : 'your account'} means:
            </Text>
            <View style={styles.list}>
              {consequences.map(({ icon: Icon, text }) => (
                <View key={text} style={styles.item}>
                  <Icon size={16} color={t.colors.foreground} />
                  <Text variant="bodySmall" style={[styles.flex, styles.lh]}>
                    {text}
                  </Text>
                </View>
              ))}
            </View>
          </CutShape>

          {balance > 0 ? (
            <Button title="Withdraw tokens first" variant="outline" onPress={() => openExternal(WALLET_WEB_URL).catch(() => {})} />
          ) : null}

          {/* 2 · Reason */}
          <View style={styles.block} accessibilityRole="radiogroup">
            <FieldLabel>Why are you leaving?</FieldLabel>
            <View style={[styles.reasons, { borderColor: withAlpha(t.colors.primary, 0.14) }]}>
              {DELETE_REASONS.map((r, i) => {
                const on = reason === r.value;
                return (
                  <Pressable
                    key={r.value}
                    onPress={() => {
                      haptic.select().catch(() => {});
                      setReason(r.value);
                      if (error) setError(undefined);
                    }}
                    accessibilityRole="radio"
                    accessibilityState={{ checked: on }}
                    style={({ pressed }) => [
                      styles.reason,
                      i > 0 && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
                      (pressed || on) && { backgroundColor: withAlpha(t.colors.primary, on ? 0.1 : 0.05) },
                    ]}
                  >
                    <View style={[styles.radio, { borderColor: on ? t.colors.primary : withAlpha(t.colors.mutedForeground, 0.6) }]}>
                      {on ? <View style={[styles.radioDot, { backgroundColor: t.colors.primary }]} /> : null}
                    </View>
                    <Text variant="bodySmall" style={[styles.flex, on && styles.bold]}>
                      {r.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            {needsDetails ? (
              <Input
                label="Tell us more"
                required
                multiline
                value={details}
                onChangeText={(v) => {
                  setDetails(v.slice(0, DELETE_DETAILS_MAX));
                  if (error) setError(undefined);
                }}
                maxLength={DELETE_DETAILS_MAX}
                placeholder="What made you decide to leave?"
                hint={`${details.length}/${DELETE_DETAILS_MAX}`}
                autoFocus
              />
            ) : null}
          </View>

          {/* 3 · Confirm */}
          <Input
            label={`Type ${username ? `“${username}”` : 'your username'} to confirm`}
            value={confirm}
            onChangeText={(v) => {
              setConfirm(v);
              if (error) setError(undefined);
            }}
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="off"
            placeholder={username}
            error={error}
            returnKeyType="done"
          />
        </ScrollView>
        <View style={[styles.footer, { paddingBottom: insets.bottom + 14 }]}>
          <Button title="Delete my account" variant="destructive" fullWidth loading={busy} disabled={!canDelete} onPress={submit} />
          <Button title="Keep my account" variant="ghost" fullWidth onPress={() => router.back()} />
        </View>
      </KeyboardAvoid>
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    bold: { fontFamily: t.fonts.bodyBold },
    scroll: { padding: 20, gap: 22, paddingBottom: 32 },
    warn: { padding: 18, gap: 8 },
    warnTitle: { fontSize: 20 },
    lh: { lineHeight: 19 },
    list: { gap: 10, marginTop: 6 },
    item: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
    block: { gap: 10 },
    reasons: { borderWidth: 1, borderRadius: t.radius.search, overflow: 'hidden' },
    reason: { minHeight: 48, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12 },
    radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
    radioDot: { width: 10, height: 10, borderRadius: 5 },
    footer: {
      gap: 4,
      paddingHorizontal: 20,
      paddingTop: 12,
      borderTopWidth: 1,
      borderTopColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: t.colors.pageBackground,
    },
  });
