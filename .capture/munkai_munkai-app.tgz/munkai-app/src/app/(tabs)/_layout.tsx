import { router, Tabs, useSegments } from 'expo-router';
import React, { useEffect, useRef } from 'react';
import { View } from 'react-native';

import { TabBar } from '@/components/navigation/TabBar';
import { useToast } from '@/components/ui';
import { AmbientBackground } from '@/components/ui/AmbientBackground';
import { UpdateSheet } from '@/components/UpdateSheet';
import { useIsOffline } from '@/lib/network';
import { useTheme } from '@/theme';

/**
 * Bottom tabs: Home · Explore · Downloads · Wallet · Profile.
 * Offline mode (Netflix-style): with no internet the bar shows only Downloads and the app switches to it.
 * A chapter open in the reader is left alone; when the connection returns, every tab comes back.
 */
export default function TabsLayout() {
  const t = useTheme();
  const toast = useToast();
  const offline = useIsOffline();
  const segments = useSegments() as string[];
  const tabsInFront = segments[0] === '(tabs)';
  const onDownloads = segments[1] === 'downloads';
  const wasOffline = useRef(offline);

  useEffect(() => {
    if (offline && tabsInFront && !onDownloads) router.navigate('/downloads');
  }, [offline, tabsInFront, onDownloads]);

  useEffect(() => {
    if (wasOffline.current && !offline) toast.success('You’re back online');
    wasOffline.current = offline;
  }, [offline, toast]);

  return (
    <View style={{ flex: 1, backgroundColor: t.colors.pageBackground }}>
      {/* The web's moving background (light streak + stars), behind all five tabs. */}
      <AmbientBackground />
      <Tabs
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        tabBar={(props) => <TabBar {...(props as any)} />}
        screenOptions={({ navigation }) => {
          // Scenes are transparent so the moving background shows through — so hide the tabs that aren't in
          // front, or they'd show through each other (they stay mounted and keep their scroll position).
          const focused = navigation.isFocused();
          return {
            headerShown: false,
            sceneStyle: { backgroundColor: 'transparent', opacity: focused ? 1 : 0, pointerEvents: focused ? 'auto' : 'none' },
          };
        }}
      >
        <Tabs.Screen name="home" />
        <Tabs.Screen name="explore" />
        <Tabs.Screen name="downloads" />
        <Tabs.Screen name="wallet" />
        <Tabs.Screen name="profile" />
      </Tabs>
      {/* "An update is ready" — shows once per new store version (lib/appUpdate). Not while offline. */}
      {offline ? null : <UpdateSheet />}
    </View>
  );
}
