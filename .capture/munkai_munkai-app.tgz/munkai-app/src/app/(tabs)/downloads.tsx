/**
 * Downloads tab (was Library; Collections / Saved moved to Profile).
 * One row per downloaded publication (chapters downloaded, size); tap one to see and read its chapters
 * (app/downloaded/[id]). Offline mode (lib/network): the tab bar is hidden and this is the only screen,
 * with a "You're offline" bar on top.
 */
import { WifiOff } from 'lucide-react-native';
import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTabBarScroll, useTabBarSpace } from '@/components/navigation/tabBarState';
import { DownloadPublicationRow, DownloadsEmpty, DownloadsFooter, useDownloadGroups } from '@/components/offline/Downloads';
import { Text } from '@/components/ui';
import { useIsOffline } from '@/lib/network';
import { OFFLINE_SUPPORTED } from '@/store/offline';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

export default function DownloadsScreen() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const space = useTabBarSpace();
  const onScroll = useTabBarScroll();
  const offline = useIsOffline();
  const groups = useDownloadGroups();
  const total = groups.reduce((n, g) => n + g.chapters.length, 0);

  const header = (
    <View style={{ paddingTop: insets.top + 8 }}>
      {offline ? (
        <View
          style={[styles.offline, { backgroundColor: withAlpha(t.colors.primary, 0.1), borderColor: withAlpha(t.colors.primary, 0.25) }]}
          accessibilityRole="alert"
        >
          <WifiOff size={16} color={t.colors.primary} strokeWidth={2.2} />
          <Text variant="bodySmall" style={styles.offlineText}>
            <Text variant="bodySmall" style={styles.bold}>
              You’re offline
            </Text>
            {' · Showing your downloads'}
          </Text>
        </View>
      ) : null}
      <Text variant="title" style={styles.h1} accessibilityRole="header">
        Downloads
      </Text>
      {total > 0 ? (
        <Text variant="bodySmall" color="mutedForeground" style={styles.sub}>
          {total} chapter{total === 1 ? '' : 's'} from {groups.length} publication{groups.length === 1 ? '' : 's'} · read without internet
        </Text>
      ) : null}
      <View style={{ height: 18 }} />
    </View>
  );

  if (!OFFLINE_SUPPORTED) {
    return (
      <View style={styles.root}>
        {header}
        <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.webNote}>
          Downloads are available in the Munkai app on iOS and Android.
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <FlatList
        data={groups}
        keyExtractor={(g) => g.pub.id}
        ListHeaderComponent={header}
        renderItem={({ item, index }) => <DownloadPublicationRow group={item} first={index === 0} />}
        ListEmptyComponent={<DownloadsEmpty />}
        ListFooterComponent={<DownloadsFooter groups={groups} />}
        // No tab bar while offline, so no room needs keeping for it.
        contentContainerStyle={{ paddingBottom: offline ? insets.bottom + 24 : space }}
        onScroll={onScroll}
        scrollEventThrottle={32}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    // Transparent: the tabs layout paints the page colour + the moving background behind.
    root: { flex: 1 },
    bold: { fontFamily: t.fonts.bodyBold },
    h1: { paddingHorizontal: 20, fontSize: 30, lineHeight: 36 },
    sub: { paddingHorizontal: 20, marginTop: 4 },
    offline: {
      marginHorizontal: 20,
      marginBottom: 14,
      minHeight: 40,
      paddingHorizontal: 12,
      borderWidth: 1,
      borderRadius: t.radius.search,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    offlineText: { flex: 1 },
    webNote: { paddingHorizontal: 32, paddingTop: 24 },
  });
