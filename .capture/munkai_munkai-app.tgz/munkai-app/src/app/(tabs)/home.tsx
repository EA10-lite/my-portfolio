/**
 * Home — approved variant "B" (without the type tabs).
 * Sticky header (avatar, greeting, search → /search, bell) that hides on scroll down and returns on scroll up —
 * balance lives on Wallet and Profile ·
 * Feed: GET /api/landing (same as the web landing). Type tabs were dropped at the user's request.
 */
import { router, useFocusEffect } from 'expo-router';
import { Bell, BookCheck, BookOpen, Flame, type LucideIcon, Search, Sparkles, Star, Trophy, Zap } from 'lucide-react-native';
import { BlurView } from 'expo-blur';
import React, { useCallback, useEffect, useId, useRef, useState } from 'react';
import {
  AccessibilityInfo,
  Animated,
  AppState,
  FlatList,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  useWindowDimensions,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { Badge, CreatorCard, CreatorCardSkeleton, PublicationCard, PublicationCardSkeleton } from '@/components/content/cards';
import { Cover } from '@/components/content/Cover';
import { SectionHeader, Shelf } from '@/components/content/Shelf';
import { tabBarHidden, useTabBarScroll, useTabBarSpace } from '@/components/navigation/tabBarState';
import { Avatar, Button, CutShape, ReadTag, Skeleton, SkeletonGroup, Text } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatCompact } from '@/lib/format';
import { openChapter, openPublication, timeAgo, typeLabel } from '@/lib/publication';
import { QK } from '@/lib/queryKeys';
import { useReadingHistory } from '@/lib/readingHistory';
import { useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import { notificationsApi } from '@/services/social';
import type { Publication, RecentChapter } from '@/services/types';
import { useOffline } from '@/store/offline';
import { useGreeting } from '@/lib/greetings';
import { isCreatorRole } from '@/services/creator';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

/** Height of the sticky header below the status bar: 6 top + 40 buttons + 10 bottom. */
const HEADER_BAR = 56;

const seeAll = (kind: string) => () => router.push({ pathname: '/browse/[kind]', params: { kind } });

export default function Home() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const space = useTabBarSpace();
  // Sticky header: pinned above the feed, hides with the tab bar on scroll down and comes back on
  // scroll up (same `tabBarHidden` value). Its glass background fades in once the feed moves under it.
  const headerH = insets.top + HEADER_BAR;
  const ios = Platform.OS === 'ios';
  const scrollY = useRef(new Animated.Value(0)).current;
  const onFeedScroll = useCallback(
    (e: NativeSyntheticEvent<NativeScrollEvent>) => scrollY.setValue(e.nativeEvent.contentOffset.y + (ios ? headerH : 0)),
    [scrollY, ios, headerH],
  );
  const onScroll = useTabBarScroll(onFeedScroll);
  const headerBg = scrollY.interpolate({ inputRange: [0, 24], outputRange: [0, 1], extrapolate: 'clamp' });
  const headerY = tabBarHidden.interpolate({ inputRange: [0, 1], outputRange: [0, -headerH] });
  const user = useSession((s) => s.user);
  const greeting = useGreeting(isCreatorRole(user?.role) ? 'creator' : 'reader');
  const history = useReadingHistory();
  const hasDownloads = useOffline((s) => Object.keys(s.chapters).length > 0);

  const { data, loading, error, refreshing, refetch } = useFetch(QK.landing, contentApi.landing);
  const notes = useFetch(QK.notifications, () => notificationsApi.page(1, 50));
  const unread = notes.data?.unreadCount ?? 0;
  useFocusEffect(
    useCallback(() => {
      notes.reload();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  return (
    <View style={styles.root}>
      <ScrollView
        onScroll={onScroll}
        scrollEventThrottle={32}
        // iOS: inset the content so the pull-to-refresh spinner sits below the header.
        // Android / web: pad the content and offset the spinner instead.
        contentInset={ios ? { top: headerH } : undefined}
        contentOffset={ios ? { x: 0, y: -headerH } : undefined}
        scrollIndicatorInsets={ios ? { top: headerH } : undefined}
        contentContainerStyle={{ paddingTop: ios ? 0 : headerH, paddingBottom: space }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refetch}
            tintColor={t.colors.primary}
            colors={[t.colors.primary]}
            progressViewOffset={headerH}
          />
        }
      >
        {error && !data ? (
          <CutShape
            cuts={t.cuts.card}
            fill={withAlpha(t.colors.destructive, 0.08)}
            stroke={withAlpha(t.colors.destructive, 0.3)}
            style={styles.error}
          >
            <Text variant="heading" style={styles.errorTitle}>
              Couldn’t load your feed
            </Text>
            <Text variant="bodySmall" color="mutedForeground">
              {apiErrorMessage(error)}
            </Text>
            <View style={styles.errorBtns}>
              <Button title="Try again" variant="outline" onPress={refetch} style={styles.errorBtn} />
              {hasDownloads ? (
                <Button title="Read downloads" onPress={() => router.navigate('/downloads')} style={styles.errorBtn} />
              ) : null}
            </View>
          </CutShape>
        ) : (
          <SkeletonGroup>
            <Featured loading={loading} items={data?.featuredPublications.slice(0, 8)} />

            {history.length > 0 ? (
              <Shelf
                title="Continue Reading"
                eyebrow="Pick Up Where You Left Off"
                icon={BookOpen}
                loading={false}
                data={history}
                keyOf={(h) => h.publicationId}
                renderSkeleton={() => <View />}
                renderItem={(h) => (
                  <Pressable
                    onPress={() => openChapter({ id: h.chapterId, publicationId: h.publicationId })}
                    accessibilityRole="button"
                    accessibilityLabel={`Continue ${h.publicationName}, chapter ${h.chapterNumber}, ${Math.round(h.progress * 100)}% read`}
                    style={({ pressed }) => [styles.continue, pressed && { opacity: 0.8 }]}
                  >
                    <Cover uri={h.coverPhoto} width={120} height={170}>
                      <View style={styles.progressTrack}>
                        <View
                          style={[styles.progressFill, { width: `${Math.round(h.progress * 100)}%`, backgroundColor: t.colors.primary }]}
                        />
                      </View>
                    </Cover>
                    <Text variant="subtitle" numberOfLines={1} style={styles.cardTitle}>
                      {h.publicationName}
                    </Text>
                    <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                      Ch. {h.chapterNumber}
                    </Text>
                  </Pressable>
                )}
              />
            ) : null}

            <NewChapters loading={loading} items={data?.recentChapters} />

            <PubShelf
              title="Trending & Rising"
              accent="& Rising"
              eyebrow="Hot Right Now"
              icon={Flame}
              iconFilled
              kind="trending"
              loading={loading}
              data={data?.trendingPublications}
            />
            <PubShelf
              title="Munkai Handpicked"
              eyebrow="Handpicked Excellence"
              icon={Star}
              iconFilled
              kind="picks"
              loading={loading}
              data={data?.munkaiPicks}
            />

            <Shelf
              title="Top Creators"
              eyebrow="Platform Leaderboard"
              linkLabel="View Leaderboard"
              icon={Trophy}
              onSeeAll={() => router.push('/top-creators')}
              loading={loading}
              data={data?.topCreators}
              keyOf={(c) => String(c.id)}
              renderItem={(c) => <CreatorCard c={c} />}
              renderSkeleton={() => <CreatorCardSkeleton />}
              gap={12}
            />

            <PubShelf
              title="Completed Stories"
              eyebrow="Binge-Ready Legends"
              linkLabel="View Archives"
              icon={BookCheck}
              kind="completed"
              loading={loading}
              data={data?.completedPublications}
            />
            <PubShelf
              title="Fanfics"
              eyebrow="Community Powered"
              icon={Star}
              iconFilled
              kind="fan"
              loading={loading}
              data={data?.fanfics}
            />
            <PubShelf
              title="Free Publications"
              eyebrow="Zero Cost, Infinite Stories"
              linkLabel="Explore All Free Reads"
              icon={Sparkles}
              kind="free"
              loading={loading}
              data={data?.freePublications}
              free
            />
          </SkeletonGroup>
        )}
      </ScrollView>

      {/* Sticky top bar */}
      <Animated.View style={[styles.header, { paddingTop: insets.top + 6, transform: [{ translateY: headerY }] }]}>
        <Animated.View
          pointerEvents="none"
          style={[
            StyleSheet.absoluteFill,
            styles.headerBg,
            {
              opacity: headerBg,
              borderBottomColor: withAlpha(t.colors.primary, 0.2),
              backgroundColor: withAlpha(t.colors.pageBackground, ios ? 0.6 : 0.97),
            },
          ]}
        >
          {ios ? <BlurView intensity={40} tint={t.isDark ? 'dark' : 'light'} style={StyleSheet.absoluteFill} /> : null}
        </Animated.View>
        <View style={styles.top}>
          <Pressable onPress={() => router.push('/profile')} accessibilityRole="button" accessibilityLabel="Your profile">
            <Avatar uri={user?.profileImage} firstName={user?.firstName} lastName={user?.lastName} seed={user?.username} size={40} />
          </Pressable>
          <View style={styles.flex}>
            {/* Web custom greetings (lib/greetings): a line per time of day, kept for the day. */}
            <Text variant="caption" color="primary" numberOfLines={1} style={styles.hello}>
              {greeting || ' '}
            </Text>
            <Text variant="heading" numberOfLines={1} style={styles.name}>
              {user?.firstName || 'Reader'}
            </Text>
          </View>
          <Pressable
            onPress={() => router.push('/search')}
            accessibilityRole="button"
            accessibilityLabel="Search"
            style={({ pressed }) => [styles.round, { backgroundColor: withAlpha(t.colors.primary, pressed ? 0.16 : 0.08) }]}
          >
            <Search size={19} color={t.colors.foreground} strokeWidth={2} />
          </Pressable>
          <Pressable
            onPress={() => router.push('/notifications')}
            accessibilityRole="button"
            accessibilityLabel={unread ? `Notifications, ${unread} unread` : 'Notifications'}
            style={({ pressed }) => [styles.round, { backgroundColor: withAlpha(t.colors.primary, pressed ? 0.16 : 0.08) }]}
          >
            <Bell size={19} color={t.colors.foreground} strokeWidth={2} />
            {unread ? <View style={[styles.dot, { borderColor: t.colors.pageBackground }]} /> : null}
          </Pressable>
        </View>
      </Animated.View>
      {/* Keeps the status bar area covered while the header is tucked away. */}
      <Animated.View
        pointerEvents="none"
        style={[styles.statusScrim, { height: insets.top, opacity: headerBg, backgroundColor: withAlpha(t.colors.pageBackground, 0.97) }]}
      />
    </View>
  );
}

/* -------------------------------- featured ---------------------------------- */

/** Copies of the list rendered for the endless loop; the view always sits in the middle copy. */
const LOOP_COPIES = 3;
const AUTO_MS = 5000;

/**
 * Featured carousel: auto-advances every 5 s and loops endlessly. The list is rendered three times over
 * and the position is quietly re-centred on the middle copy, so the jump back to the first card never shows.
 * Pauses while touched (resumes 5 s after), when Home isn't focused, in the background, and with Reduce Motion.
 */
function Featured({ loading, items }: { loading: boolean; items?: Publication[] }) {
  const styles = useThemedStyles(makeStyles);
  const t = useTheme();
  const { width } = useWindowDimensions();
  const cardW = Math.min(300, width - 72);
  const cardH = Math.round(cardW * 1.27);
  const stride = cardW + 12;
  const n = items?.length ?? 0;
  const loop = n > 1;
  const data = React.useMemo(() => (loop ? Array.from({ length: LOOP_COPIES }, () => items!).flat() : (items ?? [])), [items, loop]);

  const listRef = useRef<FlatList<Publication>>(null);
  const index = useRef(loop ? n : 0);
  const lastTouch = useRef(0);
  const dragging = useRef(false);
  const focused = useRef(true);
  const reduceMotion = useRef(false);
  const [active, setActive] = useState(0);

  useFocusEffect(
    useCallback(() => {
      focused.current = true;
      lastTouch.current = Date.now();
      return () => {
        focused.current = false;
      };
    }, []),
  );

  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled()
      .then((v) => (reduceMotion.current = v))
      .catch(() => {});
    const sub = AccessibilityInfo.addEventListener('reduceMotionChanged', (v) => (reduceMotion.current = v));
    return () => sub.remove();
  }, []);

  // Keep the position inside the middle copy (no animation, so it's invisible).
  const recenter = useCallback(() => {
    if (!loop) return;
    let i = index.current;
    if (i < n) i += n;
    else if (i >= 2 * n) i -= n;
    if (i !== index.current) {
      index.current = i;
      listRef.current?.scrollToOffset({ offset: i * stride, animated: false });
    }
  }, [loop, n, stride]);

  useEffect(() => {
    if (!loop) return;
    index.current = n;
    setActive(0);
    const timer = setInterval(() => {
      if (!focused.current || dragging.current || reduceMotion.current) return;
      if (AppState.currentState !== 'active' || Date.now() - lastTouch.current < AUTO_MS) return;
      index.current += 1;
      setActive(index.current % n);
      listRef.current?.scrollToOffset({ offset: index.current * stride, animated: true });
      setTimeout(recenter, 450);
    }, AUTO_MS);
    return () => clearInterval(timer);
  }, [loop, n, stride, recenter]);

  const renderItem = useCallback(
    ({ item }: { item: Publication }) => <FeaturedCard pub={item} width={cardW} height={cardH} />,
    [cardW, cardH],
  );

  if (loading) {
    return (
      <View style={styles.featuredRow}>
        <Skeleton width={cardW} height={cardH} />
        <Skeleton width={cardW} height={cardH} />
      </View>
    );
  }
  if (!n) return null;
  return (
    <View>
      <FlatList
        ref={listRef}
        horizontal
        data={data}
        keyExtractor={(p, i) => `${p.id}-${i}`}
        renderItem={renderItem}
        ItemSeparatorComponent={FeaturedGap}
        contentContainerStyle={styles.featuredList}
        contentOffset={loop ? { x: n * stride, y: 0 } : undefined}
        showsHorizontalScrollIndicator={false}
        snapToInterval={stride}
        decelerationRate="fast"
        initialNumToRender={loop ? 2 * n + 1 : n}
        windowSize={5}
        onScrollBeginDrag={() => {
          dragging.current = true;
        }}
        onScrollEndDrag={() => {
          dragging.current = false;
          lastTouch.current = Date.now();
        }}
        onMomentumScrollEnd={(e) => {
          lastTouch.current = Date.now();
          index.current = Math.round(e.nativeEvent.contentOffset.x / stride);
          setActive(((index.current % n) + n) % n);
          recenter();
        }}
      />
      {loop ? (
        <View style={styles.dots} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
          {items!.map((p, i) => (
            <View
              key={String(p.id)}
              style={[
                styles.pageDot,
                i === active
                  ? { width: 18, backgroundColor: t.colors.primary }
                  : { backgroundColor: withAlpha(t.colors.mutedForeground, 0.4) },
              ]}
            />
          ))}
        </View>
      ) : null}
    </View>
  );
}

const FeaturedGap = () => <View style={{ width: 12 }} />;

function FeaturedCard({ pub, width, height }: { pub: Publication; width: number; height: number }) {
  const gid = `fg${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const chapters = Number(pub.totalChapters) || 0;
  const meta = [
    typeLabel(pub.publicationType),
    chapters ? `${chapters} chapter${chapters === 1 ? '' : 's'}` : null,
    pub.isCompleted ? 'Completed' : 'Ongoing',
  ]
    .filter(Boolean)
    .join(' · ');
  return (
    <Pressable
      onPress={() => openPublication(pub)}
      accessibilityRole="button"
      accessibilityLabel={`${pub.name}, ${meta}`}
      style={({ pressed }) => [pressed && { opacity: 0.9, transform: [{ scale: 0.99 }] }]}
    >
      <Cover uri={pub.coverPhoto} width={width} height={height}>
        <Svg width={width} height={height} style={StyleSheet.absoluteFill} pointerEvents="none">
          <Defs>
            <LinearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0.45" stopColor="#00002B" stopOpacity={0} />
              <Stop offset="1" stopColor="#00002B" stopOpacity={0.95} />
            </LinearGradient>
          </Defs>
          <Rect x="0" y="0" width={width} height={height} fill={`url(#${gid})`} />
        </Svg>
        <View style={featStyles.body} pointerEvents="none">
          <Badge label={pub.isFanfic ? 'Fan translation' : 'Featured'} tone={pub.isFanfic ? 'fan' : 'primary'} />
          <Text variant="display" numberOfLines={2} style={featStyles.title}>
            {pub.name}
          </Text>
          <Text variant="bodySmall" numberOfLines={1} style={featStyles.meta}>
            {meta}
          </Text>
        </View>
      </Cover>
    </Pressable>
  );
}

const featStyles = StyleSheet.create({
  body: { position: 'absolute', left: 16, right: 16, bottom: 16, gap: 6, alignItems: 'flex-start' },
  title: { fontSize: 26, lineHeight: 29, color: '#F2F2F2' },
  meta: { fontSize: 12, lineHeight: 16, color: '#C9CCD6' },
});

/* ------------------------------ new chapters -------------------------------- */

function NewChapters({ loading, items }: { loading: boolean; items?: RecentChapter[] }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const list = (items ?? []).slice(0, 6);
  return (
    <View>
      <SectionHeader
        title="New Arrivals!!!"
        accent="Arrivals!!!"
        eyebrow="Fresh From the Ink"
        linkLabel="Catch the Latest"
        icon={Zap}
        iconFilled
        onSeeAll={loading ? undefined : () => router.push('/chapters')}
      />
      <View style={styles.chGrid}>
        {loading
          ? Array.from({ length: 4 }, (_, i) => (
              <View key={i} style={styles.chCell}>
                <Skeleton width={44} height={60} />
                <View style={styles.chText}>
                  <Skeleton width="90%" height={12} />
                  <Skeleton width="60%" height={10} />
                  <Skeleton width={36} height={10} />
                </View>
              </View>
            ))
          : list.map((c) => {
              const free = !Number(c.price);
              const tone = c.isCollected ? t.colors.primary : free ? '#22C55E' : t.colors.primary;
              return (
                <Pressable
                  key={String(c.id)}
                  onPress={() => openChapter(c)}
                  accessibilityRole="button"
                  accessibilityLabel={`${c.publicationName}, chapter ${c.chapterNumber}${free ? ', free' : `, ${c.price} tokens`}`}
                  style={({ pressed }) => [styles.chCell, pressed && { opacity: 0.8 }]}
                >
                  <Cover uri={c.coverPhoto} width={44} height={60} />
                  <View style={styles.chText}>
                    <Text variant="subtitle" numberOfLines={1} style={styles.chTitle}>
                      {c.publicationName}
                    </Text>
                    <Text variant="caption" numberOfLines={1}>
                      Ch. {c.chapterNumber}
                      {c.createdAt ? ` · ${timeAgo(c.createdAt)}` : ''}
                    </Text>
                    {free && !c.isCollected ? (
                      <ReadTag style={styles.chRead} />
                    ) : (
                      <Text variant="caption" style={[styles.chPrice, { color: tone }]}>
                        {c.isCollected ? 'OWNED' : `ጠ ${formatCompact(c.price)}`}
                      </Text>
                    )}
                  </View>
                </Pressable>
              );
            })}
      </View>
    </View>
  );
}

function PubShelf({
  title,
  icon,
  eyebrow,
  accent,
  linkLabel,
  iconFilled,
  kind,
  loading,
  data,
  free,
}: {
  title: string;
  icon: LucideIcon;
  eyebrow: string;
  accent?: string;
  linkLabel?: string;
  iconFilled?: boolean;
  kind: string;
  loading: boolean;
  data?: Publication[];
  free?: boolean;
}) {
  return (
    <Shelf
      title={title}
      icon={icon}
      eyebrow={eyebrow}
      accent={accent}
      linkLabel={linkLabel}
      iconFilled={iconFilled}
      onSeeAll={seeAll(kind)}
      loading={loading}
      data={data?.slice(0, 12)}
      keyOf={(p) => String(p.id)}
      renderItem={(p) => <PublicationCard pub={p} width={112} free={free} />}
      renderSkeleton={() => <PublicationCardSkeleton width={112} />}
      skeletonCount={3}
    />
  );
}

const makeStyles = (t: Theme) => {
  const groupBg = t.isDark ? withAlpha(t.colors.card, 0.9) : withAlpha(t.colors.background, 0.8);
  return StyleSheet.create({
    // Transparent: the tabs layout paints the page colour + the moving background behind.
    root: { flex: 1 },
    flex: { flex: 1 },
    header: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 },
    headerBg: { borderBottomWidth: StyleSheet.hairlineWidth, overflow: 'hidden' },
    statusScrim: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 11 },
    top: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingLeft: 20, paddingRight: 16, paddingBottom: 10 },
    hello: { fontSize: 10, lineHeight: 15, letterSpacing: 2.4 },
    name: { fontSize: 18, lineHeight: 22 },
    round: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
    dot: { position: 'absolute', top: 8, right: 9, width: 10, height: 10, borderRadius: 5, backgroundColor: '#FF4D6D', borderWidth: 2 },
    dots: { flexDirection: 'row', justifyContent: 'center', gap: 6, paddingTop: 12 },
    pageDot: { width: 6, height: 6, borderRadius: 3 },
    featuredList: { paddingHorizontal: 20, paddingTop: 10 },
    featuredRow: { flexDirection: 'row', gap: 12, paddingLeft: 20, paddingTop: 10, overflow: 'hidden' },
    error: { margin: 20, padding: 18, gap: 8 },
    errorTitle: { fontSize: 18 },
    errorBtn: { marginTop: 6, alignSelf: 'flex-start' },
    errorBtns: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
    continue: { width: 120, gap: 4 },
    progressTrack: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 4, backgroundColor: 'rgba(0,0,0,0.5)' },
    progressFill: { height: 4 },
    cardTitle: { fontSize: 13, lineHeight: 18, marginTop: 2 },
    small: { fontSize: 11, lineHeight: 14 },
    chGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, paddingHorizontal: 20 },
    chCell: {
      width: '47.5%',
      flexGrow: 1,
      flexDirection: 'row',
      gap: 10,
      padding: 8,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: groupBg,
    },
    chText: { flex: 1, minWidth: 0, gap: 3, justifyContent: 'center' },
    chTitle: { fontSize: 13, lineHeight: 17 },
    chRead: { alignSelf: 'flex-start', height: 24, marginTop: 4, paddingHorizontal: 10 },
    chPrice: { fontSize: 10, lineHeight: 13, fontWeight: '700' },
  });
};
