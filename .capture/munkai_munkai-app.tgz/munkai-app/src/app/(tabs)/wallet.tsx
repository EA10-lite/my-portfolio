/**
 * Wallet — approved mocks "Wallet", "Add funds / Withdraw → website", "Transfer (in-app)".
 * Balance + address come from the profile; activity from GET /api/payments/history and
 * GET /api/payments/transfer-history. Add funds / Withdraw finish on munkai.art.
 */
import * as Clipboard from 'expo-clipboard';
import { router, useFocusEffect } from 'expo-router';
import { ArrowDown, ArrowUpRight, Copy, History, Plus, Send } from 'lucide-react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { Image, Pressable, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTabBarScroll, useTabBarSpace } from '@/components/navigation/tabBarState';
import { ActivityRow, ActivityRowSkeleton } from '@/components/wallet/ActivityRow';
import { WebHandoffSheet, type HandoffKind } from '@/components/wallet/WebHandoffSheet';
import { TransferSheet } from '@/components/wallet/TransferSheet';
import { CutShape, Skeleton, SkeletonGroup, Text, useToast } from '@/components/ui';
import { formatBalance } from '@/lib/format';
import { QK } from '@/lib/queryKeys';
import { TOKENS_PER_USD, shortAddress, toUsd } from '@/lib/wallet';
import { useFetch } from '@/lib/useFetch';
import { paymentsApi } from '@/services/payments';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

export default function WalletScreen() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const space = useTabBarSpace();
  const onScroll = useTabBarScroll();
  const user = useSession((s) => s.user);
  const refreshProfile = useSession((s) => s.refreshProfile);

  const payments = useFetch(QK.paymentHistory, paymentsApi.history);
  const transfers = useFetch(QK.transfers, paymentsApi.transfers);
  const [handoff, setHandoff] = useState<HandoffKind | null>(null);
  const [transferOpen, setTransferOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    useCallback(() => {
      refreshProfile();
    }, [refreshProfile]),
  );

  const activity = useMemo(
    () =>
      [...(payments.data ?? []), ...(transfers.data ?? [])]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 6),
    [payments.data, transfers.data],
  );
  const activityLoading = payments.loading || transfers.loading;
  const activityError = !activityLoading && payments.error && transfers.error;

  const balance = Number(user?.balance ?? 0);
  const address = user?.walletAddress;

  const refreshAll = async () => {
    setRefreshing(true);
    await Promise.all([refreshProfile(), payments.refetch(), transfers.refetch()]);
    setRefreshing(false);
  };

  const copy = async () => {
    if (!address) return;
    await Clipboard.setStringAsync(address);
    toast.success('Address copied', shortAddress(address));
  };

  return (
    <View style={styles.root}>
      <ScrollView
        onScroll={onScroll}
        scrollEventThrottle={32}
        contentContainerStyle={{ paddingTop: insets.top + 8, paddingBottom: space }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={refreshAll} tintColor={t.colors.primary} colors={[t.colors.primary]} />
        }
      >
        <View style={styles.header}>
          <Text variant="title" style={styles.h1} accessibilityRole="header">
            Wallet
          </Text>
          <Pressable
            onPress={() => router.push('/wallet-history')}
            accessibilityRole="button"
            accessibilityLabel="Transaction history"
            style={({ pressed }) => [styles.round, { backgroundColor: withAlpha(t.colors.primary, pressed ? 0.16 : 0.08) }]}
          >
            <History size={20} color={t.colors.foreground} strokeWidth={2} />
          </Pressable>
        </View>

        {/* Balance */}
        <View style={styles.pad}>
          <CutShape
            cuts={t.cuts.card}
            fill={t.isDark ? '#121637' : withAlpha(t.colors.primary, 0.08)}
            stroke={withAlpha(t.colors.primary, 0.2)}
            style={styles.balance}
          >
            <Image source={require('../../../assets/images/munk-coin.png')} style={styles.coin} accessibilityIgnoresInvertColors />
            <Text variant="caption" color="mutedForeground">
              Balance
            </Text>
            {user ? (
              <>
                <Text style={styles.amount} accessibilityLabel={`${formatBalance(balance)} Munk tokens`}>
                  ጠ {formatBalance(balance)}
                </Text>
                <Text variant="bodySmall" color="mutedForeground">
                  ≈ ${toUsd(balance)} USD
                </Text>
              </>
            ) : (
              <SkeletonGroup>
                <Skeleton width={180} height={36} style={{ marginTop: 8 }} />
              </SkeletonGroup>
            )}
            {address ? (
              <Pressable
                onPress={copy}
                accessibilityRole="button"
                accessibilityLabel="Copy wallet address"
                style={({ pressed }) => [styles.address, { borderColor: withAlpha(t.colors.primary, 0.14) }, pressed && { opacity: 0.7 }]}
              >
                <Text variant="caption" color="mutedForeground">
                  Address
                </Text>
                <Text numberOfLines={1} style={[styles.addressText, { color: t.colors.foreground }]}>
                  {shortAddress(address)}
                </Text>
                <Copy size={16} color={t.colors.primary} strokeWidth={2} />
              </Pressable>
            ) : null}
          </CutShape>
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <Action
            label="Add funds"
            primary
            external
            icon={<Plus size={20} color={t.colors.onPrimary} strokeWidth={2.4} />}
            onPress={() => setHandoff('deposit')}
          />
          <Action
            label="Withdraw"
            external
            icon={<ArrowDown size={20} color={t.colors.primary} strokeWidth={2.2} />}
            onPress={() => setHandoff('withdraw')}
          />
          <Action
            label="Transfer"
            icon={<Send size={18} color={t.colors.primary} strokeWidth={2.2} />}
            onPress={() => setTransferOpen(true)}
          />
        </View>
        <View style={styles.note}>
          <ArrowUpRight size={12} color={t.colors.mutedForeground} strokeWidth={2} />
          <Text variant="bodySmall" color="mutedForeground" style={styles.noteText}>
            Add funds and Withdraw open munkai.art · $1 = ጠ{TOKENS_PER_USD}
          </Text>
        </View>

        {/* Activity */}
        <View style={styles.sectionHead}>
          <Text variant="heading" style={styles.sectionTitle}>
            Recent activity
          </Text>
          {activity.length > 0 ? (
            <Pressable onPress={() => router.push('/wallet-history')} hitSlop={10} accessibilityRole="button">
              <Text variant="subtitle" color="primary" style={styles.seeAll}>
                See all
              </Text>
            </Pressable>
          ) : null}
        </View>
        <View style={styles.group}>
          {activityLoading ? (
            <SkeletonGroup>
              {[0, 1, 2, 3].map((i) => (
                <ActivityRowSkeleton key={i} divider={i > 0} />
              ))}
            </SkeletonGroup>
          ) : activityError ? (
            <Pressable onPress={refreshAll} style={styles.emptyBox} accessibilityRole="button">
              <Text variant="bodySmall" color="mutedForeground" align="center">
                Couldn’t load activity. Tap to retry.
              </Text>
            </Pressable>
          ) : activity.length === 0 ? (
            <View style={styles.emptyBox}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                No transactions yet. Add funds to get started.
              </Text>
            </View>
          ) : (
            activity.map((a, i) => <ActivityRow key={a.id} item={a} divider={i > 0} />)
          )}
        </View>
      </ScrollView>

      <WebHandoffSheet
        kind={handoff}
        onClose={() => setHandoff(null)}
        onReturn={() => {
          refreshAll();
        }}
      />
      <TransferSheet
        visible={transferOpen}
        onClose={() => setTransferOpen(false)}
        balance={balance}
        onSent={() => {
          refreshAll();
        }}
      />
    </View>
  );
}

function Action({
  label,
  icon,
  onPress,
  primary,
  external,
}: {
  label: string;
  icon: React.ReactNode;
  onPress: () => void;
  primary?: boolean;
  external?: boolean;
}) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={external ? `${label}, opens munkai.art` : label}
      style={({ pressed }) => [styles.action, pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] }]}
    >
      <View style={[styles.actionIcon, { backgroundColor: primary ? t.colors.primary : withAlpha(t.colors.primary, 0.14) }]}>{icon}</View>
      <Text variant="subtitle" style={styles.actionText}>
        {label}
      </Text>
      {external ? (
        <View style={styles.ext}>
          <ArrowUpRight size={14} color={t.colors.mutedForeground} strokeWidth={2} />
        </View>
      ) : null}
    </Pressable>
  );
}

const makeStyles = (t: Theme) => {
  const groupBg = t.isDark ? withAlpha(t.colors.card, 0.9) : withAlpha(t.colors.background, 0.8);
  return StyleSheet.create({
    // Transparent: the tabs layout paints the page colour + the moving background behind.
    root: { flex: 1 },
    pad: { paddingHorizontal: 20 },
    header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20 },
    h1: { flex: 1, fontSize: 30, lineHeight: 36 },
    round: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
    balance: { marginTop: 16, padding: 20, overflow: 'hidden' },
    coin: { position: 'absolute', right: -18, top: -14, width: 128, height: 128 },
    amount: { fontFamily: t.fonts.displayBold, fontSize: 40, lineHeight: 48, color: t.colors.foreground, marginTop: 4 },
    address: {
      marginTop: 18,
      paddingHorizontal: 10,
      paddingVertical: 8,
      borderWidth: 1,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: withAlpha('#00002B', t.isDark ? 0.45 : 0.04),
    },
    addressText: { flex: 1, fontFamily: 'SpaceGrotesk-Medium', fontSize: 13, lineHeight: 18 },
    actions: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, paddingTop: 16 },
    action: {
      flex: 1,
      height: 84,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.14),
      backgroundColor: groupBg,
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
    },
    actionIcon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
    actionText: { fontSize: 13, lineHeight: 17 },
    ext: { position: 'absolute', top: 8, right: 8 },
    note: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 20, paddingTop: 10 },
    noteText: { fontSize: 12, lineHeight: 16 },
    sectionHead: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 24, paddingBottom: 10 },
    sectionTitle: { flex: 1, fontSize: 20 },
    seeAll: { fontSize: 13 },
    group: {
      marginHorizontal: 20,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: groupBg,
      overflow: 'hidden',
    },
    emptyBox: { padding: 24 },
  });
};
