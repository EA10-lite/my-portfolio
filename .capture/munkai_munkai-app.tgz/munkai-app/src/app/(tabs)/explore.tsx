/**
 * Explore — approved mock "Explore" (types + fiction/non-fiction moved into the filter sheet).
 * Data: GET /api/publications (filtered on the device, same rules as the web) and
 * GET /api/landing for the spotlight card.
 */
import { router, useLocalSearchParams } from 'expo-router';
import { CheckCircle2, ChevronRight, Crown, Gift, Layers, Search, SlidersHorizontal, Sparkles, Star, X } from 'lucide-react-native';
import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { PublicationCard, PublicationCardSkeleton } from '@/components/content/cards';
import { Cover } from '@/components/content/Cover';
import { SectionHeader } from '@/components/content/Shelf';
import { DEFAULT_FILTERS, ExploreFilterSheet, activeFilterCount, type ExploreFilters } from '@/components/explore/FilterSheet';
import { useTabBarScroll, useTabBarSpace } from '@/components/navigation/tabBarState';
import { Button, CutShape, Skeleton, SkeletonGroup, Text } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { PUBLICATION_TYPES, genres, openPublication, typeLabel } from '@/lib/publication';
import { QK } from '@/lib/queryKeys';
import { useFetch } from '@/lib/useFetch';
import { useInfinite } from '@/lib/useInfinite';
import { contentApi } from '@/services/content';
import type { Publication } from '@/services/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const SHORTCUTS = [
  { kind: 'chapters', label: 'Chapters', icon: Layers },
  { kind: 'creators', label: 'Top creators', icon: Crown },
  { kind: 'free', label: 'Free', icon: Gift },
  { kind: 'picks', label: 'Munkai picks', icon: Star },
  { kind: 'featured', label: 'Featured', icon: Sparkles },
  { kind: 'completed', label: 'Completed', icon: CheckCircle2 },
] as const;

const COLS = 3;
const GAP = 12;

/** Same matching rules as munkai-frontend/src/app/publications/page.tsx. */
function applyFilters(list: Publication[], q: string, f: ExploreFilters) {
  const query = q.trim().toLowerCase();
  const lang = f.language.trim().toLowerCase();
  const out = list.filter((pub) => {
    if (query) {
      const hit =
        (pub.name ?? '').toLowerCase().includes(query) ||
        genres(pub).some((g) => g.toLowerCase().includes(query)) ||
        (pub.username ?? pub.author?.username ?? '').toLowerCase().includes(query);
      if (!hit) return false;
    }
    if (f.type !== 'all' && (pub.publicationType ?? '').toLowerCase() !== f.type) return false;
    if (f.origin === 'fan' && !pub.isFanfic) return false;
    if (f.origin === 'original' && pub.isFanfic) return false;
    if (lang && !(pub.originalLanguage ?? '').toLowerCase().includes(lang)) return false;
    if (f.category === 'fiction' && !pub.isFiction) return false;
    if (f.category === 'non-fiction' && pub.isFiction) return false;
    return true;
  });
  const time = (p: Publication) => new Date(p.createdAt ?? 0).getTime() || 0;
  return out.sort((a, b) => (f.sort === 'desc' ? time(b) - time(a) : time(a) - time(b)));
}

export default function Explore() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const space = useTabBarSpace();
  const onScroll = useTabBarScroll();
  const params = useLocalSearchParams<{ focus?: string }>();

  const pubs = useInfinite(QK.publications, (cursor) => contentApi.publicationsPage({ cursor }));
  const landing = useFetch(QK.landing, contentApi.landing);

  const query = '';
  const [filters, setFilters] = useState<ExploreFilters>(DEFAULT_FILTERS);
  const [sheet, setSheet] = useState(false);

  // Home's search button lands here with ?focus=1 → go straight to the search screen.
  useEffect(() => {
    if (params.focus) {
      router.setParams({ focus: undefined });
      router.push('/search');
    }
  }, [params.focus]);

  const count = activeFilterCount(filters);
  const searching = query.trim().length > 0 || count > 0;
  const results = useMemo(() => applyFilters(pubs.items, query, filters), [pubs.items, query, filters]);
  // Filters run on the pages loaded so far (like the web) — keep pulling pages while a filter shows little.
  useEffect(() => {
    if (count > 0 && results.length < 12 && pubs.canLoadMore && !pubs.loading && !pubs.loadingMore) pubs.loadMore();
  }, [count, results.length, pubs]);
  const cardW = Math.floor((width - 40 - GAP * (COLS - 1)) / COLS);
  const spotlight = landing.data?.featuredPublications[new Date().getMonth() % Math.max(landing.data.featuredPublications.length, 1)];

  const chips = activeChips(filters);

  const header = (
    <View>
      <Text variant="title" style={[styles.h1, { marginTop: insets.top + 8 }]} accessibilityRole="header">
        Explore
      </Text>
      <View style={styles.searchRow}>
        {/* Tapping the field opens the full-screen search (approved mock "Explore · fixed search bar"). */}
        <Pressable
          onPress={() => router.push('/search')}
          accessibilityRole="search"
          accessibilityLabel="Search titles, genres, creators"
          style={({ pressed }) => [styles.search, pressed && { backgroundColor: t.colors.hover }]}
        >
          <Search size={20} color={t.colors.mutedForeground} strokeWidth={2} />
          <Text variant="body" color="mutedForeground" numberOfLines={1} style={styles.searchText}>
            Search titles, genres, creators
          </Text>
        </Pressable>
        <Pressable
          onPress={() => setSheet(true)}
          accessibilityRole="button"
          accessibilityLabel={count ? `Filters, ${count} active` : 'Filters'}
          style={({ pressed }) => [
            styles.filterBtn,
            count > 0 && { borderColor: t.colors.primary },
            pressed && { backgroundColor: t.colors.hover },
          ]}
        >
          <SlidersHorizontal size={20} color={t.colors.primary} strokeWidth={2} />
          {count > 0 ? (
            <View style={[styles.count, { backgroundColor: t.colors.primary }]}>
              <Text style={[styles.countText, { color: t.colors.onPrimary }]}>{count}</Text>
            </View>
          ) : null}
        </Pressable>
      </View>

      {chips.length > 0 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.activeChips}>
          {chips.map((c) => (
            <Pressable
              key={c.key}
              onPress={() => setFilters((f) => ({ ...f, [c.key]: DEFAULT_FILTERS[c.key] }))}
              accessibilityRole="button"
              accessibilityLabel={`Remove filter ${c.label}`}
              style={[styles.activeChip, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}
            >
              <Text variant="subtitle" color="primary" style={styles.activeChipText}>
                {c.label}
              </Text>
              <X size={14} color={t.colors.primary} strokeWidth={2.4} />
            </Pressable>
          ))}
        </ScrollView>
      ) : null}

      {!searching ? (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.shortcuts}>
            {SHORTCUTS.map(({ kind, label, icon: Icon }) => (
              <Pressable
                key={kind}
                onPress={() => router.push({ pathname: '/browse/[kind]', params: { kind } })}
                accessibilityRole="button"
                style={({ pressed }) => [pressed && { opacity: 0.7 }]}
              >
                <CutShape
                  cuts={t.cuts.card}
                  fill={withAlpha(t.colors.primary, 0.07)}
                  stroke={withAlpha(t.colors.primary, 0.14)}
                  style={styles.shortcut}
                >
                  <Icon size={20} color={t.colors.primary} strokeWidth={2} />
                  <Text variant="subtitle" style={styles.shortcutText}>
                    {label}
                  </Text>
                </CutShape>
              </Pressable>
            ))}
          </ScrollView>

          {landing.loading ? (
            <>
              <SectionHeader title="Monthly spotlight" icon={Sparkles} />
              <View style={styles.pad}>
                <Skeleton height={180} />
              </View>
            </>
          ) : spotlight ? (
            <>
              <SectionHeader
                title="Monthly spotlight"
                icon={Sparkles}
                onSeeAll={() => router.push({ pathname: '/browse/[kind]', params: { kind: 'featured' } })}
              />
              <Pressable
                onPress={() => openPublication(spotlight)}
                accessibilityRole="button"
                accessibilityLabel={`Spotlight: ${spotlight.name}`}
                style={styles.pad}
              >
                <Cover uri={spotlight.coverPhoto} height={180} blur={3} style={styles.spot}>
                  <View style={[StyleSheet.absoluteFill, { backgroundColor: withAlpha('#00002B', 0.62) }]} />
                  <View style={styles.spotBody}>
                    <View style={styles.spotCover}>
                      <Cover uri={spotlight.coverPhoto} width={96} height={140} />
                    </View>
                    <View style={styles.spotText}>
                      <View style={[styles.spotBadge, { backgroundColor: t.colors.primary }]}>
                        <Text style={[styles.spotBadgeText, { color: t.colors.onPrimary }]}>Spotlight</Text>
                      </View>
                      <Text variant="heading" numberOfLines={2} style={styles.spotTitle}>
                        {spotlight.name}
                      </Text>
                      <Text variant="bodySmall" numberOfLines={1} style={styles.spotMeta}>
                        {[spotlight.username ? `by @${spotlight.username}` : null, typeLabel(spotlight.publicationType)]
                          .filter(Boolean)
                          .join(' · ')}
                      </Text>
                      <View style={styles.spotCta}>
                        <Text variant="subtitle" style={styles.spotCtaText}>
                          Start reading
                        </Text>
                        <ChevronRight size={14} color="#87CEEB" strokeWidth={2.4} />
                      </View>
                    </View>
                  </View>
                </Cover>
              </Pressable>
            </>
          ) : null}
        </>
      ) : null}

      <View style={styles.gridHead}>
        <Text variant="heading" style={styles.gridTitle}>
          {searching
            ? pubs.loading
              ? 'Filtering…'
              : `${results.length} ${results.length === 1 ? 'result' : 'results'}`
            : 'All publications'}
        </Text>
        <Pressable onPress={() => setSheet(true)} hitSlop={8} accessibilityRole="button" accessibilityLabel="Change sort order">
          <Text variant="subtitle" color="mutedForeground" style={styles.sort}>
            {filters.sort === 'desc' ? 'Newest' : 'Oldest'} ▾
          </Text>
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.root}>
      <SkeletonGroup>
        <FlatList
          data={pubs.loading ? [] : results}
          keyExtractor={(p) => String(p.id)}
          numColumns={COLS}
          columnWrapperStyle={styles.col}
          renderItem={({ item }) => <PublicationCard pub={item} width={cardW} />}
          ListHeaderComponent={header}
          ListEmptyComponent={
            pubs.loading ? (
              <View style={styles.skeletonGrid}>
                {Array.from({ length: 9 }, (_, i) => (
                  <PublicationCardSkeleton key={i} width={cardW} />
                ))}
              </View>
            ) : pubs.error ? (
              <View style={styles.empty}>
                <Text variant="heading" align="center">
                  Couldn’t load publications
                </Text>
                <Text variant="bodySmall" color="mutedForeground" align="center">
                  {apiErrorMessage(pubs.error)}
                </Text>
                <Button title="Try again" variant="outline" onPress={pubs.refresh} />
              </View>
            ) : (
              <View style={styles.empty}>
                <Text variant="heading" align="center">
                  Nothing matches
                </Text>
                <Text variant="bodySmall" color="mutedForeground" align="center">
                  Try another word or clear some filters.
                </Text>
                {count > 0 ? <Button title="Clear filters" variant="outline" onPress={() => setFilters(DEFAULT_FILTERS)} /> : null}
              </View>
            )
          }
          contentContainerStyle={{ paddingBottom: space }}
          onEndReached={pubs.loadMore}
          onEndReachedThreshold={0.6}
          ListFooterComponent={
            pubs.loadingMore ? (
              <View style={styles.more}>
                <ActivityIndicator color={t.colors.primary} />
              </View>
            ) : null
          }
          onScroll={onScroll}
          scrollEventThrottle={32}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          showsVerticalScrollIndicator={false}
          initialNumToRender={12}
          refreshControl={
            <RefreshControl
              refreshing={pubs.refreshing}
              onRefresh={() => {
                pubs.refresh();
                landing.reload();
              }}
              tintColor={t.colors.primary}
              colors={[t.colors.primary]}
            />
          }
        />
      </SkeletonGroup>

      <ExploreFilterSheet
        visible={sheet}
        onClose={() => setSheet(false)}
        value={filters}
        onApply={setFilters}
        countFor={(f) => applyFilters(pubs.items, query, f).length}
      />
    </View>
  );
}

function activeChips(f: ExploreFilters): { key: keyof ExploreFilters; label: string }[] {
  const out: { key: keyof ExploreFilters; label: string }[] = [];
  if (f.category !== 'all') out.push({ key: 'category', label: f.category === 'fiction' ? 'Fiction' : 'Non-fiction' });
  if (f.type !== 'all') out.push({ key: 'type', label: PUBLICATION_TYPES.find((x) => x.value === f.type)?.label ?? f.type });
  if (f.origin !== 'all') out.push({ key: 'origin', label: f.origin === 'fan' ? 'Translated' : 'Original' });
  if (f.language.trim()) out.push({ key: 'language', label: f.language.trim() });
  if (f.sort !== 'desc') out.push({ key: 'sort', label: 'Oldest first' });
  return out;
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    // Transparent: the tabs layout paints the page colour + the moving background behind.
    root: { flex: 1 },
    pad: { paddingHorizontal: 20 },
    h1: { paddingHorizontal: 20, fontSize: 30, lineHeight: 36 },
    searchRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 20, paddingTop: 12 },
    search: {
      flex: 1,
      height: 48,
      borderRadius: t.radius.search,
      paddingHorizontal: 16,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      backgroundColor: t.colors.inputBackground,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.18),
    },
    searchText: { flex: 1, fontSize: 15, lineHeight: 20 },
    more: { paddingVertical: 20 },
    filterBtn: {
      width: 48,
      height: 48,
      borderRadius: t.radius.search,
      backgroundColor: t.colors.inputBackground,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.3),
      alignItems: 'center',
      justifyContent: 'center',
    },
    count: {
      position: 'absolute',
      top: -7,
      right: -7,
      minWidth: 18,
      height: 18,
      borderRadius: 9,
      paddingHorizontal: 4,
      alignItems: 'center',
      justifyContent: 'center',
    },
    countText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 11, lineHeight: 14 },
    activeChips: { paddingHorizontal: 20, paddingTop: 12, gap: 8 },
    activeChip: { height: 32, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 6 },
    activeChipText: { fontSize: 12, lineHeight: 16 },
    shortcuts: { paddingHorizontal: 20, paddingTop: 16, gap: 10 },
    shortcut: { width: 96, height: 76, padding: 12, justifyContent: 'space-between' },
    shortcutText: { fontSize: 12, lineHeight: 15 },
    spot: { justifyContent: 'flex-end' },
    spotBody: { flexDirection: 'row', alignItems: 'flex-end', gap: 14, padding: 16, flex: 1 },
    spotCover: { shadowColor: '#000', shadowOpacity: 0.6, shadowRadius: 12, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
    spotText: { flex: 1, gap: 6, paddingBottom: 2 },
    spotBadge: { alignSelf: 'flex-start', paddingHorizontal: 6, paddingVertical: 2 },
    spotBadgeText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 9, lineHeight: 13, letterSpacing: 0.9, textTransform: 'uppercase' },
    spotTitle: { color: '#F2F2F2', fontSize: 22, lineHeight: 26 },
    spotMeta: { color: '#C9CCD6', fontSize: 12, lineHeight: 16 },
    spotCta: { flexDirection: 'row', alignItems: 'center', gap: 2 },
    spotCtaText: { color: '#87CEEB', fontSize: 12, lineHeight: 16 },
    gridHead: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 28, paddingBottom: 12 },
    gridTitle: { flex: 1, fontSize: 20 },
    sort: { fontSize: 13 },
    col: { paddingHorizontal: 20, gap: GAP, marginBottom: 18 },
    skeletonGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 20, columnGap: GAP, rowGap: 18 },
    empty: { alignItems: 'center', gap: 10, paddingHorizontal: 32, paddingTop: 40 },
  });
