/**
 * Profile tab — approved mocks "Profile · Reader", "Profile · Creator", "Profile · Light".
 * Web: munkai-frontend/src/app/profile + components/profiles/{userProfile,creatorProfile}.tsx
 * Layout follows the web at phone width (identity stack on the right), then referrals (inline) and the library
 * (Collections / Saved). Downloads have their own tab; settings, support, account and legal moved to /settings (gear on the banner).
 */
import * as Clipboard from 'expo-clipboard';
import { router, useFocusEffect } from 'expo-router';
import { CalendarDays, ChevronRight, Copy, NotebookPen, Settings as SettingsIcon, Share as ShareIcon, Users } from 'lucide-react-native';
import React, { useCallback, useRef, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, Share, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTabBarScroll, useTabBarSpace } from '@/components/navigation/tabBarState';
import { ProfileBanner } from '@/components/profile/ProfileBanner';
import { ProfileLibrary } from '@/components/profile/ProfileLibrary';
import { Avatar, Button, CutShape, Text, useToast } from '@/components/ui';
import { WEB_URL } from '@/lib/config';
import { useGreeting } from '@/lib/greetings';
import { formatBalance, formatCompact, formatMonthYear, roleLabel } from '@/lib/format';
import { isCreatorRole } from '@/services/creator';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

type Referral = { firstName?: string; lastName?: string; username?: string; profileImage?: string | null };

/** How many referrals show inline before "See all". */
const REFERRALS_INLINE = 5;

export default function ProfileScreen() {
  const tabSpace = useTabBarSpace();
  const onTabScroll = useTabBarScroll();
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { user, refreshProfile } = useSession();
  const greeting = useGreeting(isCreatorRole(user?.role) || (user ? roleLabel(user) === 'Creator' : false) ? 'creator' : 'reader');

  const [refreshing, setRefreshing] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const libraryY = useRef(0);
  // The cached profile may predate the library fields → skeletons until the first refresh lands.
  const hasLibrary = user?.collectedPublications !== undefined || user?.collectedChapters !== undefined;
  const [synced, setSynced] = useState(hasLibrary);

  // Fresh numbers whenever the tab comes into view.
  useFocusEffect(
    useCallback(() => {
      refreshProfile().finally(() => setSynced(true));
    }, [refreshProfile]),
  );

  if (!user) return <View style={styles.root} />;

  const role = roleLabel(user);
  const isCreator = isCreatorRole(user.role) || role === 'Creator';
  const code = user.referralDetails?.myReferralCode;
  const referredBy = user.referralDetails?.referredBy;
  const referralCount = user.referralDetails?.referralsCount ?? user.referralDetails?.referrals?.length ?? 0;
  const joined = formatMonthYear(user.createdAt, 'long');
  const referrals = (user.referralDetails?.referrals ?? []) as Referral[];
  const libraryLoading = !synced && !hasLibrary;
  const scrollToLibrary = () => scrollRef.current?.scrollTo({ y: Math.max(0, libraryY.current - 12), animated: true });

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshProfile();
    setRefreshing(false);
  };

  const shareProfile = () =>
    Share.share({
      message: `Follow ${user.firstName} (@${user.username}) on Munkai — ${WEB_URL}/creator/${user.username}?id=${user.id}`,
    }).catch(() => {});

  const shareCode = () =>
    code &&
    Share.share({ message: `Join me on Munkai — rare digital literature & collectibles. Use my code ${code} when you sign up.` }).catch(
      () => {},
    );

  const copyCode = async () => {
    if (!code) return;
    await Clipboard.setStringAsync(code);
    toast.success('Code copied', 'Ready to paste.');
  };

  // Web labels (components/profiles/{userProfile,creatorProfile}.tsx).
  const balanceStat = {
    value: `ጠ ${formatBalance(user.balance)}`,
    label: 'Current Munk Balance',
    onPress: () => router.navigate('/wallet'),
  };
  const followedStat = {
    value: formatCompact(user.followedCreators ?? 0),
    label: 'Followed Creators',
    // Who you follow / who follows you is a paid feature with no endpoint yet: counts only, not tappable.
    onPress: undefined,
  };
  const stats = isCreator
    ? [
        {
          value: formatCompact(user.creatorDetails?.ownedPublicationsCount ?? user.publicationsCount ?? 0),
          label: 'Publications Manifested',
          onPress: () => router.push('/studio'),
        },
        balanceStat,
        { value: formatCompact(user.creatorDetails?.followersCount ?? 0), label: 'Followers Count', onPress: undefined },
        followedStat,
      ]
    : [
        { value: formatCompact(user.collectedChaptersCount ?? 0), label: 'Total Collections', onPress: scrollToLibrary },
        balanceStat,
        followedStat,
      ];

  return (
    <View style={styles.root}>
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={[styles.scroll, { paddingBottom: tabSpace }]}
        onScroll={onTabScroll}
        scrollEventThrottle={32}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={t.colors.primary}
            colors={[t.colors.primary]}
            progressViewOffset={insets.top}
          />
        }
      >
        {/* Banner */}
        <View>
          <ProfileBanner uri={user.bannerImage} />
          <View style={[styles.bannerBtns, { top: insets.top + 8 }]}>
            <Pressable onPress={shareProfile} accessibilityRole="button" accessibilityLabel="Share profile" style={styles.bannerBtn}>
              <ShareIcon size={18} color={t.colors.foreground} strokeWidth={2} />
            </Pressable>
            <Pressable
              onPress={() => router.push('/settings')}
              accessibilityRole="button"
              accessibilityLabel="Settings"
              style={styles.bannerBtn}
            >
              <SettingsIcon size={18} color={t.colors.foreground} strokeWidth={2} />
            </Pressable>
          </View>
        </View>

        {/* Identity — web profile at phone width: picture on the right over the banner, text on the left,
            main button on the right (munkai-frontend components/profiles/{userProfile,creatorProfile}.tsx). */}
        <View style={styles.identity}>
          <View style={styles.avatarWrap}>
            <View style={styles.avatarRing}>
              <Avatar
                uri={user.profileImage}
                firstName={user.firstName}
                lastName={user.lastName}
                seed={user.username}
                size={112}
                ghost="light"
              />
            </View>
            <View style={[styles.onlineDot, { borderColor: t.colors.pageBackground }]}>
              <View style={styles.onlineCore} />
            </View>
          </View>
          <Text variant="caption" color="primary" numberOfLines={1} style={styles.greeting}>
            {greeting || ' '}
          </Text>
          <View style={styles.nameRow}>
            <Text style={styles.name}>
              {user.firstName} {user.lastName}
            </Text>
            <Pressable
              onPress={() => router.push('/edit-profile')}
              accessibilityRole="button"
              accessibilityLabel="Edit profile"
              hitSlop={8}
              style={({ pressed }) => [styles.editBtn, pressed && { opacity: 0.6 }]}
            >
              <NotebookPen size={20} color={t.colors.primary} strokeWidth={2} />
            </Pressable>
          </View>
          <View style={styles.metaRow}>
            {isCreator ? (
              <View
                style={[
                  styles.rolePill,
                  { backgroundColor: withAlpha(t.colors.primary, 0.1), borderColor: withAlpha(t.colors.primary, 0.2) },
                ]}
              >
                <View style={[styles.roleDot, { backgroundColor: t.colors.primary }]} />
                <Text variant="caption" color="primary">
                  {user.creatorDetails?.isTranslator ? 'Translator' : role}
                </Text>
              </View>
            ) : null}
            <Text variant="bodySmall" color={isCreator ? 'mutedForeground' : 'primary'} style={styles.handle}>
              @{user.username}
            </Text>
            {joined ? <View style={styles.dot} /> : null}
          </View>
          {joined ? <JoinedLabel text={isCreator ? `Joined: ${joined}` : `Joined ${joined}`} upper={isCreator} /> : null}
          <Button
            title={isCreator ? 'Create Publication' : 'Ascend to Creator'}
            onPress={() => router.push(isCreator ? '/studio/publication-form' : '/become-creator')}
            style={styles.cta}
          />
        </View>

        {/* Stats — web: one panel, grid-cols-2 on phones, centred */}
        <View
          style={[styles.statsPanel, { borderColor: withAlpha(t.colors.primary, 0.08), backgroundColor: withAlpha(t.colors.card, 0.35) }]}
        >
          {stats.map((s) => (
            <Pressable
              key={s.label}
              onPress={s.onPress}
              disabled={!s.onPress}
              accessibilityRole={s.onPress ? 'button' : 'text'}
              accessibilityLabel={`${s.label}: ${s.value}`}
              style={({ pressed }) => [styles.statCell, pressed && { opacity: 0.6 }]}
            >
              <Text variant="caption" color="mutedForeground" align="center" style={styles.statLabel}>
                {s.label}
              </Text>
              <Text style={styles.statValue} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>
                {s.value}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Referral nexus */}
        <View style={styles.section}>
          <Text variant="caption" color="primary" style={styles.sectionTitle}>
            Your Referral Code
          </Text>
          <CutShape
            cuts={t.cuts.card}
            fill={withAlpha(t.colors.primary, t.isDark ? 0.06 : 0.05)}
            stroke={withAlpha(t.colors.primary, 0.14)}
          >
            <View style={styles.codeRow}>
              <View style={styles.flex}>
                <Text variant="caption">Divine Code</Text>
                <Text style={styles.code} selectable>
                  {code ?? '—'}
                </Text>
              </View>
              <Pressable
                onPress={copyCode}
                accessibilityRole="button"
                accessibilityLabel="Copy referral code"
                style={({ pressed }) => [styles.copyBtn, pressed && { backgroundColor: t.colors.hover }]}
              >
                <Copy size={18} color={t.colors.primary} strokeWidth={2} />
              </Pressable>
              <Pressable
                onPress={shareCode}
                accessibilityRole="button"
                accessibilityLabel="Share referral code"
                style={({ pressed }) => [styles.shareBtn, { opacity: pressed ? 0.85 : 1 }]}
              >
                <ShareIcon size={16} color={t.colors.onPrimary} strokeWidth={2.2} />
                <Text variant="label" color={t.colors.onPrimary}>
                  Share
                </Text>
              </Pressable>
            </View>
            {referredBy ? (
              <View style={[styles.refRow, styles.refDivider]}>
                <Avatar
                  uri={referredBy.profileImage}
                  firstName={referredBy.firstName}
                  lastName={referredBy.lastName}
                  seed={referredBy.username}
                  size={32}
                />
                <Text variant="bodySmall" style={styles.flex}>
                  <Text variant="bodySmall" color="mutedForeground">
                    Referred By{' '}
                  </Text>
                  <Text variant="bodySmall" style={styles.bold}>
                    @{referredBy.username}
                  </Text>
                </Text>
              </View>
            ) : (
              <View style={[styles.refRow, styles.refDivider]}>
                <Text variant="bodySmall" color="mutedForeground" style={styles.italic}>
                  Self-Manifested Entity
                </Text>
              </View>
            )}
            <Pressable
              onPress={() => router.push('/referrals')}
              accessibilityRole="button"
              accessibilityLabel={`Your Connections, ${referralCount}`}
              style={({ pressed }) => [styles.refRow, styles.refDivider, pressed && { backgroundColor: t.colors.hover }]}
            >
              <Users size={20} color={t.colors.primary} strokeWidth={2} />
              <Text variant="body" style={[styles.flex, styles.medium]}>
                Your Connections
              </Text>
              <View style={[styles.countPill, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}>
                <Text variant="bodySmall" color="primary" style={styles.bold}>
                  {referralCount}
                </Text>
              </View>
            </Pressable>
            {/* Web "Manifested Connections": the people, inline (first few; the rest on /referrals). */}
            {referrals.length === 0 ? (
              <View style={styles.refEmpty}>
                <Text variant="caption" color="mutedForeground" align="center">
                  No Connections Yet
                </Text>
                <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.small}>
                  Share your divine Code to have connections.
                </Text>
              </View>
            ) : (
              referrals.slice(0, REFERRALS_INLINE).map((r, i) => (
                <View key={r.username ?? String(i)} style={[styles.personRow, styles.refDivider]}>
                  <Avatar uri={r.profileImage} firstName={r.firstName} lastName={r.lastName} seed={r.username} size={36} />
                  <View style={styles.flex}>
                    <Text variant="subtitle" numberOfLines={1} style={styles.personName}>
                      {[r.firstName, r.lastName].filter(Boolean).join(' ') || r.username}
                    </Text>
                    {r.username ? (
                      <Text variant="bodySmall" color="primary" style={styles.small}>
                        @{r.username}
                      </Text>
                    ) : null}
                  </View>
                </View>
              ))
            )}
            {referralCount > REFERRALS_INLINE ? (
              <Pressable
                onPress={() => router.push('/referrals')}
                accessibilityRole="button"
                style={({ pressed }) => [styles.seeAll, styles.refDivider, pressed && { backgroundColor: t.colors.hover }]}
              >
                <Text variant="subtitle" color="primary" style={styles.seeAllText}>
                  See all ({referralCount})
                </Text>
                <ChevronRight size={16} color={t.colors.primary} strokeWidth={2.2} />
              </Pressable>
            ) : null}
          </CutShape>
        </View>

        {/* Your library — Collections / Saved (the Library tab is now Downloads) */}
        <View onLayout={(e) => (libraryY.current = e.nativeEvent.layout.y)}>
          <ProfileLibrary user={user} loading={libraryLoading} />
        </View>
      </ScrollView>
    </View>
  );
}

function JoinedLabel({ text, upper }: { text: string; upper?: boolean }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 }}>
      <CalendarDays size={14} color={t.colors.mutedForeground} strokeWidth={2} />
      <Text
        variant="bodySmall"
        color="mutedForeground"
        style={upper ? { textTransform: 'uppercase', letterSpacing: 1.2, fontSize: 12 } : undefined}
      >
        {text}
      </Text>
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    // Transparent: the tabs layout paints the page colour + the moving background behind.
    root: { flex: 1 },
    flex: { flex: 1 },
    bold: { fontFamily: t.fonts.bodyBold },
    medium: { fontFamily: t.fonts.bodyMedium, fontSize: 15 },
    italic: { fontStyle: 'italic' },
    scroll: { paddingBottom: 32 },
    bannerBtns: { position: 'absolute', right: 16, flexDirection: 'row', gap: 8 },
    bannerBtn: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: withAlpha(t.isDark ? t.colors.pageBackground : '#FFFFFF', t.isDark ? 0.55 : 0.7),
      borderWidth: 1,
      borderColor: withAlpha(t.isDark ? '#FFFFFF' : t.colors.primary, t.isDark ? 0.15 : 0.2),
    },
    identity: { paddingHorizontal: 20, marginTop: -64, alignItems: 'stretch', gap: 4 },
    avatarWrap: { alignSelf: 'flex-end' },
    greeting: { marginTop: 18, fontSize: 11, lineHeight: 16, letterSpacing: 3.3 },
    avatarRing: {
      padding: 4,
      borderRadius: 62,
      backgroundColor: t.colors.pageBackground,
      borderWidth: 2,
      borderColor: withAlpha(t.colors.primary, 0.35),
      shadowColor: '#000',
      shadowOpacity: 0.4,
      shadowRadius: 16,
      shadowOffset: { width: 0, height: 6 },
    },
    onlineDot: {
      position: 'absolute',
      right: 6,
      bottom: 6,
      width: 26,
      height: 26,
      borderRadius: 13,
      borderWidth: 4,
      backgroundColor: t.colors.primary,
      alignItems: 'center',
      justifyContent: 'center',
    },
    onlineCore: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#FFFFFF' },
    nameRow: { flexDirection: 'row', alignItems: 'center', gap: 12, maxWidth: '100%' },
    name: { flexShrink: 1, fontFamily: t.fonts.displayBold, fontSize: 30, lineHeight: 38, color: t.colors.foreground },
    editBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
    metaRow: { flexDirection: 'row', alignItems: 'center', gap: 14, flexWrap: 'wrap', marginTop: 6 },
    handle: { fontFamily: t.fonts.bodyBold, textTransform: 'uppercase', letterSpacing: 0.7 },
    dot: { width: 5, height: 5, borderRadius: 3, backgroundColor: withAlpha(t.colors.mutedForeground, 0.3) },
    rolePill: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 999,
      borderWidth: 1,
    },
    roleDot: { width: 7, height: 7, borderRadius: 4 },
    cta: { alignSelf: 'flex-end', marginTop: 24, paddingHorizontal: 28 },
    statsPanel: {
      marginHorizontal: 20,
      marginTop: 32,
      paddingVertical: 24,
      paddingHorizontal: 12,
      borderRadius: 16,
      borderWidth: 1,
      flexDirection: 'row',
      flexWrap: 'wrap',
      rowGap: 22,
    },
    statCell: { width: '50%', alignItems: 'center', gap: 6, paddingHorizontal: 6 },
    statValue: { fontFamily: t.fonts.displayBold, fontSize: 24, lineHeight: 30, color: t.colors.primary },
    statLabel: { letterSpacing: 1 },
    section: { paddingHorizontal: 20, paddingTop: 16, gap: 10 },
    sectionTitle: { letterSpacing: 1.6, fontSize: 11, marginTop: 10 },
    codeRow: { padding: 16, flexDirection: 'row', alignItems: 'center', gap: 10 },
    code: { fontFamily: t.fonts.displayBold, fontSize: 22, lineHeight: 28, letterSpacing: 3, color: t.colors.primary },
    copyBtn: {
      width: 44,
      height: 44,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.3),
      alignItems: 'center',
      justifyContent: 'center',
    },
    shareBtn: {
      height: 44,
      paddingHorizontal: 14,
      backgroundColor: t.colors.primary,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
    },
    refRow: { minHeight: 56, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 12 },
    refDivider: { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.1) },
    refEmpty: { paddingVertical: 16, paddingHorizontal: 16, gap: 4 },
    personRow: { minHeight: 56, paddingHorizontal: 16, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 12 },
    personName: { fontSize: 14, lineHeight: 19 },
    small: { fontSize: 12, lineHeight: 16 },
    seeAll: { minHeight: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4 },
    seeAllText: { fontSize: 13 },
    countPill: { paddingHorizontal: 10, paddingVertical: 2, borderRadius: 999 },
  });
