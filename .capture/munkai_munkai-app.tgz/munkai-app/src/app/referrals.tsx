/**
 * Your referrals — approved mock "Your referrals".
 * Web: the "Manifested Connections" panel in components/profiles/userProfile.tsx.
 */
import * as Clipboard from 'expo-clipboard';
import { router } from 'expo-router';
import { ChevronLeft, Copy, Share as ShareIcon, Users } from 'lucide-react-native';
import React from 'react';
import { FlatList, Pressable, Share, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Avatar, Button, CutShape, Text, useToast } from '@/components/ui';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

type Referral = { firstName?: string; lastName?: string; username?: string; profileImage?: string | null };

export default function Referrals() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const user = useSession((s) => s.user);

  const code = user?.referralDetails?.myReferralCode;
  const list = (user?.referralDetails?.referrals ?? []) as Referral[];
  const count = user?.referralDetails?.referralsCount ?? list.length;

  const share = () =>
    code &&
    Share.share({ message: `Join me on Munkai — rare digital literature & collectibles. Use my code ${code} when you sign up.` }).catch(
      () => {},
    );
  const copy = async () => {
    if (!code) return;
    await Clipboard.setStringAsync(code);
    toast.success('Code copied', 'Ready to paste.');
  };

  const header = (
    <View style={styles.headerBlock}>
      <CutShape cuts={t.cuts.card} fill={withAlpha(t.colors.primary, 0.06)} stroke={withAlpha(t.colors.primary, 0.14)} style={styles.codeCard}>
        <View style={styles.flex}>
          <Text variant="caption">Divine code</Text>
          <Text style={styles.code} selectable>
            {code ?? '—'}
          </Text>
        </View>
        <Pressable onPress={copy} accessibilityRole="button" accessibilityLabel="Copy referral code" style={styles.copyBtn}>
          <Copy size={18} color={t.colors.primary} strokeWidth={2} />
        </Pressable>
        <Pressable onPress={share} accessibilityRole="button" accessibilityLabel="Share referral code" style={styles.shareBtn}>
          <ShareIcon size={16} color={t.colors.onPrimary} strokeWidth={2.2} />
          <Text variant="label" color={t.colors.onPrimary}>
            Share
          </Text>
        </Pressable>
      </CutShape>
      <Text variant="bodySmall" color="mutedForeground" style={styles.hint}>
        Friends who join with your code appear here.
      </Text>
      {list.length > 0 ? (
        <Text variant="caption" color="primary" style={styles.sectionTitle}>
          Manifested connections
        </Text>
      ) : null}
    </View>
  );

  return (
    <View style={styles.root}>
      <View style={[styles.topBar, { paddingTop: insets.top + 4 }]}>
        <Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Back" hitSlop={6} style={styles.back}>
          <ChevronLeft size={26} color={t.colors.foreground} strokeWidth={2} />
        </Pressable>
        <Text variant="heading" style={styles.title}>
          Your referrals
        </Text>
        <View style={[styles.pill, { backgroundColor: withAlpha(t.colors.primary, 0.14) }]}>
          <Text variant="subtitle" color="primary" style={styles.pillText}>
            {count}
          </Text>
        </View>
      </View>

      <FlatList
        data={list}
        keyExtractor={(item, i) => item.username ?? String(i)}
        ListHeaderComponent={header}
        contentContainerStyle={[styles.listContent, { paddingBottom: insets.bottom + 24 }]}
        renderItem={({ item, index }) => (
          <View
            style={[
              styles.row,
              index === 0 && styles.rowFirst,
              index === list.length - 1 && styles.rowLast,
              index > 0 && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
            ]}
          >
            <Avatar uri={item.profileImage} firstName={item.firstName} lastName={item.lastName} seed={item.username} size={40} />
            <View style={styles.flex}>
              <Text variant="subtitle" numberOfLines={1} style={styles.rowName}>
                {item.firstName} {item.lastName}
              </Text>
              <Text variant="bodySmall" color="primary" style={styles.handle}>
                @{item.username}
              </Text>
            </View>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <View style={[styles.emptyIcon, { borderColor: withAlpha(t.colors.primary, 0.3) }]}>
              <Users size={22} color={withAlpha(t.colors.primary, 0.6)} strokeWidth={2} />
            </View>
            <Text variant="heading" align="center" style={styles.emptyTitle}>
              No connections detected
            </Text>
            <Text variant="bodySmall" color="mutedForeground" align="center">
              Share your divine code to expand the nexus.
            </Text>
            <Button title="Share code" variant="outline" onPress={share} style={styles.emptyBtn} />
          </View>
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const makeStyles = (t: Theme) => {
  const groupBg = t.isDark ? withAlpha(t.colors.card, 0.9) : withAlpha(t.colors.background, 0.8);
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    topBar: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 4,
      paddingHorizontal: 8,
      paddingBottom: 10,
      borderBottomWidth: 1,
      borderBottomColor: withAlpha(t.colors.primary, 0.1),
    },
    back: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
    title: { flex: 1, fontSize: 20 },
    pill: { marginRight: 12, paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999 },
    pillText: { fontSize: 13, lineHeight: 18 },
    listContent: { paddingHorizontal: 20 },
    headerBlock: { paddingTop: 16 },
    codeCard: { padding: 14, paddingLeft: 16, flexDirection: 'row', alignItems: 'center', gap: 10 },
    code: { fontFamily: t.fonts.displayBold, fontSize: 20, lineHeight: 26, letterSpacing: 3, color: t.colors.primary },
    copyBtn: {
      width: 44,
      height: 44,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.3),
      alignItems: 'center',
      justifyContent: 'center',
    },
    shareBtn: { height: 44, paddingHorizontal: 14, backgroundColor: t.colors.primary, flexDirection: 'row', alignItems: 'center', gap: 6 },
    hint: { marginTop: 10, marginHorizontal: 2 },
    sectionTitle: { letterSpacing: 1.6, fontSize: 11, marginTop: 22, marginBottom: 8 },
    row: {
      minHeight: 64,
      paddingHorizontal: 16,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      backgroundColor: groupBg,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
    },
    rowFirst: { borderTopWidth: 1, borderTopLeftRadius: 14, borderTopRightRadius: 14 },
    rowLast: { borderBottomWidth: 1, borderBottomLeftRadius: 14, borderBottomRightRadius: 14 },
    rowName: { fontSize: 15 },
    handle: { fontFamily: t.fonts.bodyBold, fontSize: 12, lineHeight: 16 },
    empty: { alignItems: 'center', gap: 10, paddingTop: 48, paddingHorizontal: 24 },
    emptyIcon: {
      width: 52,
      height: 52,
      borderRadius: 26,
      borderWidth: 2,
      borderStyle: 'dashed',
      alignItems: 'center',
      justifyContent: 'center',
    },
    emptyTitle: { fontSize: 20 },
    emptyBtn: { marginTop: 6, alignSelf: 'center' },
  });
};
