/**
 * Downloaded chapters of one publication (Downloads → tap a publication). Works offline:
 * everything comes from the on-device index (store/offline). Tap a chapter to read it, bin to remove it,
 * "Remove all" at the bottom. "View publication" only shows while online.
 */
import { router, useLocalSearchParams } from 'expo-router';
import { ArrowDownToLine, Trash2 } from 'lucide-react-native';
import React, { useEffect } from 'react';
import { FlatList, Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Cover } from '@/components/content/Cover';
import { StackHeader } from '@/components/navigation/StackHeader';
import { confirmRemovePublication, DownloadChapterRow, useDownloadGroups } from '@/components/offline/Downloads';
import { Button, Text } from '@/components/ui';
import { formatSize } from '@/lib/pickers';
import { useIsOffline } from '@/lib/network';
import { typeLabel } from '@/lib/publication';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

export default function DownloadedPublication() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const offline = useIsOffline();
  const { id } = useLocalSearchParams<{ id: string }>();
  const group = useDownloadGroups().find((g) => String(g.pub.id) === String(id));

  // Everything removed (here or elsewhere) → nothing left to show.
  useEffect(() => {
    if (!group) router.canGoBack() ? router.back() : router.replace('/downloads');
  }, [group]);
  if (!group) return <View style={styles.root} />;

  const n = group.chapters.length;
  const back = () => (router.canGoBack() ? router.back() : router.replace('/downloads'));

  const header = (
    <View style={styles.hero}>
      <Cover uri={group.pub.coverPhoto} width={84} height={118} />
      <View style={styles.flex}>
        <Text variant="heading" numberOfLines={2} style={styles.name}>
          {group.pub.name}
        </Text>
        <Text variant="bodySmall" color="mutedForeground" style={styles.meta}>
          {[typeLabel(group.pub.publicationType), `${n} chapter${n === 1 ? '' : 's'} downloaded`].filter(Boolean).join(' · ')}
        </Text>
        <View style={styles.inline}>
          <ArrowDownToLine size={13} color={t.colors.primary} strokeWidth={2.4} />
          <Text variant="subtitle" color="primary" style={styles.meta}>
            Available offline · {formatSize(group.bytes)}
          </Text>
        </View>
        {offline ? null : (
          <Button
            title="View publication"
            variant="outline"
            size="sm"
            onPress={() => router.push({ pathname: '/publication/[id]', params: { id: group.pub.id } })}
            style={styles.view}
          />
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.root}>
      <StackHeader title="Downloaded" onBack={back} />
      <FlatList
        data={group.chapters}
        keyExtractor={(c) => String(c.chapterId)}
        ListHeaderComponent={header}
        renderItem={({ item, index }) => <DownloadChapterRow chapter={item} last={index === n - 1} />}
        ListFooterComponent={
          <Pressable
            onPress={() => confirmRemovePublication(group)}
            accessibilityRole="button"
            style={({ pressed }) => [styles.removeAll, pressed && { opacity: 0.7 }]}
          >
            <Trash2 size={16} color={t.colors.destructive} />
            <Text variant="subtitle" style={[styles.removeText, { color: t.colors.destructive }]}>
              Remove all {n} download{n === 1 ? '' : 's'}
            </Text>
          </Pressable>
        }
        contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    hero: {
      flexDirection: 'row',
      gap: 16,
      padding: 20,
      marginBottom: 6,
      borderBottomWidth: 1,
      borderBottomColor: withAlpha(t.colors.primary, 0.08),
    },
    name: { fontSize: 20, lineHeight: 26 },
    meta: { fontSize: 13, lineHeight: 18, marginTop: 4 },
    inline: { flexDirection: 'row', alignItems: 'center', gap: 5 },
    view: { alignSelf: 'flex-start', marginTop: 12 },
    removeAll: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, minHeight: 52, marginTop: 16 },
    removeText: { fontSize: 14 },
  });
