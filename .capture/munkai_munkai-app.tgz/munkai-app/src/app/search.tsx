/**
 * Search — approved mocks "Search · focused, empty" and "Search · results".
 * Opens from Explore / Home with a fade, keyboard up (X/Twitter-style). The web has no
 * search endpoint — it filters the catalogue — so we search every publication + top creators.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import { ChevronRight, Clock, Search as SearchIcon, X } from 'lucide-react-native';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FlatList, Keyboard, Pressable, StyleSheet, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Cover } from '@/components/content/Cover';
import { Avatar, Skeleton, SkeletonGroup, Text } from '@/components/ui';
import { genres, openCreator, openPublication, typeLabel } from '@/lib/publication';
import { QK } from '@/lib/queryKeys';
import { useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import type { Publication, TopCreator } from '@/services/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const RECENT_KEY = 'munkai_recent_searches';
type Tab = 'top' | 'publications' | 'creators';
type Row = { kind: 'header'; title: string } | { kind: 'pub'; pub: Publication } | { kind: 'creator'; c: TopCreator };

export default function Search() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const [q, setQ] = useState('');
  const [tab, setTab] = useState<Tab>('top');
  const [recent, setRecent] = useState<string[]>([]);
  const input = useRef<TextInput>(null);

  const pubs = useFetch(QK.searchPublications, contentApi.allPublications);
  const creators = useFetch(QK.searchCreators, contentApi.topCreators);

  useEffect(() => {
    AsyncStorage.getItem(RECENT_KEY)
      .then((r) => setRecent(r ? JSON.parse(r) : []))
      .catch(() => {});
  }, []);

  const remember = (term: string) => {
    const v = term.trim();
    if (!v) return;
    const next = [v, ...recent.filter((r) => r.toLowerCase() !== v.toLowerCase())].slice(0, 8);
    setRecent(next);
    AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch(() => {});
  };
  const forget = (term?: string) => {
    const next = term ? recent.filter((r) => r !== term) : [];
    setRecent(next);
    AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch(() => {});
  };

  const term = q.trim().toLowerCase().replace(/^@/, '');
  const pubHits = useMemo(() => {
    if (!term) return [];
    const score = (p: Publication) => {
      const n = (p.name ?? '').toLowerCase();
      if (n.startsWith(term)) return 0;
      if (n.includes(term)) return 1;
      if (genres(p).some((g) => g.toLowerCase().includes(term))) return 2;
      if ((p.username ?? '').toLowerCase().includes(term)) return 3;
      return 9;
    };
    return (pubs.data ?? [])
      .map((p) => [score(p), p] as const)
      .filter(([s]) => s < 9)
      .sort((a, b) => a[0] - b[0])
      .map(([, p]) => p);
  }, [pubs.data, term]);
  const creatorHits = useMemo(
    () =>
      term
        ? (creators.data ?? []).filter((c) => `${c.firstName} ${c.lastName} ${c.username}`.toLowerCase().includes(term))
        : [],
    [creators.data, term],
  );

  const topGenres = useMemo(() => {
    const count = new Map<string, number>();
    for (const p of pubs.data ?? []) for (const g of genres(p)) count.set(g, (count.get(g) ?? 0) + 1);
    return [...count.entries()].sort((a, b) => b[1] - a[1]).slice(0, 10).map(([g]) => g);
  }, [pubs.data]);

  const rows: Row[] = useMemo(() => {
    if (tab === 'publications') return pubHits.map((pub) => ({ kind: 'pub', pub }));
    if (tab === 'creators') return creatorHits.map((c) => ({ kind: 'creator', c }));
    const out: Row[] = [];
    if (creatorHits.length) {
      out.push({ kind: 'header', title: 'Creators' });
      creatorHits.slice(0, 3).forEach((c) => out.push({ kind: 'creator', c }));
    }
    if (pubHits.length) {
      out.push({ kind: 'header', title: 'Publications' });
      pubHits.slice(0, 20).forEach((pub) => out.push({ kind: 'pub', pub }));
    }
    return out;
  }, [tab, pubHits, creatorHits]);

  const loading = (pubs.loading || creators.loading) && !!term;

  const cancel = () => {
    Keyboard.dismiss();
    router.back();
  };

  return (
    <View style={[styles.root, { paddingTop: insets.top + 6 }]}>
      <View style={styles.bar}>
        <View style={[styles.field, { borderColor: t.colors.primary }]}>
          <SearchIcon size={18} color={t.colors.mutedForeground} />
          <TextInput
            ref={input}
            value={q}
            onChangeText={setQ}
            autoFocus
            placeholder="Titles, genres, creators"
            placeholderTextColor={t.colors.mutedForeground}
            selectionColor={t.colors.primary}
            returnKeyType="search"
            autoCorrect={false}
            autoCapitalize="none"
            onSubmitEditing={() => remember(q)}
            style={[styles.input, { color: t.colors.foreground, fontFamily: t.fonts.body }]}
            accessibilityLabel="Search"
          />
          {q ? (
            <Pressable onPress={() => setQ('')} hitSlop={10} accessibilityLabel="Clear search" style={[styles.clear, { backgroundColor: withAlpha(t.colors.foreground, 0.25) }]}>
              <X size={12} color={t.colors.pageBackground} strokeWidth={3} />
            </Pressable>
          ) : null}
        </View>
        <Pressable onPress={cancel} hitSlop={8} accessibilityRole="button">
          <Text variant="subtitle" color="primary" style={styles.cancel}>
            Cancel
          </Text>
        </Pressable>
      </View>

      {!term ? (
        <FlatList
          data={[]}
          renderItem={null}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          ListHeaderComponent={
            <View>
              {recent.length ? (
                <>
                  <View style={styles.headRow}>
                    <Text variant="heading" style={styles.headTitle}>
                      Recent
                    </Text>
                    <Pressable onPress={() => forget()} hitSlop={10}>
                      <Text variant="subtitle" color="primary" style={styles.clearAll}>
                        Clear
                      </Text>
                    </Pressable>
                  </View>
                  {recent.map((r) => (
                    <Pressable key={r} onPress={() => setQ(r)} style={styles.recent} accessibilityRole="button">
                      <Clock size={18} color={t.colors.mutedForeground} />
                      <Text variant="body" style={styles.flex}>
                        {r}
                      </Text>
                      <Pressable onPress={() => forget(r)} hitSlop={10} accessibilityLabel={`Remove ${r}`}>
                        <X size={16} color={t.colors.mutedForeground} />
                      </Pressable>
                    </Pressable>
                  ))}
                </>
              ) : null}
              <View style={styles.headRow}>
                <Text variant="heading" style={styles.headTitle}>
                  Browse genres
                </Text>
              </View>
              {pubs.loading ? (
                <SkeletonGroup>
                  <View style={styles.genres}>
                    {[70, 84, 60, 76, 66, 90].map((w, i) => (
                      <Skeleton key={i} width={w} height={36} />
                    ))}
                  </View>
                </SkeletonGroup>
              ) : (
                <View style={styles.genres}>
                  {topGenres.map((g) => (
                    <Pressable key={g} onPress={() => setQ(g)} accessibilityRole="button" style={[styles.genre, { borderColor: withAlpha(t.colors.primary, 0.25) }]}>
                      <Text variant="subtitle" style={styles.genreText}>
                        {g}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              )}
            </View>
          }
        />
      ) : (
        <>
          <View style={[styles.tabs, { borderBottomColor: withAlpha(t.colors.primary, 0.1) }]} accessibilityRole="tablist">
            {(
              [
                ['top', 'Top'],
                ['publications', `Publications${pubHits.length ? ` ${pubHits.length}` : ''}`],
                ['creators', `Creators${creatorHits.length ? ` ${creatorHits.length}` : ''}`],
              ] as const
            ).map(([k, label]) => {
              const on = tab === k;
              return (
                <Pressable key={k} onPress={() => setTab(k)} accessibilityRole="tab" accessibilityState={{ selected: on }} style={[styles.tab, on && { borderBottomColor: t.colors.primary }]}>
                  <Text variant="subtitle" color={on ? 'foreground' : 'mutedForeground'} style={styles.tabText}>
                    {label}
                  </Text>
                </Pressable>
              );
            })}
          </View>
          {loading ? (
            <SkeletonGroup>
              {[0, 1, 2, 3].map((i) => (
                <View key={i} style={styles.pubRow}>
                  <Skeleton width={50} height={70} />
                  <View style={{ flex: 1, gap: 6 }}>
                    <Skeleton width="60%" height={13} radius={3} />
                    <Skeleton width="40%" height={10} radius={3} />
                  </View>
                </View>
              ))}
            </SkeletonGroup>
          ) : (
            <FlatList
              data={rows}
              keyExtractor={(r, i) => (r.kind === 'pub' ? `p${r.pub.id}` : r.kind === 'creator' ? `c${r.c.id}` : `h${i}`)}
              keyboardShouldPersistTaps="handled"
              keyboardDismissMode="on-drag"
              contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
              renderItem={({ item }) => {
                if (item.kind === 'header')
                  return (
                    <Text variant="caption" color="mutedForeground" style={styles.sectionHead}>
                      {item.title}
                    </Text>
                  );
                if (item.kind === 'creator')
                  return (
                    <Pressable
                      onPress={() => {
                        remember(q);
                        openCreator(item.c);
                      }}
                      accessibilityRole="button"
                      style={({ pressed }) => [styles.creatorRow, pressed && { backgroundColor: t.colors.hover }]}
                    >
                      <Avatar uri={item.c.profileImage} firstName={item.c.firstName} lastName={item.c.lastName} seed={item.c.username} size={44} />
                      <View style={styles.flex}>
                        <Highlight text={`${item.c.firstName} ${item.c.lastName}`.trim() || item.c.username} term={term} style={styles.name} />
                        <Text variant="bodySmall" color="mutedForeground" style={styles.sub}>
                          @{item.c.username}
                          {item.c.totalPublications != null ? ` · ${item.c.totalPublications} works` : ''}
                        </Text>
                      </View>
                      <ChevronRight size={18} color={t.colors.mutedForeground} />
                    </Pressable>
                  );
                const p = item.pub;
                return (
                  <Pressable
                    onPress={() => {
                      remember(q);
                      openPublication(p);
                    }}
                    accessibilityRole="button"
                    style={({ pressed }) => [styles.pubRow, pressed && { backgroundColor: t.colors.hover }]}
                  >
                    <Cover uri={p.coverPhoto} width={50} height={70} />
                    <View style={styles.flex}>
                      <Highlight text={p.name} term={term} style={styles.name} />
                      <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.sub}>
                        {[typeLabel(p.publicationType), p.username ? `@${p.username}` : null].filter(Boolean).join(' · ')}
                      </Text>
                      <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={[styles.sub, { opacity: 0.7 }]}>
                        {[p.totalChapters != null ? `${p.totalChapters} chapters` : null, genres(p).slice(0, 2).join(', ')].filter(Boolean).join(' · ')}
                      </Text>
                    </View>
                  </Pressable>
                );
              }}
              ListEmptyComponent={
                <View style={styles.empty}>
                  <Text variant="heading" align="center">
                    No results for “{q.trim()}”
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" align="center">
                    Try a different title, genre or @creator.
                  </Text>
                </View>
              }
            />
          )}
        </>
      )}
    </View>
  );
}

/** Bold-blue the matching part of a title. */
function Highlight({ text, term, style }: { text: string; term: string; style: object }) {
  const t = useTheme();
  const i = text.toLowerCase().indexOf(term);
  if (!term || i < 0) {
    return (
      <Text variant="subtitle" numberOfLines={1} style={style}>
        {text}
      </Text>
    );
  }
  return (
    <Text variant="subtitle" numberOfLines={1} style={style}>
      {text.slice(0, i)}
      <Text variant="subtitle" style={[style, { color: t.colors.primary }]}>
        {text.slice(i, i + term.length)}
      </Text>
      {text.slice(i + term.length)}
    </Text>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1, minWidth: 0 },
    bar: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingBottom: 10 },
    field: {
      flex: 1,
      height: 44,
      borderRadius: t.radius.search,
      borderWidth: 1.5,
      paddingHorizontal: 12,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: t.colors.inputBackground,
    },
    input: { flex: 1, height: '100%', fontSize: 15, paddingVertical: 0 },
    clear: { width: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
    cancel: { fontSize: 15 },
    headRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 20, paddingBottom: 8 },
    headTitle: { flex: 1, fontSize: 18 },
    clearAll: { fontSize: 13 },
    recent: { height: 46, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20 },
    genres: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 20 },
    genre: { height: 36, paddingHorizontal: 14, borderWidth: 1, justifyContent: 'center' },
    genreText: { fontSize: 13 },
    tabs: { flexDirection: 'row', gap: 22, paddingHorizontal: 20, borderBottomWidth: 1 },
    tab: { paddingVertical: 12, borderBottomWidth: 3, borderBottomColor: 'transparent' },
    tabText: { fontSize: 14 },
    sectionHead: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 8 },
    creatorRow: { minHeight: 64, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20 },
    pubRow: { minHeight: 86, flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingVertical: 8 },
    name: { fontSize: 15, lineHeight: 20 },
    sub: { fontSize: 12, lineHeight: 16, marginTop: 2 },
    empty: { alignItems: 'center', gap: 8, paddingTop: 48, paddingHorizontal: 32 },
  });
