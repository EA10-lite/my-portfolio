/**
 * Transaction history (web: app/auth/payments/history) — Payments and Transfers tabs.
 */
import React, { useState } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { Button, SkeletonGroup, Text } from '@/components/ui';
import { ActivityRow, ActivityRowSkeleton } from '@/components/wallet/ActivityRow';
import { apiErrorMessage } from '@/lib/api';
import { QK } from '@/lib/queryKeys';
import { useFetch } from '@/lib/useFetch';
import { paymentsApi } from '@/services/payments';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

type Tab = 'payments' | 'transfers';

export default function WalletHistory() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<Tab>('payments');
  const payments = useFetch(QK.paymentHistory, paymentsApi.history);
  const transfers = useFetch(QK.transfers, paymentsApi.transfers);
  const q = tab === 'payments' ? payments : transfers;
  const data = [...(q.data ?? [])].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <View style={styles.root}>
      <StackHeader title="Transaction history" />
      <View style={[styles.segment, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]} accessibilityRole="tablist">
        {(['payments', 'transfers'] as const).map((k) => {
          const on = k === tab;
          return (
            <Pressable
              key={k}
              onPress={() => setTab(k)}
              accessibilityRole="tab"
              accessibilityState={{ selected: on }}
              style={[styles.segItem, on && { backgroundColor: t.colors.primary }]}
            >
              <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.segText}>
                {k === 'payments' ? 'Deposits & withdrawals' : 'Transfers'}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <FlatList
        data={q.loading ? [] : data}
        keyExtractor={(a) => a.id}
        renderItem={({ item, index }) => <ActivityRow item={item} divider={index > 0} />}
        style={styles.list}
        contentContainerStyle={[styles.listContent, { paddingBottom: insets.bottom + 24 }]}
        ListEmptyComponent={
          q.loading ? (
            <SkeletonGroup>
              {Array.from({ length: 6 }, (_, i) => (
                <ActivityRowSkeleton key={i} divider={i > 0} />
              ))}
            </SkeletonGroup>
          ) : q.error ? (
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                {apiErrorMessage(q.error)}
              </Text>
              <Button title="Try again" variant="outline" onPress={q.refetch} />
            </View>
          ) : (
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                {tab === 'payments' ? 'No deposits or withdrawals yet.' : 'No transfers yet.'}
              </Text>
            </View>
          )
        }
        refreshControl={<RefreshControl refreshing={q.refreshing} onRefresh={q.refetch} tintColor={t.colors.primary} colors={[t.colors.primary]} />}
      />
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    segment: { marginHorizontal: 20, marginTop: 14, height: 40, padding: 3, borderRadius: 20, flexDirection: 'row' },
    segItem: { flex: 1, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
    segText: { fontSize: 13, lineHeight: 18 },
    list: { marginTop: 14 },
    listContent: { marginHorizontal: 20 },
    empty: { alignItems: 'center', gap: 12, paddingTop: 40, paddingHorizontal: 24 },
  });
