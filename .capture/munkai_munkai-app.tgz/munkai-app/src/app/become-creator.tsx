/**
 * Become a creator — approved mocks "Become a creator · Apply / In review / Not approved".
 * GET /api/creators/requests (status) → POST /api/creators/apply (multipart). Web: auth/become-a-creator.
 */
import { router, useFocusEffect } from 'expo-router';
import { FileText, Hourglass, Link2, Sparkles, X } from 'lucide-react-native';
import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { Checkbox, FieldLabel } from '@/components/studio/parts';
import { Button, CutShape, Input, Skeleton, SkeletonGroup, Text, useToast, KeyboardAvoid } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatSize, MB, pickPdf } from '@/lib/pickers';
import { useFetch } from '@/lib/useFetch';
import { creatorApi, isCreatorRole, type UploadFile } from '@/services/creator';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

// Web become-a-creator.tsx URL rule.
const URL_RE = /^(https?:\/\/)?(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)$/;
const FIELDS = [
  { key: 'twitterUrl', label: 'X (Twitter)', placeholder: 'x.com/yourname' },
  { key: 'linkedinUrl', label: 'LinkedIn', placeholder: 'linkedin.com/in/yourname' },
  { key: 'telegramUrl', label: 'Telegram', placeholder: 't.me/yourname' },
  { key: 'portfolioUrl', label: 'Portfolio', placeholder: 'Your website or portfolio link' },
] as const;
type Key = (typeof FIELDS)[number]['key'];

export default function BecomeCreator() {
  const styles = useThemedStyles(makeStyles);
  const user = useSession((s) => s.user);
  const q = useFetch('creator/request', creatorApi.request);
  useFocusEffect(
    useCallback(() => {
      q.reload();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  if (user && isCreatorRole(user.role)) {
    return (
      <State
        icon={Sparkles}
        tone="primary"
        title="You’re a creator"
        text="Your studio is ready. Publish your first story or add chapters to your work."
        action={<Button title="Open Creator Studio" fullWidth onPress={() => router.replace('/studio')} />}
      />
    );
  }

  if (q.loading && !q.data) {
    return (
      <View style={styles.root}>
        <StackHeader title="Become a creator" />
        <SkeletonGroup>
          <View style={styles.pad}>
            <Skeleton width="100%" height={130} />
            <Skeleton width="100%" height={52} />
            <Skeleton width="100%" height={52} />
            <Skeleton width="100%" height={52} />
          </View>
        </SkeletonGroup>
      </View>
    );
  }

  const req = q.data;
  const status = (req?.status ?? '').toLowerCase();
  if (status === 'pending') {
    return (
      <State
        icon={Hourglass}
        tone="primary"
        title="Application in review"
        text="We’re checking your links and ID. You’ll get a notification the moment you’re approved."
        extra={
          req?.createdAt ? (
            <Text variant="subtitle" color="primary" style={styles.pill}>
              Submitted {new Date(req.createdAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}
            </Text>
          ) : null
        }
        action={<Button title="Back to profile" variant="outline" fullWidth onPress={() => router.back()} />}
      />
    );
  }
  if (status === 'rejected' && req?.nextRequestTime && new Date(req.nextRequestTime).getTime() > Date.now()) {
    return <Rejected reason={req.reasonRejected} until={new Date(req.nextRequestTime)} onElapsed={q.refetch} />;
  }
  return <ApplyForm onDone={q.refetch} />;
}

function ApplyForm({ onDone }: { onDone: () => void }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const refreshProfile = useSession((s) => s.refreshProfile);
  const [vals, setVals] = useState<Record<Key, string>>({ twitterUrl: '', linkedinUrl: '', telegramUrl: '', portfolioUrl: '' });
  const [errors, setErrors] = useState<Partial<Record<Key | 'validId', string>>>({});
  const [file, setFile] = useState<UploadFile | null>(null);
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);

  const choose = async () => {
    const f = await pickPdf().catch(() => null);
    if (!f) return;
    if (!/pdf/i.test(f.type) && !f.name.toLowerCase().endsWith('.pdf')) {
      setErrors((e) => ({ ...e, validId: 'Upload your ID as a PDF.' }));
      return;
    }
    if (f.size && f.size > 5 * MB) {
      setErrors((e) => ({ ...e, validId: `That file is ${formatSize(f.size)} — the limit is 5 MB.` }));
      return;
    }
    setFile(f);
    setErrors((e) => ({ ...e, validId: undefined }));
  };

  const submit = async () => {
    const e: typeof errors = {};
    FIELDS.forEach(({ key, label }) => {
      const v = vals[key].trim();
      if (!v) e[key] = `Add your ${label} link.`;
      else if (!URL_RE.test(v)) e[key] = 'That doesn’t look like a link.';
    });
    if (!file) e.validId = 'Upload a valid ID (PDF).';
    setErrors(e);
    if (Object.values(e).some(Boolean)) {
      haptic.error().catch(() => {});
      return;
    }
    setBusy(true);
    try {
      await creatorApi.apply({ ...vals, validId: file! });
      haptic.success().catch(() => {});
      toast.success('Application sent', 'We’ll let you know when it’s reviewed.');
      refreshProfile().catch(() => {});
      onDone();
    } catch (err) {
      toast.error('Couldn’t send your application', apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.root}>
      <StackHeader title="Become a creator" />
      <KeyboardAvoid>
        <ScrollView contentContainerStyle={styles.pad} keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive">
          <CutShape cuts={t.cuts.card} fill={t.colors.card} stroke={withAlpha(t.colors.primary, 0.18)} style={styles.hero}>
            <Sparkles size={26} color={t.colors.primary} />
            <Text variant="title" style={styles.heroTitle}>
              Publish your stories. Get paid by readers.
            </Text>
            <Text variant="bodySmall" color="mutedForeground" style={styles.heroText}>
              Tell us where people can find your work. We review applications within a few days.
            </Text>
          </CutShape>

          {FIELDS.map(({ key, label, placeholder }) => (
            <Input
              key={key}
              label={label}
              value={vals[key]}
              onChangeText={(v) => {
                setVals((s) => ({ ...s, [key]: v }));
                if (errors[key]) setErrors((x) => ({ ...x, [key]: undefined }));
              }}
              placeholder={placeholder}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="url"
              error={errors[key]}
              rightAccessory={<Link2 size={18} color={t.colors.mutedForeground} />}
            />
          ))}

          <View style={styles.block}>
            <FieldLabel>Valid ID</FieldLabel>
            {file ? (
              <View style={[styles.file, { borderColor: 'rgba(34,197,94,0.4)', backgroundColor: t.colors.card }]}>
                <FileText size={22} color="#22C55E" />
                <View style={styles.flex}>
                  <Text variant="subtitle" numberOfLines={1}>
                    {file.name}
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
                    {[formatSize(file.size), 'PDF'].filter(Boolean).join(' · ')}
                  </Text>
                </View>
                <Pressable onPress={choose} hitSlop={8} accessibilityRole="button">
                  <Text variant="subtitle" color="primary" style={styles.small}>
                    Change
                  </Text>
                </Pressable>
                <Pressable onPress={() => setFile(null)} hitSlop={8} accessibilityRole="button" accessibilityLabel="Remove file">
                  <X size={16} color={t.colors.mutedForeground} />
                </Pressable>
              </View>
            ) : (
              <Pressable
                onPress={choose}
                accessibilityRole="button"
                style={({ pressed }) => [
                  styles.drop,
                  { borderColor: errors.validId ? t.colors.destructive : withAlpha(t.colors.primary, 0.4) },
                  pressed && { opacity: 0.8 },
                ]}
              >
                <FileText size={24} color={t.colors.primary} />
                <Text variant="subtitle" color="primary">
                  Upload ID (PDF)
                </Text>
              </Pressable>
            )}
            <Text variant="bodySmall" color={errors.validId ? 'destructive' : 'mutedForeground'} style={styles.small}>
              {errors.validId ?? 'PDF only, up to 5 MB. Used only to verify you — never shown publicly.'}
            </Text>
          </View>

          <Checkbox checked={agree} onChange={setAgree}>
            <Text variant="bodySmall" color="mutedForeground" style={styles.terms}>
              I agree to the{' '}
              <Text
                variant="bodySmall"
                color="primary"
                style={styles.link}
                onPress={() => router.push({ pathname: '/legal', params: { doc: 'terms' } })}
              >
                Creator Terms
              </Text>{' '}
              and confirm the work I publish is mine or properly licensed.
            </Text>
          </Checkbox>
        </ScrollView>
        <View style={[styles.footer, { paddingBottom: insets.bottom + 14 }]}>
          <Button title="Submit application" fullWidth loading={busy} disabled={!agree} onPress={submit} />
        </View>
      </KeyboardAvoid>
    </View>
  );
}

function Rejected({ reason, until, onElapsed }: { reason?: string | null; until: Date; onElapsed: () => void }) {
  const styles = useThemedStyles(makeStyles);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const ms = Math.max(0, until.getTime() - now);
  useEffect(() => {
    if (ms === 0) onElapsed();
  }, [ms, onElapsed]);
  const parts = [
    [Math.floor(ms / 86400000), 'DAYS'],
    [Math.floor(ms / 3600000) % 24, 'HRS'],
    [Math.floor(ms / 60000) % 60, 'MIN'],
    [Math.floor(ms / 1000) % 60, 'SEC'],
  ] as const;
  return (
    <State
      icon={X}
      tone="danger"
      title="Not approved this time"
      text="You can apply again once the timer runs out."
      extra={
        <>
          {reason ? (
            <View style={styles.reason}>
              <Text style={styles.reasonLabel}>REASON</Text>
              <Text variant="bodySmall" style={styles.reasonText}>
                {reason}
              </Text>
            </View>
          ) : null}
          <View style={styles.countdown} accessibilityLabel={`Apply again in ${parts[0][0]} days ${parts[1][0]} hours`}>
            {parts.map(([v, l]) => (
              <View key={l} style={styles.unit}>
                <Text variant="display" style={styles.unitValue}>
                  {String(v).padStart(2, '0')}
                </Text>
                <Text style={styles.unitLabel}>{l}</Text>
              </View>
            ))}
          </View>
        </>
      }
      action={<Button title="Back to profile" variant="outline" fullWidth onPress={() => router.back()} />}
    />
  );
}

function State({
  icon: Icon,
  tone,
  title,
  text,
  extra,
  action,
}: {
  icon: typeof X;
  tone: 'primary' | 'danger';
  title: string;
  text: string;
  extra?: React.ReactNode;
  action: React.ReactNode;
}) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const color = tone === 'danger' ? '#FF4D6D' : t.colors.primary;
  return (
    <View style={styles.root}>
      <StackHeader title="Become a creator" />
      <ScrollView contentContainerStyle={styles.state}>
        <View style={[styles.stateIcon, { borderColor: withAlpha(color, 0.6) }]}>
          <Icon size={34} color={color} />
        </View>
        <Text variant="title" align="center" style={styles.stateTitle}>
          {title}
        </Text>
        <Text variant="body" color="mutedForeground" align="center">
          {text}
        </Text>
        {extra}
      </ScrollView>
      <View style={[styles.footer, { paddingBottom: insets.bottom + 14 }]}>{action}</View>
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    pad: { padding: 20, gap: 18, paddingBottom: 32 },
    hero: { padding: 18, gap: 8 },
    heroTitle: { fontSize: 22, lineHeight: 26 },
    heroText: { lineHeight: 19 },
    block: { gap: 8 },
    small: { fontSize: 12, lineHeight: 17 },
    file: { borderWidth: 1, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
    drop: { height: 96, borderWidth: 2, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', gap: 6 },
    terms: { lineHeight: 19 },
    link: { fontWeight: '700' },
    footer: {
      paddingHorizontal: 20,
      paddingTop: 12,
      borderTopWidth: 1,
      borderTopColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: t.colors.pageBackground,
    },
    state: { alignItems: 'center', gap: 14, paddingHorizontal: 28, paddingTop: 80, paddingBottom: 32 },
    stateIcon: {
      width: 84,
      height: 84,
      borderRadius: 42,
      borderWidth: 2,
      borderStyle: 'dashed',
      alignItems: 'center',
      justifyContent: 'center',
    },
    stateTitle: { fontSize: 28, lineHeight: 32, marginTop: 6 },
    pill: { marginTop: 6, paddingHorizontal: 12, paddingVertical: 6, fontSize: 12, backgroundColor: withAlpha(t.colors.primary, 0.1) },
    reason: {
      alignSelf: 'stretch',
      marginTop: 8,
      padding: 14,
      borderWidth: 1,
      borderColor: 'rgba(255,77,109,0.3)',
      backgroundColor: 'rgba(255,77,109,0.08)',
      gap: 4,
    },
    reasonLabel: { color: '#FF4D6D', fontSize: 11, fontWeight: '700', letterSpacing: 1.4 },
    reasonText: { lineHeight: 19 },
    countdown: { flexDirection: 'row', gap: 8, marginTop: 6 },
    unit: {
      width: 64,
      paddingVertical: 10,
      alignItems: 'center',
      backgroundColor: t.colors.card,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
    },
    unitValue: { fontSize: 22, lineHeight: 28 },
    unitLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1, color: t.colors.mutedForeground },
  });
