/**
 * Terms & privacy — approved mocks "Terms & privacy" + "Jump to section".
 * Web: app/privacy-policy (Terms of Service) and app/refund-policy, shown as two tabs.
 * Route: /legal?doc=terms|refund
 */
import { useLocalSearchParams } from 'expo-router';
import { ListOrdered } from 'lucide-react-native';
import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  FlatList,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  useWindowDimensions,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { HeaderIconButton, StackHeader } from '@/components/navigation/StackHeader';
import { CutShape, Sheet, Text } from '@/components/ui';
import { refund } from '@/content/refund';
import { terms } from '@/content/terms';
import type { LegalBlock, LegalDoc } from '@/content/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

const DOCS: Record<LegalDoc['id'], LegalDoc> = { terms, refund };
const TABS: { id: LegalDoc['id']; label: string }[] = [
  { id: 'terms', label: 'Terms of Service' },
  { id: 'refund', label: 'Refund policy' },
];

export default function Legal() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const params = useLocalSearchParams<{ doc?: string }>();

  const [docId, setDocId] = useState<LegalDoc['id']>(params.doc === 'refund' ? 'refund' : 'terms');
  const doc = DOCS[docId];
  const [sheetOpen, setSheetOpen] = useState(false);
  const [current, setCurrent] = useState(0);

  const scrollRef = useRef<ScrollView>(null);
  /** y offset of each top-level heading inside the scroll content, by heading index. */
  const offsets = useRef<number[]>([]);

  const headings = useMemo(
    () => doc.blocks.filter((b): b is Extract<LegalBlock, { type: 'heading' }> => b.type === 'heading').map((b) => b.text),
    [doc],
  );

  const switchDoc = (id: LegalDoc['id']) => {
    if (id === docId) return;
    haptic.select().catch(() => {});
    offsets.current = [];
    setCurrent(0);
    setDocId(id);
    scrollRef.current?.scrollTo({ y: 0, animated: false });
  };

  const jump = (i: number) => {
    setSheetOpen(false);
    const y = offsets.current[i];
    if (y !== undefined) scrollRef.current?.scrollTo({ y: Math.max(0, y - 12), animated: true });
  };

  const onScroll = useCallback((e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const y = e.nativeEvent.contentOffset.y + 80;
    const list = offsets.current;
    let idx = 0;
    for (let i = 0; i < list.length; i++) if (list[i] !== undefined && list[i] <= y) idx = i;
    setCurrent((c) => (c === idx ? c : idx));
  }, []);

  let headingIndex = -1;

  return (
    <View style={styles.root}>
      <StackHeader
        title="Terms & privacy"
        right={
          headings.length > 1 ? (
            <HeaderIconButton label="Jump to section" onPress={() => setSheetOpen(true)}>
              <ListOrdered size={22} color={t.colors.primary} strokeWidth={2} />
            </HeaderIconButton>
          ) : undefined
        }
      />

      <View style={styles.tabs} accessibilityRole="tablist">
        {TABS.map((tab) => {
          const on = tab.id === docId;
          return (
            <Pressable
              key={tab.id}
              onPress={() => switchDoc(tab.id)}
              accessibilityRole="tab"
              accessibilityState={{ selected: on }}
              style={[styles.tab, on ? styles.tabOn : styles.tabOff]}
            >
              <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.tabText}>
                {tab.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <ScrollView
        key={docId}
        ref={scrollRef}
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 40 }]}
        onScroll={onScroll}
        scrollEventThrottle={64}
        showsVerticalScrollIndicator
      >
        <View style={[styles.badge, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]}>
          <Text variant="caption" color="primary">
            {doc.badge}
          </Text>
        </View>
        <Text variant="title" style={styles.h1} accessibilityRole="header">
          {doc.title}
        </Text>
        <Text variant="body" color="mutedForeground" style={styles.lead}>
          {doc.lead}
        </Text>

        {doc.blocks.map((block, i) => {
          if (block.type === 'heading') {
            const idx = ++headingIndex;
            return (
              <Text
                key={i}
                variant="heading"
                style={styles.h2}
                accessibilityRole="header"
                onLayout={(e) => {
                  offsets.current[idx] = e.nativeEvent.layout.y;
                }}
              >
                {block.text}
              </Text>
            );
          }
          return <Block key={i} block={block} />;
        })}
      </ScrollView>

      <Sheet visible={sheetOpen} onClose={() => setSheetOpen(false)} title="Jump to section" height={Math.min(620, height * 0.75)}>
        <FlatList
          data={headings}
          keyExtractor={(h, i) => `${i}-${h}`}
          initialScrollIndex={current > 4 ? current - 2 : undefined}
          getItemLayout={(_, i) => ({ length: 49, offset: 49 * i, index: i })}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 12 }}
          renderItem={({ item, index }) => {
            const on = index === current;
            const m = item.match(/^(\d+)\.\s*(.*)$/);
            return (
              <Pressable
                onPress={() => jump(index)}
                accessibilityRole="button"
                style={({ pressed }) => [styles.secRow, pressed && { backgroundColor: t.colors.hover }]}
              >
                <Text variant="subtitle" color={on ? 'primary' : 'mutedForeground'} style={styles.secNum}>
                  {m ? m[1] : index + 1}
                </Text>
                <Text variant="body" color={on ? 'primary' : 'foreground'} numberOfLines={1} style={styles.secText}>
                  {m ? m[2] : item}
                </Text>
              </Pressable>
            );
          }}
        />
      </Sheet>
    </View>
  );
}

const EMAIL_SPLIT = /([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/g;

/** Paragraph text with email addresses turned into mailto links. */
function RichText({ text, color, style }: { text: string; color: 'mutedForeground' | 'foreground'; style?: object }) {
  const t = useTheme();
  const parts = text.split(EMAIL_SPLIT);
  return (
    <Text variant="body" color={color} style={style} selectable>
      {parts.map((p, i) =>
        i % 2 === 1 ? (
          <Text
            key={i}
            variant="body"
            color="primary"
            style={[style, { textDecorationLine: 'underline' }]}
            onPress={() => Linking.openURL(`mailto:${p}`).catch(() => {})}
            accessibilityRole="link"
          >
            {p}
          </Text>
        ) : (
          p
        ),
      )}
    </Text>
  );
}

function Block({ block }: { block: Exclude<LegalBlock, { type: 'heading' }> }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  switch (block.type) {
    case 'subheading':
      return (
        <Text variant="subtitle" style={styles.h3}>
          {block.text}
        </Text>
      );
    case 'paragraph':
      return (
        <RichText
          text={block.text}
          color={block.emphasis ? 'foreground' : 'mutedForeground'}
          style={block.emphasis ? styles.pEmph : styles.p}
        />
      );
    case 'bullets':
      return (
        <View style={styles.bullets}>
          {block.items.map((item, i) => (
            <View key={i} style={styles.bulletRow}>
              <View style={[styles.dot, { backgroundColor: t.colors.primary }]} />
              <RichText text={item} color="mutedForeground" style={[styles.p, styles.flex]} />
            </View>
          ))}
        </View>
      );
    case 'facts':
      return (
        <View style={styles.facts}>
          {block.items.map((f) => (
            <View key={f.label} style={styles.fact}>
              <Text variant="caption" color="primary">
                {f.label}
              </Text>
              <Text variant="heading" style={styles.factValue}>
                {f.value}
              </Text>
            </View>
          ))}
        </View>
      );
    case 'callout':
      return (
        <CutShape
          cuts={t.cuts.card}
          fill={withAlpha(t.colors.primary, 0.06)}
          stroke={withAlpha(t.colors.primary, 0.14)}
          style={styles.callout}
        >
          <Text variant="heading" style={styles.calloutTitle}>
            {block.title}
          </Text>
          <Text variant="bodySmall" color="mutedForeground">
            {block.text}
          </Text>
          {block.email ? (
            <Pressable onPress={() => Linking.openURL(`mailto:${block.email}`).catch(() => {})} accessibilityRole="link" hitSlop={6}>
              <Text variant="subtitle" color="primary">
                {block.email}
              </Text>
            </Pressable>
          ) : null}
          {block.note ? (
            <Text variant="bodySmall" color="mutedForeground" style={styles.note}>
              {block.note}
            </Text>
          ) : null}
        </CutShape>
      );
  }
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    tabs: {
      flexDirection: 'row',
      gap: 8,
      paddingHorizontal: 20,
      paddingTop: 12,
      paddingBottom: 12,
      borderBottomWidth: 1,
      borderBottomColor: withAlpha(t.colors.primary, 0.08),
    },
    tab: { height: 36, paddingHorizontal: 14, alignItems: 'center', justifyContent: 'center' },
    tabOn: { backgroundColor: t.colors.primary },
    tabOff: { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
    tabText: { fontSize: 12, lineHeight: 16, letterSpacing: 0.4 },
    scroll: { paddingHorizontal: 20, paddingTop: 16 },
    badge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
    h1: { fontSize: 26, lineHeight: 32, marginTop: 12 },
    lead: { marginTop: 8, marginBottom: 12, fontSize: 15, lineHeight: 23 },
    h2: { fontSize: 18, lineHeight: 24, marginTop: 26, marginBottom: 8 },
    h3: { fontSize: 15, lineHeight: 21, marginTop: 14, marginBottom: 6 },
    p: { fontSize: 15, lineHeight: 23, marginBottom: 10 },
    pEmph: { fontSize: 16, lineHeight: 24, marginTop: 20, marginBottom: 4, fontFamily: t.fonts.bodyMedium ?? t.fonts.body },
    bullets: { gap: 2, marginBottom: 6 },
    bulletRow: { flexDirection: 'row', gap: 10 },
    dot: { width: 5, height: 5, borderRadius: 3, marginTop: 10 },
    facts: { flexDirection: 'row', gap: 10, marginVertical: 8 },
    fact: {
      flex: 1,
      padding: 14,
      gap: 4,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.12),
      backgroundColor: withAlpha(t.colors.primary, 0.05),
    },
    factValue: { fontSize: 18, lineHeight: 24 },
    callout: { marginTop: 24, padding: 18, gap: 8 },
    calloutTitle: { fontSize: 18 },
    note: { fontSize: 12, lineHeight: 17 },
    secRow: {
      height: 49,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingHorizontal: 4,
      borderBottomWidth: 1,
      borderBottomColor: withAlpha(t.colors.primary, 0.08),
    },
    secNum: { width: 26, fontSize: 13 },
    secText: { flex: 1, fontSize: 15 },
  });
