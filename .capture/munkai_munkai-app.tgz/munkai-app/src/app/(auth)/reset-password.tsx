/**
 * Reset password — approved mocks "Reset password" + "Reset link expired".
 * Web (origin/main): components/forms/reset-password.tsx → POST /api/auth/password-reset/reset
 * { password, confirmPassword, code }. Opened from the emailed link (?code=…).
 */
import { router, useLocalSearchParams } from 'expo-router';
import { Clock } from 'lucide-react-native';
import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';

import { AuthLayout } from '@/components/auth/AuthLayout';
import { PasswordInput, Rule, StrengthMeter } from '@/components/auth/parts';
import { Button, Text, useToast } from '@/components/ui';
import { apiErrorMessage, apiErrorStatus } from '@/lib/api';
import { passwordChecks, rules } from '@/lib/validation';
import { authApi } from '@/services/auth';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

export default function ResetPassword() {
  const t = useTheme();
  const toast = useToast();
  const { code } = useLocalSearchParams<{ code?: string }>();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<{ password?: string; confirm?: string }>({});
  const [loading, setLoading] = useState(false);
  const [expired, setExpired] = useState(!code);
  const checks = passwordChecks(password);

  const submit = async () => {
    const next = { password: rules.password(password), confirm: rules.confirm(password, confirm) };
    setErrors(next);
    if (next.password || next.confirm) {
      haptic.error().catch(() => {});
      return;
    }
    setLoading(true);
    try {
      await authApi.resetPassword({ password, confirmPassword: confirm, code: String(code) });
      haptic.success().catch(() => {});
      toast.success('Password updated', 'Log in with your new password.');
      router.replace('/login');
    } catch (err) {
      const status = apiErrorStatus(err);
      const msg = apiErrorMessage(err, 'Failed to reset password');
      if (status === 400 || status === 404 || status === 410 || /expired|invalid|token|code/i.test(msg)) setExpired(true);
      else toast.error('Reset failed', msg);
    } finally {
      setLoading(false);
    }
  };

  if (expired) {
    return (
      <AuthLayout
        leading="close"
        onLeadingPress={() => router.replace('/login')}
        footer={
          <>
            <Button title="Send a new link" fullWidth onPress={() => router.replace('/forgot-password')} />
            <Button title="Back to login" variant="ghost" fullWidth onPress={() => router.replace('/login')} />
          </>
        }
      >
        <View style={styles.expired}>
          <View style={[styles.icon, { borderColor: withAlpha(t.colors.danger, 0.5) }]}>
            <Clock size={30} color={t.colors.danger} />
          </View>
          <Text variant="display" align="center" style={styles.title}>
            {code ? 'This link has expired' : 'Invalid reset link'}
          </Text>
          <Text variant="body" color="mutedForeground" align="center">
            Reset links work once and only for a short time. Request a new one and open it straight away.
          </Text>
        </View>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      leading="close"
      onLeadingPress={() => router.replace('/login')}
      eyebrow={
        <Text variant="label" color="primary">
          RESET PASSWORD
        </Text>
      }
      title="Choose a new password"
      caption="Use something you haven’t used here before"
      footer={<Button title={loading ? 'Saving…' : 'Reset password'} loading={loading} fullWidth onPress={submit} />}
    >
      <PasswordInput
        label="New password"
        value={password}
        onChangeText={(v) => {
          setPassword(v);
          if (errors.password) setErrors((e) => ({ ...e, password: undefined }));
        }}
        error={errors.password}
        textContentType="newPassword"
        autoComplete="new-password"
        autoFocus
      />
      <StrengthMeter password={password} />
      <View style={styles.rules}>
        <Rule ok={checks.length} label="8–15 characters" />
        <Rule ok={checks.upper} label="Uppercase letter" />
        <Rule ok={checks.number} label="Number" />
        <Rule ok={checks.symbol} label="Symbol" />
      </View>
      <PasswordInput
        label="Confirm password"
        value={confirm}
        onChangeText={(v) => {
          setConfirm(v);
          if (errors.confirm) setErrors((e) => ({ ...e, confirm: undefined }));
        }}
        error={errors.confirm}
        textContentType="newPassword"
        returnKeyType="done"
        onSubmitEditing={submit}
      />
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  rules: { flexDirection: 'row', flexWrap: 'wrap', rowGap: 6, columnGap: 14, marginTop: 4, marginBottom: 10 },
  expired: { alignItems: 'center', gap: 14, paddingTop: 60 },
  icon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    borderWidth: 2,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  title: { fontSize: 28, lineHeight: 32 },
});
