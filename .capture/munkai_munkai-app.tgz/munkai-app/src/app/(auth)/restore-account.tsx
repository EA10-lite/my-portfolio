/**
 * Restore account — shown when login returns 403 MIGRATION_REQUIRED.
 * Web: munkai-frontend/src/components/modals/accountMigration.tsx (same fields & endpoint),
 * presented as a full screen in the auth stack instead of a popup.
 */
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View } from 'react-native';

import { AuthLayout, useCloseAuth } from '@/components/auth/AuthLayout';
import { OtpInput, PasswordInput, StrengthMeter } from '@/components/auth/parts';
import { Button, Input, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { rules } from '@/lib/validation';
import { authApi } from '@/services/auth';
import { useSession } from '@/store/session';
import { haptic } from '@/lib/haptics';

type Errors = Partial<Record<'email' | 'code' | 'password' | 'confirm', string>>;

export default function RestoreAccount() {
  const params = useLocalSearchParams<{ identifier?: string; email?: string }>();
  const toast = useToast();
  const closeAuth = useCloseAuth();
  const signIn = useSession((s) => s.signIn);

  const identifier = params.identifier ?? '';
  const [email, setEmail] = useState(params.email ?? '');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<Errors>({});
  const [cooldown, setCooldown] = useState(0);
  const [codeSent, setCodeSent] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [saving, setSaving] = useState(false);
  const confirmRef = useRef<TextInput>(null);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(id);
  }, [cooldown]);

  const fail = (next: Errors) => {
    setErrors(next);
    haptic.error().catch(() => {});
  };

  const sendCode = async () => {
    if (rules.email(email)) return fail({ email: 'Please enter a valid email to receive the code' });
    setSending(true);
    try {
      await authApi.sendVerificationCode(email.trim());
      setCodeSent(email.trim());
      setCooldown(60);
      toast.success('Code sent!', 'Check your inbox and spam folder.');
    } catch (err) {
      toast.error('Code request failed', apiErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  const submit = async () => {
    const next: Errors = {
      email: rules.email(email),
      code: codeSent ? rules.code(code) : 'Tap "Send code" to get your verification code',
      password: password.length < 8 ? 'Password must be at least 8 characters' : undefined,
      confirm: rules.confirm(password, confirm),
    };
    if (Object.values(next).some(Boolean)) return fail(next);

    setSaving(true);
    try {
      const res = await authApi.migrate({
        emailOrUsername: identifier,
        newEmail: email.trim(),
        code,
        password,
        confirmPassword: confirm,
      });
      if (!res.data?.user) throw new Error('No user returned');
      await signIn(res.data.user, res.data.token);
      toast.success('Account restored', 'Your account has been verified and updated.');
      closeAuth();
    } catch (err) {
      toast.error('Restore failed', apiErrorMessage(err, 'An error occurred during account restoration'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <AuthLayout
      leading="back"
      title="Restore your account"
      caption={'Your account needs a quick update\nbefore you can sign in'}
      footer={<Button title={saving ? 'Synchronizing…' : 'Restore account'} loading={saving} fullWidth onPress={submit} />}
    >
      <View style={styles.form}>
        {identifier ? (
          <Text variant="bodySmall" color="mutedForeground">
            Signing in as{' '}
            <Text variant="bodySmall" color="primary" style={styles.bold}>
              {identifier}
            </Text>
          </Text>
        ) : null}

        <Input
          label="Email address"
          required
          placeholder="you@example.com"
          value={email}
          onChangeText={(v) => {
            setEmail(v);
            setErrors((e) => ({ ...e, email: undefined }));
            if (codeSent && v.trim() !== codeSent) {
              setCodeSent(null);
              setCode('');
              setCooldown(0);
            }
          }}
          error={errors.email}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
          textContentType="emailAddress"
          returnKeyType="send"
          onSubmitEditing={codeSent ? undefined : sendCode}
        />

        {!codeSent ? (
          <Button title={sending ? 'Sending…' : 'Send code'} loading={sending} fullWidth onPress={sendCode} />
        ) : (
          <View style={styles.group}>
            <Text variant="label">
              Verification code{' '}
              <Text variant="label" color="danger">
                *
              </Text>
            </Text>
            <OtpInput
              value={code}
              autoFocus
              onChange={(v) => {
                setCode(v);
                setErrors((e) => ({ ...e, code: undefined }));
              }}
              error={!!errors.code}
            />
            {errors.code ? (
              <Text variant="bodySmall" color="destructive">
                {errors.code}
              </Text>
            ) : null}
            <View style={styles.resendRow}>
              <Text variant="bodySmall" color="mutedForeground">
                Didn&apos;t get it?{' '}
              </Text>
              {cooldown > 0 ? (
                <Text variant="bodySmall" color="mutedForeground" style={styles.bold}>
                  Resend in {cooldown}s
                </Text>
              ) : (
                <Pressable onPress={sendCode} disabled={sending} hitSlop={10} accessibilityRole="button">
                  <Text variant="bodySmall" color="primary" style={styles.bold}>
                    {sending ? 'Sending…' : 'Resend code'}
                  </Text>
                </Pressable>
              )}
            </View>
          </View>
        )}

        <View style={styles.group}>
          <PasswordInput
            label="New access code"
            required
            placeholder="••••••••"
            value={password}
            onChangeText={(v) => {
              setPassword(v);
              setErrors((e) => ({ ...e, password: undefined }));
            }}
            error={errors.password}
            textContentType="newPassword"
            autoComplete="new-password"
            returnKeyType="next"
            onSubmitEditing={() => confirmRef.current?.focus()}
            submitBehavior="submit"
          />
          <StrengthMeter password={password} />
        </View>

        <PasswordInput
          ref={confirmRef}
          label="Confirm access"
          required
          placeholder="••••••••"
          value={confirm}
          onChangeText={(v) => {
            setConfirm(v);
            setErrors((e) => ({ ...e, confirm: undefined }));
          }}
          error={errors.confirm}
          textContentType="newPassword"
          returnKeyType="go"
          onSubmitEditing={submit}
        />
      </View>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  form: { gap: 20 },
  group: { gap: 10 },
  resendRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', minHeight: 32 },
  bold: { fontFamily: 'SpaceGrotesk-Bold' },
});
