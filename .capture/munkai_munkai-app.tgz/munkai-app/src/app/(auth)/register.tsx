/**
 * Register — approved mock "Register · 1 / 2 / 3".
 * Web: munkai-frontend/src/components/forms/signUp.tsx, split into three short steps.
 * One route holds all state so moving between steps never loses input;
 * back (header or Android hardware back) goes to the previous step.
 */
import { router, useFocusEffect } from 'expo-router';
import { CircleCheck, Mail, Plus } from 'lucide-react-native';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, BackHandler, Easing, Pressable, StyleSheet, TextInput, View } from 'react-native';

import { AuthLayout, useCloseAuth } from '@/components/auth/AuthLayout';
import { CheckboxRow, GoogleButton, OrDivider, OtpInput, PasswordInput, Rule, StepProgress, StrengthMeter } from '@/components/auth/parts';
import { Button, Input, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { passwordChecks, rules } from '@/lib/validation';
import { authApi } from '@/services/auth';
import { useSession } from '@/store/session';
import { useTheme } from '@/theme';
import { haptic } from '@/lib/haptics';

type Step = 1 | 2 | 3;
type Errors = Partial<Record<'firstName' | 'lastName' | 'username' | 'email' | 'code' | 'password' | 'confirm' | 'terms', string>>;

const COOLDOWN = 60;

const STEP_COPY: Record<Step, { title: string; caption: string }> = {
  1: { title: 'Join the Multiverse', caption: 'Who are you?' },
  2: { title: 'Verify your email', caption: "We'll send a 6-digit code" },
  3: { title: 'Secure your access', caption: "Last step, then you're in" },
};

export default function Register() {
  const t = useTheme();
  const toast = useToast();
  const closeAuth = useCloseAuth();
  const signIn = useSession((s) => s.signIn);

  const [step, setStep] = useState<Step>(1);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [referral, setReferral] = useState('');
  const [showReferral, setShowReferral] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [codeSentTo, setCodeSentTo] = useState<string | null>(null);
  const [cooldown, setCooldown] = useState(0);
  const [sending, setSending] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const lastNameRef = useRef<TextInput>(null);
  const usernameRef = useRef<TextInput>(null);
  const confirmRef = useRef<TextInput>(null);

  // Slide between steps.
  const slide = useRef(new Animated.Value(0)).current;
  const goTo = (next: Step) => {
    const dir = next > step ? 1 : -1;
    slide.setValue(dir * 40);
    setStep(next);
    Animated.timing(slide, { toValue: 0, duration: 220, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  };

  // Resend countdown.
  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(id);
  }, [cooldown]);

  const back = useCallback(() => {
    if (step > 1) {
      goTo((step - 1) as Step);
      return true;
    }
    router.back();
    return true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  // Android hardware back steps backwards through the form.
  useFocusEffect(
    useCallback(() => {
      const sub = BackHandler.addEventListener('hardwareBackPress', () => (step > 1 ? back() : false));
      return () => sub.remove();
    }, [step, back]),
  );

  const fail = (next: Errors) => {
    setErrors(next);
    haptic.error().catch(() => {});
  };
  const clear = (key: keyof Errors) => errors[key] && setErrors((e) => ({ ...e, [key]: undefined }));

  /* Step 1 → 2 */
  const continueFromIdentity = () => {
    const next: Errors = {
      firstName: rules.firstName(firstName),
      lastName: rules.lastName(lastName),
      username: rules.username(username),
    };
    if (next.firstName || next.lastName || next.username) return fail(next);
    setErrors({});
    goTo(2);
  };

  /* Step 2: send code */
  const sendCode = async () => {
    const emailError = rules.email(email);
    if (emailError) return fail({ email: 'Enter a valid email before requesting a code' });
    setSending(true);
    try {
      await authApi.sendVerificationCode(email.trim());
      setCodeSentTo(email.trim());
      setCooldown(COOLDOWN);
      toast.success('Code sent!', 'Check your inbox and spam folder.');
    } catch (err) {
      toast.error('Could not send code', apiErrorMessage(err, 'Failed to send code'));
    } finally {
      setSending(false);
    }
  };

  /* Step 2 → 3 */
  const continueFromEmail = () => {
    const next: Errors = { email: rules.email(email), code: rules.code(code) };
    if (!next.email && !codeSentTo) next.code = 'Tap "Send code" to get your verification code';
    if (next.email || next.code) return fail(next);
    setErrors({});
    goTo(3);
  };

  /* Step 3: create account */
  const submit = async () => {
    const next: Errors = {
      password: rules.password(password),
      confirm: rules.confirm(password, confirm),
      terms: agreed ? undefined : 'You must agree to the terms',
    };
    if (next.password || next.confirm || next.terms) return fail(next);

    setSubmitting(true);
    try {
      const res = await authApi.register({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim(),
        username,
        password,
        confirmPassword: confirm,
        code,
        referralCode: referral.trim() || undefined,
      });
      if (!res.data?.user) throw new Error('No user returned');
      await signIn(res.data.user, res.data.token);
      toast.success('Welcome to Munkai!', 'Account initialization successful.');
      closeAuth();
    } catch (err) {
      const msg = apiErrorMessage(err, 'Initialization failed');
      // Same duplicate checks as the web form — send the user to the step to fix.
      if (/email/i.test(msg) && /(exist|taken|key|occupied|already)/i.test(msg)) {
        goTo(2);
        fail({ email: 'An account with this email already exists' });
        toast.error('Email occupied', 'An account with this email already exists.');
      } else if (/username/i.test(msg) && /(exist|taken|key|already)/i.test(msg)) {
        goTo(1);
        fail({ username: 'This username is already claimed' });
        toast.error('Identity taken', 'This username is already claimed.');
      } else if (/code/i.test(msg)) {
        goTo(2);
        fail({ code: msg });
      } else {
        toast.error('Initialization failed', msg);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const copy = STEP_COPY[step];
  const checks = passwordChecks(password);

  const footer =
    step === 1 ? (
      <>
        <Button title="Continue" fullWidth onPress={continueFromIdentity} />
        <View style={styles.footerRow}>
          <Text variant="bodySmall" color="mutedForeground">
            Already have an identity?{' '}
          </Text>
          <Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="link">
            <Text variant="bodySmall" color="primary" style={styles.bold}>
              Log in
            </Text>
          </Pressable>
        </View>
      </>
    ) : step === 2 ? (
      // Continue appears only once a code has been requested.
      codeSentTo ? (
        <Button title="Continue" fullWidth onPress={continueFromEmail} disabled={code.length < 6} />
      ) : null
    ) : (
      <Button title={submitting ? 'Initializing…' : 'Initialize Protocol'} loading={submitting} fullWidth onPress={submit} />
    );

  return (
    <AuthLayout
      leading="back"
      onLeadingPress={back}
      headerAccessory={<StepProgress step={step} total={3} />}
      title={copy.title}
      caption={copy.caption}
      footer={footer}
    >
      <Animated.View style={[styles.form, { transform: [{ translateX: slide }] }]}>
        {step === 1 && (
          <>
            <View style={styles.row}>
              <Input
                containerStyle={styles.flex}
                label="First name"
                required
                placeholder="John"
                value={firstName}
                onChangeText={(v) => {
                  setFirstName(v);
                  clear('firstName');
                }}
                error={errors.firstName}
                textContentType="givenName"
                autoComplete="given-name"
                returnKeyType="next"
                onSubmitEditing={() => lastNameRef.current?.focus()}
                submitBehavior="submit"
              />
              <Input
                ref={lastNameRef}
                containerStyle={styles.flex}
                label="Last name"
                required
                placeholder="Doe"
                value={lastName}
                onChangeText={(v) => {
                  setLastName(v);
                  clear('lastName');
                }}
                error={errors.lastName}
                textContentType="familyName"
                autoComplete="family-name"
                returnKeyType="next"
                onSubmitEditing={() => usernameRef.current?.focus()}
                submitBehavior="submit"
              />
            </View>
            <View style={styles.fieldGroup}>
              <Input
                ref={usernameRef}
                label="Handle"
                required
                placeholder="unique_name"
                leftIcon={
                  <Text variant="subtitle" color="primary">
                    @
                  </Text>
                }
                value={username}
                onChangeText={(v) => {
                  setUsername(v.toLowerCase().replace(/\s/g, ''));
                  clear('username');
                }}
                error={errors.username}
                autoCapitalize="none"
                autoCorrect={false}
                textContentType="username"
                autoComplete="username-new"
                maxLength={20}
                returnKeyType="next"
                onSubmitEditing={continueFromIdentity}
              />
              <View style={styles.rules}>
                <Rule ok={username.length >= 4 && username.length <= 20} label="4–20 chars" />
                <Rule ok={username.length > 0 && /^[a-z0-9_]+$/.test(username)} label="a–z 0–9 _ only" />
              </View>
            </View>

            <OrDivider label="Or sign up with" />
            <GoogleButton
              label="Sign up with Google"
              onPress={() => toast.info('Coming soon', 'Google sign-up is on its way to the app.')}
            />
          </>
        )}

        {step === 2 && (
          <>
            <Input
              label="Email address"
              required
              placeholder="you@example.com"
              leftIcon={<Mail size={18} color={t.colors.mutedForeground} strokeWidth={2} />}
              value={email}
              onChangeText={(v) => {
                setEmail(v);
                clear('email');
                // Changing the email after requesting a code starts over: code entry hides,
                // "Send code" comes back.
                if (codeSentTo && v.trim() !== codeSentTo) {
                  setCodeSentTo(null);
                  setCode('');
                  setCooldown(0);
                }
              }}
              error={errors.email}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              textContentType="emailAddress"
              autoComplete="email"
              returnKeyType="send"
              onSubmitEditing={codeSentTo ? undefined : sendCode}
            />

            {!codeSentTo ? (
              // Before a code is requested: the only action on this step.
              <Button title={sending ? 'Sending…' : 'Send code'} loading={sending} fullWidth onPress={sendCode} />
            ) : (
              <View style={styles.fieldGroup}>
                <View style={styles.sentRow}>
                  <CircleCheck size={14} color={t.colors.success} strokeWidth={2.4} />
                  <Text variant="bodySmall" color="success" style={styles.small}>
                    Code sent to {codeSentTo}. Check your inbox and spam folder.
                  </Text>
                </View>
                <Text variant="label" style={styles.otpLabel}>
                  Verification code{' '}
                  <Text variant="label" color="danger">
                    *
                  </Text>
                </Text>
                <OtpInput
                  value={code}
                  autoFocus
                  onChange={(v) => {
                    setCode(v);
                    clear('code');
                  }}
                  error={!!errors.code}
                  onSubmitEditing={continueFromEmail}
                />
                {errors.code ? (
                  <Text variant="bodySmall" color="destructive">
                    {errors.code}
                  </Text>
                ) : null}
                {/* Resend lives under the code, as a text link. */}
                <View style={styles.resendRow}>
                  <Text variant="bodySmall" color="mutedForeground">
                    Didn&apos;t get it?{' '}
                  </Text>
                  {cooldown > 0 ? (
                    <Text variant="bodySmall" color="mutedForeground" style={styles.bold}>
                      Resend in {cooldown}s
                    </Text>
                  ) : (
                    <Pressable onPress={sendCode} disabled={sending} hitSlop={10} accessibilityRole="button">
                      <Text variant="bodySmall" color="primary" style={styles.bold}>
                        {sending ? 'Sending…' : 'Resend code'}
                      </Text>
                    </Pressable>
                  )}
                </View>
              </View>
            )}
          </>
        )}

        {step === 3 && (
          <>
            <View style={styles.fieldGroup}>
              <PasswordInput
                label="Password"
                required
                placeholder="••••••••"
                value={password}
                onChangeText={(v) => {
                  setPassword(v);
                  clear('password');
                }}
                error={errors.password}
                maxLength={15}
                textContentType="newPassword"
                autoComplete="new-password"
                returnKeyType="next"
                onSubmitEditing={() => confirmRef.current?.focus()}
                submitBehavior="submit"
              />
              <StrengthMeter password={password} />
              <View style={styles.checklist}>
                <Rule ok={checks.length} label="8–15 characters" />
                <Rule ok={checks.upper} label="Uppercase letter" />
                <Rule ok={checks.number} label="Number" />
                <Rule ok={checks.symbol} label="Symbol (!@#…)" />
              </View>
            </View>

            <PasswordInput
              ref={confirmRef}
              label="Confirm password"
              required
              placeholder="••••••••"
              value={confirm}
              onChangeText={(v) => {
                setConfirm(v);
                clear('confirm');
              }}
              error={errors.confirm}
              maxLength={15}
              textContentType="newPassword"
              autoComplete="new-password"
              returnKeyType="done"
            />

            {showReferral ? (
              <Input
                label="Referral code (optional)"
                placeholder="MUNKAI1234"
                value={referral}
                onChangeText={setReferral}
                autoCapitalize="characters"
                autoCorrect={false}
                autoFocus
              />
            ) : (
              <Pressable onPress={() => setShowReferral(true)} hitSlop={8} accessibilityRole="button" style={styles.referralBtn}>
                <Plus size={16} color={t.colors.primary} strokeWidth={2.5} />
                <Text variant="bodySmall" color="primary" style={styles.bold}>
                  Have a referral code?
                </Text>
              </Pressable>
            )}

            <View>
              <CheckboxRow
                checked={agreed}
                onToggle={() => {
                  setAgreed((a) => !a);
                  clear('terms');
                }}
                accessibilityLabel="I accept the Munkai Terms of Service"
              >
                <Text variant="bodySmall" color="mutedForeground">
                  I accept the Munkai{' '}
                  <Text
                    variant="bodySmall"
                    color="primary"
                    style={styles.bold}
                    onPress={() => router.push({ pathname: '/legal', params: { doc: 'terms' } })}
                    accessibilityRole="link"
                  >
                    Terms of Service
                  </Text>
                </Text>
              </CheckboxRow>
              {errors.terms ? (
                <Text variant="bodySmall" color="destructive">
                  {errors.terms}
                </Text>
              ) : null}
            </View>
          </>
        )}
      </Animated.View>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  form: { gap: 20 },
  row: { flexDirection: 'row', gap: 12 },
  fieldGroup: { gap: 10 },
  rules: { flexDirection: 'row', gap: 16 },
  otpLabel: { marginTop: 8 },
  resendRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', minHeight: 32 },
  sentRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  small: { fontSize: 12, lineHeight: 16 },
  checklist: { flexDirection: 'row', flexWrap: 'wrap', rowGap: 6, columnGap: 16 },
  referralBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', minHeight: 44 },
  footerRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  bold: { fontFamily: 'SpaceGrotesk-Bold' },
});
