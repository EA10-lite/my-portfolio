import { Stack } from 'expo-router';
import React from 'react';

import { useTheme } from '@/theme';

/** Stack inside the auth sheet: Login ↔ Register ↔ Forgot ↔ Restore, with swipe-back. */
export default function AuthLayout() {
  const t = useTheme();
  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
        gestureEnabled: true,
        contentStyle: { backgroundColor: t.colors.pageBackground },
      }}
    />
  );
}
