/**
 * Login — approved mock "Login" (dark) / "Login · Light".
 * Web: munkai-frontend/src/components/forms/signIn.tsx
 */
import axios from 'axios';
import { router } from 'expo-router';
import React, { useRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View } from 'react-native';

import { AuthLayout, useAuthIsDismissible, useCloseAuth } from '@/components/auth/AuthLayout';
import { GoogleButton, OrDivider, PasswordInput } from '@/components/auth/parts';
import { MunkaiMark } from '@/components/brand/MunkaiMark';
import { Button, Input, Text, useToast } from '@/components/ui';
import { apiErrorMessage, apiErrorStatus } from '@/lib/api';
import { rules } from '@/lib/validation';
import { authApi } from '@/services/auth';
import { useSession } from '@/store/session';
import { haptic } from '@/lib/haptics';

export default function Login() {
  const toast = useToast();
  const closeAuth = useCloseAuth();
  // Entry point when logged out → no ✕ (nothing behind it); over the app → ✕ closes.
  const dismissible = useAuthIsDismissible();
  const signIn = useSession((s) => s.signIn);

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ identifier?: string; password?: string }>({});
  const [loading, setLoading] = useState(false);
  const passwordRef = useRef<TextInput>(null);

  const submit = async () => {
    const next = { identifier: rules.loginId(identifier), password: rules.loginPassword(password) };
    setErrors(next);
    if (next.identifier || next.password) {
      haptic.error().catch(() => {});
      return;
    }

    setLoading(true);
    try {
      const res = await authApi.login({ emailOrUsername: identifier.trim(), password });
      if (!res.data?.user) throw new Error('No user returned');
      await signIn(res.data.user, res.data.token);
      toast.success('Login successful', 'Welcome back to Munkai!');
      closeAuth();
    } catch (err) {
      // Legacy accounts must be restored first (web: AccountMigrationModal).
      if (apiErrorStatus(err) === 403 && axios.isAxiosError(err)) {
        const data = err.response?.data as { message?: string; errors?: { email?: string } } | undefined;
        if (data?.message === 'MIGRATION_REQUIRED') {
          router.push({
            pathname: '/restore-account',
            params: { identifier: identifier.trim(), email: data.errors?.email ?? '' },
          });
          return;
        }
      }
      toast.error('Login failed', apiErrorMessage(err, 'An error occurred during login'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      leading={dismissible ? 'close' : 'none'}
      eyebrow={<MunkaiMark size={40} />}
      title="Welcome back"
      caption={'Re-establish your connection\nto the multiverse'}
      footer={
        <>
          <Button title={loading ? 'Establishing link…' : 'Authenticate'} loading={loading} fullWidth onPress={submit} />
          <View style={styles.footerRow}>
            <Text variant="bodySmall" color="mutedForeground">
              New to Munkai?{' '}
            </Text>
            <Pressable onPress={() => router.push('/register')} hitSlop={10} accessibilityRole="link">
              <Text variant="bodySmall" color="primary" style={styles.bold}>
                Initialize Protocol
              </Text>
            </Pressable>
          </View>
        </>
      }
    >
      <View style={styles.form}>
        <Input
          label="User designation"
          placeholder="Email or username"
          value={identifier}
          onChangeText={(v) => {
            setIdentifier(v);
            if (errors.identifier) setErrors((e) => ({ ...e, identifier: undefined }));
          }}
          error={errors.identifier}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="email-address"
          textContentType="username"
          autoComplete="username"
          returnKeyType="next"
          onSubmitEditing={() => passwordRef.current?.focus()}
          submitBehavior="submit"
        />
        <PasswordInput
          ref={passwordRef}
          label="Access code"
          placeholder="••••••••"
          value={password}
          onChangeText={(v) => {
            setPassword(v);
            if (errors.password) setErrors((e) => ({ ...e, password: undefined }));
          }}
          error={errors.password}
          textContentType="password"
          autoComplete="current-password"
          returnKeyType="go"
          onSubmitEditing={submit}
        />
        <Pressable onPress={() => router.push('/forgot-password')} hitSlop={10} accessibilityRole="link" style={styles.forgot}>
          <Text variant="bodySmall" color="primary" style={styles.bold}>
            Forgot password?
          </Text>
        </Pressable>

        <View style={styles.gap} />
        <OrDivider label="Or continue with" />
        <GoogleButton label="Continue with Google" onPress={() => toast.info('Coming soon', 'Google sign-in is on its way to the app.')} />
      </View>
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  form: { gap: 18 },
  forgot: { alignSelf: 'flex-end', marginTop: -6, paddingVertical: 6 },
  gap: { height: 2 },
  footerRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  bold: { fontFamily: 'SpaceGrotesk-Bold' },
});
