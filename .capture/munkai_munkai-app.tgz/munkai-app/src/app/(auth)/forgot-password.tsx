/**
 * Forgot password — approved mocks "Forgot password" + "Forgot password · Sent".
 * Web: munkai-frontend/src/components/forms/forgot-password.tsx
 * The reset itself finishes on the web (email link → munkai.art/auth/reset-password).
 */
import { router } from 'expo-router';
import { Mail } from 'lucide-react-native';
import React, { useState } from 'react';
import { Linking, Platform, Pressable, StyleSheet, View } from 'react-native';

import { AuthLayout } from '@/components/auth/AuthLayout';
import { Glow } from '@/components/effects/Glow';
import { Button, CutShape, Input, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { rules } from '@/lib/validation';
import { authApi } from '@/services/auth';
import { useTheme, withAlpha } from '@/theme';
import { haptic } from '@/lib/haptics';

async function openMailApp() {
  const candidates = Platform.OS === 'ios' ? ['message://', 'googlegmail://'] : ['googlegmail://', 'mailto:'];
  for (const url of candidates) {
    try {
      await Linking.openURL(url);
      return true;
    } catch {
      // try next
    }
  }
  return false;
}

export default function ForgotPassword() {
  const t = useTheme();
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string>();
  const [loading, setLoading] = useState(false);
  const [sentTo, setSentTo] = useState<string | null>(null);

  const submit = async () => {
    const e = rules.email(email) && 'Please provide a valid email address';
    if (e) {
      setError(e);
      haptic.error().catch(() => {});
      return;
    }
    setLoading(true);
    try {
      await authApi.forgotPassword(email.trim());
      haptic.success().catch(() => {});
      setSentTo(email.trim());
    } catch (err) {
      toast.error('Error', apiErrorMessage(err, 'Unable to process password reset request'));
    } finally {
      setLoading(false);
    }
  };

  if (sentTo) {
    return (
      <AuthLayout
        leading="back"
        onLeadingPress={() => setSentTo(null)}
        footer={
          <>
            <Button
              title="Open mail app"
              fullWidth
              onPress={async () => {
                if (!(await openMailApp())) toast.info('Open your mail app', 'Look for the email from Munkai.');
              }}
            />
            <Button title="Back to login" variant="ghost" fullWidth onPress={() => router.back()} />
          </>
        }
      >
        <View style={styles.sent}>
          <View style={styles.iconWrap}>
            <View style={styles.glow} pointerEvents="none">
              <Glow size={200} color={t.colors.primary} intensity={0.3} />
            </View>
            <CutShape
              cuts={{ tl: 10, br: 10 }}
              fill={t.isDark ? withAlpha(t.colors.card, 0.85) : t.colors.background}
              stroke={withAlpha(t.colors.primary, 0.5)}
              strokeWidth={1.5}
              style={styles.iconBox}
            >
              <View>
                <Mail size={38} color={t.colors.primary} strokeWidth={1.8} />
              </View>
            </CutShape>
          </View>
          <Text variant="display" align="center" style={styles.sentTitle}>
            Check your inbox
          </Text>
          <Text variant="body" color="mutedForeground" align="center">
            We sent a rescue link to{'\n'}
            <Text variant="subtitle">{sentTo}</Text>.{'\n'}Open it to set a new password.
          </Text>
          <View style={styles.inline}>
            <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
              Not there? Check spam, or{' '}
            </Text>
            <Pressable onPress={() => setSentTo(null)} hitSlop={10} accessibilityRole="button">
              <Text variant="bodySmall" color="primary" style={[styles.small, styles.bold]}>
                try another email
              </Text>
            </Pressable>
          </View>
        </View>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      leading="back"
      title="Signal distress?"
      caption={"We'll send a rescue link\nto your designated inbox"}
      footer={
        <>
          <Button title={loading ? 'Transmitting…' : 'Send reset link'} loading={loading} fullWidth onPress={submit} />
          <View style={styles.inline}>
            <Text variant="bodySmall" color="mutedForeground">
              False alarm?{' '}
            </Text>
            <Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="link">
              <Text variant="bodySmall" color="primary" style={styles.bold}>
                Return to login
              </Text>
            </Pressable>
          </View>
        </>
      }
    >
      <Input
        label="Email address"
        placeholder="you@example.com"
        value={email}
        onChangeText={(v) => {
          setEmail(v);
          if (error) setError(undefined);
        }}
        error={error}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        textContentType="emailAddress"
        autoComplete="email"
        autoFocus
        returnKeyType="send"
        onSubmitEditing={submit}
      />
    </AuthLayout>
  );
}

const styles = StyleSheet.create({
  sent: { alignItems: 'center', gap: 14, paddingTop: 40 },
  iconWrap: { width: 200, height: 150, alignItems: 'center', justifyContent: 'center' },
  glow: { position: 'absolute', left: 0, top: -25 },
  iconBox: { width: 84, height: 84, alignItems: 'center', justifyContent: 'center' },
  sentTitle: { fontSize: 30, lineHeight: 34 },
  inline: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap' },
  small: { fontSize: 12, lineHeight: 16 },
  bold: { fontFamily: 'SpaceGrotesk-Bold' },
});
