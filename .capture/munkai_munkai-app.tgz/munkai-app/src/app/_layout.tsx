import { useFonts } from 'expo-font';
import { DarkTheme, DefaultTheme, router, Stack, ThemeProvider as NavThemeProvider, type ErrorBoundaryProps } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { NavigationBar } from 'expo-navigation-bar';
import { StatusBar } from 'expo-status-bar';
import * as SystemUI from 'expo-system-ui';
import React, { useCallback, useEffect, useMemo } from 'react';
import { Pressable, ScrollView, Text as RNText, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { toast, ToastProvider } from '@/components/ui';
import { installCrashReporter, showLastCrash } from '@/lib/crashReporter';
import { startNetworkWatch } from '@/lib/network';
import { hydrateOffline } from '@/store/offline';
import { useSession, watchSessionInvalidation } from '@/store/session';
import { fontFiles, ThemeProvider, useTheme } from '@/theme';

installCrashReporter();

// Keep the native launch screen up until fonts are loaded and the first frame renders.
SplashScreen.preventAutoHideAsync().catch(() => {});

function ThemedStack() {
  const t = useTheme();
  // Navigation's own containers (behind screens, during fades and tab switches) default to white.
  // Give them the app's colours so nothing white ever flashes between the splash and Home.
  const navTheme = useMemo(() => {
    const base = t.isDark ? DarkTheme : DefaultTheme;
    return {
      ...base,
      colors: {
        ...base.colors,
        background: t.colors.pageBackground,
        card: t.colors.pageBackground,
        text: t.colors.foreground,
        border: t.colors.border,
        primary: t.colors.primary,
      },
    };
  }, [t]);

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(t.colors.pageBackground).catch(() => {});
  }, [t.colors.pageBackground]);

  // Restore the saved session even when the app opens straight onto a deep link.
  useEffect(() => {
    useSession.getState().hydrate();
    hydrateOffline();
    startNetworkWatch();
    setTimeout(showLastCrash, 2500);
  }, []);

  // Server says the session is gone → sign out locally and tell the user (web: AppShell).
  useEffect(
    () =>
      watchSessionInvalidation(() => {
        toast.error('Session invalidated', "You've been logged out. Please log in again.");
        router.replace('/login');
      }),
    [],
  );

  // Hide the native launch screen only once our first themed frame is laid out, so the
  // animated Splash picks up from it with no blank flash in between.
  const onLayout = useCallback(() => {
    SplashScreen.hideAsync().catch(() => {});
  }, []);

  return (
    <NavThemeProvider value={navTheme}>
      <View style={{ flex: 1, backgroundColor: t.colors.pageBackground }} onLayout={onLayout}>
        <StatusBar style={t.isDark ? 'light' : 'dark'} />
        {/* Android: app colour shows through the (transparent) nav bar; buttons follow the theme. */}
        <NavigationBar style={t.isDark ? 'dark' : 'light'} />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: t.colors.pageBackground },
            animation: 'fade',
          }}
        >
          <Stack.Screen name="index" />
          <Stack.Screen name="onboarding" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen
            name="edit-profile"
            options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom', gestureEnabled: false }}
          />
          <Stack.Screen name="referrals" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="faq" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="contact" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="legal" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="browse/[kind]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="wallet-history" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="publication/[id]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="read/[id]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="notifications" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="creator/[id]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="chapters" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="top-creators" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="studio/index" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="studio/[id]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="studio/publication-form" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="studio/reorder/[id]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="downloaded/[id]" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="settings" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="delete-account" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="become-creator" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="studio/chapter" options={{ animation: 'slide_from_bottom', gestureEnabled: false }} />
          <Stack.Screen name="about" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          <Stack.Screen name="auth/reset-password" options={{ animation: 'slide_from_right', gestureEnabled: true }} />
          {/* Search fades in over Explore/Home like X/Twitter's search. */}
          <Stack.Screen name="search" options={{ animation: 'fade', animationDuration: 180, gestureEnabled: false }} />
          {/* Auth slides up as a full-screen sheet over whatever the user was doing. */}
          <Stack.Screen
            name="(auth)"
            options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom', gestureEnabled: false }}
          />
        </Stack>
      </View>
    </NavThemeProvider>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts(fontFiles);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <ToastProvider>
          <ThemedStack />
        </ToastProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}

/**
 * Last-resort screen for a crash anywhere in the app — shows what went wrong instead of a blank
 * screen (no theme / fonts used, so it works even if those are what failed).
 */
export function ErrorBoundary({ error, retry }: ErrorBoundaryProps) {
  useEffect(() => {
    SplashScreen.hideAsync().catch(() => {});
    console.error('[Munkai] crash', error);
  }, [error]);
  return (
    <View style={{ flex: 1, backgroundColor: '#00002B', paddingTop: 80, paddingHorizontal: 24 }}>
      <RNText style={{ color: '#F2F2F2', fontSize: 22, fontWeight: '700' }}>Something went wrong</RNText>
      <RNText style={{ color: '#A3A3A3', fontSize: 14, marginTop: 8, lineHeight: 20 }}>
        The app hit an error. Try again — if it keeps happening, send this message to the Munkai team.
      </RNText>
      <ScrollView style={{ marginTop: 16, maxHeight: 260, backgroundColor: '#0F172B', padding: 12 }}>
        <RNText selectable style={{ color: '#FF8FA3', fontSize: 12, fontFamily: 'Courier' }}>
          {String(error?.message ?? error)}
          {'\n\n'}
          {String(error?.stack ?? '').slice(0, 1500)}
        </RNText>
      </ScrollView>
      <View style={{ flexDirection: 'row', gap: 12, marginTop: 20 }}>
        <Pressable
          onPress={retry}
          accessibilityRole="button"
          style={{ backgroundColor: '#87CEEB', paddingHorizontal: 20, height: 48, justifyContent: 'center' }}
        >
          <RNText style={{ color: '#006097', fontWeight: '700', letterSpacing: 1 }}>TRY AGAIN</RNText>
        </Pressable>
        <Pressable
          onPress={() => {
            retry().then(() => router.replace('/'));
          }}
          accessibilityRole="button"
          style={{ borderWidth: 2, borderColor: '#87CEEB', paddingHorizontal: 20, height: 48, justifyContent: 'center' }}
        >
          <RNText style={{ color: '#87CEEB', fontWeight: '700', letterSpacing: 1 }}>RESTART</RNText>
        </Pressable>
      </View>
    </View>
  );
}
