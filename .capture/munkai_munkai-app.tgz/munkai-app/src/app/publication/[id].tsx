/**
 * Publication details — approved mock "Publication details".
 * Web (origin/main): app/publications/[id]. Data: GET /api/publications/:id,
 * GET /api/chapters/list, GET /api/publications/related.
 */
import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import {
  ArrowDownToLine,
  ArrowDownWideNarrow,
  CircleCheck,
  ArrowUpNarrowWide,
  Bookmark,
  BookmarkCheck,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  LockKeyhole,
  MoreHorizontal,
  NotebookPen,
  Search,
  Share2,
  X,
} from 'lucide-react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Animated, Linking, Pressable, RefreshControl, Share, StyleSheet, TextInput, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { PublicationCard, PublicationCardSkeleton } from '@/components/content/cards';
import { Cover } from '@/components/content/Cover';
import { Shelf } from '@/components/content/Shelf';
import { ChapterRow, ChapterRowSkeleton, chapterState } from '@/components/publication/ChapterRow';
import { CollectSheet, UnlockAllSheet } from '@/components/publication/PurchaseSheets';
import { ReportSheet } from '@/components/publication/ReportSheet';
import { Avatar, Button, CutShape, Sheet, Skeleton, SkeletonGroup, Text, useToast } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { WEB_URL } from '@/lib/config';
import { formatBalance } from '@/lib/format';
import { genres, openChapter, openCreator, readFreeChapter, typeLabel } from '@/lib/publication';
import { useReadingHistory } from '@/lib/readingHistory';
import { useFetch } from '@/lib/useFetch';
import { chaptersApi } from '@/services/chapters';
import { contentApi } from '@/services/content';
import type { ChapterIndexEntry, Publication } from '@/services/types';
import {
  cancelPublicationDownload,
  canSaveOffline,
  downloadPublication,
  isOfflineCurrent,
  OFFLINE_SUPPORTED,
  removePublication,
  useOffline,
  usePublicationJob,
} from '@/store/offline';
import { toggleSaved, useIsSaved } from '@/store/saved';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const HERO = 470;

export default function PublicationScreen() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { id, collect } = useLocalSearchParams<{ id: string; collect?: string }>();
  const me = useSession((s) => s.user);

  const pub = useFetch(`publication/${id}`, () => contentApi.publication(id));
  const pubId = pub.data?.id;
  const [order, setOrder] = useState<'desc' | 'asc'>('desc');
  const chapters = useFetch(pubId != null ? `chapters/${pubId}` : null, () => chaptersApi.index(pubId!, 'asc'));
  const related = useFetch(pubId != null ? `related/${pubId}` : null, () => contentApi.related(pubId!));
  const uncollected = useFetch(pubId != null ? `uncollected/${pubId}` : null, () => chaptersApi.uncollected(pubId!));
  const history = useReadingHistory();

  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [collectFor, setCollectFor] = useState<ChapterIndexEntry | null>(null);
  const [unlockAll, setUnlockAll] = useState(false);
  const [menu, setMenu] = useState(false);
  const [report, setReport] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const scrollY = React.useRef(new Animated.Value(0)).current;

  const saved = useIsSaved(pub.data ?? { id: id ?? '' });
  const p = pub.data;
  const isFanfic = !!p?.isFanfic;
  const isOwner = !!p && !!me && p.username === me.username;
  const resume = history.find((h) => String(h.publicationId) === String(pubId));

  // Refresh chapter ownership when coming back from the reader.
  useFocusEffect(
    useCallback(() => {
      chapters.reload();
      uncollected.reload();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [pubId]),
  );

  // Arrived from a locked chapter elsewhere (Home, reader) → open its Collect sheet once.
  const handledCollect = React.useRef(false);
  React.useEffect(() => {
    if (!collect || handledCollect.current || !chapters.data) return;
    handledCollect.current = true;
    const ch = chapters.data.find((c) => String(c.id) === String(collect));
    if (ch) open(ch);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collect, chapters.data]);

  const list = useMemo(() => {
    const all = [...(chapters.data ?? [])].filter((c) => !c.isDeleted);
    all.sort((a, b) => (order === 'asc' ? a.chapterNumber - b.chapterNumber : b.chapterNumber - a.chapterNumber));
    const q = query.trim().toLowerCase();
    return q ? all.filter((c) => (c.name ?? '').toLowerCase().includes(q) || String(c.chapterNumber).includes(q)) : all;
  }, [chapters.data, order, query]);

  const first = useMemo(() => [...(chapters.data ?? [])].sort((a, b) => a.chapterNumber - b.chapterNumber)[0], [chapters.data]);
  const resumeChapter = resume ? chapters.data?.find((c) => String(c.id) === String(resume.chapterId)) : undefined;
  const target = resumeChapter ?? first;

  const open = async (ch: ChapterIndexEntry) => {
    const state = chapterState(ch, isFanfic);
    if (state === 'owned' || state === 'reading' || isOwner) return openChapter(ch);
    if (state === 'free') {
      // Free chapters still need collecting (web: ChapterPayment with price 0) — do it inline.
      setBusyId(ch.id);
      try {
        if (await readFreeChapter(ch)) chapters.reload();
      } finally {
        setBusyId(null);
      }
      return;
    }
    setCollectFor(ch);
  };

  const share = () => {
    if (!p) return;
    Share.share({ message: `${p.name} on Munkai — ${WEB_URL}/publications/${p.slug ?? p.id}` }).catch(() => {});
  };

  if (pub.error && !p) {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <Text variant="heading" align="center">
          Couldn’t load this publication
        </Text>
        <Text variant="bodySmall" color="mutedForeground" align="center">
          {apiErrorMessage(pub.error)}
        </Text>
        <View style={styles.row}>
          <Button title="Go back" variant="outline" onPress={() => router.back()} />
          <Button title="Try again" onPress={pub.refetch} />
        </View>
      </View>
    );
  }

  const badges = p
    ? [
        p.featuredPublications ? { label: '✦ Featured', color: '#D78CFF' } : null,
        p.munkaiPicks ? { label: '◆ Munkai pick', color: '#FFC400' } : null,
        p.freePublications ? { label: 'Free', color: t.colors.success } : null,
        isFanfic ? { label: 'Fan translation', color: t.colors.neonCyan } : null,
      ].filter(Boolean)
    : [];
  const summary = p?.summary || p?.shortSummary || '';
  const gid = `ph${String(id).replace(/[^a-zA-Z0-9]/g, '')}`;
  const total = p?.totalChapters ?? chapters.data?.length ?? 0;

  const header = (
    <SkeletonGroup>
      {/* Hero */}
      <View style={{ height: HERO + insets.top - 44 }}>
        {p ? <Cover uri={p.coverPhoto} width={width} height={HERO + insets.top - 44} blur={26} style={StyleSheet.absoluteFill} /> : null}
        <Svg width={width} height={HERO + insets.top - 44} style={StyleSheet.absoluteFill}>
          <Defs>
            <LinearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={t.colors.pageBackground} stopOpacity={0.35} />
              <Stop offset="0.45" stopColor={t.colors.pageBackground} stopOpacity={0.25} />
              <Stop offset="1" stopColor={t.colors.pageBackground} stopOpacity={1} />
            </LinearGradient>
          </Defs>
          <Rect x="0" y="0" width={width} height={HERO + insets.top} fill={`url(#${gid})`} />
        </Svg>
        <View style={[styles.cover, { top: insets.top + 56, left: (width - 188) / 2 }]}>
          {p ? (
            <Cover uri={p.coverPhoto} width={188} height={268}>
              {p.publicationType ? (
                <View style={[styles.typeBadge, { backgroundColor: t.colors.primary }]}>
                  <Text style={[styles.badgeText, { color: t.colors.onPrimary }]}>{typeLabel(p.publicationType)}</Text>
                </View>
              ) : null}
            </Cover>
          ) : (
            <Skeleton width={188} height={268} />
          )}
        </View>
        <View style={styles.titleBlock}>
          {p ? (
            <>
              <Text variant="title" align="center" style={styles.title}>
                {p.name}
              </Text>
              {p.username ? (
                <Pressable onPress={() => openCreator({ username: p.username! })} accessibilityRole="button" style={styles.creator}>
                  <Avatar uri={p.profileImage} firstName={p.firstName} lastName={p.lastName} seed={p.username} size={24} />
                  <Text variant="subtitle" color="primary" style={styles.creatorText}>
                    @{p.username}
                  </Text>
                  <ChevronRight size={14} color={t.colors.primary} />
                </Pressable>
              ) : null}
            </>
          ) : (
            <>
              <Skeleton width={220} height={28} />
              <Skeleton width={110} height={16} style={{ marginTop: 10 }} />
            </>
          )}
        </View>
      </View>

      {/* Facts */}
      <View style={[styles.facts, { borderColor: withAlpha(t.colors.primary, 0.1) }]}>
        <Fact value={p ? String(total) : null} label="Chapters" />
        <View style={[styles.factDivider, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]} />
        <Fact value={p ? (genres(p)[0] ?? '—') : null} label="Genre" />
        <View style={[styles.factDivider, { backgroundColor: withAlpha(t.colors.primary, 0.12) }]} />
        <Fact
          value={p ? (p.isCompleted ? 'Finished' : 'Ongoing') : null}
          label={p ? (p.isFiction ? 'Fiction' : 'Non-fiction') : 'Status'}
          color={p?.isCompleted ? t.colors.success : '#FFC400'}
        />
      </View>

      {badges.length ? (
        <View style={styles.badges}>
          {badges.map((b) => (
            <View
              key={b!.label}
              style={[styles.badge, { borderColor: withAlpha(b!.color, 0.4), backgroundColor: withAlpha(b!.color, 0.1) }]}
            >
              <Text style={[styles.badgeText, { color: b!.color }]}>{b!.label}</Text>
            </View>
          ))}
          {saved ? (
            <View
              style={[styles.badge, { borderColor: withAlpha(t.colors.primary, 0.4), backgroundColor: withAlpha(t.colors.primary, 0.1) }]}
            >
              <Text style={[styles.badgeText, { color: t.colors.primary }]}>Saved</Text>
            </View>
          ) : null}
        </View>
      ) : null}

      {summary ? (
        <Pressable
          onPress={() => setExpanded((e) => !e)}
          accessibilityRole="button"
          accessibilityHint={expanded ? 'Show less' : 'Show full summary'}
        >
          <Text
            variant="body"
            style={[styles.summary, { color: t.isDark ? '#C9CCD6' : t.colors.foreground }]}
            numberOfLines={expanded ? undefined : 4}
          >
            {summary}
          </Text>
          {summary.length > 180 ? (
            <Text variant="subtitle" color="primary" style={styles.more}>
              {expanded ? 'Show less' : 'Read more'}
            </Text>
          ) : null}
        </Pressable>
      ) : !p ? (
        <View style={styles.summarySkeleton}>
          <Skeleton height={12} width="100%" radius={3} />
          <Skeleton height={12} width="92%" radius={3} />
          <Skeleton height={12} width="70%" radius={3} />
        </View>
      ) : null}

      {isFanfic && (p?.originalWorkTitle || p?.originalAuthor || p?.originalLanguage || p?.originalSourceUrl) ? (
        <CutShape
          cuts={t.cuts.card}
          fill={withAlpha(t.colors.neonCyan, 0.05)}
          stroke={withAlpha(t.colors.neonCyan, 0.16)}
          style={styles.original}
        >
          <View style={[styles.originalHead, { borderBottomColor: withAlpha(t.colors.primary, 0.12) }]}>
            <NotebookPen size={14} color={t.colors.primary} />
            <Text variant="caption" color="primary">
              Original work
            </Text>
          </View>
          <View style={styles.originalGrid}>
            {p?.originalWorkTitle ? <Detail label="Title" value={p.originalWorkTitle} /> : null}
            {p?.originalAuthor ? <Detail label="Author" value={p.originalAuthor} /> : null}
            {p?.originalLanguage ? <Detail label="Language" value={p.originalLanguage} /> : null}
            {p?.originalSourceUrl ? (
              <Pressable
                onPress={() => Linking.openURL(p.originalSourceUrl!).catch(() => {})}
                accessibilityRole="link"
                style={styles.source}
              >
                <Text variant="subtitle" color="primary" style={styles.sourceText}>
                  Visit source
                </Text>
                <ExternalLink size={13} color={t.colors.primary} />
              </Pressable>
            ) : null}
          </View>
        </CutShape>
      ) : null}

      {/* Chapters header */}
      <View style={styles.chHead}>
        <Text variant="heading" style={styles.chTitle}>
          Chapters{' '}
          <Text variant="subtitle" color="mutedForeground">
            {total || ''}
          </Text>
        </Text>
        <RoundIcon label="Find a chapter" onPress={() => setSearchOpen((o) => !o)} active={searchOpen}>
          <Search size={18} color={t.colors.foreground} />
        </RoundIcon>
        <Pressable
          onPress={() => setOrder((o) => (o === 'desc' ? 'asc' : 'desc'))}
          accessibilityRole="button"
          accessibilityLabel={order === 'desc' ? 'Sorted newest first' : 'Sorted oldest first'}
          style={[styles.sort, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]}
        >
          {order === 'desc' ? (
            <ArrowDownWideNarrow size={16} color={t.colors.foreground} />
          ) : (
            <ArrowUpNarrowWide size={16} color={t.colors.foreground} />
          )}
          <Text variant="subtitle" style={styles.sortText}>
            {order === 'desc' ? 'Newest' : 'Oldest'}
          </Text>
        </Pressable>
      </View>
      {searchOpen ? (
        <View style={[styles.find, { backgroundColor: t.colors.inputBackground, borderColor: withAlpha(t.colors.primary, 0.25) }]}>
          <Search size={16} color={t.colors.mutedForeground} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            autoFocus
            placeholder="Chapter name or number"
            placeholderTextColor={t.colors.mutedForeground}
            selectionColor={t.colors.primary}
            style={[styles.findInput, { color: t.colors.foreground, fontFamily: t.fonts.body }]}
          />
          {query ? (
            <Pressable onPress={() => setQuery('')} hitSlop={10} accessibilityLabel="Clear">
              <X size={16} color={t.colors.mutedForeground} />
            </Pressable>
          ) : null}
        </View>
      ) : null}
      {isFanfic ? (
        <View style={styles.fanNote}>
          <LockKeyhole size={14} color={t.colors.primary} />
          <Text variant="bodySmall" color="mutedForeground" style={styles.fanNoteText}>
            Newer chapters may be locked early — unlock them to read ahead.
          </Text>
        </View>
      ) : null}
    </SkeletonGroup>
  );

  const footer = (
    <View style={{ paddingBottom: 130 + insets.bottom }}>
      {chapters.loading ? (
        <SkeletonGroup>
          <View style={styles.pad}>
            {[0, 1, 2, 3, 4].map((i) => (
              <ChapterRowSkeleton key={i} divider={i > 0} />
            ))}
          </View>
        </SkeletonGroup>
      ) : !chapters.error && list.length === 0 ? (
        <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.empty}>
          {query ? 'No chapter matches that.' : 'No chapters yet.'}
        </Text>
      ) : chapters.error ? (
        <Pressable onPress={chapters.refetch} style={styles.empty}>
          <Text variant="bodySmall" color="mutedForeground" align="center">
            Couldn’t load chapters. Tap to retry.
          </Text>
        </Pressable>
      ) : null}
      <SkeletonGroup>
        <Shelf
          title="More like this"
          loading={related.loading}
          data={related.data?.filter((r) => String(r.id) !== String(pubId))}
          keyOf={(r) => String(r.id)}
          renderItem={(r) => <PublicationCard pub={r} width={112} />}
          renderSkeleton={() => <PublicationCardSkeleton width={112} />}
          skeletonCount={3}
        />
      </SkeletonGroup>
    </View>
  );

  const unlockable = (uncollected.data?.uncollectedCount ?? 0) > 0 && !isOwner;

  return (
    <View style={styles.root}>
      <Animated.FlatList
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: true })}
        scrollEventThrottle={16}
        data={chapters.loading ? [] : list}
        keyExtractor={(c) => String(c.id)}
        ListHeaderComponent={header}
        ListFooterComponent={footer}
        renderItem={({ item, index }) => (
          <View style={styles.pad}>
            <ChapterRow
              ch={item}
              state={isOwner ? 'owned' : chapterState(item, isFanfic, resume?.chapterId)}
              onPress={() => open(item)}
              busy={busyId === item.id}
              divider={index > 0}
            />
          </View>
        )}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={pub.refreshing}
            onRefresh={() => {
              pub.refetch();
              chapters.reload();
              uncollected.reload();
            }}
            tintColor={t.colors.primary}
            progressViewOffset={insets.top}
          />
        }
      />

      {/* Solid bar with the title fades in once the hero scrolls away. */}
      <Animated.View
        pointerEvents="none"
        style={[
          styles.solidBar,
          {
            height: insets.top + 54,
            backgroundColor: withAlpha(t.isDark ? t.colors.card : t.colors.background, 0.97),
            borderBottomColor: withAlpha(t.colors.primary, 0.12),
            opacity: scrollY.interpolate({ inputRange: [HERO - 260, HERO - 170], outputRange: [0, 1], extrapolate: 'clamp' }),
          },
        ]}
      >
        <Text variant="heading" numberOfLines={1} style={[styles.solidTitle, { marginTop: insets.top + 14 }]}>
          {p?.name ?? ''}
        </Text>
      </Animated.View>

      {/* Floating top buttons */}
      <View style={[styles.topBar, { top: insets.top + 6 }]} pointerEvents="box-none">
        <GlassButton label="Back" onPress={() => (router.canGoBack() ? router.back() : router.replace('/home'))}>
          <ChevronLeft size={24} color="#F2F2F2" />
        </GlassButton>
        <View style={styles.flex} pointerEvents="none" />
        <GlassButton label="Share" onPress={share}>
          <Share2 size={19} color="#F2F2F2" />
        </GlassButton>
        <GlassButton label="More" onPress={() => setMenu(true)}>
          <MoreHorizontal size={20} color="#F2F2F2" />
        </GlassButton>
      </View>

      {/* Sticky action bar */}
      {p ? (
        <View
          style={[
            styles.bar,
            {
              paddingBottom: Math.max(insets.bottom, 12) + 8,
              borderTopColor: withAlpha(t.colors.primary, 0.14),
              backgroundColor: withAlpha(t.isDark ? t.colors.card : t.colors.background, 0.97),
            },
          ]}
        >
          <Pressable
            onPress={() => toggleSaved(p, saved)}
            accessibilityRole="button"
            accessibilityLabel={saved ? 'Remove from saved' : 'Save'}
            style={[styles.saveBtn, { borderColor: withAlpha(t.colors.primary, 0.5) }]}
          >
            {saved ? (
              <BookmarkCheck size={20} color={t.colors.primary} strokeWidth={2.2} />
            ) : (
              <Bookmark size={20} color={t.colors.primary} />
            )}
          </Pressable>
          <DownloadButton pub={p} chapters={chapters.data ?? []} owner={isOwner} />
          {unlockable ? (
            <Pressable
              onPress={() => setUnlockAll(true)}
              accessibilityRole="button"
              style={[styles.unlock, { borderColor: t.colors.primary }]}
            >
              <Text variant="caption" color="primary" style={styles.unlockTop}>
                Unlock all
              </Text>
              <Text variant="bodySmall" color="primary" style={styles.unlockBottom}>
                {uncollected.data!.totalPrice ? `ጠ ${formatBalance(uncollected.data!.totalPrice)}` : 'Free'}
              </Text>
            </Pressable>
          ) : null}
          <Button
            title={target ? `${resumeChapter ? 'Continue' : 'Read'} Ch. ${target.chapterNumber}` : 'No chapters yet'}
            disabled={!target}
            onPress={() => target && open(target)}
            dense
            style={styles.flex}
          />
        </View>
      ) : null}

      <CollectSheet
        chapter={collectFor}
        publicationName={p?.name ?? ''}
        cover={p?.coverPhoto}
        onClose={() => setCollectFor(null)}
        onCollected={(ch) => {
          setCollectFor(null);
          chapters.reload();
          uncollected.reload();
          openChapter(ch);
        }}
      />
      {pubId != null ? (
        <UnlockAllSheet
          publicationId={pubId}
          visible={unlockAll}
          onClose={() => setUnlockAll(false)}
          onDone={() => {
            chapters.reload();
            uncollected.reload();
          }}
        />
      ) : null}
      <Sheet visible={menu} onClose={() => setMenu(false)}>
        {isOwner ? (
          <MenuRow
            label="Manage in Creator Studio"
            onPress={() => {
              setMenu(false);
              router.push({ pathname: '/studio/[id]', params: { id: String(p!.id) } });
            }}
          />
        ) : null}
        <MenuRow
          label="Share"
          onPress={() => {
            setMenu(false);
            share();
          }}
        />
        {!isOwner ? (
          <MenuRow
            label="Report publication"
            danger
            onPress={() => {
              setMenu(false);
              setTimeout(() => setReport(true), 300);
            }}
          />
        ) : null}
      </Sheet>
      <ReportSheet
        target={report && p ? { type: 'publication', id: Number(p.id), label: 'publication' } : null}
        onClose={() => setReport(false)}
      />
    </View>
  );
}

function Fact({ value, label, color }: { value: string | null; label: string; color?: string }) {
  const t = useTheme();
  return (
    <View style={factStyles.fact}>
      {value === null ? (
        <Skeleton width={48} height={18} />
      ) : (
        <Text numberOfLines={1} style={[factStyles.value, { color: color ?? t.colors.primary }]}>
          {value}
        </Text>
      )}
      <Text variant="caption" color="mutedForeground">
        {label}
      </Text>
    </View>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <View style={factStyles.detail}>
      <Text variant="caption" color="mutedForeground">
        {label}
      </Text>
      <Text numberOfLines={2} style={factStyles.detailValue}>
        {value}
      </Text>
    </View>
  );
}

function GlassButton({ label, onPress, children }: { label: string; onPress: () => void; children: React.ReactNode }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={4}
      style={({ pressed }) => [factStyles.glass, pressed && { opacity: 0.7 }]}
    >
      {children}
    </Pressable>
  );
}

function RoundIcon({
  label,
  onPress,
  active,
  children,
}: {
  label: string;
  onPress: () => void;
  active?: boolean;
  children: React.ReactNode;
}) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{ selected: !!active }}
      style={[factStyles.round, { backgroundColor: withAlpha(t.colors.primary, active ? 0.2 : 0.08) }]}
    >
      {children}
    </Pressable>
  );
}

function MenuRow({ label, onPress, danger }: { label: string; onPress: () => void; danger?: boolean }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [factStyles.menuRow, pressed && { backgroundColor: t.colors.hover }]}
    >
      <Text variant="subtitle" color={danger ? 'danger' : 'foreground'}>
        {label}
      </Text>
    </Pressable>
  );
}

const factStyles = StyleSheet.create({
  fact: { flex: 1, alignItems: 'center', gap: 3 },
  value: { fontFamily: 'Grandstander-Bold', fontSize: 18, lineHeight: 23 },
  detail: { width: '50%', paddingRight: 10, paddingBottom: 10, gap: 2 },
  detailValue: { fontFamily: 'Grandstander-Bold', fontSize: 14, lineHeight: 19 },
  glass: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,43,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  round: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  menuRow: { minHeight: 52, justifyContent: 'center', paddingHorizontal: 4 },
});

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    center: { alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 32 },
    row: { flexDirection: 'row', gap: 10, marginTop: 8 },
    flex: { flex: 1 },
    pad: { paddingHorizontal: 20 },
    cover: {
      position: 'absolute',
      shadowColor: '#000',
      shadowOpacity: 0.6,
      shadowRadius: 22,
      shadowOffset: { width: 0, height: 18 },
      elevation: 12,
    },
    typeBadge: { position: 'absolute', top: 8, left: 8, paddingHorizontal: 6, paddingVertical: 2 },
    badgeText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 10, lineHeight: 13, letterSpacing: 0.9, textTransform: 'uppercase' },
    titleBlock: { position: 'absolute', left: 20, right: 20, bottom: 0, alignItems: 'center', gap: 8 },
    title: { fontSize: 28, lineHeight: 33 },
    creator: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 4 },
    creatorText: { fontSize: 14 },
    facts: { flexDirection: 'row', marginHorizontal: 20, marginTop: 16, paddingVertical: 12, borderTopWidth: 1, borderBottomWidth: 1 },
    factDivider: { width: 1 },
    badges: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, paddingHorizontal: 20, paddingTop: 14 },
    badge: { paddingHorizontal: 9, paddingVertical: 4, borderWidth: 1 },
    summary: { paddingHorizontal: 20, paddingTop: 14, fontSize: 15, lineHeight: 23 },
    more: { paddingHorizontal: 20, paddingTop: 4, fontSize: 14 },
    summarySkeleton: { paddingHorizontal: 20, paddingTop: 16, gap: 8 },
    original: { marginHorizontal: 20, marginTop: 16, padding: 14 },
    originalHead: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingBottom: 10, borderBottomWidth: 1 },
    originalGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingTop: 10 },
    source: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingBottom: 10 },
    sourceText: { fontSize: 12 },
    chHead: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 20, paddingTop: 28, paddingBottom: 8 },
    chTitle: { flex: 1, fontSize: 20 },
    sort: { height: 40, paddingHorizontal: 12, borderRadius: 20, flexDirection: 'row', alignItems: 'center', gap: 6 },
    sortText: { fontSize: 12 },
    find: {
      marginHorizontal: 20,
      marginBottom: 6,
      height: 44,
      paddingHorizontal: 12,
      borderWidth: 1,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    findInput: { flex: 1, height: '100%', fontSize: 15 },
    fanNote: { flexDirection: 'row', gap: 6, paddingHorizontal: 20, paddingBottom: 6 },
    fanNoteText: { flex: 1, fontSize: 12, lineHeight: 17 },
    empty: { padding: 24 },
    topBar: { position: 'absolute', left: 12, right: 12, flexDirection: 'row', gap: 8 },
    solidBar: { position: 'absolute', left: 0, right: 0, top: 0, borderBottomWidth: 1, paddingHorizontal: 110 },
    solidTitle: { fontSize: 17, lineHeight: 22, textAlign: 'center' },
    bar: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      paddingHorizontal: 20,
      paddingTop: 12,
      borderTopWidth: 1,
      flexDirection: 'row',
      gap: 10,
    },
    saveBtn: { width: 54, height: 54, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
    unlock: { height: 54, paddingHorizontal: 12, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
    unlockTop: { fontSize: 11, letterSpacing: 1 },
    unlockBottom: { fontSize: 11, lineHeight: 14 },
  });

/** Save every readable chapter for offline reading (store/offline.ts). */
function DownloadButton({ pub, chapters, owner }: { pub: Publication; chapters: ChapterIndexEntry[]; owner: boolean }) {
  const t = useTheme();
  const toast = useToast();
  const job = usePublicationJob(pub.id);
  const savedMap = useOffline((s) => s.chapters);
  const unsupported = useOffline((s) => s.unsupported);
  if (!OFFLINE_SUPPORTED) return null;
  const readable = chapters.filter((c) => canSaveOffline(c, owner));
  if (!readable.length) return null;
  const savedCount = readable.filter((c) => savedMap[String(c.id)]).length;
  const upToDate = savedCount > 0 && readable.every((c) => isOfflineCurrent({ chapters: savedMap, unsupported }, c));
  const meta = { id: String(pub.id), name: pub.name, coverPhoto: pub.coverPhoto, publicationType: pub.publicationType };

  const onPress = () => {
    if (job) {
      Alert.alert('Stop downloading?', `${job.done} of ${job.total} chapters are saved so far.`, [
        { text: 'Keep going', style: 'cancel' },
        { text: 'Stop', style: 'destructive', onPress: () => cancelPublicationDownload(pub.id) },
      ]);
      return;
    }
    if (upToDate) {
      Alert.alert(
        'Remove downloads?',
        `${savedCount} chapter${savedCount === 1 ? '' : 's'} of ${pub.name} will be removed from this device.`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Remove',
            style: 'destructive',
            onPress: () => {
              removePublication(pub.id);
              toast.success('Downloads removed');
            },
          },
        ],
      );
      return;
    }
    downloadPublication(meta, chapters, owner).then((r) => {
      if (!r) return;
      if (!r.done && r.skipped && !r.failed) toast.info('PDF chapters can’t be saved offline on this device');
      else if (r.failed) toast.info(`Saved ${r.done} chapter${r.done === 1 ? '' : 's'}`, `${r.failed} couldn’t be saved.`);
      else if (r.done) toast.success('Ready to read offline', `${r.done} chapter${r.done === 1 ? '' : 's'} saved on this device.`);
    });
  };

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={
        job
          ? `Downloading ${job.done} of ${job.total}. Tap to stop`
          : upToDate
            ? 'Downloaded. Tap to remove'
            : 'Download for offline reading'
      }
      style={[
        dlStyles.btn,
        { borderColor: withAlpha(t.colors.primary, 0.5) },
        upToDate && { backgroundColor: withAlpha(t.colors.primary, 0.14) },
      ]}
    >
      {job ? (
        <Text variant="caption" color="primary" style={dlStyles.progress}>
          {job.done}/{job.total}
        </Text>
      ) : upToDate ? (
        <CircleCheck size={20} color={t.colors.primary} strokeWidth={2.2} />
      ) : (
        <ArrowDownToLine size={20} color={t.colors.primary} />
      )}
    </Pressable>
  );
}

const dlStyles = StyleSheet.create({
  btn: { width: 54, height: 54, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  progress: { fontSize: 12, fontWeight: '700' },
});
