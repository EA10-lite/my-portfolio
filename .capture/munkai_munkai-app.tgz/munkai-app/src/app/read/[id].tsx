/**
 * Chapter reader — approved mocks "Chapter reader", "Reading settings", "End of chapter",
 * "Comic chapter". Web (origin/main): components/read/ReaderPage.tsx.
 * GET /api/chapters/read?chapterId&v — prose (HTML), a PDF link, or page images.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { router, useLocalSearchParams } from 'expo-router';
import { AArrowUp, ChevronLeft, ChevronRight, Lock, MessageCircle, MoreHorizontal, Music } from 'lucide-react-native';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated,
  FlatList,
  Pressable,
  StyleSheet,
  useWindowDimensions,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Cover } from '@/components/content/Cover';
import { ReportSheet } from '@/components/publication/ReportSheet';
import { ComicPage, PdfContent } from '@/components/reader/ComicContent';
import { CommentsSheet, useComments } from '@/components/reader/CommentsSheet';
import { HtmlContent } from '@/components/reader/HtmlContent';
import { ReaderSettingsSheet } from '@/components/reader/ReaderSettingsSheet';
import { useAmbient } from '@/components/reader/useAmbient';
import { Avatar, Button, Sheet, Skeleton, SkeletonGroup, Text } from '@/components/ui';
import { apiErrorMessage, apiErrorStatus } from '@/lib/api';
import { useIsOffline } from '@/lib/network';
import { formatCompact } from '@/lib/format';
import { chapterTitle, openCreator, readFreeChapter, timeAgo } from '@/lib/publication';
import { READER_THEMES, TEXT_SIZES, useReaderPrefs, type AmbientName } from '@/lib/readerPrefs';
import { recordReading } from '@/lib/readingHistory';
import { useFetch } from '@/lib/useFetch';
import { chaptersApi, parseChapterContent } from '@/services/chapters';
import { toast } from '@/components/ui/Toast';
import {
  downloadChapter,
  hydrateOffline,
  OFFLINE_SUPPORTED,
  readOffline,
  removeChapter,
  useChapterBusy,
  useOffline,
  useSavedChapter,
} from '@/store/offline';
import axios from 'axios';
import type { ChapterNeighbour, ChapterContent } from '@/services/types';
import { useSession } from '@/store/session';
import { withAlpha } from '@/theme';

const PRIMARY = '#87CEEB';
const ON_PRIMARY = '#006097';

/**
 * Saved copy first when it's the same version; otherwise the network, falling back to the saved copy
 * when there's no connection. A saved chapter that changed upstream is refreshed in the background.
 */
async function loadChapter(id: string, version?: number): Promise<ChapterContent & { offline?: boolean }> {
  await hydrateOffline();
  const saved = useOffline.getState().chapters[String(id)];
  // Only trust the saved copy blindly when the caller asked for exactly that version.
  if (saved && version !== undefined && saved.editCount === version) {
    const local = await readOffline(id);
    if (local) return { ...local, offline: true };
  }
  try {
    const net = await chaptersApi.read(id, version);
    if (saved && (Number(net.editCount) || 0) !== saved.editCount) {
      const pub = useOffline.getState().publications[saved.publicationId];
      if (pub) downloadChapter(id, pub).catch(() => {});
    }
    return net;
  } catch (err) {
    if (saved && axios.isAxiosError(err) && !err.response) {
      const local = await readOffline(id);
      if (local) return { ...local, offline: true };
    }
    throw err;
  }
}

export default function Reader() {
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const { id, v, pub } = useLocalSearchParams<{ id: string; v?: string; pub?: string }>();
  const me = useSession((s) => s.user);
  const offlineMode = useIsOffline();
  const prefs = useReaderPrefs();
  useAmbient();

  const version = v ? Number(v) : undefined;
  const saved = useSavedChapter(id);
  const chapter = useFetch(`read/${id}/${v ?? ''}`, () => loadChapter(id, Number.isFinite(version) ? version : undefined));
  const ch = chapter.data;
  const content = useMemo(() => parseChapterContent(ch?.content), [ch?.content]);
  const comic = content.kind !== 'text';
  const theme = comic ? READER_THEMES.Onyx : READER_THEMES[prefs.theme];
  const pubId = ch?.pubId ?? ch?.publicationId ?? (pub ? Number(pub) : undefined);
  const comments = useComments(ch ? id : undefined);

  const [settings, setSettings] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const busy = useChapterBusy(id);
  const [report, setReport] = useState(false);

  // Bars: hide while scrolling down, back on scroll up / tap / near the end.
  const bars = useRef(new Animated.Value(1)).current;
  const barsShown = useRef(true);
  const setBars = (show: boolean) => {
    if (barsShown.current === show) return;
    barsShown.current = show;
    Animated.timing(bars, { toValue: show ? 1 : 0, duration: 200, useNativeDriver: true }).start();
  };
  const progress = useRef(new Animated.Value(0)).current;
  const lastY = useRef(0);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const listRef = useRef<FlatList>(null);
  const restored = useRef(false);
  const progressKey = `munkai_reading_progress_${id}`;

  const persist = useCallback(
    (y: number, frac: number) => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => {
        if (frac > 0.97) AsyncStorage.removeItem(progressKey).catch(() => {});
        else AsyncStorage.setItem(progressKey, String(Math.round(y))).catch(() => {});
        if (ch && pubId != null) {
          recordReading({
            publicationId: String(pubId),
            publicationName: ch.publicationName ?? '',
            coverPhoto: ch.coverPhoto,
            chapterId: String(id),
            chapterNumber: ch.chapterNumber,
            chapterName: ch.name,
            progress: Math.min(Math.max(frac, 0), 1),
          });
        }
      }, 600);
    },
    [ch, id, progressKey, pubId],
  );

  // First open counts as "started" for Continue reading.
  useEffect(() => {
    if (ch && pubId != null) persist(0, 0.02);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ch?.chapterNumber, pubId]);

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const { contentOffset, contentSize, layoutMeasurement } = e.nativeEvent;
    const y = contentOffset.y;
    const max = Math.max(contentSize.height - layoutMeasurement.height, 1);
    const frac = Math.min(Math.max(y / max, 0), 1);
    progress.setValue(frac);
    const dy = y - lastY.current;
    if (y < 40 || frac > 0.96) setBars(true);
    else if (dy > 10) setBars(false);
    else if (dy < -10) setBars(true);
    lastY.current = y;
    if (restored.current) persist(y, frac);
  };

  const onContentSizeChange = () => {
    if (restored.current || !ch) return;
    restored.current = true;
    AsyncStorage.getItem(progressKey)
      .then((raw) => {
        const y = raw ? Number(raw) : 0;
        if (y > 0) setTimeout(() => listRef.current?.scrollToOffset({ offset: y, animated: false }), 250);
      })
      .catch(() => {});
  };

  const goChapter = (n: ChapterNeighbour) => {
    if (n.canRead === false && !n.isCollected) {
      // Free next chapter → collect it and keep reading, no detour.
      if (n.price != null && !Number(n.price)) {
        void readFreeChapter({ id: n.id, editCount: n.editCount, publicationId: pubId ?? undefined, price: 0 }, 'replace');
        return;
      }
      if (pubId != null) router.replace({ pathname: '/publication/[id]', params: { id: String(pubId), collect: String(n.id) } });
      return;
    }
    router.replace({
      pathname: '/read/[id]',
      params: {
        id: String(n.id),
        ...(n.editCount != null ? { v: String(n.editCount) } : {}),
        ...(pubId != null ? { pub: String(pubId) } : {}),
      },
    });
  };

  const toggleAmbient = () => {
    const next: AmbientName = prefs.ambient === 'Off' ? 'Thunder' : 'Off';
    prefs.set({ ambient: next });
  };

  /* ------------------------------ states ------------------------------ */

  if (chapter.loading || (!ch && !chapter.error)) {
    return (
      <View style={[styles.root, { backgroundColor: theme.bg, paddingTop: insets.top + 80 }]}>
        <StatusBar style={theme.dark ? 'light' : 'dark'} />
        <SkeletonGroup>
          <View style={styles.skel}>
            <Skeleton width={120} height={16} style={{ alignSelf: 'center' }} />
            <Skeleton width={240} height={32} style={{ alignSelf: 'center', marginTop: 12 }} />
            <Skeleton width={160} height={14} style={{ alignSelf: 'center', marginTop: 10, marginBottom: 28 }} />
            {Array.from({ length: 12 }, (_, i) => (
              <Skeleton key={i} width={i % 3 === 2 ? '70%' : '100%'} height={14} radius={3} style={{ marginBottom: 14 }} />
            ))}
          </View>
        </SkeletonGroup>
        <TopBar insets={insets} bars={bars} theme={theme} title="Loading…" subtitle="" onBack={() => router.back()} />
      </View>
    );
  }

  if (!ch) {
    const status = apiErrorStatus(chapter.error);
    const locked = status === 402 || status === 403;
    const notSaved = !locked && offlineMode;
    return (
      <View style={[styles.root, styles.center, { backgroundColor: theme.bg, paddingTop: insets.top }]}>
        <StatusBar style={theme.dark ? 'light' : 'dark'} />
        <View style={[styles.lockIcon, { borderColor: withAlpha(PRIMARY, 0.4) }]}>
          <Lock size={26} color={PRIMARY} />
        </View>
        <Text variant="heading" align="center" style={{ color: theme.heading }}>
          {locked ? 'This chapter is locked' : notSaved ? 'Not downloaded' : 'Couldn’t open this chapter'}
        </Text>
        <Text variant="bodySmall" align="center" style={{ color: theme.text }}>
          {locked
            ? 'Collect it from the publication page to start reading.'
            : notSaved
              ? 'You’re offline. Connect to the internet to read this chapter.'
              : apiErrorMessage(chapter.error)}
        </Text>
        <View style={styles.row}>
          <Button title="Go back" variant="outline" onPress={() => router.back()} />
          {locked && pubId != null ? (
            <Button
              title="Unlock"
              onPress={() => router.replace({ pathname: '/publication/[id]', params: { id: String(pubId), collect: String(id) } })}
            />
          ) : (
            <Button title="Try again" onPress={chapter.refetch} />
          )}
        </View>
      </View>
    );
  }

  /* ------------------------------ reader ------------------------------ */

  const fontSize = TEXT_SIZES[prefs.size] ?? 19;
  const endTitle = !ch.nextChapter && ch.isCompleted ? 'End of Story' : `End of Chapter ${ch.chapterNumber}`;
  const listData: string[] = content.kind === 'images' ? content.pages : ['content'];

  const header = (
    <View style={[styles.head, { paddingTop: insets.top + 76 }]}>
      <View style={styles.pills}>
        <View style={[styles.pill, { backgroundColor: PRIMARY }]}>
          <Text style={[styles.pillText, { color: '#00002B' }]}>Chapter {ch.chapterNumber}</Text>
        </View>
        {ch.isFanfic ? (
          <View style={[styles.pill, { backgroundColor: '#04FFFF' }]}>
            <Text style={[styles.pillText, { color: '#00002B' }]}>Fan TL</Text>
          </View>
        ) : null}
      </View>
      <Text variant="title" align="center" style={[styles.h1, { color: theme.heading }]}>
        {chapterTitle(ch)}
      </Text>
      {ch.username ? (
        <Text variant="bodySmall" align="center" style={{ color: theme.text, opacity: 0.8 }}>
          {ch.isFanfic ? 'Translated by ' : 'by '}
          <Text
            variant="bodySmall"
            style={{ color: theme.dark ? PRIMARY : ON_PRIMARY, fontFamily: 'SpaceGrotesk-Bold' }}
            onPress={() => openCreator({ username: ch.username! })}
          >
            @{ch.username}
          </Text>
        </Text>
      ) : null}
    </View>
  );

  const footer = (
    <View style={[styles.end, { paddingBottom: insets.bottom + 110 }]}>
      <View style={styles.endRule}>
        <View style={[styles.rule, { backgroundColor: withAlpha(PRIMARY, 0.25) }]} />
        <Text style={[styles.endText, { color: theme.dark ? PRIMARY : ON_PRIMARY }]}>{endTitle}</Text>
        <View style={[styles.rule, { backgroundColor: withAlpha(PRIMARY, 0.25) }]} />
      </View>

      {ch.nextChapter ? (
        <Pressable
          onPress={() => goChapter(ch.nextChapter!)}
          accessibilityRole="button"
          style={[styles.next, { borderColor: withAlpha(PRIMARY, 0.25), backgroundColor: withAlpha(PRIMARY, 0.07) }]}
        >
          <Cover uri={ch.coverPhoto} width={64} height={90} />
          <View style={styles.flex}>
            <Text variant="caption" style={{ color: theme.dark ? PRIMARY : ON_PRIMARY }}>
              Up next · Chapter {ch.nextChapter.chapterNumber}
            </Text>
            <Text variant="heading" numberOfLines={2} style={[styles.nextTitle, { color: theme.heading }]}>
              {chapterTitle(ch.nextChapter)}
            </Text>
            {ch.nextChapter.collectCount ? (
              <Text variant="bodySmall" style={{ color: theme.text, opacity: 0.7, fontSize: 12 }}>
                {formatCompact(ch.nextChapter.collectCount)} collected
              </Text>
            ) : null}
            <View style={[styles.nextCta, { backgroundColor: PRIMARY }]}>
              {ch.nextChapter.canRead === false && !ch.nextChapter.isCollected && Number(ch.nextChapter.price) ? (
                <Lock size={14} color={ON_PRIMARY} strokeWidth={2.4} />
              ) : null}
              <Text style={[styles.nextCtaText, { color: ON_PRIMARY }]}>
                {ch.nextChapter.canRead === false && !ch.nextChapter.isCollected && Number(ch.nextChapter.price)
                  ? `Unlock · ጠ${formatCompact(ch.nextChapter.price)}`
                  : 'Read next'}
              </Text>
            </View>
          </View>
        </Pressable>
      ) : null}
      {ch.prevChapter ? (
        <Pressable
          onPress={() => goChapter(ch.prevChapter!)}
          accessibilityRole="button"
          style={[styles.prev, { borderColor: withAlpha(PRIMARY, 0.2) }]}
        >
          <ChevronLeft size={16} color={theme.heading} />
          <Text variant="subtitle" numberOfLines={1} style={[styles.prevText, { color: theme.heading }]}>
            Previous · Ch. {ch.prevChapter.chapterNumber} {chapterTitle(ch.prevChapter)}
          </Text>
        </Pressable>
      ) : null}

      {/* Comments preview */}
      <View style={styles.cHead}>
        <Text variant="heading" style={[styles.cTitle, { color: theme.heading }]}>
          Comments{' '}
          <Text variant="subtitle" style={{ color: theme.text, opacity: 0.7 }}>
            {comments.items ? comments.total : ''}
          </Text>
        </Text>
        {comments.items?.length ? (
          <Pressable onPress={() => setCommentsOpen(true)} hitSlop={10}>
            <Text variant="subtitle" style={{ color: theme.dark ? PRIMARY : ON_PRIMARY, fontSize: 13 }}>
              View all
            </Text>
          </Pressable>
        ) : null}
      </View>
      {(comments.items ?? []).slice(0, 2).map((c, i) => (
        <View key={c.id} style={[styles.cRow, i > 0 && { borderTopWidth: 1, borderTopColor: withAlpha(PRIMARY, 0.08) }]}>
          <Avatar uri={c.profileImage} firstName={c.username} seed={c.username} size={34} />
          <View style={styles.flex}>
            <Text variant="bodySmall" style={{ color: theme.heading, fontSize: 13 }}>
              <Text variant="subtitle" style={{ color: theme.heading, fontSize: 13 }}>
                @{c.username}
              </Text>
              <Text variant="bodySmall" style={{ color: theme.text, opacity: 0.6, fontSize: 13 }}>
                {'  '}
                {timeAgo(c.createdAt)}
              </Text>
            </Text>
            <Text variant="bodySmall" numberOfLines={3} style={{ color: theme.text, fontSize: 14, lineHeight: 20 }}>
              {c.content}
            </Text>
          </View>
        </View>
      ))}
      <Pressable
        onPress={() => setCommentsOpen(true)}
        accessibilityRole="button"
        style={[
          styles.addComment,
          { borderColor: withAlpha(PRIMARY, 0.2), backgroundColor: withAlpha(theme.dark ? '#0F172B' : '#FFFFFF', 0.9) },
        ]}
      >
        <Text variant="body" style={{ color: theme.text, opacity: 0.6, fontSize: 14 }}>
          Add a comment…
        </Text>
      </Pressable>
    </View>
  );

  const renderItem = ({ item }: { item: string }) => {
    if (content.kind === 'images') return <ComicPage uri={item} onPress={() => setBars(!barsShown.current)} />;
    if (content.kind === 'pdf') return <PdfContent url={content.url} height={height - insets.top - 60} />;
    return (
      <Pressable onPress={() => setBars(!barsShown.current)} style={styles.text} accessible={false}>
        <HtmlContent
          html={content.html}
          style={{
            size: fontSize,
            font: prefs.font,
            text: theme.text,
            heading: theme.heading,
            accent: theme.dark ? PRIMARY : ON_PRIMARY,
            muted: theme.text,
          }}
        />
      </Pressable>
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: theme.bg }]}>
      <StatusBar style={theme.dark ? 'light' : 'dark'} />
      <FlatList
        ref={listRef}
        data={listData}
        keyExtractor={(item, i) => `${i}-${item.slice(-24)}`}
        renderItem={renderItem}
        ListHeaderComponent={header}
        ListFooterComponent={footer}
        onScroll={onScroll}
        scrollEventThrottle={32}
        onContentSizeChange={onContentSizeChange}
        showsVerticalScrollIndicator={false}
        initialNumToRender={3}
        windowSize={7}
      />

      <TopBar
        insets={insets}
        bars={bars}
        theme={theme}
        title={`Ch. ${ch.chapterNumber} · ${chapterTitle(ch)}`}
        subtitle={ch.publicationName ?? ''}
        progress={progress}
        onBack={() =>
          router.canGoBack()
            ? router.back()
            : pubId != null
              ? router.replace({ pathname: '/publication/[id]', params: { id: String(pubId) } })
              : router.replace('/home')
        }
        onSettings={() => setSettings(true)}
        onMore={() => setMenu(true)}
      />

      {/* Floating bottom bar */}
      <Animated.View
        style={[
          styles.bottom,
          {
            bottom: Math.max(insets.bottom, 16),
            backgroundColor: theme.dark ? 'rgba(15,23,43,0.92)' : 'rgba(255,255,255,0.94)',
            borderColor: theme.dark ? withAlpha(PRIMARY, 0.14) : 'rgba(0,0,0,0.08)',
            opacity: bars,
            transform: [{ translateY: bars.interpolate({ inputRange: [0, 1], outputRange: [90, 0] }) }],
          },
        ]}
        pointerEvents="box-none"
      >
        {ch.prevChapter ? (
          <BarButton
            label={`Previous: chapter ${ch.prevChapter.chapterNumber}`}
            onPress={() => goChapter(ch.prevChapter!)}
            color={theme.heading}
          >
            <ChevronLeft size={18} color={theme.heading} />
            <Text variant="subtitle" style={[styles.barText, { color: theme.heading }]}>
              Ch. {ch.prevChapter.chapterNumber}
            </Text>
          </BarButton>
        ) : (
          <View style={styles.barSpacer} />
        )}
        <View style={styles.flex} />
        <BarButton label={`Comments, ${comments.total}`} onPress={() => setCommentsOpen(true)} tint>
          <MessageCircle size={18} color={theme.dark ? PRIMARY : ON_PRIMARY} />
          <Text variant="subtitle" style={[styles.barText, { color: theme.dark ? PRIMARY : ON_PRIMARY }]}>
            {comments.total}
          </Text>
        </BarButton>
        <BarButton label={prefs.ambient === 'Off' ? 'Turn on ambient sound' : 'Turn off ambient sound'} onPress={toggleAmbient}>
          <Music size={19} color={prefs.ambient === 'Off' ? theme.heading : PRIMARY} />
        </BarButton>
        <View style={styles.flex} />
        {ch.nextChapter ? (
          <BarButton label={`Next: chapter ${ch.nextChapter.chapterNumber}`} onPress={() => goChapter(ch.nextChapter!)} primary>
            <Text variant="subtitle" style={[styles.barText, { color: ON_PRIMARY }]}>
              Ch. {ch.nextChapter.chapterNumber}
            </Text>
            {ch.nextChapter.canRead === false && !ch.nextChapter.isCollected && Number(ch.nextChapter.price) ? (
              <Lock size={14} color={ON_PRIMARY} />
            ) : (
              <ChevronRight size={18} color={ON_PRIMARY} />
            )}
          </BarButton>
        ) : (
          <View style={styles.barSpacer} />
        )}
      </Animated.View>

      <ReaderSettingsSheet visible={settings} onClose={() => setSettings(false)} showText={!comic} />
      <CommentsSheet visible={commentsOpen} onClose={() => setCommentsOpen(false)} chapterId={id} comments={comments} />
      <Sheet visible={menu} onClose={() => setMenu(false)}>
        {OFFLINE_SUPPORTED && ch && pubId != null ? (
          <MenuRow
            label={busy ? 'Downloading…' : saved ? 'Remove download' : 'Download for offline'}
            onPress={() => {
              if (busy) return;
              if (saved) {
                removeChapter(id);
                toast.success('Download removed');
                setMenu(false);
                return;
              }
              downloadChapter(id, {
                id: String(pubId),
                name: ch.publicationName ?? '',
                coverPhoto: ch.coverPhoto,
                publicationType: ch.publicationType,
              })
                .then((ok) =>
                  ok ? toast.success('Saved for offline reading') : toast.info('This chapter can’t be saved offline on this device'),
                )
                .catch((e) => toast.error('Download failed', apiErrorMessage(e)));
              setMenu(false);
            }}
          />
        ) : null}
        {pubId != null ? (
          <MenuRow
            label="View publication"
            onPress={() => {
              setMenu(false);
              router.push({ pathname: '/publication/[id]', params: { id: String(pubId) } });
            }}
          />
        ) : null}
        {me && ch.username !== me.username ? (
          <MenuRow
            label="Report chapter"
            danger
            onPress={() => {
              setMenu(false);
              setTimeout(() => setReport(true), 300);
            }}
          />
        ) : null}
      </Sheet>
      <ReportSheet
        target={report ? { type: 'chapter', id: Number(ch.chapterId ?? ch.id ?? id), label: 'chapter' } : null}
        onClose={() => setReport(false)}
      />
    </View>
  );
}

function TopBar({
  insets,
  bars,
  theme,
  title,
  subtitle,
  progress,
  onBack,
  onSettings,
  onMore,
}: {
  insets: { top: number };
  bars: Animated.Value;
  theme: { dark: boolean; heading: string };
  title: string;
  subtitle: string;
  progress?: Animated.Value;
  onBack: () => void;
  onSettings?: () => void;
  onMore?: () => void;
}) {
  const { width } = useWindowDimensions();
  const color = theme.heading;
  return (
    <Animated.View
      style={[
        styles.top,
        {
          paddingTop: insets.top + 2,
          backgroundColor: theme.dark ? 'rgba(15,23,43,0.94)' : 'rgba(255,255,255,0.95)',
          borderBottomColor: theme.dark ? withAlpha(PRIMARY, 0.14) : 'rgba(0,0,0,0.08)',
          transform: [{ translateY: bars.interpolate({ inputRange: [0, 1], outputRange: [-(insets.top + 70), 0] }) }],
        },
      ]}
    >
      <Pressable onPress={onBack} accessibilityRole="button" accessibilityLabel="Back" style={styles.topBtn}>
        <ChevronLeft size={26} color={color} />
      </Pressable>
      <View style={styles.flex}>
        {subtitle ? (
          <Text variant="caption" numberOfLines={1} style={{ color, opacity: 0.6 }}>
            {subtitle}
          </Text>
        ) : null}
        <Text variant="heading" numberOfLines={1} style={[styles.topTitle, { color }]}>
          {title}
        </Text>
      </View>
      {onSettings ? (
        <Pressable onPress={onSettings} accessibilityRole="button" accessibilityLabel="Reading settings" style={styles.topBtn}>
          <AArrowUp size={22} color={color} />
        </Pressable>
      ) : null}
      {onMore ? (
        <Pressable onPress={onMore} accessibilityRole="button" accessibilityLabel="More" style={styles.topBtn}>
          <MoreHorizontal size={22} color={color} />
        </Pressable>
      ) : null}
      {progress ? (
        <Animated.View
          style={[
            styles.progress,
            { width, transform: [{ translateX: progress.interpolate({ inputRange: [0, 1], outputRange: [-width, 0] }) }] },
          ]}
        />
      ) : null}
    </Animated.View>
  );
}

function BarButton({
  label,
  onPress,
  children,
  primary,
  tint,
}: {
  label: string;
  onPress: () => void;
  children: React.ReactNode;
  primary?: boolean;
  tint?: boolean;
  color?: string;
}) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [
        styles.barBtn,
        primary && { backgroundColor: PRIMARY },
        tint && { backgroundColor: withAlpha(PRIMARY, 0.14) },
        pressed && { opacity: 0.7 },
      ]}
    >
      {children}
    </Pressable>
  );
}

function MenuRow({ label, onPress, danger }: { label: string; onPress: () => void; danger?: boolean }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={styles.menuRow}>
      <Text variant="subtitle" color={danger ? 'danger' : 'foreground'}>
        {label}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1, minWidth: 0 },
  center: { alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 32 },
  row: { flexDirection: 'row', gap: 10, marginTop: 10 },
  lockIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 2,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
  },
  skel: { paddingHorizontal: 24 },
  head: { paddingHorizontal: 24, paddingBottom: 24, alignItems: 'center', gap: 10 },
  pills: { flexDirection: 'row', gap: 6 },
  pill: { paddingHorizontal: 7, paddingVertical: 2 },
  pillText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 10, lineHeight: 14, letterSpacing: 1, textTransform: 'uppercase' },
  h1: { fontSize: 30, lineHeight: 36 },
  text: { paddingHorizontal: 24 },
  end: { paddingHorizontal: 20, paddingTop: 12 },
  endRule: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 18 },
  rule: { flex: 1, height: 1 },
  endText: { fontFamily: 'Grandstander-Bold', fontSize: 15 },
  next: { flexDirection: 'row', gap: 14, padding: 14, borderWidth: 1 },
  nextTitle: { fontSize: 19, lineHeight: 24, marginTop: 2 },
  nextCta: { marginTop: 8, height: 40, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  nextCtaText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 12, letterSpacing: 1.2, textTransform: 'uppercase' },
  prev: { marginTop: 10, height: 48, paddingHorizontal: 14, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  prevText: { flex: 1, fontSize: 13 },
  cHead: { flexDirection: 'row', alignItems: 'center', paddingTop: 26, paddingBottom: 6 },
  cTitle: { flex: 1, fontSize: 20 },
  cRow: { flexDirection: 'row', gap: 12, paddingVertical: 12 },
  addComment: { marginTop: 8, height: 46, paddingHorizontal: 14, borderWidth: 1, justifyContent: 'center' },
  top: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    paddingHorizontal: 6,
    paddingBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    borderBottomWidth: 1,
    overflow: 'hidden',
  },
  topBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontSize: 16, lineHeight: 21 },
  progress: { position: 'absolute', left: 0, bottom: 0, height: 3, backgroundColor: PRIMARY },
  bottom: {
    position: 'absolute',
    left: 16,
    right: 16,
    height: 60,
    borderRadius: 30,
    borderWidth: 1,
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    shadowColor: '#000',
    shadowOpacity: 0.35,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 10,
  },
  barBtn: {
    height: 44,
    minWidth: 44,
    paddingHorizontal: 12,
    borderRadius: 22,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  barText: { fontSize: 13 },
  barSpacer: { width: 76 },
  menuRow: { minHeight: 52, justifyContent: 'center', paddingHorizontal: 4 },
});
