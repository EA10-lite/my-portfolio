/**
 * Chapters — approved mock "Chapters list". Web (origin/main): app/publications/chapters,
 * GET /api/chapters (cursor-paginated), filtered on the device like the web.
 */
import { Eye, Search, SlidersHorizontal, X } from 'lucide-react-native';
import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, SectionList, StyleSheet, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Cover } from '@/components/content/Cover';
import { StackHeader, HeaderIconButton } from '@/components/navigation/StackHeader';
import { Button, ReadTag, Sheet, Skeleton, SkeletonGroup, Text } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { formatCompact } from '@/lib/format';
import { PUBLICATION_TYPES, chapterTitle, openChapter, timeAgo } from '@/lib/publication';
import { useInfinite } from '@/lib/useInfinite';
import { contentApi } from '@/services/content';
import type { RecentChapter } from '@/services/types';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

function bucket(date?: string) {
  if (!date) return 'Earlier';
  const d = new Date(date);
  const now = new Date();
  if (d.toDateString() === now.toDateString()) return 'Today';
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return 'Earlier';
}

export default function Chapters() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const list = useInfinite('chapters/all', (cursor) => contentApi.chaptersPage(cursor));
  const [q, setQ] = useState('');
  const [type, setType] = useState('all');
  const [sort, setSort] = useState<'desc' | 'asc'>('desc');
  const [sheet, setSheet] = useState(false);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const out = list.items.filter((c) => {
      if (type !== 'all' && (c.publicationType ?? '').toLowerCase() !== type) return false;
      if (!term) return true;
      return (
        [c.name, c.publicationName, c.username].some((v) => (v ?? '').toLowerCase().includes(term)) ||
        String(c.chapterNumber).includes(term)
      );
    });
    const time = (c: RecentChapter) => new Date(c.createdAt ?? 0).getTime() || 0;
    return out.sort((a, b) => (sort === 'desc' ? time(b) - time(a) : time(a) - time(b)));
  }, [list.items, q, type, sort]);

  const sections = useMemo(() => {
    if (sort === 'asc') return filtered.length ? [{ title: 'Oldest first', data: filtered }] : [];
    const map = new Map<string, RecentChapter[]>();
    filtered.forEach((c) => {
      const k = bucket(c.createdAt);
      map.set(k, [...(map.get(k) ?? []), c]);
    });
    return ['Today', 'Yesterday', 'Earlier'].filter((k) => map.has(k)).map((k) => ({ title: k, data: map.get(k)! }));
  }, [filtered, sort]);

  const chips = [{ value: 'all', label: 'All' }, ...PUBLICATION_TYPES];

  return (
    <View style={styles.root}>
      <StackHeader
        title="Chapters"
        right={
          <HeaderIconButton label="Sort" onPress={() => setSheet(true)}>
            <SlidersHorizontal size={20} color={t.colors.primary} />
          </HeaderIconButton>
        }
      />
      <View style={styles.searchWrap}>
        <View style={[styles.search, { backgroundColor: t.colors.inputBackground, borderColor: withAlpha(t.colors.primary, 0.18) }]}>
          <Search size={18} color={t.colors.mutedForeground} />
          <TextInput
            value={q}
            onChangeText={setQ}
            placeholder="Search chapters, titles, creators"
            placeholderTextColor={t.colors.mutedForeground}
            selectionColor={t.colors.primary}
            autoCorrect={false}
            style={[styles.input, { color: t.colors.foreground, fontFamily: t.fonts.body }]}
          />
          {q ? (
            <Pressable onPress={() => setQ('')} hitSlop={10} accessibilityLabel="Clear">
              <X size={16} color={t.colors.mutedForeground} />
            </Pressable>
          ) : null}
        </View>
      </View>
      <View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chips}>
          {chips.map((c) => {
            const on = type === c.value;
            return (
              <Pressable
                key={c.value}
                onPress={() => setType(c.value)}
                accessibilityRole="button"
                accessibilityState={{ selected: on }}
                style={[
                  styles.chip,
                  on ? { backgroundColor: t.colors.primary } : { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
                ]}
              >
                <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.chipText}>
                  {c.label}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {list.loading ? (
        <SkeletonGroup>
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <View key={i} style={styles.row}>
              <Skeleton width={54} height={76} />
              <View style={{ flex: 1, gap: 7 }}>
                <Skeleton width="40%" height={10} radius={3} />
                <Skeleton width="70%" height={13} radius={3} />
                <Skeleton width="50%" height={10} radius={3} />
              </View>
            </View>
          ))}
        </SkeletonGroup>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(c) => String(c.id)}
          stickySectionHeadersEnabled={false}
          renderSectionHeader={({ section }) => (
            <Text variant="caption" color="mutedForeground" style={styles.section}>
              {section.title}
            </Text>
          )}
          renderItem={({ item, index }) => <ChapterItem ch={item} divider={index > 0} />}
          onEndReached={list.loadMore}
          onEndReachedThreshold={0.6}
          ListFooterComponent={list.loadingMore ? <ActivityIndicator style={{ padding: 20 }} color={t.colors.primary} /> : null}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                {list.error ? apiErrorMessage(list.error) : 'No chapters match.'}
              </Text>
              {list.error ? <Button title="Try again" variant="outline" onPress={list.refresh} /> : null}
            </View>
          }
          keyboardDismissMode="on-drag"
          contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
          refreshControl={<RefreshControl refreshing={list.refreshing} onRefresh={list.refresh} tintColor={t.colors.primary} />}
        />
      )}

      <Sheet visible={sheet} onClose={() => setSheet(false)} title="Sort">
        {(['desc', 'asc'] as const).map((s) => (
          <Pressable
            key={s}
            onPress={() => {
              setSort(s);
              setSheet(false);
            }}
            style={styles.sortRow}
            accessibilityRole="radio"
            accessibilityState={{ selected: sort === s }}
          >
            <Text variant="subtitle" color={sort === s ? 'primary' : 'foreground'}>
              {s === 'desc' ? 'Newest first' : 'Oldest first'}
            </Text>
          </Pressable>
        ))}
      </Sheet>
    </View>
  );
}

function ChapterItem({ ch, divider }: { ch: RecentChapter; divider?: boolean }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const owned = !!ch.isCollected;
  const free = !Number(ch.price);
  return (
    <Pressable
      onPress={() => openChapter(ch)}
      accessibilityRole="button"
      accessibilityLabel={`${ch.publicationName}, chapter ${ch.chapterNumber}${owned ? ', owned' : free ? ', free — read now' : `, ${ch.price} tokens`}`}
      style={({ pressed }) => [
        styles.row,
        divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
        pressed && { opacity: 0.75 },
      ]}
    >
      <Cover uri={ch.coverPhoto} width={54} height={76} />
      <View style={styles.flex}>
        <Text variant="caption" color="primary" numberOfLines={1}>
          {ch.publicationName}
        </Text>
        <Text variant="subtitle" numberOfLines={1} style={styles.title}>
          Ch. {ch.chapterNumber} · {chapterTitle(ch)}
        </Text>
        <View style={styles.metaRow}>
          <Text variant="bodySmall" color="mutedForeground" style={styles.meta} numberOfLines={1}>
            {[ch.username ? `@${ch.username}` : null, timeAgo(ch.createdAt)].filter(Boolean).join(' · ')}
          </Text>
          <Eye size={12} color={t.colors.mutedForeground} />
          <Text variant="bodySmall" color="mutedForeground" style={styles.meta}>
            {formatCompact(ch.collectCount ?? ch.count ?? 0)}
          </Text>
        </View>
      </View>
      {free && !owned ? (
        <ReadTag />
      ) : (
        <View style={[styles.price, owned ? null : { backgroundColor: t.colors.primary }]}>
          <Text style={[styles.priceText, { color: owned ? t.colors.success : t.colors.onPrimary }]}>
            {owned ? '✓ Owned' : `ጠ ${formatCompact(ch.price)}`}
          </Text>
        </View>
      )}
    </Pressable>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1, minWidth: 0 },
    searchWrap: { paddingHorizontal: 20, paddingTop: 12 },
    search: {
      height: 44,
      borderRadius: t.radius.search,
      borderWidth: 1,
      paddingHorizontal: 14,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
    },
    input: { flex: 1, height: '100%', fontSize: 15, paddingVertical: 0 },
    chips: { paddingHorizontal: 20, paddingTop: 12, gap: 8 },
    chip: { height: 34, paddingHorizontal: 14, justifyContent: 'center' },
    chipText: { fontSize: 13, lineHeight: 18 },
    section: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 4 },
    row: { minHeight: 92, marginHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 8 },
    title: { fontSize: 15, lineHeight: 20, marginTop: 2 },
    metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
    meta: { fontSize: 12, lineHeight: 16 },
    price: { paddingHorizontal: 7, paddingVertical: 3 },
    priceText: { fontFamily: 'SpaceGrotesk-Bold', fontSize: 10, lineHeight: 13, letterSpacing: 0.8, textTransform: 'uppercase' },
    empty: { alignItems: 'center', gap: 12, paddingTop: 40, paddingHorizontal: 32 },
    sortRow: { minHeight: 52, justifyContent: 'center', paddingHorizontal: 4 },
  });
