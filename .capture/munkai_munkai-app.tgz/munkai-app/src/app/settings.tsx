/**
 * Settings — everything that used to sit under the Profile tab, reached from the gear on the profile banner.
 * Preferences · Account · Support & about · Legal · Log out · app version.
 */
import Constants from 'expo-constants';
import { router } from 'expo-router';
import { Bell, CircleHelp, FileText, Info, LogOut, MessageCircle, Moon, Pencil, ReceiptText, Undo2, UserX } from 'lucide-react-native';
import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { AppearanceSheet } from '@/components/profile/AppearanceSheet';
import { LogoutSheet } from '@/components/profile/LogoutSheet';
import { SettingsGroup, SettingsRow, Text, useToast } from '@/components/ui';
import { useSession } from '@/store/session';
import { useTheme, useThemePreference, useThemedStyles, withAlpha, type Theme } from '@/theme';

export default function Settings() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { preference } = useThemePreference();
  const signOut = useSession((s) => s.signOut);
  const [sheet, setSheet] = useState<null | 'appearance' | 'logout'>(null);
  const version = Constants.expoConfig?.version ?? '1.0.0';

  return (
    <View style={styles.root}>
      <StackHeader title="Settings" />
      <ScrollView contentContainerStyle={[styles.groups, { paddingBottom: insets.bottom + 32 }]} showsVerticalScrollIndicator={false}>
        <SettingsGroup title="Preferences">
          <SettingsRow
            icon={Moon}
            label="Appearance"
            value={preference === 'system' ? 'System' : preference === 'dark' ? 'Dark' : 'Light'}
            onPress={() => setSheet('appearance')}
          />
          <SettingsRow icon={Bell} label="Notifications" onPress={() => router.push('/notifications')} />
          <SettingsRow icon={ReceiptText} label="Transaction history" onPress={() => router.push('/wallet-history')} />
        </SettingsGroup>

        <SettingsGroup title="Account">
          <SettingsRow icon={Pencil} label="Edit profile" onPress={() => router.push('/edit-profile')} />
          <SettingsRow icon={UserX} label="Delete account" onPress={() => router.push('/delete-account')} />
        </SettingsGroup>

        <SettingsGroup title="Support & about">
          <SettingsRow icon={CircleHelp} label="Help & FAQ" onPress={() => router.push('/faq')} />
          <SettingsRow icon={MessageCircle} label="Contact us" onPress={() => router.push('/contact')} />
          <SettingsRow icon={Info} label="About Munkai" onPress={() => router.push('/about')} />
        </SettingsGroup>

        <SettingsGroup title="Legal">
          <SettingsRow
            icon={FileText}
            label="Privacy policy & terms"
            onPress={() => router.push({ pathname: '/legal', params: { doc: 'terms' } })}
          />
          <SettingsRow icon={Undo2} label="Refund policy" onPress={() => router.push({ pathname: '/legal', params: { doc: 'refund' } })} />
        </SettingsGroup>

        <Pressable
          onPress={() => setSheet('logout')}
          accessibilityRole="button"
          style={({ pressed }) => [styles.logout, pressed && { opacity: 0.8 }]}
        >
          <LogOut size={18} color={t.colors.danger} strokeWidth={2} />
          <Text variant="subtitle" color="danger">
            Log out
          </Text>
        </Pressable>
        <Text variant="caption" align="center" style={styles.version}>
          Munkai v{version}
        </Text>
      </ScrollView>

      <AppearanceSheet visible={sheet === 'appearance'} onClose={() => setSheet(null)} />
      <LogoutSheet
        visible={sheet === 'logout'}
        onClose={() => setSheet(null)}
        onConfirm={async () => {
          await signOut();
          setSheet(null);
          toast.success('Logout successful');
          router.replace('/login');
        }}
      />
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    groups: { paddingHorizontal: 20, paddingTop: 20, gap: 22 },
    logout: {
      minHeight: 54,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.danger, 0.25),
      backgroundColor: withAlpha(t.colors.danger, 0.08),
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
    },
    version: { marginTop: -8, letterSpacing: 1 },
  });
