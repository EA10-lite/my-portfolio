/**
 * Contact us — approved mocks "Contact us" + "Contact · sent".
 * Web: app/company/contact + components/forms/contact.tsx → POST /api/contacts/submit (multipart).
 * Mobile: type dropdown → 3 chips, name/email come from the account, attachment via
 * photo library or Files, Send pinned to the bottom (rides above the keyboard).
 */
import * as DocumentPicker from 'expo-document-picker';
import { useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { FileText, FolderOpen, Image as ImageIcon, Mail, MapPin, Paperclip, Phone, X } from 'lucide-react-native';
import React, { useRef, useState } from 'react';
import { Linking, Platform, Pressable, ScrollView, StyleSheet, View, type TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { Button, Input, Sheet, Text, useToast, KeyboardAvoid } from '@/components/ui';
import { SUPPORT } from '@/content/support';
import { apiErrorMessage } from '@/lib/api';
import { contactApi, type ContactAttachment, type ContactType } from '@/services/contact';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

const TYPES: { value: ContactType; label: string }[] = [
  { value: 'Inquiry', label: 'Inquiry' },
  { value: 'Feedback', label: 'Feedback' },
  { value: 'Complaint', label: 'Complaint' },
];
const MAX_BYTES = 10 * 1024 * 1024;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Errors = Partial<Record<'name' | 'email' | 'subject' | 'message', string>>;

export default function Contact() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const user = useSession((s) => s.user);
  const params = useLocalSearchParams<{ subject?: string; message?: string; type?: string }>();

  const accountName = user ? `${user.firstName ?? ''} ${user.lastName ?? ''}`.trim() : '';
  const accountEmail = user?.emailAddress ?? '';
  const hasAccount = !!(accountName && accountEmail);

  const [name, setName] = useState(accountName);
  const [email, setEmail] = useState(accountEmail);
  const [type, setType] = useState<ContactType>(params.type === 'Complaint' || params.type === 'Feedback' ? params.type : 'Inquiry');
  const [subject, setSubject] = useState(params.subject ?? '');
  const [message, setMessage] = useState(params.message ?? '');
  const [attachment, setAttachment] = useState<ContactAttachment | null>(null);
  const [errors, setErrors] = useState<Errors>({});
  const [sending, setSending] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);

  const scrollRef = useRef<ScrollView>(null);
  const messageRef = useRef<TextInput>(null);

  const clear = (k: keyof Errors) => errors[k] && setErrors((e) => ({ ...e, [k]: undefined }));

  const accept = (file: ContactAttachment) => {
    const ok = file.type.startsWith('image/') || file.type === 'application/pdf';
    if (!ok) return toast.error('Unsupported file', 'Attach an image or a PDF.');
    if (file.size && file.size > MAX_BYTES) return toast.error('File too large', 'Maximum size is 10MB.');
    haptic.select().catch(() => {});
    setAttachment(file);
  };

  const pick = (source: 'photos' | 'files') => {
    setPickerOpen(false);
    // Let the sheet finish closing before presenting the system picker (iOS can't stack them).
    setTimeout(
      async () => {
        try {
          if (source === 'photos') {
            const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (!perm.granted) return toast.error('Permission needed', 'Allow photo access in Settings to continue.');
            const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.85 });
            const a = res.canceled ? null : res.assets?.[0];
            if (!a) return;
            const mime = a.mimeType ?? (a.uri.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg');
            accept({
              uri: a.uri,
              type: mime,
              size: a.fileSize,
              name: a.fileName ?? `attachment-${Date.now()}.${mime.split('/')[1] ?? 'jpg'}`,
            });
          } else {
            const res = await DocumentPicker.getDocumentAsync({ type: ['image/*', 'application/pdf'], copyToCacheDirectory: true });
            const a = res.canceled ? null : res.assets?.[0];
            if (!a) return;
            const mime = a.mimeType ?? (a.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream');
            accept({ uri: a.uri, name: a.name, type: mime, size: a.size });
          }
        } catch {
          toast.error('Could not open picker', 'Please try again.');
        }
      },
      Platform.OS === 'ios' ? 350 : 0,
    );
  };

  const submit = async () => {
    const next: Errors = {
      name: name.trim() ? undefined : 'Name is required.',
      email: EMAIL_RE.test(email.trim()) ? undefined : 'Invalid email address',
      subject: subject.trim() ? undefined : 'Subject is required.',
      message: message.trim() ? undefined : 'Message is required.',
    };
    if (Object.values(next).some(Boolean)) {
      setErrors(next);
      haptic.error().catch(() => {});
      return;
    }
    setSending(true);
    try {
      await contactApi.submit({
        name: name.trim(),
        email: email.trim(),
        type,
        subject: subject.trim(),
        message: message.trim(),
        attachment,
      });
      toast.success('Message received', 'Our support team will get back to you soon.');
      setSubject('');
      setMessage('');
      setAttachment(null);
      setType('Inquiry');
      setErrors({});
      scrollRef.current?.scrollTo({ y: 0, animated: true });
    } catch (err) {
      toast.error('Submission failed', apiErrorMessage(err, 'There was an error sending your message. Please try again.'));
    } finally {
      setSending(false);
    }
  };

  const open = (url: string) => Linking.openURL(url).catch(() => toast.error('Could not open', url));

  return (
    <View style={styles.root}>
      <StackHeader title="Contact us" />
      <KeyboardAvoid>
        <ScrollView
          ref={scrollRef}
          style={styles.flex}
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
          showsVerticalScrollIndicator={false}
        >
          <Text variant="bodySmall" color="mutedForeground">
            Have a question, feedback, or inquiry? {SUPPORT.responseTime}
          </Text>

          <View style={styles.field}>
            <Text variant="label">What’s this about?</Text>
            <View style={styles.chips} accessibilityRole="radiogroup">
              {TYPES.map((opt) => {
                const on = type === opt.value;
                return (
                  <Pressable
                    key={opt.value}
                    onPress={() => {
                      haptic.select().catch(() => {});
                      setType(opt.value);
                    }}
                    accessibilityRole="radio"
                    accessibilityState={{ selected: on }}
                    style={[styles.chip, on ? styles.chipOn : styles.chipOff]}
                  >
                    <Text variant="subtitle" color={on ? t.colors.onPrimary : 'mutedForeground'} style={styles.chipText}>
                      {opt.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {!hasAccount ? (
            <>
              <Input
                label="Full name"
                value={name}
                onChangeText={(v) => {
                  setName(v);
                  clear('name');
                }}
                placeholder="John Doe"
                autoComplete="name"
                textContentType="name"
                error={errors.name}
              />
              <Input
                label="Email"
                value={email}
                onChangeText={(v) => {
                  setEmail(v);
                  clear('email');
                }}
                placeholder="example@email.com"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
                textContentType="emailAddress"
                error={errors.email}
              />
            </>
          ) : null}

          <Input
            label="Subject"
            value={subject}
            onChangeText={(v) => {
              setSubject(v);
              clear('subject');
            }}
            placeholder="Brief subject"
            returnKeyType="next"
            onSubmitEditing={() => messageRef.current?.focus()}
            submitBehavior="submit"
            maxLength={150}
            error={errors.subject}
          />
          <Input
            ref={messageRef}
            label="Message"
            value={message}
            onChangeText={(v) => {
              setMessage(v);
              clear('message');
            }}
            placeholder="Tell us how we can help…"
            multiline
            scrollEnabled={false}
            error={errors.message}
          />

          {attachment ? (
            <View style={styles.fileRow}>
              <View style={styles.fileIcon}>
                {attachment.type === 'application/pdf' ? (
                  <FileText size={18} color={t.colors.primary} strokeWidth={2} />
                ) : (
                  <ImageIcon size={18} color={t.colors.primary} strokeWidth={2} />
                )}
              </View>
              <View style={styles.flex}>
                <Text variant="subtitle" numberOfLines={1} style={styles.fileName}>
                  {attachment.name}
                </Text>
                <Text variant="bodySmall" color="mutedForeground" style={styles.meta}>
                  {attachment.type === 'application/pdf' ? 'PDF' : 'Image'}
                  {attachment.size ? ` · ${formatBytes(attachment.size)}` : ''}
                </Text>
              </View>
              <Pressable
                onPress={() => setAttachment(null)}
                accessibilityRole="button"
                accessibilityLabel="Remove attachment"
                hitSlop={8}
                style={styles.fileRemove}
              >
                <X size={18} color={t.colors.mutedForeground} strokeWidth={2} />
              </Pressable>
            </View>
          ) : (
            <Pressable
              onPress={() => setPickerOpen(true)}
              accessibilityRole="button"
              accessibilityLabel="Add attachment"
              style={({ pressed }) => [styles.attach, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.1) }]}
            >
              <View style={styles.fileIcon}>
                <Paperclip size={16} color={t.colors.primary} strokeWidth={2} />
              </View>
              <View style={styles.flex}>
                <Text variant="subtitle" style={styles.fileName}>
                  Add attachment
                </Text>
                <Text variant="bodySmall" color="mutedForeground" style={styles.meta}>
                  Photo or PDF · max 10MB · optional
                </Text>
              </View>
            </Pressable>
          )}

          {hasAccount ? (
            <Text variant="bodySmall" color="mutedForeground" style={[styles.meta, styles.sendingAs]}>
              Sending as{' '}
              <Text variant="bodySmall" color="foreground" style={[styles.meta, styles.bold]}>
                {accountName}
              </Text>{' '}
              · {accountEmail}
            </Text>
          ) : null}

          <Text variant="caption" color="primary" style={styles.sectionTitle}>
            Other ways to reach us
          </Text>
          <View style={styles.group}>
            <DetailRow icon={Mail} label="Email" value={SUPPORT.email} onPress={() => open(`mailto:${SUPPORT.email}`)} />
            <DetailRow icon={Phone} label="Phone" value={SUPPORT.phone} onPress={() => open(`tel:${SUPPORT.phoneDial}`)} divider />
            <DetailRow icon={MapPin} label="Address" value={SUPPORT.address} divider />
          </View>
        </ScrollView>

        <View style={[styles.footer, { paddingBottom: Math.max(insets.bottom, 12) + 8 }]}>
          <Button title={sending ? 'Sending…' : 'Send message'} onPress={submit} loading={sending} disabled={sending} />
        </View>
      </KeyboardAvoid>

      <Sheet visible={pickerOpen} onClose={() => setPickerOpen(false)} title="Add attachment">
        <PickerOption
          icon={<ImageIcon size={20} color={t.colors.primary} strokeWidth={2} />}
          label="Photo library"
          onPress={() => pick('photos')}
        />
        <View style={[styles.sep, { backgroundColor: withAlpha(t.colors.primary, 0.08) }]} />
        <PickerOption
          icon={<FolderOpen size={20} color={t.colors.primary} strokeWidth={2} />}
          label="Files (image or PDF)"
          onPress={() => pick('files')}
        />
        <Text variant="bodySmall" color="mutedForeground" style={styles.sheetNote}>
          PNG, JPG, WebP or PDF, up to 10MB.
        </Text>
      </Sheet>
    </View>
  );
}

function DetailRow({
  icon: Icon,
  label,
  value,
  onPress,
  divider,
}: {
  icon: typeof Mail;
  label: string;
  value: string;
  onPress?: () => void;
  divider?: boolean;
}) {
  const t = useTheme();
  const body = (
    <>
      <Icon size={20} color={t.colors.primary} strokeWidth={2} />
      <View style={detailStyles.text}>
        <Text variant="bodySmall" color="mutedForeground" style={detailStyles.label}>
          {label}
        </Text>
        <Text variant="subtitle" color={onPress ? 'primary' : 'foreground'} style={detailStyles.value} selectable={!onPress}>
          {value}
        </Text>
      </View>
    </>
  );
  const rowStyle = [detailStyles.row, divider && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }];
  if (!onPress) return <View style={rowStyle}>{body}</View>;
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="link"
      accessibilityLabel={`${label}: ${value}`}
      style={({ pressed }) => [...rowStyle, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.06) }]}
    >
      {body}
    </Pressable>
  );
}

function PickerOption({ icon, label, onPress }: { icon: React.ReactNode; label: string; onPress: () => void }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [detailStyles.option, pressed && { backgroundColor: t.colors.hover }]}
    >
      {icon}
      <Text variant="subtitle">{label}</Text>
    </Pressable>
  );
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

const detailStyles = StyleSheet.create({
  row: { minHeight: 60, paddingHorizontal: 16, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 12 },
  text: { flex: 1, gap: 2 },
  label: { fontSize: 12, lineHeight: 16 },
  value: { fontSize: 14, lineHeight: 19 },
  option: { minHeight: 56, flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 4 },
});

const makeStyles = (t: Theme) => {
  const groupBg = t.isDark ? withAlpha(t.colors.card, 0.9) : withAlpha(t.colors.background, 0.8);
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1 },
    scroll: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 24, gap: 16 },
    field: { gap: 8 },
    chips: { flexDirection: 'row', gap: 8 },
    chip: { flex: 1, height: 44, alignItems: 'center', justifyContent: 'center' },
    chipOn: { backgroundColor: t.colors.primary },
    chipOff: { borderWidth: 1, borderColor: withAlpha(t.colors.primary, 0.25) },
    chipText: { fontSize: 13, lineHeight: 18 },
    attach: {
      padding: 12,
      paddingHorizontal: 14,
      borderWidth: 1,
      borderStyle: 'dashed',
      borderColor: withAlpha(t.colors.primary, 0.4),
      backgroundColor: withAlpha(t.colors.primary, 0.05),
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
    },
    fileRow: {
      padding: 12,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.18),
      backgroundColor: groupBg,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
    },
    fileIcon: {
      width: 36,
      height: 36,
      backgroundColor: withAlpha(t.colors.primary, 0.15),
      alignItems: 'center',
      justifyContent: 'center',
    },
    fileName: { fontSize: 14, lineHeight: 19 },
    meta: { fontSize: 12, lineHeight: 17 },
    fileRemove: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
    sendingAs: { marginTop: -4 },
    bold: { fontFamily: t.fonts.bodyBold },
    sectionTitle: { letterSpacing: 1.6, fontSize: 11, marginTop: 8, marginBottom: -8 },
    group: {
      borderRadius: 14,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: groupBg,
      overflow: 'hidden',
    },
    footer: {
      paddingHorizontal: 20,
      paddingTop: 12,
      borderTopWidth: 1,
      borderTopColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: t.colors.pageBackground,
    },
    sep: { height: 1 },
    sheetNote: { marginTop: 8, paddingHorizontal: 4 },
  });
};
