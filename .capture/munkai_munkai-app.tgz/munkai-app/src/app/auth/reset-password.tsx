/** Universal link munkai.art/auth/reset-password?code=… → the app's reset screen. */
import { Redirect, useLocalSearchParams } from 'expo-router';
import React from 'react';

export default function ResetPasswordLink() {
  const { code } = useLocalSearchParams<{ code?: string }>();
  return <Redirect href={{ pathname: '/reset-password', params: code ? { code } : {} }} />;
}
