/**
 * Splash Screen — approved canvas direction "A · Cover wall".
 *
 * Layers (back → front), matching the mock:
 *   1. pageBackground            — same colour as the native launch screen (seamless handoff)
 *   2. CoverWall                  — web cover art, tilted columns drifting in opposite directions
 *   3. pageBackground @ 55%       — readability overlay (theme token, not a raw colour)
 *   4. brand-blue radial tint     — full-screen, screen-blended glow
 *   5. M mark (72pt) + MUNKAI     — mark sits exactly where the native launch image is
 *
 * Timeline: covers + overlays fade in (0–450ms) → mark pulses 1→1.06→1 → wordmark rises
 * (300–700ms) → hold until ~1.4s / startup ready → mark zooms & everything fades → route.
 */
import { router } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Animated, Easing, Platform, StyleSheet, useWindowDimensions, View } from 'react-native';
import Svg, { Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

import { MunkaiMark } from '@/components/brand/MunkaiMark';
import { CoverWall } from '@/components/effects/CoverWall';
import { Text } from '@/components/ui';
import { useReduceMotion } from '@/hooks/useReduceMotion';
import { startNetworkWatch } from '@/lib/network';
import { resolveStartupDestination, type StartupDestination } from '@/lib/startup';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

/** Must match app.json → expo-splash-screen imageWidth (80) × mark fill (0.9). */
const MARK_SIZE = 72;
const MIN_DURATION_MS = 1400;
const SLOW_START_MS = 3000;

export default function Splash() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const reduceMotion = useReduceMotion();
  const hydrate = useSession((s) => s.hydrate);

  const scene = useRef(new Animated.Value(0)).current;
  const markScale = useRef(new Animated.Value(1)).current;
  const word = useRef(new Animated.Value(0)).current;
  const exit = useRef(new Animated.Value(0)).current;

  const [slow, setSlow] = useState(false);
  const navigated = useRef(false);

  // Restore the session and decide the destination in parallel with the animation.
  const ready = useRef<Promise<StartupDestination> | null>(null);
  if (!ready.current) {
    ready.current = Promise.all([hydrate().catch(() => {}), startNetworkWatch()]).then(() => resolveStartupDestination());
  }

  useEffect(() => {
    if (reduceMotion === null) return;

    const startedAt = Date.now();
    const slowTimer = setTimeout(() => setSlow(true), SLOW_START_MS);

    if (reduceMotion) {
      scene.setValue(1);
      word.setValue(1);
    } else {
      Animated.parallel([
        Animated.timing(scene, { toValue: 1, duration: 450, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.sequence([
          Animated.timing(markScale, {
            toValue: 1.06,
            duration: 220,
            easing: Easing.bezier(0.39, 0.575, 0.565, 1),
            useNativeDriver: true,
          }),
          Animated.timing(markScale, { toValue: 1, duration: 220, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        ]),
        Animated.timing(word, { toValue: 1, duration: 400, delay: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]).start();
    }

    let cancelled = false;
    ready.current!.then(async (dest) => {
      const elapsed = Date.now() - startedAt;
      const minHold = reduceMotion ? 900 : MIN_DURATION_MS;
      if (elapsed < minHold) await new Promise((r) => setTimeout(r, minHold - elapsed));
      if (cancelled || navigated.current) return;

      Animated.timing(exit, { toValue: 1, duration: 280, easing: Easing.in(Easing.cubic), useNativeDriver: true }).start(() => {
        if (cancelled || navigated.current) return;
        navigated.current = true;
        router.replace(dest);
      });
    });

    // Watchdog: never sit on the splash — if startup hasn't moved on after 8s, go anyway.
    const watchdog = setTimeout(() => {
      if (cancelled || navigated.current) return;
      navigated.current = true;
      router.replace(resolveStartupDestination());
    }, 8000);

    return () => {
      cancelled = true;
      clearTimeout(slowTimer);
      clearTimeout(watchdog);
    };
  }, [reduceMotion, scene, markScale, word, exit]);

  const fadeOut = exit.interpolate({ inputRange: [0, 1], outputRange: [1, 0] });
  const zoom = reduceMotion ? 1 : exit.interpolate({ inputRange: [0, 1], outputRange: [1, 1.14] });

  return (
    <View style={styles.root} accessible accessibilityLabel="Munkai is loading">
      <Animated.View style={[StyleSheet.absoluteFill, { opacity: Animated.multiply(scene, fadeOut) }]}>
        <CoverWall animate={reduceMotion === false} />
        {/* Readability overlay — theme token at 55% */}
        <View style={[StyleSheet.absoluteFill, { backgroundColor: withAlpha(t.colors.pageBackground, 0.55) }]} />
        {/* Full-screen brand glow */}
        <View style={[StyleSheet.absoluteFill, styles.blend]}>
          <FullScreenGlow />
        </View>
      </Animated.View>

      <Animated.View style={[styles.center, { opacity: fadeOut, transform: [{ scale: zoom }] }]} pointerEvents="none">
        <View style={styles.markWrap}>
          <Animated.View style={[styles.markShadow, { transform: [{ scale: markScale }] }]}>
            <MunkaiMark size={MARK_SIZE} />
          </Animated.View>
          <Animated.View
            style={[
              styles.wordWrap,
              { opacity: word, transform: [{ translateY: word.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] },
            ]}
          >
            <Text style={styles.wordmark}>Munkai</Text>
          </Animated.View>
        </View>
      </Animated.View>

      {slow && (
        <View style={styles.slow} pointerEvents="none">
          <ActivityIndicator size="small" color={t.colors.primary} />
        </View>
      )}
    </View>
  );
}

/** Soft brand-blue radial wash covering the whole screen (mock: screen-blended tint). */
function FullScreenGlow() {
  const t = useTheme();
  const { width, height } = useWindowDimensions();
  const inner = t.isDark ? '#4FA5D8' : '#87CEEB';
  const outer = t.isDark ? t.colors.primaryForeground : '#4FA5D8';
  return (
    <Svg width={width} height={height}>
      <Defs>
        <RadialGradient id="splashGlowRoot" cx="50%" cy="50%" rx="65%" ry="48%" fx="50%" fy="50%">
          <Stop offset="0" stopColor={inner} stopOpacity={0.3} />
          <Stop offset="0.55" stopColor={outer} stopOpacity={0.22} />
          <Stop offset="1" stopColor={outer} stopOpacity={0.14} />
        </RadialGradient>
      </Defs>
      <Rect x="0" y="0" width={width} height={height} fill="url(#splashGlowRoot)" />
    </Svg>
  );
}

const makeStyles = (t: Theme) => {
  const shadowColor = t.isDark ? t.colors.pageBackground : '#FFFFFF';
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    blend: { mixBlendMode: 'screen' },
    center: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
    markWrap: { width: MARK_SIZE, height: MARK_SIZE, alignItems: 'center', justifyContent: 'center' },
    markShadow: {
      // iOS shadow follows the SVG's alpha; Android uses the drop-shadow filter.
      shadowColor,
      shadowOpacity: 0.85,
      shadowRadius: 10,
      shadowOffset: { width: 0, height: 3 },
      ...(Platform.OS === 'android'
        ? { filter: [{ dropShadow: { offsetX: 0, offsetY: 3, standardDeviation: 8, color: withAlpha(shadowColor, 0.85) } }] }
        : null),
    },
    wordWrap: { position: 'absolute', top: MARK_SIZE + 16, width: 300, left: (MARK_SIZE - 300) / 2, alignItems: 'center' },
    wordmark: {
      fontFamily: t.fonts.displayBold,
      fontSize: 22,
      lineHeight: 28,
      letterSpacing: 8,
      paddingLeft: 8,
      textTransform: 'uppercase',
      color: t.isDark ? t.colors.foreground : t.colors.primary,
      textShadowColor: withAlpha(shadowColor, 0.9),
      textShadowOffset: { width: 0, height: 2 },
      textShadowRadius: 10,
    },
    slow: { position: 'absolute', left: 0, right: 0, bottom: 72, alignItems: 'center' },
  });
};
