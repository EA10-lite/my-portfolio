/**
 * "See all" lists for Home / Explore shortcuts. Everything comes from GET /api/landing
 * (the same arrays the web landing sections show).
 */
import { Redirect, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { FlatList, RefreshControl, StyleSheet, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  ChapterCard,
  ChapterCardSkeleton,
  CreatorCard,
  CreatorCardSkeleton,
  PublicationCard,
  PublicationCardSkeleton,
} from '@/components/content/cards';
import { StackHeader } from '@/components/navigation/StackHeader';
import { Button, SearchField, SkeletonGroup, Text } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { QK } from '@/lib/queryKeys';
import { genres, typeLabel } from '@/lib/publication';
import { useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import type { LandingData, Publication } from '@/services/types';
import { useTheme } from '@/theme';

type Kind = 'featured' | 'picks' | 'free' | 'fan' | 'completed' | 'trending' | 'chapters' | 'creators';

const CONFIG: Record<Kind, { title: string; search?: string; pick?: (d: LandingData) => Publication[] }> = {
  featured: { title: 'Featured', search: 'Search featured', pick: (d) => d.featuredPublications },
  picks: { title: 'Munkai picks', search: 'Search Munkai picks', pick: (d) => d.munkaiPicks },
  free: { title: 'Free to read', search: 'Search free to read', pick: (d) => d.freePublications },
  fan: { title: 'Fanfics', search: 'Search fanfics', pick: (d) => d.fanfics },
  completed: { title: 'Completed stories', search: 'Search completed stories', pick: (d) => d.completedPublications },
  trending: { title: 'Trending now', search: 'Search trending', pick: (d) => d.trendingPublications },
  chapters: { title: 'New chapters' },
  creators: { title: 'Top creators' },
};

export default function Browse() {
  const { kind: raw } = useLocalSearchParams<{ kind: string }>();
  // These have their own full screens now.
  if (raw === 'chapters') return <Redirect href="/chapters" />;
  if (raw === 'creators') return <Redirect href="/top-creators" />;
  return <BrowseList raw={raw} />;
}

function BrowseList({ raw }: { raw: string }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const kind = (raw in CONFIG ? raw : 'featured') as Kind;
  const cfg = CONFIG[kind];
  const { data, loading, error, refreshing, refetch } = useFetch(QK.landing, contentApi.landing);

  const cols = kind === 'chapters' ? 2 : kind === 'creators' ? 4 : 3;
  const gap = 12;
  const cardW = Math.floor((width - 40 - gap * (cols - 1)) / cols);

  const [q, setQ] = useState('');
  const needle = q.trim().toLowerCase();
  const all: unknown[] = !data
    ? []
    : kind === 'chapters'
      ? data.recentChapters
      : kind === 'creators'
        ? data.topCreators
        : (cfg.pick?.(data) ?? []);
  // Search within this section only (title, creator, genre, type) — instant, no network.
  const items = needle && cfg.search ? (all as Publication[]).filter((p) => matches(p, needle)) : all;

  const renderItem = ({ item }: { item: unknown }) => {
    if (kind === 'chapters') return <ChapterCard ch={item as LandingData['recentChapters'][number]} width={cardW} />;
    if (kind === 'creators') return <CreatorCard c={item as LandingData['topCreators'][number]} />;
    return <PublicationCard pub={item as Publication} width={cardW} free={kind === 'free'} />;
  };

  const skeleton = (i: number) =>
    kind === 'chapters' ? (
      <ChapterCardSkeleton key={i} width={cardW} />
    ) : kind === 'creators' ? (
      <CreatorCardSkeleton key={i} />
    ) : (
      <PublicationCardSkeleton key={i} width={cardW} />
    );

  return (
    <View style={[styles.root, { backgroundColor: t.colors.pageBackground }]}>
      <StackHeader title={cfg.title} />
      {cfg.search ? (
        <View style={styles.searchWrap}>
          <SearchField value={q} onChangeText={setQ} placeholder={cfg.search} />
        </View>
      ) : null}
      <FlatList
        key={kind}
        data={loading ? [] : items}
        numColumns={cols}
        keyExtractor={(it, i) => String((it as { id?: string | number }).id ?? i)}
        renderItem={renderItem}
        columnWrapperStyle={[styles.col, kind === 'creators' && { justifyContent: 'space-between' }]}
        contentContainerStyle={{ paddingTop: cfg.search ? 4 : 16, paddingBottom: insets.bottom + 24 }}
        keyboardDismissMode="on-drag"
        keyboardShouldPersistTaps="handled"
        ListEmptyComponent={
          loading ? (
            <SkeletonGroup>
              <View style={[styles.col, styles.wrap]}>{Array.from({ length: cols * 3 }, (_, i) => skeleton(i))}</View>
            </SkeletonGroup>
          ) : error ? (
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                {apiErrorMessage(error)}
              </Text>
              <Button title="Try again" variant="outline" onPress={refetch} />
            </View>
          ) : needle ? (
            <View style={styles.empty}>
              <Text variant="heading" align="center">
                No results for “{q.trim()}”
              </Text>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                Try a different title, creator or genre.
              </Text>
              <Button title="Clear search" variant="outline" onPress={() => setQ('')} />
            </View>
          ) : (
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                Nothing here yet.
              </Text>
            </View>
          )
        }
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={refetch} tintColor={t.colors.primary} colors={[t.colors.primary]} />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

function matches(p: Publication, needle: string) {
  const who = [p.username, p.author?.username, p.users?.username, p.firstName, p.lastName, p.author?.firstName, p.author?.lastName];
  return [p.name, typeLabel(p.publicationType), ...genres(p), ...who].some((v) => (v ?? '').toString().toLowerCase().includes(needle));
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  searchWrap: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 12 },
  col: { paddingHorizontal: 20, gap: 12, marginBottom: 18 },
  wrap: { flexWrap: 'wrap', flexDirection: 'row', rowGap: 18 },
  empty: { alignItems: 'center', gap: 12, paddingTop: 40, paddingHorizontal: 24 },
});
