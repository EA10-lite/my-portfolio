/**
 * TEMPORARY placeholder — the real Onboarding screen is next (mock first).
 * Exists only so the Splash has a first-launch destination to route to.
 */
import { router } from 'expo-router';
import React from 'react';
import { StyleSheet, View } from 'react-native';

import { Button, Screen, Text } from '@/components/ui';
import { setOnboardingSeen } from '@/lib/storage';

export default function OnboardingPlaceholder() {
  const finish = async () => {
    await setOnboardingSeen(true);
    router.replace('/home');
  };

  return (
    <Screen contentStyle={styles.center}>
      <Text variant="caption" align="center">
        Placeholder
      </Text>
      <Text variant="title" align="center">
        Onboarding
      </Text>
      <Text variant="bodySmall" color="mutedForeground" align="center">
        You were routed here because this is the first launch. The real screen comes next.
      </Text>
      <View style={styles.gap} />
      <Button title="Finish onboarding" fullWidth onPress={finish} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  center: { justifyContent: 'center', gap: 12 },
  gap: { height: 12 },
});
