/**
 * Help & FAQ — approved mock "Help & FAQ".
 * Web: app/company/faq. Accordion (one open at a time) + "Still have questions?" → Contact.
 */
import { router } from 'expo-router';
import { ChevronDown } from 'lucide-react-native';
import React, { useState } from 'react';
import { LayoutAnimation, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { Button, CutShape, Text } from '@/components/ui';
import { FAQ } from '@/content/faq';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic } from '@/lib/haptics';

export default function FaqScreen() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState<string | null>(FAQ[0].id);

  const toggle = (id: string) => {
    haptic.select().catch(() => {});
    LayoutAnimation.configureNext(LayoutAnimation.create(220, 'easeInEaseOut', 'opacity'));
    setOpen((cur) => (cur === id ? null : id));
  };

  return (
    <View style={styles.root}>
      <StackHeader title="Help & FAQ" />
      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 28 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.intro}>
          <Text variant="title" style={styles.h1}>
            Frequently asked questions
          </Text>
          <Text variant="bodySmall" color="mutedForeground">
            Everything you need to know about reading, writing, and earning on Munkai.
          </Text>
        </View>

        <View style={styles.group}>
          {FAQ.map((item, i) => {
            const isOpen = open === item.id;
            const Icon = item.icon;
            return (
              <View key={item.id} style={i > 0 && styles.divider}>
                <Pressable
                  onPress={() => toggle(item.id)}
                  accessibilityRole="button"
                  accessibilityState={{ expanded: isOpen }}
                  accessibilityLabel={item.question}
                  style={({ pressed }) => [styles.question, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.05) }]}
                >
                  <Icon size={20} color={t.colors.primary} strokeWidth={2} />
                  <Text variant="subtitle" color={isOpen ? 'primary' : 'foreground'} style={styles.qText}>
                    {item.question}
                  </Text>
                  <View style={isOpen && styles.chevOpen}>
                    <ChevronDown size={18} color={t.colors.mutedForeground} strokeWidth={2} />
                  </View>
                </Pressable>
                {isOpen ? (
                  <Text variant="bodySmall" color="mutedForeground" style={styles.answer} selectable>
                    {item.answer}
                  </Text>
                ) : null}
              </View>
            );
          })}
        </View>

        <CutShape cuts={t.cuts.card} fill={withAlpha(t.colors.primary, 0.06)} stroke={withAlpha(t.colors.primary, 0.14)} style={styles.cta}>
          <View style={styles.ctaText}>
            <Text variant="heading" style={styles.ctaTitle}>
              Still have questions?
            </Text>
            <Text variant="bodySmall" color="mutedForeground">
              Can’t find the answer you’re looking for? Chat to our friendly team.
            </Text>
          </View>
          <Button title="Get in touch" onPress={() => router.push('/contact')} />
        </CutShape>
      </ScrollView>
    </View>
  );
}

const makeStyles = (t: Theme) => {
  const groupBg = t.isDark ? withAlpha(t.colors.card, 0.9) : withAlpha(t.colors.background, 0.8);
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    scroll: { paddingHorizontal: 20 },
    intro: { paddingTop: 20, paddingBottom: 16, gap: 6 },
    h1: { fontSize: 26, lineHeight: 32 },
    group: {
      borderRadius: 14,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: groupBg,
      overflow: 'hidden',
    },
    divider: { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
    question: { minHeight: 56, paddingHorizontal: 16, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
    qText: { flex: 1, fontSize: 15, lineHeight: 20 },
    chevOpen: { transform: [{ rotate: '180deg' }] },
    answer: { paddingLeft: 48, paddingRight: 16, paddingBottom: 16, lineHeight: 21 },
    cta: { marginTop: 20, padding: 18, gap: 14 },
    ctaText: { gap: 4 },
    ctaTitle: { fontSize: 18 },
  });
};
