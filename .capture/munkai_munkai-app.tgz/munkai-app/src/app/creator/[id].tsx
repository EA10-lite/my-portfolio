/**
 * Creator page — approved mocks "Creator page" / "Creator · following".
 * Web (origin/main): app/creator/[id]. GET /api/publications/creator/:id,
 * GET/POST/DELETE /api/users/follow/:username.
 */
import { router, useLocalSearchParams } from 'expo-router';
import { Check, ChevronLeft, MoreHorizontal, Share2, UserPlus } from 'lucide-react-native';
import React, { useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, Share, StyleSheet, useWindowDimensions, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { PublicationCard, PublicationCardSkeleton } from '@/components/content/cards';
import { ProfileBanner } from '@/components/profile/ProfileBanner';
import { ReportSheet } from '@/components/publication/ReportSheet';
import { Avatar, Button, CutShape, Sheet, Skeleton, SkeletonGroup, Text, useToast, SearchField, SortToggle } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { WEB_URL } from '@/lib/config';
import { formatCompact, formatMonthYear } from '@/lib/format';
import { genres, PUBLICATION_TYPES, typeLabel } from '@/lib/publication';
import { useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import { profileApi } from '@/services/profile';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic, ImpactStyle } from '@/lib/haptics';

export default function CreatorScreen() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const { width } = useWindowDimensions();
  const { id } = useLocalSearchParams<{ id: string }>();
  const me = useSession((s) => s.user);
  const refreshProfile = useSession((s) => s.refreshProfile);

  const q = useFetch(`creator/${id}`, () => contentApi.creator(id));
  const c = q.data?.creator;
  const pubs = useMemo(() => q.data?.publications ?? [], [q.data]);
  const isMe = !!c && !!me && c.username === me.username;

  const [following, setFollowing] = useState<boolean | null>(null);
  const [followers, setFollowers] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [menu, setMenu] = useState(false);
  const [report, setReport] = useState(false);
  const [tab, setTab] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<'chapters' | 'name'>('chapters');

  useEffect(() => {
    if (!c?.username || isMe) return;
    profileApi
      .isFollowing(c.username)
      .then(setFollowing)
      .catch(() => setFollowing(false));
  }, [c?.username, isMe]);
  useEffect(() => {
    if (c) setFollowers(c.totalFollowers ?? 0);
  }, [c]);

  // Same filter as Top creators (search + sort), applied to this creator's works.
  const needle = query.trim().toLowerCase();
  const filtered = useMemo(() => {
    let l = needle
      ? pubs.filter((p) => [p.name, typeLabel(p.publicationType), ...genres(p)].some((v) => (v ?? '').toLowerCase().includes(needle)))
      : pubs;
    l = [...l].sort((a, b) =>
      sort === 'name' ? (a.name ?? '').localeCompare(b.name ?? '') : (Number(b.totalChapters) || 0) - (Number(a.totalChapters) || 0),
    );
    return l;
  }, [pubs, needle, sort]);
  const tabs = useMemo(
    () =>
      PUBLICATION_TYPES.map((pt) => ({
        ...pt,
        total: pubs.filter((p) => (p.publicationType ?? '').toLowerCase() === pt.value).length,
        count: filtered.filter((p) => (p.publicationType ?? '').toLowerCase() === pt.value).length,
      })).filter((x) => x.total > 0),
    [pubs, filtered],
  );
  const active = tab && tabs.some((x) => x.value === tab) ? tab : tabs[0]?.value;
  const shown = active ? filtered.filter((p) => (p.publicationType ?? '').toLowerCase() === active) : filtered;
  const firstName = c?.firstName || (c?.username ? `@${c.username}` : 'this creator');

  const toggleFollow = async () => {
    if (!c) return;
    const next = !following;
    setBusy(true);
    haptic.impact(ImpactStyle.Light).catch(() => {});
    try {
      if (next) await profileApi.follow(c.username);
      else await profileApi.unfollow(c.username);
      setFollowing(next);
      setFollowers((n) => Math.max(0, (n ?? 0) + (next ? 1 : -1)));
      toast.success(next ? 'Following' : 'Unfollowed', `${next ? 'You are now following' : 'You unfollowed'} @${c.username}`);
      refreshProfile();
    } catch (err) {
      toast.error('Couldn’t update follow', apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const share = () => {
    if (!c) return;
    Share.share({ message: `@${c.username} on Munkai — ${WEB_URL}/creator/${c.username}` }).catch(() => {});
  };

  const cols = 3;
  const cardW = Math.floor((width - 40 - 12 * (cols - 1)) / cols);

  const notFound = !q.loading && !q.error && !!q.data && !c;
  if ((q.error && !c) || notFound) {
    return (
      <View style={[styles.root, styles.center]}>
        <Text variant="heading" align="center">
          {notFound ? 'Creator not found' : 'Couldn’t load this creator'}
        </Text>
        <Text variant="bodySmall" color="mutedForeground" align="center">
          {notFound ? 'This account may have been renamed or removed.' : apiErrorMessage(q.error)}
        </Text>
        <View style={styles.row}>
          <Button title="Go back" variant="outline" onPress={() => router.back()} />
          <Button title="Try again" onPress={q.refetch} />
        </View>
      </View>
    );
  }

  const header = (
    <SkeletonGroup>
      <ProfileBanner uri={c?.bannerImage} height={190 + insets.top - 44} />
      <View style={styles.identity}>
        <View style={styles.avatarRow}>
          <View
            style={[
              styles.avatarRing,
              { borderColor: t.colors.primary, backgroundColor: t.colors.pageBackground, shadowColor: t.colors.primary },
            ]}
          >
            {c ? (
              <Avatar uri={c.profileImage} firstName={c.firstName} lastName={c.lastName} seed={c.username} size={92} ghost="light" />
            ) : (
              <Skeleton width={92} height={92} radius={46} />
            )}
          </View>
          {c && !isMe ? (
            following === null ? (
              <Skeleton width={120} height={42} />
            ) : following ? (
              <Button
                title="Following"
                variant="outline"
                size="sm"
                onPress={toggleFollow}
                loading={busy}
                leftIcon={<Check size={16} color={t.colors.primary} strokeWidth={2.6} />}
                style={styles.follow}
              />
            ) : (
              <Button
                title="Follow"
                size="sm"
                onPress={toggleFollow}
                loading={busy}
                leftIcon={<UserPlus size={16} color={t.colors.onPrimary} strokeWidth={2.4} />}
                style={styles.follow}
              />
            )
          ) : null}
        </View>
        {c ? (
          <>
            <Text variant="title" style={styles.name}>
              {`${c.firstName ?? ''} ${c.lastName ?? ''}`.trim() || c.username}
            </Text>
            <View style={styles.meta}>
              <Text variant="subtitle" color="primary" style={styles.metaText}>
                @{c.username}
              </Text>
              {formatMonthYear(c.createdAt) ? (
                <>
                  <View style={[styles.dot, { backgroundColor: t.colors.mutedForeground }]} />
                  <Text variant="bodySmall" color="mutedForeground">
                    Joined {formatMonthYear(c.createdAt)}
                  </Text>
                </>
              ) : null}
            </View>
            <CutShape
              cuts={{ tl: 6, br: 6 }}
              fill={withAlpha(t.colors.primary, 0.12)}
              stroke={withAlpha(t.colors.primary, 0.3)}
              style={styles.role}
            >
              <Text variant="caption" color="primary">
                {c.isTranslator ? 'Translator' : c.role && c.role.toLowerCase() !== 'user' ? c.role : 'Creator'}
              </Text>
            </CutShape>
          </>
        ) : (
          <View style={{ gap: 8, marginTop: 12 }}>
            <Skeleton width={180} height={26} />
            <Skeleton width={140} height={14} />
          </View>
        )}
      </View>

      <View style={[styles.stats, { borderColor: withAlpha(t.colors.primary, 0.1) }]}>
        {[
          ['Publications', c ? formatCompact(c.totalPublications ?? pubs.length) : null],
          ['Chapters', c ? formatCompact(c.totalChapters ?? 0) : null],
          ['Followers', c ? formatCompact(followers ?? 0) : null],
        ].map(([label, value], i) => (
          <View key={label} style={[styles.stat, i > 0 && { borderLeftWidth: 1, borderLeftColor: withAlpha(t.colors.primary, 0.12) }]}>
            {value === null ? (
              <Skeleton width={36} height={22} />
            ) : (
              <Text style={[styles.statValue, { color: t.colors.primary }]}>{value}</Text>
            )}
            <Text variant="caption" color="mutedForeground">
              {label}
            </Text>
          </View>
        ))}
      </View>

      {pubs.length > 1 ? (
        <View style={styles.filterBar}>
          <SearchField
            value={query}
            onChangeText={setQuery}
            placeholder="Search works"
            accessibilityLabel={`Search ${firstName}’s works`}
            style={styles.flex}
          />
          <SortToggle
            value={sort}
            onChange={setSort}
            options={[
              { value: 'chapters', label: 'Most chapters' },
              { value: 'name', label: 'A–Z' },
            ]}
          />
        </View>
      ) : null}
      {tabs.length > 1 ? (
        <View style={[styles.tabs, { borderBottomColor: withAlpha(t.colors.primary, 0.1) }]} accessibilityRole="tablist">
          {tabs.map((x) => {
            const on = x.value === active;
            return (
              <Pressable
                key={x.value}
                onPress={() => setTab(x.value)}
                accessibilityRole="tab"
                accessibilityState={{ selected: on }}
                style={[styles.tab, on && { borderBottomColor: t.colors.primary }]}
              >
                <Text variant="subtitle" color={on ? 'foreground' : 'mutedForeground'} style={styles.tabText}>
                  {x.label} {x.count}
                </Text>
              </Pressable>
            );
          })}
        </View>
      ) : (
        <View style={{ height: 12 }} />
      )}
      <View style={{ height: 16 }} />
    </SkeletonGroup>
  );

  return (
    <View style={styles.root}>
      <FlatList
        data={q.loading ? [] : shown}
        keyboardDismissMode="on-drag"
        keyboardShouldPersistTaps="handled"
        keyExtractor={(p) => String(p.id)}
        numColumns={cols}
        columnWrapperStyle={styles.col}
        ListHeaderComponent={header}
        renderItem={({ item }) => <PublicationCard pub={item} width={cardW} />}
        ListEmptyComponent={
          q.loading ? (
            <SkeletonGroup>
              <View style={styles.skelGrid}>
                {Array.from({ length: 6 }, (_, i) => (
                  <PublicationCardSkeleton key={i} width={cardW} />
                ))}
              </View>
            </SkeletonGroup>
          ) : needle && pubs.length ? (
            <View style={styles.noMatch}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                No works match “{query.trim()}”
              </Text>
              <Button title="Clear search" variant="outline" onPress={() => setQuery('')} />
            </View>
          ) : (
            <Text variant="bodySmall" color="mutedForeground" align="center" style={styles.empty}>
              {isMe ? 'You haven’t published anything yet.' : 'This creator hasn’t shared a work yet. Follow along to know when they do.'}
            </Text>
          )
        }
        contentContainerStyle={{ paddingBottom: insets.bottom + 32 }}
        refreshControl={
          <RefreshControl refreshing={q.refreshing} onRefresh={q.refetch} tintColor={t.colors.primary} progressViewOffset={insets.top} />
        }
        showsVerticalScrollIndicator={false}
      />
      <View style={[styles.topBar, { top: insets.top + 6 }]} pointerEvents="box-none">
        <Glass label="Back" onPress={() => (router.canGoBack() ? router.back() : router.replace('/home'))}>
          <ChevronLeft size={24} color="#F2F2F2" />
        </Glass>
        <View style={{ flex: 1 }} pointerEvents="none" />
        <Glass label="Share" onPress={share}>
          <Share2 size={19} color="#F2F2F2" />
        </Glass>
        {!isMe ? (
          <Glass label="More" onPress={() => setMenu(true)}>
            <MoreHorizontal size={20} color="#F2F2F2" />
          </Glass>
        ) : null}
      </View>
      <Sheet visible={menu} onClose={() => setMenu(false)}>
        <Pressable
          onPress={() => {
            setMenu(false);
            setTimeout(() => setReport(true), 300);
          }}
          style={styles.menuRow}
          accessibilityRole="button"
        >
          <Text variant="subtitle" color="danger">
            Report creator
          </Text>
        </Pressable>
      </Sheet>
      <ReportSheet
        target={report && c ? { type: 'creator', id: Number(c.userId ?? c.id ?? 0), label: 'creator' } : null}
        onClose={() => setReport(false)}
      />
    </View>
  );
}

function Glass({ label, onPress, children }: { label: string; onPress: () => void; children: React.ReactNode }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [glass.btn, pressed && { opacity: 0.7 }]}
    >
      {children}
    </Pressable>
  );
}
const glass = StyleSheet.create({
  btn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,43,0.55)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
  },
});

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    center: { alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 32 },
    row: { flexDirection: 'row', gap: 10, marginTop: 8 },
    identity: { paddingHorizontal: 20, marginTop: -52 },
    avatarRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
    avatarRing: {
      padding: 3,
      borderRadius: 52,
      borderWidth: 2,
      shadowOpacity: 0.45,
      shadowRadius: 14,
      shadowOffset: { width: 0, height: 0 },
    },
    follow: { marginBottom: 4, minWidth: 120 },
    name: { fontSize: 26, lineHeight: 32, marginTop: 12 },
    meta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 2 },
    metaText: { fontSize: 14 },
    dot: { width: 4, height: 4, borderRadius: 2 },
    role: { alignSelf: 'flex-start', marginTop: 10, paddingHorizontal: 10, paddingVertical: 4 },
    stats: { flexDirection: 'row', marginHorizontal: 20, marginTop: 18, paddingVertical: 14, borderTopWidth: 1, borderBottomWidth: 1 },
    stat: { flex: 1, alignItems: 'center', gap: 2 },
    statValue: { fontFamily: t.fonts.displayBold, fontSize: 22, lineHeight: 28 },
    filterBar: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, paddingTop: 18 },
    flex: { flex: 1 },
    noMatch: { alignItems: 'center', gap: 12, paddingTop: 28, paddingHorizontal: 32 },
    tabs: { flexDirection: 'row', gap: 22, paddingHorizontal: 20, paddingTop: 16, borderBottomWidth: 1 },
    tab: { paddingBottom: 10, borderBottomWidth: 3, borderBottomColor: 'transparent' },
    tabText: { fontSize: 14 },
    col: { paddingHorizontal: 20, gap: 12, marginBottom: 18 },
    skelGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 20, columnGap: 12, rowGap: 18 },
    empty: { padding: 32 },
    topBar: { position: 'absolute', left: 12, right: 12, flexDirection: 'row', gap: 8 },
    menuRow: { minHeight: 52, justifyContent: 'center', paddingHorizontal: 4 },
  });
