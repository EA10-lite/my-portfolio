/**
 * About Munkai — approved mock "About". Copy from the web app/company/about (origin/main).
 * Careers and Leadership are intentionally not in the app.
 */
import Constants from 'expo-constants';
import { router } from 'expo-router';
import { BookOpen, ChevronRight, Coins, Globe, MessageCircle, PenLine, Users, type LucideIcon } from 'lucide-react-native';
import React, { useId } from 'react';
import { Linking, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Svg, { Defs, LinearGradient, Rect, Stop } from 'react-native-svg';

import { MunkaiMark } from '@/components/brand/MunkaiMark';
import { Badge } from '@/components/content/cards';
import { Cover } from '@/components/content/Cover';
import { StackHeader } from '@/components/navigation/StackHeader';
import { CutShape, Text } from '@/components/ui';
import { WEB_URL } from '@/lib/config';
import { openExternal } from '@/lib/links';
import { QK } from '@/lib/queryKeys';
import { useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';

const WHY: { icon: LucideIcon; title: string; body: string }[] = [
  { icon: PenLine, title: 'Empowering creators', body: 'Full control of your work, no gatekeepers or barriers to entry.' },
  { icon: Coins, title: 'Rewarding everyone', body: 'Earn as you engage — creating or reading, participation pays.' },
  { icon: Users, title: 'Community driven', body: 'Grow an audience, sell directly to fans, meet your people.' },
  { icon: BookOpen, title: 'Gateway to knowledge', body: 'Stories that educate and inspire, and a library to explore.' },
];

const SOCIALS = [
  { label: 'X (Twitter)', url: 'https://twitter.com/munkaiart' },
  { label: 'Instagram', url: 'https://instagram.com/munkaiart' },
  { label: 'TikTok', url: 'https://www.tiktok.com/@munkai.art' },
  { label: 'Discord', url: 'https://discord.gg/NbrYjNBf3J' },
];

export default function About() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const gid = `ab${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  // Reuse the cached landing feed for the hero art (no extra request when Home has loaded).
  const landing = useFetch(QK.landing, contentApi.landing);
  const heroUri = landing.data?.featuredPublications.find((p) => p.coverPhoto)?.coverPhoto;
  const version = Constants.expoConfig?.version ?? '1.0.0';

  return (
    <View style={styles.root}>
      <StackHeader title="About Munkai" />
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 28 }} showsVerticalScrollIndicator={false}>
        <View style={styles.heroWrap}>
          <Cover uri={heroUri} width="100%" height={230}>
            <Svg width="100%" height={230} style={StyleSheet.absoluteFill} pointerEvents="none">
              <Defs>
                <LinearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
                  <Stop offset="0" stopColor="#00002B" stopOpacity={0.35} />
                  <Stop offset="1" stopColor="#00002B" stopOpacity={0.95} />
                </LinearGradient>
              </Defs>
              <Rect x="0" y="0" width="100%" height={230} fill={`url(#${gid})`} />
            </Svg>
            <View style={styles.heroBody}>
              <Badge label="Our story" />
              <Text variant="display" style={styles.heroTitle}>
                Where every word counts
              </Text>
              <Text variant="bodySmall" style={styles.heroText}>
                A Read-to-Earn platform where creativity, storytelling and innovation converge to empower creators and readers alike.
              </Text>
            </View>
          </Cover>
        </View>

        <Text variant="title" style={styles.h2}>
          Redefining literature
        </Text>
        <Text variant="body" color="mutedForeground" style={styles.p}>
          Munkai is designed for literature enthusiasts, comic fans, digital creators, writers and artists. We are building a thriving
          ecosystem where you can discover, collect, read and share comics, poetry and short stories.
        </Text>
        <Text variant="body" color="mutedForeground" style={[styles.p, styles.pGap]}>
          Our goal is simple: create a world where creativity is rewarded and literary works are celebrated.
        </Text>

        <Text variant="title" style={styles.h2}>
          Why Munkai?
        </Text>
        <Text variant="bodySmall" color="mutedForeground" style={[styles.p, styles.sub]}>
          Bridging the gap between creators and their audience.
        </Text>
        <View style={styles.grid}>
          {WHY.map(({ icon: Icon, title, body }) => (
            <CutShape
              key={title}
              cuts={t.cuts.card}
              fill={withAlpha(t.colors.primary, 0.06)}
              stroke={withAlpha(t.colors.primary, 0.14)}
              style={styles.tile}
            >
              <View style={styles.tileIcon}>
                <Icon size={18} color={t.colors.primary} strokeWidth={2} />
              </View>
              <Text variant="subtitle" style={styles.tileTitle}>
                {title}
              </Text>
              <Text variant="bodySmall" color="mutedForeground" style={styles.tileBody}>
                {body}
              </Text>
            </CutShape>
          ))}
        </View>

        <CutShape cuts={t.cuts.card} fill={t.colors.card} stroke={withAlpha(t.colors.primary, 0.18)} style={styles.vision}>
          <MunkaiMark size={34} color={t.colors.foreground} />
          <Text variant="label">Our vision</Text>
          <Text variant="body" align="center" style={styles.quote}>
            “To redefine how literature is experienced and valued. A future where storytelling thrives, creators flourish, and readers
            discover the limitless power of imagination.”
          </Text>
        </CutShape>

        <View style={styles.group}>
          <Row icon={MessageCircle} label="Contact us" onPress={() => router.push('/contact')} />
          <Row icon={Globe} label="munkai.art" onPress={() => openExternal(WEB_URL).catch(() => {})} divider />
        </View>

        <Text variant="caption" style={styles.followLabel}>
          FOLLOW US
        </Text>
        <View style={styles.socials}>
          {SOCIALS.map((s) => (
            <Pressable
              key={s.label}
              onPress={() => Linking.openURL(s.url).catch(() => {})}
              accessibilityRole="link"
              accessibilityLabel={`Munkai on ${s.label}`}
              style={({ pressed }) => [styles.social, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.16) }]}
            >
              <Text variant="subtitle" style={styles.socialText}>
                {s.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text variant="caption" align="center" style={styles.version}>
          Munkai v{version}
        </Text>
      </ScrollView>
    </View>
  );
}

function Row({ icon: Icon, label, onPress, divider }: { icon: LucideIcon; label: string; onPress: () => void; divider?: boolean }) {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={({ pressed }) => [styles.row, divider && styles.divider, pressed && { backgroundColor: withAlpha(t.colors.primary, 0.05) }]}
    >
      <Icon size={18} color={t.colors.primary} strokeWidth={2} />
      <Text variant="subtitle" style={styles.rowText}>
        {label}
      </Text>
      <ChevronRight size={16} color={t.colors.mutedForeground} />
    </Pressable>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    heroWrap: { marginHorizontal: 20, marginTop: 12 },
    heroBody: { position: 'absolute', left: 18, right: 18, bottom: 18, gap: 8, alignItems: 'flex-start' },
    heroTitle: { fontSize: 26, lineHeight: 30, color: '#F2F2F2' },
    heroText: { color: '#C9CCD6', lineHeight: 19 },
    h2: { marginHorizontal: 20, marginTop: 26, marginBottom: 8, fontSize: 20 },
    p: { marginHorizontal: 20, lineHeight: 23 },
    pGap: { marginTop: 12 },
    sub: { marginTop: -4, marginBottom: 12 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, paddingHorizontal: 20 },
    tile: { width: '48%', flexGrow: 1, padding: 14, gap: 8 },
    tileIcon: {
      width: 36,
      height: 36,
      borderRadius: 18,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: withAlpha(t.colors.primary, 0.14),
    },
    tileTitle: { fontSize: 15 },
    tileBody: { fontSize: 12, lineHeight: 17 },
    vision: { marginHorizontal: 20, marginTop: 26, padding: 20, alignItems: 'center', gap: 10 },
    quote: { fontStyle: 'italic', lineHeight: 24 },
    group: {
      marginHorizontal: 20,
      marginTop: 18,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: withAlpha(t.colors.primary, 0.1),
      backgroundColor: t.colors.card,
      overflow: 'hidden',
    },
    row: { minHeight: 52, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', gap: 12 },
    divider: { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) },
    rowText: { flex: 1, fontSize: 15 },
    followLabel: { marginHorizontal: 20, marginTop: 22, marginBottom: 10, letterSpacing: 1 },
    socials: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingHorizontal: 20 },
    social: {
      height: 40,
      paddingHorizontal: 14,
      borderRadius: 20,
      justifyContent: 'center',
      backgroundColor: withAlpha(t.colors.primary, 0.08),
    },
    socialText: { fontSize: 13 },
    version: { marginTop: 22, letterSpacing: 1 },
  });
