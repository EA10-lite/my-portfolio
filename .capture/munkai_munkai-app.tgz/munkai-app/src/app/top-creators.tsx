/**
 * Top creators — approved mock "Top creators". GET /api/creators/top (paginated),
 * follow state from GET /api/users/following, POST/DELETE /api/users/follow/:username.
 */
import React, { useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { StackHeader } from '@/components/navigation/StackHeader';
import { Avatar, Button, Skeleton, SkeletonGroup, Text, useToast, SearchField, SortToggle } from '@/components/ui';
import { apiErrorMessage } from '@/lib/api';
import { openCreator } from '@/lib/publication';
import { QK } from '@/lib/queryKeys';
import { useFetch } from '@/lib/useFetch';
import { contentApi } from '@/services/content';
import { profileApi } from '@/services/profile';
import type { TopCreator } from '@/services/types';
import { useSession } from '@/store/session';
import { useTheme, useThemedStyles, withAlpha, type Theme } from '@/theme';
import { haptic, ImpactStyle } from '@/lib/haptics';

const PODIUM = ['#FFC400', '#C0C8D6', '#E3945A'];

export default function TopCreators() {
  const t = useTheme();
  const styles = useThemedStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const toast = useToast();
  const me = useSession((s) => s.user);
  const creators = useFetch(QK.searchCreators, contentApi.topCreators);
  const followingQ = useFetch('users/following', profileApi.following);
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<'works' | 'name'>('works');
  const [overrides, setOverrides] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState<string | null>(null);

  const followingSet = useMemo(() => new Set((followingQ.data ?? []).map((u) => u.username)), [followingQ.data]);
  const isFollowing = (u: string) => overrides[u] ?? followingSet.has(u);

  const ranked = useMemo(
    () => [...(creators.data ?? [])].sort((a, b) => (b.totalPublications ?? 0) - (a.totalPublications ?? 0)),
    [creators.data],
  );
  const term = q.trim().toLowerCase().replace(/^@/, '');
  const list = useMemo(() => {
    let l = ranked.map((c, i) => ({ c, rank: i + 1 }));
    if (term) l = l.filter(({ c }) => `${c.firstName} ${c.lastName} ${c.username}`.toLowerCase().includes(term));
    if (sort === 'name') l = [...l].sort((a, b) => `${a.c.firstName}${a.c.lastName}`.localeCompare(`${b.c.firstName}${b.c.lastName}`));
    return l;
  }, [ranked, term, sort]);
  const showPodium = !term && sort === 'works' && list.length >= 3;
  const rest = showPodium ? list.slice(3) : list;

  const toggle = async (c: TopCreator) => {
    const next = !isFollowing(c.username);
    setBusy(c.username);
    haptic.impact(ImpactStyle.Light).catch(() => {});
    try {
      if (next) await profileApi.follow(c.username);
      else await profileApi.unfollow(c.username);
      setOverrides((o) => ({ ...o, [c.username]: next }));
    } catch (err) {
      toast.error('Couldn’t update follow', apiErrorMessage(err));
    } finally {
      setBusy(null);
    }
  };

  const followBtn = (c: TopCreator) =>
    me && c.username !== me.username ? (
      <Button
        title={isFollowing(c.username) ? 'Following' : 'Follow'}
        size="sm"
        variant={isFollowing(c.username) ? 'outline' : 'primary'}
        loading={busy === c.username}
        onPress={() => toggle(c)}
        style={styles.follow}
      />
    ) : null;

  const header = showPodium ? (
    <View style={styles.podium}>
      {[1, 0, 2].map((i) => {
        const { c } = list[i];
        const size = i === 0 ? 88 : 68;
        const color = PODIUM[i];
        return (
          <Pressable
            key={c.username}
            onPress={() => openCreator(c)}
            accessibilityRole="button"
            accessibilityLabel={`Rank ${i + 1}, ${c.firstName} ${c.lastName}`}
            style={styles.pod}
          >
            <View style={[styles.podRing, { borderColor: color, shadowColor: color }]}>
              <Avatar uri={c.profileImage} firstName={c.firstName} lastName={c.lastName} seed={c.username} size={size} />
              <View style={[styles.podRank, { backgroundColor: color }]}>
                <Text style={styles.podRankText}>{i + 1}</Text>
              </View>
            </View>
            <Text variant="subtitle" numberOfLines={2} align="center" style={styles.podName}>
              {`${c.firstName} ${c.lastName}`.trim() || c.username}
            </Text>
            <Text variant="bodySmall" color="mutedForeground" style={styles.small}>
              {c.totalPublications ?? 0} works
            </Text>
            <View style={[styles.podBar, { height: [80, 56, 44][i], borderTopColor: color, backgroundColor: withAlpha(color, 0.12) }]} />
          </Pressable>
        );
      })}
    </View>
  ) : null;

  return (
    <View style={styles.root}>
      <StackHeader title="Top creators" />
      <View style={styles.bar}>
        <SearchField value={q} onChangeText={setQ} placeholder="Find a creator" style={styles.flex} />
        <SortToggle
          value={sort}
          onChange={setSort}
          options={[
            { value: 'works', label: 'Most works' },
            { value: 'name', label: 'A–Z' },
          ]}
        />
      </View>

      {creators.loading ? (
        <SkeletonGroup>
          <View style={styles.podium}>
            {[68, 88, 68].map((s, i) => (
              <View key={i} style={styles.pod}>
                <Skeleton width={s} height={s} radius={s / 2} />
                <Skeleton width={70} height={12} radius={3} style={{ marginTop: 10 }} />
              </View>
            ))}
          </View>
          {[0, 1, 2, 3].map((i) => (
            <View key={i} style={styles.row}>
              <Skeleton width={46} height={46} radius={23} />
              <View style={{ flex: 1, gap: 6 }}>
                <Skeleton width="50%" height={13} radius={3} />
                <Skeleton width="35%" height={10} radius={3} />
              </View>
            </View>
          ))}
        </SkeletonGroup>
      ) : (
        <FlatList
          data={rest}
          keyExtractor={({ c }) => c.username}
          ListHeaderComponent={header}
          renderItem={({ item: { c, rank }, index }) => (
            <View style={[styles.row, index > 0 && { borderTopWidth: 1, borderTopColor: withAlpha(t.colors.primary, 0.08) }]}>
              <Pressable
                onPress={() => openCreator(c)}
                accessibilityRole="button"
                accessibilityLabel={`Rank ${rank}, ${c.firstName} ${c.lastName}`}
                style={({ pressed }) => [styles.rowMain, pressed && { opacity: 0.8 }]}
              >
                <Text style={[styles.rank, { color: t.colors.mutedForeground }]}>{rank}</Text>
                <Avatar uri={c.profileImage} firstName={c.firstName} lastName={c.lastName} seed={c.username} size={46} />
                <View style={styles.flex}>
                  <Text variant="subtitle" numberOfLines={1} style={styles.name}>
                    {`${c.firstName} ${c.lastName}`.trim() || c.username}
                  </Text>
                  <Text variant="bodySmall" color="mutedForeground" numberOfLines={1} style={styles.small}>
                    @{c.username} · {c.totalPublications ?? 0} works
                  </Text>
                </View>
              </Pressable>
              {followBtn(c)}
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text variant="bodySmall" color="mutedForeground" align="center">
                {creators.error ? apiErrorMessage(creators.error) : 'No creators match.'}
              </Text>
              {creators.error ? <Button title="Try again" variant="outline" onPress={creators.refetch} /> : null}
            </View>
          }
          ListFooterComponent={followingQ.loading ? <ActivityIndicator style={{ padding: 16 }} color={t.colors.primary} /> : null}
          keyboardDismissMode="on-drag"
          contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}
          refreshControl={
            <RefreshControl
              refreshing={creators.refreshing}
              onRefresh={() => {
                creators.refetch();
                followingQ.reload();
              }}
              tintColor={t.colors.primary}
            />
          }
        />
      )}
    </View>
  );
}

const makeStyles = (t: Theme) =>
  StyleSheet.create({
    root: { flex: 1, backgroundColor: t.colors.pageBackground },
    flex: { flex: 1, minWidth: 0 },
    bar: { flexDirection: 'row', gap: 10, paddingHorizontal: 20, paddingTop: 12 },
    podium: { flexDirection: 'row', alignItems: 'flex-end', gap: 14, paddingHorizontal: 20, paddingTop: 26, paddingBottom: 8 },
    pod: { flex: 1, alignItems: 'center', gap: 4 },
    podRing: { padding: 3, borderRadius: 60, borderWidth: 2, shadowOpacity: 0.6, shadowRadius: 12, shadowOffset: { width: 0, height: 0 } },
    podRank: {
      position: 'absolute',
      bottom: -10,
      alignSelf: 'center',
      width: 26,
      height: 26,
      borderRadius: 13,
      alignItems: 'center',
      justifyContent: 'center',
    },
    podRankText: { fontFamily: 'Grandstander-Bold', fontSize: 15, lineHeight: 20, color: '#00002B' },
    podName: { fontSize: 14, lineHeight: 18, marginTop: 12 },
    podBar: { alignSelf: 'stretch', marginTop: 6, borderTopWidth: 2 },
    row: { minHeight: 70, marginHorizontal: 20, flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 10 },
    rowMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 14 },
    rank: { width: 22, fontFamily: 'Grandstander-Bold', fontSize: 16 },
    name: { fontSize: 15 },
    small: { fontSize: 12, lineHeight: 16, marginTop: 2 },
    follow: { minWidth: 100 },
    empty: { alignItems: 'center', gap: 12, paddingTop: 40, paddingHorizontal: 32 },
  });
