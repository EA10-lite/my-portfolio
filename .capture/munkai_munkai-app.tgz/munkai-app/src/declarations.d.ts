declare module '*.ttf' {
  const value: number;
  export default value;
}
declare module '*.png' {
  const value: number;
  export default value;
}
