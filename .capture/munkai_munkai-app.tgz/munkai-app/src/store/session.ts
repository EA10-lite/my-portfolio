import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';

import { removeAllOffline } from './offline';

import { camelize, onUnauthorized } from '@/lib/api';
import { clearReadingHistory } from '@/lib/readingHistory';
import { clearToken, loadToken, saveToken } from '@/lib/secureToken';
import { clearFetchCache } from '@/lib/useFetch';
import { clearInfiniteCache } from '@/lib/useInfinite';
import { authApi } from '@/services/auth';
import type { User } from '@/services/types';

const USER_KEY = 'munkai_user';

type SessionState = {
  user: User | null;
  /** True once the saved session has been read from the device. */
  hydrated: boolean;
  isAuthenticated: boolean;
  hydrate: () => Promise<void>;
  /** Store a fresh login (token may be absent if the API relies on cookies). */
  signIn: (user: User, token?: string) => Promise<void>;
  setUser: (user: User) => void;
  refreshProfile: () => Promise<void>;
  signOut: (opts?: { remote?: boolean }) => Promise<void>;
};

let hydrating: Promise<void> | null = null;

export const useSession = create<SessionState>((set, get) => ({
  user: null,
  hydrated: false,
  isAuthenticated: false,

  hydrate: () => {
    // One shared run — the splash and deep links (notifications) both call this.
    hydrating ??= (async () => {
      const [token, rawUser] = await Promise.all([loadToken(), AsyncStorage.getItem(USER_KEY).catch(() => null)]);
      let user: User | null = null;
      try {
        user = rawUser ? camelize<User>(JSON.parse(rawUser)) : null;
      } catch {
        user = null;
      }
      // Logged in = we have the saved user. The token may be absent when the API uses
      // cookies; if the session is actually dead, the profile refresh 401s and signs out.
      void token;
      set({ user, isAuthenticated: !!user, hydrated: true });
      // Refresh in the background — never blocks launch.
      if (user) get().refreshProfile();
    })();
    return hydrating;
  },

  signIn: async (user, token) => {
    if (token) await saveToken(token);
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(user)).catch(() => {});
    set({ user, isAuthenticated: true });
  },

  setUser: (user) => {
    AsyncStorage.setItem(USER_KEY, JSON.stringify(user)).catch(() => {});
    set({ user });
  },

  refreshProfile: async () => {
    try {
      const user = await authApi.profile();
      if (user) get().setUser(user);
    } catch {
      // Offline or invalid session — the 401 listener handles the latter.
    }
  },

  signOut: async ({ remote = true } = {}) => {
    if (remote) authApi.logout().catch(() => {});
    await clearToken();
    await AsyncStorage.removeItem(USER_KEY).catch(() => {});
    clearFetchCache();
    clearInfiniteCache();
    await clearReadingHistory();
    removeAllOffline();
    set({ user: null, isAuthenticated: false });
  },
}));

/** Session invalidated by the server → sign out locally. Returns unsubscribe. */
export function watchSessionInvalidation(onInvalid: () => void) {
  return onUnauthorized(() => {
    if (!useSession.getState().isAuthenticated) return;
    useSession.getState().signOut({ remote: false });
    onInvalid();
  });
}
