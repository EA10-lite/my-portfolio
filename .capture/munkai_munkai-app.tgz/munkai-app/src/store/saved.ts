import { create } from 'zustand';

import { toast } from '@/components/ui/Toast';
import { apiErrorMessage } from '@/lib/api';
import { contentApi } from '@/services/content';
import type { Publication } from '@/services/types';

import { useSession } from './session';
import { haptic, ImpactStyle } from '@/lib/haptics';

/** Optimistic saved/unsaved overrides on top of `user.savedPublications`. */
const useOverrides = create<{ map: Record<string, boolean>; set: (id: string, v: boolean | undefined) => void }>((set) => ({
  map: {},
  set: (id, v) =>
    set((s) => {
      const map = { ...s.map };
      if (v === undefined) delete map[id];
      else map[id] = v;
      return { map };
    }),
}));

export function useIsSaved(pub: Pick<Publication, 'id' | 'isSaved'>) {
  const id = String(pub.id);
  const override = useOverrides((s) => s.map[id]);
  const inProfile = useSession((s) => !!s.user?.savedPublications?.some((p) => String(p.id) === id));
  if (override !== undefined) return override;
  return inProfile || !!pub.isSaved;
}

export async function toggleSaved(pub: Pick<Publication, 'id' | 'name'>, currentlySaved: boolean) {
  const id = String(pub.id);
  const next = !currentlySaved;
  useOverrides.getState().set(id, next);
  haptic.impact(ImpactStyle.Light).catch(() => {});
  try {
    if (next) await contentApi.save(pub.id);
    else await contentApi.unsave(pub.id);
    toast.success(next ? 'Saved to Library' : 'Removed from saved');
    await useSession.getState().refreshProfile();
    useOverrides.getState().set(id, undefined);
  } catch (err) {
    useOverrides.getState().set(id, undefined);
    toast.error(next ? 'Could not save' : 'Could not remove', apiErrorMessage(err));
  }
}
