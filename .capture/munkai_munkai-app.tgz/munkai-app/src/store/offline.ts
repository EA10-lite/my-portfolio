/**
 * Offline reading — chapters you own (or free ones) saved on the device.
 *
 * Layout: <documents>/offline/<chapterId>-<stamp>/ holds content.json (the read response plus the
 * *file names* of downloaded pages / PDF — never absolute paths, which change on iOS app updates)
 * and the files themselves. offline/index.json lists what's saved and which folder is current.
 * A re-download goes into a new folder and only replaces the old one once it has fully succeeded.
 */
import { Directory, File, Paths } from 'expo-file-system';
import { Platform } from 'react-native';
import { create } from 'zustand';

import { chaptersApi, parseChapterContent } from '@/services/chapters';
import type { ChapterContent, ChapterIndexEntry } from '@/services/types';

export const OFFLINE_SUPPORTED = Platform.OS === 'ios' || Platform.OS === 'android';

export type SavedChapter = {
  chapterId: string;
  publicationId: string;
  chapterNumber: number;
  name?: string | null;
  editCount: number;
  kind: 'text' | 'images' | 'pdf';
  bytes: number;
  savedAt: number;
  /** Folder name under offline/. */
  dir: string;
};
export type SavedPublication = { id: string; name: string; coverPhoto?: string | null; publicationType?: string };
type Index = {
  chapters: Record<string, SavedChapter>;
  publications: Record<string, SavedPublication>;
  /** Chapters this device can't keep offline (PDFs on Android), by editCount — so they don't block "downloaded". */
  unsupported: Record<string, number>;
};
type Job = { publicationId: string; done: number; total: number; failed: number; token: number };
type State = Index & { ready: boolean; jobs: Record<string, Job>; busy: Record<string, true> };

type Stored = SavedFileRefs & { chapter: ChapterContent };
type SavedFileRefs = { pages?: string[]; pdf?: string };

export const useOffline = create<State>(() => ({ ready: false, chapters: {}, publications: {}, unsupported: {}, jobs: {}, busy: {} }));

const root = () => new Directory(Paths.document, 'offline');
const indexFile = () => new File(root(), 'index.json');
const folder = (name: string) => new Directory(root(), name);

/** Bumped by every removal / sign-out so downloads already in flight don't write themselves back. */
let generation = 0;
let tokenSeq = 0;
const inFlight = new Map<string, Promise<boolean>>();

function safeDelete(d: Directory | File) {
  try {
    if (d.exists) d.delete();
  } catch {
    // ignore
  }
}

function persist() {
  if (!OFFLINE_SUPPORTED) return;
  const { chapters, publications, unsupported } = useOffline.getState();
  try {
    root().create({ idempotent: true, intermediates: true });
    indexFile().write(JSON.stringify({ chapters, publications, unsupported }));
  } catch (e) {
    if (__DEV__) console.warn('[Munkai] offline index write failed', e);
  }
}

let loading: Promise<void> | null = null;
export function hydrateOffline() {
  if (!OFFLINE_SUPPORTED) {
    useOffline.setState({ ready: true });
    return Promise.resolve();
  }
  if (!loading) {
    const gen = generation;
    loading = (async () => {
      try {
        const f = indexFile();
        if (f.exists && gen === generation) {
          const data = JSON.parse(await f.text()) as Partial<Index>;
          if (gen === generation) {
            // Merge: anything saved while we were loading wins.
            useOffline.setState((s) => ({
              chapters: { ...(data.chapters ?? {}), ...s.chapters },
              publications: { ...(data.publications ?? {}), ...s.publications },
              unsupported: { ...(data.unsupported ?? {}), ...s.unsupported },
            }));
          }
        }
      } catch {
        // corrupt index → start fresh
      }
      useOffline.setState({ ready: true });
    })();
  }
  return loading;
}

const extFrom = (url: string, fallback: string) => {
  const m = url.split('?')[0].match(/\.([a-zA-Z0-9]{2,5})$/);
  return (m ? m[1] : fallback).toLowerCase();
};

function dirSize(dir: Directory): number {
  let n = 0;
  for (const item of dir.list()) n += item instanceof File ? (item.size ?? 0) : dirSize(item as Directory);
  return n;
}

/** Downloads one chapter. Resolves false when it can't be kept on this device (PDFs on Android) or was cancelled. */
export function downloadChapter(chapterId: string | number, pub: SavedPublication): Promise<boolean> {
  if (!OFFLINE_SUPPORTED) return Promise.resolve(false);
  const id = String(chapterId);
  const running = inFlight.get(id);
  if (running) return running;
  const task = doDownload(id, pub).finally(() => inFlight.delete(id));
  inFlight.set(id, task);
  return task;
}

async function doDownload(id: string, pub: SavedPublication): Promise<boolean> {
  const gen = generation;
  useOffline.setState((s) => ({ busy: { ...s.busy, [id]: true } }));
  const name = `${id}-${Date.now()}`;
  const dir = folder(name);
  try {
    const ch = await chaptersApi.read(id);
    const parsed = parseChapterContent(ch.content);
    const editCount = Number(ch.editCount) || 0;
    if (parsed.kind === 'pdf' && Platform.OS === 'android') {
      // No offline PDF viewer on Android — remember that so it doesn't count as "missing".
      if (gen === generation) {
        useOffline.setState((s) => ({ unsupported: { ...s.unsupported, [id]: editCount } }));
        persist();
      }
      return false;
    }
    dir.create({ intermediates: true, idempotent: true });

    const refs: SavedFileRefs = {};
    if (parsed.kind === 'images') {
      refs.pages = [];
      for (let i = 0; i < parsed.pages.length; i++) {
        if (gen !== generation) throw new Error('cancelled');
        const fileName = `${String(i + 1).padStart(3, '0')}.${extFrom(parsed.pages[i], 'jpg')}`;
        await File.downloadFileAsync(parsed.pages[i], new File(dir, fileName), { idempotent: true });
        refs.pages.push(fileName);
      }
    } else if (parsed.kind === 'pdf') {
      await File.downloadFileAsync(parsed.url, new File(dir, 'chapter.pdf'), { idempotent: true });
      refs.pdf = 'chapter.pdf';
    }
    const stored: Stored = { ...refs, chapter: ch };
    new File(dir, 'content.json').write(JSON.stringify(stored));

    // Removed or signed out while downloading → throw the result away.
    if (gen !== generation) {
      safeDelete(dir);
      return false;
    }
    const previous = useOffline.getState().chapters[id];
    const entry: SavedChapter = {
      chapterId: id,
      publicationId: String(pub.id),
      chapterNumber: ch.chapterNumber,
      name: ch.name,
      editCount,
      kind: parsed.kind,
      bytes: dirSize(dir),
      savedAt: Date.now(),
      dir: name,
    };
    useOffline.setState((s) => {
      const unsupported = { ...s.unsupported };
      delete unsupported[id];
      return {
        chapters: { ...s.chapters, [id]: entry },
        publications: { ...s.publications, [String(pub.id)]: { ...pub, id: String(pub.id) } },
        unsupported,
      };
    });
    persist();
    if (previous && previous.dir !== name) safeDelete(folder(previous.dir)); // swap only after success
    return true;
  } catch (e) {
    safeDelete(dir); // the previous copy (if any) is untouched
    if (gen !== generation) return false;
    throw e;
  } finally {
    useOffline.setState((s) => {
      const busy = { ...s.busy };
      delete busy[id];
      return { busy };
    });
  }
}

/** What can be saved: chapters you own or that are free (same rule as the reader). Creators can save their own. */
export const canSaveOffline = (c: Pick<ChapterIndexEntry, 'canRead' | 'isCollected' | 'price' | 'isDeleted' | 'state'>, owner = false) =>
  !c.isDeleted && (owner || c.canRead || c.isCollected || !Number(c.price)) && (owner || c.state == null || c.state === 'live');

/** True when a chapter has an up-to-date offline copy, or is known not to be savable on this device. */
export function isOfflineCurrent(s: Pick<State, 'chapters' | 'unsupported'>, c: Pick<ChapterIndexEntry, 'id' | 'editCount'>) {
  const id = String(c.id);
  const v = Number(c.editCount) || 0;
  return s.chapters[id]?.editCount === v || s.unsupported[id] === v;
}

/** Downloads every readable chapter of a publication that isn't saved (or is out of date). */
export async function downloadPublication(pub: SavedPublication, chapters: ChapterIndexEntry[], owner = false) {
  if (!OFFLINE_SUPPORTED) return;
  const pid = String(pub.id);
  const state = useOffline.getState();
  if (state.jobs[pid]) return;
  const todo = chapters.filter((c) => canSaveOffline(c, owner) && !isOfflineCurrent(state, c));
  if (!todo.length) return { done: 0, failed: 0 };
  const token = ++tokenSeq;
  const job: Job = { publicationId: pid, done: 0, total: todo.length, failed: 0, token };
  const mine = () => useOffline.getState().jobs[pid]?.token === token;
  useOffline.setState((s) => ({ jobs: { ...s.jobs, [pid]: { ...job } } }));
  for (const c of todo) {
    if (!mine()) break; // cancelled (or replaced by a newer run)
    try {
      const ok = await downloadChapter(c.id, pub);
      if (!ok) job.failed++;
    } catch {
      job.failed++;
    }
    job.done++;
    if (mine()) useOffline.setState((s) => ({ jobs: { ...s.jobs, [pid]: { ...job } } }));
  }
  if (mine()) {
    useOffline.setState((s) => {
      const next = { ...s.jobs };
      delete next[pid];
      return { jobs: next };
    });
  }
  // Chapters this device can't keep aren't failures.
  const unsupported = todo.filter((c) => useOffline.getState().unsupported[String(c.id)] !== undefined).length;
  return { done: job.done - job.failed, failed: Math.max(0, job.failed - unsupported), skipped: unsupported };
}

export function cancelPublicationDownload(publicationId: string | number) {
  useOffline.setState((s) => {
    const next = { ...s.jobs };
    delete next[String(publicationId)];
    return { jobs: next };
  });
}

/** The saved read response (with local file paths rebuilt for this install), or null. */
export async function readOffline(chapterId: string | number): Promise<ChapterContent | null> {
  const entry = OFFLINE_SUPPORTED ? useOffline.getState().chapters[String(chapterId)] : undefined;
  if (!entry) return null;
  try {
    const dir = folder(entry.dir);
    const f = new File(dir, 'content.json');
    if (!f.exists) return null;
    const stored = JSON.parse(await f.text()) as Stored;
    let content = stored.chapter.content;
    if (stored.pages) {
      const files = stored.pages.map((n) => new File(dir, n));
      if (files.some((x) => !x.exists)) return null;
      content = JSON.stringify(files.map((x) => x.uri));
    } else if (stored.pdf) {
      const pdf = new File(dir, stored.pdf);
      if (!pdf.exists) return null;
      content = pdf.uri;
    }
    return { ...stored.chapter, content };
  } catch {
    return null;
  }
}

export function removeChapter(chapterId: string | number) {
  const id = String(chapterId);
  generation++;
  const entry = useOffline.getState().chapters[id];
  if (entry && OFFLINE_SUPPORTED) safeDelete(folder(entry.dir));
  useOffline.setState((s) => {
    const chapters = { ...s.chapters };
    const pid = chapters[id]?.publicationId;
    delete chapters[id];
    const publications = { ...s.publications };
    if (pid && !Object.values(chapters).some((c) => c.publicationId === pid)) delete publications[pid];
    return { chapters, publications };
  });
  persist();
}

export function removePublication(publicationId: string | number) {
  const pid = String(publicationId);
  cancelPublicationDownload(pid);
  Object.values(useOffline.getState().chapters)
    .filter((c) => c.publicationId === pid)
    .forEach((c) => removeChapter(c.chapterId));
  generation++;
}

/** Deletes everything (also on sign-out). */
export function removeAllOffline() {
  generation++;
  useOffline.setState({ jobs: {}, chapters: {}, publications: {}, unsupported: {} });
  if (OFFLINE_SUPPORTED) safeDelete(root());
}

/* ---------------------------------- hooks ---------------------------------- */

export const useSavedChapter = (chapterId?: string | number | null) =>
  useOffline((s) => (chapterId == null ? undefined : s.chapters[String(chapterId)]));
export const useChapterBusy = (chapterId?: string | number | null) =>
  useOffline((s) => (chapterId == null ? false : !!s.busy[String(chapterId)]));
export const usePublicationJob = (publicationId?: string | number | null) =>
  useOffline((s) => (publicationId == null ? undefined : s.jobs[String(publicationId)]));
