# Munkai — Mobile App

The iOS and Android app for [Munkai](https://munkai.art): read, collect and publish comics, books, stories and poems.

- **Stack:** Expo SDK 57 · React Native 0.86 · Expo Router · TypeScript · zustand
- **Styling:** plain `StyleSheet` + theme tokens (no NativeWind / Tailwind)
- **Source of truth:** `munkai-frontend` (web). Same endpoints, same rules. The app is user-facing only — **no admin features**.
- **Money rule:** deposits, withdrawals and top-ups happen on munkai.art (opened in the browser). The only token movement inside the app is **Transfer** (and spending tokens you already have to collect chapters).

More docs:

| Doc | What's in it |
|---|---|
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | How the app is put together: routes, data layer, state, API map, offline, creator tools |
| [`docs/STORE_LISTING.md`](docs/STORE_LISTING.md) | App Store / Play Store copy, privacy & rating questionnaires, review notes, open questions |
| [`assets/store/`](assets/store) | App icons, feature graphic and store screenshots for submission |

## Getting started

```bash
cp .env.example .env          # set EXPO_PUBLIC_API_URL (e.g. https://dev.munkai.art)
npm install
npx expo run:ios              # or: npx expo run:android
```

The app uses native modules that Expo Go doesn't ship (WebView, image picker, audio, file system…), so run it as a **development build** (`expo run:*` or `eas build --profile development`). After adding any package with native code, rebuild.

Day to day, once a dev build is installed:

```bash
npx expo start                # then press i / a, or open the dev build on your phone
```

### Environment

| Variable | Purpose |
|---|---|
| `EXPO_PUBLIC_API_URL` | Backend base URL. Dev: `https://dev.munkai.art`. Falls back to `https://api.munkai.art` when unset. |

### Scripts

| Command | |
|---|---|
| `npm run typecheck` | `tsc --noEmit` — must pass before shipping |
| `npm run lint` | `expo lint` |
| `npx expo-doctor` | Checks dependency versions against the SDK |
| `npx expo install <pkg>` | Always use this (not `npm install`) to add packages — it picks SDK-compatible versions |

## Project layout

```
src/
  app/                 Expo Router — every file is a screen
    (auth)/            Login, register, forgot/reset password, restore account (full-screen sheet)
    (tabs)/            Home, Explore, Library, Wallet, Profile (floating tab bar)
    studio/            Creator Studio: overview, manage publication, publication form, chapter editor, reorder
    publication/[id]   Publication details          read/[id]     Reader
    creator/[id]       Creator page                 search        Search
    …                  notifications, chapters, top-creators, faq, contact, legal, about, become-creator, …
  components/          UI by area (ui/, content/, reader/, studio/, wallet/, offline/, …)
  services/            API calls, one file per area (content, chapters, creator, payments, social, profile, auth)
  store/               zustand stores: session, saved, offline
  lib/                 api client, useFetch/useInfinite, formatting, pickers, reader prefs, reading history
  theme/               Colors (dark default + light), typography, metrics, ThemeProvider
  content/             In-app FAQ, terms and refund policy text
assets/                Icons, splash, fonts, coin image
  store/               Store submission artwork: icons, feature graphic, screenshots (not bundled — nothing imports it)
docs/                  Documentation
```

## Conventions

- **Screens follow approved mocks.** Every new screen is designed on the Munkai design canvas first, then built. The file header names the mock and the web source it mirrors.
- **Styling:**
  ```tsx
  const makeStyles = (t: Theme) => StyleSheet.create({ box: { backgroundColor: t.colors.card } });
  const styles = useThemedStyles(makeStyles);
  ```
  Colors always come from `useTheme()` / tokens; dark is the default theme.
- **Data:** `useFetch(key, fn)` for one-shot reads (cached, stale-while-revalidate), `useInfinite(key, fn)` for cursor lists. Call `invalidate(key)` after a write.
- **API shape:** responses are camelized in `lib/api.ts`; types live in `services/types.ts` and mirror the web's `interfaces/interface.ts`.
- **Accessibility:** 44pt touch targets, `accessibilityRole`/`accessibilityLabel` on every pressable, no colour-only meaning.
- **Formatting:** Prettier with `--single-quote --print-width 140 --trailing-comma all`.

### Local APK with EAS (`--local`)

Profiles are in `eas.json`:
- `development`: dev client
- `preview`: installable **APK** pointing at `dev.munkai.art`
- `production`: Play **AAB** pointing at `api.munkai.art`

`.env` is git-ignored, so EAS doesn't see it. The API URL for each build comes from that profile's `env` in `eas.json`.

One-time setup:

```bash
npm install -g eas-cli
eas login
eas init                      # links the project (adds extra.eas.projectId to app.json)
```

Build:

```bash
eas build -p android --profile preview --local
```

The `.apk` lands in the project folder. Install it with `adb install -r <file>.apk`, or send it to the phone. A local build needs the Android SDK + NDK and JDK 17 on this Mac (install them through Android Studio). The first run asks whether to generate an Android keystore; say yes, and EAS keeps it for later builds.

## Building for the stores

Store assets and questionnaire answers are in [`docs/STORE_LISTING.md`](docs/STORE_LISTING.md) and [`assets/store/`](assets/store). EAS build profiles are in `eas.json` (see above).

Before a store build:
1. `npm run typecheck`
2. Bump `expo.version` in `app.json`.
3. Upload `apple-app-site-association` and `assetlinks.json` to munkai.art, so password-reset links open the app (see ARCHITECTURE → Deep links).
