import { AudienceToggle } from "../components/AudienceToggle";
import { SectionHeading } from "../components/SectionHeading";
import { STEPS, type Audience } from "../data/content";

export function HowItWorks({ audience, onAudience }: { audience: Audience; onAudience: (a: Audience) => void }) {
  const steps = STEPS[audience];
  return (
    <section id="how-it-works" className="scroll-mt-16 bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="How it works"
          title="Up and running in three steps"
          body="Whether you're serving or selling, getting started takes minutes."
        />

        <div className="mt-10 flex justify-center">
          <AudienceToggle value={audience} onChange={onAudience} idPrefix="how" />
        </div>

        <ol
          id="how-panel"
          role="tabpanel"
          aria-labelledby={`how-tab-${audience}`}
          className="relative mt-12 grid gap-5 md:grid-cols-3 md:gap-6"
        >
          {/* connector line behind the numbers, desktop only */}
          <div className="absolute left-[16%] right-[16%] top-8 hidden h-px border-t-2 border-dashed border-brand/15 md:block" aria-hidden />

          {steps.map((step, i) => (
            <li
              key={step.title}
              className="relative flex gap-4 rounded-[var(--radius-card)] border border-line bg-white p-6 md:flex-col md:items-center md:border-0 md:bg-transparent md:p-2 md:text-center"
            >
              <span className="relative grid size-12 shrink-0 place-items-center rounded-full bg-brand text-lg font-bold text-white ring-8 ring-white md:size-16 md:text-2xl">
                {i + 1}
              </span>
              <div>
                <h3 className="text-lg font-semibold text-ink md:mt-4">{step.title}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-ink-soft">{step.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
