import { Icon } from "../components/Icon";
import { SectionHeading } from "../components/SectionHeading";
import { TRUST_POINTS } from "../data/content";

export function Trust() {
  return (
    <section id="trust" className="scroll-mt-16 bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Why trust Kopa"
          title="Safe for corps members. Fair for vendors."
          body="Money is only useful if you can trust where it goes. Here's how we keep every naira accounted for."
        />

        {/* backed by */}
        <div className="mx-auto mt-12 flex max-w-3xl flex-col items-center gap-4 rounded-[var(--radius-card)] border border-line px-6 py-7 sm:flex-row sm:justify-center sm:gap-8">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-muted">Supported by</p>
          <img src="/images/tef.png" alt="The Tony Elumelu Foundation" className="h-16 w-auto sm:h-20" />
        </div>

        {/* trust points */}
        <ul className="mt-12 grid gap-x-8 gap-y-8 sm:gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {TRUST_POINTS.map((t) => (
            <li key={t.title} className="flex gap-4 sm:block">
              <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-brand text-white">
                <Icon name={t.icon} className="size-5" />
              </span>
              <div>
                <h3 className="text-base font-semibold text-ink sm:mt-4">{t.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{t.body}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
