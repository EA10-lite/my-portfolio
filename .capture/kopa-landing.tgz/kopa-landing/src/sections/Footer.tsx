import { Mail } from "lucide-react";
import { Logo } from "../components/Logo";
import { COMPANY, FOOTER_LINKS, LINKS } from "../data/content";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-brand-deep text-white">
      <div className="mx-auto max-w-6xl px-4 pb-10 pt-16 sm:px-6">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <Logo tone="light" />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-white/60">
              Connecting corps members and vendors seamlessly. {COMPANY.tagline}
            </p>
            <a
              href={`mailto:${LINKS.supportEmail}`}
              className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-leaf hover:text-white"
            >
              <Mail className="size-4" />
              {LINKS.supportEmail}
            </a>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {FOOTER_LINKS.map((col) => (
              <div key={col.heading}>
                <p className="text-sm font-semibold">{col.heading}</p>
                <ul className="mt-4 space-y-3">
                  {col.links.map((l) => (
                    <li key={l.label}>
                      <a href={l.href} className="text-sm text-white/60 transition hover:text-white">
                        {l.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14 border-t border-white/10 pt-8 text-xs leading-relaxed text-white/45">
          <p>
            Kopa Xclusive is operated by {COMPANY.name} ({COMPANY.rc}), {COMPANY.address}.
          </p>
          <p className="mt-2">
            Credit is subject to eligibility checks and approval. Repayments are collected by direct debit according to
            the agreement you accept in the app. Never share your bank password, PIN or OTP with anyone claiming to be
            from Kopa Xclusive.
          </p>
          <p className="mt-6 text-white/60">© {year} {COMPANY.name} All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
