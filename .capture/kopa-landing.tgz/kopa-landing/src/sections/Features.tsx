import { ArrowRight } from "lucide-react";
import { AudienceToggle } from "../components/AudienceToggle";
import { Button } from "../components/Button";
import { Icon } from "../components/Icon";
import { SectionHeading } from "../components/SectionHeading";
import { FEATURES, type Audience } from "../data/content";
import { useAppHref } from "../components/useAppHref";

const SPOTLIGHT: Record<Audience, { kicker: string; title: string; body: string; cta: string }> = {
  corper: {
    kicker: "For corps members",
    title: "Don't wait for allowance day.",
    body: "Get what you need now from vendors you trust, and repay automatically from the account your allowance lands in.",
    cta: "Get the app",
  },
  vendor: {
    kicker: "For vendors",
    title: "Turn corps members into regulars.",
    body: "Reach corps members with approved spending power, get paid into your Kopa wallet, and withdraw when you're ready.",
    cta: "Get the app",
  },
};

/** A small slice of the app — the corper's credit or the vendor's wallet. */
function SpotlightChip({ audience }: { audience: Audience }) {
  const corper = audience === "corper";
  return (
    <div className="relative mt-8 hidden rounded-2xl bg-white/10 p-4 ring-1 ring-white/15 backdrop-blur sm:block">
      <div className="flex items-center justify-between text-xs text-white/60">
        <span>{corper ? "Available Credit" : "Wallet balance"}</span>
        <span className="rounded-full bg-leaf/20 px-2 py-0.5 text-[10px] font-semibold text-leaf">
          {corper ? "Approved" : "Verified vendor"}
        </span>
      </div>
      <p className="mt-1.5 text-2xl font-bold tracking-tight">{corper ? "₦38,500.00" : "₦184,250.00"}</p>
      {corper ? (
        <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/15">
          <div className="h-full w-[23%] rounded-full bg-leaf" />
        </div>
      ) : (
        <p className="mt-2 text-xs text-white/60">12 sales today · Withdraw anytime</p>
      )}
    </div>
  );
}

export function Features({ audience, onAudience }: { audience: Audience; onAudience: (a: Audience) => void }) {
  const spot = SPOTLIGHT[audience];
  const appHref = useAppHref();
  return (
    <section id="features" className="relative scroll-mt-16 bg-brand-light/60 py-20 sm:py-28">
      <span id="features-vendors" className="absolute -top-16" aria-hidden />
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <SectionHeading
          eyebrow="Features"
          title="Built for both sides of the counter"
          body="One platform connecting corps members and the vendors who serve them."
        />

        <div className="mt-10 flex justify-center">
          <AudienceToggle value={audience} onChange={onAudience} idPrefix="features" />
        </div>

        <div
          id="features-panel"
          role="tabpanel"
          aria-labelledby={`features-tab-${audience}`}
          className="mt-12 grid gap-5 lg:grid-cols-[0.9fr_2fr] lg:gap-6"
        >
          {/* spotlight card */}
          <div className="relative flex flex-col overflow-hidden rounded-[var(--radius-card)] bg-brand p-7 text-white sm:p-8">
            <div className="absolute -right-16 -top-16 size-48 rounded-full bg-white/5" aria-hidden />
            <div className="absolute -bottom-20 -left-10 size-56 rounded-full bg-leaf/20 blur-2xl" aria-hidden />
            <p className="relative text-xs font-semibold uppercase tracking-[0.18em] text-leaf">{spot.kicker}</p>
            <h3 className="relative mt-3 text-2xl font-bold leading-snug sm:text-3xl">{spot.title}</h3>
            <p className="relative mt-4 text-[15px] leading-relaxed text-white/75">{spot.body}</p>
            <SpotlightChip audience={audience} />
            <div className="relative mt-8 lg:mt-auto lg:pt-8">
              <Button href={appHref} variant="white" className="w-full sm:w-auto">
                {spot.cta}
                <ArrowRight className="size-4" />
              </Button>
            </div>
          </div>

          {/* feature grid */}
          <ul className="grid gap-3 sm:grid-cols-2 sm:gap-4 lg:gap-5">
            {FEATURES[audience].map((f) => (
              <li
                key={f.title}
                className="flex gap-4 rounded-[var(--radius-card)] border border-white bg-white p-5 shadow-card transition hover:-translate-y-0.5 sm:block sm:p-6"
              >
                <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-brand-light">
                  <Icon name={f.icon} className="size-5 text-brand" />
                </span>
                <div>
                  <h4 className="text-base font-semibold text-ink sm:mt-4">{f.title}</h4>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{f.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
