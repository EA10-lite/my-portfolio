import { Check } from "lucide-react";
import { StoreBadges } from "../components/StoreBadges";
import { LINKS } from "../data/content";

const CORPER_NEEDS = ["NYSC state code & call-up number", "NIN and BVN", "The account your allowance is paid into"];
const VENDOR_NEEDS = ["Business name, category & address", "CAC registration number (RC or BN)", "Owner's details and a bank account for payouts"];

export function GetStarted() {
  return (
    <section id="get-started" className="scroll-mt-16 bg-white pb-20 sm:pb-28">
      <div className="mx-auto grid max-w-6xl gap-5 px-4 sm:px-6 lg:grid-cols-2 lg:gap-6">
        {/* corps members */}
        <div className="relative isolate overflow-hidden rounded-[32px] bg-brand-deep p-7 text-white sm:p-10">
          <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-deep via-brand-dark to-brand" />
          <div className="absolute -right-24 -top-24 -z-10 size-72 rounded-full bg-leaf/25 blur-3xl" />
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-leaf">Corps members</p>
          <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
            Download Kopa and get covered.
          </h2>
          <p className="mt-4 max-w-md text-[15px] leading-relaxed text-white/75">
            Sign up in minutes. Once you're approved, your spending limit is ready to use at vendors near you.
          </p>
          <ul className="mt-6 space-y-2.5">
            {CORPER_NEEDS.map((n) => (
              <li key={n} className="flex items-center gap-2.5 text-sm text-white/80">
                <Check className="size-4 shrink-0 text-leaf" strokeWidth={3} />
                {n}
              </li>
            ))}
          </ul>
          <StoreBadges className="mt-8" />
        </div>

        {/* vendors */}
        <div className="flex flex-col rounded-[32px] border border-line bg-brand-light/60 p-7 sm:p-10">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-naija">Vendors</p>
          <h2 className="mt-3 text-3xl font-bold leading-tight tracking-tight text-ink sm:text-4xl">
            Sell to corps members near you.
          </h2>
          <p className="mt-4 max-w-md text-[15px] leading-relaxed text-ink-soft">
            Download the same Kopa app, choose "Continue as a Vendor", and start receiving payments once the Kopa team verifies your business.
          </p>
          <ul className="mt-6 space-y-2.5">
            {VENDOR_NEEDS.map((n) => (
              <li key={n} className="flex items-center gap-2.5 text-sm text-ink-soft">
                <Check className="size-4 shrink-0 text-brand" strokeWidth={3} />
                {n}
              </li>
            ))}
          </ul>
          <div className="mt-8 lg:mt-auto lg:pt-8">
            <StoreBadges />
            <p className="mt-4 text-sm text-ink-soft">
              Questions before you sign up?{" "}
              <a href={`mailto:${LINKS.supportEmail}`} className="font-semibold text-brand underline-offset-4 hover:underline">
                Talk to us
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
