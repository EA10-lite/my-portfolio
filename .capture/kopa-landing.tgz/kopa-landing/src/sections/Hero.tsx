import { ArrowRight, Check, CheckCircle2, Smartphone, Store } from "lucide-react";
import { Button } from "../components/Button";
import { PhoneMockup } from "../components/PhoneMockup";
import { HERO } from "../data/content";
import { useAppHref } from "../components/useAppHref";

export function Hero() {
  const appHref = useAppHref();
  return (
    <section
      id="top"
      className="relative isolate overflow-hidden bg-brand-deep pb-20 pt-28 text-white sm:pt-32 lg:pb-28 lg:pt-40"
    >
      {/* backdrop: evergreen gradient, a soft leaf glow, faint grid */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-deep via-brand-dark to-brand" />
      <div className="absolute -right-40 top-10 -z-10 size-[520px] rounded-full bg-leaf/25 blur-[120px]" />
      <div className="absolute -left-32 bottom-0 -z-10 size-[380px] rounded-full bg-naija/20 blur-[110px]" />
      <div
        className="absolute inset-0 -z-10 opacity-[0.07] [background-image:linear-gradient(to_right,white_1px,transparent_1px),linear-gradient(to_bottom,white_1px,transparent_1px)] [background-size:56px_56px] [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]"
      />

      <div className="mx-auto grid max-w-6xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:gap-10">
        {/* copy */}
        <div className="text-center lg:text-left">
          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-medium text-white/85 sm:text-sm">
            <span className="size-1.5 rounded-full bg-leaf" />
            {HERO.eyebrow}
          </span>

          <h1 className="mt-6 text-[2.6rem] font-extrabold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
            {HERO.title[0]}
            <br />
            <span className="relative inline-block text-leaf">
              {HERO.title[1]}
              <svg
                viewBox="0 0 200 12"
                className="absolute -bottom-2 left-0 h-3 w-full text-leaf/60"
                preserveAspectRatio="none"
                aria-hidden
              >
                <path d="M2 9 Q 100 1 198 7" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              </svg>
            </span>
          </h1>

          <p className="mx-auto mt-7 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg lg:mx-0">
            {HERO.body}
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:justify-center lg:justify-start">
            <Button href={appHref} variant="white" icon={<Smartphone className="size-5" />}>
              {HERO.corperCta}
            </Button>
            <Button href={appHref} variant="outline-light" icon={<Store className="size-5" />}>
              {HERO.vendorCta}
              <ArrowRight className="size-4" />
            </Button>
          </div>

          <ul className="mt-9 flex flex-col items-center gap-2.5 text-sm text-white/70 sm:flex-row sm:flex-wrap sm:justify-center sm:gap-x-6 lg:justify-start">
            {HERO.points.map((p) => (
              <li key={p} className="flex items-center gap-2">
                <Check className="size-4 text-leaf" strokeWidth={3} />
                {p}
              </li>
            ))}
          </ul>
        </div>

        {/* visual */}
        <div className="relative mx-auto">
          <div className="relative rotate-0 lg:rotate-[3deg]">
            <PhoneMockup />
          </div>

          {/* floating: corper payment */}
          <div className="absolute -left-10 -top-6 hidden w-56 rounded-2xl bg-white p-3.5 text-ink shadow-card ring-1 ring-black/5 sm:block lg:-left-28">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="size-9 shrink-0 text-leaf" />
              <div className="leading-tight">
                <p className="text-xs font-semibold">Payment successful</p>
                <p className="mt-0.5 text-[11px] text-ink-soft">₦4,500 · Mama T's Kitchen</p>
              </div>
            </div>
          </div>

          {/* floating: vendor payout */}
          <div className="absolute -right-6 -bottom-8 hidden w-52 rounded-2xl bg-white p-3.5 text-ink shadow-card ring-1 ring-black/5 sm:block lg:-right-20">
            <p className="text-[11px] text-ink-soft">Vendor wallet</p>
            <p className="mt-0.5 text-lg font-bold text-brand">+ ₦12,000</p>
            <p className="text-[11px] text-ink-muted">Received from a corps member</p>
          </div>
        </div>
      </div>
    </section>
  );
}
