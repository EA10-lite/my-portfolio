import { useEffect, useState } from "react";
import { appDownloadHref } from "../data/content";

/**
 * The download link for this visitor. Starts as "#get-started" (what the
 * pre-rendered page contains) and switches to the phone's own store after
 * the page loads, so server and client HTML agree.
 */
export function useAppHref() {
  const [href, setHref] = useState("/#get-started");
  useEffect(() => setHref(appDownloadHref()), []);
  return href;
}
