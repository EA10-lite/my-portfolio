import { Bell, Store, ArrowDownToLine, Wallet, Receipt, Phone, Wifi, Tv, Zap } from "lucide-react";

/**
 * A drawn (not screenshotted) version of the corper home screen in
 * Kopa-Mobile: greeting, Available Credit hero card, quick actions, bills.
 * Figures are illustrative.
 */
export function PhoneMockup() {
  const actions = [
    { icon: Store, label: "Pay" },
    { icon: ArrowDownToLine, label: "Request" },
    { icon: Wallet, label: "Wallet" },
    { icon: Receipt, label: "History" },
  ];
  const bills = [
    { icon: Phone, label: "Airtime" },
    { icon: Wifi, label: "Data" },
    { icon: Tv, label: "TV" },
    { icon: Zap, label: "Power" },
  ];

  return (
    <div className="relative w-[272px] rounded-[44px] bg-brand-deep p-2.5 shadow-2xl shadow-black/50 ring-1 ring-white/10 sm:w-[296px]">
      <div className="relative overflow-hidden rounded-[36px] bg-white">
        {/* notch */}
        <div className="absolute left-1/2 top-2 h-5 w-24 -translate-x-1/2 rounded-full bg-brand-deep" />

        <div className="px-4 pb-6 pt-10">
          {/* header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="grid size-9 place-items-center rounded-full bg-brand text-xs font-semibold text-white">
                AO
              </div>
              <div className="leading-tight">
                <p className="text-[10px] text-ink-muted">Good morning</p>
                <p className="text-[13px] font-semibold text-ink">Amaka</p>
              </div>
            </div>
            <div className="relative grid size-9 place-items-center rounded-full bg-input">
              <Bell className="size-4 text-ink" />
              <span className="absolute right-2 top-2 size-1.5 rounded-full bg-red-500" />
            </div>
          </div>

          {/* credit card */}
          <div className="relative mt-4 overflow-hidden rounded-3xl bg-brand p-4 text-white">
            <div className="absolute -right-10 -top-10 size-32 rounded-full bg-white/5" />
            <div className="absolute -bottom-12 right-6 size-24 rounded-full bg-leaf/20" />
            <p className="relative text-[10px] text-white/70">Available Credit</p>
            <p className="relative mt-1 text-2xl font-bold tracking-tight">₦38,500.00</p>
            <div className="relative mt-3 h-1.5 overflow-hidden rounded-full bg-white/15">
              <div className="h-full w-[23%] rounded-full bg-leaf" />
            </div>
            <div className="relative mt-3 flex justify-between text-[10px]">
              <div>
                <p className="text-white/60">Amount Spent</p>
                <p className="font-semibold">₦11,500</p>
              </div>
              <div className="text-right">
                <p className="text-white/60">Next repayment</p>
                <p className="font-semibold">28 Nov</p>
              </div>
            </div>
          </div>

          {/* quick actions */}
          <div className="mt-4 grid grid-cols-4 gap-2">
            {actions.map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-1.5">
                <div className="grid size-11 place-items-center rounded-2xl bg-brand-light">
                  <Icon className="size-[18px] text-brand" strokeWidth={1.8} />
                </div>
                <span className="text-[10px] font-medium text-ink-soft">{label}</span>
              </div>
            ))}
          </div>

          {/* bills */}
          <p className="mt-5 text-[12px] font-semibold text-ink">Pay bills</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {bills.map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-1.5 rounded-2xl border border-line py-2.5">
                <Icon className="size-4 text-brand" strokeWidth={1.8} />
                <span className="text-[9px] text-ink-soft">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
