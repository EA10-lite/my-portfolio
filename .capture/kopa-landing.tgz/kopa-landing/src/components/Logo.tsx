type LogoProps = { tone?: "light" | "dark"; className?: string };

/** Logo mark + wordmark. "light" is for dark backgrounds. */
export function Logo({ tone = "dark", className = "" }: LogoProps) {
  return (
    <a href="/" className={`flex items-center gap-2.5 ${className}`} aria-label="Kopa Xclusive home">
      <img src="/images/kopa-logo.png" alt="" className="h-9 w-auto" width={30} height={36} />
      <span
        className={`text-lg font-bold tracking-tight ${tone === "light" ? "text-white" : "text-brand"}`}
      >
        Kopa <span className={tone === "light" ? "text-leaf" : "text-leaf"}>Xclusive</span>
      </span>
    </a>
  );
}
