import type { ReactNode } from "react";

type Variant = "primary" | "white" | "outline-light" | "outline" | "muted";

const VARIANTS: Record<Variant, string> = {
  primary: "bg-brand text-white shadow-lg shadow-brand/25 hover:bg-brand-dark",
  white: "bg-white text-brand shadow-lg shadow-black/20 hover:bg-brand-light",
  "outline-light": "border border-white/40 text-white hover:bg-white/10",
  outline: "border border-brand text-brand hover:bg-brand-light",
  muted: "bg-brand-light text-brand hover:bg-brand/10",
};

/** Pill button — same fully rounded shape as the app's Button. */
export function Button({
  href,
  children,
  variant = "primary",
  icon,
  className = "",
}: {
  href: string;
  children: ReactNode;
  variant?: Variant;
  icon?: ReactNode;
  className?: string;
}) {
  return (
    <a
      href={href}
      className={`inline-flex items-center justify-center gap-2.5 rounded-full px-6 py-3.5 text-[15px] font-semibold transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-leaf ${VARIANTS[variant]} ${className}`}
    >
      {icon}
      {children}
    </a>
  );
}
