import {
  BadgeCheck, BarChart3, CreditCard, Landmark, Lock, QrCode, RefreshCw, Scale,
  ShieldCheck, ShoppingBag, Store, UserCheck, Users, Wallet, Zap, type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  BadgeCheck, BarChart3, CreditCard, Landmark, Lock, QrCode, RefreshCw, Scale,
  ShieldCheck, ShoppingBag, Store, UserCheck, Users, Wallet, Zap,
};

/** Looks up a lucide icon by the name used in data/content.ts. */
export function Icon({ name, className }: { name: string; className?: string }) {
  const Cmp = ICONS[name] ?? ShieldCheck;
  return <Cmp className={className} strokeWidth={1.8} aria-hidden />;
}
