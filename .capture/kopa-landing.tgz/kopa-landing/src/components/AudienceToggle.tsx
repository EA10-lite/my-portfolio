import { GraduationCap, Store } from "lucide-react";
import { AUDIENCE_LABEL, type Audience } from "../data/content";

/** Segmented control switching between the two audiences. */
export function AudienceToggle({
  value,
  onChange,
  idPrefix,
}: {
  value: Audience;
  onChange: (a: Audience) => void;
  idPrefix: string;
}) {
  const items: { key: Audience; icon: typeof Store }[] = [
    { key: "corper", icon: GraduationCap },
    { key: "vendor", icon: Store },
  ];
  return (
    <div role="tablist" aria-label="Choose audience" className="inline-flex rounded-full bg-brand-light p-1.5">
      {items.map(({ key, icon: I }) => {
        const active = value === key;
        return (
          <button
            key={key}
            role="tab"
            id={`${idPrefix}-tab-${key}`}
            aria-selected={active}
            aria-controls={`${idPrefix}-panel`}
            onClick={() => onChange(key)}
            className={`flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold transition sm:px-6 ${
              active ? "bg-brand text-white shadow-md shadow-brand/25" : "text-brand hover:bg-white/60"
            }`}
          >
            <I className="size-4" />
            {AUDIENCE_LABEL[key]}
          </button>
        );
      })}
    </div>
  );
}
