import type { ReactNode } from "react";

export function SectionHeading({
  eyebrow,
  title,
  body,
  tone = "dark",
}: {
  eyebrow: string;
  title: ReactNode;
  body?: string;
  tone?: "dark" | "light";
}) {
  const light = tone === "light";
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className={`text-xs font-semibold uppercase tracking-[0.18em] ${light ? "text-leaf" : "text-naija"}`}>
        {eyebrow}
      </p>
      <h2
        className={`mt-3 text-3xl font-bold leading-tight tracking-tight sm:text-4xl lg:text-[2.75rem] ${
          light ? "text-white" : "text-ink"
        }`}
      >
        {title}
      </h2>
      {body && (
        <p className={`mt-4 text-base leading-relaxed sm:text-lg ${light ? "text-white/70" : "text-ink-soft"}`}>
          {body}
        </p>
      )}
    </div>
  );
}
