import { LINKS } from "../data/content";

function AppleGlyph() {
  return (
    <svg viewBox="0 0 24 24" className="size-7 fill-current" aria-hidden>
      <path d="M16.37 12.6c-.02-2.1 1.72-3.12 1.8-3.17-0.98-1.43-2.5-1.63-3.04-1.65-1.29-.13-2.52.76-3.18.76-.66 0-1.67-.74-2.75-.72-1.41.02-2.72.82-3.44 2.09-1.47 2.55-.38 6.32 1.05 8.39.7 1.01 1.53 2.15 2.62 2.11 1.05-.04 1.45-.68 2.72-.68 1.27 0 1.63.68 2.74.66 1.13-.02 1.85-1.03 2.54-2.05.8-1.17 1.13-2.31 1.15-2.37-.03-.01-2.2-.85-2.21-3.37zM14.29 6.43c.58-.7.97-1.67.86-2.64-.83.03-1.84.55-2.44 1.25-.53.62-1 1.61-.88 2.56.93.07 1.88-.47 2.46-1.17z" />
    </svg>
  );
}

function PlayGlyph() {
  return (
    <svg viewBox="0 0 24 24" className="size-6" aria-hidden>
      <path d="M3.6 2.2 13.4 12l-9.8 9.8c-.36-.2-.6-.6-.6-1.07V3.27c0-.47.24-.87.6-1.07z" fill="#34A853" />
      <path d="m16.8 8.6-3.4 3.4-9.8-9.8c.3-.17.68-.2 1.05 0l12.15 6.4z" fill="#FBBC04" />
      <path d="m16.8 15.4-12.15 6.4c-.37.2-.75.17-1.05 0l9.8-9.8 3.4 3.4z" fill="#EA4335" />
      <path d="m20.4 13.3-3.6 2.1-3.4-3.4 3.4-3.4 3.6 2.1c.84.5.84 2.1 0 2.6z" fill="#4285F4" />
    </svg>
  );
}

function Badge({ href, glyph, top, bottom }: { href: string; glyph: React.ReactNode; top: string; bottom: string }) {
  return (
    <a
      href={href}
      className="inline-flex h-14 w-full items-center justify-center sm:w-auto sm:min-w-[170px] sm:justify-start gap-3 rounded-2xl bg-black px-4 text-white ring-1 ring-white/15 transition hover:bg-neutral-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-leaf"
    >
      {glyph}
      <span className="flex flex-col leading-none">
        <span className="text-[10px] font-medium text-white/75">{top}</span>
        <span className="mt-1 text-lg font-semibold tracking-tight">{bottom}</span>
      </span>
    </a>
  );
}

export function StoreBadges({ className = "" }: { className?: string }) {
  return (
    <div className={`flex flex-col gap-3 sm:flex-row sm:flex-wrap ${className}`}>
      <Badge href={LINKS.appStore} glyph={<AppleGlyph />} top="Download on the" bottom="App Store" />
      <Badge href={LINKS.playStore} glyph={<PlayGlyph />} top="GET IT ON" bottom="Google Play" />
    </div>
  );
}
