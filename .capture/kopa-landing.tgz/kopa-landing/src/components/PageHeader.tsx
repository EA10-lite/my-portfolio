import type { ReactNode } from "react";

/** Dark title band for inner pages, so the transparent navbar sits on it like on the home hero. */
export function PageHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return (
    <section className="relative isolate overflow-hidden bg-brand-deep pb-14 pt-28 text-white sm:pb-16 sm:pt-36">
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-deep via-brand-dark to-brand" />
      <div className="absolute -right-40 -top-20 -z-10 size-[420px] rounded-full bg-leaf/20 blur-[110px]" />
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-leaf">{eyebrow}</p>
        <h1 className="mt-3 text-4xl font-extrabold tracking-tight sm:text-5xl">{title}</h1>
        {children && <div className="mt-4 max-w-2xl text-base leading-relaxed text-white/70">{children}</div>}
      </div>
    </section>
  );
}
