import { StrictMode } from "react";
import { renderToString } from "react-dom/server";
import App from "./App";
import { ROUTES, type RoutePath } from "./routes";

/** Used only at build time by scripts/prerender.mjs. */
export function render(path: RoutePath) {
  return renderToString(
    <StrictMode>
      <App path={path} />
    </StrictMode>,
  );
}

export { ROUTES };
export { SITE_URL } from "./routes";
