/**
 * The site's pages. Each one is pre-rendered to its own HTML file at build
 * time (scripts/prerender.mjs), with the title and description below.
 */
export type RoutePath = "/" | "/faq" | "/terms" | "/privacy" | "/contact";

export const SITE_URL = "https://www.kopaxclusive.com.ng";

export const ROUTES: Record<RoutePath, { title: string; description: string }> = {
  "/": {
    title: "Kopa Xclusive — Shop Now, Pay Later for NYSC Corps Members",
    description:
      "Kopa Xclusive gives NYSC corps members a spending limit to shop now and pay later at trusted vendors, with repayment from their allowance account. Vendors get paid straight into their wallet.",
  },
  "/faq": {
    title: "FAQs — Kopa Xclusive",
    description:
      "Answers for NYSC corps members and vendors: signing up, spending limits, repayment by direct debit, vendor payouts, marketplace orders and account safety.",
  },
  "/terms": {
    title: "Terms & Conditions — Kopa Xclusive",
    description:
      "The terms that govern your use of the Kopa Xclusive app, website and services, including credit, payments, repayment and merchant use.",
  },
  "/privacy": {
    title: "Privacy Policy — Kopa Xclusive",
    description:
      "How Kopa Xclusive collects, uses, shares and protects your personal data, in line with the Nigeria Data Protection Act 2023.",
  },
  "/contact": {
    title: "Contact Us — Kopa Xclusive",
    description:
      "Get in touch with the Kopa Xclusive team — support for corps members and vendors, privacy and data requests, and our office in Kaduna.",
  },
};

/** Maps a URL path (with or without a trailing slash) to a known page. */
export function resolveRoute(pathname: string): RoutePath {
  const p = (pathname.replace(/\/+$/, "") || "/") as RoutePath;
  return p in ROUTES ? p : "/";
}
