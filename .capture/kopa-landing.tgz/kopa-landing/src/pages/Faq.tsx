import { ChevronDown, MessageCircle } from "lucide-react";
import { Button } from "../components/Button";
import { PageHeader } from "../components/PageHeader";
import { FAQ_GROUPS } from "../data/faq";

/** schema.org FAQPage, so Google can show these answers in search results. */
const FAQ_JSON_LD = JSON.stringify({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: FAQ_GROUPS.flatMap((g) =>
    g.items.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a.join(" ") },
    })),
  ),
}).replace(/</g, "\\u003c");

export function Faq() {
  return (
    <>
      <PageHeader eyebrow="FAQs" title="Frequently asked questions">
        <p>How Kopa works for corps members and vendors — spending limits, repayment, payouts and keeping your account safe.</p>
      </PageHeader>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: FAQ_JSON_LD }} />

      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        {/* jump links */}
        <nav aria-label="FAQ topics" className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-2 sm:mx-0 sm:flex-wrap sm:px-0">
          {FAQ_GROUPS.map((g) => (
            <a
              key={g.id}
              href={`#${g.id}`}
              className="shrink-0 rounded-full bg-brand-light px-4 py-2 text-sm font-medium text-brand transition hover:bg-brand hover:text-white"
            >
              {g.title}
            </a>
          ))}
        </nav>

        <div className="mt-10 space-y-14">
          {FAQ_GROUPS.map((g) => (
            <section key={g.id} id={g.id} className="scroll-mt-24 lg:grid lg:grid-cols-[260px_1fr] lg:gap-14">
              <h2 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">{g.title}</h2>
              <div className="mt-4 divide-y divide-line rounded-[var(--radius-card)] border border-line lg:mt-0">
                {g.items.map((f) => (
                  // <details> works before JavaScript loads and keeps answers in the HTML for search engines.
                  <details key={f.q} className="group">
                    <summary className="flex cursor-pointer list-none items-start justify-between gap-4 px-5 py-4 text-left text-[15px] font-semibold text-ink transition hover:text-brand sm:px-6 sm:py-5 [&::-webkit-details-marker]:hidden">
                      {f.q}
                      <ChevronDown className="mt-0.5 size-5 shrink-0 text-brand transition group-open:rotate-180" />
                    </summary>
                    <div className="space-y-3 px-5 pb-5 text-[15px] leading-relaxed text-ink-soft sm:px-6">
                      {f.a.map((p, i) => (
                        <p key={i}>{p}</p>
                      ))}
                    </div>
                  </details>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-16 flex flex-col items-start gap-5 rounded-[var(--radius-card)] bg-brand-light/60 p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8">
          <div className="flex gap-4">
            <MessageCircle className="mt-0.5 size-6 shrink-0 text-brand" strokeWidth={1.8} />
            <div>
              <h2 className="text-lg font-semibold text-ink">Still have a question?</h2>
              <p className="mt-1 text-sm text-ink-soft">Our team is happy to help corps members and vendors.</p>
            </div>
          </div>
          <Button href="/contact" className="w-full sm:w-auto">
            Contact us
          </Button>
        </div>
      </div>
    </>
  );
}
