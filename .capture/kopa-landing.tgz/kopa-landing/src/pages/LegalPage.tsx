import type { ReactNode } from "react";
import { ChevronDown, Mail } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { LEGAL_DOCUMENTS, LEGAL_OPERATOR, type LegalDocument } from "../data/legal";

function slug(title: string) {
  return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

/** Strips the leading "12. " so the contents list reads cleanly. */
function plainTitle(title: string) {
  const t = title.replace(/^\d+\.\s*/, "");
  const lower = t.charAt(0) + t.slice(1).toLowerCase();
  // Keep acronyms upper-case: "Verification and KYC", not "kyc".
  return lower.replace(/\b(kyc|nysc|bvn|nin|ndpa|otp|pin|bnpl|sms|kopa)\b/gi, (m) =>
    m.toLowerCase() === "kopa" ? "Kopa" : m.toUpperCase(),
  );
}

/**
 * The source documents use three list styles: "●" inline (Privacy), "- "
 * lines and "1. " lines (Terms). Turn each into a real list without editing
 * the text Legal signed off.
 */
function Body({ text }: { text: string }) {
  const out: ReactNode[] = [];
  let list: { ordered: boolean; items: string[] } | null = null;
  const flush = () => {
    if (!list) return;
    const Tag = list.ordered ? "ol" : "ul";
    out.push(
      <Tag
        key={out.length}
        className={`my-3 space-y-1.5 pl-5 ${list.ordered ? "list-decimal" : "list-disc"} marker:text-brand`}
      >
        {list.items.map((it, i) => (
          <li key={i} className="pl-1">
            {it}
          </li>
        ))}
      </Tag>,
    );
    list = null;
  };
  const push = (ordered: boolean, item: string) => {
    if (!list || list.ordered !== ordered) {
      flush();
      list = { ordered, items: [] };
    }
    list.items.push(item);
  };

  for (const raw of text.split("\n")) {
    const line = raw.trim();
    if (!line) {
      flush();
      continue;
    }
    if (line.includes("●")) {
      const [lead, ...bullets] = line.split("●").map((s) => s.trim());
      if (lead) {
        flush();
        out.push(<p key={out.length}>{lead}</p>);
      }
      bullets.filter(Boolean).forEach((b) => push(false, b.replace(/;$/, "")));
      continue;
    }
    const dash = line.match(/^[-•]\s+(.*)$/);
    if (dash) {
      push(false, dash[1]);
      continue;
    }
    const num = line.match(/^\d+[.)]\s+(.*)$/);
    if (num) {
      push(true, num[1]);
      continue;
    }
    flush();
    out.push(<p key={out.length}>{line}</p>);
  }
  flush();
  return <div className="space-y-3">{out}</div>;
}

export function LegalPage({ doc }: { doc: LegalDocument["key"] }) {
  const d = LEGAL_DOCUMENTS[doc];
  const sections = d.sections.filter((s) => s.title);
  const preamble = d.sections.find((s) => !s.title);

  const toc = (
    <ol className="space-y-1 text-sm">
      {sections.map((s) => (
        <li key={s.title}>
          <a
            href={`#${slug(s.title)}`}
            className="block rounded-lg px-3 py-1.5 text-ink-soft transition hover:bg-brand-light hover:text-brand"
          >
            {plainTitle(s.title)}
          </a>
        </li>
      ))}
    </ol>
  );

  return (
    <>
      <PageHeader eyebrow="Legal" title={d.title}>
        <p>
          Effective {d.effectiveDate} · Last updated {d.lastUpdated}
        </p>
      </PageHeader>

      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 sm:py-16 lg:grid-cols-[260px_1fr] lg:gap-14">
        {/* contents: collapsible on phones, sticky sidebar on desktop */}
        <aside>
          <details className="group rounded-2xl border border-line lg:hidden">
            <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-3.5 text-sm font-semibold text-ink">
              Contents
              <ChevronDown className="size-4 transition group-open:rotate-180" />
            </summary>
            <div className="max-h-80 overflow-y-auto border-t border-line p-2">{toc}</div>
          </details>
          <nav aria-label="Contents" className="sticky top-24 hidden max-h-[calc(100vh-8rem)] overflow-y-auto lg:block">
            <p className="px-3 pb-2 text-xs font-semibold uppercase tracking-[0.18em] text-ink-muted">Contents</p>
            {toc}
          </nav>
        </aside>

        <article className="min-w-0 text-[15px] leading-relaxed text-ink-soft">
          {preamble && <Body text={preamble.body} />}
          {sections.map((s) => (
            <section key={s.title} id={slug(s.title)} className="scroll-mt-24 pt-10">
              <h2 className="text-lg font-semibold text-ink sm:text-xl">{s.title}</h2>
              <div className="mt-3">
                <Body text={s.body} />
              </div>
            </section>
          ))}

          <div className="mt-14 rounded-[var(--radius-card)] bg-brand-light/60 p-6 text-sm">
            <p className="font-semibold text-ink">{LEGAL_OPERATOR.company}</p>
            <p className="mt-1">{LEGAL_OPERATOR.rcNumber}</p>
            <p>{LEGAL_OPERATOR.address}</p>
            <a
              href={`mailto:${doc === "privacy" ? LEGAL_OPERATOR.privacyEmail : LEGAL_OPERATOR.supportEmail}`}
              className="mt-3 inline-flex items-center gap-2 font-semibold text-brand hover:underline"
            >
              <Mail className="size-4" />
              {doc === "privacy" ? LEGAL_OPERATOR.privacyEmail : LEGAL_OPERATOR.supportEmail}
            </a>
          </div>
        </article>
      </div>
    </>
  );
}
