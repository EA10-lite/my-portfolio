import { useEffect, useState } from "react";
import { Hero } from "../sections/Hero";
import { HowItWorks } from "../sections/HowItWorks";
import { Features } from "../sections/Features";
import { Trust } from "../sections/Trust";
import { GetStarted } from "../sections/GetStarted";
import type { Audience } from "../data/content";

export function Home() {
  // One choice shared by How it works and Features, so a vendor who picks
  // "Vendors" once doesn't have to pick it again further down. Starts on
  // "corper" so the pre-rendered HTML matches; "#features-vendors" applies after.
  const [audience, setAudience] = useState<Audience>("corper");

  useEffect(() => {
    const fromHash = () => {
      const h = window.location.hash;
      if (h.startsWith("#features")) setAudience(h.includes("vendor") ? "vendor" : "corper");
    };
    fromHash();
    window.addEventListener("hashchange", fromHash);
    return () => window.removeEventListener("hashchange", fromHash);
  }, []);

  return (
    <>
      <Hero />
      <HowItWorks audience={audience} onAudience={setAudience} />
      <Features audience={audience} onAudience={setAudience} />
      <Trust />
      <GetStarted />
    </>
  );
}
