import { useEffect, useState } from "react";
import { LifeBuoy, Mail, MapPin, Phone, ShieldCheck, Smartphone, type LucideIcon } from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import { StoreBadges } from "../components/StoreBadges";
import { COMPANY, LINKS } from "../data/content";

const API_URL = import.meta.env.VITE_API_URL ?? "https://kopa-backend-apio.onrender.com/api/v1";

/**
 * The support phone number is set by the Kopa team in the admin
 * (Settings → support phone) and served by GET /settings/public — the same
 * source the app's Help & Support screen reads. Shown only once it loads.
 */
function useSupportPhone() {
  const [phone, setPhone] = useState("");
  useEffect(() => {
    const ctrl = new AbortController();
    fetch(`${API_URL}/settings/public`, { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => {
        const data = body?.data ?? body;
        if (typeof data?.supportPhone === "string") setPhone(data.supportPhone.trim());
      })
      .catch(() => {});
    return () => ctrl.abort();
  }, []);
  return phone;
}

function Card({
  icon: Icon,
  title,
  body,
  children,
}: {
  icon: LucideIcon;
  title: string;
  body: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col rounded-[var(--radius-card)] border border-line bg-white p-6 shadow-card">
      <span className="grid size-12 place-items-center rounded-2xl bg-brand-light">
        <Icon className="size-5 text-brand" strokeWidth={1.8} />
      </span>
      <h2 className="mt-4 text-lg font-semibold text-ink">{title}</h2>
      <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{body}</p>
      <div className="mt-5 pt-1 lg:mt-auto">{children}</div>
    </div>
  );
}

const linkCls = "inline-flex items-center gap-2 break-all text-[15px] font-semibold text-brand hover:underline";

export function Contact() {
  const phone = useSupportPhone();
  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(COMPANY.address)}`;

  return (
    <>
      <PageHeader eyebrow="Contact us" title="We're here to help">
        <p>Questions about your account, a payment, or selling on Kopa? Reach the team directly.</p>
      </PageHeader>

      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <Card
            icon={Mail}
            title="Customer support"
            body="For corps members and vendors — account questions, payments, repayments, payouts and anything else."
          >
            <a href={`mailto:${LINKS.supportEmail}`} className={linkCls}>
              <Mail className="size-4 shrink-0" />
              {LINKS.supportEmail}
            </a>
            {phone && (
              <a href={`tel:${phone.replace(/\s+/g, "")}`} className={`${linkCls} mt-2`}>
                <Phone className="size-4 shrink-0" />
                {phone}
              </a>
            )}
          </Card>

          <Card
            icon={ShieldCheck}
            title="Privacy & data requests"
            body="To access, correct or delete your personal data, or to ask how we use it."
          >
            <a href={`mailto:${LINKS.privacyEmail}`} className={linkCls}>
              <Mail className="size-4 shrink-0" />
              {LINKS.privacyEmail}
            </a>
            <a href="/privacy" className="mt-2 block text-sm text-ink-soft underline-offset-4 hover:text-brand hover:underline">
              Read our Privacy Policy
            </a>
          </Card>

          <Card icon={MapPin} title="Our office" body={`${COMPANY.name} (${COMPANY.rc})`}>
            <a href={mapUrl} target="_blank" rel="noopener noreferrer" className={linkCls}>
              <MapPin className="size-4 shrink-0" />
              <span className="break-normal">{COMPANY.address}</span>
            </a>
          </Card>
        </div>

        {/* already a user → the app is the fastest route */}
        <div className="mt-5 grid gap-5 lg:grid-cols-2">
          <div className="flex gap-4 rounded-[var(--radius-card)] bg-brand-light/60 p-6">
            <LifeBuoy className="mt-0.5 size-6 shrink-0 text-brand" strokeWidth={1.8} />
            <div>
              <h2 className="text-base font-semibold text-ink">Already using Kopa?</h2>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">
                Open <strong className="font-semibold text-ink">Help &amp; Support</strong> in the app to raise a ticket
                and follow our replies. Problem with a purchase? Use <strong className="font-semibold text-ink">Report a
                problem</strong> on the transaction so our team can review it before the money is settled.
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-5 rounded-[var(--radius-card)] bg-brand p-6 text-white">
            <div className="flex gap-4">
              <Smartphone className="mt-0.5 size-6 shrink-0 text-leaf" strokeWidth={1.8} />
              <div>
                <h2 className="text-base font-semibold">Don't have the app yet?</h2>
                <p className="mt-1.5 text-sm text-white/70">For corps members and vendors.</p>
              </div>
            </div>
            <StoreBadges />
          </div>
        </div>

        <p className="mt-8 text-center text-xs text-ink-muted">
          Kopa Xclusive will never ask for your bank password, card PIN or OTP.
        </p>
      </section>
    </>
  );
}
