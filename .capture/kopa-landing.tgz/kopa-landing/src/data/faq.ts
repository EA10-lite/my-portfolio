/**
 * FAQ answers are written from how the app and backend actually behave
 * (checked against kopa-backend and Kopa-Mobile, Oct 2026). Anything about
 * pricing points to the Terms rather than stating a rate, because charges
 * are shown in the app before each transaction.
 *
 * If a rule changes in the backend (e.g. orders.autoConfirmDays), update the
 * matching answer here.
 */
export type Faq = { q: string; a: string[] };
export type FaqGroup = { id: string; title: string; items: Faq[] };

export const FAQ_GROUPS: FaqGroup[] = [
  {
    id: "general",
    title: "General",
    items: [
      {
        q: "What is Kopa Xclusive?",
        a: [
          "Kopa Xclusive is an app that lets NYSC corps members shop now and pay later at approved vendors, and helps those vendors sell to corps members and get paid into a Kopa wallet.",
          "It is operated by Buba Rumbus Tech & Investment Co. Ltd. (RC 7151779), Kaduna.",
        ],
      },
      {
        q: "Who can use Kopa?",
        a: [
          "Serving NYSC corps members, who sign up with their NYSC details, and businesses that sell to them, who sign up as vendors. Both use the same app — you choose \"Continue as a Corp Member\" or \"Continue as a Vendor\" when you sign up.",
        ],
      },
      {
        q: "Where do I download the app?",
        a: ["Kopa is available on the App Store for iPhone and on Google Play for Android. There is no separate vendor website — vendors sign up in the app too."],
      },
      {
        q: "How much does it cost?",
        a: [
          "Downloading the app and signing up are free. Where a purchase, credit request or service carries a charge, the app shows it to you before you confirm — nothing is hidden. Section 8 of our Terms & Conditions covers fees and charges in full.",
        ],
      },
    ],
  },
  {
    id: "corps-members",
    title: "For corps members",
    items: [
      {
        q: "What do I need to sign up?",
        a: [
          "Your NYSC state code, call-up letter number and place of primary assignment (PPA), your NIN and BVN, a passport photograph, and the bank account your allowance is paid into.",
        ],
      },
      {
        q: "How is my spending limit decided?",
        a: [
          "After you submit your details, the Kopa team reviews your profile and sets a credit ceiling when they approve it. You'll see it in the app once you're approved.",
        ],
      },
      {
        q: "How do I get credit to spend?",
        a: [
          "Once you're approved and have set up automatic repayment, request credit in the app — from ₦5,000, in steps of ₦1,000, up to your ceiling. When the request is approved, it appears as Available Credit on your home screen.",
        ],
      },
      {
        q: "How do I pay a vendor?",
        a: [
          "Scan the vendor's QR code or enter the payment code they give you, check the amount, and confirm with your 6-digit transaction PIN. You can also order from vendors in the in-app market.",
        ],
      },
      {
        q: "Can I pay bills with Kopa?",
        a: [
          "Yes — airtime, data, TV subscriptions, electricity and exam pins. If a bill payment fails, the amount goes straight back to your available credit. If the provider is slow to respond, we keep checking until it confirms, and you are never charged twice.",
        ],
      },
    ],
  },
  {
    id: "repayment",
    title: "Repayment",
    items: [
      {
        q: "How do repayments work?",
        a: [
          "Before you can request credit, you set up a direct-debit mandate on the account your allowance is paid into. Each purchase is then collected automatically from that account one month after the purchase date. Your repayment schedule in the app shows every upcoming debit.",
        ],
      },
      {
        q: "What happens if a repayment debit fails?",
        a: [
          "We'll notify you in the app. The Kopa team may try the debit again, so make sure there's money in the linked account. If you're having trouble repaying, contact support as early as you can — the Terms & Conditions explain how late repayment is handled.",
        ],
      },
      {
        q: "Can I turn off automatic repayment?",
        a: [
          "Yes, once you have nothing left to repay. While a repayment is still scheduled, the mandate stays in place so your credit can be collected as agreed.",
        ],
      },
    ],
  },
  {
    id: "vendors",
    title: "For vendors",
    items: [
      {
        q: "What do I need to sign up as a vendor?",
        a: [
          "Your business name, category, phone number and address, your CAC registration number (RC or BN), the owner's details and photo, and the bank account you want payouts sent to. The Kopa team reviews your details before you can receive payments.",
        ],
      },
      {
        q: "How do I get paid?",
        a: [
          "For in-person sales, generate a payment code or QR in the app; when the corps member confirms, the amount is credited to your Kopa wallet. For marketplace orders, the money is held safely until the buyer confirms delivery, then it moves to your wallet.",
        ],
      },
      {
        q: "How do I withdraw my money?",
        a: [
          "Request a withdrawal from your wallet (minimum ₦100). The Kopa team reviews it and sends it by bank transfer to your registered account. If a withdrawal is declined or the transfer fails, the amount goes back to your wallet.",
        ],
      },
      {
        q: "How do marketplace orders work?",
        a: [
          "When a corps member orders from your listings, the payment is held until delivery is confirmed. Ship within 7 days or the order is cancelled and refunded. After you mark it delivered, the buyer has 7 days to confirm or report a problem — if they do nothing, it's confirmed automatically and you're paid.",
        ],
      },
    ],
  },
  {
    id: "safety",
    title: "Safety & support",
    items: [
      {
        q: "Something went wrong with a purchase. What do I do?",
        a: [
          "Open the transaction in the app and tap Report a problem. Our team reviews both sides before the money is settled. Each purchase can have one open report at a time.",
        ],
      },
      {
        q: "Is my information safe?",
        a: [
          "We protect your data in line with the Nigeria Data Protection Act 2023. Every payment needs your transaction PIN, and you can sign in with Face ID. Our Privacy Policy explains what we collect and why.",
        ],
      },
      {
        q: "Will Kopa ever ask for my bank password, PIN or OTP?",
        a: ["No. Never share your bank password, card PIN or OTP with anyone — including someone claiming to be from Kopa Xclusive."],
      },
      {
        q: "How do I contact Kopa?",
        a: [
          "In the app, open Help & Support to raise a ticket and follow our replies. You can also email support@kopaxclusive.com, or see all our details on the Contact page.",
        ],
      },
    ],
  },
];
