/**
 * Kopa Xclusive legal documents — copied verbatim from
 * Kopa-Mobile/lib/legal/documents.ts so the website and app say the same thing.
 * Re-copy that file when Legal updates it.
 *
 * Original note from the app:
 *
 * These are bundled rather than fetched because the app stores require the
 * policy to be reachable offline and before sign-in, and because
 * GET /settings/public currently returns empty `termsUrl` / `privacyUrl`.
 * If those are ever populated the screen offers them as an "open online"
 * link, but this text stays the source of truth in the app.
 *
 * Generated from the source documents — edit those and regenerate rather
 * than hand-editing the text here.
 */

export interface LegalSection {
  /** e.g. "1. DATA CONTROLLER". Empty for the preamble. */
  title: string;
  body: string;
}

export interface LegalDocument {
  key: "terms" | "privacy";
  title: string;
  effectiveDate: string;
  lastUpdated: string;
  sections: LegalSection[];
}

export const PRIVACY_POLICY: LegalDocument = {
  key: "privacy",
  title: "Privacy Policy",
  effectiveDate: "2 October 2026",
  lastUpdated: "2 October 2026",
  sections: [
  {
    title: ``,
    body: `KOPA XCLUSIVE PRIVACY POLICY Serve… We’ve Got You Covered. Effective Date: 2 October 2026 Last Updated: 2 October 2026 Kopa Xclusive ("Kopa Xclusive", "Kopa", "we", "us", or "our") is a technology platform operated by Buba Rumbus Tech & Investment Co. Ltd. Our purpose is simple: to serve. From everyday needs to financial services and opportunities, Kopa Xclusive is built around the people we serve. Just as we are committed to serving you, we are committed to protecting the information you entrust to us. This Privacy Policy explains how we collect, use, disclose, store, protect and otherwise process personal data when you access or use the Kopa Xclusive mobile application, website, platform, products and related services. This Privacy Policy is intended to operate in accordance with applicable Nigerian data-protection law, including the Nigeria Data Protection Act 2023 (NDPA), and applicable requirements governing the distribution of our services through digital platforms.`,
  },
  {
    title: `1. DATA CONTROLLER`,
    body: `For purposes of applicable data-protection law, the relevant data controller is: Buba Rumbus Tech & Investment Co. Ltd. Trading/Product Name: Kopa Xclusive CAC Registration Number: RC 7151779 Registered Office: No. 3 Kachia Road, Barnawa, Kaduna State, Nigeria. Website: www.kopaxclusive.com.ng Privacy Email: privacy@kopaxclusive.com.ng 
Kopa Xclusive may work with authorised data processors, technology providers, payment providers, financial institutions, credit-reference providers, identity-verification providers and other service providers to deliver its services.`,
  },
  {
    title: `2. OUR COMMITMENT TO YOU`,
    body: `At Kopa Xclusive, service is at the heart of what we do. Our promise is: Serve… We’ve Got You Covered. This means we aim to provide our users with services that are useful, accessible, secure and responsible. It also means treating your personal information with care. We do not view your personal data simply as information. We recognise that it represents a part of your identity, financial life and interaction with our platform. Accordingly, we seek to: ● Collect information responsibly; ● Explain why information is collected; ● Use information for legitimate purposes; ● Protect information against unauthorised access; ● Give you appropriate control over your information; ● Work with trusted service providers; ● Respect your rights under applicable data-protection law.`,
  },
  {
    title: `3. SCOPE OF THIS POLICY`,
    body: `This Privacy Policy applies to personal data processed through: ● The Kopa Xclusive mobile application; ● www.kopaxclusive.com.ng; ● Kopa Xclusive user accounts; ● Merchant and vendor services; 
● Credit and payment services; ● Airtime and data services; ● Customer-support channels; ● Kopa Xclusive programmes and services; ● Other services operated by Kopa Xclusive that expressly refer to this Privacy Policy. By using Kopa Xclusive, you acknowledge that you have read and understood this Privacy Policy. Where a particular Kopa Xclusive service requires additional privacy information or consent, we may provide a separate privacy notice before collecting or processing the relevant information.`,
  },
  {
    title: `4. WHAT IS PERSONAL`,
    body: `DATA? Personal data means information relating to an identified or identifiable individual. Depending on the services you use, this may include: ● Your name; ● Telephone number; ● Email address; ● Identification information; ● Financial information; ● Transaction information; ● Device information; ● Location information where applicable; ● Other information that can reasonably be associated with you.`,
  },
  {
    title: `5. INFORMATION WE COLLECT`,
    body: `We seek to collect information that is reasonably necessary for the relevant service, legal obligation, security purpose or other lawful purpose. 5.1 Registration and Profile Information We may collect: ● Full name; 
● Phone number; ● Email address; ● Date of birth; ● Residential address; ● State of residence; ● State of origin; ● Gender where required; ● Nationality where required; ● Employment or professional information; ● NYSC-related information; ● Place of primary assignment; ● Other information necessary to establish and maintain your account.`,
  },
  {
    title: `6. IDENTITY AND KYC INFORMATION`,
    body: `Depending on the service you request, we may collect or verify: ● BVN; ● NIN; ● Government-issued identification; ● NYSC identification information; ● Identification documents; ● Photograph; ● Selfie or liveness information; ● Verification information; ● Other information required for lawful identity verification. We may use authorised third-party identity-verification providers to verify information supplied by you. We will not request information merely because it is technically available. Information should be collected only where reasonably necessary for the relevant purpose.`,
  },
  {
    title: `7. FINANCIAL AND PAYMENT INFORMATION`,
    body: `Where you use payment, credit, repayment or other financial services, we may process: 
● Bank account information; ● Payment information; ● Transaction records; ● Credit information; ● Credit-limit information; ● Repayment information; ● Outstanding obligations; ● Direct-debit mandate information; ● Merchant payment information; ● Payment status; ● Financial-institution information; ● Other information necessary to provide the relevant financial service. Kopa Xclusive does not request your banking password, ATM PIN or OTP for ordinary account operation. You should never disclose your banking password, PIN or OTP to another person claiming to represent Kopa Xclusive.`,
  },
  {
    title: `8. CREDIT AND CREDIT-ASSESSMENT INFORMATION`,
    body: `Where Kopa Xclusive provides or facilitates credit-related services, we may process information necessary to assess and manage credit risk. This may include: ● Identity information; ● Financial information; ● Transaction history; ● Repayment history; ● Credit information; ● Employment information; ● Income information where applicable; ● Information obtained from authorised credit-reference agencies; ● Information obtained from financial institutions or other lawful sources; ● Fraud and risk indicators. This information may be used to: ● Assess eligibility; 
● Determine appropriate credit limits; ● Assess affordability and repayment capacity; ● Manage credit exposure; ● Monitor repayment; ● Prevent fraud; ● Recover legitimate outstanding obligations; ● Comply with legal and regulatory requirements. Where required by law, you will be informed where automated decision-making or profiling is used and of the relevant rights available to you.`,
  },
  {
    title: `9. TRANSACTION INFORMATION`,
    body: `When you conduct a transaction through Kopa Xclusive, we may process: ● Transaction amount; ● Date and time; ● Merchant/vendor information; ● Transaction reference; ● Payment status; ● Service purchased; ● Repayment information; ● Relevant account information. This information helps us provide services, maintain accurate records, prevent fraud and resolve disputes.`,
  },
  {
    title: `10. DEVICE AND TECHNICAL INFORMATION`,
    body: `When you use our website or mobile application, we may collect technical information such as: ● Device type; ● Operating system; ● Application version; ● IP address; ● Browser information; 
● Network information; ● Device identifiers where lawfully necessary; ● Crash and diagnostic information; ● Login information; ● Security logs. We do not use device information for purposes unrelated to the operation, security or improvement of our services unless separately disclosed and permitted by law.`,
  },
  {
    title: `11. LOCATION INFORMATION`,
    body: `Kopa Xclusive may request access to location information only where it is necessary for a specific service and permitted by law. If a feature requires location information, we will provide an appropriate permission request or notice. You may control location permissions through your device settings, subject to the effect that disabling the permission may have on particular services.`,
  },
  {
    title: `12. CAMERA, PHOTOS AND DOCUMENTS`,
    body: `Certain features may require access to your camera, photographs or documents, including: ● Identity verification; ● Uploading identification documents; ● Profile verification; ● Submitting supporting documents; ● Other user-requested functionality. We will not access your camera, photos or files for unrelated purposes. Where your operating system provides a permission mechanism, we will request the relevant permission before accessing protected resources.`,
  },
  {
    title: `13. CONTACTS, SMS AND OTHER DEVICE PERMISSIONS`,
    body: `Kopa Xclusive will not request access to your contacts, SMS, call logs or other sensitive device information unless the relevant permission is necessary for a specific lawful functionality and the applicable platform permits that use. Where a permission is not necessary for a core feature, we will not request it merely to collect additional information.`,
  },
  {
    title: `14. HOW WE COLLECT INFORMATION`,
    body: `We may collect personal data: 1. Directly from you; 2. When you create or use your account; 3. When you complete a transaction; 4. When you communicate with customer support; 5. From merchants or vendors involved in your transaction; 6. From authorised payment providers; 7. From financial institutions where lawfully permitted; 8. From authorised identity-verification providers; 9. From authorised credit-reference agencies; 10. From fraud-prevention and security providers; 11. From NYSC or other institutions where legally permitted and necessary; 12. Automatically from your device or browser where appropriate; 13. From other lawful sources.`,
  },
  {
    title: `15. WHY WE PROCESS YOUR PERSONAL DATA`,
    body: `We may process your personal data for the following purposes. Providing Services 
To: ● Create and manage your account; ● Process transactions; ● Provide payment services; ● Facilitate credit services; ● Process repayments; ● Provide airtime and data services; ● Connect you with participating merchants; ● Provide customer support; ● Deliver other Kopa Xclusive services. Identity Verification To: ● Verify your identity; ● Conduct KYC procedures; ● Prevent identity theft; ● Protect accounts; ● Meet legal and regulatory requirements. Credit Assessment To: ● Assess credit applications; ● Determine eligibility; ● Establish credit limits; ● Assess repayment capacity; ● Monitor credit exposure; ● Manage repayment. Fraud and Security To: ● Detect suspicious activity; ● Prevent fraudulent transactions; ● Protect users; ● Protect merchants; ● Detect account takeover; ● Investigate security incidents; ● Maintain platform security. 
Legal and Regulatory Compliance To comply with applicable: ● Nigerian laws; ● Data-protection requirements; ● Financial regulations; ● KYC requirements; ● Anti-money-laundering requirements; ● Court orders; ● Regulatory requests; ● Law-enforcement requirements. Service Improvement To: ● Understand platform usage; ● Diagnose technical problems; ● Improve performance; ● Develop features; ● Improve user experience; ● Monitor reliability and security.`,
  },
  {
    title: `16. LAWFUL BASIS FOR PROCESSING`,
    body: `Depending on the circumstances, Kopa Xclusive may rely on one or more lawful bases recognised under applicable data-protection law, including: ● Consent; ● Performance of a contract; ● Steps taken at your request before entering into a contract; ● Compliance with a legal obligation; ● Protection of vital interests; ● Legitimate interests where applicable; ● Public interest where applicable; ● Establishment, exercise or defence of legal claims; ● Other lawful grounds recognised by applicable law. Where processing relies on consent, consent will be requested in an appropriate and understandable manner. 
You may withdraw consent where the processing is based on consent, subject to applicable legal limitations. Withdrawal of consent does not affect processing that was lawful before withdrawal.`,
  },
  {
    title: `17. DATA MINIMISATION`,
    body: `Kopa Xclusive seeks to collect information that is adequate, relevant and reasonably necessary for the purpose for which it is processed. We do not intend to collect personal information simply because it is available or potentially useful. Where information is optional, we will seek to distinguish it from information that is necessary for a particular service.`,
  },
  {
    title: `18. SHARING YOUR PERSONAL DATA`,
    body: `We may disclose personal data to third parties where necessary and lawful. These may include: Payment Providers For payment processing, settlements, direct debit and related services. Financial Institutions Where necessary to provide or facilitate financial services. Credit-Reference Agencies For credit assessment, credit reporting and responsible credit management where legally permitted. Identity-Verification Providers For KYC and identity verification. 
Merchants and Vendors Where necessary to complete or support a transaction or service requested by you. Technology Providers Including providers of: ● Cloud infrastructure; ● Hosting; ● Database services; ● Security; ● Analytics; ● Communications; ● Customer support; ● Software infrastructure. Professional Advisers Such as lawyers, accountants, auditors and other professional advisers. Regulators and Government Authorities Where required or permitted by law. Fraud-Prevention Providers Where necessary to detect, prevent or investigate fraud or financial crime. We do not sell personal or sensitive user data for monetary consideration.`,
  },
  {
    title: `19. THIRD-PARTY PROCESSORS`,
    body: `Some service providers process personal data on our behalf. Where we appoint a third-party processor, we seek to require appropriate confidentiality, security and data-protection obligations. Third-party providers may only process personal data for authorised purposes and in accordance with applicable contractual and legal requirements.`,
  },
  {
    title: `20. INTERNATIONAL DATA TRANSFERS`,
    body: `Some of our technology or service providers may operate outside Nigeria. Where personal data is transferred across borders, Kopa Xclusive will take steps required by applicable Nigerian data-protection law to ensure that the transfer is lawful and that appropriate safeguards are implemented.`,
  },
  {
    title: `21. DATA SECURITY`,
    body: `We use reasonable technical and organisational safeguards designed to protect personal data against: ● Unauthorised access; ● Unauthorised disclosure; ● Loss; ● Theft; ● Alteration; ● Destruction; ● Misuse; ● Unlawful processing. Security measures may include: ● Encryption; ● Secure communications; ● Access controls; ● Authentication; ● Monitoring; ● Logging; ● Secure infrastructure; ● Role-based access; ● Security testing; ● Incident-response procedures. No online system can guarantee absolute security. You are responsible for protecting your account credentials and authentication information.`,
  },
  {
    title: `22. DATA RETENTION`,
    body: `We retain personal data only for as long as reasonably necessary for the purposes for which it was collected or as required by applicable law. The retention period may depend on: ● The nature of the information; ● The purpose for which it was collected; ● Whether you maintain an active account; ● Financial and transaction-record requirements; ● Legal and regulatory requirements; ● Fraud-prevention requirements; ● Dispute-resolution requirements. Where personal data is no longer required, we will take appropriate steps to delete, anonymise or securely dispose of it, subject to lawful retention requirements.`,
  },
  {
    title: `23. ACCOUNT DELETION`,
    body: `You may request deletion of your Kopa Xclusive account and personal data through the account-deletion mechanism provided in the application or through our website/contact channel. Account deletion does not necessarily mean immediate deletion of every record. Certain information may need to be retained where required by law, regulation, financial-record obligations, fraud-prevention requirements, dispute resolution, legal claims or other lawful obligations. Where information is not required to be retained, it will be deleted or anonymised in accordance with our data-retention procedures.`,
  },
  {
    title: `24. YOUR DATA-PROTECTION RIGHTS`,
    body: `Subject to applicable law, you may have the right to: 1. Be informed about how your personal data is processed; 2. Request access to your personal data; 
3. Request correction of inaccurate or incomplete information; 4. Object to certain processing; 5. Request restriction of processing; 6. Request deletion or erasure where applicable; 7. Request portability of your data where applicable; 8. Withdraw consent where processing is based on consent; 9. Object to certain automated decision-making; 10. Request human intervention where applicable; 11. Lodge a complaint with the Nigeria Data Protection Commission.`,
  },
  {
    title: `25. DATA SUBJECT REQUESTS`,
    body: `To exercise your rights, contact: Privacy Team Kopa Xclusive Buba Rumbus Tech & Investment Co. Ltd. Email: privacy@kopaxclusive.com.ng Website: www.kopaxclusive.com.ng We may request reasonable information to verify your identity before processing a request involving your personal data. This is necessary to prevent unauthorised persons from obtaining or changing personal information.`,
  },
  {
    title: `26. AUTOMATED DECISION-MAKING AND PROFILING`,
    body: `Certain Kopa Xclusive services may use automated systems to assist with: ● Identity verification; ● Fraud detection; ● Transaction monitoring; ● Risk assessment; ● Credit assessment; 
● Account security. Where automated decision-making has a legal or similarly significant effect on you, applicable law may provide rights to information, objection, human intervention or challenge. Where applicable, we will provide information about the nature and significance of such processing.`,
  },
  {
    title: `27. MARKETING`,
    body: `Where permitted by applicable law, Kopa Xclusive may send promotional communications about: ● Products; ● Services; ● Offers; ● Programmes; ● Events; ● Educational content. You may opt out of marketing communications. However, you may continue to receive essential service communications, including: ● Transaction notifications; ● Security alerts; ● Repayment notifications; ● Account notices; ● Legal or regulatory notices.`,
  },
  {
    title: `28. COOKIES AND SIMILAR TECHNOLOGIES`,
    body: `Our website may use cookies and similar technologies for purposes such as: ● Website functionality; ● Security; ● Session management; 
● Preferences; ● Analytics; ● Performance monitoring. Where required, we will provide appropriate cookie controls and consent mechanisms.`,
  },
  {
    title: `29. CHILDREN'S PRIVACY`,
    body: `Kopa Xclusive services are not intended for children below the minimum age legally permitted to use the relevant service. We do not knowingly collect children's personal data in violation of applicable law. If we become aware that personal data has been collected from a child unlawfully, we will take appropriate steps to address the situation.`,
  },
  {
    title: `30. THIRD-PARTY WEBSITES AND SERVICES`,
    body: `Kopa Xclusive may integrate with or provide links to third-party services. These third parties may have separate privacy policies. Kopa Xclusive is not responsible for privacy practices of third-party services that it does not control. You should review the relevant third party's privacy policy before providing information directly to that third party.`,
  },
  {
    title: `31. DATA BREACHES`,
    body: `If Kopa Xclusive becomes aware of a personal-data breach, we will assess and respond to the incident in accordance with applicable law and our internal incident-response procedures. 
Where notification to affected individuals or a regulatory authority is required, we will make the required notification in accordance with applicable legal requirements.`,
  },
  {
    title: `32. ACCURACY OF YOUR INFORMATION`,
    body: `You are responsible for providing accurate, complete and current information. You should update your information when it changes. Providing inaccurate, fraudulent or misleading information may result in: ● Account restrictions; ● Service suspension; ● Credit restrictions; ● Transaction cancellation; ● Account termination; ● Reporting to appropriate authorities where legally required.`,
  },
  {
    title: `33. DIRECT DEBIT AND RECURRING PAYMENTS`,
    body: `Where you voluntarily authorise a direct-debit or recurring-payment mandate, Kopa Xclusive and/or its authorised payment partners may process information required to establish, manage and execute the mandate. You will be provided with relevant information and required authorisation before a mandate is established. Payment processing may depend on third-party financial institutions and payment providers.`,
  },
  {
    title: `34. CREDIT REPAYMENT AND COLLECTION`,
    body: `Where you have a valid outstanding obligation to Kopa Xclusive or a relevant financial partner, we may process and use information necessary to: ● Notify you of outstanding obligations; ● Process authorised repayments; ● Manage payment mandates; ● Communicate with you regarding repayment; ● Maintain accurate financial records; ● Take lawful recovery measures; ● Meet regulatory requirements. We will handle repayment and collection activities in accordance with applicable law and applicable contractual terms.`,
  },
  {
    title: `35. CORPORATE TRANSACTIONS`,
    body: `If Kopa Xclusive or its relevant business assets are involved in a merger, acquisition, investment, restructuring, financing, sale or similar corporate transaction, personal data may be transferred as part of the transaction where legally permitted. Appropriate privacy protections will continue to apply.`,
  },
  {
    title: `36. CHANGES TO THIS PRIVACY POLICY`,
    body: `We may update this Privacy Policy from time to time. Changes may occur because of: ● New services; ● Changes to our technology; ● Changes to applicable laws; ● Regulatory requirements; ● Changes to our data-processing practices. Where material changes occur, we may notify users through the application, website, email or another appropriate channel. The latest version will always display the applicable Last Updated date.`,
  },
  {
    title: `37. COMPLAINTS`,
    body: `If you believe Kopa Xclusive has processed your personal data improperly, we encourage you to contact us first. We will review reasonable complaints and take appropriate steps to address them. You may also have the right to lodge a complaint with the Nigeria Data Protection Commission (NDPC).`,
  },
  {
    title: `38. GOVERNING LAW`,
    body: `This Privacy Policy is governed by applicable laws of the Federal Republic of Nigeria, including the Nigeria Data Protection Act 2023 and other applicable data-protection requirements. Where mandatory privacy laws of another jurisdiction apply to a particular user or transaction, Kopa Xclusive will take appropriate steps to comply with those requirements where applicable.`,
  },
  {
    title: `39. CONTACT INFORMATION KOPA XCLUSIVE`,
    body: `Powered by: Buba Rumbus Tech & Investment Co. Ltd. CAC Registration Number: RC 7151779 Registered Office: No. 3 Kachia Road, Barnawa, Kaduna State, Nigeria Website: www.kopaxclusive.com.ng 
Privacy Email: privacy@kopaxclusive.com.ng Effective Date: 2 October 2026 Last Updated: 2 October 2026 SERVE… WE'VE GOT YOU COVERED. At Kopa Xclusive, our commitment goes beyond providing a platform. We are building a service ecosystem designed to support people through their journey — from NYSC to the next level. Your trust matters to us. Your information matters to us. Your security matters to us. Serve… We’ve Got You Covered. Kopa Xclusive From NYSC to Next Level. © 2026 Buba Rumbus Tech & Investment Co. Ltd. All rights reserved.`,
  },
  ],
};

export const TERMS_AND_CONDITIONS: LegalDocument = {
  key: "terms",
  title: "Terms & Conditions",
  effectiveDate: "2 October 2026",
  lastUpdated: "2 October 2026",
  sections: [
  {
    title: ``,
    body: `KOPA XCLUSIVE

MASTER TERMS & CONDITIONS

Effective Date: 2 October 2026
Last Updated: 2 October 2026

Operator: Buba Rumbus Tech & Investment Co. Ltd.
Company Registration Number: RC 7151779
Registered Address: No. 3 Kachia Road, Barnawa, Kaduna State, Nigeria.

Kopa Xclusive (“Kopa”, “we”, “us”, “our” or the “Company”) operates a technology platform designed to provide eligible users with access to selected payment, credit, merchant, airtime/data, service and other financial or technology-enabled services through the Kopa platform.

These Terms and Conditions (“Terms”) govern your access to and use of the Kopa mobile application, website, platform, products and related services.

By registering for, accessing or using Kopa, you acknowledge that you have read, understood and agreed to these Terms and all applicable policies incorporated into them.`,
  },
  {
    title: `1. DEFINITIONS`,
    body: `For purposes of these Terms:

“Account” means the account created by a User on the Kopa Platform.

“App” means the Kopa Xclusive mobile application.

“Credit Facility” means any credit, deferred payment, BNPL, advance or other facility made available to an eligible User through Kopa or a participating financial institution or credit provider.

“Merchant” means an approved business, vendor or service provider participating in the Kopa ecosystem.

“User” means any person who accesses or uses Kopa.

“Credit Provider” means Kopa where legally permitted, or an appropriately licensed financial institution or other authorized provider supplying a Credit Facility through or in connection with Kopa.

“Payment Provider” means an authorized payment service provider, bank, processor, switch, acquiring institution or other payment partner used by Kopa.

“Services” means all services made available through Kopa from time to time.

“Personal Data” has the meaning assigned to it under applicable Nigerian data-protection law.

“Transaction” means any payment, purchase, credit request, repayment, airtime/data purchase, merchant transaction, refund or other activity carried out through the Platform.`,
  },
  {
    title: `2. ELIGIBILITY`,
    body: `You may use Kopa only where:

1. you meet the applicable minimum age requirement;
2. you have legal capacity to enter into a binding agreement;
3. you provide accurate and complete information;
4. you successfully complete applicable identity, KYC, fraud, credit or verification procedures;
5. you comply with applicable laws and regulations; and
6. you satisfy any additional eligibility criteria applicable to a particular service.

Kopa may impose additional eligibility requirements for specific products.

Eligibility for the Kopa Platform does not automatically constitute approval for credit.`,
  },
  {
    title: `3. ACCOUNT REGISTRATION`,
    body: `You must provide accurate, current and complete information when creating an Account.

You are responsible for:

- protecting your login credentials;
- maintaining the confidentiality of authentication information;
- preventing unauthorized access to your device and Account;
- immediately reporting suspected unauthorized access; and
- ensuring information supplied to Kopa remains accurate.

You must not:

- create an Account using another person's identity;
- provide false information;
- impersonate another person;
- create multiple accounts for fraudulent purposes;
- sell, transfer or lend your Account; or
- permit another person to use your Account in a manner that violates these Terms.

Kopa may suspend or restrict an Account where reasonably necessary to protect the User, Kopa, a Merchant, a financial partner or the integrity of the Platform.`,
  },
  {
    title: `4. VERIFICATION AND KYC`,
    body: `Kopa may conduct identity verification, customer due diligence, fraud screening, credit assessment and other verification procedures.

Depending on the service requested, Kopa or its authorized partners may require information including:

- full name;
- telephone number;
- email address;
- date of birth;
- government-issued identification;
- BVN and/or NIN where legally applicable;
- bank account information;
- employment or income information;
- transaction information;
- device and security information; and
- other information reasonably necessary for the relevant service.

Kopa will process Personal Data in accordance with its Privacy Policy and applicable data-protection laws.

Kopa will not request access to information that it is prohibited from collecting under applicable law or platform policies.`,
  },
  {
    title: `5. SERVICES`,
    body: `Kopa may provide or facilitate access to services including:

- merchant purchases;
- Buy Now, Pay Later services;
- credit facilities;
- airtime and data purchases;
- bill or service payments;
- merchant offers;
- repayment services;
- financial education;
- employment or entrepreneurship-related services; and
- other services introduced from time to time.

Some Services may be provided by third-party regulated institutions.

Where a third party is the actual financial service provider, the applicable provider's terms will also apply.`,
  },
  {
    title: `6. CREDIT FACILITIES`,
    body: `Where Kopa facilitates access to credit, the User will receive specific credit terms before accepting the relevant facility.

The applicable credit disclosure shall state, where relevant:

- principal amount;
- total amount payable;
- interest or service charges;
- applicable fees;
- repayment date(s);
- repayment frequency;
- applicable penalties or default charges;
- consequences of late repayment;
- cancellation or withdrawal rights where applicable; and
- applicable dispute and complaint procedures.

No credit facility is approved merely because a User has registered with Kopa.

Each Credit Facility is subject to eligibility, affordability, risk and verification requirements.`,
  },
  {
    title: `7. CREDIT DECISIONING`,
    body: `Kopa and/or an authorized Credit Provider may use information supplied by the User, transaction information, permitted credit information and other legally obtained information to determine eligibility and credit limits.

Credit decisions may include:

- approval;
- rejection;
- reduced credit limit;
- increased credit limit;
- temporary suspension;
- repayment restructuring; or
- other risk-based decisions.

Kopa does not guarantee approval of any credit application.

Where legally required, Users may request information concerning applicable decision-making and complaint procedures.`,
  },
  {
    title: `8. FEES, INTEREST AND CHARGES`,
    body: `Before completing a transaction involving a fee, Kopa will provide the User with the applicable charge or pricing information.

No material fee should be hidden from the User.

Applicable charges may include:

- transaction fees;
- merchant/service fees where applicable;
- credit-related charges;
- subscription charges;
- late-payment charges where legally permitted;
- third-party provider charges; and
- other disclosed charges.

The total cost applicable to a credit transaction shall be disclosed before acceptance.`,
  },
  {
    title: `9. REPAYMENT`,
    body: `Where a User receives a Credit Facility, the User agrees to repay the amount due according to the applicable Credit Agreement.

Repayment may be made through approved payment channels.

Where the User has provided a valid direct debit mandate, repayment may be initiated in accordance with the applicable mandate, payment-system rules and the Credit Agreement.

A User should not assume that cancellation of the Kopa App or deletion of an Account cancels an outstanding financial obligation.`,
  },
  {
    title: `10. DIRECT DEBIT`,
    body: `Where applicable, a User may authorize repayment through direct debit.

The direct debit authorization shall be separately presented to the User and shall specify the relevant authorization, account/payment information, applicable limits or conditions, revocation process and other required information.

Kopa will not represent a direct debit mandate as unlimited authority to withdraw funds beyond the authority granted and applicable law.`,
  },
  {
    title: `11. MERCHANT TRANSACTIONS`,
    body: `Users may purchase goods or services from participating Merchants.

Kopa may authenticate a transaction using mechanisms including:

- PIN;
- OTP;
- barcode;
- QR code;
- transaction reference;
- device authentication; or
- other approved security mechanisms.

A User must not disclose authentication credentials to a Merchant or any other unauthorized person.`,
  },
  {
    title: `12. MERCHANT SETTLEMENT`,
    body: `Merchant settlement may occur according to the Merchant Agreement and applicable payment-provider arrangements.

Settlement timing may vary depending on:

- transaction verification;
- fraud checks;
- payment-provider processing;
- reconciliation;
- refunds;
- chargebacks;
- weekends or public holidays;
- system outages; or
- other legitimate operational circumstances.

A transaction appearing as approved within the App does not necessarily mean that final settlement to the Merchant has occurred.`,
  },
  {
    title: `13. AIRTIME AND DATA SERVICES`,
    body: `Where Kopa provides airtime or data services:

1. the User must verify the recipient telephone number before confirmation;
2. Kopa is not responsible for losses caused by an incorrect number supplied by the User, subject to applicable consumer-protection requirements;
3. transactions may be subject to telecom-network availability;
4. failed transactions will be handled according to the applicable transaction and refund procedure; and
5. Kopa may rely on authorized telecommunications or payment partners to process the transaction.

Where a transaction is debited but the service is not successfully delivered, Kopa will investigate the transaction and process any applicable reversal or refund in accordance with its refund and dispute procedures.`,
  },
  {
    title: `14. REFUNDS, REVERSALS AND CHARGEBACKS`,
    body: `A User may request a refund or report an unsuccessful transaction through Kopa's designated complaint channels.

Refunds may be subject to:

- the nature of the transaction;
- Merchant policies;
- payment-provider rules;
- telecom-provider rules;
- fraud investigations;
- applicable law; and
- whether the transaction has already been settled.

Kopa will not unreasonably delay a valid refund or reversal.`,
  },
  {
    title: `15. ERRORS AND UNAUTHORIZED TRANSACTIONS`,
    body: `Users must promptly notify Kopa of:

- unauthorized transactions;
- duplicate transactions;
- incorrect charges;
- failed transactions;
- suspected fraud;
- compromised credentials; or
- other transaction errors.

Kopa may investigate reported transactions and may request reasonable information necessary to resolve the matter.`,
  },
  {
    title: `16. FRAUD AND PROHIBITED ACTIVITIES`,
    body: `Users must not use Kopa to:

- commit fraud;
- launder money;
- finance unlawful activities;
- impersonate another person;
- manipulate transactions;
- create fake transactions;
- exploit technical vulnerabilities;
- bypass security controls;
- submit false documents;
- abuse promotional offers;
- manipulate merchants;
- interfere with Platform operations;
- reverse-engineer the Platform unlawfully; or
- conduct any activity prohibited by Nigerian or applicable international law.

Kopa may suspend transactions, freeze or restrict access where reasonably necessary to investigate suspected fraud, subject to applicable law and regulatory requirements.`,
  },
  {
    title: `17. PRIVACY AND DATA PROTECTION`,
    body: `Kopa's collection and processing of Personal Data is governed by its Privacy Policy.

Kopa shall process Personal Data in accordance with applicable Nigerian data-protection legislation and applicable regulatory requirements.

Where a third-party provider processes Personal Data on behalf of or in connection with Kopa, appropriate contractual and technical controls shall apply.

Users may exercise applicable data-protection rights through the channels identified in the Privacy Policy.`,
  },
  {
    title: `18. THIRD-PARTY SERVICES`,
    body: `Kopa may integrate with third parties including:

- banks;
- payment service providers;
- credit-information providers;
- telecommunications providers;
- identity-verification providers;
- merchants;
- technology providers;
- cloud providers; and
- other regulated or commercial partners.

Third-party services may be subject to separate terms and privacy notices.

Kopa will disclose material third-party relationships where required by law or applicable regulatory/platform rules.`,
  },
  {
    title: `19. SERVICE AVAILABILITY`,
    body: `Kopa will use reasonable efforts to maintain availability of its Platform.

However, availability may be affected by:

- telecommunications failures;
- payment-network failures;
- bank outages;
- third-party service failures;
- maintenance;
- cybersecurity incidents;
- force majeure;
- regulatory intervention; or
- other circumstances beyond Kopa's reasonable control.`,
  },
  {
    title: `20. SECURITY`,
    body: `Kopa shall maintain reasonable technical and organizational measures designed to protect its systems and information.

Users must maintain reasonable security practices, including:

- keeping passwords and PINs confidential;
- using secure devices;
- not sharing OTPs;
- reporting suspicious activity; and
- maintaining control over registered telephone numbers and email accounts.`,
  },
  {
    title: `21. COMPLAINTS AND CUSTOMER SUPPORT`,
    body: `Users may submit complaints through Kopa's designated customer-support channels.

Kopa will maintain a complaint-management process designed to provide:

- acknowledgement;
- investigation;
- communication;
- resolution;
- escalation; and
- recordkeeping.

Where a regulated financial institution is responsible for the relevant service, complaints may also be escalated through the applicable institution's regulatory complaint process.`,
  },
  {
    title: `22. ACCOUNT SUSPENSION AND TERMINATION`,
    body: `Kopa may suspend or terminate an Account where:

- the User breaches these Terms;
- fraud is suspected;
- the User provides false information;
- the User creates a security risk;
- required verification cannot be completed;
- continued access is prohibited by law;
- a regulatory authority requires action; or
- continued access presents a material risk to Kopa, Users or partners.

Suspension or termination does not automatically extinguish outstanding financial obligations.`,
  },
  {
    title: `23. INTELLECTUAL PROPERTY`,
    body: `The Kopa name, trademarks, software, interface, content, designs, databases and other intellectual property belong to Kopa or its licensors unless otherwise stated.

Users receive a limited, non-exclusive, non-transferable right to use the Platform for its intended lawful purpose.`,
  },
  {
    title: `24. LIMITATION OF LIABILITY`,
    body: `To the maximum extent permitted by applicable law, Kopa shall not be liable for losses caused solely by circumstances outside its reasonable control, including failures of third-party networks or services.

Nothing in these Terms shall exclude or limit liability that cannot lawfully be excluded or limited.

Nothing in these Terms removes statutory consumer rights available to a User.`,
  },
  {
    title: `25. INDEMNITY`,
    body: `To the extent permitted by law, a User may be responsible for losses reasonably incurred by Kopa as a direct result of the User's fraud, deliberate misuse of the Platform or material breach of these Terms.

This clause shall not operate to remove statutory consumer rights.`,
  },
  {
    title: `26. CHANGES TO THESE TERMS`,
    body: `Kopa may update these Terms from time to time.

Where a change materially affects Users, Kopa shall provide appropriate notice through the Platform or other reasonable communication channels.

Continued use of the Platform after the effective date of an update may constitute acceptance where legally permissible.`,
  },
  {
    title: `27. GOVERNING LAW`,
    body: `These Terms shall be governed by the laws of the Federal Republic of Nigeria.

Nothing in these Terms prevents a consumer from exercising rights or remedies available under applicable Nigerian law.`,
  },
  {
    title: `28. DISPUTE RESOLUTION`,
    body: `Kopa encourages Users to first submit disputes through its internal complaints process.

Where a dispute cannot be resolved through internal procedures, the parties may pursue applicable mediation, arbitration, regulatory escalation or court proceedings as permitted by applicable law.`,
  },
  {
    title: `29. SEVERABILITY`,
    body: `If any provision of these Terms is determined to be invalid or unenforceable, the remaining provisions shall remain effective to the extent permitted by law.`,
  },
  {
    title: `30. ENTIRE AGREEMENT`,
    body: `These Terms, together with applicable product-specific terms, Privacy Policy, Credit Agreement, Direct Debit Mandate and other incorporated policies, constitute the applicable agreement between Kopa and the User.

Where a product-specific agreement conflicts with these Terms, the product-specific agreement shall govern that particular transaction to the extent of the conflict.`,
  },
  {
    title: `31. CONTACT`,
    body: `Buba Rumbus Tech & Investment Co. Ltd.

No. 3 Kachia Road, Barnawa, Kaduna State, Nigeria.

Email: legal@kopaxclusive.com
Customer Support: support@kopaxclusive.com
Website: https://kopaxclusive.com.ng

For legal, regulatory or privacy matters, use the designated contact details provided on the Kopa Platform.

Last Updated: 2 October 2026`,
  },
  ],
};

export const LEGAL_DOCUMENTS: Record<LegalDocument["key"], LegalDocument> = {
  privacy: PRIVACY_POLICY,
  terms: TERMS_AND_CONDITIONS,
};

/** Operator details, repeated at the foot of both documents. */
export const LEGAL_OPERATOR = {
  company: "Buba Rumbus Tech & Investment Co. Ltd.",
  rcNumber: "RC 7151779",
  address: "No. 3 Kachia Road, Barnawa, Kaduna State, Nigeria",
  website: "www.kopaxclusive.com.ng",
  privacyEmail: "privacy@kopaxclusive.com.ng",
  supportEmail: "support@kopaxclusive.com",
  tagline: "Serve… We've Got You Covered.",
} as const;
