/**
 * All landing-page copy and links live here, so wording can change without
 * touching layout. Claims are kept to what the product actually does today
 * (Kopa-Mobile + backend) — no invented rates, fees or user counts.
 */

export const LINKS = {
  // TODO: replace with real store listings once published.
  appStore: "#",
  playStore: "#",
  supportEmail: "support@kopaxclusive.com",
  privacyEmail: "privacy@kopaxclusive.com.ng",
  website: "www.kopaxclusive.com.ng",
};

/**
 * Where a "download" button should go: the visitor's own store on a phone,
 * otherwise the Get started section, which shows both store buttons.
 * Corps members and vendors use the same app — they pick their role at sign-up.
 */
export function appDownloadHref(): string {
  if (typeof navigator === "undefined") return "/#get-started";
  const ua = navigator.userAgent;
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  if (isIOS && LINKS.appStore !== "#") return LINKS.appStore;
  if (/Android/i.test(ua) && LINKS.playStore !== "#") return LINKS.playStore;
  return "/#get-started";
}

export const COMPANY = {
  name: "Buba Rumbus Tech & Investment Co. Ltd.",
  rc: "RC 7151779",
  address: "No. 3 Kachia Road, Barnawa, Kaduna State, Nigeria",
  tagline: "Serve… We've Got You Covered.",
};

export const NAV = [
  { label: "How it works", href: "/#how-it-works" },
  { label: "Corps members", href: "/#features" },
  { label: "Vendors", href: "/#features-vendors" },
  { label: "FAQs", href: "/faq" },
  { label: "Contact", href: "/contact" },
];

export const HERO = {
  eyebrow: "Built for NYSC corps members",
  title: ["Your service year,", "covered."],
  body: "Shop now and pay later at trusted vendors near your PPA. Kopa gives corps members a spending limit, and vendors a steady stream of customers — paid straight into their wallet.",
  corperCta: "I'm a corps member",
  vendorCta: "I'm a vendor",
  points: ["Spending limit set at approval", "Auto-repay from your allowance account", "Pay with QR or payment code"],
};

export type Audience = "corper" | "vendor";

export const AUDIENCE_LABEL: Record<Audience, string> = {
  corper: "Corps members",
  vendor: "Vendors",
};

export const STEPS: Record<Audience, { title: string; body: string }[]> = {
  corper: [
    {
      title: "Sign up with your NYSC details",
      body: "Download the app and verify yourself with your state code, call-up number, NIN, BVN and the account your allowance is paid into.",
    },
    {
      title: "Get your spending limit",
      body: "Once the Kopa team approves your profile, you get a credit limit. Set up auto-repay so repayments come out of your allowance account on schedule.",
    },
    {
      title: "Buy from vendors",
      body: "Scan a vendor's QR code or enter their payment code, confirm with your PIN, and you're done. Shop the in-app market or pay bills the same way.",
    },
  ],
  vendor: [
    {
      title: "Download the app and sign up",
      body: "Choose \"Continue as a Vendor\" and tell us about your business — category, address, owner details and your CAC registration number (RC or BN) — and the bank account you want paid into.",
    },
    {
      title: "Get verified",
      body: "The Kopa team reviews your details. Once approved, corps members can find you, pay you and order from your listings.",
    },
    {
      title: "Receive payments",
      body: "Generate a payment code or QR at the counter. Every sale lands in your Kopa wallet, ready to withdraw to your bank account.",
    },
  ],
};

export const FEATURES: Record<Audience, { icon: string; title: string; body: string }[]> = {
  corper: [
    { icon: "CreditCard", title: "Shop now, pay later", body: "Buy what you need before your allowance lands — food, clothes, gadgets — within the limit you've been approved for." },
    { icon: "QrCode", title: "Pay in seconds", body: "Scan the vendor's QR code or type their payment code. Confirm with your 6-digit transaction PIN and it's done." },
    { icon: "RefreshCw", title: "Repayment on autopilot", body: "A direct-debit mandate collects each repayment from your allowance account, so you never miss a date." },
    { icon: "ShoppingBag", title: "A marketplace near your PPA", body: "Browse fashion, beauty, grocery, food and electronics from approved vendors, and order in-app." },
    { icon: "ShieldCheck", title: "Your order money is protected", body: "For marketplace orders, the vendor is only paid after you confirm delivery. Something wrong? Report it in the app." },
    { icon: "Zap", title: "Bills in one place", body: "Airtime, data, TV, electricity and exam pins — paid from the same app." },
  ],
  vendor: [
    { icon: "Users", title: "Customers who can spend", body: "Corps members across your area, with approved spending limits — even in the weeks before allowance day." },
    { icon: "Wallet", title: "Paid straight to your wallet", body: "Every sale is credited to your Kopa wallet. Withdraw to your bank account whenever you're ready." },
    { icon: "QrCode", title: "Sell at the counter", body: "Generate a payment code or QR for each sale. The corper scans, confirms, and you see it land." },
    { icon: "Store", title: "List your products", body: "Put your products in the Kopa market so corps members can browse and order from you." },
    { icon: "BadgeCheck", title: "A verified badge", body: "Approved vendors are checked by the Kopa team, so corps members know they're buying from a real business." },
    { icon: "BarChart3", title: "Track every sale", body: "See your sales, orders and payouts in one place, with a clear history for your records." },
  ],
};

export const TRUST_POINTS = [
  { icon: "UserCheck", title: "Every profile is reviewed", body: "Corps members and vendors are checked by the Kopa team before they can transact." },
  { icon: "Landmark", title: "Bank accounts are verified", body: "Account names are confirmed with the bank before any money moves." },
  { icon: "Lock", title: "PIN and Face ID", body: "Sign in with Face ID, and confirm every payment with your transaction PIN. We'll never ask for your bank password or OTP." },
  { icon: "Scale", title: "Disputes handled fairly", body: "Report a problem with any purchase and our team reviews both sides before money is settled." },
];

export const FOOTER_LINKS = [
  {
    heading: "Product",
    links: [
      { label: "How it works", href: "/#how-it-works" },
      { label: "For corps members", href: "/#features" },
      { label: "For vendors", href: "/#features-vendors" },
      { label: "Get the app", href: "/#get-started" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "Why trust us", href: "/#trust" },
      { label: "FAQs", href: "/faq" },
      { label: "Contact us", href: "/contact" },
    ],
  },
  {
    heading: "Legal",
    links: [
      { label: "Terms & Conditions", href: "/terms" },
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Data requests", href: `mailto:${LINKS.privacyEmail}` },
    ],
  },
];
