import { useEffect } from "react";
import { Navbar } from "./components/Navbar";
import { Footer } from "./sections/Footer";
import { Home } from "./pages/Home";
import { LegalPage } from "./pages/LegalPage";
import { Contact } from "./pages/Contact";
import { Faq } from "./pages/Faq";
import { ROUTES, type RoutePath } from "./routes";

export default function App({ path }: { path: RoutePath }) {
  useEffect(() => {
    document.title = ROUTES[path].title;
  }, [path]);

  return (
    <>
      <Navbar />
      <main>
        {path === "/" && <Home />}
        {path === "/faq" && <Faq />}
        {path === "/terms" && <LegalPage doc="terms" />}
        {path === "/privacy" && <LegalPage doc="privacy" />}
        {path === "/contact" && <Contact />}
      </main>
      <Footer />
    </>
  );
}
