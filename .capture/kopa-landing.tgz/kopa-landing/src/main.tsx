import { StrictMode } from 'react'
import { createRoot, hydrateRoot } from 'react-dom/client'
import '@fontsource/poppins/400.css'
import '@fontsource/poppins/500.css'
import '@fontsource/poppins/600.css'
import '@fontsource/poppins/700.css'
import '@fontsource/poppins/800.css'
import './index.css'
import App from './App.tsx'
import { resolveRoute } from './routes'

const root = document.getElementById('root')!
const path = resolveRoute(window.location.pathname)
const app = (
  <StrictMode>
    <App path={path} />
  </StrictMode>
)

// The production build ships pre-rendered HTML for each page
// (scripts/prerender.mjs) so search engines and link previews see the full
// content; React takes it over. If a host served another page's HTML (an
// SPA fallback), render fresh instead of adopting the wrong markup.
if (root.dataset.route === path) {
  hydrateRoot(root, app)
} else {
  root.replaceChildren()
  createRoot(root).render(app)
}
