// Renders every page to static HTML: dist/index.html, dist/terms/index.html,
// dist/privacy/index.html, dist/contact/index.html. Each gets its own title,
// description, canonical URL and social tags, and its content is in the HTML
// itself rather than only appearing after JavaScript runs.
import { mkdir, readFile, writeFile, rm } from "node:fs/promises";
import { fileURLToPath, pathToFileURL } from "node:url";
import path from "node:path";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const { render, ROUTES, SITE_URL } = await import(
  pathToFileURL(path.join(root, "dist-ssr/entry-server.js")).href
);

const template = await readFile(path.join(root, "dist/index.html"), "utf8");
if (!template.includes('<div id="root"></div>')) throw new Error("root placeholder not found in dist/index.html");

const esc = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
const homeUrl = `${SITE_URL}/`;

for (const [route, meta] of Object.entries(ROUTES)) {
  const url = route === "/" ? homeUrl : `${SITE_URL}${route}`;
  let html = template.replace(
    '<div id="root"></div>',
    `<div id="root" data-route="${route}">${render(route)}</div>`,
  );

  if (route !== "/") {
    const title = esc(meta.title);
    const desc = esc(meta.description);
    html = html
      .replace(/<title>.*?<\/title>/s, `<title>${title}</title>`)
      .replace(/(<meta name="description" content=")[^"]*(")/, `$1${desc}$2`)
      .replace(/(<link rel="canonical" href=")[^"]*(")/, `$1${url}$2`)
      .replace(/(<meta property="og:url" content=")[^"]*(")/, `$1${url}$2`)
      .replace(/(<meta property="og:title" content=")[^"]*(")/, `$1${title}$2`)
      .replace(/(<meta property="og:description" content=")[^"]*(")/, `$1${desc}$2`)
      .replace(/(<meta name="twitter:title" content=")[^"]*(")/, `$1${title}$2`)
      .replace(/(<meta name="twitter:description" content=")[^"]*(")/, `$1${desc}$2`);
  }

  // /terms is written as both terms/index.html and terms.html, so it resolves
  // on any static host (Vercel, Netlify, nginx, S3) without extra config.
  const outs =
    route === "/"
      ? [path.join(root, "dist/index.html")]
      : [path.join(root, "dist", route, "index.html"), path.join(root, "dist", `${route}.html`)];
  for (const out of outs) {
    await mkdir(path.dirname(out), { recursive: true });
    await writeFile(out, html);
  }
  console.log(`✓ pre-rendered ${route}`);
}

await rm(path.join(root, "dist-ssr"), { recursive: true, force: true });
