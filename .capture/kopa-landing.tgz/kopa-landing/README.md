# Kopa Xclusive — landing page

React + Vite + TypeScript + Tailwind v4.

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # output in dist/
```

- All copy and links: `src/data/content.ts` (store links and vendor sign-up URL are placeholders — search for TODO).
- Brand tokens (colours, font): `src/index.css`, taken from Kopa-Mobile.

## Pages

| URL | File |
|---|---|
| `/` | `src/pages/Home.tsx` (sections in `src/sections/`) |
| `/faq` | `src/pages/Faq.tsx` (questions in `src/data/faq.ts`) |
| `/terms` | `src/pages/LegalPage.tsx` |
| `/privacy` | `src/pages/LegalPage.tsx` |
| `/contact` | `src/pages/Contact.tsx` |

- Terms and Privacy text is `src/data/legal.ts`, copied **verbatim** from `Kopa-Mobile/lib/legal/documents.ts`. When Legal updates the documents, copy that file over again so the app and site match.
- The contact page shows the support phone number set in the admin (Settings), read from `GET /settings/public`. Set `VITE_API_URL` if the API isn't `https://kopa-backend-apio.onrender.com/api/v1`, and add the website's domain to the backend's CORS origins (`app.corsOrigins`), otherwise the phone line stays hidden.
- To add a page: add it to `src/routes.ts`, render it in `src/App.tsx`, and add it to `public/sitemap.xml`.

## SEO

- `npm run build` pre-renders every page (`dist/index.html`, `dist/terms/index.html` + `dist/terms.html`, …) (via `src/entry-server.tsx` + `scripts/prerender.mjs`), so search engines and WhatsApp/X link previews see the full content.
- Meta tags, Open Graph, X card and structured data (Organization, WebSite, MobileApplication) are in `index.html`.
- `public/robots.txt`, `public/sitemap.xml`, `public/site.webmanifest`, `public/og-image.jpg` (1200×630 share image).
- The domain is set to `https://www.kopaxclusive.com.ng/` everywhere — change it in `index.html`, `robots.txt` and `sitemap.xml` if the site goes live elsewhere.
- When the store links are added, also add `"installUrl"` / `"downloadUrl"` to the MobileApplication block in `index.html`.
