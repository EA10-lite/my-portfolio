import { PRIMARY, hit } from "@/src/theme";
import ping from "@/src/services/ping";
import NoteForm, {
  NoteFormValues,
  SubmitMode,
} from "@/src/screens/messages/components/NoteForm";
import NoteScreen from "@/src/screens/messages/components/NoteScreen";
import { usePartnerStore } from "@/src/stores/partnerStore";
import { useToastStore } from "@/src/stores/toastStore";
import { Feather } from "@expo/vector-icons";
import { isAxiosError } from "axios";
import * as Clipboard from "expo-clipboard";
import { router } from "expo-router";
import { TouchableOpacity } from "react-native";

const NewMessage = () => {
  const { partner } = usePartnerStore();
  const { showToast } = useToastStore();

  const handleSubmit = async (values: NoteFormValues, mode: SubmitMode) => {
    if (!partner?._id) {
      showToast("Please Add a Partner", "error");
      return;
    }
    if (values.tones.length === 0) {
      showToast("Please select at least one tone", "error");
      return;
    }

    try {
      const response = await ping.createPing({
        message: values.message,
        tones: values.tones,
        ping_type: "text",
        partner: partner._id,
        title: "Love Note",
      });

      if (response.status === 200 || response.status === 201) {
        if (mode === "copy") {
          await Clipboard.setStringAsync(values.message);
          showToast("Note saved and copied", "success");
        } else {
          showToast("Note saved", "success");
        }
        // Leave the toast on screen briefly before returning.
        await new Promise((resolve) => setTimeout(resolve, 1000));
        router.back();
      }
    } catch (error) {
      showToast(
        (isAxiosError(error) && error.response?.data?.message) ||
          "Couldn't save your note. Please try again.",
        "error",
      );
    }
  };

  return (
    <NoteScreen
      title="New Love Note"
      rightAction={
        <TouchableOpacity
          onPress={() => router.back()}
          accessibilityRole="button"
          accessibilityLabel="Close"
          hitSlop={hit.icon}
        >
          <Feather name="x" size={24} color={PRIMARY} />
        </TouchableOpacity>
      }
    >
      <NoteForm
        initialValues={{ message: "", tones: [] }}
        onSubmit={handleSubmit}
      />
    </NoteScreen>
  );
};

export default NewMessage;
