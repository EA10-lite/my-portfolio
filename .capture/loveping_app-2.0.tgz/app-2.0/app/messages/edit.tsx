import ping from "@/src/services/ping";
import NoteForm, {
  NoteFormValues,
  SubmitMode,
} from "@/src/screens/messages/components/NoteForm";
import NoteScreen from "@/src/screens/messages/components/NoteScreen";
import { usePartnerStore } from "@/src/stores/partnerStore";
import { useToastStore } from "@/src/stores/toastStore";
import { normalizeToArray } from "@/src/utils/formatter";
import { isAxiosError } from "axios";
import * as Clipboard from "expo-clipboard";
import { router, useLocalSearchParams } from "expo-router";

const Edit = () => {
  const { partner } = usePartnerStore();
  const { showToast } = useToastStore();
  const { id, tones, message } = useLocalSearchParams<{
    id: string;
    tones?: string;
    message?: string;
  }>();

  const handleSubmit = async (values: NoteFormValues, mode: SubmitMode) => {
    if (values.tones.length === 0) {
      showToast("Please select at least one tone", "error");
      return;
    }

    try {
      const response = await ping.updatePing(String(id), {
        message: values.message,
        tones: values.tones,
        ping_type: "text",
        partner: partner?._id?.toString() || "",
        title: "Love Note",
      });

      if (response.status === 200 || response.status === 201) {
        if (mode === "copy") {
          await Clipboard.setStringAsync(values.message);
          showToast("Note saved and copied", "success");
        } else {
          showToast("Note saved", "success");
        }
        await new Promise((resolve) => setTimeout(resolve, 1000));
        router.back();
      }
    } catch (error) {
      showToast(
        (isAxiosError(error) && error.response?.data?.message) ||
          "Couldn't save your note. Please try again.",
        "error",
      );
    }
  };

  return (
    <NoteScreen title="Edit">
      <NoteForm
        initialValues={{
          message: message || "",
          tones: normalizeToArray(tones),
        }}
        placeholder="Enter your message"
        onSubmit={handleSubmit}
      />
    </NoteScreen>
  );
};

export default Edit;
