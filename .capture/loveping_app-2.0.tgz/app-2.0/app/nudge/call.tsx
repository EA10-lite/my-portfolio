import RefreshIcon from "@/assets/icons/refresh.svg";
import SaveIcon from "@/assets/icons/save.svg";
import {
  ActionButton,
  AppText,
  Button,
  Header,
  NotLoggedIn,
  SuggestionCard,
  ToneTags,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { usePartnerStore, useUserStore } from "@/src/stores";
import { WHITE_80, space } from "@/src/theme";
import { StyleSheet, View } from "react-native";

const starters = (pronoun: string) => [
  `Tell ${pronoun} you’re proud of ${pronoun}`,
  `Ask how ${pronoun === "him" ? "his" : pronoun === "her" ? "her" : "their"} big day went`,
  `Share something funny that reminded you of ${pronoun}`,
];

/**
 * Call nudge. Still a static screen (no call-nudge data from the API yet):
 * the partner's name and pronouns now come from their profile instead of
 * being hardcoded to "damilola" / "her".
 */
const CallNudge = () => {
  const { user } = useUserStore();
  const { partner } = usePartnerStore();
  const pronoun =
    partner?.gender === "male"
      ? "him"
      : partner?.gender === "female"
        ? "her"
        : "them";

  return (
    <MainLayout>
      <Header title="Call Nudge" />

      <View style={styles.body}>
        <AppText size="sm" color={WHITE_80} italic style={styles.intro}>
          Now&apos;s a great time to give{" "}
          {partner?.partner_name || "your partner"} a quick call
        </AppText>

        <SuggestionCard title="Suggested Call Starters" style={styles.gap}>
          {starters(pronoun).map((item) => (
            <AppText key={item} size="sm" weight="medium" style={styles.line}>
              • {item}
            </AppText>
          ))}
        </SuggestionCard>

        <View style={[styles.row, styles.gap]}>
          <ActionButton
            icon={<RefreshIcon />}
            onPress={() => {}}
            accessibilityLabel="New suggestions"
          />
          <ActionButton
            icon={<SaveIcon />}
            onPress={() => {}}
            accessibilityLabel="Save"
          />
        </View>

        <ToneTags
          tones={["Romantic", "Anniversary"]}
          onChangeTone={() => {}}
          style={styles.gap}
        />

        <Button
          title="Make Call"
          onPress={() => {}}
          size="lg"
          variant="primary"
        />
      </View>

      {user?.is_guest && <NotLoggedIn />}
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  // `p-6 flex-1`
  body: { flex: 1, padding: space[6] },
  intro: { marginBottom: space[8] },
  gap: { marginBottom: space[6] },
  line: { lineHeight: 24 },
  row: { flexDirection: "row", alignItems: "center", gap: space[4] },
});

export default CallNudge;
