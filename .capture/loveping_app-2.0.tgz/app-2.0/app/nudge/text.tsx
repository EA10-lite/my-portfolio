import CopyIcon from "@/assets/icons/copy.svg";
import EditIcon from "@/assets/icons/edit.svg";
import RefreshIcon from "@/assets/icons/refresh.svg";
import SaveIcon from "@/assets/icons/save.svg";
import {
  ActionButton,
  AppText,
  Button,
  ChangeToneModal,
  Header,
  SuggestionCard,
  ToneTags,
} from "@/src/components";
import { useClipboard } from "@/src/hooks/useClipBoard";
import { MainLayout } from "@/src/layouts";
import nudges from "@/src/services/nudges";
import ping from "@/src/services/ping";
import { usePartnerStore } from "@/src/stores";
import { useToastStore } from "@/src/stores/toastStore";
import { WHITE_80, rs, space, useResponsive } from "@/src/theme";
import { normalizeToArray } from "@/src/utils/formatter";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isAxiosError } from "axios";
import { router, useLocalSearchParams } from "expo-router";
import { useRef, useState } from "react";
import { ScrollView, Share, StyleSheet, View } from "react-native";

const errorMessage = (error: unknown, fallback: string) =>
  (isAxiosError(error) && error.response?.data?.message) || fallback;

const TextNudge = () => {
  const { showToast } = useToastStore();
  const params = useLocalSearchParams<{
    message: string;
    id: string;
    tone?: string;
    dayOfWeek?: string;
  }>();
  const message = String(params.message ?? "");
  const id = String(params.id ?? "");
  const { partner } = usePartnerStore();
  const { copy } = useClipboard();
  const { isSm } = useResponsive();
  const gap = rs(isSm, space[4], space[6]);

  const changeToneModal = useRef<BottomSheetModal>(null);
  const openChangeToneModal = () => changeToneModal.current?.present();
  const closeChangeToneModal = () => changeToneModal.current?.dismiss();

  const handleCopy = async () => {
    await copy(message);
    showToast("Copied", "success");
  };

  const [saving, setSaving] = useState(false);
  const handleSave = async () => {
    try {
      setSaving(true);
      const response = await ping.updatePing(id, {
        message,
        tones: normalizeToArray(params.tone),
        ping_type: "text",
        partner: partner?._id?.toString() || "",
        title: "Love Note",
        isSaved: true,
      });
      if (response.status === 200 || response.status === 201) {
        showToast("Saved", "success", "top");
      }
    } catch (error) {
      showToast(
        errorMessage(error, "An error occurred while saving the message"),
        "error",
        "top",
      );
    } finally {
      setSaving(false);
    }
  };

  // "Copy & Send" used to save and copy only. It now copies and opens the
  // share sheet so the note can go straight into WhatsApp, Messages, etc.
  const handleCopyAndSend = async () => {
    await copy(message);
    try {
      await Share.share({ message });
    } catch {
      showToast("Copied", "success");
    }
  };

  const [selectedTones, setSelectedTones] = useState<string[]>(
    normalizeToArray(params.tone),
  );
  const [loading, setLoading] = useState<boolean>(false);

  const handleToneUpdate = async () => {
    // Loading was never switched on, so the button showed no progress.
    setLoading(true);
    try {
      const response = await nudges.updateTextNudge(id, {
        tone: selectedTones,
        message,
        DayOfWeek: params.dayOfWeek as string, // omitted when absent, as before
        ping_type: "text",
        isSaved: true,
      });

      if (response.status === 200) {
        showToast("Tone updated", "success");
        closeChangeToneModal();
      }
    } catch (error) {
      showToast(
        errorMessage(error, "An unexpected error occurred during Tone Update"),
        "error",
        "top",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleSelectTone = (tone: string) => {
    if (selectedTones.includes(tone)) {
      setSelectedTones((prev) => prev.filter((t) => t !== tone));
      return;
    }
    if (selectedTones.length >= 2) {
      showToast("You can only select up to 2 tones", "error", "top");
      return;
    }
    setSelectedTones((prev) => [...prev, tone]);
  };

  return (
    <MainLayout>
      <Header title="Text Nudge" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scroll}
      >
        <View
          style={[
            styles.fill,
            { paddingHorizontal: rs(isSm, space[4], space[6]) },
          ]}
        >
          <AppText
            size="sm"
            color={WHITE_80}
            italic
            style={{ marginBottom: rs(isSm, space[6], space[8]) }}
          >
            {/* Said "...give X a quick call" on the text nudge. */}
            Now&apos;s a great time to send{" "}
            {partner?.partner_name || "your partner"} something sweet
          </AppText>

          <SuggestionCard
            title="Here's something sweet"
            style={{ marginBottom: gap }}
          >
            <AppText
              size="sm"
              weight="medium"
              style={styles.message}
              selectable
            >
              {message}
            </AppText>
          </SuggestionCard>

          <View
            style={[
              styles.actions,
              { gap: rs(isSm, space[3], space[4]), marginBottom: gap },
            ]}
          >
            <ActionButton
              icon={<RefreshIcon />}
              onPress={() => {}}
              accessibilityLabel="New suggestion"
            />
            <ActionButton
              icon={<EditIcon />}
              accessibilityLabel="Edit message"
              onPress={() =>
                router.push({
                  pathname: "/nudge/edit",
                  params: {
                    message,
                    id,
                    tone: selectedTones.join(","),
                    dayOfWeek: params.dayOfWeek,
                  },
                })
              }
            />
            <ActionButton
              icon={<CopyIcon />}
              onPress={handleCopy}
              accessibilityLabel="Copy message"
            />
            <ActionButton
              icon={<SaveIcon />}
              onPress={handleSave}
              loading={saving}
              accessibilityLabel="Save message"
            />
          </View>

          <ToneTags
            tones={selectedTones}
            onChangeTone={openChangeToneModal}
            style={{ gap: rs(isSm, space[3], space[4]), marginBottom: gap }}
          />

          <Button
            title="Copy & Send"
            onPress={handleCopyAndSend}
            size="lg"
            variant="primary"
          />
        </View>
      </ScrollView>

      <ChangeToneModal
        ref={changeToneModal}
        onClose={closeChangeToneModal}
        selectedTones={selectedTones}
        handleSelectTone={handleSelectTone}
        handleUpdate={handleToneUpdate}
        handleClear={() => setSelectedTones([])}
        loading={loading}
      />
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1, paddingVertical: space[6] },
  message: { lineHeight: 24 },
  actions: { flexDirection: "row", alignItems: "center" },
});

export default TextNudge;
