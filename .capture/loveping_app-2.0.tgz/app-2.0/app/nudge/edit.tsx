import ClearIcon from "@/assets/icons/clear.svg";
import CopyIcon from "@/assets/icons/copy.svg";
import SaveIcon from "@/assets/icons/save.svg";
import {
  ActionButton,
  AppText,
  ChangeToneModal,
  Header,
  Submit,
  Textbox,
  ToneTags,
} from "@/src/components";
import { useClipboard } from "@/src/hooks/useClipBoard";
import { MainLayout } from "@/src/layouts";
import nudges from "@/src/services/nudges";
import { usePartnerStore } from "@/src/stores";
import { useToastStore } from "@/src/stores/toastStore";
import { WHITE_80, space } from "@/src/theme";
import { normalizeToArray } from "@/src/utils/formatter";
import { textNudgeSchema } from "@/src/utils/validations";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isAxiosError } from "axios";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { useRef, useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";

type EditMessageFormValues = { message: string };

const EditMessage = () => {
  const params = useLocalSearchParams<{
    message?: string;
    id: string;
    tone?: string;
    dayOfWeek?: string;
  }>();
  const { showToast } = useToastStore();
  const { partner } = usePartnerStore();
  const { copy } = useClipboard();

  const changeToneModal = useRef<BottomSheetModal>(null);
  const openChangeToneModal = () => changeToneModal.current?.present();
  const closeChangeToneModal = () => changeToneModal.current?.dismiss();

  const [selectedTones, setSelectedTones] = useState<string[]>(
    normalizeToArray(params.tone),
  );

  const handleSelectTone = (tone: string) => {
    if (selectedTones.includes(tone)) {
      setSelectedTones((prev) => prev.filter((t) => t !== tone));
      return;
    }
    if (selectedTones.length >= 2) {
      showToast("You can only select up to 2 tones", "error", "top");
      return;
    }
    setSelectedTones((prev) => [...prev, tone]);
  };

  const handleCopy = async (message: string) => {
    await copy(message);
    showToast("Copied", "success");
  };

  /**
   * Saves the edit. `andCopy` (the main button) also copies the message and
   * returns home; the save icon saves and stays on the page.
   * The save icon used to show "Saved" without saving anything, and the
   * request always sent tone "romantic" / day "monday", whatever was picked.
   */
  const save = async (message: string, andCopy: boolean) => {
    if (message.trim() === "") {
      showToast("No message to save", "error");
      return;
    }
    try {
      const response = await nudges.updateTextNudge(String(params.id), {
        message,
        ping_type: "text",
        isSaved: true,
        tone: selectedTones.length ? selectedTones : "romantic",
        DayOfWeek: params.dayOfWeek || "monday",
      });
      if (response.status === 200) {
        if (andCopy) {
          await copy(message);
          showToast("Message updated", "success");
          router.replace("/(tabs)");
        } else {
          showToast("Saved", "success");
        }
      }
    } catch (error) {
      showToast(
        (isAxiosError(error) && error.response?.data?.message) ||
          "An unexpected error occurred during Update Text Nudge",
        "error",
        "top",
      );
    }
  };

  const [savingIcon, setSavingIcon] = useState(false);

  return (
    <MainLayout>
      <Header title="Edit Message" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scroll}
      >
        <View style={[styles.fill, styles.body]}>
          <AppText size="sm" color={WHITE_80} italic style={styles.intro}>
            {/* Was hardcoded to "damilola". */}
            Now’s a great time to put a smile on{" "}
            {partner?.partner_name
              ? `${partner.partner_name}’s`
              : "your partner’s"}{" "}
            face
          </AppText>

          <Formik<EditMessageFormValues>
            initialValues={{ message: params.message || "" }}
            onSubmit={(values) => save(values.message, true)}
            validationSchema={textNudgeSchema}
          >
            {({ setFieldValue, values, isSubmitting }) => (
              <View>
                <Textbox
                  name="message"
                  label="Message"
                  multiline
                  numberOfLines={4}
                  hasBg
                />
                <View style={styles.actions}>
                  <ActionButton
                    icon={<CopyIcon />}
                    onPress={() => handleCopy(values.message)}
                    accessibilityLabel="Copy message"
                  />
                  <ActionButton
                    icon={<SaveIcon />}
                    loading={savingIcon}
                    accessibilityLabel="Save message"
                    onPress={async () => {
                      setSavingIcon(true);
                      await save(values.message, false);
                      setSavingIcon(false);
                    }}
                  />
                  <ActionButton
                    icon={<ClearIcon />}
                    accessibilityLabel="Clear message"
                    onPress={() => {
                      setFieldValue("message", "");
                      showToast("Cleared", "success");
                    }}
                  />
                </View>

                <ToneTags
                  tones={selectedTones}
                  onChangeTone={openChangeToneModal}
                  style={styles.tags}
                />

                <Submit title="Save & Copy" loading={isSubmitting} />
              </View>
            )}
          </Formik>
        </View>
      </ScrollView>

      <ChangeToneModal
        ref={changeToneModal}
        onClose={closeChangeToneModal}
        selectedTones={selectedTones}
        handleSelectTone={handleSelectTone}
        handleClear={() => setSelectedTones([])}
        // Tones are sent with the save; this just confirms the choice.
        // (It used to leave the sheet open.)
        handleUpdate={closeChangeToneModal}
      />
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1, paddingBottom: space[16] },
  body: { padding: space[6] },
  intro: { marginBottom: space[8] },
  actions: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[3],
    marginBottom: space[6],
  },
  tags: { marginBottom: space[6] },
});

export default EditMessage;
