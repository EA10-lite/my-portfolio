import RefreshIcon from "@/assets/icons/refresh.svg";
import StarAltIcon from "@/assets/icons/star-alt.svg";
import {
  ActionButton,
  AppText,
  FilterModal,
  GiftCard,
  Header,
  ToneTags,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { usePartnerStore } from "@/src/stores";
import { defaultGifts } from "@/src/stores/giftStore";
import {
  PRIMARY_1A,
  WHITE,
  WHITE_80,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useRef } from "react";
import { ScrollView, StyleSheet, View } from "react-native";

/** Gift nudge. Static for now ("coming soon" on Home). */
const GiftNudge = () => {
  const { partner } = usePartnerStore();
  const { isSm } = useResponsive();
  const filterRef = useRef<BottomSheetModal>(null);
  const openFilterModal = () => filterRef.current?.present();
  const closeFilterModal = () => filterRef.current?.dismiss();
  const gap = rs(isSm, space[4], space[6]);

  return (
    <MainLayout>
      <Header
        title="Gift Nudge"
        rightAction={
          <ActionButton
            icon={<Feather name="filter" size={18} color={WHITE} />}
            onPress={openFilterModal}
            hasBorder={false}
            bgColor={PRIMARY_1A}
            accessibilityLabel="Filter gifts"
          />
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scroll}
      >
        <View style={{ padding: rs(isSm, space[4], space[6]) }}>
          <AppText
            size={isSm ? "sm" : "xs"}
            color={WHITE_80}
            italic
            style={styles.intro}
          >
            It&apos;s a perfect day to surprise{" "}
            {partner?.partner_name || "your partner"}
          </AppText>

          <ToneTags
            tones={["Romantic", "Anniversary"]}
            onChangeTone={() => {}}
            style={{ marginBottom: gap }}
          />

          <View style={{ gap }}>
            <View style={styles.titleRow}>
              <View style={styles.title}>
                <StarAltIcon width={16} height={16} />
                <AppText size="sm" weight="medium">
                  Gift Suggestions
                </AppText>
              </View>

              <ActionButton
                icon={<RefreshIcon />}
                onPress={() => {}}
                hasBorder={false}
                bgColor={PRIMARY_1A}
                accessibilityLabel="New suggestions"
              />
            </View>

            {defaultGifts.map((suggestion) => (
              <GiftCard
                key={suggestion.id}
                title={suggestion.title}
                icon={suggestion.icon}
                isSaved={false}
              />
            ))}
          </View>
        </View>
      </ScrollView>

      <FilterModal ref={filterRef} onClose={closeFilterModal} type="gift" />
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  scroll: { flexGrow: 1 },
  intro: { marginBottom: space[4] },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  title: { flexDirection: "row", alignItems: "center", gap: space[2] },
});

export default GiftNudge;
