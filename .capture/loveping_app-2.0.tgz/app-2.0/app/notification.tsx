import NotificationIcon from "@/assets/icons/notification.svg";
import { AppText, Button, Empty, Header, Loader } from "@/src/components";
import { useNotifications } from "@/src/hooks/useNotifications";
import { MainLayout } from "@/src/layouts";
import { Notification } from "@/src/services/notification";
import { useToastStore } from "@/src/stores";
import {
  ERROR,
  GREY,
  PRIMARY,
  PRIMARY_1A,
  WHITE_05,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { useFocusEffect } from "expo-router";
import { useCallback, useMemo, useState } from "react";
import {
  Linking,
  Pressable,
  RefreshControl,
  SectionList,
  StyleSheet,
  View,
} from "react-native";

type Section = { key: string; title: string; data: Notification[] };

/** Local calendar day, e.g. "2026-10-18". */
const dayKey = (iso: string) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};

const dayTitle = (iso: string) => {
  const date = new Date(iso);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) return "Today";
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    // Show the year only when it isn't this year.
    ...(date.getFullYear() !== today.getFullYear() ? { year: "numeric" } : {}),
  });
};

/**
 * Groups by calendar day (newest first). This used to group by the exact
 * `createdAt` timestamp, so every notification got its own "Today" header.
 */
const groupByDay = (items: Notification[]): Section[] => {
  const sections: Section[] = [];
  const byKey = new Map<string, Section>();
  for (const n of items) {
    const key = dayKey(n.createdAt);
    let section = byKey.get(key);
    if (!section) {
      section = { key, title: dayTitle(n.createdAt), data: [] };
      byKey.set(key, section);
      sections.push(section);
    }
    section.data.push(n);
  }
  return sections;
};

const Notifications = () => {
  const {
    notifications,
    unreadCount,
    hasMore,
    isLoading,
    isLoadingMore,
    isRefreshing,
    error,
    loadMore,
    refresh,
    markAllAsRead,
    markAsRead,
  } = useNotifications();
  const { showToast } = useToastStore();
  const { isSm } = useResponsive();
  const pad = rs(isSm, space[4], space[6]);
  const [marking, setMarking] = useState(false);

  // Fresh list every time the page opens (the cache could be 5 min old).
  useFocusEffect(
    useCallback(() => {
      refresh();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []),
  );

  const sections = useMemo(() => groupByDay(notifications), [notifications]);

  const handleMarkAll = async () => {
    setMarking(true);
    try {
      await markAllAsRead();
    } catch {
      showToast("Couldn't mark notifications as read", "error", "top");
    } finally {
      setMarking(false);
    }
  };

  const handleOpen = async (n: Notification) => {
    markAsRead(n._id);
    if (n.url) {
      try {
        await Linking.openURL(n.url);
      } catch {
        showToast("Couldn't open this link", "error", "top");
      }
    }
  };

  const renderBody = () => {
    if (isLoading) {
      return (
        <View style={styles.center}>
          <Loader size={28} color={PRIMARY} />
        </View>
      );
    }

    if (error && notifications.length === 0) {
      return (
        <View style={styles.fill}>
          <Empty
            icon={<NotificationIcon width={20} height={20} />}
            description="We couldn't load your notifications"
          />
          <View style={styles.retry}>
            <Button title="Try again" variant="outline-secondary" onPress={refresh} />
          </View>
        </View>
      );
    }

    if (notifications.length === 0) {
      // Pull-to-refresh still works on the empty state.
      return (
        <SectionList
          sections={[]}
          renderItem={() => null}
          contentContainerStyle={styles.fill}
          refreshControl={
            <RefreshControl refreshing={isRefreshing} onRefresh={refresh} tintColor={PRIMARY} />
          }
          ListEmptyComponent={
            <Empty
              icon={<NotificationIcon width={20} height={20} />}
              description="No new nudges or reminders for now. We'll ping you when there's something sweet"
            />
          }
        />
      );
    }

    return (
      <SectionList
        sections={sections}
        keyExtractor={(item) => item._id}
        stickySectionHeadersEnabled={false}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          padding: pad,
          // Room for the floating "Mark as read" button.
          paddingBottom: unreadCount > 0 ? 120 : space[6],
        }}
        refreshControl={
          <RefreshControl refreshing={isRefreshing} onRefresh={refresh} tintColor={PRIMARY} />
        }
        onEndReached={loadMore}
        onEndReachedThreshold={0.4}
        renderSectionHeader={({ section }) => (
          <View
            style={[styles.dateRow, { marginTop: section.key === sections[0]?.key ? 0 : pad }]}
            accessibilityRole="header"
          >
            <View style={styles.rule} />
            <View style={styles.dateChip}>
              <AppText size="xs" weight="medium">
                {section.title}
              </AppText>
            </View>
            <View style={styles.rule} />
          </View>
        )}
        ItemSeparatorComponent={() => <View style={{ height: rs(isSm, space[4], space[6]) }} />}
        renderItem={({ item }) => (
          <NotificationItem notification={item} onPress={() => handleOpen(item)} />
        )}
        ListFooterComponent={
          isLoadingMore ? (
            <View style={styles.footer}>
              <Loader size={20} color={PRIMARY} />
            </View>
          ) : !hasMore && notifications.length > 5 ? (
            <AppText size="xs" color={GREY} align="center" style={styles.footer}>
              You’re all caught up
            </AppText>
          ) : null
        }
      />
    );
  };

  return (
    <MainLayout>
      <Header title="Notifications" />
      {renderBody()}

      {unreadCount > 0 && (
        <View style={styles.markRead}>
          <Button
            onPress={handleMarkAll}
            size="sm"
            title="Mark all as read"
            loading={marking}
          />
        </View>
      )}
    </MainLayout>
  );
};

const ICONS: Record<string, { name: keyof typeof Feather.glyphMap; color: string }> = {
  date: { name: "calendar", color: "#FA5EBC" },
  gift: { name: "gift", color: "#D7BA38" },
  love: { name: "heart", color: "#FA2E2E" },
  settings: { name: "settings", color: "#8838F2" },
};

const NotificationItem = ({
  notification,
  onPress,
}: {
  notification: Notification;
  onPress: () => void;
}) => {
  const { subject, body, createdAt, read, url, type = "" } = notification;
  const { isSm } = useResponsive();
  const icon = ICONS[type] ?? ICONS.love;
  const time = new Date(createdAt).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    // The whole row is tappable: marks it read and opens its link if it has
    // one. (The icon used to be a button that did nothing.)
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.item,
        { gap: rs(isSm, space[3], space[4]) },
        pressed && styles.pressed,
      ]}
      accessibilityRole={url ? "link" : "button"}
      accessibilityLabel={`${read ? "" : "Unread. "}${subject}. ${body}. ${time}`}
      accessibilityHint={url ? "Opens the link" : undefined}
    >
      <View style={[styles.icon, { backgroundColor: `${icon.color}1A` }]}>
        <Feather name={icon.name} size={16} color={icon.color} />
      </View>
      <View style={styles.itemText}>
        <View style={styles.subjectRow}>
          <AppText size="sm" weight="medium" numberOfLines={2} style={styles.subject}>
            {subject}
          </AppText>
          {!read && <View style={styles.unreadDot} />}
        </View>
        <AppText size="xs" color={GREY} numberOfLines={3}>
          {body}
        </AppText>
        <View style={styles.metaRow}>
          <AppText size="xs" color={GREY}>
            {time}
          </AppText>
          {url && <Feather name="external-link" size={12} color={GREY} />}
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  retry: { alignItems: "center", paddingBottom: space[16] },
  footer: { paddingVertical: space[6], alignItems: "center" },
  dateRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[3],
    marginBottom: space[4],
  },
  rule: { flex: 1, height: 1, backgroundColor: PRIMARY_1A },
  // `bg-white-05 border border-primary-1A rounded-3xl px-2.5 py-1.5`
  dateChip: {
    backgroundColor: WHITE_05,
    borderWidth: 1,
    borderColor: PRIMARY_1A,
    borderRadius: radii["3xl"],
    paddingHorizontal: space[2.5],
    paddingVertical: space[1.5],
  },
  // `absolute bottom-[64px] right-4`
  markRead: { position: "absolute", bottom: 64, right: space[4] },
  item: { flexDirection: "row", alignItems: "flex-start", width: "100%", borderRadius: radii.md },
  pressed: { opacity: 0.7 },
  // Same 40px circle the ActionButton drew.
  icon: { width: 40, height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center" },
  itemText: { flex: 1, flexShrink: 1, gap: space[2] },
  subjectRow: { flexDirection: "row", alignItems: "flex-start", gap: space[2] },
  subject: { flex: 1, lineHeight: 21 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: space[1.5] },
  unreadDot: {
    width: space[1.5],
    height: space[1.5],
    borderRadius: space[1.5] / 2,
    backgroundColor: ERROR,
    marginTop: space[1],
    flexShrink: 0,
  },
});

export default Notifications;
