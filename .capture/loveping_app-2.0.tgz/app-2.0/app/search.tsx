import { AppText, Header, MessageCard } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import ping from "@/src/services/ping";
import { useSearchStore } from "@/src/stores";
import {
  GREY,
  PRIMARY,
  PRIMARY_1A,
  WHITE,
  fontSize,
  hit,
  radii,
  rs,
  space,
  useResponsive,
  weight,
} from "@/src/theme";
import { toneLabel } from "@/src/components/ui/ToneTags";
import { Ionicons } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import {
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import useSWR from "swr";

const SUGGESTIONS = ["Romantic", "Good night", "Anniversary"];

type Nudge = {
  _id: string;
  message: string;
  tones: string[];
  isSaved?: boolean;
};

/**
 * Search used to store the query without searching anything. It now filters
 * the user's messages (same SWR cache as the Messages tab, so usually no
 * extra request) by text or tone.
 */
const Search = () => {
  const {
    query,
    setQuery,
    clearQuery,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
  } = useSearchStore();
  const { isSm } = useResponsive();
  const pad = rs(isSm, space[4], space[6]);
  const listGap = rs(isSm, space[3], space[4]);
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const { data, mutate } = useSWR("/ping/all", ping.getAllPing, {
    revalidateOnFocus: false,
    dedupingInterval: 30000,
  });

  const term = query.trim().toLowerCase();
  const results = useMemo(() => {
    if (!term) return [];
    const nudges: Nudge[] = data?.data ?? [];
    return nudges.filter(
      (n) =>
        n.message?.toLowerCase().includes(term) ||
        n.tones?.some(
          (t) =>
            t.toLowerCase().includes(term) ||
            toneLabel(t).toLowerCase().includes(term),
        ),
    );
  }, [data?.data, term]);

  const runSearch = (value: string) => {
    setQuery(value);
    addRecentSearch(value);
    setOpenIndex(0);
  };

  return (
    <MainLayout>
      <Header title="Search" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scroll}
      >
        <View style={[styles.section, { padding: pad }]}>
          <View style={styles.field}>
            <Ionicons name="search-outline" size={16} color={PRIMARY} />
            <TextInput
              placeholder="Search"
              value={query}
              onChangeText={setQuery}
              onSubmitEditing={() => query.trim() && addRecentSearch(query)}
              style={styles.input}
              placeholderTextColor={GREY}
              returnKeyType="search"
              autoFocus
              autoCorrect={false}
              accessibilityLabel="Search messages"
            />
            {query.length > 0 && (
              <TouchableOpacity
                onPress={clearQuery}
                accessibilityRole="button"
                accessibilityLabel="Clear search"
                hitSlop={hit.glyph}
              >
                <Ionicons name="close-circle" size={16} color={GREY} />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {term ? (
          <View style={{ padding: pad, gap: space[4] }}>
            <AppText size="sm" weight="medium" accessibilityLiveRegion="polite">
              {results.length
                ? `${results.length} ${results.length === 1 ? "result" : "results"}`
                : `No messages match “${query.trim()}”`}
            </AppText>
            {results.map((nudge, index) => (
              <MessageCard
                key={nudge._id}
                id={nudge._id}
                message={nudge.message}
                tones={nudge.tones}
                isSaved={nudge.isSaved}
                isOpen={openIndex === index}
                onPress={() => setOpenIndex(openIndex === index ? null : index)}
                onChange={() => mutate()}
              />
            ))}
          </View>
        ) : (
          <>
            <View style={[styles.section, { padding: pad }]}>
              <AppText size="sm" weight="medium" style={styles.heading}>
                Search suggestions
              </AppText>
              <View style={{ gap: listGap }}>
                {SUGGESTIONS.map((item) => (
                  <SearchRow
                    key={item}
                    label={item}
                    onPress={() => runSearch(item)}
                  />
                ))}
              </View>
            </View>

            <View style={{ padding: pad }}>
              <View style={styles.headingRow}>
                <AppText size="sm" weight="medium">
                  Recent Searches
                </AppText>
                {recentSearches.length > 0 && (
                  <TouchableOpacity
                    onPress={clearRecentSearches}
                    accessibilityRole="button"
                    accessibilityLabel="Clear recent searches"
                    hitSlop={hit.text}
                  >
                    <AppText size="xs" weight="medium" color={PRIMARY}>
                      Clear
                    </AppText>
                  </TouchableOpacity>
                )}
              </View>
              <View style={{ gap: listGap }}>
                {recentSearches.length > 0 ? (
                  recentSearches.map((item) => (
                    <SearchRow
                      key={item}
                      label={item}
                      onPress={() => runSearch(item)}
                    />
                  ))
                ) : (
                  <AppText size="sm" weight="medium" color={GREY}>
                    No recent searches
                  </AppText>
                )}
              </View>
            </View>
          </>
        )}
      </ScrollView>
    </MainLayout>
  );
};

const SearchRow = ({
  label,
  onPress,
}: {
  label: string;
  onPress: () => void;
}) => (
  <TouchableOpacity
    style={styles.row}
    onPress={onPress}
    accessibilityRole="button"
    accessibilityLabel={`Search for ${label}`}
    hitSlop={{ top: 6, bottom: 6 }}
  >
    <Ionicons name="time-outline" size={16} color={GREY} />
    <AppText size="sm" weight="medium" color={GREY}>
      {label}
    </AppText>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  scroll: { flexGrow: 1, paddingBottom: space[16] },
  section: { borderBottomWidth: 1, borderBottomColor: PRIMARY_1A },
  // `flex-row items-center gap-2 border border-primary-1A rounded py-2.5 px-4`
  field: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    borderWidth: 1,
    borderColor: PRIMARY_1A,
    borderRadius: radii.base,
    paddingVertical: space[2.5],
    paddingHorizontal: space[4],
  },
  // `flex-1 text-base font-inter-medium text-white`
  input: {
    flex: 1,
    ...fontSize.base,
    ...weight.medium,
    color: WHITE,
    paddingVertical: 0,
  },
  heading: { marginBottom: space[4] },
  headingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: space[4],
  },
  row: { flexDirection: "row", alignItems: "center", gap: space[2] },
});

export default Search;
