import { AppText, Button } from "@/src/components";
import { router } from "expo-router";
import { Pressable, StyleSheet, View } from "react-native";

import Badge from "@/assets/icons/badge.svg";
import ExistingUser from "@/assets/icons/existing-user.svg";
import Guest from "@/assets/icons/guest.svg";
import NewUser from "@/assets/icons/new-user.svg";
import { usePushNotifications } from "@/src/context/PushNotificationProvider";
import { MainLayout } from "@/src/layouts";
import auth from "@/src/services/auth";
import { useToastStore, useUserStore } from "@/src/stores";
import {
  PRIMARY_14,
  WHITE_08,
  WHITE_80,
  gutter,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { saveRefreshToken, saveToken } from "@/src/utils";
import { isAxiosError } from "axios";
import { useState } from "react";
import { SvgProps } from "react-native-svg";

// Type for valid route paths
type ValidRoute =
  "/auth/signup" | "/auth/signin" | "/auth/complete-account-setup";

const getStartedOptions = [
  {
    id: 0,
    title: "New User",
    description: "Create a Loveping account to save nudges and gifts forever.",
    icon: NewUser,
    route: "/auth/signup" as ValidRoute,
  },
  {
    id: 1,
    title: "Existing User",
    description: "Sign in to access your saved messages and gift history.",
    icon: ExistingUser,
    route: "/auth/signin" as ValidRoute,
  },
  {
    id: 2,
    title: "Guest",
    description:
      "Continue without an account — try Loveping with limited features.",
    icon: Guest,
    route: "/auth/complete-account-setup" as ValidRoute,
  },
];

type getStartedOption = {
  id: number;
  title: string;
  description: string;
  icon: React.FC<SvgProps>;
  route: ValidRoute;
};

const GetStarted = () => {
  const { expoPushToken } = usePushNotifications();
  const { showToast } = useToastStore();
  const { setUser } = useUserStore();
  const { isSm } = useResponsive();
  const px = rs(isSm, gutter.base, gutter.sm);

  const [isSelected, setIsSelected] = useState<getStartedOption | null>(
    getStartedOptions[0],
  );

  const [loading, setLoading] = useState(false);
  const signupAsGuest = async () => {
    try {
      setLoading(true);
      const response = await auth.signupAsGuest({
        notification_token: expoPushToken ?? "",
      });
      // Await both so the first API call after this has the token.
      await saveToken(response.data.token);
      if (response.data.refresh_token) {
        await saveRefreshToken(response.data.refresh_token);
      }
      setUser({
        ...response.data.user,
        is_guest: true,
      });
      router.push("/auth/complete-account-setup");
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An unexpected error occurred during Login", "error", "top");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <View style={[styles.body, { padding: px }]}>
        <View
          style={[styles.intro, { marginBottom: rs(isSm, space[4], space[6]) }]}
        >
          <AppText size="lg" weight="semibold" accessibilityRole="header">
            Get Started
          </AppText>
          <AppText
            size={isSm ? "sm" : "xs"}
            weight="medium"
            color={WHITE_80}
            style={styles.subtitle}
          >
            Your gentle reminder to keep the spark alive
          </AppText>
        </View>

        <View style={styles.options}>
          {getStartedOptions.map((option) => (
            <GetStartedOption
              title={option.title}
              description={option.description}
              Icon={option.icon}
              key={option.id}
              isSelected={isSelected?.id === option.id}
              onPress={() => {
                setIsSelected(option);
              }}
            />
          ))}
        </View>
      </View>

      <View style={{ paddingHorizontal: px }}>
        <Button
          title="Continue"
          onPress={() => {
            if (isSelected?.id === 2) {
              signupAsGuest();
            } else if (isSelected) {
              router.push(isSelected?.route);
            }
          }}
          variant="primary"
          size="lg"
          loading={loading}
        />
      </View>
    </MainLayout>
  );
};

type GetStartedOptionProps = {
  title: string;
  description: string;
  Icon: React.FC<SvgProps>;
  isSelected?: boolean;
  onPress: () => void;
  loading?: boolean;
};

const GetStartedOption = ({
  title,
  description,
  Icon,
  isSelected = false,
  onPress,
  loading,
}: GetStartedOptionProps) => {
  const { isSm } = useResponsive();
  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      accessibilityRole="radio"
      accessibilityState={{ selected: isSelected }}
      accessibilityLabel={`${title}. ${description}`}
    >
      <View
        style={[
          styles.card,
          {
            gap: rs(isSm, space[4], space[5]),
            padding: rs(isSm, space[3], space[5]),
          },
          isSelected ? styles.cardSelected : styles.cardIdle,
        ]}
      >
        <View style={styles.iconBox}>
          <Icon />
        </View>

        <View style={styles.cardText}>
          <AppText size="base" weight="semibold">
            {title}
          </AppText>
          <AppText size="sm" weight="medium" color={WHITE_80}>
            {description}
          </AppText>
        </View>

        {isSelected && (
          <View style={styles.badge}>
            <Badge />
          </View>
        )}
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  body: { flex: 1 },
  intro: { paddingTop: space[8] },
  subtitle: { marginTop: space[1] },
  options: { gap: space[4] },
  // `flex-row items-center bg-white-08 rounded-md overflow-hidden`
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: WHITE_08,
    borderRadius: radii.md,
    overflow: "hidden",
  },
  cardSelected: { borderWidth: 0.5, borderColor: PRIMARY_14 },
  cardIdle: { borderWidth: 1, borderColor: WHITE_08 },
  // `w-18 h-16 rounded bg-white-08 overflow-hidden`
  iconBox: {
    width: space[18],
    height: space[16],
    borderRadius: radii.base,
    backgroundColor: WHITE_08,
    overflow: "hidden",
  },
  cardText: { flex: 1 },
  badge: { position: "absolute", right: 0, top: 0 },
});

export default GetStarted;
