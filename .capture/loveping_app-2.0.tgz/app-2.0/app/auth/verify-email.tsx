import { AppText, GoBack, OTPInput, OtpTimer, Submit } from "@/src/components";
import auth from "@/src/services/auth";
import { useToastStore } from "@/src/stores";
import {
  PRIMARY_1A,
  SECONDARY,
  WHITE_80,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { isAxiosError } from "axios";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import { useEffect, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const VerifyEmail = () => {
  const insets = useSafeAreaInsets();
  const { email, hasPartner } = useLocalSearchParams();
  const { isSm } = useResponsive();

  const { showToast } = useToastStore();
  const [keyboardHeight, setKeyboardHeight] = useState<number>(0);

  // Handle keyboard show/hide for Android
  useEffect(() => {
    if (Platform.OS === "android") {
      const showSubscription = Keyboard.addListener("keyboardDidShow", (e) => {
        setKeyboardHeight(e.endCoordinates.height);
      });
      const hideSubscription = Keyboard.addListener("keyboardDidHide", () => {
        setKeyboardHeight(0);
      });

      return () => {
        showSubscription.remove();
        hideSubscription.remove();
      };
    }
  }, []);

  const handleSubmit = async (values: { otp: string }) => {
    try {
      const response = await auth.verifyOTPCode({
        email_address: email as string,
        code: values.otp,
        type: "verify_user",
      });
      if (response.status === 200 || response.status === 201) {
        showToast("Email verified successfully", "success", "top");
        if (hasPartner !== "true") {
          router.push("/auth/complete-account-setup");
        } else {
          router.dismissAll();
          router.replace("/(tabs)");
        }
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An error occurred", "error", "top");
      }
    }
  };

  const [resending, setResending] = useState<boolean>(false);
  const resendOTP = async () => {
    try {
      setResending(true);
      const response = await auth.requestOTPCode({
        email_address: email as string,
        type: "verify_user",
      });
      if (response.status === 200 || response.status === 201) {
        showToast("OTP sent successfully", "success", "top");
        setTimeLeft(60);
        setIsRunning(true);
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An error occurred", "error", "top");
      }
    } finally {
      setResending(false);
    }
  };

  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [isRunning, setIsRunning] = useState<boolean>(true);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | undefined;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    if (timeLeft === 0) {
      setIsRunning(false);
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  return (
    <View
      style={[
        styles.screen,
        { paddingTop: insets.top, paddingBottom: insets.bottom },
      ]}
    >
      <View style={styles.header}>
        <View style={styles.side}>
          <GoBack />
        </View>

        <AppText
          size="base"
          weight="semibold"
          align="center"
          style={styles.fill}
          accessibilityRole="header"
        >
          Verification
        </AppText>

        <View style={styles.side} />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.fill}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 20}
      >
        <Formik initialValues={{ otp: "" }} onSubmit={handleSubmit}>
          {({ values, isSubmitting }) => (
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{
                flexGrow: 1,
                paddingBottom: Platform.OS === "android" ? keyboardHeight : 0,
              }}
            >
              <View
                style={[
                  styles.fill,
                  { padding: rs(isSm, space[4], space[6]) },
                ]}
              >
                <AppText
                  size="sm"
                  weight="medium"
                  color={WHITE_80}
                  style={styles.lead}
                >
                  Enter the 6-digit OTP that was sent to {email}
                </AppText>

                <OTPInput numInputs={6} name="otp" />

                <OtpTimer
                  isRunning={isRunning}
                  timeLeft={timeLeft}
                  onResend={resendOTP}
                  disabled={isRunning || resending}
                />
              </View>

              <View style={styles.footer}>
                <Submit
                  title="Continue"
                  loading={isSubmitting || resending}
                  disable={values.otp.length !== 6}
                />
              </View>
            </ScrollView>
          )}
        </Formik>
      </KeyboardAvoidingView>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: SECONDARY },
  fill: { flex: 1 },
  // `border-b border-primary-1A px-6 py-4 flex-row items-center justify-between`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: space[6],
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  side: { width: space[14.5] },
  lead: { lineHeight: 21 },
  footer: { paddingHorizontal: space[6] },
});

export default VerifyEmail;
