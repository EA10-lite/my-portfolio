import PinScreen from "@/src/screens/auth/PinScreen";

/**
 * PIN Authentication Screen Route
 * 
 * This route displays the PIN entry screen when:
 * - User has onboarded
 * - User is logged in
 * - User has a PIN saved
 */
export default PinScreen;

