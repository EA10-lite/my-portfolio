import { AppText, Input, Submit } from "@/src/components";
import { usePushNotifications } from "@/src/context/PushNotificationProvider";
import { MainLayout } from "@/src/layouts";
import auth from "@/src/services/auth";
import { useToastStore, useUserStore } from "@/src/stores";
import { usePartnerStore } from "@/src/stores/partnerStore";
import {
  PRIMARY,
  PRIMARY_1A,
  WHITE_08,
  gutter,
  radii,
  rs,
  space,
  useResponsive,
  hit,
} from "@/src/theme";
import { saveRefreshToken, saveToken } from "@/src/utils";
import { signinSchema } from "@/src/utils/validations";
import { isAxiosError } from "axios";
import { router } from "expo-router";
import { Formik } from "formik";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";

type SigninFormValues = {
  email_address: string;
  password: string;
};

const Signin = () => {
  const { expoPushToken } = usePushNotifications();
  const { showToast } = useToastStore();
  const { setUser } = useUserStore();
  const { setPartner } = usePartnerStore();
  const { isSm } = useResponsive();
  const px = rs(isSm, gutter.base, gutter.sm);

  const handleSubmit = async (values: SigninFormValues) => {
    try {
      const response = await auth.login({
        ...values,
        notification_token: expoPushToken ?? "",
      });
      if (response.status === 200 || response.status === 201) {
        // Await both so the first API call after this has the token.
        await saveToken(response.data.token);
        if (response.data.refresh_token) {
          await saveRefreshToken(response.data.refresh_token);
        }
        setUser({ ...response.data.user });
        if (!response.data.user.is_verified) {
          const otp_result = await auth.requestOTPCode({
            email_address: values.email_address,
            type: "verify_user",
          });

          if (otp_result.status === 200 || otp_result.status === 201) {
            showToast("OTP sent successfully", "success", "top");
            router.push({
              pathname: "/auth/verify-email",
              params: {
                email: values.email_address,
                hasPartner: response.data.user.partner ? "true" : "false",
              },
            });
          }
        } else {
          router.dismissAll();
          if (response.data.user.partner) {
            setPartner(response.data.user.partner);
            router.replace("/(tabs)");
          } else {
            router.replace("/auth/complete-account-setup");
          }
        }
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An unexpected error occurred during Login", "error", "top");
      }
      console.log(error);
    }
  };

  return (
    <MainLayout>
      <View style={[styles.titleBar, { paddingHorizontal: px }]}>
        <AppText size="base" weight="semibold" accessibilityRole="header">
          Existing User
        </AppText>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.fill}
        keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
      >
        <Formik
          initialValues={{
            email_address: "",
            password: "",
          }}
          onSubmit={handleSubmit}
          validationSchema={signinSchema}
        >
          {({ isSubmitting }) => (
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={styles.scroll}
              onScrollBeginDrag={Keyboard.dismiss}
            >
              <View
                style={[styles.form, { gap: rs(isSm, space[4], space[6]) }]}
              >
                <View style={[styles.fill, { padding: px }]}>
                  <Input
                    name="email_address"
                    label="Email Address"
                    type="email-address"
                    disabled={isSubmitting}
                  />
                  <Input
                    name="password"
                    label="Password"
                    isSecureText={true}
                    disabled={isSubmitting}
                  />

                  <TouchableOpacity
                    style={styles.forgot}
                    onPress={() => router.push("/auth/forgot-password")}
                    accessibilityRole="link"
                    hitSlop={hit.pill}
                  >
                    <AppText size="xs" weight="medium" color={PRIMARY}>
                      Forgot Password?
                    </AppText>
                  </TouchableOpacity>
                </View>

                <View style={{ paddingHorizontal: px }}>
                  <Submit title="Login" loading={isSubmitting} />
                </View>
              </View>
            </ScrollView>
          )}
        </Formik>
      </KeyboardAvoidingView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1 },
  form: { flex: 1 },
  // `border-b border-[#48D9621A] px-4 sm:px-6 py-4`
  titleBar: {
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  // `border border-white-08 rounded-2xl py-2.5 px-4 self-start bg-white-08`
  forgot: {
    alignSelf: "flex-start",
    borderWidth: 1,
    borderColor: WHITE_08,
    backgroundColor: WHITE_08,
    borderRadius: radii["2xl"],
    paddingVertical: space[2.5],
    paddingHorizontal: space[4],
  },
});

export default Signin;
