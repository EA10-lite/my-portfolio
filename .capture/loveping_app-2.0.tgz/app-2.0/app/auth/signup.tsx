import { AppText, Checkbox, Input, Submit } from "@/src/components";
import { usePushNotifications } from "@/src/context/PushNotificationProvider";
import { MainLayout } from "@/src/layouts";
import auth from "@/src/services/auth";
import { usePartnerStore, useUserStore } from "@/src/stores";
import { useToastStore } from "@/src/stores/toastStore";
import {
  PRIMARY,
  PRIMARY_1A,
  WHITE_80,
  gutter,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { saveRefreshToken, saveToken } from "@/src/utils";
import { signupSchema } from "@/src/utils/validations";
import { isAxiosError } from "axios";
import { router, useLocalSearchParams } from "expo-router";
import { Formik } from "formik";
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";

type SignupFormValues = {
  full_name: string;
  email_address: string;
  password: string;
  confirmPassword: string;
  terms: boolean;
};

const Signup = () => {
  const { expoPushToken } = usePushNotifications();
  const { setUser } = useUserStore();
  const { partner } = usePartnerStore();
  const { showToast } = useToastStore();
  const { id } = useLocalSearchParams();
  const { isSm } = useResponsive();
  const px = rs(isSm, gutter.base, gutter.sm);

  const handleSubmit = async (values: SignupFormValues) => {
    if (!values.terms) {
      showToast("Please agree to the terms and conditions", "error", "top");
      return;
    }

    try {
      const response = await auth.signup({
        full_name: values.full_name,
        email_address: values.email_address,
        password: values.password,
        notification_token: expoPushToken ?? "",
      });

      if (response.status === 201 || response.status === 200) {
        // Await both so the first API call after this has the token.
        await saveToken(response.data.token);
        if (response.data.refresh_token) {
          await saveRefreshToken(response.data.refresh_token);
        }
        setUser({
          ...response.data.user,
          is_guest: false,
        });

        const otp_result = await auth.requestOTPCode({
          email_address: values.email_address,
          type: "verify_user",
        });

        if (otp_result.status === 200 || otp_result.status === 201) {
          showToast("OTP sent successfully", "success", "top");
          router.push({
            pathname: "/auth/verify-email",
            params: {
              email: values.email_address,
              otp_code: otp_result.data.otp,
            },
          });
        }
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "bottom");
      } else {
        showToast(
          "An unexpected error occurred during Login",
          "error",
          "bottom",
        );
      }
      console.log(error);
    }
  };

  const upgradeGuest = async (values: SignupFormValues) => {
    if (!values.terms) {
      showToast("Please agree to the terms and conditions", "error", "top");
      return;
    }
    try {
      const response = await auth.upgradeGuest({
        full_name: values.full_name,
        email_address: values.email_address,
        password: values.password,
        guest_id: id as string,
      });

      if (response.status === 201 || response.status === 200) {
        // The upgrade returns new tokens and the updated user; both used to
        // be dropped, so the app still treated the person as a guest.
        await saveToken(response.data.token);
        if (response.data.refresh_token) {
          await saveRefreshToken(response.data.refresh_token);
        }
        setUser(response.data.user);

        const otp_result = await auth.requestOTPCode({
          email_address: values.email_address,
          type: "verify_user",
        });

        if (otp_result.status === 200 || otp_result.status === 201) {
          showToast("OTP sent successfully", "success", "top");
          router.push({
            pathname: "/auth/verify-email",
            params: {
              email: values.email_address,
              // The guest already set up their partner: after verifying,
              // go home instead of through account setup again.
              hasPartner: partner ? "true" : "false",
            },
          });
        }
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An unexpected error occurred during Login", "error", "top");
      }
      console.log(error);
    }
  };

  return (
    <MainLayout>
      <View style={[styles.titleBar, { paddingHorizontal: px }]}>
        <AppText size="base" weight="semibold" accessibilityRole="header">
          New User
        </AppText>
      </View>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.fill}
        keyboardVerticalOffset={Platform.OS === "ios" ? 60 : 20}
      >
        <Formik
          initialValues={{
            full_name: "",
            email_address: "",
            password: "",
            confirmPassword: "",
            terms: false,
          }}
          onSubmit={id ? upgradeGuest : handleSubmit}
          validationSchema={signupSchema}
        >
          {({ isSubmitting }) => (
            <ScrollView
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={styles.scroll}
            >
              <View
                style={[styles.fill, { gap: rs(isSm, space[4], space[6]) }]}
              >
                <View style={[styles.fill, { padding: px }]}>
                  <AppText
                    size="sm"
                    weight="medium"
                    color={WHITE_80}
                    style={styles.intro}
                  >
                    Back up your nudges, save your partner&apos;s dates, and
                    never miss a spark.
                  </AppText>
                  <View style={styles.fill}>
                    <Input
                      name="full_name"
                      label="Full Name"
                      disabled={isSubmitting}
                    />
                    <Input
                      name="email_address"
                      label="Email Address"
                      type="email-address"
                      disabled={isSubmitting}
                    />
                    <Input
                      name="password"
                      label="Password"
                      isSecureText={true}
                      isPassword={true}
                      disabled={isSubmitting}
                    />
                    <Input
                      name="confirmPassword"
                      label="Confirm Password"
                      isSecureText={true}
                      isPassword={true}
                      disabled={isSubmitting}
                    />

                    <Checkbox
                      name="terms"
                      label="I agree to the terms and conditions"
                      Label={
                        <AppText size="sm" weight="medium" style={styles.terms}>
                          I agree to the{" "}
                          <AppText
                            size="sm"
                            weight="medium"
                            color={PRIMARY}
                            style={styles.underline}
                          >
                            terms and conditions
                          </AppText>
                        </AppText>
                      }
                    />
                  </View>
                </View>

                <View style={{ paddingHorizontal: px }}>
                  <Submit title="Continue" loading={isSubmitting} />
                </View>
              </View>
            </ScrollView>
          )}
        </Formik>
      </KeyboardAvoidingView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1 },
  titleBar: {
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  intro: { marginBottom: space[6] },
  terms: { flexShrink: 1 },
  underline: { textDecorationLine: "underline" },
});

export default Signup;
