import {
  AppText,
  GoBack,
  Input,
  OTPInput,
  OtpTimer,
  Submit,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import auth from "@/src/services/auth";
import { useToastStore } from "@/src/stores";
import {
  PRIMARY,
  PRIMARY_08,
  PRIMARY_1A,
  WHITE_80,
  gutter,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import {
  resetPasswordSchema,
  resetPasswordSchema2,
} from "@/src/utils/validations";
import { isAxiosError } from "axios";
import { router } from "expo-router";
import { Formik } from "formik";
import { useEffect, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";

type ResetPasswordFormValues = {
  email_address: string;
};

type ResetPasswordFormValues2 = {
  newPassword: string;
  confirmPassword: string;
};

const ForgotPassword = () => {
  const { showToast } = useToastStore();
  const { isSm } = useResponsive();
  const px = rs(isSm, gutter.base, gutter.sm);

  const [otp_id, setOtpId] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [step, setStep] = useState<number>(1);

  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  const sendEmailVerification = async (values: ResetPasswordFormValues) => {
    setEmail(values.email_address);
    try {
      await auth.requestOTPCode({
        ...values,
        type: "reset_password",
      });
      showToast("OTP sent to your email", "success");
      setStep(2);
      setIsRunning(true);
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error");
      } else {
        showToast(
          "An unexpected error occurred during Request OTP Code",
          "error",
        );
      }
      console.log(error);
    }
  };

  const verifyOTP = async (values: { otp: string }) => {
    try {
      const response = await auth.verifyOTPCode({
        email_address: email as string,
        code: values.otp,
        type: "reset_password",
      });
      if (response.status === 200 || response.status === 201) {
        showToast("OTP verified successfully", "success");
        setOtpId(response.data.otp_id);
        setStep(3);
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error");
      } else {
        showToast("An error occurred", "error");
      }
    }
  };

  const [resending, setResending] = useState<boolean>(false);
  const resendOTP = async () => {
    try {
      setResending(true);
      const response = await auth.requestOTPCode({
        email_address: email as string,
        type: "reset_password",
      });
      if (response.status === 200 || response.status === 201) {
        showToast("OTP sent successfully", "success");
        setTimeLeft(60);
        setIsRunning(true);
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error");
      } else {
        showToast("An error occurred", "error");
      }
    } finally {
      setResending(false);
    }
  };

  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | undefined;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    if (timeLeft === 0) {
      setIsRunning(false);
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft]);

  const resetPassword = async (values: ResetPasswordFormValues2) => {
    try {
      const response = await auth.resetPassword({
        password: values.newPassword,
        otp_id: otp_id as string,
      });
      if (response.status === 200 || response.status === 201) {
        showToast("Password reset successfully", "success");
        router.push("/success?type=password_reset");
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error");
      } else {
        showToast("An error occurred", "error");
      }
    }
  };
  return (
    <MainLayout>
      <View style={[styles.header, { paddingHorizontal: px }]}>
        <View style={styles.side}>
          <GoBack
            onPress={step === 1 ? () => router.back() : () => setStep(1)}
          />
        </View>

        <AppText
          size="base"
          weight="semibold"
          align="center"
          style={styles.fill}
          accessibilityRole="header"
        >
          {step === 1
            ? "Reset Password"
            : step === 2
              ? "OTP Input"
              : "Reset Password"}
        </AppText>

        <View style={[styles.side, styles.stepChip]}>
          <AppText size="xs" weight="medium" color={PRIMARY} align="center">
            {step} of 3
          </AppText>
        </View>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.fill}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 20}
      >
        {step === 1 ? (
          <Formik
            initialValues={{ email_address: "" }}
            onSubmit={sendEmailVerification}
            validationSchema={resetPasswordSchema}
          >
            {({ isSubmitting }) => (
              <ScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={styles.scroll}
              >
                <View style={styles.fill}>
                  <View style={[styles.fill, { padding: px }]}>
                    <AppText
                      size="sm"
                      weight="medium"
                      color={WHITE_80}
                      style={{ marginBottom: rs(isSm, space[4], space[6]) }}
                    >
                      Enter the email linked to your Loveping account and
                      we&apos;ll send you an OTP
                    </AppText>
                    <View style={styles.fill}>
                      <Input
                        name="email_address"
                        label="Email Address"
                        type="email-address"
                      />
                    </View>
                  </View>

                  <View style={{ paddingHorizontal: px }}>
                    <Submit title="Reset" loading={isSubmitting} />
                  </View>
                </View>
              </ScrollView>
            )}
          </Formik>
        ) : step === 2 ? (
          <Formik initialValues={{ otp: "" }} onSubmit={verifyOTP}>
            {({ isSubmitting }) => (
              <ScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={styles.scroll}
              >
                <View style={[styles.fill, styles.gap6]}>
                  <View style={[styles.fill, styles.pad6]}>
                    <AppText size="sm" weight="medium" color={WHITE_80}>
                      Enter the 6-digit OTP that was sent to {email}
                    </AppText>
                    <View>
                      <OTPInput numInputs={6} name="otp" />
                      <OtpTimer
                        isRunning={isRunning}
                        timeLeft={timeLeft}
                        onResend={resendOTP}
                        disabled={isRunning || resending}
                      />
                    </View>
                  </View>

                  <View style={styles.px6}>
                    <Submit title="Verify" loading={isSubmitting} />
                  </View>
                </View>
              </ScrollView>
            )}
          </Formik>
        ) : (
          <Formik
            initialValues={{ newPassword: "", confirmPassword: "" }}
            onSubmit={resetPassword}
            validationSchema={resetPasswordSchema2}
          >
            {({ isSubmitting }) => (
              <ScrollView
                showsVerticalScrollIndicator={false}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={styles.scroll}
              >
                <View style={styles.fill}>
                  <View style={[styles.fill, styles.pad6]}>
                    <AppText
                      size="sm"
                      weight="medium"
                      color={WHITE_80}
                      style={styles.lead}
                    >
                      Create a new password for your Loveping account
                    </AppText>
                    <View style={styles.fill}>
                      <Input
                        name="newPassword"
                        label="New Password"
                        isSecureText={true}
                      />
                      <Input
                        name="confirmPassword"
                        label="Confirm Password"
                        isSecureText={true}
                      />
                    </View>
                  </View>

                  <View style={styles.px6}>
                    <Submit title="Reset" loading={isSubmitting} />
                  </View>
                </View>
              </ScrollView>
            )}
          </Formik>
        )}
      </KeyboardAvoidingView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1 },
  // `border-b border-primary-1A py-4 flex-row items-center justify-between`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  side: { width: space[14.5] },
  // `border border-primary-08 bg-primary-08 rounded-2xl py-1.5`
  stepChip: {
    borderWidth: 1,
    borderColor: PRIMARY_08,
    backgroundColor: PRIMARY_08,
    borderRadius: radii["2xl"],
    paddingVertical: space[1.5],
  },
  gap6: { gap: space[6] },
  pad6: { padding: space[6] },
  px6: { paddingHorizontal: space[6] },
  lead: { marginBottom: space[6] },
});

export default ForgotPassword;
