import {
  AppText,
  Button,
  Chip,
  DatePickerModal,
  GenderModal,
  Input,
  LoveLanguageModal,
  NudgeTypeModal,
  RelationshipTypeModal,
  Select,
  Submit,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import {
  useModalStore,
  useNudgeStore,
  usePartnerStore,
  useToastStore,
} from "@/src/stores";
import { Feather } from "@expo/vector-icons";
import { Formik } from "formik";
import { useEffect, useRef, useState } from "react";
import {
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";

import { TONES } from "@/src/constants/data";
import {
  PRIMARY,
  PRIMARY_08,
  PRIMARY_1A,
  WHITE_80,
  gutter,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { PartnerPreference } from "@/src/interfaces/Partner";
import partner from "@/src/services/partner";
import { formatDate } from "@/src/utils/formatter";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isAxiosError } from "axios";
import { router } from "expo-router";

type ToneStylePreferencesFormValues = {
  selectedTones: string[];
};

type RelationshipContextFormValues = {
  partner_name: string;
  gender: "male" | "female";
  relationship_type: string;
  partner_birthday: string;
  anniversary_date: string;
  love_language: string[];
};

type NudgeFormValues = {
  nudgeType: "once_a_week" | "repeat";
  day: string[];
  isRandom: boolean;
};

const CompleteAccountSetup = () => {
  const { setNudge } = useNudgeStore();
  const { setPartner, partner: partnerData } = usePartnerStore();
  const { showToast } = useToastStore();
  const [step, setStep] = useState<number>(1);
  const { isSm } = useResponsive();
  const px = rs(isSm, gutter.base, gutter.sm);
  const [keyboardHeight, setKeyboardHeight] = useState<number>(0);

  // Match other auth screens: add Android-only bottom padding while keyboard is open.
  useEffect(() => {
    if (Platform.OS === "android") {
      const showSubscription = Keyboard.addListener("keyboardDidShow", (e) => {
        setKeyboardHeight(e.endCoordinates.height);
      });
      const hideSubscription = Keyboard.addListener("keyboardDidHide", () => {
        setKeyboardHeight(0);
      });

      return () => {
        showSubscription.remove();
        hideSubscription.remove();
      };
    }
  }, []);

  const [partnerId, setPartnerId] = useState<string>("");
  const addPartner = async (
    values: RelationshipContextFormValues,
    nextStep: number,
  ) => {
    try {
      if (partnerData) {
        setStep(nextStep);
        return;
      }
      if (values.love_language.length === 0) {
        showToast("Please select at least one love language", "error", "top");
        return;
      }
      const response = await partner.addPartner({ ...values });
      if (response.status === 200 || response.status === 201) {
        setStep(nextStep);
        setPartnerId(response.data._id);
        setPartner(response.data);
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An unexpected error occurred during Login", "error", "top");
      }
      console.log(error);
    }
  };

  const [preference, setPreference] = useState<PartnerPreference>({
    partner: "",
    tone: [],
    nudge_type: {
      repeat: "once_a_week",
      days: [],
      isRandom: false,
    },
  });

  const handleStep2Submit = async (
    values: ToneStylePreferencesFormValues,
    nextStep: number,
  ) => {
    if (values.selectedTones.length === 0) {
      showToast("Please select at least one tone", "error", "top");
      return;
    }

    setPreference({
      ...preference,
      tone: values.selectedTones,
    });

    setStep(nextStep);
  };

  const handleSelectTone = (
    tone: string,
    values: ToneStylePreferencesFormValues,
    setFieldValue: (field: string, value: any) => void,
  ) => {
    const current = values.selectedTones || [];
    const exists = current.includes(tone);
    const next = exists
      ? current.filter((t) => t !== tone)
      : [...current, tone];
    setFieldValue("selectedTones", next);
  };

  const handleSubmit = async (values: NudgeFormValues) => {
    try {
      const response = await partner.addPartnerPreference({
        partner: partnerId
          ? partnerId
          : partnerData?._id
            ? partnerData._id
            : "",
        tone: preference.tone,
        nudge_type: {
          repeat: values.nudgeType,
          days: values.day,
          isRandom: values.isRandom,
        },
      });

      if (response.status === 200 || response.status === 201) {
        setNudge({
          repeat: values.nudgeType,
          days: values.day,
          isRandom: values.isRandom,
        });
        router.dismissAll();
        router.replace("/success?type=account_setup_complete");
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An unexpected error occurred during Login", "error", "top");
      }
      console.log(error);
    }
  };

  // Use modal store for all modals
  const { datePickerModal, openDatePickerModal, closeDatePickerModal } =
    useModalStore();

  const nudgeModalRef = useRef<BottomSheetModal>(null);
  const openNudgeModal = () => nudgeModalRef.current?.present();
  const closeNudgeModal = () => nudgeModalRef.current?.dismiss();

  const loveLanguageModalRef = useRef<BottomSheetModal>(null);
  const openLoveLanguageModal = () => loveLanguageModalRef.current?.present();
  const closeLoveLanguageModal = () => loveLanguageModalRef.current?.dismiss();

  const genderModalRef = useRef<BottomSheetModal>(null);
  const openGenderModal = () => genderModalRef.current?.present();
  const closeGenderModal = () => genderModalRef.current?.dismiss();

  const relationshipModalRef = useRef<BottomSheetModal>(null);
  const openRelationshipModal = () => relationshipModalRef.current?.present();
  const closeRelationshipModal = () => relationshipModalRef.current?.dismiss();

  return (
    <MainLayout>
      <View style={[styles.header, { paddingHorizontal: px }]}>
        <AppText
          size="base"
          weight="semibold"
          numberOfLines={1}
          style={styles.title}
          accessibilityRole="header"
        >
          {step === 1
            ? "Add Partner"
            : step === 2
              ? "Tone & Style Preferences"
              : "Notification Settings"}
        </AppText>

        <View style={styles.stepChip}>
          <AppText size="xs" weight="bold" color={PRIMARY} align="center">
            {step} of 3
          </AppText>
        </View>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.fill}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 20}
      >
        {step === 1 ? (
          <Formik
            initialValues={{
              partner_name: partnerData?.partner_name || "",
              gender: partnerData?.gender || "female",
              relationship_type: partnerData?.relationship_type || "spouse",
              partner_birthday:
                partnerData?.partner_birthday?.split("T")[0] || "",
              anniversary_date:
                partnerData?.anniversary_date?.split("T")[0] || "",
              love_language: partnerData?.love_language || ([] as string[]),
            }}
            onSubmit={(values: RelationshipContextFormValues) =>
              addPartner(values, 2)
            }
          >
            {({ values, setFieldValue, isSubmitting }) => (
              <>
                <LoveLanguageModal
                  ref={loveLanguageModalRef}
                  onClose={closeLoveLanguageModal}
                  selectedLanguages={values["love_language"]}
                  handleSelectLoveLanguage={(language: string) => {
                    const current = values["love_language"] || [];
                    const exists = current.includes(language);
                    const next = exists
                      ? current.filter((l) => l !== language)
                      : [...current, language];
                    setFieldValue("love_language", next);
                  }}
                  onSave={closeLoveLanguageModal}
                />

                <GenderModal
                  ref={genderModalRef}
                  onClose={closeGenderModal}
                  selectedGender={values["gender"]}
                  handleSelectGender={(gender: string) => {
                    setFieldValue("gender", gender);
                  }}
                  onSave={closeGenderModal}
                />

                <RelationshipTypeModal
                  ref={relationshipModalRef}
                  onClose={closeRelationshipModal}
                  selectedRelationshipType={values["relationship_type"]}
                  handleSelectRelationshipType={(relationshipType: string) => {
                    setFieldValue("relationship_type", relationshipType);
                  }}
                  onSave={closeRelationshipModal}
                />

                <DatePickerModal
                  isVisible={
                    datePickerModal.isVisible &&
                    datePickerModal.context === "partnerBirthday"
                  }
                  onClose={closeDatePickerModal}
                  onSelect={(formatted: string) =>
                    setFieldValue("partner_birthday", formatted)
                  }
                  value={values["partner_birthday"]}
                />
                <DatePickerModal
                  isVisible={
                    datePickerModal.isVisible &&
                    datePickerModal.context === "anniversary"
                  }
                  onClose={closeDatePickerModal}
                  onSelect={(formatted: string) =>
                    setFieldValue("anniversary_date", formatted)
                  }
                  value={values["anniversary_date"]}
                />

                <ScrollView
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  removeClippedSubviews={true}
                  contentContainerStyle={{
                    flexGrow: 1,
                    paddingBottom:
                      Platform.OS === "android" ? keyboardHeight : 0,
                  }}
                >
                  <View style={[styles.fill, { padding: px }]}>
                    <Input name="partner_name" label="Partner's Name" />
                    <Select
                      name="gender"
                      label="Partner's Gender"
                      onPress={openGenderModal}
                      value={values["gender"]}
                      icon={<Feather name="user" size={20} color="#48D962" />}
                      placeholder="Select Partner's Gender"
                    />
                    <Select
                      name="relationship_type"
                      label="Relationship Type"
                      onPress={openRelationshipModal}
                      value={values["relationship_type"]}
                      icon={<Feather name="user" size={20} color="#48D962" />}
                      placeholder="Select Relationship Type"
                    />
                    <Select
                      name="partner_birthday"
                      label="Partner's Birthday"
                      onPress={() => openDatePickerModal("partnerBirthday")}
                      value={
                        values["partner_birthday"]
                          ? formatDate(values["partner_birthday"])
                          : ""
                      }
                      icon={
                        <Feather name="calendar" size={20} color="#48D962" />
                      }
                      placeholder="Select Partner's Birthday"
                    />

                    <Select
                      name="anniversary_date"
                      label="Anniversary"
                      onPress={() => openDatePickerModal("anniversary")}
                      value={
                        values["anniversary_date"]
                          ? formatDate(values["anniversary_date"])
                          : ""
                      }
                      icon={
                        <Feather name="calendar" size={20} color="#48D962" />
                      }
                      placeholder="Select Anniversary"
                    />

                    <Select
                      name="love_language"
                      label="Love Language"
                      onPress={openLoveLanguageModal}
                      value={((): string => {
                        const selected = values["love_language"] || [];
                        if (selected.length === 0) return "";
                        if (selected.length === 1) return selected[0];
                        return `${selected[0]} + ${selected.length - 1} others`;
                      })()}
                    />
                  </View>
                  <View style={{ paddingHorizontal: px }}>
                    <Submit title="Continue" loading={isSubmitting} />
                  </View>
                </ScrollView>
              </>
            )}
          </Formik>
        ) : step === 2 ? (
          <Formik
            initialValues={{
              selectedTones: [] as string[],
            }}
            onSubmit={(values) => handleStep2Submit(values, 3)}
          >
            {({ setFieldValue, values, isSubmitting }) => (
              <>
                <View style={[styles.fill, { padding: px }]}>
                  <AppText
                    size="base"
                    weight="medium"
                    color={WHITE_80}
                    style={styles.question}
                  >
                    What kind of messages do you want to send?
                  </AppText>

                  <View style={styles.tones}>
                    {TONES.map((tone) => (
                      <Chip
                        key={tone.value}
                        label={tone.name}
                        selected={values["selectedTones"]?.includes(tone.value)}
                        onPress={() =>
                          handleSelectTone(tone.value, values, setFieldValue)
                        }
                      />
                    ))}
                  </View>
                </View>
                <View style={[styles.actions, { paddingHorizontal: px }]}>
                  <Submit title="Save Preferences" loading={false} />
                  <Button
                    title="Back"
                    onPress={() => setStep(1)}
                    variant="outline-secondary"
                    size="lg"
                  />
                </View>
              </>
            )}
          </Formik>
        ) : (
          <Formik
            key="step3-form"
            enableReinitialize={true}
            initialValues={{
              nudgeType: "once_a_week" as "once_a_week" | "repeat",
              day: ["tuesday"],
              isRandom: false,
            }}
            onSubmit={(values) => handleSubmit(values)}
          >
            {({ setFieldValue, values, isSubmitting }) => (
              <>
                <NudgeTypeModal
                  ref={nudgeModalRef}
                  onClose={closeNudgeModal}
                  nudgeType={values["nudgeType"]}
                  selectedDays={values["day"]}
                  onChangeNudgeType={(type: string) => {
                    // update type and normalize days to respect constraints
                    const currentDays = values["day"] || [];
                    let normalizedDays = currentDays;
                    if (type === "once_a_week") {
                      normalizedDays =
                        currentDays.length > 0 ? [currentDays[0]] : [];
                    } else {
                      normalizedDays = currentDays.slice(0, 3);
                    }
                    setFieldValue("nudgeType", type);
                    setFieldValue("day", normalizedDays);
                  }}
                  handleSelectDay={(day: string) => {
                    const type = values["nudgeType"];
                    const current = values["day"] || [];
                    const exists = current.includes(day);

                    if (type === "once_a_week") {
                      // Single selection behavior
                      if (exists) {
                        setFieldValue("day", []);
                      } else {
                        setFieldValue("day", [day]);
                      }
                      return;
                    }

                    // type === "Repeat" -> toggle up to max 3
                    if (exists) {
                      setFieldValue(
                        "day",
                        current.filter((d) => d !== day),
                      );
                    } else {
                      if (current.length >= 3) {
                        // prevent adding more than 3
                        showToast(
                          "You can choose up to 3 days for Repeat",
                          "error",
                        );
                        return;
                      }
                      setFieldValue("day", [...current, day]);
                    }
                  }}
                  setDays={(days: string[]) => {
                    setFieldValue("day", days);
                  }}
                />

                <View style={[styles.fill, { padding: px }]}>
                  <AppText
                    size="base"
                    weight="medium"
                    color={WHITE_80}
                    style={{ marginBottom: rs(isSm, space[4], space[6]) }}
                  >
                    When should we nudge you?
                  </AppText>

                  <Select
                    name="nudgeType"
                    label="Nudge Type"
                    value={(() => {
                      const type = values["nudgeType"];
                      const day = values["day"];
                      if (!type && !day) return "";
                      if (!type) return String(day ?? "");
                      if (!day) return String(type ?? "");
                      return `${type === "once_a_week" ? "Once a week" : "Repeat"} (${Array.isArray(day) ? day.join(", ") : day > 0 ? day : "please select a day"})`;
                    })()}
                    onPress={openNudgeModal}
                  />
                </View>
                <View style={[styles.actions, { paddingHorizontal: px }]}>
                  <Submit title="Set Reminder" loading={isSubmitting} />
                  <Button
                    title="Back"
                    onPress={() => setStep(2)}
                    variant="outline-secondary"
                    size="lg"
                  />
                </View>
              </>
            )}
          </Formik>
        )}
      </KeyboardAvoidingView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  // `border-b border-[#48D9621A] py-4 flex-row items-center justify-between`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  title: { flex: 1, flexShrink: 1, marginRight: space[2] },
  // `min-w-[58px] border border-[#48D96208] bg-[#48D96208] rounded-[35px] py-[6px]`
  stepChip: {
    minWidth: space[14.5],
    flexShrink: 0,
    borderWidth: 1,
    borderColor: PRIMARY_08,
    backgroundColor: PRIMARY_08,
    borderRadius: radii["2xl"],
    paddingVertical: space[1.5],
  },
  question: { marginBottom: space[4] },
  // `flex-row items-center gap-3 flex-wrap`
  tones: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: space[3],
  },
  actions: { gap: space[4] },
});

export default CompleteAccountSetup;
