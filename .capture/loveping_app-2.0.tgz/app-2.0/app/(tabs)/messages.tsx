import { MessagesScreen } from "@/src/screens";

export default function Messages() {
    return (
        <MessagesScreen />
    );
}   