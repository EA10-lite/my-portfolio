import ProfileScreen from "@/src/screens/profile/ProfileScreen";

const Profile = () => {
  return <ProfileScreen />;
};

export default Profile;
