import HomeScreen from "@/src/screens/home/HomeScreen";

/**
 * Home  Screen Route
 * 
 * This route displays the home screen when:
 */

export default HomeScreen;