import GiftsScreen from "@/src/screens/gifts/GiftsScreen";

const Gifts = () => {
    return (
        <GiftsScreen />
    )
}

export default Gifts;