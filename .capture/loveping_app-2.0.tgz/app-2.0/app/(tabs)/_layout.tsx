import { CustomTabBar } from "@/src/components";
import { useTabBarMetrics } from "@/src/components/tabBarMetrics";
import { setAppReady } from "@/src/context/notificationRouting";
import { UpdateSheet } from "@/src/features/appUpdate";
import { useTabBarStore } from "@/src/hooks/useTabStore";
import { SECONDARY } from "@/src/theme";
import { Tabs } from "expo-router";
import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, View } from "react-native";

export default function TabLayout() {
  // Select only `hidden` so the layout re-renders just when it flips.
  const hidden = useTabBarStore((s) => s.hidden);
  const translateY = useRef(new Animated.Value(0)).current;
  // Slide exactly off screen: bar height + its gap from the bottom edge
  // (a fixed 100 left 16-30px showing on phones with a home indicator or
  // Android nav bar).
  const { space: hideDistance } = useTabBarMetrics();

  // Slide the floating tab bar away while the user scrolls down.
  useEffect(() => {
    Animated.timing(translateY, {
      toValue: hidden ? hideDistance + 8 : 0,
      duration: 250,
      useNativeDriver: true,
    }).start();
  }, [hidden, hideDistance, translateY]);

  // The user is signed in and past the PIN screen: open any notification
  // that was tapped while the app was starting.
  useEffect(() => {
    setAppReady(true);
    return () => setAppReady(false);
  }, []);

  return (
    <View style={styles.screen}>
      <Tabs
        screenOptions={{
          headerShown: false,
        }}
        screenListeners={{
          // Always bring the bar back when the tab changes: otherwise it
          // stayed hidden if the new tab had nothing to scroll.
          focus: () => useTabBarStore.getState().setHidden(false),
        }}
        tabBar={(props) => <CustomTabBar translateY={translateY} {...props} />}
      />
      {/* Optional update: once per version, then the Home banner. */}
      <UpdateSheet />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: SECONDARY },
});
