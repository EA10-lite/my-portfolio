import { AppText, Header, ToggleItem } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { MaterialIcons } from "@expo/vector-icons";
import { useState } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";

import DeleteIcon from "@/assets/icons/delete.svg";
import UploadIcon from "@/assets/icons/upload.svg";
import { useUserStore } from "@/src/stores";
import {
  DANGER_33,
  ERROR_1A,
  PRIMARY,
  PRIMARY_08,
  PRIMARY_14,
  WHITE_08,
  WHITE_80,
  radii,
  rs,
  space,
  useResponsive, hit } from "@/src/theme";
import { router } from "expo-router";

// NOTE: these toggles and data-centre buttons are not wired to the API yet
// (see the plan, B9); this screen only restyles them.
const Privacy = () => {
  const { user } = useUserStore();
  const { isSm } = useResponsive();
  const [profileVisibility, setProfileVisibility] = useState<boolean>(
    user?.profile_visibility || false,
  );
  const [appLock, setAppLock] = useState<boolean>(false);
  const pad = rs(isSm, space[4], space[5]);

  return (
    <MainLayout>
      <Header title="Privacy" />

      <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
        <AppText
          size="sm"
          color={WHITE_80}
          italic
          style={{ marginBottom: rs(isSm, space[6], space[8]) }}
        >
          Control who sees your activity and data
        </AppText>

        <View style={[styles.fill, { gap: rs(isSm, space[4], space[6]) }]}>
          <View style={styles.group}>
            <ToggleItem
              title="Profile Visibility"
              value={profileVisibility}
              onValueChange={(value: boolean) => setProfileVisibility(value)}
              isLast={true}
            />
          </View>

          <View style={styles.group}>
            <View style={[styles.groupHeader, { padding: pad }]}>
              <AppText size="sm" weight="medium" style={styles.groupTitle}>
                Data center
              </AppText>
              <AppText size={isSm ? "sm" : "xs"} color={WHITE_80} italic>
                What should we do with your data on the app?
              </AppText>
            </View>

            <View style={{ padding: pad }}>
              <View style={[styles.row, { gap: rs(isSm, space[4], space[5]) }]}>
                <TouchableOpacity
                  style={[styles.circle, styles.upload]}
                  accessibilityRole="button"
                  accessibilityLabel="Export my data"
                  hitSlop={hit.circle}
                >
                  <UploadIcon />
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.circle, styles.delete]}
                  accessibilityRole="button"
                  accessibilityLabel="Delete my data"
                  hitSlop={hit.circle}
                >
                  <DeleteIcon />
                </TouchableOpacity>
              </View>
            </View>
          </View>

          <ToggleItem
            title="App Lock"
            value={appLock}
            onValueChange={(value: boolean) => setAppLock(value)}
            isLast={true}
          />

          <TouchableOpacity
            style={[styles.group, styles.linkRow]}
            onPress={() => router.push("/profile/settings/pin")}
            accessibilityRole="button"
          >
            <AppText size="sm" weight="medium">
              Set Pin
            </AppText>
            <MaterialIcons name="arrow-forward-ios" size={16} color={PRIMARY} />
          </TouchableOpacity>
        </View>
      </View>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  // `border border-primary-14 bg-white-08 rounded-md`
  group: {
    borderWidth: 1,
    borderColor: PRIMARY_14,
    backgroundColor: WHITE_08,
    borderRadius: radii.md,
  },
  groupHeader: { borderBottomWidth: 1, borderBottomColor: PRIMARY_14 },
  groupTitle: { marginBottom: space[2] },
  row: { flexDirection: "row", alignItems: "center" },
  circle: {
    width: space[10],
    height: space[10],
    borderRadius: space[10] / 2,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  upload: { backgroundColor: PRIMARY_08, borderColor: PRIMARY_14 },
  delete: { backgroundColor: DANGER_33, borderColor: ERROR_1A },
  linkRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: space[5],
  },
});

export default Privacy;
