import { AppText, FieldItem, Header, ToggleItem } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { useState } from "react";
import { StyleSheet, View } from "react-native";

import BellIcon from '@/assets/icons/bell-alt.svg';
import {
    BLUE_MEDIUM_1A,
    PRIMARY_14,
    WHITE_08,
    WHITE_80,
    radii,
    rs,
    space,
    useResponsive,
} from "@/src/theme";
import { useToastStore, useUserStore } from "@/src/stores";
import { router } from "expo-router";
import account from "@/src/services/account";
import { UserDTO } from "@/src/utils/interface";


const Notification = () => {
    const { showToast } = useToastStore();
    const { user, setUser } = useUserStore()
    const { isSm } = useResponsive();
    const [specialOccassionReminder, setSpecialOccassionReminder] = useState<boolean>(user?.special_occassion_reminders || false);
    const [silentMode, setSilentMode] = useState<boolean>(user?.silent_mode || false);

    const handleChange = async (silentMode: boolean, specialOccassionReminder: boolean) => {
        try {
            const response = await account.updateProfile({
                ...user,
                special_occassion_reminders: specialOccassionReminder,
                silent_mode: silentMode,
            })

            if (response.status === 200) {
                setUser({
                    ...user,
                    special_occassion_reminders: specialOccassionReminder,
                    silent_mode: silentMode,
                } as UserDTO)
            }
        } catch (error) {
            console.log("ERROR:", error);
            showToast("Failed to update notifications", "error", "top");
            setSpecialOccassionReminder(user?.special_occassion_reminders || false)
            setSilentMode(user?.silent_mode || false)
        }
    }
    const notficationItems = [
        {
            title: "Special Occassion Reminder",
            value: specialOccassionReminder,
            onValueChange: (value: boolean) => {
                setSpecialOccassionReminder(value)
                handleChange(silentMode, value)
            }
        },
        {
            title: "Silent Mode",
            value: silentMode,
            onValueChange: (value: boolean) => {
                setSilentMode(value)
                handleChange(value, specialOccassionReminder)
            }
        }
    ]
    return (
        <MainLayout>
            <Header title="Notifications" />

            <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
                <AppText
                    size={isSm ? "sm" : "xs"}
                    color={WHITE_80}
                    italic
                    style={{ marginBottom: rs(isSm, space[6], space[8]) }}
                >
                    Manage daily nudges and reminders
                </AppText>

                <View style={styles.stack}>
                    <FieldItem
                        title="Nudge Type"
                        description="Customise your nudge settings"
                        icon={<BellIcon width={20} height={20} />}
                        iconBgColor={BLUE_MEDIUM_1A}
                        iconBorderColor={BLUE_MEDIUM_1A}
                        onPress={() => router.push("/profile/settings/notifications/nudge")}
                    />

                    <View style={styles.group}>
                        {notficationItems.map((item, index) => (
                            <ToggleItem
                                key={index}
                                title={item.title}
                                value={item.value}
                                onValueChange={item.onValueChange}
                                isLast={index === notficationItems.length - 1}
                            />
                        ))}
                    </View>
                </View>
            </View>
        </MainLayout>
    )
}



const styles = StyleSheet.create({
    fill: { flex: 1 },
    stack: { gap: space[5] },
    // `border border-primary-14 bg-white-08 rounded-md`
    group: {
        borderWidth: 1,
        borderColor: PRIMARY_14,
        backgroundColor: WHITE_08,
        borderRadius: radii.md,
    },
});

export default Notification;