import {
  AppText,
  Header,
  NudgeTypeModal,
  Select,
  Submit,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { useNudgeStore } from "@/src/stores";
import { useToastStore } from "@/src/stores/toastStore";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isAxiosError } from "axios";
import { router } from "expo-router";
import { Formik } from "formik";
import { useRef } from "react";
import { StyleSheet, View } from "react-native";
import { WHITE_80, space } from "@/src/theme";

type NudgeFormValues = {
  nudgeType: "repeat" | "once_a_week";
  days: string[];
};

const Nudge = () => {
  const { nudge, setNudge } = useNudgeStore();
  const { showToast } = useToastStore();

  const nudgeModalRef = useRef<BottomSheetModal>(null);
  const openNudgeModal = () => nudgeModalRef.current?.present();
  const closeNudgeModal = () => nudgeModalRef.current?.dismiss();

  const handleSubmit = async (values: NudgeFormValues) => {
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      setNudge({
        repeat: values.nudgeType,
        days: values.days,
        isRandom: false,
      });
      showToast("Nudge updated successfully", "success", "top");
      router.back();
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast(
          "An unexpected error occurred during Nudge Update",
          "error",
          "top",
        );
      }
    }
  };

  return (
    <MainLayout>
      <Header title="Nudge Type" />

      <View style={styles.fill}>
        <Formik
          initialValues={{
            nudgeType:
              (nudge?.repeat as "repeat" | "once_a_week") || "once_a_week",
            days: (nudge?.days as string[]) || ([] as string[]),
          }}
          onSubmit={handleSubmit}
        >
          {({ values, setFieldValue, isSubmitting }) => (
            <>
              <View style={styles.body}>
                <AppText
                  size="base"
                  weight="medium"
                  color={WHITE_80}
                  style={styles.question}
                >
                  When should we nudge you?
                </AppText>

                <NudgeTypeModal
                  ref={nudgeModalRef}
                  onClose={closeNudgeModal}
                  nudgeType={values["nudgeType"]}
                  selectedDays={values["days"]}
                  onChangeNudgeType={(type: string) => {
                    // update type and normalize days to respect constraints
                    const currentDays = values["days"] || [];
                    let normalizedDays = currentDays;
                    if (type === "once_a_week") {
                      normalizedDays =
                        currentDays.length > 0 ? [currentDays[0]] : [];
                    } else {
                      normalizedDays = currentDays.slice(0, 3);
                    }
                    setFieldValue("nudgeType", type);
                    setFieldValue("days", normalizedDays);
                  }}
                  handleSelectDay={(day: string) => {
                    const type = values["nudgeType"];
                    const current = values["days"] || [];
                    const exists = current.includes(day);

                    if (type === "once_a_week") {
                      // Single selection behavior
                      if (exists) {
                        setFieldValue("days", []);
                      } else {
                        setFieldValue("days", [day]);
                      }
                      return;
                    }

                    // type === "Repeat" -> toggle up to max 3
                    if (exists) {
                      setFieldValue(
                        "days",
                        current.filter((d) => d !== day),
                      );
                    } else {
                      if (current.length >= 3) {
                        // prevent adding more than 3
                        showToast(
                          "You can choose up to 3 days for Repeat",
                          "error",
                        );
                        return;
                      }
                      setFieldValue("days", [...current, day]);
                    }
                  }}
                  setDays={(days: string[]) => {
                    setFieldValue("days", days);
                  }}
                />
                <Select
                  name="nudgeType"
                  label="Nudge Type"
                  value={(() => {
                    const type = values["nudgeType"];
                    const day = values["days"];
                    if (!type && !day) return "";
                    if (!type) return String(day ?? "");
                    if (!day) return String(type ?? "");
                    return `${type === "once_a_week" ? "Once a week" : "Repeat"} (${Array.isArray(day) ? day.join(", ") : day > 0 ? day : "please select a day"})`;
                  })()}
                  onPress={openNudgeModal}
                />
              </View>

              <View style={styles.footer}>
                <Submit title="Update" loading={isSubmitting} />
              </View>
            </>
          )}
        </Formik>
      </View>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  body: { flex: 1, padding: space[6] },
  question: { marginBottom: space[6] },
  footer: { paddingHorizontal: space[6] },
});

export default Nudge;
