import { AppText, Header, Input, Submit } from "@/src/components"
import { MainLayout } from "@/src/layouts"
import { useToastStore } from "@/src/stores/toastStore"
import { savePin } from "@/src/utils/pinStorage"
import { Formik } from "formik"
import { StyleSheet, View } from "react-native"
import { WHITE_80, rs, space, useResponsive } from "@/src/theme"
import * as Yup from "yup"

import { router } from "expo-router"

/**
 * Validation schema for PIN form
 * Ensures both PINs are 6 digits and match
 */
const pinValidationSchema = Yup.object().shape({
    pin: Yup.string()
        .required("PIN is required")
        .length(6, "PIN must be exactly 6 digits")
        .matches(/^\d+$/, "PIN must contain only numbers"),
    confirmPin: Yup.string()
        .required("Please confirm your PIN")
        .oneOf([Yup.ref("pin")], "PINs do not match"),
});

type PinFormValues = {
    pin: string;
    confirmPin: string;
}

const Pin = () => {
    const { showToast } = useToastStore();
    const { isSm } = useResponsive();
    /**
     * Handles PIN submission
     * Validates, saves PIN to storage, and shows success modal
     */
    const handleSubmit = async (values: PinFormValues) => {
        try {
            // Validate PIN format
            if (values.pin.length !== 6 || !/^\d{6}$/.test(values.pin)) {
                showToast("PIN must be exactly 6 digits", "error");
                return;
            }

            // Check if PINs match
            if (values.pin !== values.confirmPin) {
                showToast("PINs do not match", "error");
                return;
            }

            // Save PIN to storage
            await savePin(values.pin);
            // Simulate API call delay for better UX
            await new Promise(resolve => setTimeout(resolve, 500));
            router.push("/success?type=pin_set");
        } catch (error: any) {
            console.error("Error setting PIN:", error);
            showToast(error?.message || "Failed to set PIN. Please try again.", "error");
        }
    }   
    return (
        <MainLayout>
            <Header title="Pin" />
            <View
                style={[
                    styles.fill,
                    {
                        paddingHorizontal: rs(isSm, space[4], space[6]),
                        paddingTop: rs(isSm, space[4], space[6]),
                    },
                ]}
            >
                <AppText size="sm" color={WHITE_80} italic style={styles.lead}>
                    Enter a 6-Digit Pin
                </AppText>

                <Formik
                    initialValues={{
                        pin: "",
                        confirmPin: ""
                    }}
                    validationSchema={pinValidationSchema}
                    onSubmit={handleSubmit}
                >
                    {({ isSubmitting })=> (
                        <View style={styles.fill}>
                            <View style={styles.fill}>
                                <Input 
                                    name="pin"
                                    label="Pin"
                                    isSecureText
                                    isPassword={false}
                                />
                                <Input 
                                    name="confirmPin"
                                    label="Confirm Pin"
                                    isSecureText
                                    isPassword={false}
                                />
                            </View>
                            
                            <Submit title="Set Pin" loading={isSubmitting} />
                        </View>
                    )}
                </Formik>
            </View>
        </MainLayout>
    )
}


const styles = StyleSheet.create({
    fill: { flex: 1 },
    lead: { marginBottom: space[8] },
});

export default Pin;