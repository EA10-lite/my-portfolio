import { Header, MenuItem, MenuList } from "@/src/components";
import { MainLayout } from "@/src/layouts";

import { router } from "expo-router";

import NotificationIcon from '@/assets/icons/bell.svg';
import GlobeIcon from '@/assets/icons/globe.svg';
import PrivacyIcon from '@/assets/icons/lock.svg';
import { ERROR_1A, PRIMARY_1A, PURPLE_LIGHT_1A } from "@/src/constants/colors";

const settingsItems: MenuItem[] = [
    {
        id: 1,
        title: "Notifications",
        description: "Manage nudges, reminders, and alerts",
        icon: <NotificationIcon width={20} height={20} />,
        iconBgColor: PURPLE_LIGHT_1A,
        iconBorderColor: PURPLE_LIGHT_1A,
        onPress: () => router.push("/profile/settings/notifications"),
    },
    {
        id: 2,
        title: "Privacy",
        description: "Control visibility, data, and app lock",
        icon: <PrivacyIcon width={20} height={20} />,
        iconBgColor: ERROR_1A,
        iconBorderColor: ERROR_1A,
        onPress: () => router.push("/profile/settings/privacy"),
    },
    {
        id: 3,
        title: "Language",
        description: "Select your preferred app language",
        icon: <GlobeIcon width={20} height={20} />,
        iconBgColor: PRIMARY_1A,
        iconBorderColor: PRIMARY_1A,
        onPress: () => {},
    },
]


const Settings = () => {
  return (
    <MainLayout>
      <Header title="App Settings" />
      <MenuList items={settingsItems} />
    </MainLayout>
  );
};

export default Settings;