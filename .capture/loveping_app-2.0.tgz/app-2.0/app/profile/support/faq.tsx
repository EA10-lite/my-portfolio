import HistoryIcon from "@/assets/icons/file-primary.svg";
import { Accordion, Empty, FAQCardSkeleton, Header } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import feedback from "@/src/services/feedback";
import { rs, space, useResponsive } from "@/src/theme";
import { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import useSWR from "swr";

const Faq = () => {
  const [activeAccordion, setActiveAccordion] = useState<number | null>(0);
  const { isSm } = useResponsive();

  const { data, isLoading } = useSWR("getFAQ", feedback.getFAQ, {
    revalidateOnFocus: false,
  });

  return (
    <MainLayout>
      <Header title="Help & FAQs" />

      {isLoading ? (
        <View style={styles.fill}>
          <FAQCardSkeleton />
        </View>
      ) : data?.data?.length > 0 ? (
        <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
          <ScrollView
            style={styles.fill}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.scroll}
          >
            <View style={[styles.fill, { gap: rs(isSm, space[4], space[6]) }]}>
              {data?.data?.map((faq: any, index: number) => (
                <Accordion
                  key={index}
                  title={faq.question}
                  content={faq.answer}
                  isOpen={activeAccordion === index}
                  toggleAccordion={() =>
                    setActiveAccordion(activeAccordion === index ? null : index)
                  }
                />
              ))}
            </View>
          </ScrollView>
        </View>
      ) : (
        <Empty
          description="No FAQs found"
          icon={<HistoryIcon width={24} height={24} />}
        />
      )}
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { paddingBottom: 120 },
});

export default Faq;
