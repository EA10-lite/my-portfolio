import { Header, MenuItem, MenuList } from "@/src/components";
import { MainLayout } from "@/src/layouts";

import { router } from "expo-router";

import NotificationIcon from "@/assets/icons/bell.svg";
import FeedbackIcon from "@/assets/icons/feedback.svg";
import MessageIcon from "@/assets/icons/message.svg";
import WarningIcon from "@/assets/icons/warning.svg";
import { PRIMARY } from "@/src/constants/colors";

const supportItems: MenuItem[] = [
  {
    id: 1,
    title: "Help & FAQs",
    description: "Quick answers to common questions",
    icon: <NotificationIcon width={20} height={20} />,
    iconBgColor: "#8A38F51A",
    iconBorderColor: "#8A38F51A",
    onPress: () => router.push("/profile/support/faq"),
  },
  {
    id: 2,
    title: "Contact Us",
    description: "Send us a message directly",
    icon: <MessageIcon width={20} height={20} color={PRIMARY} />,
    iconBgColor: "#3FCBAD1A",
    iconBorderColor: "#3FCBAD1A",
    onPress: () => router.push("/profile/support/contact"),
  },
  {
    id: 3,
    title: "Feedback",
    description: "Tell us what you love or what we can improve",
    icon: <FeedbackIcon width={20} height={20} />,
    iconBgColor: "#4563FD1A",
    iconBorderColor: "#4563FD1A",
    onPress: () => router.push("/profile/support/feedback"),
  },
  {
    id: 4,
    title: "Report an issue",
    description: "Let us know about a bug or problem",
    icon: <WarningIcon width={20} height={20} />,
    iconBgColor: "#FA2E2E1A",
    iconBorderColor: "#FA2E2E1A",
    onPress: () => router.push("/profile/support/report"),
  },
];

const support = () => {
  return (
    <MainLayout>
      <Header title="App support" />
      <MenuList items={supportItems} />
    </MainLayout>
  );
};

export default support;
