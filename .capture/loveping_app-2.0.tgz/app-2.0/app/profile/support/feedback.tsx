import ThumbsDownIcon from "@/assets/icons/thumbs-down.svg";
import ThumbsUpIcon from "@/assets/icons/thumbs-up.svg";
import { AppText, Header, Submit, Textbox } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { useToastStore } from "@/src/stores/toastStore";
import {
  DANGER_24,
  ERROR,
  PRIMARY,
  WHITE_08,
  WHITE_80,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { feedbackSchema } from "@/src/utils/validations";
import { Formik } from "formik";
import { StyleSheet, TouchableOpacity, View } from "react-native";

import feedback from "@/src/services/feedback";
import { router } from "expo-router";

type FeedbackFormValues = {
  message: string;
  feedback_type: "positive" | "negative";
};

const Feedback = () => {
  const { showToast } = useToastStore();
  const { isSm } = useResponsive();

  const handleSubmit = async (values: FeedbackFormValues) => {
    try {
      const response = await feedback.addFeedback(values);
      if (response.status === 200 || response.status === 201) {
        router.push("/success?type=feedback_submitted");
      } else {
        showToast("Failed to submit feedback", "error");
      }
    } catch (error: any) {
      const message =
        error.response?.data?.message ??
        error.response?.data?.error ??
        error.response?.data?.detail ??
        error.message;
      showToast(message || "Could not submit feedback", "error", "top");
    }
  };

  return (
    <MainLayout>
      <Header title="Feedback" />

      <Formik
        initialValues={{
          message: "",
          feedback_type: "positive" as FeedbackFormValues["feedback_type"],
        }}
        onSubmit={handleSubmit}
        validationSchema={feedbackSchema}
      >
        {({ setFieldValue, values, isSubmitting }) => (
          <>
            <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
              <AppText
                size={isSm ? "sm" : "xs"}
                color={WHITE_80}
                italic
                style={{ marginBottom: rs(isSm, space[6], space[8]) }}
              >
                Tell us what you love or what we can improve
              </AppText>

              <View
                style={[
                  styles.choices,
                  { marginBottom: rs(isSm, space[6], space[8]) },
                ]}
              >
                <TouchableOpacity
                  onPress={() => setFieldValue("feedback_type", "positive")}
                  accessibilityRole="radio"
                  accessibilityState={{
                    selected: values.feedback_type === "positive",
                  }}
                >
                  <View
                    style={[
                      styles.choice,
                      styles.positive,
                      values.feedback_type === "positive" && styles.positiveOn,
                    ]}
                  >
                    <AppText size="sm" weight="medium" color={PRIMARY}>
                      I love it
                    </AppText>
                    <ThumbsUpIcon width={16} height={16} />
                  </View>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setFieldValue("feedback_type", "negative")}
                  accessibilityRole="radio"
                  accessibilityState={{
                    selected: values.feedback_type === "negative",
                  }}
                >
                  <View
                    style={[
                      styles.choice,
                      styles.negative,
                      values.feedback_type === "negative" && styles.negativeOn,
                    ]}
                  >
                    <AppText size="sm" weight="medium" color={ERROR}>
                      Needs Work
                    </AppText>
                    <ThumbsDownIcon width={16} height={16} />
                  </View>
                </TouchableOpacity>
              </View>
              <Textbox
                name="message"
                label="Message"
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.footer}>
              <Submit title="Send" loading={isSubmitting} />
            </View>
          </>
        )}
      </Formik>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  choices: { flexDirection: "row", alignItems: "center", gap: space[4] },
  // `flex-row items-center gap-2 rounded-2xl p-2.5 px-6`
  choice: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    borderRadius: radii["2xl"],
    paddingVertical: space[2.5],
    paddingHorizontal: space[6],
  },
  positive: { backgroundColor: WHITE_08 },
  positiveOn: { borderWidth: 1, borderColor: PRIMARY },
  negative: { backgroundColor: DANGER_24 },
  negativeOn: { borderWidth: 1, borderColor: ERROR },
  footer: { paddingHorizontal: space[6], gap: space[4] },
});

export default Feedback;
