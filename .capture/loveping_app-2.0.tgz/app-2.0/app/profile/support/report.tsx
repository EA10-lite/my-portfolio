import CheckIcon from "@/assets/icons/check.svg";
import { AppText, Header, Submit, Textbox } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { useToastStore } from "@/src/stores/toastStore";
import {
  PRIMARY,
  PRIMARY_1A,
  WHITE_08,
  WHITE_80,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { reportSchema } from "@/src/utils/validations";
import { Formik } from "formik";
import { StyleSheet, TouchableOpacity, View } from "react-native";

import report from "@/src/services/report";
import { router } from "expo-router";

type ReportFormValues = {
  message: string;
  issue_type: "bug" | "feature" | "payment" | "privacy" | "other" | "rating";
};

const Report = () => {
  const { showToast } = useToastStore();
  const { isSm } = useResponsive();

  const handleSubmit = async (values: ReportFormValues) => {
    try {
      const response = await report.addReport(values);
      if (response.status === 200 || response.status === 201) {
        router.push("/success?type=report_submitted");
      } else {
        showToast("Failed to submit report", "error");
      }
    } catch (error: any) {
      const message =
        error.response?.data?.message ??
        error.response?.data?.error ??
        error.response?.data?.detail ??
        error.message;
      showToast(message || "Could not submit feedback", "error", "top");
    }
  };

  return (
    <MainLayout>
      <Header title="Report an issue" />

      <Formik
        initialValues={{
          message: "",
          issue_type: "bug" as ReportFormValues["issue_type"],
        }}
        onSubmit={handleSubmit}
        validationSchema={reportSchema}
      >
        {({ values, setFieldValue, isSubmitting }) => (
          <>
            <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
              <AppText
                size={isSm ? "sm" : "xs"}
                color={WHITE_80}
                italic
                style={{ marginBottom: rs(isSm, space[6], space[8]) }}
              >
                Let us know about a bug or problem
              </AppText>

              <View style={styles.choices}>
                <ReportBtns
                  title="Bug Report"
                  isSelected={values.issue_type === "bug"}
                  onPress={() => setFieldValue("issue_type", "bug")}
                />
                <ReportBtns
                  title="Precision Concern"
                  isSelected={values.issue_type === "feature"}
                  onPress={() => setFieldValue("issue_type", "feature")}
                />
                <ReportBtns
                  title="Payment issue"
                  isSelected={values.issue_type === "payment"}
                  // Was `setFieldValue("reportType", ...)`, so this option
                  // could never be selected or sent.
                  onPress={() => setFieldValue("issue_type", "payment")}
                />
                <ReportBtns
                  title="Privacy issue"
                  isSelected={values.issue_type === "privacy"}
                  onPress={() => setFieldValue("issue_type", "privacy")}
                />
              </View>
              <Textbox
                name="message"
                label="Tell us what went wrong"
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.footer}>
              <Submit title="Send" loading={isSubmitting} />
            </View>
          </>
        )}
      </Formik>
    </MainLayout>
  );
};

type ReportBtnProps = {
  title: string;
  isSelected: boolean;
  onPress: () => void;
};

const ReportBtns = ({ title, isSelected, onPress }: ReportBtnProps) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      accessibilityRole="radio"
      accessibilityState={{ selected: isSelected }}
    >
      <View style={[styles.choice, isSelected && styles.choiceOn]}>
        <AppText size="sm" weight="medium" color={PRIMARY}>
          {title}
        </AppText>
        {isSelected && <CheckIcon width={16} height={16} />}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  choices: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: space[4],
    marginBottom: space[6],
  },
  // `bg-white-08 rounded-2xl p-2.5 px-6 flex-row items-center justify-center gap-2`
  choice: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: space[2],
    backgroundColor: WHITE_08,
    borderRadius: radii["2xl"],
    paddingVertical: space[2.5],
    paddingHorizontal: space[6],
  },
  choiceOn: { borderWidth: 1, borderColor: PRIMARY_1A },
  footer: { paddingHorizontal: space[6] },
});

export default Report;
