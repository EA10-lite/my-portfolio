import { Header, Input, Submit, Textbox } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import feedback from "@/src/services/feedback";
import { useToastStore, useUserStore } from "@/src/stores";
import { rs, space, useResponsive } from "@/src/theme";
import { contactSchema } from "@/src/utils/validations";
import { router } from "expo-router";
import { Formik } from "formik";
import { StyleSheet, View } from "react-native";

type ContactFormValues = {
  name: string;
  email: string;
  message: string;
};

const Contact = () => {
  const { user } = useUserStore();
  const { showToast } = useToastStore();
  const { isSm } = useResponsive();

  const handleSubmit = async (values: ContactFormValues) => {
    try {
      // `contactUs` resolves with the response body (not the axios response)
      // and throws on HTTP errors, so reaching this line means it succeeded.
      // The old check on `response.status` was always false.
      await feedback.contactUs(values);
      router.push("/success?type=feedback_submitted");
    } catch (error: any) {
      const message =
        error.response?.data?.message ??
        error.response?.data?.error ??
        error.response?.data?.detail ??
        error.message;
      showToast(message || "Could not submit feedback", "error", "top");
    }
  };

  return (
    <MainLayout>
      <Header title="Contact Us" />

      <Formik
        initialValues={{
          name: user?.full_name || "",
          email: user?.email_address || "",
          message: "",
        }}
        onSubmit={handleSubmit}
        validationSchema={contactSchema}
      >
        {({ isSubmitting }) => (
          <View
            style={[
              styles.fill,
              {
                paddingHorizontal: rs(isSm, space[4], space[6]),
                paddingTop: rs(isSm, space[4], space[6]),
              },
            ]}
          >
            <View style={styles.fill}>
              <Input name="name" label="Name" disabled={true} />
              <Input
                name="email"
                label="Email Address"
                type="email-address"
                disabled={true}
              />
              <Textbox
                name="message"
                label="Message"
                multiline
                numberOfLines={4}
              />
            </View>

            <Submit title="Send" loading={isSubmitting} />
          </View>
        )}
      </Formik>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
});

export default Contact;
