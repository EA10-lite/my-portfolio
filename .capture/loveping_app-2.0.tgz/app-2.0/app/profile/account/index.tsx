import {
  AppText,
  DatePickerModal,
  Header,
  Input,
  LoveLanguageModal,
  Select,
  Submit,
} from "@/src/components";
import { PRIMARY, PRIMARY_1A, WHITE_08, radii, rs, space, useResponsive, hit } from "@/src/theme";
import { UpdateProfile } from "@/src/interfaces/Account";
import { Partner } from "@/src/interfaces/Partner";
import { MainLayout } from "@/src/layouts";
import account from "@/src/services/account";
import { useModalStore, usePartnerStore, useUserStore } from "@/src/stores";
import { useToastStore } from "@/src/stores/toastStore";
import { formatDate } from "@/src/utils/formatter";
import { UserDTO } from "@/src/utils/interface";
import {
  editAccountNoPartnerSchema,
  editAccountSchema,
} from "@/src/utils/validations";
import { Feather } from "@expo/vector-icons";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isAxiosError } from "axios";
import { router } from "expo-router";
import { Formik } from "formik";
import { useRef } from "react";
import { ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";

const EditAccount = () => {
  const { user, setUser } = useUserStore();
  const { partner, setPartner } = usePartnerStore();
  const { showToast } = useToastStore();

  const handleSubmit = async (values: UpdateProfile) => {
    try {
      const response = await account.updateProfile(values);
      if (response.status === 200 || response.status === 201 || response.data) {
        setUser({
          ...user,
          full_name: values.full_name,
        } as UserDTO);
        setPartner({
          ...partner,
          partner_name: response?.data?.partner?.partner_name,
          partner_birthday: response?.data?.partner?.partner_birthday,
          anniversary_date: response?.data?.partner?.anniversary_date,
          love_language: response?.data?.partner?.love_language,
        } as Partner);
        router.push("/success?type=account_updated");
      }
    } catch (error: any) {
      const message =
        error.response?.data?.message ??
        error.response?.data?.error ??
        error.response?.data?.detail ??
        error.message;
      if (isAxiosError(error)) {
        showToast(message || "Failed to update account", "error", "top");
      } else {
        showToast("Failed to update account", "error", "top");
      }
    }
  };

  const { datePickerModal, closeDatePickerModal, openDatePickerModal } =
    useModalStore();

  const { isSm } = useResponsive();
  const px = rs(isSm, space[4], space[6]);
  const hasPartner = !!(partner || user?.partner);

  const loveLanguageModalRef = useRef<BottomSheetModal>(null);
  const openLoveLanguageModal = () => loveLanguageModalRef.current?.present();
  const closeLoveLanguageModal = () => loveLanguageModalRef.current?.dismiss();

  return (
    <MainLayout>
      <Header title="My Account" />

      <Formik
        initialValues={{
          full_name: user?.full_name || "",
          email: user?.email_address || "",
          partner_name:
            partner?.partner_name || user?.partner?.partner_name || "",
          partner_birthday:
            partner?.partner_birthday?.split("T")[0] ||
            user?.partner?.partner_birthday?.split("T")[0] ||
            "",
          anniversary_date:
            partner?.anniversary_date?.split("T")[0] ||
            user?.partner?.anniversary_date?.split("T")[0] ||
            "",
          love_language:
            partner?.love_language || user?.partner?.love_language || [],
        }}
        onSubmit={(values) => handleSubmit(values)}
        validationSchema={
          hasPartner ? editAccountSchema : editAccountNoPartnerSchema
        }
      >
        {({ values, setFieldValue, isSubmitting }) => (
          <ScrollView
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
            scrollEventThrottle={16}
            contentContainerStyle={styles.scroll}
          >
            <DatePickerModal
              isVisible={
                (datePickerModal.isVisible &&
                  datePickerModal.context === "partnerBirthday") ||
                (datePickerModal.isVisible &&
                  datePickerModal.context === "anniversary")
              }
              onClose={closeDatePickerModal}
              onSelect={(formatted: string) =>
                setFieldValue(
                  datePickerModal.context === "partnerBirthday"
                    ? "partner_birthday"
                    : datePickerModal.context === "anniversary"
                      ? "anniversary_date"
                      : "",
                  formatted,
                )
              }
              value={
                datePickerModal.context === "partnerBirthday"
                  ? values["partner_birthday"]
                  : datePickerModal.context === "anniversary"
                    ? values["anniversary_date"]
                    : ""
              }
            />
            <LoveLanguageModal
              ref={loveLanguageModalRef}
              onClose={closeLoveLanguageModal}
              selectedLanguages={values["love_language"]}
              handleSelectLoveLanguage={(language: string) => {
                const current = values["love_language"] || [];
                const exists = current.includes(language);
                const next = exists
                  ? current.filter((l) => l !== language)
                  : [...current, language];
                setFieldValue("love_language", next);
              }}
              onSave={closeLoveLanguageModal}
            />

            <View
              style={[
                styles.fill,
                { paddingVertical: rs(isSm, space[4], space[6]) },
              ]}
            >
              <View style={[styles.section, { paddingHorizontal: px }]}>
                <AppText
                  size="base"
                  weight="semibold"
                  color={PRIMARY}
                  style={styles.sectionTitle}
                >
                  Personal Info
                </AppText>

                <Input name="full_name" label="Full Name" />

                <Input name="email" label="Email Address" disabled={true} />

                <TouchableOpacity
                  style={styles.chip}
                  onPress={() => router.push("/profile/account/password")}
                  accessibilityRole="link"
                  hitSlop={hit.pill}
                >
                  <AppText size="xs" color={PRIMARY}>
                    Update Password?
                  </AppText>
                </TouchableOpacity>
              </View>

              {hasPartner && (
                <View style={{ paddingHorizontal: px }}>
                  <AppText
                    size="base"
                    weight="semibold"
                    color={PRIMARY}
                    style={styles.sectionTitle}
                  >
                    Partner Info
                  </AppText>

                  <Input name="partner_name" label="Name" />

                  <Select
                    name="partner_birthday"
                    label="Partner's Birthday"
                    onPress={() => openDatePickerModal("partnerBirthday")}
                    value={
                      values["partner_birthday"]
                        ? formatDate(values["partner_birthday"])
                        : ""
                    }
                    icon={<Feather name="calendar" size={20} color={PRIMARY} />}
                    placeholder="Select Partner's Birthday"
                  />
                  <Select
                    name="anniversary_date"
                    label="Anniversary"
                    onPress={() => openDatePickerModal("anniversary")}
                    value={
                      values["anniversary_date"]
                        ? formatDate(values["anniversary_date"])
                        : ""
                    }
                    icon={<Feather name="calendar" size={20} color={PRIMARY} />}
                    placeholder="Select Anniversary"
                  />
                  <Select
                    name="love_language"
                    label="Love Language"
                    onPress={openLoveLanguageModal}
                    value={((): string => {
                      const selected = values["love_language"] || [];
                      if (selected.length === 0) return "";
                      if (selected.length === 1) return selected[0];
                      return `${selected[0]?.replace("_", " ")} + ${selected.length - 1} others`;
                    })()}
                  />
                </View>
              )}
            </View>

            <View style={{ paddingHorizontal: px }}>
              <Submit title="Update" loading={isSubmitting} />
            </View>
          </ScrollView>
        )}
      </Formik>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1 },
  // `mb-8 pb-8 border-b border-primary/10`
  section: {
    marginBottom: space[8],
    paddingBottom: space[8],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  sectionTitle: { marginBottom: space[6] },
  // `border border-white-08 rounded-2xl py-1.5 px-4 self-start bg-white-08`
  chip: {
    alignSelf: "flex-start",
    borderWidth: 1,
    borderColor: WHITE_08,
    backgroundColor: WHITE_08,
    borderRadius: radii["2xl"],
    paddingVertical: space[1.5],
    paddingHorizontal: space[4],
  },
});

export default EditAccount;
