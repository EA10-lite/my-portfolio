import { Header, Input, Submit } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { useToastStore } from "@/src/stores/toastStore";
import { useGutter } from "@/src/theme";
import { Formik } from "formik";
import { ScrollView, StyleSheet, View } from "react-native";

import account from "@/src/services/account";
import { editPasswordSchema } from "@/src/utils/validations";
import { isAxiosError } from "axios";
import { router } from "expo-router";


type EditPasswordFormValues = {
    oldPassword: string;
    newPassword: string;
    confirmPassword: string;
}


const EditPassword = () => {
    const { showToast } = useToastStore();
    const px = useGutter();

    const handleSubmit = async (values: EditPasswordFormValues) => {
        try {
            const response = await account.updatePassword({
                current_password: values.oldPassword,
                new_password: values.newPassword,
            })
            if(response.status === 200 || response.status === 201) {
                router.push("/success?type=password_updated");
            }
        } catch (error: any) {
            if(isAxiosError(error)) {
                showToast(error.response?.data?.message, "error", "top");
            }
            else {
                showToast("An unexpected error occurred during Password Update", "error", "top");
            }
            console.log(error);
        }
    }

    return (
        <MainLayout>
            <Header title="Update Password" />


            <Formik
                initialValues={{
                    oldPassword: "",
                    newPassword: "",
                    confirmPassword: "",
                }}
                onSubmit={(values)=> handleSubmit(values)}
                validationSchema={editPasswordSchema}
            >
                {({ isSubmitting })=> (
                    <ScrollView
                        showsVerticalScrollIndicator={false}
                        keyboardShouldPersistTaps="handled"
                        removeClippedSubviews={true}
                        contentContainerStyle={styles.scroll}
                    >
                        <View style={[styles.fill, { padding: px }]}>
                            <Input
                                name="oldPassword"
                                label="Old Password"
                                isSecureText={true}
                                isPassword
                            />

                            <Input
                                name="newPassword"
                                label="New Password"
                                isSecureText={true}
                                isPassword
                            />

                            <Input
                                name="confirmPassword"
                                label="Confirm Password"
                                isSecureText={true}
                                isPassword
                            />
                        </View>

                        <View style={{ paddingHorizontal: px }}>
                            <Submit title="Update" loading={isSubmitting} />
                        </View>
                    </ScrollView>
                )}
            </Formik>
        </MainLayout>
    )
}

const styles = StyleSheet.create({
    fill: { flex: 1 },
    scroll: { flexGrow: 1 },
});

export default EditPassword;