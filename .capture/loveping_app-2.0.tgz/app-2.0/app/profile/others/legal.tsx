import { AppText, Header } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import {
  GREY_90,
  PRIMARY,
  PRIMARY_1A,
  WHITE_08,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { useState } from "react";
import { ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";

type TermType = {
    title: string;
    content: string | string[];
}

const terms: TermType[] = [
    {
        title: "Acceptance of Terms",
        content: "By using Loveping, you agree to these Terms of Service. If you do not agree, please do not use the app."
    },
    {
        title: "Eligibility",
        content: "You must be at least 16 years old to use Loveping."
    },
    {
        title: "Use of the App",
        content: [
            "Loveping is designed to help couples connect through nudges, gifts, and shared moments.",
            "You agree not to misuse the app for spam, harassment, or harmful behavior."
        ]
    },
    {
        title: "Content",
        content: [
            "You are responsible for the messages and content you create or save in Loveping.",
            "We do not share your private notes, history, or saved content with others."
        ]
    },
    {
        title: "Purchases & Gifts",
        content: [
            "Some gift suggestions may link to third-party stores. Loveping is not responsible for transactions outside the app."
        ]
    },
    {
        title: "Termination",
        content: "We may suspend accounts that misuse the app, violate these terms, or cause harm to others."
    },
    {
        title: "Changes to Terms",
        content: "We may update these Terms from time to time. Continued use means you accept the latest version."
    }
]


const Legal = () => {
  const [activeTab, setActiveTab] = useState<string | null>("terms");
  const { isSm } = useResponsive();

  return (
    <MainLayout>
      <Header title="Legal" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View
          style={[
            styles.fill,
            {
              padding: rs(isSm, space[4], space[6]),
              gap: rs(isSm, space[4], space[6]),
            },
          ]}
        >
          <TouchableOpacity
            onPress={() => setActiveTab(activeTab === "terms" ? null : "terms")}
            accessibilityRole="button"
            accessibilityState={{ expanded: activeTab === "terms" }}
          >
            <View style={styles.card}>
              <View
                style={[styles.header, activeTab === "terms" && styles.headerOpen]}
              >
                <AppText size="sm" weight="medium" color={PRIMARY}>
                  Terms & Conditions
                </AppText>
              </View>

              {activeTab === "terms" && (
                <View style={{ padding: rs(isSm, space[4], space[5]) }}>
                  {terms.map((term: TermType, index) => (
                    <View key={index} style={styles.term}>
                      <AppText size="sm" weight="medium" style={styles.termTitle}>
                        {term.title}
                      </AppText>
                      {term.content instanceof Array ? (
                        term.content.map((content: string, index: number) => (
                          // Was `ext-xs` (typo), so bullets rendered at 14px.
                          <AppText
                            key={index}
                            size="xs"
                            weight="medium"
                            color={GREY_90}
                            style={[styles.body, styles.bullet]}
                          >
                            {" "}
                            • {content}
                          </AppText>
                        ))
                      ) : (
                        <AppText
                          size="xs"
                          weight="medium"
                          color={GREY_90}
                          style={styles.body}
                        >
                          {term.content}
                        </AppText>
                      )}
                    </View>
                  ))}
                </View>
              )}
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() =>
              setActiveTab(activeTab === "privacy" ? null : "privacy")
            }
            accessibilityRole="button"
            accessibilityState={{ expanded: activeTab === "privacy" }}
          >
            <View style={styles.card}>
              <View
                style={[
                  styles.header,
                  activeTab === "privacy" && styles.headerOpen,
                ]}
              >
                <AppText size="sm" weight="medium" color={PRIMARY}>
                  Privacy Policy
                </AppText>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  // `border border-primary-1A rounded-md bg-white-08`
  card: {
    borderWidth: 1,
    borderColor: PRIMARY_1A,
    borderRadius: radii.md,
    backgroundColor: WHITE_08,
  },
  header: {
    padding: space[5],
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerOpen: { borderBottomWidth: 1, borderBottomColor: PRIMARY_1A },
  term: { marginBottom: space[4] },
  termTitle: { marginBottom: space[1.5] },
  body: { lineHeight: 18 },
  bullet: { marginBottom: space[1.5] },
});

export default Legal;
