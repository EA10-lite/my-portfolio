import Logo from "@/assets/icons/logo.svg";
import { AppText, Header } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import {
  GREY_90,
  PRIMARY,
  WHITE_08,
  WHITE_80,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import Constants from "expo-constants";
import { StyleSheet, View } from "react-native";

const About = () => {
  const { isSm } = useResponsive();
  const cardStyle = [styles.card, { padding: rs(isSm, space[4], space[5]) }];
  const gap = { marginBottom: rs(isSm, space[6], space[8]) };

  return (
    <MainLayout>
      <Header title="About Loveping" />

      <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
        <View style={styles.fill}>
          <AppText size={isSm ? "sm" : "xs"} color={WHITE_80} italic style={gap}>
            Built to help couples stay intentional about love
          </AppText>

          <View style={[cardStyle, gap]}>
            <AppText size="sm" weight="medium" color={PRIMARY} style={styles.cardTitle}>
              Our Story
            </AppText>
            <AppText size="xs" weight="medium" color={GREY_90} style={styles.body}>
              Loveping was built to help couples stay intentional about love. We
              believe little nudges — a kind word, a thoughtful gift, a sweet
              reminder — can keep relationships strong and joyful.
            </AppText>
          </View>

          <View style={[cardStyle, gap]}>
            <AppText size="sm" weight="medium" color={PRIMARY} style={styles.cardTitle}>
              Our Message
            </AppText>
            <AppText size="xs" weight="medium" color={GREY_90} style={styles.body}>
              Loveping isn&apos;t just an app — it&apos;s a companion for love.
              Every feature is designed to make connecting with your partner
              simple, meaningful, and heartfelt.
            </AppText>
          </View>

          <View style={cardStyle}>
            <AppText size="sm" weight="medium" color={PRIMARY} style={styles.cardTitle}>
              Version
            </AppText>
            <AppText size="xs" weight="medium" color={GREY_90} style={styles.body}>
              App version: v{Constants.expoConfig?.version}
            </AppText>
          </View>
        </View>

        <View style={styles.logo} accessibilityRole="image" accessibilityLabel="Loveping">
          <Logo />
        </View>
      </View>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  // `bg-white-08 rounded-md`
  card: { backgroundColor: WHITE_08, borderRadius: radii.md },
  cardTitle: { marginBottom: space[2] },
  body: { lineHeight: 18 },
  logo: { flexDirection: "row", justifyContent: "center" },
});

export default About;
