import { Header, MenuItem, MenuList } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { Feather } from "@expo/vector-icons";

import { router } from "expo-router";

import LegalIcon from '@/assets/icons/legal.svg';
import ShareIcon from '@/assets/icons/share-alt.svg';
import StarIcon from '@/assets/icons/star.svg';

const OthersItems: MenuItem[] = [
    {
        id: 1,
        title: "Rate us",
        description: "Enjoying Loveping? Leave us a review",
        icon: <StarIcon width={20} height={20} />,
        iconBgColor: "#D7BA381A",
        iconBorderColor: "#D7BA381A",
        onPress: () => {},
    },
    {
        id: 2,
        title: "Share Loveping",
        description: "Invite your friends to spread the love",
        icon: <ShareIcon width={20} height={20} />,
        iconBgColor: "#FA55DB1A",
        iconBorderColor: "#FA55DB1A",
        onPress: () => {},
    },
    {
        id: 3,
        title: "About Loveping",
        description: "Learn more about Loveping and our mission",
        icon: <Feather name="info" size={20} color="#8C65FF" />,
        iconBgColor: "#8C65FF1A",
        iconBorderColor: "#8C65FF1A",
        onPress: () => router.push("/profile/others/about"),
    },
    {
        id: 4,
        title: "Legal",
        description: "Read our terms and privacy policy",
        icon: <LegalIcon width={20} height={20} />,
        iconBgColor: "#F27A1F1A",
        iconBorderColor: "#F27A1F1A",
        onPress: () => router.push("/profile/others/legal"),
    },
]


const Others = () => {
  return (
    <MainLayout>
      <Header title="App Others" />
      <MenuList items={OthersItems} />
    </MainLayout>
  );
};

export default Others;