import { GiftCard, Header } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { space, useGutter } from "@/src/theme";
import { ScrollView, StyleSheet, View } from "react-native";

import Bracelet from "@/assets/gifts/bracelet.svg";
import FlowerBouquet from "@/assets/gifts/flower.svg";

// NOTE: placeholder data; not yet wired to the gift store (see plan, B16).
const suggestions = [
  {
    id: 1,
    title: "Boxes of chocolates",
    icon: <Bracelet />,
  },
  {
    id: 2,
    title: "Flowers",
    icon: <FlowerBouquet />,
  },
];

const Wishlists = () => {
  const px = useGutter();
  return (
    <MainLayout>
      <Header title="Saved Gifts" />

      <View style={[styles.fill, { padding: px }]}>
        <ScrollView
          style={styles.fill}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.scroll}
        >
          <View style={styles.list}>
            {suggestions.map((suggestion) => (
              <GiftCard
                key={suggestion.id}
                title={suggestion.title}
                icon={suggestion.icon}
                isSaved={true}
              />
            ))}
          </View>
        </ScrollView>
      </View>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { paddingBottom: 120 },
  list: { flex: 1, gap: space[6] },
});

export default Wishlists;
