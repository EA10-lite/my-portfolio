import { Header, MenuItem, MenuList } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { Feather } from "@expo/vector-icons";

import FileIcon from '@/assets/icons/file-alt.svg';
import SaveIcon from '@/assets/icons/save-alt.svg';
import { PINK_DARK_1A, PURPLE_LIGHT_1A, YELLOW, YELLOW_1A } from "@/src/constants/colors";
import { router } from "expo-router";

const contentItems: MenuItem[] = [
    {
        id: 1,
        title: "Saved Messages",
        description: "View saved nudges and custom notes",
        icon: <SaveIcon width={20} height={20} />,
        iconBgColor: PINK_DARK_1A,
        iconBorderColor: PINK_DARK_1A,
        onPress: () => router.push("/profile/content/saved"),
    },
    {
        id: 5,
        title: "Wishlist Gifts",
        description: "View gifts you've saved for later",
        icon: <Feather name="gift" size={20} color={YELLOW} />,
        iconBgColor: YELLOW_1A,
        iconBorderColor: YELLOW_1A,
        onPress: () => router.push("/profile/content/wishlists"),
    },
    {
        id: 2,
        title: "History",
        description: "View nudges and gifts you've used before",
        icon: <FileIcon width={20} height={20} />,
        iconBgColor: PURPLE_LIGHT_1A,
        iconBorderColor: PURPLE_LIGHT_1A,
        onPress: () => router.push("/profile/content/history"),
    },
]


const Content = () => {
  return (
    <MainLayout>
      <Header title="My Content" />
      <MenuList items={contentItems} />
    </MainLayout>
  );
};

export default Content;