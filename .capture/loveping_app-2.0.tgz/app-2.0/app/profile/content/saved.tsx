import SaveIcon from "@/assets/icons/save.svg";
import {
  AppText,
  Empty,
  Header,
  MessageCard,
  MessageCardSkeleton,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import ping from "@/src/services/ping";
import { ERROR, rs, space, useResponsive } from "@/src/theme";
import { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import useSWR from "swr";

type Nudge = {
  _id: string;
  message: string;
  tones: string[];
  isSaved: boolean;
};

const Saved = () => {
  const [isOpen, setIsOpen] = useState<number | null>(0);
  const { isSm } = useResponsive();

  const { data, isLoading, error, mutate } = useSWR(
    "/ping/all",
    ping.getAllPing,
    {
      revalidateOnFocus: true,
      revalidateOnMount: true,
      dedupingInterval: 0,
    },
  );

  const handleChange = () => {
    mutate();
  };

  const saved: Nudge[] =
    data?.data?.filter((nudge: Nudge) => nudge.isSaved) ?? [];

  return (
    <MainLayout>
      <Header title="Saved Messages" />

      {error ? (
        // Header stays visible so the user can go back (the old error
        // screen had no way out).
        <View style={styles.fill}>
          <AppText size="lg" color={ERROR} align="center">
            Error
          </AppText>
        </View>
      ) : isLoading ? (
        <MessageCardSkeleton />
      ) : saved.length === 0 ? (
        <Empty
          icon={<SaveIcon width={24} height={24} />}
          description="No saved messages yet"
        />
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          removeClippedSubviews={true}
          contentContainerStyle={styles.scroll}
          style={{
            paddingHorizontal: rs(isSm, space[4], space[6]),
            paddingTop: rs(isSm, space[4], space[6]),
          }}
        >
          <View style={[styles.fill, { gap: rs(isSm, space[4], space[5]) }]}>
            {saved.map((item, index) => (
              <MessageCard
                key={item._id ?? index}
                message={item.message}
                tones={item.tones}
                onPress={() => setIsOpen(index === isOpen ? null : index)}
                isOpen={isOpen === index}
                isSaved={true}
                id={item._id}
                onChange={handleChange}
              />
            ))}
          </View>
        </ScrollView>
      )}
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1, paddingBottom: 120 },
});

export default Saved;
