import HistoryIcon from "@/assets/icons/file-primary.svg";
import {
  AppText,
  Empty,
  Header,
  MessageCard,
  MessageCardSkeleton,
} from "@/src/components";
import { MainLayout } from "@/src/layouts";
import ping from "@/src/services/ping";
import { ERROR, rs, space, useResponsive } from "@/src/theme";
import { useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import useSWR from "swr";

type Nudge = {
  _id: string;
  message: string;
  tones: string[];
  isSaved?: boolean;
  status?: "delivered" | "pending" | "failed";
  updatedAt?: string;
};

const History = () => {
  const [isOpen, setIsOpen] = useState<number | null>(0);
  const { isSm } = useResponsive();

  const { data, isLoading, error, mutate } = useSWR(
    "/ping/all",
    ping.getAllPing,
    {
      revalidateOnFocus: true,
      revalidateOnMount: true,
      dedupingInterval: 0,
    },
  );

  const handleChange = () => {
    mutate();
  };

  const delivered: Nudge[] =
    data?.data?.filter((nudge: Nudge) => nudge?.status === "delivered") ?? [];

  return (
    <MainLayout>
      <Header title="History" />

      {error ? (
        // Header stays visible so the user can go back (the old error
        // screen had no way out).
        <View style={styles.fill}>
          <AppText size="lg" color={ERROR} align="center">
            Error
          </AppText>
        </View>
      ) : isLoading ? (
        <MessageCardSkeleton />
      ) : delivered.length === 0 ? (
        <Empty
          icon={<HistoryIcon width={24} height={24} />}
          description="Your history is empty"
        />
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          removeClippedSubviews={true}
          contentContainerStyle={styles.scroll}
          style={{
            paddingHorizontal: rs(isSm, space[4], space[6]),
            paddingTop: rs(isSm, space[4], space[6]),
          }}
        >
          <View style={[styles.fill, { gap: rs(isSm, space[4], space[5]) }]}>
            {delivered.map((item, index) => (
              <MessageCard
                key={item._id ?? index}
                message={item.message}
                tones={item.tones}
                onPress={() => setIsOpen(index === isOpen ? null : index)}
                isOpen={isOpen === index}
                isSaved={true}
                id={item._id}
                onChange={handleChange}
                timestamp={item?.updatedAt}
              />
            ))}
          </View>
        </ScrollView>
      )}
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1, paddingBottom: 120 },
});

export default History;
