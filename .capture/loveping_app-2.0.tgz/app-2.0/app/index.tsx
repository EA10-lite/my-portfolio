import WelcomScreen from "@/src/screens/home/WelcomScreen";
import { useStoreHydrated } from "@/src/hooks/useStoreHydrated";
import { useUserStore } from "@/src/stores/userStore";
import { SECONDARY } from "@/src/theme";
import { isPinEnabled } from "@/src/utils/pinStorage";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Href, Redirect } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect, useRef, useState } from "react";
import { StyleSheet, View } from "react-native";

type BootDecision = { welcome: true } | { welcome: false; target: Href };

/**
 * Boot route. The native splash stays on screen (see `app/_layout.tsx`)
 * until we know where to send the user, then hides with no extra delay.
 *
 * - First launch: Welcome screen, then onboarding.
 * - Not onboarded: onboarding.
 * - Logged out: get started.
 * - PIN set: PIN screen. Otherwise: tabs.
 */
export default function Index() {
  const hydrated = useStoreHydrated(useUserStore);
  const isLoggedIn = useUserStore((state) => state.isLoggedIn);
  const [decision, setDecision] = useState<BootDecision | null>(null);
  const decided = useRef(false);

  useEffect(() => {
    // Wait for the persisted user store so `isLoggedIn` is the saved value,
    // and decide exactly once (the old splash could navigate twice).
    if (!hydrated || decided.current) return;
    decided.current = true;

    const decide = async (): Promise<BootDecision> => {
      try {
        const hasSeenWelcome = await AsyncStorage.getItem(
          "loveping-has-seen-welcome",
        );
        if (hasSeenWelcome === null) return { welcome: true };
      } catch (error) {
        console.error("Error checking first launch:", error);
      }

      const isOnboarded = await AsyncStorage.getItem("loveping-isOnboarded");
      if (!isOnboarded) return { welcome: false, target: "/onboarding" };
      if (!isLoggedIn) return { welcome: false, target: "/auth/get-started" };

      const pinEnabled = await isPinEnabled();
      return { welcome: false, target: pinEnabled ? "/auth/pin" : "/(tabs)" };
    };

    decide()
      .catch(
        (error): BootDecision => {
          console.error("Boot routing failed:", error);
          return { welcome: false, target: "/onboarding" };
        },
      )
      .then(setDecision);
  }, [hydrated, isLoggedIn]);

  useEffect(() => {
    if (decision) {
      SplashScreen.hideAsync().catch(() => {
        // Already hidden or not available (e.g. web).
      });
    }
  }, [decision]);

  if (!decision) return <View style={styles.screen} />;
  if (decision.welcome) return <WelcomScreen />;
  return <Redirect href={decision.target} />;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: SECONDARY },
});
