import Logo from "@/assets/icons/logo.svg";
import { AppText, Button } from "@/src/components";
import { usePushNotifications } from "@/src/context/PushNotificationProvider";
import auth from "@/src/services/auth";
import { useToastStore, useUserStore } from "@/src/stores";
import {
  PRIMARY,
  SECONDARY,
  gutter,
  rs,
  space,
  useResponsive,
  hit,
} from "@/src/theme";
import { saveRefreshToken, saveToken } from "@/src/utils";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { isAxiosError } from "axios";
import { router } from "expo-router";
import { useState } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const Onboarding = () => {
  const { expoPushToken } = usePushNotifications();
  const { showToast } = useToastStore();
  const { setUser } = useUserStore();
  const insets = useSafeAreaInsets();
  const { isSm } = useResponsive();

  const handleGetStarted = async () => {
    await AsyncStorage.setItem("loveping-isOnboarded", "true");
    router.push("/auth/get-started");
  };

  const [loading, setLoading] = useState<boolean>(false);
  const handleContinueAsGuest = async () => {
    try {
      setLoading(true);
      const response = await auth.signupAsGuest({
        notification_token: expoPushToken ?? "",
      });
      // Await both so the first API call after this has the token.
      await saveToken(response.data.token);
      if (response.data.refresh_token) {
        await saveRefreshToken(response.data.refresh_token);
      }
      setUser({
        ...response.data.user,
        is_guest: true,
      });
      AsyncStorage.setItem("loveping-isOnboarded", "true");
      router.push("/auth/complete-account-setup");
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An unexpected error occurred during Login", "error", "top");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <View
      style={[
        styles.screen,
        {
          paddingHorizontal: rs(isSm, gutter.base, gutter.sm),
          paddingTop: insets.top + 16,
          paddingBottom: insets.bottom + 16,
        },
      ]}
    >
      <View
        style={styles.center}
        accessibilityRole="image"
        accessibilityLabel="Loveping"
      >
        <Logo />
      </View>

      <View style={styles.hero}>
        <AppText size="2xl" weight="semibold" color={PRIMARY}>
          Welcome to Loveping
        </AppText>
        <AppText size="sm" weight="medium" style={styles.subtitle}>
          Your gentle reminder to keep the spark alive
        </AppText>
      </View>

      <View>
        <Button
          title="Get started"
          onPress={handleGetStarted}
          variant="primary"
          disabled={loading}
          size="lg"
        />

        <TouchableOpacity
          onPress={handleContinueAsGuest}
          style={styles.guest}
          disabled={loading}
          accessibilityRole="button"
          accessibilityState={{ busy: loading }}
          hitSlop={hit.text}
        >
          <AppText size="sm" weight="medium" align="center">
            {loading ? "Loading..." : "Continue as Guests"}
          </AppText>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: SECONDARY },
  center: { alignItems: "center", justifyContent: "center" },
  hero: { flex: 1, alignItems: "center", justifyContent: "center" },
  subtitle: { marginTop: space[1] },
  guest: { marginTop: space[4] },
});

export default Onboarding;
