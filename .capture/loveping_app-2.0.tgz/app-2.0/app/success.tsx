import { AppText, Button } from "@/src/components";
import {
  getSuccessConfig,
  handleSuccessAction,
  SuccessType,
} from "@/src/config/successConfigs";
import { MainLayout } from "@/src/layouts";
import { WHITE_80, space, hit } from "@/src/theme";
import { useLocalSearchParams } from "expo-router";
import { StyleSheet, TouchableOpacity, View } from "react-native";

/**
 * Success route component
 * Displays success screens based on the type query parameter
 *
 * Usage:
 * router.push("/success?type=password_reset")
 * router.push({ pathname: "/success", params: { type: "account_updated" } })
 */
const Success = () => {
  // Get the type from query parameters
  const { type } = useLocalSearchParams<{ type: string }>();

  // Get the configuration for this success type
  const config = type ? getSuccessConfig(type as SuccessType) : undefined;

  // Fallback configuration if type is missing or invalid
  if (!config) {
    return (
      <MainLayout>
        <View style={styles.invalid}>
          <AppText size="xl" weight="semibold" align="center" style={styles.title}>
            Invalid Success Type
          </AppText>
          <AppText
            size="sm"
            weight="medium"
            color={WHITE_80}
            align="center"
            style={styles.invalidText}
          >
            The success type &quot;{type}&quot; is not recognized.
          </AppText>
          <Button
            title="Go Back"
            onPress={() => handleSuccessAction("back")}
            variant="primary"
            size="lg"
          />
        </View>
      </MainLayout>
    );
  }

  // Extract configuration values with defaults
  const {
    title,
    subtitle,
    icon,
    buttonText = "Continue",
    secondaryButtonText,
    width = 80,
    onPressAction,
    onSecondaryPressAction,
    nextSuccessType,
    nextSuccessTypeSecondary,
  } = config;

  // Handle primary button press
  const handlePrimaryPress = () => {
    handleSuccessAction(onPressAction, nextSuccessType);
  };

  // Handle secondary button press
  const handleSecondaryPress = () => {
    handleSuccessAction(
      onSecondaryPressAction || onPressAction,
      nextSuccessTypeSecondary || nextSuccessType,
    );
  };

  return (
    <MainLayout>
      <View style={styles.fill}>
        <View style={styles.hero}>
          {icon && icon}
          <View style={[styles.copy, { maxWidth: `${width}%` }]}>
            <AppText
              size="xl"
              weight="semibold"
              align="center"
              style={styles.title}
              accessibilityRole="header"
            >
              {title}
            </AppText>
            {subtitle && (
              <AppText size="sm" weight="medium" color={WHITE_80} align="center">
                {subtitle}
              </AppText>
            )}
          </View>
        </View>

        <View style={styles.actions}>
          <Button
            title={buttonText}
            onPress={handlePrimaryPress}
            variant="primary"
            size="lg"
          />
          {secondaryButtonText && (
            <TouchableOpacity
              onPress={handleSecondaryPress}
              accessibilityRole="button"
              hitSlop={hit.text}
            >
              <AppText size="sm" weight="medium" align="center">
                {secondaryButtonText}
              </AppText>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  hero: { flex: 1, justifyContent: "center", alignItems: "center" },
  copy: { alignSelf: "center" },
  // `text-[20px] font-semibold mb-1.5` (20px with the default line height)
  title: { fontSize: 20, lineHeight: 24, marginBottom: space[1.5] },
  actions: { gap: space[4], paddingHorizontal: space[6] },
  invalid: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: space[6],
  },
  invalidText: { marginBottom: space[6] },
});

export default Success;
