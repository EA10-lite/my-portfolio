import Constants from "expo-constants";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";

import ErrorBoundary from "@/src/components/ErrorBoundary";
import { RequiredUpdateScreen, useUpdateCheck } from "@/src/features/appUpdate";
import { SECONDARY, fontAssets } from "@/src/theme";
import PushNotificationProvider from "@/src/context/PushNotificationProvider";
import { addBreadcrumb, initCrashLogger } from "@/src/services/crashLogger";
// Registers the "session expired" handler with the API client.
import "@/src/services/session";
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet";
import { useUserStore } from "@/src/stores/userStore";
import { useStoreHydrated } from "@/src/hooks/useStoreHydrated";
import { router, Stack, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";

// Keep the native splash up until fonts are loaded and `app/index.tsx` has
// decided where to send the user; it hides the splash itself.
SplashScreen.preventAutoHideAsync().catch(() => {});
SplashScreen.setOptions({ duration: 250, fade: true });

/** [route name, title] */
const PUBLIC_SCREENS = [
  ["index", "Home"],
  ["onboarding", "Onboarding"],
  ["auth/get-started", "Get started"],
  ["auth/signin", "Sign in"],
  ["auth/signup", "Sign up"],
  ["auth/verify-email", "Verify email"],
  ["auth/forgot-password", "Forgot password"],
  ["auth/complete-account-setup", "Complete Account Setup"],
  ["auth/pin", "PIN"],
  ["success", "Success"],
] as const;

const PRIVATE_SCREENS = [
  ["(tabs)", "Home"],
  ["notification", "Notifications"],
  ["search", "Search"],
  ["messages/new", "New Message"],
  ["messages/edit", "Edit Message"],
  ["nudge/text", "Text Nudge"],
  ["nudge/call", "Call Nudge"],
  ["nudge/gift", "Gift Nudge"],
  ["nudge/edit", "Edit Nudge"],
  ["profile/account/index", "Account"],
  ["profile/account/password", "Password"],
  ["profile/content/index", "Content"],
  ["profile/content/saved", "Saved"],
  ["profile/content/wishlists", "Wishlist"],
  ["profile/content/history", "History"],
  ["profile/others/index", "Others"],
  ["profile/others/about", "About"],
  ["profile/others/legal", "Legal"],
  ["profile/settings/index", "Settings"],
  ["profile/settings/language", "Language"],
  ["profile/settings/notifications/index", "Notification settings"],
  ["profile/settings/notifications/nudge", "Nudge settings"],
  ["profile/settings/pin", "PIN settings"],
  ["profile/settings/privacy", "Privacy"],
  ["profile/support/index", "Support"],
  ["profile/support/contact", "Contact"],
  ["profile/support/faq", "FAQ"],
  ["profile/support/feedback", "Feedback"],
  ["profile/support/report", "Report"],
] as const;

/** Top-level route segments that need a session. */
const PRIVATE_ROOTS = new Set([
  "(tabs)",
  "notification",
  "search",
  "messages",
  "nudge",
  "profile",
]);

/**
 * Sends a logged-out user away from private screens: after sign-out or an
 * expired session, or when a deep link / notification opens a private screen
 * with no session. A redirect (rather than `Stack.Protected`) because the
 * auth screens set the user and navigate in the same tick; a guard would
 * still be `false` at that moment and drop the navigation.
 */
function useAuthGuard() {
  const hydrated = useStoreHydrated(useUserStore);
  const isLoggedIn = useUserStore((state) => state.isLoggedIn);
  const segments = useSegments();
  const onPrivateScreen = PRIVATE_ROOTS.has(segments[0] ?? "");

  useEffect(() => {
    if (hydrated && !isLoggedIn && onPrivateScreen) {
      router.replace("/auth/get-started");
    }
  }, [hydrated, isLoggedIn, onPrivateScreen]);
}

export default function RootLayout() {
  useAuthGuard();
  // Asks the backend for the latest/minimum version (launch + foreground).
  useUpdateCheck();
  // Inter, registered under the names the theme and old Tailwind classes use.
  const [fontsLoaded, fontError] = useFonts(fontAssets);

  // Initialize crash logging on app startup
  useEffect(() => {
    // Get Sentry DSN from environment variables or use a placeholder
    // You should set SENTRY_DSN in your .env file
    const sentryDsn =
      process.env.EXPO_PUBLIC_SENTRY_DSN ||
      Constants.expoConfig?.extra?.sentryDsn;
    const environment = __DEV__ ? "development" : "production";

    if (sentryDsn) {
      initCrashLogger(sentryDsn, environment);
      addBreadcrumb("App started", "lifecycle", "info");
    } else {
      // Log warning if Sentry DSN is not configured
      console.warn("Sentry DSN not configured. Crash logging will not work.");
      console.warn(
        "Please set EXPO_PUBLIC_SENTRY_DSN in your .env file or app.config.js",
      );
    }
  }, []);

  useEffect(() => {
    if (fontError) console.warn("Failed to load fonts:", fontError);
  }, [fontError]);

  // Native splash is still visible while fonts load (usually a few ms).
  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <PushNotificationProvider>
          <GestureHandlerRootView
            style={{ flex: 1, backgroundColor: SECONDARY }}
          >
            <BottomSheetModalProvider>
              <StatusBar style="light" />

              <Stack
                screenOptions={{
                  headerShown: false,
                  // Same background on every screen to prevent transition flicker.
                  contentStyle: { backgroundColor: SECONDARY },
                }}
              >
                {/* Public: boot, onboarding, auth, and the shared success page
                    (also used after a logged-out password reset). Guests and
                    full accounts are both "logged in"; guests upgrade via
                    auth/signup. */}
                {PUBLIC_SCREENS.map(([name, title]) => (
                  <Stack.Screen key={name} name={name} options={{ title }} />
                ))}

                {/* Private: see `useAuthGuard` below. */}
                {PRIVATE_SCREENS.map(([name, title]) => (
                  <Stack.Screen key={name} name={name} options={{ title }} />
                ))}
              </Stack>
              {/* Covers everything, logged in or not, when this version is
                  below the backend's minimum. */}
              <RequiredUpdateScreen />
            </BottomSheetModalProvider>
          </GestureHandlerRootView>
        </PushNotificationProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
