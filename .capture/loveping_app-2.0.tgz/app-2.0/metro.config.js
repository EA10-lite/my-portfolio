const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

// Import .svg files as React components (react-native-svg-transformer).
const { transformer, resolver } = config;

config.transformer = {
  ...transformer,
  babelTransformerPath: require.resolve("react-native-svg-transformer"),
};
config.resolver = {
  ...resolver,
  assetExts: resolver.assetExts.filter((ext) => ext !== "svg"),
  sourceExts: [...resolver.sourceExts, "svg"],
};

module.exports = config;
