import { Keyboard, Pressable, StyleSheet } from "react-native";
import {
  SafeAreaView,
  useSafeAreaInsets,
} from "react-native-safe-area-context";
import Toast from "../components/Toast";
import { useKeyboardVisible } from "../hooks/useKeyboardVisible";
import { SECONDARY } from "../theme";

interface MainLayoutProps {
  children: React.ReactNode;
  showBottomPadding?: boolean;
}

/** Page shell: top safe area, optional bottom inset, tap-to-dismiss keyboard, toast host. */
const MainLayout = ({
  children,
  showBottomPadding = true,
}: MainLayoutProps) => {
  const insets = useSafeAreaInsets();
  const keyboardVisible = useKeyboardVisible();
  return (
    <SafeAreaView
      edges={["top"]}
      style={[
        styles.screen,
        { paddingBottom: showBottomPadding ? insets.bottom : 0 },
      ]}
    >
      {/* Tap outside a field to close the keyboard. Disabled while the
          keyboard is closed: a disabled Pressable doesn't claim touches, so it
          no longer competes with scroll views for swipes. */}
      <Pressable
        style={styles.fill}
        onPress={Keyboard.dismiss}
        disabled={!keyboardVisible}
        accessible={false}
      >
        {children}
      </Pressable>
      <Toast />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: SECONDARY },
  fill: { flex: 1 },
});

export default MainLayout;
