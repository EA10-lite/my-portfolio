/**
 * Compares dotted versions numerically ("1.10.0" > "1.9.2").
 * Missing parts count as 0; anything after "-" or "+" is ignored.
 * Returns -1, 0 or 1.
 */
export const compareVersions = (a: string, b: string): number => {
  const parts = (v: string) =>
    v
      .split(/[-+]/)[0]
      .split(".")
      .map((n) => parseInt(n, 10) || 0);
  const pa = parts(a);
  const pb = parts(b);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
};

export const isValidVersion = (v: unknown): v is string =>
  typeof v === "string" && /^\d+(\.\d+){0,3}([-+].*)?$/.test(v.trim());
