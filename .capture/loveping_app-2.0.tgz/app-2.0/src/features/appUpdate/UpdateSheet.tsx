import { AppText, Button } from "@/src/components";
import CustomModal from "@/src/components/modals/CustomModal";
import { PRIMARY, WHITE_80, space } from "@/src/theme";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useEffect, useRef } from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useUpdateStore } from "./store";
import { AppIconTile, ReleaseNotes, pillStyle } from "./UpdateParts";
import { openStore } from "./useUpdateCheck";

/**
 * Optional-update bottom sheet. Opens once per new version when the user
 * reaches the tabs; after "Maybe later" the Home banner takes over.
 * Mount inside the tabs layout.
 */
const UpdateSheet = () => {
  const ref = useRef<BottomSheetModal>(null);
  const insets = useSafeAreaInsets();
  const status = useUpdateStore((s) => s.status);
  const info = useUpdateStore((s) => s.info);
  const seen = useUpdateStore((s) => s.sheetSeenVersion);
  const markSheetSeen = useUpdateStore((s) => s.markSheetSeen);
  const latest = info?.latestVersion;
  const shouldShow = status === "optional" && !!latest && seen !== latest;

  useEffect(() => {
    if (!shouldShow) return;
    // Let the tabs finish their first paint before sliding the sheet up.
    const t = setTimeout(() => ref.current?.present(), 600);
    return () => clearTimeout(t);
  }, [shouldShow]);

  const close = () => {
    if (latest) markSheetSeen(latest);
    ref.current?.dismiss();
  };

  const update = async () => {
    if (latest) markSheetSeen(latest);
    await openStore();
    ref.current?.dismiss();
  };

  return (
    <CustomModal ref={ref} onClose={() => latest && markSheetSeen(latest)}>
      <View style={[styles.body, { paddingBottom: insets.bottom + space[6] }]}>
        <View style={styles.icon}>
          <AppIconTile />
        </View>

        <View style={[pillStyle.pill, styles.pill]}>
          <AppText size="xs" weight="medium" color={PRIMARY}>
            {info?.size
              ? `Version ${latest} · ${info.size}`
              : `Version ${latest}`}
          </AppText>
        </View>

        <AppText
          size="xl"
          weight="semibold"
          align="center"
          accessibilityRole="header"
          style={styles.title}
        >
          A fresh update is here
        </AppText>
        <AppText
          size="sm"
          weight="medium"
          color={WHITE_80}
          align="center"
          style={styles.subtitle}
        >
          Update now to get the newest features and keep your nudges running
          smoothly.
        </AppText>

        <View style={styles.notes}>
          <ReleaseNotes notes={info?.releaseNotes ?? []} />
        </View>

        <View style={styles.actions}>
          <Button
            title="Update now"
            variant="primary"
            size="lg"
            onPress={update}
          />
          <Button
            title="Maybe later"
            variant="outline-secondary"
            size="lg"
            onPress={close}
          />
        </View>
      </View>
    </CustomModal>
  );
};

const styles = StyleSheet.create({
  body: {
    paddingHorizontal: space[6],
    paddingTop: space[5],
    alignItems: "center",
  },
  icon: { marginBottom: space[5] },
  pill: { marginBottom: space[3] },
  title: { marginBottom: space[1.5] },
  subtitle: { maxWidth: 290, marginBottom: space[6] },
  notes: { alignSelf: "stretch", marginBottom: space[6] },
  actions: { alignSelf: "stretch", gap: space[3] },
});

export default UpdateSheet;
