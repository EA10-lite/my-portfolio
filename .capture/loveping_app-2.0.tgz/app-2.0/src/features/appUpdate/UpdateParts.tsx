import { AppText } from "@/src/components";
import {
  PRIMARY,
  PRIMARY_14,
  PRIMARY_1A,
  WHITE_08,
  WHITE_80,
  radii,
  space,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { Image, StyleSheet, View } from "react-native";

const ICON = require("../../../assets/app-icon/icon.png");

/** The app icon on a rounded tile. */
export const AppIconTile = ({ size = 72 }: { size?: number }) => (
  <Image
    source={ICON}
    style={{ width: size, height: size, borderRadius: size * 0.28 }}
    accessibilityLabel="Loveping"
  />
);

/** "What's new" list from the backend's release notes. */
export const ReleaseNotes = ({ notes }: { notes: string[] }) =>
  notes.length ? (
    <View style={styles.notes}>
      <AppText
        size="xs"
        weight="semibold"
        color={WHITE_80}
        style={styles.notesTitle}
      >
        WHAT’S NEW
      </AppText>
      {notes.map((note) => (
        <View key={note} style={styles.noteRow}>
          <Feather
            name="check"
            size={18}
            color={PRIMARY}
            style={styles.check}
          />
          <AppText size="sm" weight="medium" style={styles.noteText}>
            {note}
          </AppText>
        </View>
      ))}
    </View>
  ) : null;

const styles = StyleSheet.create({
  // `bg-white-08 border border-primary-14 rounded-md p-4 gap-3`
  notes: {
    alignSelf: "stretch",
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    borderRadius: radii.md,
    padding: space[4],
    gap: space[3],
  },
  notesTitle: { letterSpacing: 0.5 },
  noteRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  check: { marginTop: 1 },
  noteText: { flex: 1 },
});

export const pillStyle = StyleSheet.create({
  pill: {
    paddingHorizontal: space[3],
    paddingVertical: space[1],
    borderRadius: radii["2xl"],
    backgroundColor: PRIMARY_1A,
  },
});
