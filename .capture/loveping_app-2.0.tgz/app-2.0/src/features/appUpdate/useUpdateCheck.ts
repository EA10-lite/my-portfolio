import { useEffect } from "react";
import { AppState, Linking } from "react-native";
import { fetchVersionInfo, statusFor, storeUrlFor } from "./service";
import { useUpdateStore } from "./store";

/** Re-check at most this often when the app comes back to the foreground. */
const RECHECK_MS = 6 * 60 * 60 * 1000;

const check = async () => {
  try {
    const info = await fetchVersionInfo();
    useUpdateStore.getState().setResult(info, statusFor(info));
  } catch {
    // Endpoint missing / offline: keep whatever we knew; never block the app
    // because the check failed.
  }
};

/**
 * Checks for an update at launch and whenever the app returns to the
 * foreground (throttled). Mount once, in the root layout.
 */
export const useUpdateCheck = () => {
  useEffect(() => {
    check();
    const sub = AppState.addEventListener("change", (state) => {
      if (state !== "active") return;
      const { lastCheckedAt, status } = useUpdateStore.getState();
      // While blocked, re-check every time: the user may just have updated.
      if (status === "required" || Date.now() - lastCheckedAt > RECHECK_MS)
        check();
    });
    return () => sub.remove();
  }, []);
};

/** Opens this app's store page. Returns false if no URL could be opened. */
export const openStore = async (): Promise<boolean> => {
  const url = storeUrlFor(useUpdateStore.getState().info);
  if (!url) return false;
  try {
    await Linking.openURL(url);
    return true;
  } catch {
    // market:// fails where there's no Play Store app: fall back to the web.
    if (url.startsWith("market://")) {
      await Linking.openURL(
        url.replace("market://", "https://play.google.com/store/apps/"),
      );
      return true;
    }
    return false;
  }
};
