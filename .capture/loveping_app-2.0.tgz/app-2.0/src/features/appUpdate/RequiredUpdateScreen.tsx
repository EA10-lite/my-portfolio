import { AppText, Button } from "@/src/components";
import {
  PRIMARY,
  PRIMARY_08,
  PRIMARY_14,
  PRIMARY_1A,
  SECONDARY,
  WHITE_08,
  WHITE_80,
  radii,
  space,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { BackHandler, Platform, StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { installedVersion } from "./service";
import { useUpdateStore } from "./store";
import { AppIconTile } from "./UpdateParts";
import { openStore } from "./useUpdateCheck";

/**
 * Full-screen block shown when the installed version is below the backend's
 * `min_version`. Covers every screen (rendered last in the root layout) and
 * swallows the Android back button; only "Update now" is offered.
 */
const RequiredUpdateScreen = () => {
  const status = useUpdateStore((s) => s.status);
  const info = useUpdateStore((s) => s.info);
  const insets = useSafeAreaInsets();
  const [opening, setOpening] = useState(false);
  const [failed, setFailed] = useState(false);
  const blocked = status === "required";

  useEffect(() => {
    if (!blocked) return;
    const sub = BackHandler.addEventListener("hardwareBackPress", () => true);
    return () => sub.remove();
  }, [blocked]);

  if (!blocked) return null;

  const handleUpdate = async () => {
    setOpening(true);
    setFailed(!(await openStore()));
    setOpening(false);
  };

  return (
    <View
      style={[
        StyleSheet.absoluteFill,
        styles.screen,
        {
          paddingTop: insets.top + space[14],
          paddingBottom: insets.bottom + space[8],
        },
      ]}
      accessibilityViewIsModal
    >
      <View style={styles.body}>
        <View style={styles.rings}>
          <View style={[StyleSheet.absoluteFill, styles.outerRing]} />
          <View style={styles.innerRing} />
          <AppIconTile size={64} />
        </View>

        <AppText
          size="2xl"
          weight="semibold"
          align="center"
          accessibilityRole="header"
          style={styles.title}
        >
          Time for an update
        </AppText>
        <AppText
          size="sm"
          weight="medium"
          color={WHITE_80}
          align="center"
          style={styles.subtitle}
        >
          This version of Loveping is no longer supported. Update to keep
          sending nudges and love notes.
        </AppText>

        <View style={styles.versions}>
          <View>
            <AppText size="xs" weight="medium" color={WHITE_80}>
              You have
            </AppText>
            <AppText size="base" weight="semibold">
              {installedVersion()}
            </AppText>
          </View>
          <Feather name="arrow-right" size={20} color={PRIMARY} />
          <View style={styles.right}>
            <AppText size="xs" weight="medium" color={WHITE_80}>
              Required
            </AppText>
            <AppText size="base" weight="semibold" color={PRIMARY}>
              {info?.minVersion}
            </AppText>
          </View>
        </View>
      </View>

      <View style={styles.footer}>
        <Button
          title="Update now"
          variant="primary"
          size="lg"
          loading={opening}
          onPress={handleUpdate}
          style={styles.button}
        />
        <AppText size="xs" weight="medium" color={WHITE_80} align="center">
          {failed
            ? `Couldn't open the store. Search for Loveping in the ${Platform.OS === "ios" ? "App Store" : "Play Store"}.`
            : `Opens the ${Platform.OS === "ios" ? "App Store" : "Play Store"}. Your notes and settings stay safe.`}
        </AppText>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: {
    backgroundColor: SECONDARY,
    paddingHorizontal: space[6],
    zIndex: 1000,
    elevation: 1000,
  },
  body: { flex: 1, alignItems: "center", justifyContent: "center" },
  rings: {
    width: 120,
    height: 120,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: space[8],
  },
  outerRing: {
    borderRadius: 60,
    borderWidth: 1,
    borderColor: PRIMARY_1A,
    backgroundColor: PRIMARY_08,
  },
  innerRing: {
    position: "absolute",
    top: 16,
    left: 16,
    right: 16,
    bottom: 16,
    borderRadius: 44,
    borderWidth: 1,
    borderColor: PRIMARY_14,
  },
  title: { marginBottom: space[2] },
  subtitle: { maxWidth: 300, marginBottom: space[7] },
  versions: {
    alignSelf: "stretch",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    borderRadius: radii.md,
    paddingVertical: space[4],
    paddingHorizontal: space[5],
  },
  right: { alignItems: "flex-end" },
  footer: { gap: space[4], alignItems: "center" },
  button: { alignSelf: "stretch" },
});

export default RequiredUpdateScreen;
