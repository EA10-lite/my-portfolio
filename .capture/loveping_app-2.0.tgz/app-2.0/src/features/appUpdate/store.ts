import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { UpdateStatus, VersionInfo } from "./service";

interface UpdateState {
  info: VersionInfo | null;
  status: UpdateStatus;
  lastCheckedAt: number;
  /** Latest version whose sheet was already shown (shown once per version). */
  sheetSeenVersion: string | null;
  /** Latest version whose Home banner was dismissed with the X. */
  bannerDismissedVersion: string | null;
  setResult: (info: VersionInfo | null, status: UpdateStatus) => void;
  markSheetSeen: (version: string) => void;
  dismissBanner: (version: string) => void;
}

/**
 * Update-prompt state. Device-level (not cleared on sign-out); only the
 * "seen"/"dismissed" versions are saved, the version info is re-fetched.
 */
export const useUpdateStore = create<UpdateState>()(
  persist(
    (set) => ({
      info: null,
      status: "none",
      lastCheckedAt: 0,
      sheetSeenVersion: null,
      bannerDismissedVersion: null,
      setResult: (info, status) =>
        set({ info, status, lastCheckedAt: Date.now() }),
      markSheetSeen: (version) => set({ sheetSeenVersion: version }),
      dismissBanner: (version) => set({ bannerDismissedVersion: version }),
    }),
    {
      name: "loveping-app-update",
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({
        sheetSeenVersion: s.sheetSeenVersion,
        bannerDismissedVersion: s.bannerDismissedVersion,
      }),
    },
  ),
);
