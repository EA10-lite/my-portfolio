import { AppText } from "@/src/components";
import {
  PRIMARY,
  PRIMARY_14,
  PRIMARY_1A,
  PRIMARY_33,
  SECONDARY,
  WHITE_80,
  hit,
  radii,
  space,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import {
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  View,
  ViewStyle,
} from "react-native";
import { useUpdateStore } from "./store";
import { openStore } from "./useUpdateCheck";

/**
 * Small "Update available" card for Home. Appears after the sheet was
 * dismissed with "Maybe later", until updated or closed with the X
 * (once per version).
 */
const UpdateBanner = ({ style }: { style?: StyleProp<ViewStyle> }) => {
  const status = useUpdateStore((s) => s.status);
  const latest = useUpdateStore((s) => s.info?.latestVersion);
  const seen = useUpdateStore((s) => s.sheetSeenVersion);
  const dismissed = useUpdateStore((s) => s.bannerDismissedVersion);
  const dismissBanner = useUpdateStore((s) => s.dismissBanner);

  if (
    status !== "optional" ||
    !latest ||
    seen !== latest ||
    dismissed === latest
  ) {
    return null;
  }

  return (
    <View style={[styles.card, style]} accessibilityRole="summary">
      <View style={styles.iconWrap}>
        <Feather name="download" size={18} color={PRIMARY} />
      </View>
      <View style={styles.text}>
        <AppText size="sm" weight="semibold">
          Update available
        </AppText>
        <AppText size="xs" weight="medium" color={WHITE_80} numberOfLines={1}>
          Version {latest} is ready to install
        </AppText>
      </View>
      <TouchableOpacity
        style={styles.update}
        onPress={openStore}
        accessibilityRole="button"
        accessibilityLabel={`Update to version ${latest}`}
        hitSlop={hit.pill}
      >
        <AppText size="xs" weight="semibold" color={SECONDARY}>
          Update
        </AppText>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.close}
        onPress={() => dismissBanner(latest)}
        accessibilityRole="button"
        accessibilityLabel="Dismiss update reminder"
      >
        <Feather name="x" size={18} color={WHITE_80} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[3],
    paddingVertical: space[3],
    paddingLeft: space[4],
    paddingRight: space[1],
    borderRadius: radii.md,
    backgroundColor: PRIMARY_14,
    borderWidth: 1,
    borderColor: PRIMARY_33,
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: PRIMARY_1A,
    alignItems: "center",
    justifyContent: "center",
  },
  text: { flex: 1, minWidth: 0 },
  update: {
    height: 36,
    paddingHorizontal: space[4],
    borderRadius: radii["2xl"],
    backgroundColor: PRIMARY,
    alignItems: "center",
    justifyContent: "center",
  },
  // 44x44 target for the X.
  close: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default UpdateBanner;
