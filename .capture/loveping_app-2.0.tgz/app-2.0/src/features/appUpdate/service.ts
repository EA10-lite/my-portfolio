import axios from "axios";
import Constants from "expo-constants";
import { Platform } from "react-native";
import { BASE_API } from "../../services/client";
import { compareVersions, isValidVersion } from "./version";

/**
 * Backend contract — GET {BASE_API}/app/version?platform=ios|android&version=<installed>
 *
 * {
 *   "latest_version": "2.1.0",          // newest build in the store
 *   "min_version": "2.0.0",             // anything older is blocked
 *   "store_url": "https://…",           // optional, else built from app ids
 *   "release_notes": ["…", "…"],        // optional, shown as "What's new"
 *   "size": "18 MB"                     // optional
 * }
 *
 * No auth. If the endpoint is missing, slow or malformed the app shows nothing.
 */
export type VersionInfo = {
  latestVersion: string;
  minVersion: string;
  storeUrl: string | null;
  releaseNotes: string[];
  size: string | null;
};

export type UpdateStatus = "none" | "optional" | "required";

export const installedVersion = (): string =>
  Constants.expoConfig?.version ?? "0.0.0";

const ANDROID_PACKAGE = "com.loveping.app";

/** Store page for this app: backend URL first, else built from the app ids. */
export const storeUrlFor = (info: VersionInfo | null): string | null => {
  if (info?.storeUrl) return info.storeUrl;
  if (Platform.OS === "android") {
    return `market://details?id=${ANDROID_PACKAGE}`;
  }
  const appStoreId = Constants.expoConfig?.extra?.iosAppStoreId;
  return appStoreId ? `itms-apps://apps.apple.com/app/id${appStoreId}` : null;
};

/** Plain axios: no auth header and no token-refresh retries for this call. */
export const fetchVersionInfo = async (): Promise<VersionInfo | null> => {
  if (Platform.OS !== "ios" && Platform.OS !== "android") return null;
  const { data } = await axios.get(`${BASE_API}/app/version`, {
    params: { platform: Platform.OS, version: installedVersion() },
    timeout: 8000,
  });
  const latest = data?.latest_version;
  const min = data?.min_version ?? "0.0.0";
  if (!isValidVersion(latest) || !isValidVersion(min)) return null;
  return {
    latestVersion: latest.trim(),
    minVersion: min.trim(),
    storeUrl: typeof data.store_url === "string" ? data.store_url : null,
    releaseNotes: Array.isArray(data.release_notes)
      ? data.release_notes
          .filter((n: unknown) => typeof n === "string")
          .slice(0, 5)
      : [],
    size: typeof data.size === "string" ? data.size : null,
  };
};

export const statusFor = (
  info: VersionInfo | null,
  current = installedVersion(),
): UpdateStatus => {
  if (!info) return "none";
  if (compareVersions(current, info.minVersion) < 0) return "required";
  if (compareVersions(current, info.latestVersion) < 0) return "optional";
  return "none";
};
