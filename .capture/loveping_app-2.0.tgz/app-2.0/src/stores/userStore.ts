import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { UserDTO } from "../utils/interface";
import { isGuestUser } from "../utils/guest";

/** Sign-out lives in `services/session.ts` (it clears much more than this store). */
interface UserState {
  user: UserDTO | null;
  isLoggedIn: boolean;
  setUser: (userData: UserDTO) => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: null,
      isLoggedIn: false,
      // `is_guest` is derived from the server's `user_type` so it can't go
      // stale (it stayed true after a guest upgraded their account).
      setUser: (userData: UserDTO) =>
        set({
          user: { ...userData, is_guest: isGuestUser(userData) },
          isLoggedIn: true,
        }),
    }),
    {
      name: "loveping-user", // storage key
      storage: createJSONStorage(() => AsyncStorage),
    },
  ),
);
