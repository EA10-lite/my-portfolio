import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";


// Save the nudge data
interface Nudge {
    repeat: "once_a_week" | "repeat";
    days: string[];
    isRandom: boolean;
}

interface NudgeState {
    nudge: Nudge | null;
    setNudge: (nudge: Nudge) => void;
    clearNudge: () => void;
}

export const useNudgeStore = create<NudgeState>()(
    persist(
        (set) => ({
            nudge: null,
            setNudge: (nudge: Nudge) => set({ nudge }),
            clearNudge: () => {
                set({
                    nudge: null,
                })
            }
        }),
        {
            name: "loveping-user-nudge", // storage key
            storage: createJSONStorage(() => AsyncStorage),
        }
    )
);
