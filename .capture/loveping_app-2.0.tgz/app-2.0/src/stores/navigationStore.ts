import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

/**
 * Navigation Store
 * 
 * Manages tab navigation state across screens.
 * Persists active tab selections so users return to their last viewed tab.
 * 
 * Usage:
 * import { useNavigationStore } from "@/src/stores/navigationStore";
 * 
 * // Get and set gifts tab
 * const { giftsActiveTab, setGiftsActiveTab } = useNavigationStore();
 * 
 * // Get and set messages tab
 * const { messagesActiveTab, setMessagesActiveTab } = useNavigationStore();
 */

type GiftsTab = 'suggestions' | 'saved' | 'history';
type MessagesTab = 'nudges' | 'saved' | 'history';

interface NavigationState {
  // Gifts screen tabs
  giftsActiveTab: GiftsTab;
  setGiftsActiveTab: (tab: GiftsTab) => void;

  // Messages screen tabs
  messagesActiveTab: MessagesTab;
  setMessagesActiveTab: (tab: MessagesTab) => void;
}

export const useNavigationStore = create<NavigationState>()(
  persist(
    (set) => ({
      // Gifts screen tabs - default to 'suggestions'
      giftsActiveTab: 'suggestions',
      setGiftsActiveTab: (tab) =>
        set({
          giftsActiveTab: tab,
        }),

      // Messages screen tabs - default to 'nudges'
      messagesActiveTab: 'nudges',
      setMessagesActiveTab: (tab) =>
        set({
          messagesActiveTab: tab,
        }),
    }),
    {
      name: 'loveping-navigation', // storage key
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

