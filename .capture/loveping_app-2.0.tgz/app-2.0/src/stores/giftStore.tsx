import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

import Bracelet from "@/assets/gifts/bracelet.svg";
import Chocolates from "@/assets/gifts/chocolate-box.svg";
import FlowerBouquet from "@/assets/gifts/flower.svg";
import Totebag from "@/assets/gifts/tote-bag.svg";
import Wristwatch from "@/assets/gifts/wristwatch.svg";
import { Gift } from "../utils/interface";

export const defaultGifts: Gift[] = [
    {
        id: 1,
        title: "Bracelet",
        icon: <Bracelet />,
    },
    
    {
        id: 2,
        title: "Chocolates",
        icon: <Chocolates />,
    },
    {
        id: 3,
        title: "Flower Bouquet",
        icon: <FlowerBouquet />,
    },
    {
        id: 4,
        title: "Totebag",
        icon: <Totebag />,
    },
    {
        id: 5,
        title: "Wristwatch",
        icon: <Wristwatch />,
    },
]


interface GiftState {
    gifts: Gift[];
    setGifts: (gifts: Gift[]) => void;
    saveGift: (id: number) => void;
    removeGift: (id: number) => void;
    isSavedGift: (id: number) => boolean;
    // Internal property for persistence (only IDs are persisted)
    _giftIds?: number[];
}

export const useGiftStore = create<GiftState>()(
    persist(
        (set, get) => ({
            gifts: [],
            // Set gifts by filtering defaultGifts based on the provided Gift array IDs
            setGifts: (gifts: Gift[]) => {
                const ids = gifts.map((gift) => gift.id);
                const fullGifts = defaultGifts.filter((gift) => ids.includes(gift.id));
                set({ gifts: fullGifts, _giftIds: ids });
            },
            saveGift: (id: number) => {
                const currentGifts = get().gifts;
                // Check if gift is already saved
                if (currentGifts.some((gift) => gift.id === id)) return;
                // Find the gift in defaultGifts and add it
                const giftToAdd = defaultGifts.find((gift) => gift.id === id);
                if (giftToAdd) {
                    const newGiftIds = [...currentGifts.map((g) => g.id), id];
                    set({ 
                        gifts: [...currentGifts, giftToAdd],
                        _giftIds: newGiftIds
                    });
                }
            },
            removeGift: (id: number) => {
                const currentGifts = get().gifts;
                const filteredGifts = currentGifts.filter((gift) => gift.id !== id);
                set({ 
                    gifts: filteredGifts,
                    _giftIds: filteredGifts.map((g) => g.id)
                });
            },
            isSavedGift: (id: number) => get().gifts.some((gift) => gift.id === id),
            _giftIds: [],
        }),
        {
            name: "loveping-gifts",
            storage: createJSONStorage(() => AsyncStorage),
            // Only persist the gift IDs, exclude the full gifts array
            partialize: (state) => ({ _giftIds: state._giftIds || [] }),
            // Reconstruct Gift[] from persisted IDs on rehydration
            onRehydrateStorage: () => (state) => {
                if (!state) return;
                if (state._giftIds && state._giftIds.length > 0) {
                    const fullGifts = defaultGifts.filter((gift) => 
                        state._giftIds!.includes(gift.id)
                    );
                    state.gifts = fullGifts;
                } else {
                    state.gifts = [];
                }
            },
        }
    )
)

