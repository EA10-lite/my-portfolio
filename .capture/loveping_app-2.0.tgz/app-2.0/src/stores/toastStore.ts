import { create } from "zustand";

export type ToastType = "success" | "error";

/**
 * Toast Store
 * 
 * Usage:
 * import { useToastStore } from "@/src/stores/toastStore";
 * 
 * // Show success toast
 * const { showToast } = useToastStore();
 * showToast("Operation successful!", "success");
 * 
 * // Show error toast
 * showToast("Something went wrong", "error");
 */

interface ToastState {
  message: string;
  type: ToastType | null;
  isVisible: boolean;
  showToast: (message: string, type: ToastType, position?: "top" | "bottom") => void;
  hideToast: () => void;
  position: "top" | "bottom";
}

export const useToastStore = create<ToastState>((set) => ({
  message: "",
  type: null,
  isVisible: false,
  // Show a toast with a message and type. Position defaults to bottom
  // so that existing usages without position continue to work as-is.
  showToast: (message: string, type: ToastType, position = "bottom") =>
    set({ message, type, position, isVisible: true }),
  hideToast: () => set({ isVisible: false }),
  position: "bottom",
}));
