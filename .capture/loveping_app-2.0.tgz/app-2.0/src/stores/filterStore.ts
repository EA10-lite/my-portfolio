import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

/**
 * Filter Store
 * 
 * Manages filter state for gifts, messages, and other filtered content.
 * Uses persistence to remember user's filter preferences across sessions.
 * 
 * Usage:
 * import { useFilterStore } from "@/src/stores/filterStore";
 * 
 * // Get selected tones
 * const { selectedTones, toggleTone } = useFilterStore();
 * 
 * // Toggle a tone
 * toggleTone('Romantic');
 * 
 * // Clear all filters
 * const { clearFilters } = useFilterStore();
 * clearFilters();
 */

interface FilterState {
  // Tone filters
  selectedTones: string[];
  setSelectedTones: (tones: string[]) => void;
  toggleTone: (tone: string) => void;

  // Occasion filters
  selectedOccasions: string[];
  setSelectedOccasions: (occasions: string[]) => void;
  toggleOccasion: (occasion: string) => void;

  // Gift type filters
  selectedGiftTypes: string[];
  setSelectedGiftTypes: (giftTypes: string[]) => void;
  toggleGiftType: (giftType: string) => void;

  // Clear all filters
  clearFilters: () => void;

  // Check if any filters are active
  hasActiveFilters: () => boolean;
}

export const useFilterStore = create<FilterState>()(
  persist(
    (set, get) => ({
      // Tone filters
      selectedTones: [],
      setSelectedTones: (tones) =>
        set({
          selectedTones: tones,
        }),
      toggleTone: (tone) =>
        set((state) => {
          const current = state.selectedTones || [];
          const exists = current.includes(tone);
          const next = exists
            ? current.filter((t) => t !== tone)
            : [...current, tone];
          return {
            selectedTones: next,
          };
        }),

      // Occasion filters
      selectedOccasions: [],
      setSelectedOccasions: (occasions) =>
        set({
          selectedOccasions: occasions,
        }),
      toggleOccasion: (occasion) =>
        set((state) => {
          const current = state.selectedOccasions || [];
          const exists = current.includes(occasion);
          const next = exists
            ? current.filter((o) => o !== occasion)
            : [...current, occasion];
          return {
            selectedOccasions: next,
          };
        }),

      // Gift type filters
      selectedGiftTypes: [],
      setSelectedGiftTypes: (giftTypes) =>
        set({
          selectedGiftTypes: giftTypes,
        }),
      toggleGiftType: (giftType) =>
        set((state) => {
          const current = state.selectedGiftTypes || [];
          const exists = current.includes(giftType);
          const next = exists
            ? current.filter((g) => g !== giftType)
            : [...current, giftType];
          return {
            selectedGiftTypes: next,
          };
        }),

      // Clear all filters
      clearFilters: () =>
        set({
          selectedTones: [],
          selectedOccasions: [],
        }),

      // Check if any filters are active
      hasActiveFilters: () => {
        const state = get();
        return (
          (state.selectedTones?.length ?? 0) > 0 ||
          (state.selectedOccasions?.length ?? 0) > 0
        );
      },
    }),
    {
      name: "loveping-filters", // storage key
      storage: createJSONStorage(() => AsyncStorage),
      // Only persist selected filters, not helper functions
      partialize: (state) => ({
        selectedTones: state.selectedTones,
        selectedOccasions: state.selectedOccasions,
      }),
    }
  )
);

