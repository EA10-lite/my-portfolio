import { create } from "zustand";

/**
 * Modal Store
 *
 * Centralized state management for all modals in the application.
 * This eliminates prop drilling and provides a single source of truth
 * for modal visibility across the app.
 *
 * Usage:
 * import { useModalStore } from "@/src/stores/modalStore";
 *
 * // Open filter modal
 * const { openFilterModal } = useModalStore();
 * openFilterModal('gifts');
 *
 * // Close filter modal
 * const { closeFilterModal } = useModalStore();
 * closeFilterModal();
 *
 * // Check if modal is visible
 * const { filterModal } = useModalStore();
 * {filterModal.isVisible && <FilterModal />}
 */

interface FilterModalState {
  isVisible: boolean;
  type?: "gifts" | "messages" | "nudge";
}

interface DeleteModalState {
  isVisible: boolean;
  id: number | null;
  type?: string; // 'gift' | 'message' | 'profile' etc.
  title?: string;
  message?: string;
}

interface SuccessModalState {
  isVisible: boolean;
  message?: string;
}

interface ModalState {
  // Filter Modal State
  filterModal: FilterModalState;
  openFilterModal: (type?: "gifts" | "messages" | "nudge") => void;
  closeFilterModal: () => void;

  // Change Tone Modal State
  changeToneModal: { isVisible: boolean };
  openChangeToneModal: () => void;
  closeChangeToneModal: () => void;

  // Delete Modal State
  deleteModal: DeleteModalState;
  openDeleteModal: (
    id: number,
    type?: string,
    title?: string,
    message?: string,
  ) => void;
  closeDeleteModal: () => void;

  // Success Modal State
  successModal: SuccessModalState;
  openSuccessModal: (message?: string) => void;
  closeSuccessModal: () => void;

  // Date Picker Modal State
  datePickerModal: {
    isVisible: boolean;
    context?: "partnerBirthday" | "anniversary" | "general";
  };
  openDatePickerModal: (
    context?: "partnerBirthday" | "anniversary" | "general",
  ) => void;
  closeDatePickerModal: () => void;

  // Nudge Type Modal State
  nudgeTypeModal: { isVisible: boolean };
  openNudgeTypeModal: () => void;
  closeNudgeTypeModal: () => void;

  // Love Language Modal State
  loveLanguageModal: { isVisible: boolean };
  openLoveLanguageModal: () => void;
  closeLoveLanguageModal: () => void;

  // Gender Modal State
  genderModal: { isVisible: boolean };
  openGenderModal: () => void;
  closeGenderModal: () => void;

  // Relationship Type Modal State
  relationshipTypeModal: { isVisible: boolean };
  openRelationshipTypeModal: () => void;
  closeRelationshipTypeModal: () => void;

  // Computed: Check if any modal is active (for BlurBackground)
  hasActiveModal: () => boolean;
}

export const useModalStore = create<ModalState>((set, get) => ({
  // Filter Modal
  filterModal: {
    isVisible: false,
    type: undefined,
  },
  openFilterModal: (type) =>
    set({
      filterModal: {
        isVisible: true,
        type,
      },
    }),
  closeFilterModal: () =>
    set({
      filterModal: {
        isVisible: false,
        type: undefined,
      },
    }),
  // Change Tone Modal
  changeToneModal: {
    isVisible: false,
  },
  openChangeToneModal: () =>
    set({
      changeToneModal: {
        isVisible: true,
      },
    }),
  closeChangeToneModal: () =>
    set({
      changeToneModal: {
        isVisible: false,
      },
    }),

  // Delete Modal
  deleteModal: {
    isVisible: false,
    id: null,
    type: undefined,
    title: undefined,
    message: undefined,
  },
  openDeleteModal: (id, type, title, message) =>
    set({
      deleteModal: {
        isVisible: true,
        id,
        type,
        title,
        message,
      },
    }),
  closeDeleteModal: () =>
    set({
      deleteModal: {
        isVisible: false,
        id: null,
        type: undefined,
        title: undefined,
        message: undefined,
      },
    }),

  // Success Modal
  successModal: {
    isVisible: false,
    message: undefined,
  },
  openSuccessModal: (message) =>
    set({
      successModal: {
        isVisible: true,
        message,
      },
    }),
  closeSuccessModal: () =>
    set({
      successModal: {
        isVisible: false,
        message: undefined,
      },
    }),

  // Date Picker Modal
  datePickerModal: {
    isVisible: false,
    context: "general",
  },
  openDatePickerModal: (context = "general") =>
    set({
      datePickerModal: {
        isVisible: true,
        context,
      },
    }),
  closeDatePickerModal: () =>
    set({
      datePickerModal: {
        isVisible: false,
        context: "general",
      },
    }),

  // Nudge Type Modal
  nudgeTypeModal: {
    isVisible: false,
  },
  openNudgeTypeModal: () =>
    set({
      nudgeTypeModal: {
        isVisible: true,
      },
    }),
  closeNudgeTypeModal: () =>
    set({
      nudgeTypeModal: {
        isVisible: false,
      },
    }),

  // Love Language Modal
  loveLanguageModal: {
    isVisible: false,
  },
  openLoveLanguageModal: () =>
    set({
      loveLanguageModal: {
        isVisible: true,
      },
    }),
  closeLoveLanguageModal: () =>
    set({
      loveLanguageModal: {
        isVisible: false,
      },
    }),

  // Gender Modal
  genderModal: {
    isVisible: false,
  },
  openGenderModal: () =>
    set({
      genderModal: {
        isVisible: true,
      },
    }),
  closeGenderModal: () =>
    set({
      genderModal: {
        isVisible: false,
      },
    }),

  // Relationship Type Modal
  relationshipTypeModal: {
    isVisible: false,
  },
  openRelationshipTypeModal: () =>
    set({
      relationshipTypeModal: {
        isVisible: true,
      },
    }),
  closeRelationshipTypeModal: () =>
    set({
      relationshipTypeModal: {
        isVisible: false,
      },
    }),

  // Computed: Check if any modal is currently active
  hasActiveModal: () => {
    const state = get();
    return (
      state.filterModal.isVisible ||
      state.deleteModal.isVisible ||
      state.successModal.isVisible ||
      state.datePickerModal.isVisible ||
      state.nudgeTypeModal.isVisible ||
      state.loveLanguageModal.isVisible
    );
  },
}));
