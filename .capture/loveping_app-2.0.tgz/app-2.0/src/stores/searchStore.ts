import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

/**
 * Search Store
 * 
 * Manages search query state and recent searches.
 * Persists search history for better user experience.
 * 
 * Usage:
 * import { useSearchStore } from "@/src/stores/searchStore";
 * 
 * // Get search query
 * const { query, setQuery } = useSearchStore();
 * 
 * // Add to recent searches
 * const { addRecentSearch, recentSearches } = useSearchStore();
 * addRecentSearch('Romantic');
 * 
 * // Clear recent searches
 * const { clearRecentSearches } = useSearchStore();
 * clearRecentSearches();
 */

interface SearchState {
  // Current search query
  query: string;
  setQuery: (query: string) => void;
  clearQuery: () => void;

  // Recent searches (limited to last 10)
  recentSearches: string[];
  addRecentSearch: (query: string) => void;
  clearRecentSearches: () => void;
  removeRecentSearch: (query: string) => void;

  // Maximum number of recent searches to store
  MAX_RECENT_SEARCHES: number;
}

export const useSearchStore = create<SearchState>()(
  persist(
    (set, get) => ({
      // Current search query
      query: '',
      setQuery: (query) =>
        set({
          query,
        }),
      clearQuery: () =>
        set({
          query: '',
        }),

      // Recent searches
      recentSearches: [],
      addRecentSearch: (query) => {
        if (!query || query.trim().length === 0) return;
        
        const trimmedQuery = query.trim();
        const state = get();
        
        // Remove if already exists (to move to top)
        const filtered = state.recentSearches.filter(
          (s) => s.toLowerCase() !== trimmedQuery.toLowerCase()
        );
        
        // Add to beginning and limit to MAX_RECENT_SEARCHES
        const updated = [trimmedQuery, ...filtered].slice(
          0,
          state.MAX_RECENT_SEARCHES
        );
        
        set({
          recentSearches: updated,
        });
      },
      clearRecentSearches: () =>
        set({
          recentSearches: [],
        }),
      removeRecentSearch: (query) =>
        set((state) => ({
          recentSearches: state.recentSearches.filter(
            (s) => s.toLowerCase() !== query.toLowerCase()
          ),
        })),

      // Maximum recent searches
      MAX_RECENT_SEARCHES: 10,
    }),
    {
      name: 'loveping-search', // storage key
      storage: createJSONStorage(() => AsyncStorage),
      // Only persist query and recent searches, not constants
      partialize: (state) => ({
        query: state.query,
        recentSearches: state.recentSearches,
      }),
    }
  )
);

