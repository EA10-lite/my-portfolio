import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { Partner } from "../interfaces/Partner";

interface PartnerState {
    partner: Partner | null;
    setPartner: (partner: Partner) => void;
    clearPartner: () => void;
}

export const usePartnerStore = create<PartnerState>()(
    persist(
        (set) => ({
            partner: null,
            setPartner: (partner: Partner) => set({ partner }),
            clearPartner: () => {
                set({
                    partner: null,
                })
            }
        }),
        {
            name: "loveping-partner", // storage key
            storage: createJSONStorage(() => AsyncStorage),
        }
    )
);
