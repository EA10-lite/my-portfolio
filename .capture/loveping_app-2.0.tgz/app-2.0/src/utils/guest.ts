import type { UserDTO } from "./interface";

/**
 * Guest accounts come from `/auth/register/anonymous` with
 * `user_type: "ping_guest"`, a generated name ("Anonymous User 1a2b3c4d")
 * and a placeholder email (`anonymous.…@anonymous.local`).
 */
export const isGuestUser = (user: Partial<UserDTO> | null | undefined) =>
  !!user && (user.user_type === "ping_guest" || user.is_guest === true);

/** Name to show in the UI: "Guest" instead of the generated name. */
export const displayName = (user: Partial<UserDTO> | null | undefined) =>
  isGuestUser(user) ? "Guest" : (user?.full_name ?? "");

/** The backend sends `_id`; older code expected `id`. */
export const userId = (user: Partial<UserDTO> | null | undefined) =>
  user?._id ?? (user?.id != null ? String(user.id) : undefined);

/** Guests have no email or password: logging out loses the account. */
export const GUEST_LOGOUT_WARNING =
  "You're using a guest account. If you log out, you can't get back into it and your partner details and nudges will be lost. Create an account first to keep them.";
