import AsyncStorage from "@react-native-async-storage/async-storage";

const PIN_STORAGE_KEY = "loveping-user-pin";
const PIN_ENABLED_KEY = "loveping-pin-enabled";

/**
 * Saves the user's PIN to secure storage
 * @param pin - The 6-digit PIN to save
 */
export const savePin = async (pin: string): Promise<void> => {
  try {
    if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
      throw new Error("PIN must be exactly 6 digits");
    }
    await AsyncStorage.setItem(PIN_STORAGE_KEY, pin);
    await AsyncStorage.setItem(PIN_ENABLED_KEY, "true");
  } catch (error) {
    console.error("Error saving PIN:", error);
    throw error;
  }
};

/**
 * Retrieves the saved PIN from storage
 * @returns The saved PIN or null if not found
 */
export const getPin = async (): Promise<string | null> => {
  try {
    return await AsyncStorage.getItem(PIN_STORAGE_KEY);
  } catch (error) {
    console.error("Error retrieving PIN:", error);
    return null;
  }
};

/**
 * Verifies if the provided PIN matches the saved PIN
 * @param pin - The PIN to verify
 * @returns True if the PIN matches, false otherwise
 */
export const verifyPin = async (pin: string): Promise<boolean> => {
  try {
    const savedPin = await getPin();
    return savedPin === pin;
  } catch (error) {
    console.error("Error verifying PIN:", error);
    return false;
  }
};

/**
 * Checks if PIN is enabled for the user
 * @returns True if PIN is enabled, false otherwise
 */
export const isPinEnabled = async (): Promise<boolean> => {
  try {
    const enabled = await AsyncStorage.getItem(PIN_ENABLED_KEY);
    const pin = await getPin();
    return enabled === "true" && pin !== null;
  } catch (error) {
    console.error("Error checking PIN status:", error);
    return false;
  }
};

/**
 * Removes the PIN from storage (used when disabling PIN)
 */
export const removePin = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem(PIN_STORAGE_KEY);
    await AsyncStorage.removeItem(PIN_ENABLED_KEY);
  } catch (error) {
    console.error("Error removing PIN:", error);
    throw error;
  }
};

