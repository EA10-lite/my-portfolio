/**
 * Date formatter utility functions
 */

/**
 * Formats a date string (YYYY-MM-DD) to a readable format (Month Day, Year)
 * @param dateString - Date string in format "YYYY-MM-DD"
 * @returns Formatted date string like "January 1, 2025"
 */
export const formatDate = (dateString: string): string => {
    if (!dateString?.trim()) return "";
    try {
        const s = dateString.trim();
        const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
        let date: Date;
        if (iso) {
            const y = Number(iso[1]);
            const m = Number(iso[2]) - 1;
            const d = Number(iso[3]);
            date = new Date(y, m, d);
            if (
                isNaN(date.getTime()) ||
                date.getFullYear() !== y ||
                date.getMonth() !== m ||
                date.getDate() !== d
            ) {
                throw new Error("Invalid date string");
            }
        } else {
            date = new Date(s);
            if (isNaN(date.getTime())) {
                throw new Error("Invalid date string");
            }
        }

        const options: Intl.DateTimeFormatOptions = {
            year: "numeric",
            month: "long",
            day: "numeric",
        };

        return date.toLocaleDateString("en-US", options);
    } catch (error) {
        console.error("Error formatting date:", error);
        return "Invalid Date";
    }
};

/**
 * Formats a date string to a shorter format (Month Day)
 * @param dateString - Date string in format "YYYY-MM-DD"
 * @returns Formatted date string like "Nov 20"
 */
export const formatDateShort = (dateString: string): string => {
    try {
        const date = new Date(dateString);
        
        if (isNaN(date.getTime())) {
            throw new Error('Invalid date string');
        }
        
        const options: Intl.DateTimeFormatOptions = {
            month: 'short',
            day: 'numeric'
        };
        
        return date.toLocaleDateString('en-US', options);
    } catch (error) {
        console.error('Error formatting date:', error);
        return 'Invalid Date';
    }
};

/**
 * Formats a date string to a numeric format (MM/DD/YYYY)
 * @param dateString - Date string in format "YYYY-MM-DD"
 * @returns Formatted date string like "01/01/2025"
 */
export const formatDateNumeric = (dateString: string): string => {
    try {
        const date = new Date(dateString);
        
        if (isNaN(date.getTime())) {
            throw new Error('Invalid date string');
        }
        
        const options: Intl.DateTimeFormatOptions = {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        };
        
        return date.toLocaleDateString('en-US', options);
    } catch (error) {
        console.error('Error formatting date:', error);
        return 'Invalid Date';
    }
};

/**
 * Formats a date string to show relative time (e.g., "2 days ago", "in 3 hours")
 * @param dateString - Date string in format "YYYY-MM-DD"
 * @returns Relative time string
 */
export const formatDateRelative = (dateString: string): string => {
    try {
        const date = new Date(dateString);
        const now = new Date();
        
        if (isNaN(date.getTime())) {
            throw new Error('Invalid date string');
        }
        
        const diffInMs = date.getTime() - now.getTime();
        const diffInDays = Math.round(diffInMs / (1000 * 60 * 60 * 24));
        
        if (diffInDays === 0) {
            return 'Today';
        } else if (diffInDays === 1) {
            return 'Tomorrow';
        } else if (diffInDays === -1) {
            return 'Yesterday';
        } else if (diffInDays > 0) {
            return `In ${diffInDays} day${diffInDays > 1 ? 's' : ''}`;
        } else {
            return `${Math.abs(diffInDays)} day${Math.abs(diffInDays) > 1 ? 's' : ''} ago`;
        }
    } catch (error) {
        console.error('Error formatting date:', error);
        return 'Invalid Date';
    }
};

/**
 * Validates if a date string is in the correct format (YYYY-MM-DD)
 * @param dateString - Date string to validate
 * @returns boolean indicating if the date string is valid
 */
export const isValidDateString = (dateString: string): boolean => {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(dateString)) {
        return false;
    }
    
    const date = new Date(dateString);
    return !isNaN(date.getTime()) && date.toISOString().split('T')[0] === dateString;
};



// Helper function to normalize string or string array to a comma-separated string
export const normalizeToString = (value: string | string[] | undefined): string => {
    if (!value) return "";
    if (Array.isArray(value)) {
        return value.join(",");
    }
    return value;
};


/**
 * Normalizes a value to an array of strings
 * Handles both string arrays and comma-separated strings
 * @param value - Can be a string, string array, or undefined
 * @returns Array of strings, with whitespace trimmed and empty values filtered out
 * @example
 * normalizeToArray("romantic, funny, sweet") // ["romantic", "funny", "sweet"]
 * normalizeToArray(["romantic", "funny"]) // ["romantic", "funny"]
 * normalizeToArray("romantic") // ["romantic"]
 */
export const normalizeToArray = (value: string | string[] | undefined): string[] => {
    if (!value) return [];
    if (Array.isArray(value)) {
        // If already an array, trim whitespace and filter empty values
        return value.map(item => item.trim()).filter(item => item.length > 0);
    }
    // If it's a string, split by comma, trim whitespace, and filter empty values
    return value.split(",").map(item => item.trim()).filter(item => item.length > 0);
};