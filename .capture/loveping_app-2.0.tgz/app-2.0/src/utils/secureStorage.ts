import * as SecureStore from 'expo-secure-store';

const ACCESS_TOKEN_KEY = 'loveping-access-token';
const REFRESH_TOKEN_KEY = 'loveping-refresh-token';

/**
 * Persists the access token in secure storage.
 * @param token Access token string returned from authentication APIs.
 */
export async function saveToken(token: string): Promise<void> {
  await SecureStore.setItemAsync(ACCESS_TOKEN_KEY, token);
}

export async function saveRefreshToken(token: string): Promise<void> {
  await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, token);
}

/**
 * Retrieves the access token from secure storage.
 * @returns The access token string or null when it has not been stored yet.
 */
export async function getToken(): Promise<string | null> {
  return SecureStore.getItemAsync(ACCESS_TOKEN_KEY);
}

export async function getRefreshToken(): Promise<string | null> {
  return SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
}

/**
 * Removes the access token from secure storage.
 */
export async function deleteToken(): Promise<void> {
  await SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY);
}


export async function deleteRefreshToken(): Promise<void> {
  await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
}