import { Partner } from "../interfaces/Partner";

export interface UserDTO {
  full_name: string;
  partner: Partner;
  email_address: string;
  /** What the backend actually sends. */
  _id?: string;
  /** @deprecated Not sent by the backend; use `userId(user)`. */
  id?: string | number;
  createdAt: string;
  updatedAt: string;
  daily_nudge: boolean;
  profile_visibility: boolean;
  silent_mode: boolean;
  special_occassion_reminders: boolean;
  user_type: string;
  language: string;
  is_verified: boolean;
  is_guest?: boolean;
}

export interface Gift {
  id: number;
  title: string;
  icon: React.ReactNode;
}

export interface UpcomingPing {
  _id: string;
  date: string;
  title: string;
  message: string;
}
