import * as yup from 'yup';

export const signinSchema = yup.object().shape({
    email_address: yup.string().email('Invalid email').required('Email is required'),
    password: yup.string().required('Password is required'),
});

export const signupSchema = yup.object().shape({
    full_name: yup.string().required('Full name is required'),
    email_address: yup.string().email('Invalid email').required('Email is required'),
    password: yup.string().required('Password is required'),
    confirmPassword: yup.string().required('Confirm password is required').oneOf([yup.ref('password')], 'Passwords must match'),
    terms: yup.boolean()
});


export const resetPasswordSchema = yup.object().shape({
    email_address: yup.string().email('Invalid email').required('Email is required'),
});

export const resetPasswordSchema2 = yup.object().shape({
    newPassword: yup.string().required('New password is required'),
    confirmPassword: yup.string().required('Confirm password is required').oneOf([yup.ref('newPassword')], 'Passwords must match'),
});


export const contactSchema = yup.object().shape({
    name: yup.string().required('Name is required'),
    // The contact form's field is `email` (it was validated as `email_address`,
    // which never had a value, so the form could not be submitted).
    email: yup.string().email('Invalid email').required('Email is required'),
    message: yup.string().required('Message is required'),
});


export const feedbackSchema = yup.object().shape({
    message: yup.string().required('Message is required'),
});

export const reportSchema = yup.object().shape({
    message: yup.string().required('Message is required'),
    reportType: yup.string()
});


export const textNudgeSchema = yup.object().shape({
    message: yup.string().required('Message is required'),
});


export const relationshipContextSchema = yup.object().shape({
    partnerName: yup.string().required('Partner name is required'),
    partnerGender: yup.string().required('Partner gender is required'),
    partnerRelationshipType: yup.string().required('Partner relationship type is required'),
    partnerBirthday: yup.string().required('Partner birthday is required'),
    anniversary: yup.string().optional(),
    loveLanguage: yup.array().of(yup.string()).required('Love language is required'),
});


export const toneStylePreferencesSchema = yup.object().shape({
    selectedTones: yup.array().of(yup.string()).required('Selected tones are required'),
});



export const editAccountSchema = yup.object().shape({
    full_name: yup.string().required('Full name is required'),
    email: yup.string().email('Invalid email').required('Email is required'),
    partner_name: yup.string().required('Partner name is required'),
    partner_birthday: yup.string().required('Partner birthday is required'),
});

// Used when the user has no partner yet, so the hidden partner fields
// don't block the form (guests and users who skipped partner setup).
export const editAccountNoPartnerSchema = yup.object().shape({
    full_name: yup.string().required('Full name is required'),
    email: yup.string().email('Invalid email').required('Email is required'),
});


export const editPasswordSchema = yup.object().shape({
    oldPassword: yup.string().required('Old password is required'),
    newPassword: yup.string().required('New password is required'),
    confirmPassword: yup.string().required('Confirm password is required').oneOf([yup.ref('newPassword')], 'Passwords must match'),
});



export const newMessageValidationSchema = yup.object().shape({
    message: yup.string().required('Message is required'),
    tones: yup.array().of(yup.string()).required('Tones are required'),
});