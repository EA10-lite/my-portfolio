import client from "./client";

type Report = {
  message: string;
  issue_type: "bug" | "feature" | "payment" | "privacy" | "other" | "rating";
};

const addReport = async (body: Report) => {
  const response = await client.post(
    "/issues",
    { ...body },
    {
      withCredentials: true,
    },
  );
  return response;
};

export default {
  addReport,
};
