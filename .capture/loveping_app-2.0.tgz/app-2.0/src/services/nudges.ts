import { UpdateNudge } from "../interfaces/Nudge";
import client from "./client";

const updateTextNudge = async (id: string, data: UpdateNudge) => {
    return await client.patch(`/nudges/text/${id}`, { ...data }, {
        withCredentials: true
    })
}

export default {
    updateTextNudge,
}