import {
  Login,
  RequestOTPCode,
  ResetPassword,
  Signup,
  SignupAsGuest,
  UpgradeGuest,
  VerifyOTPCode,
} from "../interfaces/Auth";
import { saveRefreshToken, saveToken } from "../utils/secureStorage";
import client from "./client";

const login = (body: Login) => {
  return client.post("/auth/login", { ...body }, { withCredentials: true });
};

const signup = (body: Signup) => {
  return client.post("/auth/register", { ...body });
};

const signupAsGuest = (body: SignupAsGuest) => {
  return client.post("/auth/register/anonymous", { ...body });
};

const requestOTPCode = (body: RequestOTPCode) => {
  return client.post("/auth/otp/generate", { ...body });
};

const resetPassword = (body: ResetPassword) => {
  return client.post(`/auth/otp/reset-password`, { ...body });
};

const verifyOTPCode = (body: VerifyOTPCode) => {
  return client.post(`/auth/otp/verify`, { ...body });
};

const upgradeGuest = (body: UpgradeGuest) => {
  return client.post(`/auth/register/upgrade-guest`, { ...body });
};

const getDashboard = async () => {
  return client.get("/auth/dashboard", {
    withCredentials: true,
  });
};

const getProfile = async () => {
  const response = await client.get("/auth/me", {
    withCredentials: true,
  });
  return response.data;
};

export type RefreshTokenResponse = {
  token: string;
  refresh_token: string;
  refresh_token_expires_at: string;
};

const refreshToken = async (body: { refresh_token: string }) => {
  const response = await client.post<RefreshTokenResponse>(
    "/auth/refresh",
    { ...body },
    { withCredentials: true },
  );
  const data = response.data;
  await saveToken(data.token);
  if (data.refresh_token) {
    await saveRefreshToken(data.refresh_token);
  }
  return data;
};

export default {
  login,
  signup,
  signupAsGuest,
  requestOTPCode,
  resetPassword,
  verifyOTPCode,
  upgradeGuest,
  getDashboard,
  getProfile,
  refreshToken,
};
