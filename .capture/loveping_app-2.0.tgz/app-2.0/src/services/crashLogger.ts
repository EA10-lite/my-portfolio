/**
 * Crash Logger Service
 * 
 * This service provides centralized crash logging functionality using Sentry.
 * It captures and logs:
 * - JavaScript errors and exceptions
 * - Unhandled promise rejections
 * - React component errors (via ErrorBoundary)
 * - Custom error events with context
 * 
 * All crashes are automatically sent to Sentry for investigation.
 */

import * as Sentry from '@sentry/react-native';

/**
 * Initialize crash logging with Sentry
 * Should be called once at app startup in the root layout
 * 
 * @param dsn - Sentry DSN (Data Source Name) for your project
 *              Get this from https://sentry.io after creating a project
 * @param environment - Environment name (e.g., 'development', 'production', 'preview')
 */
export const initCrashLogger = (dsn: string, environment: string = 'production') => {
  Sentry.init({
    dsn,
    environment,
    // Enable native crash reporting
    enableNativeCrashHandling: true,
    // Enable automatic breadcrumb tracking
    enableAutoSessionTracking: true,
    // Track user interactions
    enableNativeNagger: false,
    // Set sample rate for performance monitoring (0.0 to 1.0)
    tracesSampleRate: 1.0,
    // Capture unhandled promise rejections
    enableCaptureFailedRequests: true,
    // Additional options
    beforeSend(event, hint) {
      // You can modify events before they're sent
      // For example, filter out sensitive data
      return event;
    },
  });
};

/**
 * Log a custom error with additional context
 * 
 * @param error - The error object or error message
 * @param context - Additional context about the error (user info, action, etc.)
 */
export const logError = (error: Error | string, context?: Record<string, any>) => {
  if (context) {
    Sentry.setContext('error_context', context);
  }

  if (error instanceof Error) {
    Sentry.captureException(error);
  } else {
    Sentry.captureMessage(error, 'error');
  }
};

/**
 * Log a warning (non-critical issues)
 * 
 * @param message - Warning message
 * @param context - Additional context
 */
export const logWarning = (message: string, context?: Record<string, any>) => {
  if (context) {
    Sentry.setContext('warning_context', context);
  }
  Sentry.captureMessage(message, 'warning');
};

/**
 * Log an info message (for debugging)
 * 
 * @param message - Info message
 * @param context - Additional context
 */
export const logInfo = (message: string, context?: Record<string, any>) => {
  if (context) {
    Sentry.setContext('info_context', context);
  }
  Sentry.captureMessage(message, 'info');
};

/**
 * Set user information for crash reports
 * Helps identify which users are experiencing crashes
 * 
 * @param user - User object with id, email, username, etc.
 */
export const setUser = (user: {
  id?: string;
  email?: string;
  username?: string;
  [key: string]: any;
}) => {
  Sentry.setUser(user);
};

/**
 * Clear user information (e.g., on logout)
 */
export const clearUser = () => {
  Sentry.setUser(null);
};

/**
 * Add breadcrumb (track user actions leading to a crash)
 * 
 * @param message - Breadcrumb message
 * @param category - Category of the breadcrumb (e.g., 'navigation', 'user_action')
 * @param level - Severity level ('debug', 'info', 'warning', 'error')
 * @param data - Additional data
 */
export const addBreadcrumb = (
  message: string,
  category: string = 'custom',
  level: 'debug' | 'info' | 'warning' | 'error' = 'info',
  data?: Record<string, any>
) => {
  Sentry.addBreadcrumb({
    message,
    category,
    level,
    data,
    timestamp: Date.now() / 1000,
  });
};

/**
 * Set additional context for all future events
 * 
 * @param key - Context key
 * @param context - Context data
 */
export const setContext = (key: string, context: Record<string, any>) => {
  Sentry.setContext(key, context);
};

/**
 * Set a tag for filtering crashes in Sentry dashboard
 * 
 * @param key - Tag key
 * @param value - Tag value
 */
export const setTag = (key: string, value: string) => {
  Sentry.setTag(key, value);
};

/**
 * Manually capture an exception
 * 
 * @param exception - Error object
 * @param hint - Additional hint about the error
 */
export const captureException = (exception: Error, hint?: any) => {
  Sentry.captureException(exception, hint);
};

/**
 * Manually capture a message
 * 
 * @param message - Message to capture
 * @param level - Severity level
 */
export const captureMessage = (
  message: string,
  level: 'debug' | 'info' | 'warning' | 'error' | 'fatal' = 'info'
) => {
  Sentry.captureMessage(message, level);
};

