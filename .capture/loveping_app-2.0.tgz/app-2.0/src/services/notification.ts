import client from "./client";

export interface NotificationResponse {
  count: number;
  data: Notification[];
  limit: number;
  page: number;
  total: number;
  totalPages: number;
  unreadCount: number;
}

export interface Notification {
  _id: string;
  body: string;
  createdAt: string;
  read: boolean;
  readAt: null | string;
  subject: string;
  /** Optional https link set when the notification was sent. */
  url?: string;
  /** Not sent by the backend yet; picks the icon when present. */
  type?: string;
}

export const NOTIFICATIONS_PAGE_SIZE = 20;

/** GET /notifications/mine — newest first, paged. */
const getMyNotifications = async (page: number = 1) => {
  const response = await client.get<NotificationResponse>(
    "/notifications/mine",
    {
      params: { page, limit: NOTIFICATIONS_PAGE_SIZE },
      withCredentials: true,
    },
  );

  return response.data;
};

/** POST /notifications/mine/read-all */
const markNotificationAsRead = async () => {
  // Second argument is the request body; options come third.
  return await client.post(
    `/notifications/mine/read-all`,
    {},
    { withCredentials: true },
  );
};

/** POST /notifications/mine/:id/read — one notification. */
const markOneNotificationAsRead = async (id: string) => {
  return await client.post(
    `/notifications/mine/${id}/read`,
    {},
    { withCredentials: true },
  );
};

export default {
  getMyNotifications,
  markNotificationAsRead,
  markOneNotificationAsRead,
};
