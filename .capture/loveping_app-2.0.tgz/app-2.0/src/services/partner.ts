

import { Partner, PartnerPreference } from "../interfaces/Partner";
import client from "./client";

const addPartner = (body: Partner) => {
    return client.post('partners', {...body}, {
        withCredentials: true
    })
}

const getPartners = async () => {
    return client.get('partners', {
        withCredentials: true
    })
}

const addPartnerPreference = async (body: PartnerPreference) => {
    console.log("BODY", body);
    const response = await client.post('ping-preferences', {...body}, {
        withCredentials: true
    })


    return response;
}

const editPartnerPreference = (body: PartnerPreference) => {
    return client.patch('ping-preferences', {...body}, {
        withCredentials: true
    })
}


export default {
    addPartner,
    getPartners,
    addPartnerPreference,
    editPartnerPreference,
}