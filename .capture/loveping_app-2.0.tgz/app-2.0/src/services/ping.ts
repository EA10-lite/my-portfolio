import { AddNudge } from "../interfaces/Nudge";
import client from "./client";

const updatePing = async (id: string, data: AddNudge) => {
  return await client.patch(
    `/ping/${id}`,
    { ...data },
    {
      withCredentials: true,
    },
  );
};

const getAllPing = async (url: string) => {
  return client.get(url, {
    withCredentials: true,
  });
};

const deletePing = async (id: string) => {
  return client.delete(`/ping/${id}`, {
    withCredentials: true,
  });
};

const createPing = async (data: AddNudge) => {
  return client.post(
    `/ping/note-nudge`,
    { ...data },
    {
      withCredentials: true,
    },
  );
};

export default {
  updatePing,
  getAllPing,
  deletePing,
  createPing,
};
