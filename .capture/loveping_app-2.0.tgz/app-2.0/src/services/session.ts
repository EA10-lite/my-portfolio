import * as Notifications from "expo-notifications";
import { router } from "expo-router";
import { mutate } from "swr";
import {
  useFilterStore,
  useNavigationStore,
  useNudgeStore,
  usePartnerStore,
  useSearchStore,
  useToastStore,
  useUserStore,
} from "../stores";
import { useGiftStore } from "../stores/giftStore";
import { removePin } from "../utils/pinStorage";
import { deleteRefreshToken, deleteToken } from "../utils/secureStorage";
import { setSessionExpiredHandler } from "./client";
import { addBreadcrumb, clearUser } from "./crashLogger";

/**
 * Per-user persisted stores. Each is reset to its initial state on sign-out,
 * which also overwrites what it had saved in AsyncStorage.
 * Device-level flags (welcome seen, onboarded) are deliberately kept.
 */
type ResettableStore = {
  getInitialState: () => unknown;
  setState: (state: never, replace: true) => void;
};

const userStores: ResettableStore[] = [
  useUserStore,
  usePartnerStore,
  useNudgeStore,
  useGiftStore,
  useFilterStore,
  useSearchStore,
  useNavigationStore,
];

/** Cancel the local "upcoming ping" reminders scheduled for this user. */
export const cancelPingReminders = async () => {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(
    scheduled
      .filter((n) => n.identifier.startsWith("ping_"))
      .map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)),
  );
};

/** Run every step even if one fails; sign-out must never get stuck. */
const settle = (tasks: (() => unknown)[]) =>
  Promise.allSettled(tasks.map((task) => Promise.resolve().then(task)));

let signingOut = false;

/**
 * Sign the user out and wipe everything that belongs to them on this device:
 * tokens, PIN, persisted stores, cached API data, scheduled reminders and
 * the badge. Previously logout only cleared the user store, so the next
 * person to log in inherited the old PIN, partner, cache and reminders.
 */
export const signOut = async ({
  reason = "user",
}: { reason?: "user" | "expired" } = {}) => {
  if (signingOut) return;
  signingOut = true;
  try {
    addBreadcrumb(`Sign out (${reason})`, "auth", "info");

    await settle([
      deleteToken,
      deleteRefreshToken,
      removePin,
      cancelPingReminders,
      () => Notifications.setBadgeCountAsync(0),
      // Drop every SWR cache entry without refetching.
      () => mutate(() => true, undefined, { revalidate: false }),
      clearUser,
    ]);

    userStores.forEach((store) =>
      store.setState(store.getInitialState() as never, true),
    );

    router.replace("/auth/get-started");

    if (reason === "expired") {
      useToastStore
        .getState()
        .showToast(
          "Your session has expired. Please log in again.",
          "error",
          "top",
        );
    }
  } finally {
    signingOut = false;
  }
};

// When the API can no longer refresh the login, end the session cleanly
// instead of leaving the app "logged in" with no valid token.
setSessionExpiredHandler(() => {
  if (useUserStore.getState().isLoggedIn) {
    signOut({ reason: "expired" });
  }
});
