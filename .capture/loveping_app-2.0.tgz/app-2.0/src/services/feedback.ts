import client from "./client";

type Feedback = {
  message: string;
  feedback_type: "positive" | "negative";
};

type ContactUsPayload = {
  name: string;
  email: string;
  message: string;
};

const addFeedback = async (body: Feedback) => {
  const response = await client.post(
    "/feedback",
    { ...body },
    {
      withCredentials: true,
    },
  );
  return response;
};

const getFAQ = async () => {
  const response = await client.get("/faqs", { withCredentials: true });
  return response?.data;
};

const contactUs = async (body: ContactUsPayload) => {
  const response = await client.post("/contact-us", { ...body }, {
    withCredentials: true,
  });
  return response?.data;
};

export default {
  addFeedback,
  getFAQ,
  contactUs,
};
