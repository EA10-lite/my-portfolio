// import axios from "axios";
// import { getAuthToken, removeAuthToken, removeRefreshToken, setAuthToken, setRefreshToken } from "../util/cookies";
// import { refreshTokenService } from "./auth.service";

// const client = axios.create({
//     baseURL: import.meta.env.VITE_CLIENT_API,
//     headers: {
//         "Content-Type": "application/json",
//         ClientId: import.meta.env.VITE_CLIENT_ID,
//         ClientSecret: import.meta.env.VITE_CLIENT_SECRET,
//     },
// });

// client.interceptors.request.use(
//     (config) => {
//         const token = getAuthToken();
//         if (token) {
//             config.headers.Authorization = `Bearer ${token}`;
//         }
//         return config;
//     },
//     (error) => {
//         return Promise.reject(error);
//     }
// );

// client.interceptors.response.use(
//     (response) => response,
//     async (error) => {
//         const originalRequest = error.config as (typeof error.config & { _retry?: boolean });

//         if (error.response?.status === 401 && !originalRequest?._retry) {
//             originalRequest._retry = true;

//             try {
//                 const refreshResponse = await refreshTokenService();
//                 const newAccessToken =
//                     refreshResponse?.responseData?.accessToken;

//                 if (!newAccessToken) {
//                     throw new Error("Refresh token response did not include access token");
//                 }

//                 setAuthToken(newAccessToken);
//                 setRefreshToken(refreshResponse?.responseData?.refreshToken);
//                 originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
//                 return client(originalRequest);
//             } catch {
//                 removeAuthToken();
//                 removeRefreshToken();
//                 window.location.href = "/login";
//             }
//         }

//         return Promise.reject(error);
//     }
// );

// export default client;
