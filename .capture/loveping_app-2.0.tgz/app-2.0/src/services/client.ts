import axios, {
  AxiosError,
  InternalAxiosRequestConfig,
  isAxiosError,
} from "axios";
import {
  deleteRefreshToken,
  deleteToken,
  getRefreshToken,
  getToken,
  saveRefreshToken,
  saveToken,
} from "../utils/secureStorage";

export const BASE_API =
  "http://localhost:3000/api/v1"; /* process.env.BASE_API || "http://localhost:3000/api/v1" */

const client = axios.create({
  baseURL: BASE_API,
});

/** No auth header — used so expired Bearer is not sent to `/auth/refresh`. */
const refreshClient = axios.create({
  baseURL: BASE_API,
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
});

type RefreshResponse = {
  token: string;
  refresh_token?: string;
  refresh_token_expires_at?: string;
};

type RetriableConfig = InternalAxiosRequestConfig & { _retry?: boolean };

function shouldSkipRefreshForUrl(url: string | undefined): boolean {
  if (!url) return false;
  const path = url.split("?")[0];
  if (path === "/auth/login") return true;
  if (path === "/auth/register" || path === "/auth/register/anonymous")
    return true;
  if (path.includes("/auth/otp/")) return true;
  if (path.includes("/auth/refresh")) return true;
  return false;
}

/**
 * Called when the session can't be refreshed (no refresh token, or the
 * server rejected it). `services/session.ts` registers a handler that signs
 * the user out; kept as a callback so this module doesn't import the stores.
 */
let onSessionExpired: (() => void) | null = null;
export const setSessionExpiredHandler = (handler: () => void) => {
  onSessionExpired = handler;
};

const endSession = async () => {
  await deleteToken();
  await deleteRefreshToken();
  onSessionExpired?.();
};

let isRefreshing = false;
let failedQueue: {
  resolve: (token: string) => void;
  reject: (reason?: unknown) => void;
}[] = [];

function processQueue(error: unknown | null, token: string | null = null) {
  failedQueue.forEach((prom) => {
    if (error != null) {
      prom.reject(error);
    } else if (token != null) {
      prom.resolve(token);
    }
  });
  failedQueue = [];
}

client.interceptors.request.use(
  async (config) => {
    try {
      const accessToken = await getToken();
      if (accessToken) {
        config.headers.Authorization = `Bearer ${accessToken}`;
      }
      config.headers.Accept = "application/json";
      config.headers["Content-Type"] = "application/json";
      return config;
    } catch (e) {
      console.error("Error retrieving token from SecureStore:", e);
      return config;
    }
  },
  (error) => Promise.reject(error),
);

client.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as RetriableConfig | undefined;
    const status = error.response?.status;

    if (
      status !== 401 ||
      !originalRequest ||
      originalRequest._retry ||
      shouldSkipRefreshForUrl(originalRequest.url)
    ) {
      return Promise.reject(error);
    }

    if (isRefreshing) {
      return new Promise<string>((resolve, reject) => {
        failedQueue.push({ resolve, reject });
      })
        .then((token) => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return client(originalRequest);
        })
        .catch((err) => Promise.reject(err));
    }

    originalRequest._retry = true;
    isRefreshing = true;

    try {
      const refreshTokenValue = await getRefreshToken();
      if (!refreshTokenValue) {
        processQueue(error, null);
        await endSession();
        return Promise.reject(error);
      }

      const { data } = await refreshClient.post<RefreshResponse>(
        "/auth/refresh",
        { refresh_token: refreshTokenValue },
        { withCredentials: true },
      );

      await saveToken(data.token);
      if (data.refresh_token) {
        await saveRefreshToken(data.refresh_token);
      }

      processQueue(null, data.token);
      originalRequest.headers.Authorization = `Bearer ${data.token}`;
      return client(originalRequest);
    } catch (refreshErr) {
      processQueue(refreshErr, null);
      // Only a real rejection from the server ends the session. A network
      // error (offline, timeout) used to delete the tokens too, logging the
      // user out for a dropped connection.
      if (isAxiosError(refreshErr) && refreshErr.response) {
        await endSession();
      }
      return Promise.reject(refreshErr);
    } finally {
      isRefreshing = false;
    }
  },
);

export default client;
