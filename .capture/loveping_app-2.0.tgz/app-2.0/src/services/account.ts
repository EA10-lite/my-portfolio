import { UpdatePassword, UpdateProfile } from "../interfaces/Account";
import client from "./client";

const updatePassword = (body: UpdatePassword) => {
  return client.post(
    "/auth/change-password",
    { ...body },
    { withCredentials: true },
  );
};

const updateProfile = async (body: UpdateProfile) => {
  const response = await client.patch(
    "/auth/profile-with-partner",
    { ...body },
    { withCredentials: true },
  );

  return response;
};

export default {
  updatePassword,
  updateProfile,
};
