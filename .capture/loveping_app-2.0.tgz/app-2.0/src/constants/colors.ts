/**
 * Kept for backwards compatibility: colour tokens now live in `src/theme/colors`.
 */
export * from "../theme/colors";
