

export const TONES = [
    {
        name: "Romantic",
        value: "romantic",
    },
    {
        name: "Playful",
        value: "playful",
    },
    {
        name: "Deep & Thoughtful",
        value: "deep_n_thoughtful",
    },
    {
        name: "Supportive",
        value: "supportive",
    },
    {
        name: "Funny/Lighthearted",
        value: "funny_n_light_hearted",
    },
]