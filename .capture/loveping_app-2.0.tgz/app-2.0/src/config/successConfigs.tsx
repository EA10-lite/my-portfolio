import ProfileIcon from "@/assets/illustrations/account.svg";
import NotificationIcon from "@/assets/illustrations/bell.svg";
import CompletedIcon from "@/assets/illustrations/handshake.svg";
import LockIcon from "@/assets/illustrations/lock.svg";
import MessageIcon from "@/assets/illustrations/message.svg";
import { router } from "expo-router";
import { Dimensions, View } from "react-native";
import { space } from "@/src/theme";

const WIDTH = Dimensions.get("window").width;

/** Space under each illustration (`mb-24`). */
const iconWrap = { marginBottom: space[24] };

/**
 * Success screen configuration types
 * Maps success types to their display properties
 */
export type SuccessType =
  | "password_reset"
  | "password_updated"
  | "enable_notification"
  | "account_setup_complete"
  | "account_updated"
  | "pin_set"
  | "report_submitted"
  | "feedback_submitted";

export type SuccessConfig = {
  title: string;
  subtitle: string;
  buttonText?: string;
  secondaryButtonText?: string;
  icon?: React.ReactNode;
  width?: number;
  // Navigation actions
  onPressAction?: "back" | "login" | "home" | "profile" | "close";
  onSecondaryPressAction?: "back" | "home" | "profile" | "close";
  // Navigate to another success screen
  nextSuccessType?: SuccessType;
  nextSuccessTypeSecondary?: SuccessType;
};

/**
 * Success screen configurations
 * Centralized configuration for all success screens in the app
 */
export const SUCCESS_CONFIGS: Record<SuccessType, SuccessConfig> = {
  // Password reset success (forgot-password flow)
  password_reset: {
    title: "Password Reset Successful",
    subtitle: "You can now log in with your new password.",
    buttonText: "Continue",
    icon: (
      <View style={iconWrap}>
        <LockIcon width={178} height={208} />
      </View>
    ),
    onPressAction: "login",
  },

  // Password updated success (profile/account/password)
  password_updated: {
    title: "Password Updated Successfully",
    subtitle: "Your password has been updated",
    buttonText: "Continue",
    icon: (
      <View style={iconWrap}>
        <LockIcon width={178} height={208} />
      </View>
    ),
    onPressAction: "close",
  },

  // Enable notification (complete-account-setup step 3)
  enable_notification: {
    title: "Enable Notification",
    subtitle: "Get gentle nudges and love reminders right on time",
    buttonText: "Continue",
    secondaryButtonText: "Remind me later",
    icon: (
      <View style={iconWrap}>
        <NotificationIcon width={146} height={138} />
      </View>
    ),
    width: 66,
    onPressAction: "close",
    onSecondaryPressAction: "close",
    // Navigate to account setup complete screen after this
    nextSuccessType: "account_setup_complete",
    nextSuccessTypeSecondary: "account_setup_complete",
  },

  // Account setup complete (complete-account-setup final step)
  account_setup_complete: {
    title: "You're all set",
    subtitle: "We'll nudge when the moment's right",
    buttonText: "Start Loveping",
    icon: (
      <View style={iconWrap}>
        <CompletedIcon width={WIDTH} />
      </View>
    ),
    onPressAction: "home",
  },

  // Account updated (profile/account/index)
  account_updated: {
    title: "Account Updated Successfully",
    subtitle: "Your account details have been updated.",
    buttonText: "Continue",
    icon: (
      <View style={iconWrap}>
        <ProfileIcon width={235} height={198} />
      </View>
    ),
    onPressAction: "close",
  },

  // PIN set (profile/settings/pin)
  pin_set: {
    title: "PIN Set Successfully",
    subtitle: "PIN created successfully — your account is now extra secure",
    buttonText: "Continue",
    icon: (
      <View style={iconWrap}>
        <LockIcon width={178} height={208} />
      </View>
    ),
    onPressAction: "profile",
  },

  // Report submitted (profile/support/report)
  report_submitted: {
    title: "Thanks for reporting!",
    subtitle: "Our team will look into it quickly",
    buttonText: "OK, Got it",
    icon: (
      <View style={iconWrap}>
        <MessageIcon width={220} height={178} />
      </View>
    ),
    onPressAction: "close",
  },

  // Feedback submitted (profile/support/feedback)
  feedback_submitted: {
    title: "Thanks for your feedback!",
    subtitle: "We're always improving Loveping for you.",
    buttonText: "OK, Got it",
    icon: (
      <View style={iconWrap}>
        <MessageIcon width={220} height={178} />
      </View>
    ),
    onPressAction: "close",
  },
};

/**
 * Get success configuration by type
 * @param type - The success type identifier
 * @returns Success configuration or undefined if not found
 */
export const getSuccessConfig = (
  type: SuccessType,
): SuccessConfig | undefined => {
  return SUCCESS_CONFIGS[type];
};

/**
 * Handle navigation action based on action type
 * @param action - The navigation action to perform
 * @param nextSuccessType - Optional success type to navigate to
 */
export const handleSuccessAction = (
  action?: "back" | "login" | "home" | "profile" | "close",
  nextSuccessType?: SuccessType,
) => {
  // If there's a next success screen to show, navigate to it
  if (nextSuccessType) {
    router.push({
      pathname: "/success",
      params: { type: nextSuccessType },
    });
    return;
  }

  // Otherwise, handle the standard navigation actions
  switch (action) {
    case "back":
      router.back();
      break;
    case "login":
      router.dismiss();
      router.replace("/auth/signin");
      break;
    case "home":
      router.replace("/(tabs)");
      break;
    case "profile":
      router.push("/(tabs)/profile");
      break;
    case "close":
    default:
      // For route-based success, "close" means go back
      router.back();
      break;
  }
};
