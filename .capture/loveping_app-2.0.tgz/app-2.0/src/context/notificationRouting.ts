import type { Href } from "expo-router";
import { router } from "expo-router";

/**
 * Where a tapped notification should take the user.
 * - Local "upcoming ping" reminders -> Home, where today's nudges are.
 * - Anything else (server pushes) -> the notifications list.
 */
export const hrefForNotification = (
  data: Record<string, unknown> | undefined,
): Href => (data?.type === "upcoming_ping" ? "/(tabs)" : "/notification");

let pending: Href | null = null;
let appReady = false;

/**
 * Taps can arrive before the app can navigate (cold start: boot routing and
 * the PIN screen run first). The route is parked here and opened once the
 * tabs are mounted, i.e. the user is signed in and past the PIN screen.
 */
export const openFromNotification = (href: Href) => {
  pending = href;
  flush();
};

export const setAppReady = (ready: boolean) => {
  appReady = ready;
  if (ready) flush();
};

function flush() {
  if (!appReady || !pending) return;
  const href = pending;
  pending = null;
  // `navigate` reuses an existing screen instead of stacking duplicates.
  router.navigate(href);
}
