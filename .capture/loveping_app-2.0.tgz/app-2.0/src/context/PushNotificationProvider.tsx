import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { Platform } from "react-native";
import { refreshNotifications } from "../hooks/useNotifications";
import { UpcomingPing } from "../utils/interface";
import {
  hrefForNotification,
  openFromNotification,
} from "./notificationRouting";

interface NotificationContextProps {
  expoPushToken: string | null;
  sendLocalNotification: (title: string, body: string) => Promise<void>;
  scheduleUpcomingPings: (pings: UpcomingPing[]) => Promise<void>;
}

const NotificationContext = createContext<NotificationContextProps>({
  expoPushToken: null,
  sendLocalNotification: async () => {},
  scheduleUpcomingPings: async () => {},
});

export const usePushNotifications = () => useContext(NotificationContext);

interface Props {
  children: React.ReactNode;
}

export default function PushNotificationProvider({ children }: Props) {
  const [expoPushToken, setExpoPushToken] = useState<string | null>(null);

  const notificationListener = useRef<Notifications.Subscription | undefined>(
    undefined,
  );

  const responseListener = useRef<Notifications.Subscription | undefined>(
    undefined,
  );

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
        shouldShowBanner: true,
        shouldShowList: true,
      }),
    });

    registerForPushNotifications();

    // A push arrived while the app is open: refresh the bell's unread count.
    notificationListener.current =
      Notifications.addNotificationReceivedListener(() => {
        refreshNotifications();
      });

    // Taps used to be ignored. Open the matching screen; `handled` stops the
    // cold-start check below from opening the same tap twice.
    const handled = new Set<string>();
    const handleResponse = (response: Notifications.NotificationResponse) => {
      const id = response.notification.request.identifier;
      if (handled.has(id)) return;
      handled.add(id);
      refreshNotifications();
      openFromNotification(
        hrefForNotification(response.notification.request.content.data),
      );
    };

    responseListener.current =
      Notifications.addNotificationResponseReceivedListener(handleResponse);

    // The tap that launched the app from a closed state.
    Notifications.getLastNotificationResponseAsync()
      .then((response) => {
        if (response) {
          handleResponse(response);
          Notifications.clearLastNotificationResponseAsync?.();
        }
      })
      .catch(() => {});

    return () => {
      notificationListener.current?.remove();
      responseListener.current?.remove();
    };
  }, []);

  const registerForPushNotifications = async () => {
    try {
      // Android 13+ only shows the permission prompt once a channel exists,
      // so create it first. (`sound: "true"` looked for a custom sound file
      // named "true"; "default" is the system notification sound.)
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("default", {
          name: "Default",
          importance: Notifications.AndroidImportance.MAX,
          sound: "default",
          vibrationPattern: [0, 250, 250, 250],
          lightColor: "#48D962",
        });
      }

      const permissions = await Notifications.getPermissionsAsync();

      let finalStatus = permissions.status;

      if (permissions.status !== "granted") {
        const requestResult = await Notifications.requestPermissionsAsync();
        finalStatus = requestResult.status;
      }

      if (finalStatus !== "granted") {
        console.log("Notification permission denied");
        return;
      }

      // Pass the EAS project id explicitly; required outside Expo Go.
      const projectId =
        Constants.expoConfig?.extra?.eas?.projectId ??
        Constants.easConfig?.projectId;
      const token = await Notifications.getExpoPushTokenAsync(
        projectId ? { projectId } : undefined,
      );
      setExpoPushToken(token.data);
    } catch (error) {
      console.log("Push notification registration error:", error);
    }
  };

  const sendLocalNotification = async (title: string, body: string) => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title,
          body,
          sound: true,
        },
        trigger: null, // Send immediately
      });
    } catch (error) {
      console.log("Local notification error:", error);
    }
  };

  const scheduleUpcomingPings = async (pings: UpcomingPing[]) => {
    try {
      // Cancel all existing scheduled notifications first
      const allNotifications =
        await Notifications.getAllScheduledNotificationsAsync();
      for (const notification of allNotifications) {
        if (notification.identifier.startsWith("ping_")) {
          await Notifications.cancelScheduledNotificationAsync(
            notification.identifier,
          );
        }
      }

      const now = Date.now();

      for (const ping of pings) {
        const date = new Date(ping.date);

        // Skip past or invalid dates.
        if (!(date.getTime() > now)) continue;

        try {
          // A date trigger has no upper limit. The old seconds-from-now
          // interval was capped at ~24.8 days, so later pings were dropped.
          await Notifications.scheduleNotificationAsync({
            identifier: `ping_${ping._id}`,
            content: {
              title: ping.title,
              body: ping.message,
              sound: true,
              badge: 1,
              data: {
                pingId: ping._id,
                type: "upcoming_ping",
              },
            },
            trigger: {
              type: Notifications.SchedulableTriggerInputTypes.DATE,
              date,
              channelId: "default",
            },
          });
        } catch (error) {
          console.log(`Error scheduling notification ${ping._id}:`, error);
        }
      }
    } catch (error) {
      console.log("Scheduling error:", error);
    }
  };

  return (
    <NotificationContext.Provider
      value={{
        expoPushToken,
        sendLocalNotification,
        scheduleUpcomingPings,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}
