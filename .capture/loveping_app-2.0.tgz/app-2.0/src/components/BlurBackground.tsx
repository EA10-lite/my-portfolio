import { BlurView } from "expo-blur";
import { StyleSheet, View } from "react-native";

type BlurBackgroundProps = {
  intensity?: number;
  tint?: "light" | "dark";
};

/** Full-bleed blur behind a modal. */
const BlurBackground = ({
  intensity = 60,
  tint = "dark",
}: BlurBackgroundProps) => (
  <View style={StyleSheet.absoluteFill}>
    <BlurView
      intensity={intensity}
      tint={tint}
      style={StyleSheet.absoluteFill}
    />
  </View>
);

export default BlurBackground;
