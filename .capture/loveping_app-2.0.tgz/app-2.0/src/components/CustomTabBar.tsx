import Gifts from "@/assets/icons/gift.svg";
import Home from "@/assets/icons/home.svg";
import Messages from "@/assets/icons/message.svg";
import Profile from "@/assets/icons/profile.svg";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import React from "react";
import {
  Animated,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import {
  BG_DARK,
  PRIMARY,
  PRIMARY_08,
  PRIMARY_14,
  SECONDARY,
  WHITE,
  radii,
  space,
  useResponsive,
} from "../theme";
import { TAB_SIZE, useTabBarMetrics } from "./tabBarMetrics";
import AppText from "./ui/AppText";

type IconConfig = {
  icon: (color: string) => React.ReactNode;
  label: string;
};

const icons: Record<string, IconConfig> = {
  index: {
    icon: (color) => <Home color={color} />,
    label: "Home",
  },
  messages: {
    icon: (color) => <Messages color={color} />,
    label: "Messages",
  },
  gifts: {
    icon: (color) => <Gifts color={color} />,
    label: "Gifts",
  },
  profile: {
    icon: (color) => <Profile color={color} />,
    label: "Profile",
  },
};

interface CustomTabBarProps extends BottomTabBarProps {
  translateY: Animated.Value;
}

export default function CustomTabBar({
  state,
  navigation,
  translateY,
}: CustomTabBarProps) {
  const orderedRoutes = ["index", "messages", "gifts", "profile"];
  const { isSm, width } = useResponsive();
  const { bottom, paddingVertical } = useTabBarMetrics();
  // Spacing by available width so the three 48px circles plus the active
  // pill ("Messages" is the longest label) always fit on one line:
  //   < 370dp (320-360dp Androids): compact, 14px label
  //   370-399dp (iPhone SE / mini / 393dp iPhones): medium, 16px label
  //   >= 400dp (Plus / Max, large Androids): roomy
  const narrow = width < 370;
  const medium = !narrow && width < 400;
  const sidePadding = narrow ? space[3] : medium ? space[4] : space[6];
  const innerPadding = narrow ? space[2] : medium ? space[4] : space[5];

  return (
    <Animated.View
      style={[
        styles.wrapper,
        {
          bottom,
          paddingHorizontal: sidePadding,
          transform: [{ translateY }],
        },
      ]}
    >
      <View
        accessibilityRole="tablist"
        style={[
          styles.bar,
          {
            paddingHorizontal: innerPadding,
            paddingVertical,
            gap: narrow ? space[1] : space[2],
          },
        ]}
      >
        {orderedRoutes.map((routeName) => {
          const index = state.routes.findIndex((r) => r.name === routeName);

          if (index === -1) return null;

          const route = state.routes[index];
          const isFocused = state.index === index;
          const color = isFocused ? SECONDARY : WHITE;

          const onPress = () => {
            const event = navigation.emit({
              type: "tabPress",
              target: route.key,
              canPreventDefault: true,
            });

            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          const renderIcon = icons[routeName];

          if (!renderIcon) return null;

          return (
            <TouchableOpacity
              key={route.key}
              accessibilityRole="tab"
              accessibilityState={{ selected: isFocused }}
              accessibilityLabel={renderIcon.label}
              onPress={onPress}
              activeOpacity={0.8}
              style={[styles.tab, isFocused ? styles.tabActive : styles.tabIdle]}
            >
              {isFocused ? (
                <View
                  style={[
                    styles.activeContent,
                    narrow && { paddingHorizontal: space[3] },
                  ]}
                >
                  {renderIcon.icon(color)}
                  <AppText
                    size={isSm && !narrow ? "base" : "sm"}
                    weight="medium"
                    color={SECONDARY}
                    numberOfLines={1}
                    // Large accessibility text: grow a little, then truncate
                    // rather than push the bar off screen.
                    maxFontSizeMultiplier={1.3}
                    style={styles.activeLabel}
                  >
                    {renderIcon.label}
                  </AppText>
                </View>
              ) : (
                renderIcon.icon(color)
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: "absolute",
    left: 0,
    right: 0,
    alignItems: "center",
    pointerEvents: "box-none",
  },
  // `flex-row bg-bg-dark gap-2 rounded-4xl justify-between items-center border border-primary-14`
  bar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: space[2],
    backgroundColor: BG_DARK,
    borderRadius: radii["4xl"],
    borderWidth: 1,
    borderColor: PRIMARY_14,
    // Fill the width (inside the wrapper's side padding) instead of
    // shrink-wrapping, so the bar no longer changes width and jumps when the
    // label changes ("Home" vs "Messages"); capped and centred on tablets.
    width: "100%",
    maxWidth: 480,
  },
  tab: {
    height: TAB_SIZE,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: PRIMARY_14,
  },
  tabActive: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: PRIMARY,
    borderRadius: 100,
  },
  tabIdle: {
    width: TAB_SIZE,
    backgroundColor: PRIMARY_08,
    borderRadius: TAB_SIZE / 2,
  },
  activeContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: space[4],
    gap: space[2],
    minWidth: 0,
  },
  activeLabel: { flexShrink: 1 },
});
