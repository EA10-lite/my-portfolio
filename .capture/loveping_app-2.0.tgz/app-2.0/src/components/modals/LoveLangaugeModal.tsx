import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { rs, space, useResponsive } from "@/src/theme";
import Button from "../Button";
import Chip from "../ui/Chip";
import SheetHeader from "../ui/SheetHeader";
import CustomModal from "./CustomModal";
import { sheetStyles } from "./sheetStyles";

type LoveLanguageModalProps = {
  onClose: () => void;
  selectedLanguages: string[];
  handleSelectLoveLanguage: (language: string) => void;
  onSave: (selectedLanguages: string[]) => void;
};

const languages = [
  { name: "Words of Affirmation", value: "words_of_affirmation" },
  { name: "Quality Time", value: "quality_time" },
  { name: "Acts of Service", value: "act_of_service" },
  { name: "Physical Touch", value: "physical_touch" },
  { name: "Receiving Gifts", value: "receiving_gifts" },
];

const LoveLanguageModal = forwardRef<BottomSheetModal, LoveLanguageModalProps>(
  ({ onClose, selectedLanguages, handleSelectLoveLanguage, onSave }, ref) => {
    const insets = useSafeAreaInsets();
    const { isSm } = useResponsive();

    return (
      <CustomModal ref={ref} onClose={onClose}>
        <View style={sheetStyles.root}>
          <SheetHeader title="Love Language" onClose={onClose} />

          <View
            style={[
              sheetStyles.body,
              {
                paddingTop: rs(isSm, space[6], space[8]),
                paddingBottom: insets.bottom + 16,
              },
            ]}
          >
            <View style={sheetStyles.options}>
              {languages.map((language) => (
                <Chip
                  key={language.value}
                  tone="muted"
                  label={language.name}
                  selected={selectedLanguages.includes(language.value)}
                  onPress={() => handleSelectLoveLanguage(language.value)}
                />
              ))}
            </View>

            <Button
              title="Save"
              onPress={() => onSave(selectedLanguages)}
              variant="primary"
              size="lg"
            />
          </View>
        </View>
      </CustomModal>
    );
  },
);

LoveLanguageModal.displayName = "Love Language Modal";

export default LoveLanguageModal;
