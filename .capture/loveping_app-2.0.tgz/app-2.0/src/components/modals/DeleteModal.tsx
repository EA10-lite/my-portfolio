import TrashIcon from "@/assets/icons/delete.svg";
import {
  DANGER_33,
  GREY,
  PRIMARY,
  PRIMARY_14,
  PRIMARY_1A,
  rs,
  space,
  useResponsive, hit } from "@/src/theme";
import Feather from "@expo/vector-icons/Feather";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Button from "../Button";
import AppText from "../ui/AppText";
import CustomModal from "./CustomModal";

type DeleteModalProps = {
  onClose: () => void;
  title?: string;
  message?: string;
  onCancel: () => void;
  onDelete: () => void;
  cancelButtonText?: string;
  deleteButtonText?: string;
  icon?: React.ReactNode;
  deleting?: boolean;
};

/** Confirmation sheet (delete, remove, logout). */
const DeleteModal = forwardRef<BottomSheetModal, DeleteModalProps>(
  (
    {
      onClose,
      title = "Delete",
      message = "Are you sure you want to delete this item?",
      onCancel,
      onDelete,
      cancelButtonText = "Cancel",
      deleteButtonText = "Delete",
      icon,
      deleting = false,
    },
    ref,
  ) => {
    const insets = useSafeAreaInsets();
    const { isSm } = useResponsive();

    return (
      <CustomModal ref={ref} onClose={onClose} showClose={false}>
        <View style={styles.root}>
          <TouchableOpacity
            onPress={onClose}
            style={styles.close}
            accessibilityRole="button"
            accessibilityLabel="Close"
            hitSlop={hit.icon}
          >
            <Feather name="x" size={16} color={PRIMARY} />
          </TouchableOpacity>

          <View
            style={[
              styles.body,
              {
                paddingTop: rs(isSm, space[6], space[8]),
                paddingBottom: insets.bottom + 16,
              },
            ]}
          >
            <View style={{ marginBottom: rs(isSm, space[12], space[16]) }}>
              <View style={styles.iconCircle}>
                {icon ? icon : <TrashIcon width={24} height={24} />}
              </View>
              <AppText
                size="2xl"
                weight="bold"
                align="center"
                style={styles.title}
                accessibilityRole="header"
              >
                {title}
              </AppText>
              <AppText size="base" weight="medium" color={GREY} align="center">
                {message}
              </AppText>
            </View>

            <View style={[styles.actions, { gap: rs(isSm, space[4], space[5]) }]}>
              <View style={styles.fill}>
                <Button
                  title={cancelButtonText}
                  onPress={onCancel}
                  variant="danger"
                  disabled={deleting}
                />
              </View>
              <View style={styles.fill}>
                <Button
                  title={deleteButtonText}
                  onPress={onDelete}
                  variant="primary"
                  disabled={deleting}
                  loading={deleting}
                />
              </View>
            </View>
          </View>
        </View>
      </CustomModal>
    );
  },
);

DeleteModal.displayName = "Delete Modal";

const styles = StyleSheet.create({
  root: { position: "relative", height: "100%", width: "100%" },
  fill: { flex: 1 },
  // `absolute right-6 w-7 h-7 bg-primary-14 border border-primary-1A rounded-full`
  close: {
    position: "absolute",
    right: space[6],
    zIndex: 1,
    width: space[7],
    height: space[7],
    borderRadius: space[7] / 2,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: PRIMARY_14,
    borderWidth: 1,
    borderColor: PRIMARY_1A,
  },
  // `px-6 w-[90%] mx-auto`
  body: { paddingHorizontal: space[6], width: "90%", alignSelf: "center" },
  // `rounded-full border border-danger-33 bg-danger-33 w-15 h-15 mx-auto mb-4`
  iconCircle: {
    width: space[15],
    height: space[15],
    borderRadius: space[15] / 2,
    borderWidth: 1,
    borderColor: DANGER_33,
    backgroundColor: DANGER_33,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: space[4],
  },
  title: { marginBottom: space[4] },
  actions: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
});

export default DeleteModal;
