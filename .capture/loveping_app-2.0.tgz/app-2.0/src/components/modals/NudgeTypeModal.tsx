import { AntDesign, MaterialIcons } from "@expo/vector-icons";
import Feather from "@expo/vector-icons/Feather";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef, useEffect, useRef, useState } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  GREY,
  GREY_10,
  PRIMARY,
  PRIMARY_1A,
  PRIMARY_33,
  SECONDARY,
  WHITE_05,
  radii,
  space, hit } from "@/src/theme";
import Button from "../Button";
import AppText from "../ui/AppText";
import Chip from "../ui/Chip";
import SheetHeader from "../ui/SheetHeader";
import CustomModal from "./CustomModal";

type NudgeTypeModalProps = {
  onClose: () => void;
  nudgeType: string;
  selectedDays: string[];
  handleSelectDay: (day: string) => void;
  onChangeNudgeType: (type: string) => void;
  setDays: (days: string[]) => void;
};

const days = [
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

const NudgeTypeModal = forwardRef<BottomSheetModal, NudgeTypeModalProps>(
  (
    {
      onClose,
      nudgeType,
      selectedDays,
      handleSelectDay,
      onChangeNudgeType,
      setDays,
    },
    ref,
  ) => {
    const insets = useSafeAreaInsets();
    const [isRandom, setIsRandom] = useState<boolean>(false);
    const [selectedOption, setSelectedOption] = useState<
      "once_a_week" | "repeat"
    >("once_a_week");
    const [isOpenOption, setIsOpenOption] = useState<boolean>(false);
    const isInitialMount = useRef<boolean>(true);

    const handleRandom = () => {
      // Randomly select days based on the current selected option
      // If "once a week": randomly choose 1 day
      // If "repeat": randomly choose max 3 days
      const shuffled = [...days].sort(() => Math.random() - 0.5);
      const maxDays = selectedOption === "once_a_week" ? 1 : 3;
      const chosenDays = shuffled.slice(0, maxDays);
      setDays(chosenDays);
    };

    // Handle day selection with "once a week" constraint
    const handleDaySelection = (day: string) => {
      // If "once a week" is selected, only allow 1 day
      if (selectedOption === "once_a_week") {
        // If the day is already selected, deselect it by setting empty array
        if (selectedDays.includes(day)) {
          setDays([]);
        } else {
          // Replace all selected days with just this one
          setDays([day]);
        }
      } else {
        // For "repeat" mode, use the original toggle behavior
        handleSelectDay(day);
      }
    };

    // Sync selectedOption with nudgeType prop when modal opens
    useEffect(() => {
      if (nudgeType) {
        if (nudgeType === "once_a_week" || nudgeType === "repeat") {
          setSelectedOption(nudgeType);
        }
      }
    }, [nudgeType]);

    // Effect to handle option change and enforce day limits
    useEffect(() => {
      // Skip on initial mount to avoid clearing form values
      if (isInitialMount.current) {
        isInitialMount.current = false;
        return;
      }

      // If random is enabled, re-randomize days when option changes
      if (isRandom) {
        handleRandom();
      } else {
        // Only enforce limits when switching to "once_a_week" and multiple days are selected (non-random mode)
        if (selectedOption === "once_a_week" && selectedDays?.length > 1) {
          // Keep the first day and remove the rest
          setDays([selectedDays[0]]);
        }
      }
      // Update the nudge type in parent component (only if it actually changed)
      if (nudgeType !== selectedOption) {
        onChangeNudgeType(selectedOption);
      }
    }, [selectedOption]);

    // Effect to handle random checkbox toggle
    useEffect(() => {
      if (isRandom) {
        // When random is enabled, immediately randomize days based on current option
        handleRandom();
      }
    }, [isRandom]);

    const handleClose = () => {
      setIsOpenOption(false);
      onClose();
    };

    return (
      <CustomModal ref={ref} onClose={handleClose} showClose={false}>
        <View style={styles.root}>
          <SheetHeader title="Nudge Type" onClose={onClose} />

          <View style={{ paddingBottom: insets.bottom + 16 }}>
            <View style={styles.daysSection}>
              <View style={styles.preferences}>
                <AppText
                  size="base"
                  weight="medium"
                  color={GREY}
                  style={styles.preferencesTitle}
                >
                  Select your preferences
                </AppText>

                <View style={styles.dropdownWrap}>
                  <View style={styles.dropdownRow}>
                    <TouchableOpacity
                      style={styles.dropdownTrigger}
                      onPress={() => setIsOpenOption(!isOpenOption)}
                      accessibilityRole="button"
                      accessibilityState={{ expanded: isOpenOption }}
                      hitSlop={hit.pill}
                    >
                      <AppText size="sm" color={GREY}>
                        {selectedOption === "once_a_week"
                          ? "Once a week"
                          : "Repeat"}
                      </AppText>
                      <MaterialIcons
                        name="keyboard-arrow-down"
                        size={18}
                        color={PRIMARY}
                      />
                    </TouchableOpacity>
                  </View>
                  {isOpenOption && (
                    <View style={styles.dropdownMenu}>
                      <TouchableOpacity
                        style={[styles.dropdownItem, styles.dropdownDivider]}
                        onPress={() => {
                          setSelectedOption("once_a_week");
                          setIsOpenOption(false);
                        }}
                      >
                        <AppText
                          size="sm"
                          color={
                            selectedOption === "once_a_week" ? PRIMARY : GREY
                          }
                        >
                          Once a week
                        </AppText>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.dropdownItem}
                        onPress={() => {
                          setSelectedOption("repeat");
                          setIsOpenOption(false);
                        }}
                      >
                        <AppText
                          size="sm"
                          color={selectedOption === "repeat" ? PRIMARY : GREY}
                        >
                          Repeat
                        </AppText>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>

                <View style={styles.randomGroup}>
                  <TouchableOpacity
                    style={styles.randomRow}
                    onPress={() => setIsRandom(!isRandom)}
                    accessibilityRole="checkbox"
                    accessibilityState={{ checked: isRandom }}
                    accessibilityLabel="Choose random"
                    hitSlop={hit.text}
                  >
                    <View style={styles.checkbox}>
                      {isRandom && (
                        <AntDesign name="check" size={12} color={PRIMARY} />
                      )}
                    </View>
                    <AppText size="sm">Choose random</AppText>
                  </TouchableOpacity>

                  <View style={styles.randomRow}>
                    <Feather name="info" size={16} color={GREY} />
                    <AppText size="xs" color={GREY}>
                      Days will be reshuffled every week
                    </AppText>
                  </View>
                </View>
              </View>

              <View style={styles.days}>
                {days.map((day) => (
                  <Chip
                    key={day}
                    tone="muted"
                    label={day}
                    capitalize
                    selected={selectedDays?.includes(day)}
                    selectedBorderWidth={1}
                    onPress={() => handleDaySelection(day)}
                  />
                ))}
              </View>
            </View>

            <View style={styles.footer}>
              <Button
                title="Save"
                onPress={() => onClose()}
                variant="primary"
                size="lg"
              />
            </View>
          </View>
        </View>
      </CustomModal>
    );
  },
);

NudgeTypeModal.displayName = "NudgeTypeModal";

const styles = StyleSheet.create({
  root: { height: "100%", width: "100%" },
  daysSection: { marginBottom: space[6] },
  // `border-b border-[#48D9621A] p-6`
  preferences: {
    padding: space[6],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  preferencesTitle: { marginBottom: space[6] },
  dropdownWrap: { position: "relative", marginBottom: space[5] },
  dropdownRow: { flexDirection: "row", justifyContent: "flex-start" },
  // `bg-[#FFFFFF05] rounded-[50px] px-[10px] py-[5px] flex-row items-center gap-2`
  dropdownTrigger: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    backgroundColor: WHITE_05,
    borderRadius: radii["3xl"],
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderWidth: 0.7,
    borderColor: PRIMARY_33,
  },
  // `absolute top-0 z-20 bg-[#02231A] border-[0.5px] border-[#48D96233] rounded-[5px] w-[158px]`
  dropdownMenu: {
    position: "absolute",
    top: 0,
    zIndex: 20,
    elevation: 20,
    width: 158,
    overflow: "hidden",
    backgroundColor: SECONDARY,
    borderWidth: 0.5,
    borderColor: PRIMARY_33,
    borderRadius: radii.base,
  },
  dropdownItem: {
    paddingHorizontal: space[4],
    paddingVertical: space[3],
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  dropdownDivider: { borderBottomWidth: 1, borderBottomColor: GREY_10 },
  randomGroup: { gap: space[5] },
  randomRow: { flexDirection: "row", alignItems: "center", gap: space[2] },
  // `border border-primary w-[16px] h-[16px]`
  checkbox: {
    width: 16,
    height: 16,
    borderWidth: 1,
    borderColor: PRIMARY,
    alignItems: "center",
    justifyContent: "center",
  },
  // `flex-row items-center gap-3 flex-wrap p-6`
  days: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: space[3],
    padding: space[6],
  },
  footer: { paddingHorizontal: space[6] },
});

export default NudgeTypeModal;
