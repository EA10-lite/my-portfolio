import { SECONDARY } from "@/src/theme";
import {
  BottomSheetBackdrop,
  BottomSheetModal,
  BottomSheetView,
} from "@gorhom/bottom-sheet";
import { forwardRef, useCallback } from "react";
import { StyleSheet } from "react-native";

interface ModalProps {
  onClose?: () => void;
  children: React.ReactNode;
  snapPoints?: (string | number)[];
  showClose?: boolean;
}

const CustomModal = forwardRef<BottomSheetModal, ModalProps>(
  ({ onClose, showClose = true, children }, ref) => {
    const handleSheetChanges = useCallback(
      (index: number) => {
        // closed
        if (index === -1) {
          onClose?.();
        }
      },
      [onClose],
    );

    const renderBackdrop = useCallback(
      (props: any) => (
        <BottomSheetBackdrop
          {...props}
          disappearsOnIndex={-1}
          appearsOnIndex={0}
          opacity={0.5}
          pressBehavior="close"
          onPress={onClose}
        />
      ),
      [onClose],
    );

    return (
      <BottomSheetModal
        ref={ref}
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}
        enablePanDownToClose
        backgroundStyle={styles.container}
        handleIndicatorStyle={styles.handle}
      >
        <BottomSheetView style={styles.contentContainer}>
          {children}
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

CustomModal.displayName = "CustomModal";

const styles = StyleSheet.create({
  container: {
    backgroundColor: SECONDARY,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  handle: {
    width: 53,
    height: 4,
    backgroundColor: "#FFFFFF1A",
    marginTop: 8,
  },
  contentContainer: {
    flex: 1,
  },
});

export default CustomModal;
