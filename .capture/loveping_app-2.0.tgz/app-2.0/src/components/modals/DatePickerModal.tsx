import {
  BG_DARKER,
  CHIP_DAY_BG,
  PRIMARY,
  PRIMARY_33,
  SECONDARY,
  WHITE,
  radii,
  space, hit } from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { useMemo, useState } from "react";
import { Pressable, StyleSheet, View } from "react-native";
import Modal from "react-native-modal";
import AppText from "../ui/AppText";

type DatePickerModalProps = {
  isVisible: boolean;
  onClose: () => void;
  // onSelect returns YYYY-MM-DD for Formik / API usage
  onSelect: (value: string) => void;
  value: Date | string;
};

const DatePickerModal = ({
  isVisible,
  onClose,
  onSelect,
  value,
}: DatePickerModalProps) => {
  // Month labels used for header and formatting
  const monthNames = useMemo(
    () => [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ],
    [],
  );

  // Resolve initial selected date from the incoming value (Date or string)
  const initialDate = useMemo(() => {
    if (value instanceof Date) return value;
    if (typeof value === "string" && value.trim().length > 0) {
      const s = value.trim();
      const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
      if (iso) {
        const y = Number(iso[1]);
        const m = Number(iso[2]) - 1;
        const d = Number(iso[3]);
        const local = new Date(y, m, d);
        if (
          local.getFullYear() === y &&
          local.getMonth() === m &&
          local.getDate() === d
        ) {
          return local;
        }
      }
      const legacy = /^(\d{1,2})-([A-Za-z]+)-(\d{4})$/.exec(s);
      if (legacy) {
        const d = Number(legacy[1]);
        const monthIdx = monthNames.findIndex((name) => name === legacy[2]);
        const y = Number(legacy[3]);
        if (monthIdx >= 0 && !Number.isNaN(d) && !Number.isNaN(y)) {
          return new Date(y, monthIdx, d);
        }
      }
      const parsed = new Date(s);
      if (!isNaN(parsed.getTime())) return parsed;
    }
    return new Date();
  }, [value, monthNames]);

  const [currentMonth, setCurrentMonth] = useState<number>(
    initialDate.getMonth(),
  );
  const [currentYear, setCurrentYear] = useState<number>(
    initialDate.getFullYear(),
  );
  const [selectedDate, setSelectedDate] = useState<Date | null>(initialDate);

  // Helpers
  const getDaysInMonth = (month: number, year: number) =>
    new Date(year, month + 1, 0).getDate();
  const getFirstDayOfMonth = (month: number, year: number) =>
    new Date(year, month, 1).getDay(); // 0 = Sunday

  const daysInMonth = useMemo(
    () => getDaysInMonth(currentMonth, currentYear),
    [currentMonth, currentYear],
  );
  const firstDayIndex = useMemo(
    () => getFirstDayOfMonth(currentMonth, currentYear),
    [currentMonth, currentYear],
  );

  const toISODateString = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };

  const goPrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const goNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const goPrevYear = () => {
    setCurrentYear((y) => y - 1);
  };

  const goNextYear = () => {
    setCurrentYear((y) => y + 1);
  };

  const handleSelectDay = (day: number) => {
    const chosen = new Date(currentYear, currentMonth, day);
    setSelectedDate(chosen);
    // Immediately return the formatted value for Formik and close
    onSelect(toISODateString(chosen));
    onClose();
  };

  // Render week day labels
  const weekDays = ["S", "M", "T", "W", "T", "F", "S"];

  return (
    <Modal
      isVisible={isVisible}
      animationOut="fadeOut"
      animationIn="fadeIn"
      animationOutTiming={100}
      animationInTiming={100}
      onBackdropPress={onClose}
      backdropOpacity={0.3}
      useNativeDriverForBackdrop
      style={styles.modal}
    >
      <View style={styles.card}>
        {/* Header */}
        <View style={styles.header}>
          <AppText size="base" weight="semibold">
            Select Date
          </AppText>
          <View style={styles.navGroup}>
            <View style={styles.navPill}>
              <Pressable
                onPress={goPrevYear}
                style={styles.navButton}
                accessibilityRole="button"
                hitSlop={hit.glyph}
                accessibilityLabel="Previous year"
              >
                <Feather name="chevron-left" size={18} color={PRIMARY} />
              </Pressable>
              <AppText size="xs" weight="medium" color={PRIMARY}>
                {`${currentYear}`}
              </AppText>
              <Pressable
                onPress={goNextYear}
                style={styles.navButton}
                accessibilityRole="button"
                hitSlop={hit.glyph}
                accessibilityLabel="Next year"
              >
                <Feather name="chevron-right" size={18} color={PRIMARY} />
              </Pressable>
            </View>
            <View style={styles.navPill}>
              <Pressable
                onPress={goPrevMonth}
                style={styles.navButton}
                accessibilityRole="button"
                hitSlop={hit.glyph}
                accessibilityLabel="Previous month"
              >
                <Feather name="chevron-left" size={18} color={PRIMARY} />
              </Pressable>
              <AppText size="xs" weight="medium" color={PRIMARY}>
                {`${monthNames[currentMonth]}`}
              </AppText>
              <Pressable
                onPress={goNextMonth}
                style={styles.navButton}
                accessibilityRole="button"
                hitSlop={hit.glyph}
                accessibilityLabel="Next month"
              >
                <Feather name="chevron-right" size={18} color={PRIMARY} />
              </Pressable>
            </View>
          </View>
        </View>

        {/* Week labels */}
        <View style={styles.weekRow}>
          {weekDays.map((d, index) => (
            <AppText
              key={index}
              size="xs"
              weight="medium"
              align="center"
              style={styles.weekDay}
            >
              {d}
            </AppText>
          ))}
        </View>

        {/* Calendar grid */}
        <View style={styles.grid}>
          {/* Leading blanks */}
          {Array.from({ length: firstDayIndex }).map((_, idx) => (
            <View key={`b-${idx}`} style={styles.cell} />
          ))}

          {/* Month days */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const dayNum = i + 1;
            const isSelected =
              selectedDate?.getFullYear() === currentYear &&
              selectedDate?.getMonth() === currentMonth &&
              selectedDate?.getDate() === dayNum;

            return (
              <View key={dayNum} style={styles.cell}>
                <Pressable
                  onPress={() => handleSelectDay(dayNum)}
                  accessibilityRole="button"
                  accessibilityState={{ selected: isSelected }}
                  accessibilityLabel={`${dayNum} ${monthNames[currentMonth]} ${currentYear}`}
                  style={[
                    styles.day,
                    { backgroundColor: isSelected ? PRIMARY : CHIP_DAY_BG },
                  ]}
                >
                  <AppText
                    size="xs"
                    weight="medium"
                    color={isSelected ? SECONDARY : WHITE}
                  >
                    {dayNum}
                  </AppText>
                </Pressable>
              </View>
            );
          })}
        </View>
      </View>
    </Modal>
  );
};

const DAY_WIDTH = "14.285%";

const styles = StyleSheet.create({
  modal: { margin: 0, padding: 0 },
  // `w-[96%] mx-auto rounded-md border-[0.5px] border-primary-33 bg-secondary`
  card: {
    width: "96%",
    alignSelf: "center",
    borderRadius: radii.md,
    borderWidth: 0.5,
    borderColor: PRIMARY_33,
    backgroundColor: SECONDARY,
  },
  // `mb-4 p-4 flex-row items-center justify-between border-b border-primary-33`
  header: {
    marginBottom: space[4],
    padding: space[4],
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_33,
  },
  navGroup: { flexDirection: "row", alignItems: "center", columnGap: space[2] },
  // `flex-row items-center gap-x-2 bg-bg-darker rounded-[35px] px-2 py-1`
  navPill: {
    flexDirection: "row",
    alignItems: "center",
    columnGap: space[2],
    backgroundColor: BG_DARKER,
    borderRadius: radii["2xl"],
    paddingHorizontal: space[2],
    paddingVertical: space[1],
  },
  navButton: { padding: space[1] },
  weekRow: {
    marginBottom: space[2],
    flexDirection: "row",
    justifyContent: "space-between",
    padding: space[4],
  },
  weekDay: { width: DAY_WIDTH },
  grid: { flexDirection: "row", flexWrap: "wrap", paddingBottom: space[4] },
  cell: { marginBottom: space[3], width: DAY_WIDTH, alignItems: "center" },
  day: {
    height: 40,
    width: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default DatePickerModal;
