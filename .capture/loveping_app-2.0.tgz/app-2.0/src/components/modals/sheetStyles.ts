import { StyleSheet } from "react-native";
import { space } from "@/src/theme";

/** Layout shared by the option bottom sheets (gender, love language, ...). */
export const sheetStyles = StyleSheet.create({
  root: { position: "relative", height: "100%", width: "100%" },
  // `py-6 sm:py-8 px-6` (vertical padding applied per screen width)
  body: { paddingHorizontal: space[6] },
  // `flex-row items-center gap-5 flex-wrap` + `mb-16`
  options: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: space[5],
    marginBottom: space[16],
  },
});
