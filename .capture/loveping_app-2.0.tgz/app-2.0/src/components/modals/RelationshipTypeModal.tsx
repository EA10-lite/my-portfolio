import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { rs, space, useResponsive } from "@/src/theme";
import Button from "../Button";
import Chip from "../ui/Chip";
import SheetHeader from "../ui/SheetHeader";
import CustomModal from "./CustomModal";
import { sheetStyles } from "./sheetStyles";

type RelationshipTypeModalProps = {
  onClose: () => void;
  selectedRelationshipType: string;
  handleSelectRelationshipType: (relationshipType: string) => void;
  onSave: (selectedRelationshipType: string) => void;
};

const relationshipTypeOptions = [
  { name: "Spouse", value: "spouse" },
  { name: "Partner", value: "partner" },
];

const RelationshipTypeModal = forwardRef<
  BottomSheetModal,
  RelationshipTypeModalProps
>(
  (
    { onClose, selectedRelationshipType, handleSelectRelationshipType, onSave },
    ref,
  ) => {
    const insets = useSafeAreaInsets();
    const { isSm } = useResponsive();

    return (
      <CustomModal ref={ref} onClose={onClose} showClose={false}>
        <View style={sheetStyles.root}>
          <SheetHeader title="Relationship Type" onClose={onClose} />

          <View
            style={[
              sheetStyles.body,
              {
                paddingTop: rs(isSm, space[6], space[8]),
                paddingBottom: insets.bottom + 16,
              },
            ]}
          >
            <View style={sheetStyles.options}>
              {relationshipTypeOptions.map((option) => (
                <Chip
                  key={option.value}
                  tone="muted"
                  label={option.name}
                  selected={selectedRelationshipType === option.value}
                  onPress={() => handleSelectRelationshipType(option.value)}
                />
              ))}
            </View>

            <Button
              title="Save"
              onPress={() => onSave(selectedRelationshipType)}
              variant="primary"
              size="lg"
            />
          </View>
        </View>
      </CustomModal>
    );
  },
);

RelationshipTypeModal.displayName = "Relationship Modal";

export default RelationshipTypeModal;
