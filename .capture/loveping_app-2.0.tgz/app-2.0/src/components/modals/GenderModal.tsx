import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { rs, space, useResponsive } from "@/src/theme";
import Button from "../Button";
import Chip from "../ui/Chip";
import SheetHeader from "../ui/SheetHeader";
import CustomModal from "./CustomModal";
import { sheetStyles } from "./sheetStyles";

type GenderModalProps = {
  onClose: () => void;
  selectedGender: string;
  handleSelectGender: (gender: string) => void;
  onSave: (selectedGender: string) => void;
};

const genderOptions = [
  { name: "Male", value: "male" },
  { name: "Female", value: "female" },
  { name: "Other", value: "other" },
];

const GenderModal = forwardRef<BottomSheetModal, GenderModalProps>(
  ({ onClose, selectedGender, handleSelectGender, onSave }, ref) => {
    const insets = useSafeAreaInsets();
    const { isSm } = useResponsive();

    return (
      <CustomModal ref={ref} onClose={onClose}>
        <View style={sheetStyles.root}>
          <SheetHeader title="Gender" onClose={onClose} />

          <View
            style={[
              sheetStyles.body,
              {
                paddingTop: rs(isSm, space[6], space[8]),
                paddingBottom: insets.bottom + 16,
              },
            ]}
          >
            <View style={sheetStyles.options}>
              {genderOptions.map((gender) => (
                <Chip
                  key={gender.value}
                  tone="muted"
                  label={gender.name}
                  // Exact match: the old `includes` check also highlighted
                  // "Male" whenever "female" was selected.
                  selected={selectedGender === gender.value}
                  onPress={() => handleSelectGender(gender.value)}
                />
              ))}
            </View>

            <Button
              title="Save"
              onPress={() => onSave(selectedGender)}
              variant="primary"
              size="lg"
            />
          </View>
        </View>
      </CustomModal>
    );
  },
);

GenderModal.displayName = "Gender Modal";

export default GenderModal;
