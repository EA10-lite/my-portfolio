import { useFilterStore } from "@/src/stores";
import {
  PRIMARY,
  PRIMARY_1A,
  hit,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import Feather from "@expo/vector-icons/Feather";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Button from "../Button";
import ToneItem from "../ToneItem";
import AppText from "../ui/AppText";
import CustomModal from "./CustomModal";

type FilterModalProps = {
  onClose: () => void;
  type?: "gift" | "message";
};

const tones = [
  "Romantic",
  "Playful",
  "Encouraging",
  "Deep & Thoughtful",
  "Supportive",
  "Casual",
];

const occasions = [
  "Birthday",
  "Anniversary",
  "Just because",
  "Celebrations",
  "Apologies",
];

const giftTypes = ["Digital", "Physical"];

type FilterGroupProps = {
  title: string;
  options: string[];
  selected: string[];
  onToggle: (value: string) => void;
  style?: object;
};

const FilterGroup = ({
  title,
  options,
  selected,
  onToggle,
  style,
}: FilterGroupProps) => (
  <View style={style}>
    <AppText size="base" weight="semibold" style={styles.groupTitle}>
      {title}
    </AppText>
    <View style={styles.options}>
      {options.map((option) => (
        <ToneItem
          key={option}
          tone={option}
          isSelected={selected.includes(option)}
          onPress={() => onToggle(option)}
        />
      ))}
    </View>
  </View>
);

/** Tone + occasion (messages) or tone + type (gifts) filter sheet. */
const FilterModal = forwardRef<BottomSheetModal, FilterModalProps>(
  ({ onClose, type = "message" }, ref) => {
    const insets = useSafeAreaInsets();
    const { isSm } = useResponsive();
    // Filter state lives in the persisted Zustand store.
    const {
      selectedTones,
      selectedOccasions,
      toggleTone,
      toggleOccasion,
      clearFilters,
      selectedGiftTypes,
      toggleGiftType,
    } = useFilterStore();

    const lastGroupGap = { marginBottom: rs(isSm, space[6], space[8]) };

    return (
      <CustomModal ref={ref} onClose={onClose}>
        <View style={styles.root}>
          <View style={styles.header}>
            <AppText size="base" weight="semibold" align="center">
              {/* Was always "Filter Gifts Ideas", even on Messages. */}
              {type === "gift" ? "Filter Gift Ideas" : "Filter Messages"}
            </AppText>
            <TouchableOpacity
              onPress={onClose}
              style={styles.close}
              accessibilityRole="button"
              accessibilityLabel="Close"
              hitSlop={hit.icon}
            >
              <Feather name="x" size={18} color={PRIMARY} />
            </TouchableOpacity>
          </View>

          <ScrollView>
            <View
              style={{
                paddingTop: rs(isSm, space[6], space[8]),
                paddingHorizontal: rs(isSm, space[4], space[6]),
                paddingBottom: insets.bottom + 16,
              }}
            >
              <FilterGroup
                title="Tone"
                options={tones}
                selected={selectedTones}
                onToggle={toggleTone}
                style={{ marginBottom: rs(isSm, space[4], space[6]) }}
              />
              {type === "message" ? (
                <FilterGroup
                  title="Occasion"
                  options={occasions}
                  selected={selectedOccasions}
                  onToggle={toggleOccasion}
                  style={lastGroupGap}
                />
              ) : (
                <FilterGroup
                  title="Type"
                  options={giftTypes}
                  selected={selectedGiftTypes}
                  onToggle={toggleGiftType}
                  style={lastGroupGap}
                />
              )}

              <View style={styles.actions}>
                <Button
                  title="Apply Filters"
                  onPress={onClose}
                  variant="primary"
                  size="lg"
                />
                <Button
                  title="Clear Filters"
                  onPress={() => {
                    clearFilters();
                    onClose();
                  }}
                  variant="outline-secondary"
                  size="lg"
                />
              </View>
            </View>
          </ScrollView>
        </View>
      </CustomModal>
    );
  },
);

FilterModal.displayName = "Filter Modal";

const styles = StyleSheet.create({
  root: { position: "relative", height: "100%", width: "100%" },
  // `border-b border-primary-1A py-4`, title centred
  header: {
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
    justifyContent: "center",
  },
  // `w-[28px] h-[28px] rounded-full bg-[#48D9621A] absolute right-6`.
  // The original `top-1/2` had no translate, so the button sat below centre.
  close: {
    position: "absolute",
    right: space[6],
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: PRIMARY_1A,
    alignItems: "center",
    justifyContent: "center",
  },
  groupTitle: { marginBottom: space[4] },
  // `flex-row items-center gap-2 gap-y-4 flex-wrap`
  options: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    columnGap: space[2],
    rowGap: space[4],
  },
  actions: { gap: space[4] },
});

export default FilterModal;
