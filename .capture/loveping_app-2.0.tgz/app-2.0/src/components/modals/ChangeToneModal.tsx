import { TONES } from "@/src/constants/data";
import { GREY, space } from "@/src/theme";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { forwardRef } from "react";
import { StyleSheet, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Button from "../Button";
import ToneItem from "../ToneItem";
import AppText from "../ui/AppText";
import SheetHeader from "../ui/SheetHeader";
import CustomModal from "./CustomModal";

type ChangeToneModalProps = {
  onClose: () => void;
  selectedTones: string[];
  handleSelectTone: (tone: string) => void;
  handleUpdate: () => void;
  handleClear: () => void;
  loading?: boolean;
};

/** Pick up to two tones for a message. */
const ChangeToneModal = forwardRef<BottomSheetModal, ChangeToneModalProps>(
  (
    {
      onClose,
      selectedTones,
      handleSelectTone,
      loading = false,
      handleUpdate,
      handleClear,
    },
    ref,
  ) => {
    const insets = useSafeAreaInsets();

    return (
      <CustomModal ref={ref} onClose={onClose}>
        <View style={styles.root}>
          <SheetHeader title="Change Tone" onClose={onClose} />

          <View style={[styles.body, { paddingBottom: insets.bottom + 16 }]}>
            <View style={styles.section}>
              <AppText
                size="base"
                weight="medium"
                color={GREY}
                style={styles.hint}
              >
                Select Multiple (2 MAX)
              </AppText>
              <View style={styles.tones}>
                {TONES.map((tone) => (
                  <ToneItem
                    key={tone.value}
                    tone={tone.name}
                    isSelected={
                      selectedTones.includes(tone.value) ||
                      selectedTones?.includes(tone.name)
                    }
                    onPress={() => handleSelectTone(tone.value || tone.name)}
                  />
                ))}
              </View>
            </View>

            <View style={styles.actions}>
              <Button
                title="Update"
                onPress={handleUpdate}
                variant="primary"
                size="lg"
                loading={loading}
              />
              <Button
                title="Clear Selection"
                onPress={handleClear}
                variant="outline-secondary"
                size="lg"
              />
            </View>
          </View>
        </View>
      </CustomModal>
    );
  },
);

ChangeToneModal.displayName = "Change Tone Modal";

const styles = StyleSheet.create({
  root: { position: "relative", height: "100%", width: "100%" },
  // `py-8 px-6`
  body: { paddingTop: space[8], paddingHorizontal: space[6] },
  section: { marginBottom: space[16] },
  hint: { marginBottom: space[4] },
  tones: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: space[5],
  },
  actions: { gap: space[4] },
});

export default ChangeToneModal;
