import { router } from "expo-router";
import { StyleSheet, View } from "react-native";
import { PRIMARY_1A, space, useGutter } from "../theme";
import GoBack from "./GoBack";
import AppText from "./ui/AppText";

type HeaderProps = {
  title: string;
  step?: number;
  goBack?: () => void;
  rightAction?: React.ReactNode;
};

/** Page header: back button, centred title, optional right-hand action. */
const Header = ({ title, goBack, rightAction }: HeaderProps) => {
  const px = useGutter();
  return (
    <View style={[styles.header, { paddingHorizontal: px }]}>
      <View style={styles.side}>
        <GoBack onPress={goBack ? goBack : () => router.back()} />
      </View>
      <AppText
        size="base"
        weight="semibold"
        align="center"
        numberOfLines={1}
        style={styles.title}
        accessibilityRole="header"
      >
        {title}
      </AppText>
      <View style={[styles.side, styles.right]}>{rightAction}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  // `border-b border-primary-1A py-4 flex-row items-center justify-between`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  side: { minWidth: space[14.5] },
  right: { alignItems: "flex-end" },
  title: { flex: 1, paddingHorizontal: space[2] },
});

export default Header;
