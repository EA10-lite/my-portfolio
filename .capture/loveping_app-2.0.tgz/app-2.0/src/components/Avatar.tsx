import { WHITE, space } from "@/src/theme";
import { Image, StyleSheet, View } from "react-native";
import AppText from "./ui/AppText";

type AvatarProps = {
  image?: string;
  initials: string;
  size?: "sm" | "md" | "lg";
};

// `w-10 h-10`, `w-12.5 h-12.5`, `w-15 h-15`
const dimension = { sm: space[10], md: space[12.5], lg: space[15] };

const getInitials = (name: string) => {
  if (!name || name.trim().length === 0) {
    return "??";
  }

  // Remove extra spaces and split into words
  const words = name
    .trim()
    .split(/\s+/)
    .filter((word) => word.length > 0);

  if (words.length === 0) {
    return "??";
  }

  if (words.length === 1) {
    // Single word: take first 2 letters (or repeat first letter if only 1 character)
    const firstWord = words[0];
    const initials = firstWord.substring(0, 2).toUpperCase();
    return initials.length === 1 ? initials + initials : initials;
  }
  // Multiple words: first letter of first word and first letter of last word
  const firstInitial = words[0][0];
  const lastInitial = words[words.length - 1][0];
  return (firstInitial + lastInitial).toUpperCase();
};

const Avatar = ({ image, initials, size = "md" }: AvatarProps) => {
  const d = dimension[size];
  return (
    <View
      style={[styles.circle, { width: d, height: d, borderRadius: d / 2 }]}
      accessibilityRole="image"
      accessibilityLabel={initials}
    >
      {image ? (
        <Image source={{ uri: image }} style={styles.image} />
      ) : (
        <AppText
          size="base"
          weight="medium"
          color="#000000"
          align="center"
          style={styles.initials}
        >
          {getInitials(initials)}
        </AppText>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  circle: {
    backgroundColor: WHITE,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
  image: { width: "100%", height: "100%" },
  initials: { textTransform: "uppercase" },
});

export default Avatar;
