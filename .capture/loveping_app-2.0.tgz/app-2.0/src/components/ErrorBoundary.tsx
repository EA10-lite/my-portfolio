/**
 * Error Boundary Component
 * 
 * Catches JavaScript errors anywhere in the child component tree,
 * logs those errors, and displays a fallback UI instead of crashing the app.
 * 
 * This component should wrap the root of your app or major sections
 * to prevent the entire app from crashing due to a single component error.
 */

import { logError } from '@/src/services/crashLogger';
import React, { Component, ErrorInfo, ReactNode } from 'react';
import {
  ERROR,
  GREY_AF,
  PRIMARY,
  SECONDARY,
  WHITE_08,
  WHITE_80,
  radii,
  space,
} from '@/src/theme';
import { Platform, ScrollView, StyleSheet, TouchableOpacity, View } from 'react-native';
import AppText from './ui/AppText';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI
    return {
      hasError: true,
      error,
      errorInfo: null,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log the error to crash reporting service
    logError(error, {
      componentStack: errorInfo.componentStack,
      errorBoundary: true,
    });

    // Call custom error handler if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Update state with error info
    this.setState({
      error,
      errorInfo,
    });
  }

  handleReset = () => {
    // Reset error boundary state
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
    });
  };

  render() {
    if (this.state.hasError) {
      // Render custom fallback UI if provided
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default fallback UI
      return (
        <View style={styles.screen}>
          <ScrollView style={styles.full} contentContainerStyle={styles.content}>
            <AppText size="2xl" weight="bold" style={styles.title} accessibilityRole="header">
              Something went wrong
            </AppText>
            <AppText size="base" color={WHITE_80} align="center" style={styles.body}>
              We&apos;re sorry for the inconvenience. The error has been logged and we&apos;ll look into it.
            </AppText>

            {__DEV__ && this.state.error && (
              <View style={styles.debug}>
                <AppText size="sm" color={ERROR} style={[styles.mono, styles.debugTitle]}>
                  {this.state.error.toString()}
                </AppText>
                {this.state.errorInfo && (
                  <AppText size="xs" color={GREY_AF} style={styles.mono}>
                    {this.state.errorInfo.componentStack}
                  </AppText>
                )}
              </View>
            )}

            <TouchableOpacity
              style={styles.button}
              onPress={this.handleReset}
              accessibilityRole="button"
            >
              <AppText weight="semibold">Try Again</AppText>
            </TouchableOpacity>
          </ScrollView>
        </View>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;


const styles = StyleSheet.create({
  // `flex-1 bg-secondary justify-center items-center p-6`
  screen: {
    flex: 1,
    backgroundColor: SECONDARY,
    justifyContent: 'center',
    alignItems: 'center',
    padding: space[6],
  },
  full: { width: '100%' },
  content: { alignItems: 'center' },
  title: { marginBottom: space[4] },
  body: { marginBottom: space[6] },
  // `w-full mb-4 p-4 bg-white-08 rounded-lg`
  debug: {
    width: '100%',
    marginBottom: space[4],
    padding: space[4],
    backgroundColor: WHITE_08,
    borderRadius: radii.lg,
  },
  debugTitle: { marginBottom: space[2] },
  mono: { fontFamily: Platform.select({ ios: 'Menlo', default: 'monospace' }) },
  // `bg-primary px-6 py-3 rounded-lg`
  button: {
    backgroundColor: PRIMARY,
    paddingHorizontal: space[6],
    paddingVertical: space[3],
    borderRadius: radii.lg,
  },
});
