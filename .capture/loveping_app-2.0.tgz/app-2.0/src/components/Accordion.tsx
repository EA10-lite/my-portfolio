import { GREY_90, PRIMARY, PRIMARY_1A, WHITE_08, radii, rs, space, useResponsive } from "@/src/theme";
import { MaterialIcons } from "@expo/vector-icons";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import AppText from "./ui/AppText";

type AccordionProps = {
  title: string;
  content: string;
  isOpen: boolean;
  toggleAccordion: () => void;
};

/** Expandable question/answer card (FAQ). */
const Accordion = ({ title, content, isOpen, toggleAccordion }: AccordionProps) => {
  const { isSm } = useResponsive();
  const padding = rs(isSm, space[4], space[5]);
  return (
    <TouchableOpacity
      onPress={toggleAccordion}
      accessibilityRole="button"
      accessibilityState={{ expanded: isOpen }}
    >
      <View style={styles.card}>
        <View style={[styles.header, { padding }, isOpen && styles.headerOpen]}>
          <AppText size="sm" weight="medium" style={styles.title}>
            {title}
          </AppText>
          <MaterialIcons
            name={isOpen ? "keyboard-arrow-up" : "keyboard-arrow-down"}
            size={24}
            color={PRIMARY}
          />
        </View>

        {isOpen && (
          <View style={{ padding }}>
            <AppText size="xs" weight="medium" color={GREY_90} style={styles.body}>
              {content}
            </AppText>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  // `border border-primary-1A rounded-md bg-white-08`
  card: {
    borderWidth: 1,
    borderColor: PRIMARY_1A,
    borderRadius: radii.md,
    backgroundColor: WHITE_08,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerOpen: { borderBottomWidth: 1, borderBottomColor: PRIMARY_1A },
  title: { flexShrink: 1 },
  body: { lineHeight: 18 },
});

export default Accordion;
