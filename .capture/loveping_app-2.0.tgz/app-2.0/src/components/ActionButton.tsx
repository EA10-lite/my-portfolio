import { PRIMARY, PRIMARY_08, PRIMARY_1A } from "@/src/theme";
import { StyleSheet, TouchableOpacity } from "react-native";
import Loader from "./Loader";

type ActionButtonProps = {
  icon: React.ReactNode;
  onPress: () => void;
  bgColor?: string;
  borderColor?: string;
  hasBorder?: boolean;
  loading?: boolean;
  /** Screen-reader label; icon-only buttons need one. */
  accessibilityLabel?: string;
};

/** 40px round icon button. */
const ActionButton = ({
  icon,
  onPress,
  bgColor = PRIMARY_08,
  borderColor = PRIMARY_1A,
  hasBorder = true,
  loading = false,
  accessibilityLabel,
}: ActionButtonProps) => {
  return (
    <TouchableOpacity
      style={[
        styles.button,
        {
          backgroundColor: bgColor,
          borderColor: borderColor,
          borderWidth: hasBorder ? 1 : 0,
        },
      ]}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      accessibilityState={{ busy: loading }}
      hitSlop={4}
    >
      {loading ? <Loader size={16} color={PRIMARY} /> : icon}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  // `w-10 h-10 rounded-full items-center justify-center`
  button: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default ActionButton;
