import React from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import {
  PRIMARY,
  SECONDARY,
  WHITE,
  WHITE_05,
  radii,
  rs,
  slopFor,
  space,
  useResponsive,
} from "../theme";
import AppText from "./ui/AppText";

interface ReusableTabProps {
  tabs: TabProps[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  children?: React.ReactNode;
}

type TabProps = {
  id: string;
  label: string;
  content?: React.ReactNode;
};

/**
 * Pill tab bar plus the active tab's content.
 *
 * @example
 * <ReusableTab tabs={[{ id: "saved", label: "Saved", content: <Saved /> }]}
 *   activeTab={tab} onTabChange={setTab} />
 */
const ReusableTab = ({
  tabs,
  activeTab,
  onTabChange,
  children,
}: ReusableTabProps) => {
  const { isSm } = useResponsive();
  const activeTabContent = tabs.find((tab) => tab.id === activeTab)?.content;

  return (
    <View style={styles.fill}>
      <View
        accessibilityRole="tablist"
        style={[
          styles.bar,
          {
            gap: rs(isSm, space[3], space[5]),
            paddingVertical: rs(isSm, space[4], space[6]),
            paddingHorizontal: rs(isSm, space[4], space[6]),
          },
        ]}
      >
        {tabs.map((tab) => (
          <TabItem
            key={tab.id}
            label={tab.label}
            active={activeTab === tab.id}
            onClick={() => onTabChange(tab.id)}
          />
        ))}
      </View>

      <View style={styles.fill}>{children || activeTabContent}</View>
    </View>
  );
};

interface TabItemProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

const TAB_HEIGHT = 40;

const TabItem = ({ label, onClick, active }: TabItemProps) => {
  const { isSm } = useResponsive();
  return (
    <TouchableOpacity
      onPress={onClick}
      accessibilityRole="tab"
      accessibilityState={{ selected: active }}
      hitSlop={slopFor(TAB_HEIGHT)}
      style={[
        styles.tab,
        { paddingHorizontal: rs(isSm, space[4], space[6]) },
        { backgroundColor: active ? PRIMARY : WHITE_05 },
      ]}
    >
      <AppText
        size={isSm ? "sm" : "xs"}
        weight="medium"
        align="center"
        color={active ? SECONDARY : WHITE}
      >
        {label}
      </AppText>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  bar: { flexDirection: "row", alignItems: "center" },
  // `h-[40px] items-center justify-center rounded-2xl`
  tab: {
    height: TAB_HEIGHT,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: radii["2xl"],
  },
});

export default ReusableTab;
