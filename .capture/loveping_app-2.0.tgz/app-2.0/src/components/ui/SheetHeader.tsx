import Feather from "@expo/vector-icons/Feather";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { PRIMARY, PRIMARY_1A, space, hit } from "@/src/theme";
import AppText from "./AppText";

type SheetHeaderProps = {
  title: string;
  onClose: () => void;
};

/** Title row + round close button shared by the bottom sheets. */
const SheetHeader = ({ title, onClose }: SheetHeaderProps) => (
  <View style={styles.header}>
    <AppText size="base" weight="semibold">
      {title}
    </AppText>
    <TouchableOpacity
      onPress={onClose}
      style={styles.close}
      accessibilityRole="button"
      accessibilityLabel="Close"
      hitSlop={hit.icon}
    >
      <Feather name="x" size={18} color={PRIMARY} />
    </TouchableOpacity>
  </View>
);

const styles = StyleSheet.create({
  // `border-b border-[#48D9621A] py-4 px-6 flex-row items-center justify-between`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: space[4],
    paddingHorizontal: space[6],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  // `w-[28px] h-[28px] rounded-full bg-[#48D9621A]`
  close: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: PRIMARY_1A,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default SheetHeader;
