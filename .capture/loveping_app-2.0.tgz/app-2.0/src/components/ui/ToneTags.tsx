import { TONES } from "@/src/constants/data";
import { PRIMARY, WHITE, WHITE_08, hit, radii, space } from "@/src/theme";
import {
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  View,
  ViewStyle,
} from "react-native";
import AppText from "./AppText";

/** Display name for a tone value (`deep_n_thoughtful` -> `Deep & Thoughtful`). */
export const toneLabel = (tone: string) =>
  TONES.find((t) => t.value?.toLowerCase() === tone?.toLowerCase())?.name ||
  tone;

type ToneTagsProps = {
  tones: string[];
  /** Shows a "Change Tone" pill when set. */
  onChangeTone?: () => void;
  style?: StyleProp<ViewStyle>;
};

/**
 * Row of read-only tone pills plus an optional "Change Tone" action.
 * `bg-white-08 border border-white-08 rounded-lg px-2.5 py-1.5 text-xs`
 */
const ToneTags = ({ tones, onChangeTone, style }: ToneTagsProps) => (
  <View style={[styles.row, style]}>
    {tones.map((tone) => (
      <View key={tone} style={styles.pill}>
        <AppText
          size="xs"
          weight="medium"
          color={WHITE}
          style={styles.capitalize}
        >
          {toneLabel(tone)}
        </AppText>
      </View>
    ))}
    {onChangeTone && (
      <TouchableOpacity
        style={styles.pill}
        onPress={onChangeTone}
        accessibilityRole="button"
        hitSlop={hit.pill}
      >
        <AppText size="xs" weight="medium" color={PRIMARY}>
          Change Tone
        </AppText>
      </TouchableOpacity>
    )}
  </View>
);

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: space[4],
  },
  pill: {
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: WHITE_08,
    borderRadius: radii.lg,
    paddingHorizontal: space[2.5],
    paddingVertical: space[1.5],
  },
  capitalize: { textTransform: "capitalize" },
});

export default ToneTags;
