import { FontAwesome6 } from "@expo/vector-icons";
import { StyleProp, StyleSheet, TouchableOpacity, ViewStyle } from "react-native";
import {
  GREY,
  PRIMARY,
  PRIMARY_1A,
  WHITE_05,
  radii,
  space, hit } from "@/src/theme";
import AppText from "./AppText";

type ChipProps = {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  /**
   * `accent`: tone chips (label and tick turn green when selected).
   * `muted`: option chips in bottom sheets (grey label and tick).
   */
  tone?: "accent" | "muted";
  /** Border width when selected (sheets use 0.5, day chips 1). */
  selectedBorderWidth?: number;
  capitalize?: boolean;
  style?: StyleProp<ViewStyle>;
};

/** Selectable pill used for tones, genders, love languages and days. */
const Chip = ({
  label,
  selected = false,
  onPress,
  tone = "accent",
  selectedBorderWidth,
  capitalize,
  style,
}: ChipProps) => {
  const accent = tone === "accent";
  const borderWidth = selected ? (selectedBorderWidth ?? (accent ? 1 : 0.5)) : 0;
  return (
    <TouchableOpacity
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected }}
      hitSlop={hit.pill}
      style={[
        styles.base,
        accent ? styles.accent : styles.muted,
        { borderWidth, borderColor: PRIMARY_1A },
        style,
      ]}
    >
      <AppText
        size="sm"
        weight={accent ? "medium" : "regular"}
        color={accent && selected ? PRIMARY : GREY}
        style={capitalize ? styles.capitalize : undefined}
      >
        {label}
      </AppText>
      {selected && (
        <FontAwesome6
          name="circle-check"
          size={14}
          color={accent ? PRIMARY : GREY}
        />
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: space[2],
    backgroundColor: WHITE_05,
  },
  // `rounded-3xl p-2.5 px-6`
  accent: {
    borderRadius: radii["3xl"],
    paddingVertical: space[2.5],
    paddingHorizontal: space[6],
  },
  // `rounded-[50px] px-4 py-1.5`
  muted: {
    borderRadius: radii["3xl"],
    paddingVertical: space[1.5],
    paddingHorizontal: space[4],
  },
  capitalize: { textTransform: "capitalize" },
});

export default Chip;
