import { StyleSheet, Text, TextProps, TextStyle } from "react-native";
import {
  FontSizeKey,
  FontWeightKey,
  WHITE,
  fontSize as sizes,
  weight as weights,
} from "@/src/theme";

export type AppTextProps = TextProps & {
  /** Tailwind-equivalent size: xs 12/16, sm 14/20, base 16/24, lg 18/28 ... */
  size?: FontSizeKey;
  weight?: FontWeightKey;
  color?: string;
  align?: TextStyle["textAlign"];
  italic?: boolean;
};

/**
 * Text with the app's type scale. Replaces class stacks such as
 * `text-sm font-inter-medium text-white`.
 */
const AppText = ({
  size = "sm",
  weight = "regular",
  color = WHITE,
  align,
  italic,
  style,
  ...rest
}: AppTextProps) => (
  <Text
    {...rest}
    style={[
      sizes[size],
      weights[weight],
      { color },
      align ? { textAlign: align } : null,
      italic ? styles.italic : null,
      style,
    ]}
  />
);

const styles = StyleSheet.create({
  italic: { fontStyle: "italic" },
});

export default AppText;
