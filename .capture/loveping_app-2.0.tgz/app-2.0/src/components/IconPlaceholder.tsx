import HexIcon from "@/assets/icons/hexagon.svg";
import { StyleSheet, View } from "react-native";

/** Hexagon badge with an icon centred on top of it. */
const IconPlaceholder = ({ icon }: { icon: React.ReactNode }) => {
  return (
    <View style={styles.container}>
      <HexIcon />
      <View style={styles.overlay}>{icon}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: "center", justifyContent: "center" },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default IconPlaceholder;
