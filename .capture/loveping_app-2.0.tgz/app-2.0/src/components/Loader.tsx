import { AntDesign } from "@expo/vector-icons";
import React, { useEffect, useRef } from "react";
import { Animated, Easing } from "react-native";

type LoadingProps = {
    size?:   number;
    color?:  string;
}

const Loader = ({ size = 32, color = "#fff"} : LoadingProps) => {
    const spinValue = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        const animation = Animated.loop(
          Animated.timing(spinValue, {
            toValue: 1,
            duration: 800,
            easing: Easing.linear,
            useNativeDriver: true,
          })
        );
        animation.start();
        return () => {
          animation.stop();   // 🚨 THIS LINE PREVENTS THE CRASH
        };
    }, [spinValue]);

    const spin = spinValue.interpolate({
        inputRange: [0, 1],
        outputRange: ['0deg', '360deg'],
    });

    return (
        <Animated.View style={{ transform: [{ rotate: spin }] }}>
            <AntDesign name="loading-3-quarters" size={size} color={color} />
        </Animated.View>
    )
}

export default Loader;