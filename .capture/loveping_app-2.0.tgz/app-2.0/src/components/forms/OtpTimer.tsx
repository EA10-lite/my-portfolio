import { WHITE, WHITE_08, radii, space, hit } from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import AppText from "../ui/AppText";

type OtpTimerProps = {
  isRunning: boolean;
  timeLeft: number;
  onResend: () => void;
  disabled?: boolean;
};

/** "OTP Expires in: 42s" pill, or the "Resend New OTP" link once it runs out. */
const OtpTimer = ({ isRunning, timeLeft, onResend, disabled }: OtpTimerProps) => (
  <View style={styles.container}>
    {isRunning ? (
      <View style={styles.pill} accessibilityLiveRegion="polite">
        <Feather name="info" size={16} color={WHITE} />
        <AppText size="sm" weight="medium">
          OTP Expires in: {timeLeft}s
        </AppText>
      </View>
    ) : (
      <TouchableOpacity
        onPress={onResend}
        disabled={disabled}
        accessibilityRole="button"
        hitSlop={hit.text}
      >
        <AppText size="sm" weight="medium" align="center">
          Resend New OTP
        </AppText>
      </TouchableOpacity>
    )}
  </View>
);

const styles = StyleSheet.create({
  container: { marginTop: space[4] },
  // `flex-row items-center justify-center gap-2 px-2.5 py-1 rounded-2xl bg-white-08 w-fit mx-auto`
  pill: {
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: space[2],
    paddingHorizontal: space[2.5],
    paddingVertical: space[1],
    borderRadius: radii["2xl"],
    backgroundColor: WHITE_08,
  },
});

export default OtpTimer;
