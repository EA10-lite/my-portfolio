import { WHITE, fontSize, radii, space } from "@/src/theme";
import { FormikValues, useFormikContext } from "formik";
import React, { useEffect, useRef, useState } from "react";
import { StyleSheet, TextInput, View } from "react-native";
import AppText from "../ui/AppText";
import { fieldBorderColor, isFilled } from "./fieldBorder";

interface OTPInputProps {
  numInputs: number;
  label?: string;
  name: string;
  disabled?: boolean;
}

const OTPInput: React.FC<OTPInputProps> = ({
  numInputs = 6,
  label,
  name,
  disabled = false,
}) => {
  const { errors, touched, values, setFieldValue, handleSubmit } =
    useFormikContext<FormikValues>();

  const [isFocused, setIsFocused] = useState<number>(-1);
  const [otpValues, setOtpValues] = useState<string[]>(
    new Array(numInputs).fill(""),
  );

  const inputsRef = useRef<TextInput[]>([]);

  const handleChange = (value: string, index: number) => {
    if (value.match(/^\d*$/)) {
      const chars = value.split("");
      let newOtp = [...otpValues];

      if (chars.length > 1) {
        // Handle paste (user typed multiple digits quickly)
        newOtp = chars.slice(0, numInputs);
        setOtpValues(newOtp);
        setFieldValue(name, newOtp.join(""));
        return;
      }

      newOtp[index] = value;
      setOtpValues(newOtp);
      setFieldValue(name, newOtp.join(""));

      if (value && index < numInputs - 1) {
        inputsRef.current[index + 1]?.focus();
      }
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    if (e.nativeEvent.key === "Backspace" && !otpValues[index] && index > 0) {
      inputsRef.current[index - 1]?.focus();
    } else if (e.nativeEvent.key === "Enter") {
      handleSubmit();
    }
  };

  useEffect(() => {
    const fieldValue = values[name];
    if (fieldValue) {
      const splitOtpValues = fieldValue.split("").slice(0, numInputs);
      setOtpValues(
        splitOtpValues.concat(
          new Array(numInputs - splitOtpValues.length).fill(""),
        ),
      );
    }
  }, [values, name, numInputs]);

  return (
    <View style={styles.container}>
      {/* Label (kept even when empty so spacing matches the previous layout) */}
      <AppText size="sm" weight="medium" color="#374151" style={styles.label}>
        {label}
      </AppText>

      <View style={styles.row}>
        {otpValues.map((val, index) => (
          <TextInput
            key={index}
            ref={(el) => {
              if (el) {
                inputsRef.current[index] = el;
              }
            }}
            accessibilityLabel={`Digit ${index + 1} of ${numInputs}`}
            value={val}
            editable={!disabled}
            onChangeText={(text) => handleChange(text, index)}
            onKeyPress={(e) => handleKeyPress(e, index)}
            onFocus={() => setIsFocused(index)}
            onBlur={() => setIsFocused(-1)}
            maxLength={1}
            keyboardType="number-pad"
            returnKeyType="done"
            secureTextEntry={true}
            // Stops iOS offering "Use Strong Password" on these secure boxes.
            textContentType="oneTimeCode"
            importantForAutofill="no"
            autoComplete="off"
            style={[
              styles.box,
              {
                borderColor: fieldBorderColor({
                  hasError: !!(touched[name] && errors[name]),
                  active: isFocused === index || isFilled(val),
                }),
              },
            ]}
          />
        ))}
      </View>

      {touched[name] && errors[name] && (
        <AppText size="xs" color="#EF4444" style={styles.error}>
          {errors[name] as string}
        </AppText>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { width: "100%", marginBottom: space[4] },
  label: { marginBottom: space[2] },
  row: { flexDirection: "row", width: "100%", gap: space[2] },
  box: {
    flex: 1,
    aspectRatio: 1,
    textAlignVertical: "center",
    textAlign: "center",
    fontSize: fontSize.lg.fontSize,
    lineHeight: 24,
    color: WHITE,
    borderWidth: 1,
    borderRadius: radii.md,
    backgroundColor: "transparent",
  },
  error: { marginTop: space[1] },
});

export default OTPInput;
