import { ERROR, PRIMARY, PRIMARY_1A } from "@/src/theme";

/**
 * One border rule for every form field:
 * error (shown once the field is touched) > active (focused or filled) > idle.
 */
export const fieldBorderColor = ({
  hasError,
  active,
}: {
  hasError: boolean;
  active: boolean;
}) => (hasError ? ERROR : active ? PRIMARY : PRIMARY_1A);

/** A field counts as filled when it holds a non-empty string or array. */
export const isFilled = (value: unknown) =>
  Array.isArray(value)
    ? value.length > 0
    : value !== undefined && value !== null && String(value).trim() !== "";
