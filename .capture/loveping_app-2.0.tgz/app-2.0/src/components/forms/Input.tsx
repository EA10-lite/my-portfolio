import {
  GREY,
  PRIMARY,
  PRIMARY_08,
  fontSize,
  radii,
  space,
  weight, hit } from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { FormikValues, useFormikContext } from "formik";
import React, { useRef, useState } from "react";
import {
  KeyboardTypeOptions,
  Platform,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { fieldBorderColor, isFilled } from "./fieldBorder";
import AppText from "../ui/AppText";
import Error from "./Error";

type fieldProps = {
  name: string;
  label?: string;
  placeholder?: string;
  type?: KeyboardTypeOptions | undefined;
  disabled?: boolean;
  Icon?: React.ElementType;
  isSecureText?: boolean;
  mandatory?: boolean;
  value?: string;
  isPassword?: boolean;
  optional?: boolean;
};

const Input = ({
  name,
  label,
  placeholder,
  type = "default",
  isSecureText,
  mandatory,
  disabled,
  value,
  isPassword = true,
  optional = false,
}: fieldProps) => {
  const { values, errors, touched, handleChange } =
    useFormikContext<FormikValues>();
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [showPassword, setShowPassword] = useState<boolean>(false);

  const inputRef = useRef<TextInput>(null);
  const inputAccessoryViewID = `${name}-inputAccessory`;

  return (
    <View style={styles.container}>
      {label && (
        <View style={styles.labelRow}>
          <AppText size="base" weight="medium" style={styles.label}>
            {label}
            <AppText size="base" color="#DC2626">
              {mandatory && "*"}
            </AppText>
          </AppText>
          {optional && (
            <View style={styles.optional}>
              <AppText size="xs" weight="bold" color={PRIMARY} align="center">
                optional
              </AppText>
            </View>
          )}
        </View>
      )}

      <View>
        <TextInput
          ref={inputRef}
          accessibilityLabel={label}
          style={[
            styles.input,
            {
              borderColor: fieldBorderColor({
                hasError: !!(errors[name] && touched[name]),
                active: isFocused || isFilled(value ? value : values[name]),
              }),
            },
            {
              textAlignVertical: Platform.OS === "ios" ? "top" : "center",
              lineHeight: Platform.OS === "ios" ? 0 : 24,
            },
          ]}
          placeholder={placeholder}
          placeholderTextColor={GREY}
          keyboardType={type}
          onChangeText={handleChange(name)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
          }}
          value={value ? value : values[name]}
          secureTextEntry={isSecureText && !showPassword}
          inputAccessoryViewID={
            Platform.OS === "ios" ? inputAccessoryViewID : undefined
          }
          /**
           * Block iOS "Use Strong Password" on secure fields: users pick their
           * own memorable password. `"none"` and empty `passwordRules` don't
           * stop it (iOS still guesses a sign-up form from the field layout);
           * `"oneTimeCode"` does, since iOS never offers generated passwords
           * for one-time-code fields. Trade-off: no Keychain autofill here.
           * Applied whether or not the password is currently shown, so the
           * suggestion can't appear after toggling the eye icon.
           */
          textContentType={
            Platform.OS === "ios" && isSecureText ? "oneTimeCode" : undefined
          }
          // Android: keep Google autofill from offering to save or generate.
          importantForAutofill={isSecureText ? "no" : undefined}
          editable={disabled ? false : true}
          autoComplete="off"
          autoCapitalize="none"
          autoCorrect={false}
          spellCheck={false}
        />
        {isSecureText && isPassword && (
          <TouchableOpacity
            style={styles.eye}
            onPress={() => setShowPassword((prev) => !prev)}
            accessibilityRole="button"
            accessibilityLabel={showPassword ? "Hide password" : "Show password"}
            hitSlop={hit.icon}
          >
            <Feather
              name={showPassword ? "eye-off" : "eye"}
              size={20}
              color={PRIMARY}
            />
          </TouchableOpacity>
        )}

        {errors[name] && touched[name] && (!isPassword || !isSecureText) && (
          <View style={styles.errorIcon} pointerEvents="none">
            <Feather name="info" size={20} color={PRIMARY} />
          </View>
        )}
      </View>

      <Error
        error={errors?.[name] as string | undefined}
        visible={!!touched[name]}
      />
    </View>
  );
};

const INPUT_HEIGHT = 56;

const styles = StyleSheet.create({
  container: { marginBottom: space[4] },
  labelRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    marginBottom: space[1],
  },
  label: { marginBottom: space[1] },
  // `min-w-15 px-2.5 border border-primary-08 bg-primary-08 rounded-2xl py-1.5`
  optional: {
    minWidth: space[15],
    paddingHorizontal: space[2.5],
    paddingVertical: space[1.5],
    borderWidth: 1,
    borderColor: PRIMARY_08,
    backgroundColor: PRIMARY_08,
    borderRadius: radii["2xl"],
  },
  // `w-full rounded-2xl text-left text-base text-grey font-medium px-5 border`
  input: {
    width: "100%",
    height: INPUT_HEIGHT,
    borderRadius: radii["2xl"],
    borderWidth: 1,
    paddingHorizontal: space[5],
    fontSize: fontSize.base.fontSize,
    ...weight.medium,
    color: GREY,
    textAlign: "left",
  },
  eye: { position: "absolute", right: space[4], top: space[4] },
  errorIcon: {
    position: "absolute",
    right: space[4],
    top: (INPUT_HEIGHT - 20) / 2,
  },
});

export default Input;
