import { GREY, PRIMARY, PRIMARY_1A, radii, space } from "@/src/theme";
import { MaterialIcons } from "@expo/vector-icons";
import { FormikContext } from "formik";
import React, { useContext } from "react";
import {
  KeyboardTypeOptions,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import AppText from "../ui/AppText";
import { fieldBorderColor, isFilled } from "./fieldBorder";

type fieldProps = {
  name: string;
  label?: string;
  placeholder?: string;
  type?: KeyboardTypeOptions | undefined;
  disabled?: boolean;
  Icon?: React.ElementType;
  value?: string;
  onPress?: () => void;
  icon?: React.ReactNode;
};

/** Read-only field that opens a picker (sheet or date picker) when tapped. */
const Select = ({ name, label, placeholder, value, onPress, icon }: fieldProps) => {
  // Optional: a Select outside a Formik form still works (no error state).
  const formik = useContext(FormikContext);
  const hasError = !!(formik?.errors?.[name] && formik?.touched?.[name]);
  const borderColor = fieldBorderColor({ hasError, active: isFilled(value) });
  return (
    <View style={styles.container}>
      {label && (
        <View style={styles.labelWrap}>
          <AppText size="base" weight="medium" style={styles.label}>
            {label}
          </AppText>
        </View>
      )}

      <TouchableOpacity
        style={[styles.field, { borderColor }]}
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={label}
        accessibilityValue={{ text: value || placeholder }}
      >
        <AppText
          size="base"
          weight="medium"
          color={GREY}
          style={styles.value}
        >
          {value || placeholder}
        </AppText>
        {icon || (
          <MaterialIcons name="keyboard-arrow-down" size={24} color={PRIMARY} />
        )}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { marginBottom: space[4] },
  labelWrap: { marginBottom: space[1] },
  label: { marginBottom: space[1] },
  // `w-full flex-row items-center justify-between rounded-2xl px-5 py-3.5 border border-primary-1A`
  field: {
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: radii["2xl"],
    paddingHorizontal: space[5],
    paddingVertical: space[3.5],
    borderWidth: 1,
    borderColor: PRIMARY_1A,
  },
  value: { textTransform: "capitalize", flexShrink: 1 },
});

export default Select;
