import { PRIMARY, space, hit } from "@/src/theme";
import { AntDesign } from "@expo/vector-icons";
import { FormikValues, useFormikContext } from "formik";
import React from "react";
import { Pressable, StyleSheet, View } from "react-native";
import AppText from "../ui/AppText";

interface CheckboxProps {
  name: string;
  label: string;
  Label?: React.ReactNode;
}

const Checkbox = ({ name, label, Label }: CheckboxProps) => {
  const { values, setFieldValue } = useFormikContext<FormikValues>();
  const checked = !!values[name];

  return (
    <Pressable
      style={styles.row}
      onPress={() => setFieldValue(name, !values[name])}
      accessibilityRole="checkbox"
      accessibilityState={{ checked }}
      accessibilityLabel={label}
      hitSlop={hit.text}
    >
      <View style={styles.box}>
        {checked && <AntDesign name="check" size={14} color={PRIMARY} />}
      </View>

      {Label ? (
        Label
      ) : (
        <AppText size="sm" weight="medium" style={styles.label}>
          {label}
        </AppText>
      )}
    </Pressable>
  );
};

const styles = StyleSheet.create({
  row: { flexDirection: "row", gap: space[2] },
  // `border border-primary w-[20px] h-[20px] items-center justify-center`
  box: {
    width: 20,
    height: 20,
    borderWidth: 1,
    borderColor: PRIMARY,
    alignItems: "center",
    justifyContent: "center",
  },
  label: { flexShrink: 1 },
});

export default Checkbox;
