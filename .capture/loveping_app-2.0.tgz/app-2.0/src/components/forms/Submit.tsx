import { PRIMARY, SECONDARY, radii, space } from "@/src/theme";
import { FormikValues, useFormikContext } from "formik";
import React from "react";
import { Pressable, StyleSheet } from "react-native";
import Loader from "../Loader";
import AppText from "../ui/AppText";

type buttonProps = {
  title: string;
  loading: boolean;
  disable?: boolean;
};

/** Formik submit button. The whole 50px pill is the touch target. */
const Submit = ({ title, loading, disable }: buttonProps) => {
  const { handleSubmit } = useFormikContext<FormikValues>();
  const isDisabled = disable || loading;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityState={{ disabled: !!isDisabled, busy: loading }}
      disabled={isDisabled}
      onPress={() => handleSubmit()}
      style={[styles.button, { opacity: isDisabled ? 0.6 : 1 }]}
    >
      {loading && <Loader size={18} color={SECONDARY} />}
      <AppText size="sm" weight="semibold" color={SECONDARY} align="center">
        {title}
      </AppText>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  // `bg-primary px-6 h-[50px] rounded-2xl items-center justify-center`
  button: {
    backgroundColor: PRIMARY,
    paddingHorizontal: space[6],
    height: 50,
    borderRadius: radii["2xl"],
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: space[3],
  },
});

export default Submit;
