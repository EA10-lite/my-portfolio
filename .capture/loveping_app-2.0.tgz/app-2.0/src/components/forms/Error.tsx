import React from "react";
import { ERROR } from "@/src/theme";
import AppText from "../ui/AppText";

interface ErrorProps {
  error?: string | null;
  visible: boolean;
}

const Error: React.FC<ErrorProps> = ({ error, visible }) => {
  if (!visible || !error) return null;

  return (
    <AppText size="xs" color={ERROR} accessibilityLiveRegion="polite">
      {error}
    </AppText>
  );
};

export default Error;
