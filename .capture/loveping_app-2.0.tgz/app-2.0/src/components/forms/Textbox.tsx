import { fieldBorderColor, isFilled } from "./fieldBorder";
import {
  GREY_AF,
  TEXT_ERROR,
  WHITE,
  WHITE_08,
  WHITE_80,
  fontSize,
  radii,
  space,
  useResponsive,
  weight,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { useFormikContext } from "formik";
import React, { useState } from "react";
import { StyleSheet, TextInput, View } from "react-native";
import AppText from "../ui/AppText";

interface TextBoxProps {
  name: string;
  label?: string;
  mandatory?: boolean;
  placeholder?: string;
  maxLength?: number;
  info?: string;
  multiline?: boolean;
  numberOfLines?: number;
  hasBg?: boolean;
}

/** Multi-line Formik text field. */
const TextBox: React.FC<TextBoxProps> = ({
  name,
  label,
  mandatory,
  placeholder,
  maxLength,
  info,
  hasBg = false,
}) => {
  const { values, errors, touched, handleChange, setFieldError, setFieldTouched } =
    useFormikContext<any>();
  const { isSm } = useResponsive();
  const [isFocused, setIsFocused] = useState(false);

  const handleInputChange = (text: string) => {
    if (maxLength && text.length > maxLength) return;

    if (maxLength && text.length >= maxLength) {
      setFieldError(name, `Maximum of ${maxLength} characters reached.`);
    } else {
      if (errors[name] === `Maximum of ${maxLength} characters reached.`) {
        setFieldError(name, "");
      }
    }

    handleChange(name)(text);
  };

  return (
    <View style={styles.container}>
      {label && (
        <AppText size="base" weight="medium" style={styles.label}>
          {label}
          <AppText size="base" color="#DC2626">
            {mandatory && "*"}
          </AppText>
        </AppText>
      )}
      <View
        style={[
          styles.box,
          {
            // Was red whenever Formik had an error, even before the user
            // touched the field; now matches Input.
            borderColor: fieldBorderColor({
              hasError:
                typeof errors[name] === "string" &&
                !!errors[name] &&
                (!!touched[name] || !!maxLength),
              active: isFocused || isFilled(values[name]),
            }),
          },
          hasBg && styles.boxBg,
        ]}
      >
        <TextInput
          style={styles.input}
          accessibilityLabel={label ?? placeholder}
          placeholder={placeholder}
          value={values[name] || ""}
          onChangeText={handleInputChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            setFieldTouched(name, true, false);
          }}
          multiline={true}
          numberOfLines={4}
          maxLength={maxLength}
          placeholderTextColor={GREY_AF}
          autoComplete="off"
          autoCapitalize="none"
          autoCorrect={false}
        />
      </View>

      {info && (
        <View style={styles.info}>
          <Feather name="info" size={16} color={WHITE_80} />
          <AppText size={isSm ? "sm" : "xs"} color={WHITE_80} italic>
            {info}
          </AppText>
        </View>
      )}

      {typeof errors[name] === "string" && touched[name] && (
        <AppText size={isSm ? "sm" : "xs"} weight="medium" color={TEXT_ERROR}>
          {errors[name] as string}{" "}
        </AppText>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { marginBottom: space[5] },
  label: { marginBottom: space[2] },
  // `border rounded-md` (+ `bg-white-08` when hasBg)
  box: { borderWidth: 1, borderRadius: radii.md },
  boxBg: { backgroundColor: WHITE_08 },
  // `w-full text-sm text-white py-2 px-4 h-32`
  input: {
    width: "100%",
    height: 128,
    paddingVertical: space[2],
    paddingHorizontal: space[4],
    fontSize: fontSize.sm.fontSize,
    ...weight.regular,
    color: WHITE,
    textAlignVertical: "top",
    textAlign: "left",
  },
  info: {
    flexDirection: "row",
    flexShrink: 1,
    alignItems: "center",
    gap: space[2],
    marginTop: space[2],
  },
});

export default TextBox;
