import { useSafeAreaInsets } from "react-native-safe-area-context";
import { rs, space, useResponsive } from "../theme";

/** Height of one tab button (pill and circles). */
export const TAB_SIZE = 48;
/** Gap under the bar on devices without a bottom inset (iPhone SE, some Androids). */
const MIN_BOTTOM_GAP = 16;

/**
 * Real geometry of the floating tab bar on this device.
 * - `height`: the bar itself (padding + 48px tabs + border).
 * - `bottom`: its distance from the screen edge (home indicator / Android
 *   nav bar inset, or 16).
 * - `space`: how much of the screen it covers; use it as bottom padding for
 *   tab-screen content and to place anything floating above it.
 */
export const useTabBarMetrics = () => {
  const insets = useSafeAreaInsets();
  const { isSm } = useResponsive();
  const paddingVertical = rs(isSm, space[3], space[4]);
  const height = TAB_SIZE + paddingVertical * 2 + 2; // + 1px border top and bottom
  const bottom = insets.bottom > 0 ? insets.bottom : MIN_BOTTOM_GAP;
  return { height, bottom, paddingVertical, space: height + bottom };
};

/** Bottom padding for a scrolling tab screen: clears the bar plus a gap. */
export const useTabBarClearance = (extra: number = space[6]) =>
  useTabBarMetrics().space + extra;
