import React from "react";
import { StyleSheet, View } from "react-native";
import { PRIMARY_14, WHITE_08, radii, rs, space, useResponsive } from "@/src/theme";

/** Loading placeholder: three tab pills and two message cards. */
const MessageCardSkeleton = () => {
  const { isSm } = useResponsive();
  const pill = [styles.pill, { width: rs(isSm, space[20], 112) }];
  return (
    <View style={styles.fill}>
      {/* Tabs */}
      <View
        style={[
          styles.tabs,
          { gap: rs(isSm, space[3], space[5]), padding: rs(isSm, space[4], space[6]) },
        ]}
      >
        <View style={pill} />
        <View style={pill} />
        <View style={pill} />
      </View>

      {/* Cards */}
      <View
        style={{
          paddingHorizontal: rs(isSm, space[4], space[6]),
          gap: rs(isSm, space[4], space[6]),
        }}
      >
        {[1, 2].map((item) => (
          <View
            key={item}
            style={[styles.card, { padding: rs(isSm, space[4], space[6]) }]}
          >
            <View style={[styles.line, styles.full]} />
            <View style={[styles.line, styles.full]} />
            <View style={[styles.line, styles.short]} />

            <View style={styles.row}>
              <View style={[pill, styles.outlined]} />
              <View style={[pill, styles.outlined]} />
            </View>
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  tabs: { flexDirection: "row", alignItems: "center" },
  pill: { height: 40, borderRadius: radii["2xl"], backgroundColor: WHITE_08 },
  outlined: { borderWidth: 1, borderColor: WHITE_08 },
  card: {
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    backgroundColor: WHITE_08,
  },
  line: {
    height: space[3],
    borderRadius: radii.sm,
    backgroundColor: WHITE_08,
    marginBottom: space[3],
  },
  full: { width: "100%" },
  short: { width: "75%", marginBottom: space[4] },
  row: { flexDirection: "row", alignItems: "center", gap: space[4], width: "100%" },
});

export default MessageCardSkeleton;
