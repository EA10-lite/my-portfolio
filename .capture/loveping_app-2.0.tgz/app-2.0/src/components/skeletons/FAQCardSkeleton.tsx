import React from "react";
import { StyleSheet, View } from "react-native";
import { PRIMARY_14, WHITE_08, radii, rs, space, useResponsive } from "@/src/theme";

/** Loading placeholder for the FAQ list. */
const FAQCardSkeleton = () => {
  const { isSm } = useResponsive();
  return (
    <View style={styles.fill}>
      <View
        style={[
          styles.list,
          {
            paddingHorizontal: rs(isSm, space[4], space[6]),
            gap: rs(isSm, space[4], space[6]),
          },
        ]}
      >
        {[1, 2].map((item) => (
          <View
            key={item}
            style={[styles.card, { padding: rs(isSm, space[4], space[6]) }]}
          >
            <View style={[styles.line, styles.full]} />
            <View style={[styles.line, styles.full]} />
            <View style={[styles.line, styles.short]} />
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  list: { paddingVertical: space[4] },
  card: {
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    backgroundColor: WHITE_08,
  },
  line: {
    height: space[3],
    borderRadius: radii.sm,
    backgroundColor: WHITE_08,
    marginBottom: space[3],
  },
  full: { width: "100%" },
  short: { width: "75%", marginBottom: space[4] },
});

export default FAQCardSkeleton;
