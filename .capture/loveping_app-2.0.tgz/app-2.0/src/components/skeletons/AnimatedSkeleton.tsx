import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect } from "react";
import { StyleProp, ViewStyle } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";

type Props = {
  style?: StyleProp<ViewStyle>;
  borderRadius?: number;
};

const AnimatedLinear = Animated.createAnimatedComponent(LinearGradient);

const AnimatedSkeleton: React.FC<Props> = ({ style, borderRadius = 8 }) => {
  const translateX = useSharedValue(-200);

  useEffect(() => {
    translateX.value = withRepeat(
      withTiming(200, { duration: 1200 }),
      -1,
      false,
    );
  }, [translateX]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  return (
    <Animated.View
      style={[
        {
          backgroundColor: "rgba(72,217,98,0.05)",
          overflow: "hidden",
          borderRadius,
        },
        style,
      ]}
    >
      <AnimatedLinear
        colors={["transparent", "rgba(72,217,98,0.25)", "transparent"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={[
          {
            width: "50%",
            height: "100%",
          },
          animatedStyle,
        ]}
      />
    </Animated.View>
  );
};

export default AnimatedSkeleton;
