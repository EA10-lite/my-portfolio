import { StyleSheet, Switch, View } from "react-native";
import {
  PRIMARY,
  PRIMARY_14,
  PRIMARY_33,
  WHITE,
  WHITE_08,
  rs,
  space,
  useResponsive,
} from "../theme";
import AppText from "./ui/AppText";

type ToggleProps = {
  title: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  isLast?: boolean;
};

/** Settings row with a switch. */
const ToggleItem = ({
  title,
  value,
  onValueChange,
  isLast = false,
}: ToggleProps) => {
  const { isSm } = useResponsive();
  return (
    <View
      style={[
        styles.row,
        { padding: rs(isSm, space[4], space[5]) },
        !isLast && styles.divider,
      ]}
    >
      <AppText size={isSm ? "sm" : "xs"} weight="medium" style={styles.title}>
        {title}
      </AppText>
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ true: WHITE_08, false: WHITE_08 }}
        thumbColor={value ? PRIMARY : WHITE}
        ios_backgroundColor={PRIMARY_14}
        style={styles.switch}
        accessibilityLabel={title}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  divider: { borderBottomWidth: 1, borderBottomColor: PRIMARY_14 },
  title: { flex: 1 },
  switch: { borderWidth: 0.5, borderColor: PRIMARY_33 },
});

export default ToggleItem;
