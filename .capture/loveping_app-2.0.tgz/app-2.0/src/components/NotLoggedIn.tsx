import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import { PRIMARY, WHITE_08, hit, rs, space, useResponsive } from "../theme";
import { useUserStore } from "../stores";
import { userId } from "../utils/guest";
import Button from "./Button";
import AppText from "./ui/AppText";

/** Banner shown to guest users: "Signup required" + Signup button. */
const NotLoggedIn = () => {
  const { user } = useUserStore();
  const { isSm } = useResponsive();
  // The X used to be a no-op (`onPress={() => {}}`); it now hides the banner
  // until the screen is next mounted.
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;
  return (
    <View
      style={[
        styles.banner,
        {
          paddingHorizontal: rs(isSm, space[4], space[6]),
          paddingVertical: rs(isSm, space[4], space[6]),
        },
      ]}
    >
      <View style={styles.left}>
        <Feather name="info" size={24} color={PRIMARY} />
        <AppText
          size={isSm ? "sm" : "xs"}
          weight="medium"
          numberOfLines={1}
          style={styles.message}
        >
          Signup required to use this feature 💚
        </AppText>
        <Button
          title="Signup"
          style={styles.button}
          onPress={() =>
            router.push({
              pathname: "/auth/signup",
              params: {
                // Was `user?.id`, which the backend never sends, so the upgrade
                // never ran and a separate new account was created instead.
                id: userId(user),
              },
            })
          }
        />
      </View>

      <TouchableOpacity
        onPress={() => setDismissed(true)}
        style={styles.close}
        accessibilityRole="button"
        accessibilityLabel="Dismiss"
        hitSlop={hit.icon}
      >
        <Feather name="x" size={24} color={PRIMARY} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  banner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: WHITE_08,
  },
  left: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[4],
    flex: 1,
    flexShrink: 1,
    minWidth: 0,
  },
  message: { flexShrink: 1 },
  button: { flexShrink: 0 },
  close: { flexShrink: 0, marginLeft: space[2] },
});

export default NotLoggedIn;
