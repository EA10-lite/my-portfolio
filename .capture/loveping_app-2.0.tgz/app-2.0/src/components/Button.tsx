import {
  DANGER_33,
  ERROR,
  ERROR_1A,
  NEUTRAL_LIGHT,
  PRIMARY,
  PRIMARY_1A,
  SECONDARY,
  TEXT_DARK,
  WHITE_05,
  radii,
  rs,
  space,
  useResponsive, hit } from "@/src/theme";
import {
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
} from "react-native";
import Loader from "./Loader";
import AppText from "./ui/AppText";

type Variant =
  | "primary"
  | "secondary"
  | "outline"
  | "ghost"
  | "outline-secondary"
  | "danger";

type ButtonProps = {
  title: string;
  Icon?: React.ReactNode;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  variant?: Variant;
  size?: "sm" | "md" | "lg";
  style?: StyleProp<ViewStyle>;
  iconPosition?: "left" | "right";
};

const textColor: Record<Variant, string> = {
  primary: SECONDARY,
  secondary: PRIMARY,
  outline: PRIMARY,
  ghost: "#000000",
  "outline-secondary": PRIMARY,
  danger: ERROR,
};

const Button = ({
  title,
  Icon,
  onPress,
  disabled,
  loading,
  variant = "primary",
  size = "md",
  style,
  iconPosition = "left",
}: ButtonProps) => {
  const { isSm } = useResponsive();
  const isDisabled = disabled || loading;

  // Size variants: sm `px-4 py-2 min-h-9`, md `px-4 sm:px-6 sm:py-3 min-h-11`,
  // lg `px-6 sm:px-8 h-[50px]`
  const sizeStyle: ViewStyle =
    size === "sm"
      ? styles.sm
      : size === "md"
        ? {
            ...styles.md,
            paddingHorizontal: rs(isSm, space[4], space[6]),
            paddingVertical: rs(isSm, 0, space[3]),
          }
        : { ...styles.lg, paddingHorizontal: rs(isSm, space[6], space[8]) };

  return (
    <TouchableOpacity
      disabled={isDisabled}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!isDisabled, busy: !!loading }}
      // `sm` buttons are 36px tall; grow the touch area to 44.
      hitSlop={size === "sm" ? hit.pill : undefined}
      style={[
        styles.base,
        sizeStyle,
        variantStyles[variant],
        isDisabled && styles.disabled,
        style,
      ]}
    >
      {Icon && !loading && iconPosition === "left" && Icon}
      {loading && (
        <Loader
          size={18}
          color={
            variant === "outline" || variant === "ghost" ? TEXT_DARK : SECONDARY
          }
        />
      )}
      <AppText
        size={size === "sm" ? "xs" : "sm"}
        weight="semibold"
        color={textColor[variant]}
        align="center"
      >
        {title}
      </AppText>
      {Icon && !loading && iconPosition === "right" && Icon}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  // `rounded-3xl items-center justify-center flex-row gap-2`
  base: {
    borderRadius: radii["3xl"],
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: space[2],
  },
  sm: {
    paddingHorizontal: space[4],
    paddingVertical: space[2],
    minHeight: 36,
  },
  md: { minHeight: 44 },
  lg: { height: 50 },
  disabled: { opacity: 0.5 },
});

const variantStyles = StyleSheet.create({
  primary: { backgroundColor: PRIMARY },
  secondary: {
    backgroundColor: SECONDARY,
    borderWidth: 1,
    borderColor: SECONDARY,
  },
  outline: { backgroundColor: "#EFF6FF" }, // Tailwind `bg-blue-50`
  ghost: { backgroundColor: NEUTRAL_LIGHT },
  "outline-secondary": {
    backgroundColor: WHITE_05,
    borderWidth: 0.5,
    borderColor: PRIMARY_1A,
  },
  danger: {
    backgroundColor: DANGER_33,
    borderWidth: 1,
    borderColor: ERROR_1A,
  },
});

export default Button;
