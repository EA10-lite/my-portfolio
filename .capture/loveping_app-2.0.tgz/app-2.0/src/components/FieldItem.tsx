import {
  PRIMARY,
  PRIMARY_14,
  SECONDARY,
  WHITE_08,
  WHITE_80,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { MaterialIcons } from "@expo/vector-icons";
import { StyleSheet, TouchableOpacity, View, ViewStyle } from "react-native";
import AppText from "./ui/AppText";

type FieldItemProps = {
  title: string;
  description: string;
  icon: React.ReactNode;
  iconBgColor: string;
  iconBorderColor: string;
  onPress: () => void;
  variant?: "default" | "outline" | "ghost";
  numberOfLines?: number;
  isComingSoon?: boolean;
};

/** Navigation row: coloured icon circle, title, description, chevron. */
const FieldItem = ({
  title,
  description,
  icon,
  iconBgColor,
  iconBorderColor,
  onPress,
  variant = "default",
  numberOfLines = 1,
  isComingSoon = false,
}: FieldItemProps) => {
  const { isSm } = useResponsive();
  const padding = rs(isSm, space[3], space[5]);
  const variantStyle: ViewStyle | null =
    variant === "default"
      ? { ...styles.card, padding }
      : variant === "outline"
        ? { ...styles.outline, padding }
        : null;

  return (
    <TouchableOpacity
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={`${title}. ${description}`}
    >
      <View style={[styles.row, variantStyle]}>
        <View style={styles.left}>
          <View
            style={[
              styles.icon,
              { backgroundColor: iconBgColor, borderColor: iconBorderColor },
            ]}
          >
            {icon}
          </View>

          <View style={styles.text}>
            <View style={styles.titleRow}>
              <AppText size="sm" weight="semibold">
                {title}
              </AppText>
              {isComingSoon && (
                <View style={styles.badge}>
                  <AppText weight="semibold" color="#FF9B4F" style={styles.badgeText}>
                    Coming soon
                  </AppText>
                </View>
              )}
            </View>
            <AppText size="xs" color={WHITE_80} numberOfLines={numberOfLines}>
              {description}
            </AppText>
          </View>
        </View>
        <View style={styles.chevron}>
          <MaterialIcons name="arrow-forward-ios" size={16} color={PRIMARY} />
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  // `p-3 sm:p-5 rounded-md border border-primary-14 bg-white-08`
  card: {
    borderRadius: radii.md,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    backgroundColor: WHITE_08,
  },
  // `bg-secondary p-3 sm:p-5 rounded-md`
  outline: { backgroundColor: SECONDARY, borderRadius: radii.md },
  left: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[4],
    flex: 1,
    flexShrink: 1,
  },
  icon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 0.5,
    alignItems: "center",
    justifyContent: "center",
  },
  text: { flex: 1, flexShrink: 1 },
  titleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    marginBottom: space[1.5],
  },
  // `bg-[#D7965B33] rounded-[3px] px-2.5 h-[19px]`
  badge: {
    backgroundColor: "#D7965B33",
    borderRadius: 3,
    paddingHorizontal: space[2.5],
    height: 19,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: { fontSize: 8, lineHeight: 10, textTransform: "uppercase" },
  chevron: { flexShrink: 0, marginLeft: space[2] },
});

export default FieldItem;
