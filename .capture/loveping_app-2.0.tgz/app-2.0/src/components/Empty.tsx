import { StyleSheet, View } from "react-native";
import { GREY, space } from "../theme";
import IconPlaceholder from "./IconPlaceholder";
import AppText from "./ui/AppText";

type EmptyProps = {
  icon: React.ReactNode;
  description: string;
};

/** Centred empty state: hexagon icon + message. */
const Empty = ({ icon, description }: EmptyProps) => {
  return (
    <View style={styles.container}>
      <View style={styles.inner}>
        <IconPlaceholder icon={icon} />
        <AppText size="base" weight="medium" color={GREY} align="center">
          {description}
        </AppText>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center" },
  // `w-[73%] mx-auto items-center justify-center gap-4`
  inner: {
    width: "73%",
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
    gap: space[4],
  },
});

export default Empty;
