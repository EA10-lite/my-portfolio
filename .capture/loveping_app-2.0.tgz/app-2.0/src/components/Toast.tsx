import CheckIcon from "@/assets/icons/check.svg";
import WarningIcon from "@/assets/icons/warning.svg";
import { useToastStore } from "@/src/stores/toastStore";
import {
  ERROR,
  ERROR_1A,
  PRIMARY,
  SECONDARY,
  WHITE_08,
  radii,
  space,
} from "@/src/theme";
import { useEffect, useRef } from "react";
import { Animated, Platform, StyleSheet, View } from "react-native";
import { FullWindowOverlay } from "react-native-screens";
import AppText from "./ui/AppText";

const Toast = () => {
  const { message, type, isVisible, hideToast, position } = useToastStore();
  const translateY = useRef(new Animated.Value(100)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (isVisible) {
      // Set initial offset based on position before animating in
      translateY.setValue(position === "top" ? -200 : 100);

      Animated.parallel([
        Animated.spring(translateY, {
          toValue: 0,
          useNativeDriver: true,
          tension: 50,
          friction: 8,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();

      // Auto dismiss after 3 seconds
      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.spring(translateY, {
            toValue: position === "top" ? -200 : 100,
            useNativeDriver: true,
            tension: 50,
            friction: 8,
          }),
          Animated.timing(opacity, {
            toValue: 0,
            duration: 200,
            useNativeDriver: true,
          }),
        ]).start(() => {
          hideToast();
        });
      }, 3000);

      return () => clearTimeout(timer);
    } else {
      translateY.setValue(position === "top" ? -200 : 100);
      opacity.setValue(0);
    }
  }, [isVisible, hideToast, translateY, opacity, position]);

  if (!isVisible) return null;

  const isSuccess = type === "success";
  const body = (
    <View
      pointerEvents="none"
      style={[styles.wrapper, position === "top" ? styles.top : styles.bottom]}
    >
      <Animated.View
        accessibilityRole="alert"
        style={[
          styles.toast,
          isSuccess ? styles.success : styles.error,
          { transform: [{ translateY }], opacity },
        ]}
      >
        {isSuccess ? (
          <CheckIcon width={16} height={16} />
        ) : (
          <WarningIcon width={16} height={16} />
        )}
        <AppText size="xs" weight="medium" color={isSuccess ? PRIMARY : ERROR}>
          {message}
        </AppText>
      </Animated.View>
    </View>
  );

  // On iOS the toast must sit above native modals and sheets.
  return Platform.OS === "ios" ? (
    <FullWindowOverlay>{body}</FullWindowOverlay>
  ) : (
    body
  );
};

const styles = StyleSheet.create({
  // `absolute left-6 right-6 z-[99]`
  wrapper: {
    position: "absolute",
    left: space[6],
    right: space[6],
    zIndex: 99,
  },
  top: { top: space[24] }, // `top-24`
  bottom: { bottom: space[20] }, // `bottom-20`
  // `border rounded-lg px-2.5 py-1.5 flex-row items-center justify-center w-fit mx-auto gap-2`
  toast: {
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: space[2],
    borderWidth: 1,
    borderRadius: radii.lg,
    paddingHorizontal: space[2.5],
    paddingVertical: space[1.5],
  },
  success: { backgroundColor: SECONDARY, borderColor: WHITE_08 },
  error: { backgroundColor: ERROR_1A, borderColor: ERROR_1A },
});

export default Toast;
