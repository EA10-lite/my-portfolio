import Feather from "@expo/vector-icons/Feather";
import { StyleSheet, View } from "react-native";
import { PRIMARY_08, WHITE, layout, rs, space, useResponsive } from "../theme";
import ActionButton from "./ActionButton";
import AppText from "./ui/AppText";

type TabScreenHeaderProps = {
  title: string;
  onSearch: () => void;
  onFilter: () => void;
  /** Number of active filters, announced to screen readers. */
  activeFilters?: number;
};

/** "Messages" / "Gifts" header: title on the left, search + filter buttons. */
const TabScreenHeader = ({
  title,
  onSearch,
  onFilter,
  activeFilters = 0,
}: TabScreenHeaderProps) => {
  const { isSm } = useResponsive();
  return (
    <View
      style={[
        styles.header,
        { paddingHorizontal: rs(isSm, space[4], space[6]) },
      ]}
    >
      <AppText size="base" weight="semibold" accessibilityRole="header">
        {title}
      </AppText>

      <View style={styles.actions}>
        <ActionButton
          icon={<Feather name="search" size={18} color={WHITE} />}
          onPress={onSearch}
          hasBorder={false}
          bgColor={PRIMARY_08}
          accessibilityLabel="Search"
        />
        <ActionButton
          icon={<Feather name="filter" size={18} color={WHITE} />}
          onPress={onFilter}
          hasBorder={false}
          bgColor={PRIMARY_08}
          accessibilityLabel={
            activeFilters ? `Filter, ${activeFilters} active` : "Filter"
          }
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  // `flex-row items-center justify-between border-b border-primary-1A py-4`
  header: {
    ...layout.headerRule,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: space[4],
  },
  actions: { flexDirection: "row", alignItems: "center", gap: space[3] },
});

export default TabScreenHeader;
