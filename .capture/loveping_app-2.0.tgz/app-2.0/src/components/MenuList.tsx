import { View } from "react-native";
import { rs, space, useResponsive } from "../theme";
import FieldItem from "./FieldItem";

export type MenuItem = {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  iconBgColor: string;
  iconBorderColor: string;
  onPress: () => void;
};

/** Page body made of navigation rows (`p-4 sm:p-6 gap-4 sm:gap-5`). */
const MenuList = ({ items }: { items: MenuItem[] }) => {
  const { isSm } = useResponsive();
  return (
    <View
      style={{
        padding: rs(isSm, space[4], space[6]),
        gap: rs(isSm, space[4], space[5]),
      }}
    >
      {items.map((item) => (
        <FieldItem
          key={item.id}
          title={item.title}
          description={item.description}
          icon={item.icon}
          iconBgColor={item.iconBgColor}
          iconBorderColor={item.iconBorderColor}
          onPress={item.onPress}
        />
      ))}
    </View>
  );
};

export default MenuList;
