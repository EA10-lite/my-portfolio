import TrashIcon from "@/assets/icons/delete.svg";
import SaveIcon from "@/assets/icons/save.svg";
import ShareIcon from "@/assets/icons/share.svg";
import {
  DANGER_33,
  PRIMARY,
  PRIMARY_08,
  PRIMARY_14,
  PRIMARY_1A,
  WHITE_05,
  WHITE_08,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import Feather from "@expo/vector-icons/Feather";
import { Image, StyleSheet, View } from "react-native";
import ActionButton from "../ActionButton";
import Button from "../Button";
import AppText from "../ui/AppText";

type GiftCardProps = {
  title: string;
  image?: string;
  icon?: React.ReactNode;
  isSaved?: boolean;
  isHistory?: boolean;
  handleSave?: () => void;
  handleDelete?: () => void;
  handleRemove?: () => void;
};

const GiftCard = ({
  title,
  image,
  icon,
  isSaved = false,
  isHistory = false,
  handleSave,
  handleDelete,
  handleRemove,
}: GiftCardProps) => {
  const { isSm } = useResponsive();
  return (
    <View style={styles.card}>
      <View style={{ padding: rs(isSm, space[4], space[5]) }}>
        <View style={[styles.row, { gap: rs(isSm, space[4], space[6]) }]}>
          {/* Gift image */}
          {icon ? (
            <View style={styles.thumb}>{icon}</View>
          ) : (
            image && (
              <View style={[styles.thumb, styles.thumbImage]}>
                <Image source={{ uri: image }} />
              </View>
            )
          )}
          <View>
            <AppText
              size="base"
              weight="semibold"
              style={{ lineHeight: 24, marginBottom: rs(isSm, space[2], space[4]) }}
            >
              {title}
            </AppText>

            <View style={styles.tag}>
              <AppText size="xs" weight="medium" align="center">
                Physical Gift
              </AppText>
            </View>
          </View>
        </View>
      </View>

      <View
        style={[styles.footer, { paddingHorizontal: rs(isSm, space[4], space[5]) }]}
      >
        {!isHistory ? (
          <View style={styles.actions}>
            {isSaved ? (
              <Button
                title="Remove"
                onPress={handleRemove || (() => {})}
                Icon={<TrashIcon width={16} height={16} />}
                iconPosition="right"
                variant="danger"
                size="sm"
              />
            ) : (
              <Button
                title="Save for later"
                onPress={handleSave || (() => {})}
                Icon={<SaveIcon width={16} height={16} />}
                iconPosition="right"
                variant="outline-secondary"
                size="sm"
              />
            )}
            <Button
              title="Buy now"
              onPress={() => {}}
              Icon={<Feather name="arrow-up-right" size={20} color={PRIMARY} />}
              iconPosition="right"
              variant="secondary"
              size="sm"
            />
          </View>
        ) : (
          <View style={styles.actions}>
            <ActionButton
              icon={<ShareIcon width={16} height={16} />}
              onPress={() => {}}
              bgColor={PRIMARY_08}
              borderColor={PRIMARY_1A}
              accessibilityLabel="Share"
            />
            <ActionButton
              icon={<TrashIcon width={16} height={16} />}
              onPress={handleDelete || (() => {})}
              bgColor={DANGER_33}
              borderColor={DANGER_33}
              accessibilityLabel="Delete"
            />
          </View>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  // `bg-white-08 border border-primary-14 rounded-md`
  card: {
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    borderRadius: radii.md,
  },
  row: { flexDirection: "row", alignItems: "center" },
  thumb: { width: space[15], height: space[15], borderRadius: radii.base },
  thumbImage: { backgroundColor: WHITE_05, justifyContent: "flex-end" },
  // `border border-white-08 bg-white-08 px-4 py-2 rounded-3xl max-w-[116px]`
  tag: {
    borderWidth: 1,
    borderColor: WHITE_08,
    backgroundColor: WHITE_08,
    paddingHorizontal: space[4],
    paddingVertical: space[2],
    borderRadius: radii["3xl"],
    maxWidth: 116,
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: PRIMARY_1A,
    paddingVertical: space[3],
  },
  actions: { flexDirection: "row", alignItems: "center", gap: space[3] },
});

export default GiftCard;
