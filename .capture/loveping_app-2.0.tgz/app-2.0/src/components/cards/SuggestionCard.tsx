import StarAltIcon from "@/assets/icons/star-alt.svg";
import { ReactNode } from "react";
import { StyleProp, StyleSheet, View, ViewStyle } from "react-native";
import { PRIMARY_1A, layout, rs, space, useResponsive } from "../../theme";
import AppText from "../ui/AppText";

type SuggestionCardProps = {
  title: string;
  children: ReactNode;
  style?: StyleProp<ViewStyle>;
};

/** Card with a star + title header row, used by the text and call nudges. */
const SuggestionCard = ({ title, children, style }: SuggestionCardProps) => {
  const { isSm } = useResponsive();
  const padding = rs(isSm, space[4], space[5]);
  return (
    <View style={[layout.surface, styles.card, style]}>
      <View style={[styles.header, { padding }]}>
        <StarAltIcon width={16} height={16} />
        <AppText size="sm" weight="medium">
          {title}
        </AppText>
      </View>
      <View style={{ padding }}>{children}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  // `border border-primary-1A rounded-md bg-white-08`
  card: { borderColor: PRIMARY_1A },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
});

export default SuggestionCard;
