import CopyIcon from "@/assets/icons/copy.svg";
import DeleteIcon from "@/assets/icons/delete.svg";
import EditIcon from "@/assets/icons/edit.svg";
import SaveIcon from "@/assets/icons/save.svg";
import ShareIcon from "@/assets/icons/share.svg";
import { TONES } from "@/src/constants/data";
import { useClipboard } from "@/src/hooks/useClipBoard";
import ping from "@/src/services/ping";
import { useToastStore } from "@/src/stores";
import { usePartnerStore } from "@/src/stores/partnerStore";
import {
  PRIMARY,
  PRIMARY_14,
  PRIMARY_1A,
  WHITE_08,
  radii,
  rs,
  space,
  useResponsive, hit } from "@/src/theme";
import { Ionicons } from "@expo/vector-icons";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { isAxiosError } from "axios";
import { router } from "expo-router";
import { useRef, useState } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import ActionButton from "../ActionButton";
import Button from "../Button";
import ChangeToneModal from "../modals/ChangeToneModal";
import DeleteModal from "../modals/DeleteModal";
import AppText from "../ui/AppText";

type MessageCardProps = {
  id: string | number;
  message: string;
  tones: string[];
  onPress: () => void;
  isOpen: boolean;
  isSaved?: boolean;
  isHistory?: boolean;
  timestamp?: string;
  onChange?: () => void; // Callback to refresh data after successful deletion
};

const MessageCard = ({
  id,
  message,
  tones,
  onPress,
  isOpen = false,
  isSaved = false,
  isHistory = false,
  timestamp = "12:00 PM",
  onChange,
}: MessageCardProps) => {
  const { partner } = usePartnerStore();
  const { showToast } = useToastStore();
  const { copy } = useClipboard();
  const { isSm } = useResponsive();

  const deleteModal = useRef<BottomSheetModal>(null);
  const openDeleteModal = () => deleteModal.current?.present();
  const closeDeleteModal = () => deleteModal.current?.dismiss();

  const changeToneModal = useRef<BottomSheetModal>(null);
  const openChangeToneModal = () => changeToneModal.current?.present();
  const closeChangeToneModal = () => changeToneModal.current?.dismiss();

  const handleCopyAndSave = () => {
    showToast("Copied and saved", "success", "bottom");
  };

  const handleCopy = () => {
    copy(message);
    showToast("Copied", "success", "bottom");
  };

  const [saving, setSaving] = useState(false);
  const handleSave = async () => {
    try {
      setSaving(true);
      const response = await ping.updatePing(id.toString(), {
        message: message,
        tones: tones,
        ping_type: "text",
        partner: partner?._id?.toString() || "",
        title: "Love Note",
        isSaved: true,
      });
      if (response.status === 200 || response.status === 201) {
        showToast("Saved", "success", "top");

        onChange?.();
      }
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      } else {
        showToast("An error occurred while saving the message", "error", "top");
      }
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = () => {
    router.push({
      pathname: "/messages/edit",
      params: {
        id: id.toString(),
        tones: tones,
        message: message,
      },
    });
  };

  const [deleting, setDeleting] = useState(false);
  const handleDelete = async () => {
    try {
      setDeleting(true);
      const response = await ping.deletePing(id.toString());
      if (response.status === 200 || response.status === 204) {
        showToast("Deleted", "success", "top");
        closeDeleteModal();

        // Trigger data refresh in parent component
        onChange?.();
      }
    } catch (error) {
      console.log("ERROR:", error);
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      }
    } finally {
      setDeleting(false);
    }
  };

  const handleShare = () => {
    showToast("Shared", "success", "top");
  };

  const [selectedTones, setSelectedTones] = useState<string[]>(
    tones.map(
      (tone) =>
        TONES.find((t) => t.value?.toLowerCase() === tone?.toLowerCase())
          ?.name || "",
    ) || [],
  );
  const handleSelectTone = (tone: string) => {
    if (selectedTones.includes(tone)) {
      setSelectedTones((prev) => prev.filter((t) => t !== tone));
      return;
    } else if (selectedTones.length >= 2) {
      return;
    }
    setSelectedTones((prev) => [...prev, tone]);
  };

  const [loading, setLoading] = useState(false);
  const handleUpdate = async () => {
    try {
      setLoading(true);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    } catch (error) {
      if (isAxiosError(error)) {
        showToast(error.response?.data?.message, "error", "top");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setSelectedTones([]);
  };

  const pad = rs(isSm, space[4], space[5]);
  const pillPadding = {
    paddingHorizontal: rs(isSm, space[3], space[4]),
    paddingVertical: rs(isSm, space[1.5], space[2]),
  };
  const pillText = isSm ? "sm" : "xs";

  const timestampPill = (padding: object, size: "sm" | "xs") => (
    <View style={[styles.pill, styles.timestamp, padding]}>
      <Ionicons name="time-outline" size={16} color="white" />
      <AppText size={size} weight="medium">
        {timestamp}
      </AppText>
    </View>
  );

  return (
    <>
      <TouchableOpacity
        style={styles.card}
        onPress={onPress}
        accessibilityRole="button"
        accessibilityState={{ expanded: isOpen }}
      >
        <View style={{ padding: pad }}>
          <AppText
            size={isSm ? "base" : "sm"}
            weight="medium"
            style={[styles.message, { lineHeight: rs(isSm, 20, 24) }]}
          >
            {message}
          </AppText>
          <View style={styles.metaRow}>
            <View style={styles.tones}>
              {selectedTones?.map((tone) => (
                <View key={tone} style={[styles.pill, pillPadding]}>
                  <AppText size={pillText} weight="medium">
                    {TONES.find(
                      (t) => t.value?.toLowerCase() === tone?.toLowerCase(),
                    )?.name || tone}
                  </AppText>
                </View>
              ))}
              {tones.length < 2 && !isHistory && (
                <TouchableOpacity
                  style={styles.changeTone}
                  onPress={openChangeToneModal}
                  accessibilityRole="button"
                  hitSlop={hit.pill}
                >
                  <AppText size={pillText} weight="medium" color={PRIMARY}>
                    Change tone
                  </AppText>
                </TouchableOpacity>
              )}
            </View>

            {isHistory && tones.length < 2 && timestampPill(pillPadding, pillText)}
          </View>
        </View>

        {isOpen && (
          <View style={[styles.footer, { padding: pad }]}>
            <View style={styles.footerRow}>
              <View style={styles.actions}>
                {isHistory && (
                  <ActionButton
                    onPress={handleShare}
                    icon={<ShareIcon width={16} height={16} />}
                    accessibilityLabel="Share"
                  />
                )}
                {!isHistory && (
                  <ActionButton
                    onPress={handleEdit}
                    icon={<EditIcon />}
                    accessibilityLabel="Edit"
                  />
                )}
                {!isHistory && (
                  <ActionButton
                    onPress={handleCopy}
                    icon={<CopyIcon />}
                    accessibilityLabel="Copy"
                  />
                )}

                {isSaved && !isHistory ? (
                  <ActionButton
                    onPress={openDeleteModal}
                    icon={<DeleteIcon width={18} height={18} />}
                    bgColor="#DB121233" // danger-33
                    borderColor="#FA2E2E1A" // error-1A
                    accessibilityLabel="Delete"
                  />
                ) : (
                  <ActionButton
                    onPress={handleSave}
                    icon={<SaveIcon />}
                    loading={saving}
                    accessibilityLabel="Save"
                  />
                )}
              </View>

              {tones.length >= 2 && !isHistory && (
                <TouchableOpacity
                  style={styles.changeTone}
                  onPress={openChangeToneModal}
                  accessibilityRole="button"
                  hitSlop={hit.pill}
                >
                  <AppText size="sm" weight="medium" color={PRIMARY}>
                    Change tone
                  </AppText>
                </TouchableOpacity>
              )}

              {isHistory &&
                tones.length >= 2 &&
                timestampPill(
                  { paddingHorizontal: space[4], paddingVertical: space[2] },
                  "sm",
                )}
            </View>

            {!isHistory && (
              <View style={{ marginTop: rs(isSm, space[4], space[6]) }}>
                <Button
                  title={isSaved ? "Copy" : "Copy & Save"}
                  onPress={handleCopyAndSave}
                  variant="primary"
                  size="lg"
                  disabled={false}
                  loading={false}
                />
              </View>
            )}
          </View>
        )}
      </TouchableOpacity>

      <DeleteModal
        ref={deleteModal}
        onClose={closeDeleteModal}
        onDelete={handleDelete}
        onCancel={closeDeleteModal}
        title={"Delete Message"}
        message={"Are you sure you want to delete this item?"}
        deleteButtonText="Delete"
        cancelButtonText="Cancel"
        deleting={deleting}
      />

      <ChangeToneModal
        ref={changeToneModal}
        onClose={closeChangeToneModal}
        selectedTones={selectedTones}
        handleSelectTone={handleSelectTone}
        handleUpdate={handleUpdate}
        handleClear={handleClear}
        loading={loading}
      />
    </>
  );
};

const styles = StyleSheet.create({
  // `bg-white-08 border-[0.5px] border-primary-14 rounded-md`
  card: {
    backgroundColor: WHITE_08,
    borderWidth: 0.5,
    borderColor: PRIMARY_14,
    borderRadius: radii.md,
  },
  message: { marginBottom: space[4] },
  metaRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: space[4],
  },
  tones: {
    flexDirection: "row",
    flexWrap: "wrap",
    flex: 1,
    alignItems: "center",
    gap: space[2],
  },
  // `rounded-2xl bg-white-08 border border-white-08`
  pill: {
    borderRadius: radii["2xl"],
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: WHITE_08,
  },
  timestamp: {
    minWidth: space[24],
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
  },
  // `rounded-2xl py-2 px-4 bg-primary-1A border border-white-08`
  changeTone: {
    borderRadius: radii["2xl"],
    paddingVertical: space[2],
    paddingHorizontal: space[4],
    backgroundColor: PRIMARY_1A,
    borderWidth: 1,
    borderColor: WHITE_08,
  },
  footer: { borderTopWidth: 1, borderTopColor: PRIMARY_1A },
  footerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
  },
  actions: { flexDirection: "row", alignItems: "center", gap: space[3] },
});

export default MessageCard;
