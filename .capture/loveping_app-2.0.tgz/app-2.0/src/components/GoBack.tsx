import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { TouchableOpacity } from "react-native";
import { PRIMARY, hit } from "../theme";

type GoBackProps = {
  onPress?: () => void;
};

const GoBack = ({ onPress = () => router.back() }: GoBackProps) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel="Go back"
      hitSlop={hit.icon}
    >
      <Feather name="arrow-left" size={24} color={PRIMARY} />
    </TouchableOpacity>
  );
};

export default GoBack;
