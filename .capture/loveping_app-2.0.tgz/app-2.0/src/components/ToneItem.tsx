import { GREY, PRIMARY, PRIMARY_1A, WHITE_05, radii, space, useResponsive, hit } from "@/src/theme";
import { FontAwesome6 } from "@expo/vector-icons";
import { StyleSheet, TouchableOpacity } from "react-native";
import AppText from "./ui/AppText";

type ToneItemProps = {
  tone: string;
  isSelected: boolean;
  onPress: () => void;
};

/** Compact tone chip used in the tone and filter sheets and note forms. */
const ToneItem = ({ tone, isSelected, onPress }: ToneItemProps) => {
  const { isSm } = useResponsive();
  return (
    <TouchableOpacity
      style={[styles.chip, isSelected && styles.selected]}
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: isSelected }}
      hitSlop={hit.pill}
    >
      <AppText
        size={isSm ? "sm" : "xs"}
        color={isSelected ? PRIMARY : GREY}
        style={styles.label}
      >
        {tone}
      </AppText>
      {isSelected && <FontAwesome6 name="circle-check" size={14} color={PRIMARY} />}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  // `flex-row items-center gap-2 bg-white-05 rounded-3xl py-2 px-4`
  chip: {
    flexDirection: "row",
    alignItems: "center",
    gap: space[2],
    backgroundColor: WHITE_05,
    borderRadius: radii["3xl"],
    paddingVertical: space[2],
    paddingHorizontal: space[4],
  },
  selected: { borderWidth: 1, borderColor: PRIMARY_1A },
  label: { textTransform: "capitalize" },
});

export default ToneItem;
