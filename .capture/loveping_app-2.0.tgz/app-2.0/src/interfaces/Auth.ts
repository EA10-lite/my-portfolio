export type Login = {
  email_address: string;
  password: string;
  notification_token: string;
};

export type Signup = {
  full_name: string;
  email_address: string;
  password: string;
  notification_token: string;
};

export type UpgradeGuest = {
  guest_id: string;
  full_name: string;
  email_address: string;
  password: string;
};

export type SignupAsGuest = {
  notification_token: string;
};

export type RequestOTPCode = {
  email_address: string;
  type: "verify_user" | "reset_password";
};

export type ResetPassword = {
  password: string;
  otp_id: string;
};

export type ChangePassword = {
  current_password: string;
  new_password: string;
};

export type VerifyOTPCode = {
  code: string;
  email_address: string;
  type: "verify_user" | "reset_password";
};

export type OTP = {
  code: string;
};
