

export type UpdatePassword = {
    current_password: string;
    new_password: string;
}

export type UpdateProfile = {
    full_name?: string;
    partner_name?: string;
    partner_birthday?: string;
    anniversary_date?: string;
    love_language?: string[];
    special_occassion_reminders?: boolean;
    silent_mode?: boolean;
}