

export type Partner = {
    _id?: string;
    partner_name: string;
    relationship_type: string;
    partner_birthday: string;
    anniversary_date: string;
    love_language: string[];
    gender: "male" | "female";
}

export type PartnerPreference = {
    partner: string;
    tone: string[];
    nudge_type: Nudge;
}

export type Nudge = {
    repeat: "once_a_week" | "repeat";
    days: string[];
    isRandom: boolean,
}

// "partner": "6908d560230ca7c7f3a223cd",
//     "tone": [ "romantic", "deep_n_thoughtful" ], // romantic, playful, deep_n_thoughtful, supportive, funny_n_light_hearted
//     "nudge_type": {
//         "repeat": "once_a_week", // repeat, once_a_week
//         "days": [ "monday", "friday" ], // monday - sunday
//         "isRandom": true // false
//     }