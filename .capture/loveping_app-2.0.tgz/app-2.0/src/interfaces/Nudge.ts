export type UpdateNudge = {
    message: string;
    tone: string | string[];
    DayOfWeek: string | string[];
    ping_type: "text" | "call" | "gift";
    isSaved: boolean;
}

export type Nudge = {
    message: string;
    tone: string | string[];
    DayOfWeek: string | string[];
    ping_type: "text" | "call" | "gift";
    isSaved: boolean;
}

export type AddNudge = {
    message: string;
    tones: string[];
    ping_type: "text" | "call" | "gift";
    partner: string;
    title?: string;
    isSaved?: boolean;
}

export type Note = {
    message: string;
    tones: string[];
    ping_type: "text" | "call" | "gift";
}