/**
 * Colour tokens for Loveping (App 2.0).
 *
 * Single source of truth for every colour. Values are identical to the
 * Tailwind theme used in App 1.x (removed in 2.0), so screens render the
 * same colours. `src/constants/colors.ts` re-exports this
 * file so existing imports keep working.
 */

// Primary brand colors
export const PRIMARY = '#48D962';
export const SECONDARY = '#02231A';
export const GREY = '#9CA9A5';
export const ERROR = '#FA2E2E';

// White color with opacity variants
export const WHITE = '#FFFFFF';
export const WHITE_80 = '#FFFFFF80'; // 50% opacity
export const WHITE_08 = '#FFFFFF08'; // ~3% opacity
export const WHITE_05 = '#FFFFFF05'; // ~2% opacity

// Primary color with opacity variants
export const PRIMARY_1A = '#48D9621A'; // ~10% opacity
export const PRIMARY_08 = '#48D96208'; // ~3% opacity
export const PRIMARY_14 = '#48D96214'; // ~8% opacity
export const PRIMARY_33 = '#48D96233'; // ~20% opacity

// Error color with opacity variants
export const ERROR_1A = '#FA2E2E1A'; // ~10% opacity
export const ERROR_40 = '#FA2E2E40'; // ~25% opacity

// Grey variants
export const GREY_90 = '#909090';
export const GREY_AF = '#9CA3AF';

// Background colors
export const BG_DARK = '#07271E';
export const BG_DARKER = '#0A2B22';
export const BG_DARKEST = '#0A2A21';

// Text colors
export const TEXT_DARK = '#112358';
export const TEXT_ERROR = '#e63946';

// Notification/Event type colors
export const PINK = '#FA5EBC';
export const PINK_1A = '#FA5EBC1A'; // ~10% opacity
export const PINK_DARK = '#EE4A99';
export const PINK_DARK_1A = '#EE4A991A'; // ~10% opacity

export const YELLOW = '#D7BA38';
export const YELLOW_1A = '#D7BA381A'; // ~10% opacity

export const PURPLE = '#8838F2';
export const PURPLE_1A = '#8838F21A'; // ~10% opacity

export const PURPLE_LIGHT = '#A561FF';
export const PURPLE_LIGHT_1A = '#A561FF1A'; // ~10% opacity
export const PURPLE_LIGHT_26 = '#A561FF26'; // ~15% opacity

export const ORANGE = '#FF621A';
export const ORANGE_1A = '#FF621A1A'; // ~10% opacity

export const CYAN = '#0AECD6';
export const CYAN_1A = '#0AECD61A'; // ~10% opacity

export const BLUE = '#5072F9';
export const BLUE_1A = '#5072F91A'; // ~10% opacity

export const BLUE_LIGHT = '#3BD1DC';
export const BLUE_LIGHT_1A = '#3BD1DC1A'; // ~10% opacity

export const BLUE_DARK = '#3870F3';
export const BLUE_DARK_1A = '#3870F31A'; // ~10% opacity

export const BLUE_MEDIUM = '#3194DB';
export const BLUE_MEDIUM_1A = '#3194DB1A'; // ~10% opacity

// Danger/Error variants
export const DANGER = '#DB1212';
export const DANGER_1A = '#DB12121A'; // ~10% opacity
export const DANGER_24 = '#DB121224'; // ~14% opacity
export const DANGER_33 = '#DB121233'; // ~20% opacity

// Extra alpha variants that NativeWind produced with opacity modifiers
// (e.g. `border-primary/10`) or arbitrary values (e.g. `bg-[#FFFFFF20]`).
export const WHITE_20 = '#FFFFFF20';
export const SURFACE_KEY = '#0A2A21'; // PIN keypad keys (`bg-[#0A2A21]`)
export const CHIP_DAY_BG = '#9CA9A50D'; // date-picker day (`bg-[#9CA9A50D]`)
export const PRIMARY_20 = 'rgba(72, 217, 98, 0.2)'; // `border-primary/20`
export const GREY_10 = 'rgba(156, 169, 165, 0.1)'; // `border-grey/10`

// Neutral colors
export const NEUTRAL_LIGHT = '#E7E9EE';
export const CRIMSON = 'crimson';

/**
 * Color palette object for easy reference and potential future theming
 */
export const colors = {
  primary: PRIMARY,
  secondary: SECONDARY,
  error: ERROR,
  white: {
    base: WHITE,
    '80': WHITE_80,
    '08': WHITE_08,
    '05': WHITE_05,
  },
  primaryOpacity: {
    '1A': PRIMARY_1A,
    '08': PRIMARY_08,
    '14': PRIMARY_14,
    '33': PRIMARY_33,
  },
  errorOpacity: {
    '1A': ERROR_1A,
    '40': ERROR_40,
  },
  grey: {
    base: GREY,
    '90': GREY_90,
    'AF': GREY_AF,
  },
  background: {
    dark: BG_DARK,
    darker: BG_DARKER,
    darkest: BG_DARKEST,
  },
  text: {
    dark: TEXT_DARK,
    error: TEXT_ERROR,
  },
  notification: {
    pink: PINK,
    pinkOpacity: PINK_1A,
    yellow: YELLOW,
    yellowOpacity: YELLOW_1A,
    purple: PURPLE,
    purpleOpacity: PURPLE_1A,
    purpleLight: PURPLE_LIGHT,
    purpleLightOpacity: PURPLE_LIGHT_1A,
    purpleLight26: PURPLE_LIGHT_26,
    orange: ORANGE,
    orangeOpacity: ORANGE_1A,
    cyan: CYAN,
    cyanOpacity: CYAN_1A,
    blue: BLUE,
    blueOpacity: BLUE_1A,
    blueLight: BLUE_LIGHT,
    blueLightOpacity: BLUE_LIGHT_1A,
    blueDark: BLUE_DARK,
    blueDarkOpacity: BLUE_DARK_1A,
  },
  danger: {
    base: DANGER,
    '1A': DANGER_1A,
    '24': DANGER_24,
    '33': DANGER_33,
  },
  neutral: {
    light: NEUTRAL_LIGHT,
    crimson: CRIMSON,
  },
} as const;

