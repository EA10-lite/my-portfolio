/**
 * Spacing scale in density-independent pixels.
 *
 * Mirrors `theme.extend.spacing` in the old `tailwind.config.js`
 * (App 1.x): the key is the
 * Tailwind step (`p-4` -> space[4] = 16), the value is the pixel size.
 */
export const space = {
  0: 0,
  px: 1,
  0.5: 2,
  1: 4,
  1.5: 6,
  2: 8,
  2.5: 10,
  3: 12,
  3.5: 14,
  4: 16,
  5: 20,
  6: 24,
  7: 28,
  8: 32,
  10: 40,
  12: 48,
  12.5: 50,
  13: 52,
  14: 56,
  14.5: 58,
  15: 60,
  16: 64,
  18: 72,
  20: 80,
  24: 96,
} as const;

/** Horizontal page gutter: `px-4 sm:px-6`. */
export const gutter = { base: space[4], sm: space[6] } as const;
