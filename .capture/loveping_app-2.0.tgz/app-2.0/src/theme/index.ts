import { StyleSheet } from "react-native";
import { PRIMARY_14, PRIMARY_1A, SECONDARY, WHITE_08 } from "./colors";
import { radii } from "./radii";

export * from "./colors";
export * from "./radii";
export * from "./responsive";
export * from "./spacing";
export * from "./typography";
export * from "./touch";

/** Small, frequently repeated layout and surface styles. */
export const layout = StyleSheet.create({
  fill: { flex: 1 },
  row: { flexDirection: "row", alignItems: "center" },
  center: { alignItems: "center", justifyContent: "center" },
  screen: { flex: 1, backgroundColor: SECONDARY },
  /** Bottom hairline used under page headers: `border-b border-primary-1A`. */
  headerRule: { borderBottomWidth: 1, borderBottomColor: PRIMARY_1A },
  /** The recurring card: `bg-white-08 border border-primary-14 rounded-md`. */
  surface: {
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    borderRadius: radii.md,
  },
});
