import type { TextStyle } from "react-native";

/**
 * Font families. Keys are the names registered with `useFonts` in
 * `app/_layout.tsx`; they match the names App 1.x used.
 */
export const fontFamily = {
  regular: "Inter_18pt-Regular",
  light: "Inter_18pt-Light",
  extraLight: "Inter_18pt-ExtraLight",
  medium: "Inter_18pt-Medium",
  semibold: "Inter_18pt-SemiBold",
  bold: "Inter_18pt-Bold",
  display: "Inter_24pt-Bold",
} as const;

/** Font files to register at startup (see `app/_layout.tsx`). */
export const fontAssets = {
  [fontFamily.regular]: require("../../assets/fonts/Inter_18pt-Regular.ttf"),
  [fontFamily.light]: require("../../assets/fonts/Inter_18pt-Light.ttf"),
  [fontFamily.extraLight]: require("../../assets/fonts/Inter_18pt-ExtraLight.ttf"),
  [fontFamily.medium]: require("../../assets/fonts/Inter_18pt-Medium.ttf"),
  [fontFamily.semibold]: require("../../assets/fonts/Inter_18pt-SemiBold.ttf"),
  [fontFamily.bold]: require("../../assets/fonts/Inter_18pt-Bold.ttf"),
  [fontFamily.display]: require("../../assets/fonts/Inter_24pt-Bold.ttf"),
};

/**
 * Font sizes with the line heights the Tailwind config paired them with
 * (`text-sm` = 14/20, `text-base` = 16/24, ...).
 */
export const fontSize = {
  xs: { fontSize: 12, lineHeight: 16 },
  sm: { fontSize: 14, lineHeight: 20 },
  base: { fontSize: 16, lineHeight: 24 },
  lg: { fontSize: 18, lineHeight: 28 },
  xl: { fontSize: 20, lineHeight: 28 },
  "2xl": { fontSize: 24, lineHeight: 32 },
  "3xl": { fontSize: 30, lineHeight: 36 },
  "4xl": { fontSize: 36, lineHeight: 40 },
} as const satisfies Record<string, TextStyle>;

export type FontSizeKey = keyof typeof fontSize;
export type FontWeightKey = "regular" | "medium" | "semibold" | "bold";

/**
 * With custom fonts each weight is its own family, so weight is chosen by
 * family rather than `fontWeight` (Android ignores `fontWeight` for custom
 * families).
 */
export const weight: Record<FontWeightKey, TextStyle> = {
  regular: { fontFamily: fontFamily.regular },
  medium: { fontFamily: fontFamily.medium },
  semibold: { fontFamily: fontFamily.semibold },
  bold: { fontFamily: fontFamily.bold },
};
