import type { Insets } from "react-native";

/** Minimum comfortable touch target (Apple HIG 44pt; Material asks for 48dp). */
export const MIN_TOUCH = 44;

/** Even hit slop on all sides. */
export const slop = (n: number): Insets => ({ top: n, bottom: n, left: n, right: n });

/**
 * Hit slop that grows a `width` x `height` target to at least 44x44
 * without changing its visual size.
 * e.g. a 24px icon -> slopFor(24) = 10 on every side.
 */
export const slopFor = (width: number, height: number = width): Insets => {
  const x = Math.max(0, Math.ceil((MIN_TOUCH - width) / 2));
  const y = Math.max(0, Math.ceil((MIN_TOUCH - height) / 2));
  return { top: y, bottom: y, left: x, right: x };
};

/** Ready-made presets for the target sizes that recur in the app. */
export const hit = {
  /** 24px icon buttons (back arrow, close X). */
  icon: slopFor(24),
  /** 16-20px glyphs (edit pencil, small chevrons). */
  glyph: slopFor(16),
  /** One line of tappable text (~20px tall): "Continue as Guest", "Resend". */
  text: { top: 12, bottom: 12, left: 8, right: 8 } as Insets,
  /** Pills 28-36px tall (chips, "Forgot Password?", "Change tone"). */
  pill: { top: 6, bottom: 6, left: 4, right: 4 } as Insets,
  /** 40px circles that are just under the minimum. */
  circle: slopFor(40),
} as const;
