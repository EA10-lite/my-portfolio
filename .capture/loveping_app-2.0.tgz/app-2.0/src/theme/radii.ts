/**
 * Border radius scale.
 *
 * NOTE: this is the project's own scale from the old `tailwind.config.js`
 * (App 1.x), not Tailwind's defaults. `rounded-md` is 10, `rounded-2xl` is 35, and so on.
 */
export const radii = {
  none: 0,
  sm: 4,
  base: 5, // `rounded`
  md: 10,
  lg: 20,
  xl: 28,
  "2xl": 35,
  "3xl": 50,
  "4xl": 70,
  full: 9999,
} as const;
