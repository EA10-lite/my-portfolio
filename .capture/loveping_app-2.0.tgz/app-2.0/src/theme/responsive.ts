import { useWindowDimensions } from "react-native";
import { gutter } from "./spacing";

/**
 * The old NativeWind `sm:` breakpoint (App 1.x `screens.sm`).
 * Phones at least this wide get the `sm` variant of a style; narrower
 * phones (e.g. 360dp Android) get the base style, exactly as before.
 */
export const SM_BREAKPOINT = 375;

export const useResponsive = () => {
  const { width } = useWindowDimensions();
  return { isSm: width >= SM_BREAKPOINT, width };
};

/** Pick the base or `sm` value: `rs(isSm, 16, 24)`. */
export const rs = <T,>(isSm: boolean, base: T, sm: T): T => (isSm ? sm : base);

/** Page gutter (`px-4 sm:px-6` / `p-4 sm:p-6`): 16, or 24 on wider phones. */
export const useGutter = () => {
  const { isSm } = useResponsive();
  return rs(isSm, gutter.base, gutter.sm);
};
