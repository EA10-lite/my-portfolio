// shared/hooks/useModals.ts
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useRef } from "react";

export const useModals = () => {
  const nudgeModalRef = useRef<BottomSheetModal>(null);
  const loveLanguageModalRef = useRef<BottomSheetModal>(null);
  const genderModalRef = useRef<BottomSheetModal>(null);
  const relationshipModalRef = useRef<BottomSheetModal>(null);

  const modals = {
    nudge: nudgeModalRef,
    loveLanguage: loveLanguageModalRef,
    gender: genderModalRef,
    relationship: relationshipModalRef,
  };

  const openModal = (name: keyof typeof modals) => {
    modals[name].current?.present();
  };

  const closeModal = (name: keyof typeof modals) => {
    modals[name].current?.dismiss();
  };

  const closeAllModals = () => {
    Object.values(modals).forEach((ref) => ref.current?.dismiss());
  };

  return { modals, openModal, closeModal, closeAllModals };
};
