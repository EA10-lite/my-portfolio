import * as Notifications from "expo-notifications";
import { useMemo } from "react";
import { mutate as globalMutate } from "swr";
import useSWRInfinite, { unstable_serialize } from "swr/infinite";
import notification, {
  Notification,
  NotificationResponse,
} from "../services/notification";

/** Page `n` (1-based) of the user's notifications. */
const getKey = (index: number, previous: NotificationResponse | null) => {
  if (previous && previous.page >= previous.totalPages) return null; // no more
  return ["notifications", index + 1] as const;
};

const fetchPage = ([, page]: readonly [string, number]) =>
  notification.getMyNotifications(page);

/**
 * Refetch the notifications list and unread count from anywhere, e.g. when a
 * push arrives. (A plain `mutate("notifications")` doesn't reach a paged key.)
 */
export const refreshNotifications = () =>
  globalMutate(unstable_serialize(getKey));

type Pages = NotificationResponse[] | undefined;

const withRead = (pages: Pages, isRead: (n: Notification) => boolean): Pages =>
  pages?.map((page) => {
    let newlyRead = 0;
    const data = page.data.map((n) => {
      if (!n.read && isRead(n)) {
        newlyRead++;
        return { ...n, read: true, readAt: new Date().toISOString() };
      }
      return n;
    });
    return { ...page, data, newlyRead };
  }) as Pages;

/**
 * The user's notifications, newest first, loaded 20 at a time.
 * Shared by the notifications page and the Home bell badge.
 */
export const useNotifications = () => {
  const swr = useSWRInfinite(getKey, fetchPage, {
    revalidateOnFocus: false,
    revalidateFirstPage: true,
    dedupingInterval: 1000 * 60 * 5,
  });
  const { data: pages, size, setSize, mutate, isLoading, isValidating, error } = swr;

  const notifications = useMemo(
    () => pages?.flatMap((page) => page.data) ?? [],
    [pages],
  );
  const first = pages?.[0];
  const last = pages?.[pages.length - 1];
  // Unread count is a server total; adjust it for anything read locally.
  const unreadCount = first
    ? Math.max(
        0,
        first.unreadCount -
          (pages ?? []).reduce((sum, p: any) => sum + (p.newlyRead ?? 0), 0),
      )
    : 0;
  const hasMore = !!last && last.page < last.totalPages;
  const isLoadingMore = isValidating && size > (pages?.length ?? 0);

  const markAllAsRead = async () => {
    // Optimistic: show everything read straight away.
    await mutate(
      (current) =>
        current?.map((page) => ({
          ...page,
          unreadCount: 0,
          data: page.data.map((n) => ({ ...n, read: true })),
        })),
      { revalidate: false },
    );
    try {
      await notification.markNotificationAsRead();
      // Clear the app icon badge too; it used to stay on after reading.
      Notifications.setBadgeCountAsync(0).catch(() => {});
    } finally {
      // Sync with the server either way (rolls back on failure).
      mutate();
    }
  };

  const markAsRead = async (id: string) => {
    const target = notifications.find((n) => n._id === id);
    if (!target || target.read) return;
    await mutate((current) => withRead(current, (n) => n._id === id), {
      revalidate: false,
    });
    try {
      await notification.markOneNotificationAsRead(id);
    } catch {
      mutate(); // roll back to the server's state
    }
  };

  return {
    notifications,
    unreadCount,
    total: first?.total ?? 0,
    hasMore,
    isLoading,
    isLoadingMore,
    isRefreshing: isValidating && !isLoadingMore && !isLoading,
    error,
    loadMore: () => (hasMore && !isLoadingMore ? setSize(size + 1) : undefined),
    refresh: () => mutate(),
    markAllAsRead,
    markAsRead,
  };
};
