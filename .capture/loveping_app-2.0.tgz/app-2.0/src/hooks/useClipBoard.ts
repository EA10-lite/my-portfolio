import * as Clipboard from "expo-clipboard";
import { useState } from "react";

export function useClipboard() {
  const [copied, setCopied] = useState(false);

  const copy = async (text: string) => {
    try {
      await Clipboard.setStringAsync(String(text));

      setCopied(true);

      // reset after 2 seconds
      setTimeout(() => {
        setCopied(false);
      }, 2000);

      return true;
    } catch (error) {
      console.log("Copy failed:", error);
      return false;
    }
  };

  const paste = async () => {
    try {
      return await Clipboard.getStringAsync();
    } catch (error) {
      console.log("Paste failed:", error);
      return "";
    }
  };

  return {
    copy,
    paste,
    copied,
  };
}
