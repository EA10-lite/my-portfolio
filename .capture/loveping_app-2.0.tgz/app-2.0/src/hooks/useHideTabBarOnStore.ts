import { useFocusEffect } from "expo-router";
import { useCallback, useRef } from "react";
import type { NativeScrollEvent, NativeSyntheticEvent } from "react-native";
import { useTabBarStore } from "./useTabStore";

/**
 * Hides the floating tab bar while scrolling down and shows it on scroll up.
 *
 * Doesn't subscribe the screen to the store: it used to read the whole store
 * (`useTabBarStore()`), so every scroll step re-rendered the entire screen —
 * and every other mounted tab — which made long lists stutter and drop
 * swipes.
 */
export const useHideTabBarOnScroll = () => {
  const lastOffset = useRef(0);

  // Coming back to this screen (e.g. from a pushed page): show the bar and
  // restart the direction tracking.
  useFocusEffect(
    useCallback(() => {
      useTabBarStore.getState().setHidden(false);
      lastOffset.current = 0;
    }, []),
  );

  const handleScroll = useCallback(
    (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      const { setHidden } = useTabBarStore.getState();
      const currentOffset = event.nativeEvent.contentOffset.y;
      const diff = currentOffset - lastOffset.current;

      // Always show near the top.
      if (currentOffset <= 20) {
        setHidden(false);
        lastOffset.current = currentOffset;
        return;
      }

      // Ignore tiny movements.
      if (Math.abs(diff) < 10) return;

      setHidden(diff > 0);
      lastOffset.current = currentOffset;
    },
    [],
  );

  return { handleScroll };
};
