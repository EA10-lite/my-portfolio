import { create } from "zustand";

interface TabBarStore {
  hidden: boolean;
  setHidden: (hidden: boolean) => void;
}

export const useTabBarStore = create<TabBarStore>((set, get) => ({
  hidden: false,
  // Only write when the value changes: scroll handlers call this on every
  // step, and each write used to re-render every subscribed screen.
  setHidden: (hidden) => {
    if (get().hidden !== hidden) set({ hidden });
  },
}));
