import { useEffect, useState } from "react";

type PersistedStore = {
  persist: {
    hasHydrated: () => boolean;
    onFinishHydration: (fn: () => void) => () => void;
  };
};

/**
 * True once a persisted Zustand store has finished loading from AsyncStorage.
 * Reading a persisted value (e.g. `isLoggedIn`) before this is true returns
 * the store's default, not what the user saved.
 */
export const useStoreHydrated = (store: PersistedStore) => {
  const [hydrated, setHydrated] = useState(() => store.persist.hasHydrated());

  useEffect(() => {
    const unsubscribe = store.persist.onFinishHydration(() => setHydrated(true));
    // Hydration may have finished between the first render and this effect.
    setHydrated(store.persist.hasHydrated());
    return unsubscribe;
  }, [store]);

  return hydrated;
};
