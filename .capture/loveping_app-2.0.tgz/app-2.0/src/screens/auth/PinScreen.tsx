import { AppText, Avatar } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { signOut } from "@/src/services/session";
import {
  GUEST_LOGOUT_WARNING,
  displayName,
  isGuestUser,
} from "@/src/utils/guest";
import { useUserStore } from "@/src/stores/userStore";
import {
  ERROR,
  PRIMARY,
  SURFACE_KEY,
  WHITE,
  WHITE_08,
  WHITE_20,
  WHITE_80,
  space,
  hit,
} from "@/src/theme";
import { verifyPin } from "@/src/utils/pinStorage";
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, StyleSheet, TouchableOpacity, View } from "react-native";

/**
 * PIN Screen Component
 *
 * Displays a PIN entry interface for user authentication.
 * Matches the design with:
 * - User avatar and welcome message
 * - 6 PIN input dots
 * - Numeric keypad (0-9)
 * - Backspace and logout functionality
 */
const PinScreen = () => {
  const { user } = useUserStore();
  const [pin, setPin] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  // Handle numeric keypad input
  const handleNumberPress = (number: string) => {
    if (pin.length < 6 && !isVerifying) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      const newPin = pin + number;
      setPin(newPin);
      setError("");

      // Auto-verify when 6 digits are entered
      if (newPin.length === 6) {
        handleVerify(newPin);
      }
    }
  };

  // Handle backspace
  const handleBackspace = () => {
    if (pin.length > 0 && !isVerifying) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setPin(pin.slice(0, -1));
      setError("");
    }
  };

  // Verify PIN
  const handleVerify = async (pinToVerify?: string) => {
    const pinToCheck = pinToVerify || pin;

    if (pinToCheck.length !== 6) {
      return;
    }

    setIsVerifying(true);
    setError("");

    try {
      const isValid = await verifyPin(pinToCheck);

      if (isValid) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        // PIN is correct, navigate to main app
        router.replace("/(tabs)");
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        setError("Incorrect PIN. Please try again.");
        setPin("");
      }
    } catch {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setError("Error verifying PIN. Please try again.");
      setPin("");
    } finally {
      setIsVerifying(false);
    }
  };

  // Handle logout
  const handleLogout = () => {
    Alert.alert(
      "Logout",
      isGuestUser(user)
        ? GUEST_LOGOUT_WARNING
        : "Are you sure you want to logout? You'll need to login again.",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Logout",
          style: "destructive",
          // Clears tokens, PIN and all of this user's data on the device.
          onPress: () => signOut(),
        },
      ],
    );
  };

  // First name for the welcome message. (The old code read `user.name`,
  // which doesn't exist on UserDTO, so it always said "User".)
  const firstName = displayName(user).trim().split(/\s+/)[0] || "User";

  return (
    <MainLayout>
      {/* Header: avatar and welcome message */}
      <View style={styles.top}>
        <View style={styles.greeting}>
          <View style={styles.avatarRing}>
            <Avatar size="lg" initials={user?.full_name || "User"} />
          </View>
          <AppText size="base" weight="semibold" style={styles.welcome}>
            Welcome Back, {firstName}
          </AppText>
        </View>

        {/* PIN prompt */}
        <View style={styles.prompt}>
          <AppText
            size="sm"
            weight="medium"
            color={WHITE_80}
            style={styles.promptText}
          >
            Enter Your Pin
          </AppText>

          {/* PIN dots */}
          <View
            style={styles.dots}
            accessibilityRole="text"
            accessibilityLabel={`${pin.length} of 6 digits entered`}
          >
            {[0, 1, 2, 3, 4, 5].map((index) => (
              <View
                key={index}
                style={[
                  styles.dot,
                  { backgroundColor: index < pin.length ? PRIMARY : WHITE_20 },
                ]}
              />
            ))}
          </View>

          {error ? (
            <AppText
              size="sm"
              weight="medium"
              color={ERROR}
              style={styles.error}
              accessibilityLiveRegion="assertive"
            >
              {error}
            </AppText>
          ) : null}
        </View>
      </View>

      {/* Numeric keypad */}
      <View style={styles.keypadArea}>
        <View style={styles.keypad}>
          {[
            [1, 2, 3],
            [4, 5, 6],
            [7, 8, 9],
          ].map((row) => (
            <View key={row.join("")} style={styles.keyRow}>
              {row.map((num) => (
                <KeypadButton
                  key={num}
                  num={num}
                  isVerifying={isVerifying}
                  handleNumberPress={handleNumberPress}
                />
              ))}
            </View>
          ))}

          {/* Row 4: Logout, 0, Backspace */}
          <View style={[styles.keyRow, styles.center]}>
            <TouchableOpacity
              onPress={handleLogout}
              style={styles.logout}
              accessibilityRole="button"
              accessibilityLabel="Log out"
              hitSlop={hit.pill}
            >
              <AppText size="base" weight="medium" color={PRIMARY}>
                Logout
              </AppText>
            </TouchableOpacity>

            <KeypadButton
              num={0}
              isVerifying={isVerifying}
              handleNumberPress={handleNumberPress}
            />

            <TouchableOpacity
              onPress={handleBackspace}
              disabled={isVerifying || pin.length === 0}
              style={styles.key}
              activeOpacity={0.7}
              accessibilityRole="button"
              accessibilityLabel="Delete last digit"
            >
              <MaterialIcons name="backspace" size={24} color={WHITE} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </MainLayout>
  );
};

type KeypadButtonProps = {
  num: number;
  isVerifying: boolean;
  handleNumberPress: (num: string) => void;
};

const KeypadButton = ({
  num,
  isVerifying,
  handleNumberPress,
}: KeypadButtonProps) => {
  return (
    <TouchableOpacity
      onPress={() => handleNumberPress(num.toString())}
      disabled={isVerifying}
      style={styles.key}
      activeOpacity={0.7}
      accessibilityRole="button"
      accessibilityLabel={`${num}`}
    >
      <AppText size="2xl" weight="semibold">
        {num}
      </AppText>
    </TouchableOpacity>
  );
};

const KEY_SIZE = 80;

const styles = StyleSheet.create({
  center: { alignItems: "center" },
  // `flex-1 items-center justify-center mb-12`
  top: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: space[12],
  },
  greeting: {
    alignItems: "center",
    marginTop: space[12],
    marginBottom: space[12],
  },
  // `w-20 h-20 rounded-full bg-white overflow-hidden items-center justify-center mb-4`
  avatarRing: {
    width: space[20],
    height: space[20],
    borderRadius: space[20] / 2,
    backgroundColor: WHITE,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: space[4],
  },
  welcome: { marginTop: space[2] },
  prompt: { alignItems: "center", marginBottom: space[8] },
  promptText: { marginBottom: space[6] },
  dots: { flexDirection: "row", gap: space[3] },
  dot: { width: space[3], height: space[3], borderRadius: space[3] / 2 },
  error: { marginTop: space[4] },
  // `flex-1 justify-end px-6 pb-8 mt-12`
  keypadArea: {
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: space[6],
    paddingBottom: space[8],
    marginTop: space[12],
  },
  // `gap-4 mb-4 w-[80%] mx-auto`
  keypad: {
    gap: space[4],
    marginBottom: space[4],
    width: "80%",
    alignSelf: "center",
  },
  keyRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: space[6],
  },
  key: {
    width: KEY_SIZE,
    height: KEY_SIZE,
    borderRadius: KEY_SIZE / 2,
    backgroundColor: SURFACE_KEY,
    alignItems: "center",
    justifyContent: "center",
  },
  // `px-4 py-1.5 rounded-[28px] bg-[#FFFFFF08] border-[1.35px] border-[#FFFFFF08]`
  logout: {
    paddingHorizontal: space[4],
    paddingVertical: space[1.5],
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: WHITE_08,
    borderWidth: 1.35,
    borderColor: WHITE_08,
  },
});

export default PinScreen;
