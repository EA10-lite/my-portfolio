import BirthdayIcon from "@/assets/icons/birthday.svg";
import MessageIcon from "@/assets/icons/message.svg";
import { AppText } from "@/src/components";
import { usePartnerStore } from "@/src/stores/partnerStore";
import {
  PRIMARY,
  PRIMARY_14,
  WHITE_08,
  WHITE_80,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { formatDateShort } from "@/src/utils/formatter";
import { Feather } from "@expo/vector-icons";
import { StyleSheet, View } from "react-native";

/** Anniversary and birthday tiles on the Home tab. */
const UpcomingNudges = () => {
  const { partner } = usePartnerStore();
  const { isSm } = useResponsive();

  const anniversaryDate = partner?.anniversary_date;
  const birthdayDate = partner?.partner_birthday;

  const allNudges = [
    {
      id: 1,
      title: "Anniversary",
      date: anniversaryDate,
      iconBgColor: "#FA5EBC1A",
      iconBorderColor: "#FA5EBC1A",
      icon: <Feather name="calendar" size={20} color="#FA5EBC" />,
    },
    {
      id: 2,
      title: "Birthday",
      date: birthdayDate,
      iconBgColor: "#3870F31A",
      iconBorderColor: "#3870F31A",
      icon: <BirthdayIcon />,
    },
  ];

  return (
    <View>
      {allNudges.length > 0 && (
        <AppText
          size="base"
          weight="medium"
          style={{ marginBottom: rs(isSm, space[4], space[6]) }}
        >
          Upcoming
        </AppText>
      )}

      <View style={styles.row}>
        {allNudges.map((nudge) => (
          <View style={styles.fill} key={nudge.id}>
            <UpcomingNudgeItem
              title={nudge.title}
              date={nudge?.date || ""}
              icon={nudge.icon}
              iconBgColor={nudge.iconBgColor}
              iconBorderColor={nudge.iconBorderColor}
            />
          </View>
        ))}
      </View>
    </View>
  );
};

type UpcomingNudgeItemProps = {
  title: string;
  date: string;
  icon?: React.ReactNode;
  iconBgColor?: string;
  iconBorderColor?: string;
};

const UpcomingNudgeItem = ({
  title,
  date,
  icon = <MessageIcon color={PRIMARY} />,
  iconBgColor = "#48D9621A", // primary-1A
  iconBorderColor = "#48D9621A", // primary-1A
}: UpcomingNudgeItemProps) => {
  const { isSm } = useResponsive();
  return (
    <View style={[styles.tile, { padding: rs(isSm, space[3], space[4]) }]}>
      <View
        style={[
          styles.icon,
          {
            backgroundColor: iconBgColor,
            borderColor: iconBorderColor,
            marginBottom: rs(isSm, space[3], space[4]),
          },
        ]}
      >
        {icon}
      </View>
      <AppText size="sm" weight="medium" numberOfLines={1} style={styles.title}>
        {title}
      </AppText>
      <AppText size="xs" weight="medium" color={WHITE_80} numberOfLines={1}>
        {formatDateShort(date)}
      </AppText>
    </View>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: space[4],
  },
  // `bg-white-08 border border-primary-14 rounded-md w-full`
  tile: {
    width: "100%",
    backgroundColor: WHITE_08,
    borderWidth: 1,
    borderColor: PRIMARY_14,
    borderRadius: radii.md,
  },
  icon: {
    width: space[10],
    height: space[10],
    borderRadius: space[10] / 2,
    borderWidth: 0.5,
    alignItems: "center",
    justifyContent: "center",
  },
  title: { marginBottom: space[1] },
});

export default UpcomingNudges;
