import Logo from "@/assets/icons/logo.svg";
import { SECONDARY, space } from "@/src/theme";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { useEffect } from "react";
import { ImageBackground, StyleSheet, View } from "react-native";

/** How long the first-launch welcome illustration stays up. */
const WELCOME_DURATION_MS = 2000;

/** First-launch only: brand illustration, then onboarding. */
const WelcomScreen = () => {
  useEffect(() => {
    AsyncStorage.setItem("loveping-has-seen-welcome", "true").catch(() => {});
    const timer = setTimeout(() => {
      router.replace("/onboarding");
    }, WELCOME_DURATION_MS);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.screen}>
      <ImageBackground
        source={require("@/assets/images/welcome.webp")}
        style={styles.image}
        accessibilityIgnoresInvertColors
      />
      <View style={styles.logo} accessibilityRole="image" accessibilityLabel="Loveping">
        <Logo />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: SECONDARY },
  image: { flex: 1, backgroundColor: SECONDARY },
  // `absolute top-24 left-0 right-0 z-50 items-center`
  logo: {
    position: "absolute",
    top: space[24],
    left: 0,
    right: 0,
    zIndex: 50,
    alignItems: "center",
    justifyContent: "center",
  },
});

export default WelcomScreen;
