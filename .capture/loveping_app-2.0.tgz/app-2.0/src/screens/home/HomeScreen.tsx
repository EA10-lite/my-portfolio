import { useTabBarClearance } from "@/src/components/tabBarMetrics";
import { MainLayout } from "@/src/layouts/index";
import { router } from "expo-router";
import { ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";

import NotificationIcon from "@/assets/icons/notification.svg";

import CallIcon from "@/assets/icons/call.svg";
import TextIcon from "@/assets/icons/message-alt.svg";
import { AppText, FieldItem, NotLoggedIn } from "@/src/components";
import { usePartnerStore, useToastStore, useUserStore } from "@/src/stores";
import { Feather } from "@expo/vector-icons";
import UpcomingNudges from "./components/Upcoming";
import { UpdateBanner } from "@/src/features/appUpdate";

import { usePushNotifications } from "@/src/context/PushNotificationProvider";
import { useHideTabBarOnScroll } from "@/src/hooks/useHideTabBarOnStore";
import { useNotifications } from "@/src/hooks/useNotifications";
import auth from "@/src/services/auth";
import {
  BLUE_LIGHT_1A,
  ERROR,
  PRIMARY_08,
  PRIMARY_14,
  PRIMARY_1A,
  PURPLE_LIGHT_1A,
  WHITE_08,
  WHITE_80,
  YELLOW_1A,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { normalizeToString } from "@/src/utils/formatter";
import { displayName } from "@/src/utils/guest";
import { useEffect, useRef } from "react";
import useSWR from "swr";

const nudgeItems = [
  {
    id: 1,
    title: "Text Nudge",
    description: "It’s a great time to send a message",
    icon: <TextIcon width={20} height={20} />,
    iconBgColor: PURPLE_LIGHT_1A,
    iconBorderColor: PURPLE_LIGHT_1A,
    type: "text",
  },
  {
    id: 2,
    title: "Call Nudge",
    description: "A brief call could mean alot",
    icon: <CallIcon width={20} height={20} />,
    iconBgColor: BLUE_LIGHT_1A,
    iconBorderColor: BLUE_LIGHT_1A,
    type: "call",
  },
  {
    id: 5,
    title: "Gift Nudge",
    description: "Her birthday is coming up soon!",
    icon: <Feather name="gift" size={20} color="#D7BA38" />,
    iconBgColor: YELLOW_1A,
    iconBorderColor: YELLOW_1A,
    type: "gift",
    isComingSoon: true,
  },
];

const HomeScreen = () => {
  const { handleScroll } = useHideTabBarOnScroll();
  // Room for the floating tab bar on this device.
  const bottomSpace = useTabBarClearance();
  const { user } = useUserStore();
  const { partner } = usePartnerStore();
  const { showToast } = useToastStore();
  const { scheduleUpcomingPings } = usePushNotifications();
  // Own cache key: Profile used to share "/" and could get dashboard data.
  const { data } = useSWR("dashboard", auth.getDashboard, {
    revalidateOnFocus: false,
  });
  const { unreadCount } = useNotifications();
  const { isSm } = useResponsive();
  const pad = rs(isSm, space[4], space[6]);

  const handleNudgeClick = (type: string) => {
    if (type === "text") {
      if (data?.data?.todays_ping?.text_ping?.length <= 0) {
        showToast("No text nudges available", "success");
      } else {
        router.push({
          pathname: "/nudge/text",
          params: {
            message: data?.data?.todays_ping?.text_ping[0]?.message,
            id: data?.data?.todays_ping?.text_ping[0]?._id,
            tone: normalizeToString(
              data?.data?.todays_ping?.text_ping[0]?.tone,
            ),
            dayOfWeek: normalizeToString(
              data?.data?.todays_ping?.text_ping[0]?.DayOfWeek,
            ),
          },
        });
      }
    } else if (type === "call") {
      if (data?.data?.todays_ping?.call_ping?.length <= 0) {
        showToast("No call nudges available", "success");
      } else {
        router.push("/nudge/call");
      }
    } else if (type === "gift") {
    }
  };

  // Schedule local reminders when the dashboard data changes. This used to
  // run on every render, cancelling and re-creating notifications each time.
  const scheduleRef = useRef(scheduleUpcomingPings);
  scheduleRef.current = scheduleUpcomingPings;
  const upcomingPings = data?.data?.upcoming_pings;
  useEffect(() => {
    if (upcomingPings) {
      scheduleRef.current(upcomingPings);
    }
  }, [upcomingPings]);

  return (
    <MainLayout showBottomPadding={false}>
      <View style={[styles.header, { padding: pad }]}>
        <View style={styles.greeting}>
          <AppText
            size="lg"
            weight="semibold"
            numberOfLines={1}
            style={styles.hello}
            accessibilityRole="header"
          >
            Hello {displayName(user)}
          </AppText>
          <AppText size="xs" weight="medium" color={WHITE_80} numberOfLines={1}>
            Your gentle reminder to keep the spark alive
          </AppText>
        </View>
        <TouchableOpacity
          style={styles.bell}
          onPress={() => router.push("/notification")}
          accessibilityRole="button"
          accessibilityLabel={
            unreadCount > 0
              ? `Notifications, ${unreadCount} unread`
              : "Notifications"
          }
        >
          <NotificationIcon width={20} height={20} />

          {unreadCount > 0 && (
            <View style={styles.badge}>
              <AppText weight="bold" style={styles.badgeText}>
                {unreadCount > 99 ? "99+" : unreadCount}
              </AppText>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomSpace }]}
        style={styles.fill}
        onScroll={handleScroll}
      >
        <View style={{ padding: pad }}>
          <UpdateBanner
            style={{ marginBottom: rs(isSm, space[4], space[6]) }}
          />
          <View
            style={[
              styles.card,
              {
                padding: rs(isSm, space[4], space[5]),
                marginBottom: rs(isSm, space[4], space[6]),
              },
            ]}
          >
            <AppText size="base" weight="medium" style={styles.cardTitle}>
              Today&apos;s Nudges
            </AppText>

            <View style={styles.list}>
              {nudgeItems.map((item) => (
                <FieldItem
                  key={item.id}
                  {...item}
                  onPress={() => handleNudgeClick(item.type)}
                  variant="outline"
                  numberOfLines={1}
                />
              ))}
            </View>
          </View>

          {partner && <UpcomingNudges />}
        </View>
        {user?.is_guest && <NotLoggedIn />}
      </ScrollView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1 },
  // `flex-row items-center justify-between border-b border-primary-1A`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  greeting: { flex: 1, flexShrink: 1, marginRight: space[2] },
  hello: { marginBottom: space[1] },
  // `w-12 h-12 rounded-full bg-primary-08 border border-primary-08`
  bell: {
    width: space[12],
    height: space[12],
    borderRadius: space[12] / 2,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: PRIMARY_08,
    borderWidth: 1,
    borderColor: PRIMARY_08,
    flexShrink: 0,
  },
  // `absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-error`
  badge: {
    position: "absolute",
    top: -4,
    right: -4,
    minWidth: 20,
    height: 20,
    paddingHorizontal: space[1],
    borderRadius: 10,
    backgroundColor: ERROR,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: { fontSize: 10, lineHeight: 12 },
  // `bg-white-08 rounded-lg border border-primary-14`
  card: {
    backgroundColor: WHITE_08,
    borderRadius: radii.lg,
    borderWidth: 1,
    borderColor: PRIMARY_14,
  },
  cardTitle: { marginBottom: space[4] },
  list: { gap: space[3] },
});

export default HomeScreen;
