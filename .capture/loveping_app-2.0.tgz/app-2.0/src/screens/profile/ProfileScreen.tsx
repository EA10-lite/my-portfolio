import { useTabBarClearance } from "@/src/components/tabBarMetrics";
import EditIcon from "@/assets/icons/edit.svg";
import Logout from "@/assets/icons/logout.svg";
import { AppText, Avatar, DeleteModal, FieldItem } from "@/src/components";
import { MainLayout } from "@/src/layouts/index";
import { usePartnerStore, useUserStore } from "@/src/stores";
import { ScrollView, StyleSheet, TouchableOpacity, View } from "react-native";

import AccountIcon from "@/assets/icons/account.svg";
import FileIcon from "@/assets/icons/file.svg";
import SettingsIcon from "@/assets/icons/setting.svg";
import StarIcon from "@/assets/icons/star.svg";
import SupportIcon from "@/assets/icons/support.svg";
import {
  BLUE_1A,
  CYAN_1A,
  DANGER_1A,
  ERROR_40,
  ORANGE_1A,
  PRIMARY,
  PRIMARY_1A,
  PURPLE_LIGHT_26,
  WHITE_08,
  WHITE_80,
  YELLOW_1A,
  radii,
  rs,
  space,
  useGutter,
  useResponsive,
  hit,
} from "@/src/theme";
import { signOut } from "@/src/services/session";
import {
  GUEST_LOGOUT_WARNING,
  displayName,
  isGuestUser,
} from "@/src/utils/guest";
import { useHideTabBarOnScroll } from "@/src/hooks/useHideTabBarOnStore";
import auth from "@/src/services/auth";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { router } from "expo-router";
import { useEffect, useRef } from "react";
import useSWR from "swr";

const profileItems = [
  {
    id: 1,
    title: "My Account",
    description: "Manage profile and login details",
    icon: <AccountIcon width={20} height={20} />,
    iconBgColor: PURPLE_LIGHT_26,
    iconBorderColor: PURPLE_LIGHT_26,
    onPress: () => router.push("/profile/account"),
  },
  {
    id: 2,
    title: "My Content",
    description: "Access saved notes, gifts, and history",
    icon: <FileIcon width={20} height={20} />,
    iconBgColor: ORANGE_1A,
    iconBorderColor: ORANGE_1A,
    onPress: () => router.push("/profile/content"),
  },
  {
    id: 3,
    title: "App Settings",
    description: "Set preferences and notifications",
    icon: <SettingsIcon width={20} height={20} />,
    iconBgColor: CYAN_1A,
    iconBorderColor: CYAN_1A,
    onPress: () => router.push("/profile/settings"),
  },
  {
    id: 4,
    title: "Support",
    description: "Get help or contact us anytime",
    icon: <SupportIcon width={20} height={20} />,
    iconBgColor: BLUE_1A,
    iconBorderColor: BLUE_1A,
    onPress: () => router.push("/profile/support"),
  },
  {
    id: 5,
    title: "Others",
    description: "Rate, share, and learn about Loveping",
    icon: <StarIcon width={20} height={20} />,
    iconBgColor: YELLOW_1A,
    iconBorderColor: YELLOW_1A,
    onPress: () => router.push("/profile/others"),
  },
];

const ProfileScreen = () => {
  const { handleScroll } = useHideTabBarOnScroll();
  // Room for the floating tab bar on this device.
  const bottomSpace = useTabBarClearance();
  const { user, setUser } = useUserStore();
  const guest = isGuestUser(user);
  const { setPartner } = usePartnerStore();
  const { isSm } = useResponsive();
  const px = useGutter();

  const modalRef = useRef<BottomSheetModal>(null);
  const openDeleteModal = () => modalRef.current?.present();
  const closeDeleteModal = () => modalRef.current?.dismiss();

  // Own cache key: Home used to share "/" and could get dashboard data.
  const { data, isLoading } = useSWR("profile", auth.getProfile, {
    revalidateOnFocus: false,
  });

  useEffect(() => {
    if (data && data?.partner && !isLoading) {
      setPartner(data.partner);
    }
  }, [data, isLoading, setPartner, setUser, user]);

  const fields = [
    {
      label: "Nudges sent",
      value: data?.nudges_count?.total || 0,
    },
    {
      label: "Call Nudges",
      value: data?.nudges_count?.call || 0,
    },
    {
      label: "Gifts shared",
      value: data?.nudges_count?.gift || 0,
    },
  ];

  return (
    <MainLayout showBottomPadding={false}>
      <View style={[styles.header, { paddingHorizontal: px }]}>
        <AppText size="base" weight="semibold" accessibilityRole="header">
          Profile
        </AppText>
        <TouchableOpacity
          style={styles.logout}
          onPress={openDeleteModal}
          accessibilityRole="button"
          accessibilityLabel="Log out"
          hitSlop={hit.circle}
        >
          <Logout width={20} height={20} />
        </TouchableOpacity>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomSpace }]}
        onScroll={handleScroll}
      >
        <View style={{ padding: px }}>
          <View style={{ marginBottom: rs(isSm, space[6], space[8]) }}>
            <View
              style={[
                styles.userRow,
                { marginBottom: rs(isSm, space[4], space[6]) },
              ]}
            >
              <View
                style={[styles.user, { gap: rs(isSm, space[3], space[5]) }]}
              >
                {user?.full_name && <Avatar initials={displayName(user)} />}

                <View style={styles.userText}>
                  <AppText
                    size="sm"
                    weight="semibold"
                    numberOfLines={1}
                    style={styles.name}
                  >
                    {displayName(user)}
                  </AppText>
                  <AppText size="xs" color={WHITE_80} numberOfLines={1}>
                    {/* Guests have a placeholder `@anonymous.local` email. */}
                    {guest ? "Guest account · not backed up" : user?.email_address}
                  </AppText>
                </View>
              </View>

              <TouchableOpacity
                style={styles.edit}
                onPress={() => router.push("/profile/account")}
                accessibilityRole="button"
                accessibilityLabel="Edit account"
                hitSlop={hit.glyph}
              >
                <EditIcon width={16} height={16} />
              </TouchableOpacity>
            </View>
            <View
              style={[
                styles.stats,
                {
                  padding: rs(isSm, space[4], space[6]),
                  gap: rs(isSm, space[2], space[4]),
                },
              ]}
            >
              {fields.map((field, index) => (
                <Field key={index} label={field.label} value={field.value} />
              ))}
            </View>
          </View>

          <View>
            <AppText
              size="sm"
              weight="semibold"
              color={PRIMARY}
              style={{ marginBottom: rs(isSm, space[6], space[8]) }}
            >
              Settings
            </AppText>
            <View style={{ gap: rs(isSm, space[6], space[8]) }}>
              {profileItems.map((item) => (
                <FieldItem
                  key={item.id}
                  title={item.title}
                  description={item.description}
                  icon={item.icon}
                  iconBgColor={item.iconBgColor}
                  iconBorderColor={item.iconBorderColor}
                  onPress={item.onPress}
                  variant="ghost"
                />
              ))}
            </View>
          </View>
        </View>
      </ScrollView>

      <DeleteModal
        ref={modalRef}
        onClose={closeDeleteModal}
        onCancel={closeDeleteModal}
        onDelete={() => {
          closeDeleteModal();
          signOut();
        }}
        title={"Logout"}
        message={
          guest ? GUEST_LOGOUT_WARNING : "Are you sure you want to logout?"
        }
        cancelButtonText="Cancel"
        deleteButtonText="Logout"
        icon={<Logout width={24} height={24} />}
      />
    </MainLayout>
  );
};

type FieldProps = {
  label: string;
  value: number;
};

const Field = ({ label, value }: FieldProps) => {
  return (
    <View style={styles.field}>
      <AppText size="sm" weight="semibold">
        {value}
      </AppText>
      <AppText size="xs" color={WHITE_80}>
        {label}
      </AppText>
    </View>
  );
};

const styles = StyleSheet.create({
  scroll: { flexGrow: 1 },
  // `flex-row items-center justify-between border-b border-[#48D9621A] py-4`
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: space[4],
    borderBottomWidth: 1,
    borderBottomColor: PRIMARY_1A,
  },
  // `w-10 h-10 rounded-full bg-danger-1A border border-error-40`
  logout: {
    width: space[10],
    height: space[10],
    borderRadius: space[10] / 2,
    backgroundColor: DANGER_1A,
    borderWidth: 1,
    borderColor: ERROR_40,
    alignItems: "center",
    justifyContent: "center",
  },
  userRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  user: { flexDirection: "row", alignItems: "center", flex: 1, flexShrink: 1 },
  userText: { flex: 1, flexShrink: 1 },
  name: { marginBottom: space[1], textTransform: "capitalize" },
  edit: { flexShrink: 0, marginLeft: space[2] },
  // `border border-[#48D9621A] bg-[#FFFFFF08] rounded-[10px] flex-row items-center justify-between`
  stats: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: PRIMARY_1A,
    backgroundColor: WHITE_08,
    borderRadius: radii.md,
  },
  field: { flexDirection: "column", gap: space[3] },
});

export default ProfileScreen;
