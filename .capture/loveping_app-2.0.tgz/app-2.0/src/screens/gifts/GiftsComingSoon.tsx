import { AppText, Button } from "@/src/components";
import { useTabBarClearance } from "@/src/components/tabBarMetrics";
import { useHideTabBarOnScroll } from "@/src/hooks/useHideTabBarOnStore";
import { MainLayout } from "@/src/layouts";
import { usePartnerStore } from "@/src/stores";
import {
  BLUE_LIGHT,
  BLUE_LIGHT_1A,
  ERROR,
  PINK,
  PINK_1A,
  PRIMARY_14,
  PURPLE_LIGHT,
  PURPLE_LIGHT_1A,
  SECONDARY,
  WHITE_08,
  WHITE_80,
  YELLOW,
  YELLOW_1A,
  layout,
  radii,
  rs,
  space,
  useResponsive,
} from "@/src/theme";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { ScrollView, StyleSheet, View, useWindowDimensions } from "react-native";

const YELLOW_33 = "#D7BA3833";
const YELLOW_40 = "#D7BA3840";

type Feature = {
  icon: keyof typeof Feather.glyphMap;
  color: string;
  bg: string;
  title: string;
  body: string;
};

/**
 * Gifts isn't integrated yet: this explains what's coming and offers one
 * useful action meanwhile. Design: "Loveping Gifts Coming Soon", option A.
 */
const GiftsComingSoon = () => {
  const { partner } = usePartnerStore();
  const { isSm } = useResponsive();
  const { handleScroll } = useHideTabBarOnScroll();
  const bottomSpace = useTabBarClearance();
  const px = rs(isSm, space[4], space[6]);
  const name = partner?.partner_name?.trim() || "your partner";
  // Shorter phones (most 360dp Androids, iPhone SE): smaller hero and
  // tighter gaps so the button stays above the tab bar without scrolling.
  const { height } = useWindowDimensions();
  const compact = height < 800;
  const gap = compact ? space[5] : space[7];

  const features: Feature[] = [
    {
      icon: "heart",
      color: PINK,
      bg: PINK_1A,
      title: `Ideas picked for ${name}`,
      body: "Matched to their love language and what they enjoy.",
    },
    {
      icon: "calendar",
      color: BLUE_LIGHT,
      bg: BLUE_LIGHT_1A,
      title: "Nudges before big days",
      body: "A heads-up ahead of birthdays and anniversaries.",
    },
    {
      icon: "bookmark",
      color: PURPLE_LIGHT,
      bg: PURPLE_LIGHT_1A,
      title: "A wishlist to come back to",
      body: "Save ideas now, decide when the moment’s right.",
    },
  ];

  return (
    <MainLayout showBottomPadding={false}>
      <View style={[styles.header, { paddingHorizontal: px }]}>
        <AppText size="base" weight="semibold" accessibilityRole="header">
          Gifts
        </AppText>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        scrollEventThrottle={16}
        onScroll={handleScroll}
        contentContainerStyle={[
          styles.content,
          {
            paddingHorizontal: px,
            paddingBottom: bottomSpace,
            paddingTop: compact ? space[6] : space[10],
          },
        ]}
      >
        <View
          style={[styles.hero, compact && styles.heroCompact, { marginBottom: gap }]}
          accessible
          accessibilityLabel="Gifts, coming soon"
        >
          <View style={styles.ringOuter} />
          <View style={styles.ringInner} />
          <Feather name="gift" size={compact ? 42 : 52} color={YELLOW} />
          <View style={styles.dot} />
        </View>

        <View style={styles.badge}>
          <AppText size="xs" weight="semibold" color={YELLOW} style={styles.badgeText}>
            COMING SOON
          </AppText>
        </View>

        <AppText size="xl" weight="semibold" align="center" style={styles.title}>
          Thoughtful gifts, at the right moment
        </AppText>
        <AppText
          size="sm"
          weight="medium"
          color={WHITE_80}
          align="center"
          style={[styles.lead, { marginBottom: gap }]}
        >
          We’re building a gift space that knows your partner. Here’s what it’ll do:
        </AppText>

        <View style={[styles.features, { marginBottom: gap }]}>
          {features.map((f) => (
            <View key={f.title} style={[layout.surface, styles.feature]}>
              <View style={[styles.featureIcon, { backgroundColor: f.bg }]}>
                <Feather name={f.icon} size={18} color={f.color} />
              </View>
              <View style={styles.featureText}>
                <AppText size="sm" weight="semibold">
                  {f.title}
                </AppText>
                <AppText size="xs" weight="medium" color={WHITE_80}>
                  {f.body}
                </AppText>
              </View>
            </View>
          ))}
        </View>

        <Button
          title="Send a love note instead"
          variant="primary"
          size="lg"
          onPress={() => router.push("/messages/new")}
          Icon={<Feather name="message-circle" size={18} color={SECONDARY} />}
          style={styles.cta}
        />
      </ScrollView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  header: { ...layout.headerRule, paddingVertical: space[4] },
  content: { flexGrow: 1, alignItems: "center" },
  hero: {
    width: 132,
    height: 132,
    alignItems: "center",
    justifyContent: "center",
  },
  heroCompact: { width: 108, height: 108 },
  ringOuter: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 999,
    backgroundColor: YELLOW_1A,
    borderWidth: 1,
    borderColor: YELLOW_33,
  },
  ringInner: {
    position: "absolute",
    top: 18,
    left: 18,
    right: 18,
    bottom: 18,
    borderRadius: 999,
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: YELLOW_40,
  },
  // The red dot from the app icon.
  dot: {
    position: "absolute",
    top: 14,
    right: 18,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: ERROR,
    borderWidth: 3,
    borderColor: SECONDARY,
  },
  badge: {
    paddingHorizontal: space[3],
    paddingVertical: space[1],
    borderRadius: radii["2xl"],
    backgroundColor: YELLOW_1A,
    marginBottom: space[3.5],
  },
  badgeText: { letterSpacing: 0.5 },
  title: { maxWidth: 320, marginBottom: space[2] },
  lead: { maxWidth: 300 },
  features: { alignSelf: "stretch", gap: space[3] },
  feature: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: space[3.5],
    paddingVertical: space[3.5],
    paddingHorizontal: space[4],
    borderColor: PRIMARY_14,
    backgroundColor: WHITE_08,
  },
  featureIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  featureText: { flex: 1, gap: 2 },
  cta: { alignSelf: "stretch" },
});

export default GiftsComingSoon;
