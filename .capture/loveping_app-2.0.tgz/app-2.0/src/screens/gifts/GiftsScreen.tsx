import GiftsComingSoon from "./GiftsComingSoon";
import GiftsTabsScreen from "./GiftsTabsScreen";

/**
 * Gifts isn't backed by the API yet (suggestions, saved and history are
 * local placeholders), so the tab shows a coming-soon screen. Flip this
 * once the gift endpoints exist to bring back the full tab.
 */
export const GIFTS_ENABLED = false;

export default function GiftsScreen() {
  return GIFTS_ENABLED ? <GiftsTabsScreen /> : <GiftsComingSoon />;
}
