import { useTabBarClearance } from "@/src/components/tabBarMetrics";
import { useHideTabBarOnScroll } from "@/src/hooks/useHideTabBarOnStore";
import { rs, space, useResponsive } from "@/src/theme";
import { ReactNode } from "react";
import { ScrollView, StyleSheet, View } from "react-native";

/** Scrolling column of gift cards with the tab bar hide-on-scroll behaviour. */
const GiftList = ({
  children,
  footer,
}: {
  children: ReactNode;
  footer?: ReactNode;
}) => {
  const { handleScroll } = useHideTabBarOnScroll();
  // Room for the floating tab bar on this device.
  const bottomSpace = useTabBarClearance();
  const { isSm } = useResponsive();
  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      scrollEventThrottle={16}
      contentContainerStyle={[styles.scroll, { paddingBottom: bottomSpace }]}
      onScroll={handleScroll}
    >
      <View
        style={{
          paddingHorizontal: rs(isSm, space[4], space[6]),
          gap: rs(isSm, space[4], space[6]),
        }}
      >
        {children}
      </View>
      {footer}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scroll: { flexGrow: 1, gap: space[4] },
});

export default GiftList;
