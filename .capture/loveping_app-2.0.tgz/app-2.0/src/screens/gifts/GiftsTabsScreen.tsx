import { FilterModal, ReusableTab, TabScreenHeader } from "@/src/components";
import { MainLayout } from "@/src/layouts/index";
import { useFilterStore, useNavigationStore } from "@/src/stores";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { router } from "expo-router";
import { useRef } from "react";
import { StyleSheet, View } from "react-native";
import History from "./tabs/History";
import Saved from "./tabs/Saved";
import Suggestions from "./tabs/Suggestions";

/** The full Gifts tab (suggestions, saved, history). Not live yet: see GiftsScreen. */
export default function GiftsTabsScreen() {
  const { giftsActiveTab, setGiftsActiveTab } = useNavigationStore();
  const { selectedTones, selectedGiftTypes } = useFilterStore();

  const filterRef = useRef<BottomSheetModal>(null);
  const openFilterModal = () => filterRef.current?.present();
  const closeFilterModal = () => filterRef.current?.dismiss();

  const tabs = [
    { id: "suggestions", label: "Suggestions", content: <Suggestions /> },
    { id: "saved", label: "Saved", content: <Saved /> },
    { id: "history", label: "History", content: <History /> },
  ];

  return (
    <MainLayout showBottomPadding={false}>
      <TabScreenHeader
        title="Gifts"
        onSearch={() => router.push("/search")}
        onFilter={openFilterModal}
        activeFilters={selectedTones.length + selectedGiftTypes.length}
      />

      <View style={styles.fill}>
        <ReusableTab
          tabs={tabs}
          activeTab={giftsActiveTab}
          onTabChange={(tab) =>
            setGiftsActiveTab(tab as "suggestions" | "saved" | "history")
          }
        />
      </View>

      <FilterModal ref={filterRef} onClose={closeFilterModal} type="gift" />
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
});
