import GiftIcon from "@/assets/icons/save.svg";
import { Empty, GiftCard } from "@/src/components";
import { defaultGifts, useGiftStore } from "@/src/stores/giftStore";
import GiftList from "../components/GiftList";

const Suggestions = () => {
  const { saveGift, _giftIds } = useGiftStore();
  const suggestions = defaultGifts.filter(
    (gift) => !_giftIds?.includes(gift.id),
  );

  // Used to render a blank tab once every suggestion had been saved.
  if (suggestions.length === 0) {
    return (
      <Empty
        icon={<GiftIcon width={24} height={24} />}
        description="You've saved every suggestion. Check your Saved tab."
      />
    );
  }

  return (
    <GiftList>
      {suggestions.map((gift) => (
        <GiftCard
          key={gift.id}
          title={gift.title}
          icon={gift.icon}
          isSaved={false}
          handleSave={() => saveGift(gift.id)}
        />
      ))}
    </GiftList>
  );
};

export default Suggestions;
