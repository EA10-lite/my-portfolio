import SavedIcon from "@/assets/icons/save.svg";
import { DeleteModal, Empty, GiftCard } from "@/src/components";
import { useToastStore } from "@/src/stores";
import { StyleSheet, View } from "react-native";
import GiftList from "../components/GiftList";

import { useGiftStore } from "@/src/stores/giftStore";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { useRef, useState } from "react";

const Saved = () => {
  const { showToast } = useToastStore();
  const { gifts, removeGift } = useGiftStore();

  const [selectedId, setSelectedId] = useState<number | null>(null);
  const deleteModal = useRef<BottomSheetModal>(null);
  const openDeleteModal = (id: number) => {
    setSelectedId(id);
    deleteModal.current?.present();
  };
  const closeDeleteModal = () => {
    setSelectedId(null);
    deleteModal.current?.dismiss();
  };

  const [deleting, setDeleting] = useState<boolean>(false);
  const handleRemove = async () => {
    setDeleting(true);

    await new Promise((resolve) => setTimeout(resolve, 1000));

    removeGift(selectedId as number);
    setDeleting(false);
    closeDeleteModal();
    showToast("Removed", "success", "top");
  };

  return (
    <View style={styles.fill}>
      {gifts.length === 0 ? (
        <Empty
          icon={<SavedIcon width={24} height={24} />}
          description="No saved nudges yet"
        />
      ) : (
        <GiftList
          footer={
            <DeleteModal
              ref={deleteModal}
              title={"Remove Gift?"}
              message={
                "This gift will be permanently removed from your Wishlist"
              }
              onClose={closeDeleteModal}
              onCancel={closeDeleteModal}
              onDelete={handleRemove}
              deleteButtonText="Remove"
              deleting={deleting}
            />
          }
        >
          {gifts.map((gift) => (
            <GiftCard
              key={gift.id}
              title={gift.title || ""}
              icon={gift.icon}
              isSaved={true}
              handleRemove={() => openDeleteModal(gift.id)}
            />
          ))}
        </GiftList>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
});

export default Saved;
