import HistoryIcon from "@/assets/icons/file-primary.svg";
import { DeleteModal, Empty, GiftCard } from "@/src/components";
import { useToastStore } from "@/src/stores";
import { useRef, useState } from "react";
import { StyleSheet, View } from "react-native";
import GiftList from "../components/GiftList";

import { useGiftStore } from "@/src/stores/giftStore";
import { BottomSheetModal } from "@gorhom/bottom-sheet";

const History = () => {
  const { showToast } = useToastStore();
  const { removeGift, gifts } = useGiftStore();

  const [selectedId, setSelectedId] = useState<number | null>(null);
  const deleteModal = useRef<BottomSheetModal>(null);
  const openDeleteModal = (id: number) => {
    setSelectedId(id);
    deleteModal.current?.present();
  };
  const closeDeleteModal = () => {
    setSelectedId(null);
    deleteModal.current?.dismiss();
  };
  // Keep deleting state local as it's component-specific UI state
  const [deleting, setDeleting] = useState<boolean>(false);

  const handleDelete = async () => {
    setDeleting(true);

    await new Promise((resolve) => setTimeout(resolve, 1000));

    removeGift(selectedId as number);
    setDeleting(false);
    closeDeleteModal();
    showToast("Deleted", "error", "top");
  };

  return (
    <View style={styles.fill}>
      {gifts.length === 0 ? (
        <Empty
          icon={<HistoryIcon width={24} height={24} />}
          description="Your history is empty"
        />
      ) : (
        <GiftList
          footer={
            <DeleteModal
              ref={deleteModal}
              title={"Delete Gift?"}
              message={
                "This gift will be permanently removed from your Wishlist"
              }
              onClose={closeDeleteModal}
              onCancel={closeDeleteModal}
              onDelete={handleDelete}
              deleting={deleting}
            />
          }
        >
          {gifts.map((gift) => (
            <GiftCard
              key={gift.id}
              title={gift.title}
              icon={gift.icon}
              isHistory={true}
              handleDelete={() => openDeleteModal(gift.id)}
            />
          ))}
        </GiftList>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
});

export default History;
