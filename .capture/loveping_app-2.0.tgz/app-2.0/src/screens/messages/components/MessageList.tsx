import { useTabBarClearance } from "@/src/components/tabBarMetrics";
import { Empty, MessageCard } from "@/src/components";
import { useHideTabBarOnScroll } from "@/src/hooks/useHideTabBarOnStore";
import { rs, space, useResponsive } from "@/src/theme";
import { ReactNode, useState } from "react";
import { ScrollView, StyleSheet, View } from "react-native";

export type Nudge = {
  _id: string;
  message: string;
  tones: string[];
  isSaved?: boolean;
  status?: "delivered" | "pending" | "failed";
};

type MessageListProps = {
  data: Nudge[];
  onChange?: () => void;
  emptyIcon: ReactNode;
  emptyText: string;
  /** History cards show a timestamp instead of actions. */
  isHistory?: boolean;
  /** Force the saved state (Saved tab); otherwise read from each item. */
  forceSaved?: boolean;
};

/**
 * Scrollable list of message cards with one card expanded at a time.
 * Shared by the Nudges, Saved and History tabs, which were three copies.
 */
const MessageList = ({
  data,
  onChange,
  emptyIcon,
  emptyText,
  isHistory,
  forceSaved,
}: MessageListProps) => {
  const [isOpen, setIsOpen] = useState<number | null>(0);
  const { handleScroll } = useHideTabBarOnScroll();
  // Room for the floating tab bar on this device.
  const bottomSpace = useTabBarClearance();
  const { isSm } = useResponsive();

  if (!data?.length) {
    return (
      <View style={styles.fill}>
        <Empty icon={emptyIcon} description={emptyText} />
      </View>
    );
  }

  return (
    <View style={styles.fill}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomSpace }]}
        onScroll={handleScroll}
      >
        <View
          style={[
            styles.list,
            { paddingHorizontal: rs(isSm, space[4], space[6]) },
          ]}
        >
          {data.map((nudge, index) => (
            <MessageCard
              key={nudge._id ?? index}
              id={nudge._id}
              message={nudge.message}
              tones={nudge.tones}
              onPress={() => setIsOpen(index === isOpen ? null : index)}
              isOpen={isOpen === index}
              isHistory={isHistory}
              isSaved={isHistory ? undefined : forceSaved || nudge.isSaved}
              onChange={onChange}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1, gap: space[6] },
  list: { gap: space[4] },
});

export default MessageList;
