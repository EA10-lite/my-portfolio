import { AppText, Button, Submit, Textbox, ToneItem } from "@/src/components";
import { PRIMARY, WHITE_80, rs, space, useResponsive } from "@/src/theme";
import { newMessageValidationSchema } from "@/src/utils/validations";
import { useToastStore } from "@/src/stores/toastStore";
import { TONES } from "@/src/constants/data";
import { Formik } from "formik";
import { useRef, useState } from "react";
import { StyleSheet, View } from "react-native";

export type NoteFormValues = { message: string; tones: string[] };
export type SubmitMode = "copy" | "save";

type NoteFormProps = {
  initialValues: NoteFormValues;
  placeholder?: string;
  /** Resolve when done; throw (or show a toast) on failure. */
  onSubmit: (values: NoteFormValues, mode: SubmitMode) => Promise<void>;
};

const MAX_TONES = 2;

/**
 * Message + tone picker with "Save & Copy" and "Save only".
 * Shared by New Love Note and Edit, which were two copies of the same form.
 */
const NoteForm = ({ initialValues, placeholder, onSubmit }: NoteFormProps) => {
  const { isSm } = useResponsive();
  const { showToast } = useToastStore();
  // The mode used to be a hidden Formik field set right before submitForm(),
  // which could submit with the previous value. A ref is read synchronously.
  const modeRef = useRef<SubmitMode>("copy");
  const [savingOnly, setSavingOnly] = useState(false);

  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => onSubmit(values, modeRef.current)}
      validationSchema={newMessageValidationSchema}
      enableReinitialize={false}
    >
      {({ values, setFieldValue, submitForm, isSubmitting }) => {
        const toggleTone = (value: string) => {
          if (values.tones.includes(value)) {
            setFieldValue(
              "tones",
              values.tones.filter((t) => t !== value),
            );
            return;
          }
          if (values.tones.length >= MAX_TONES) {
            showToast("You can only select up to 2 tones", "error");
            return;
          }
          setFieldValue("tones", [...values.tones, value]);
        };

        return (
          <>
            <AppText
              size="sm"
              color={WHITE_80}
              style={{ marginBottom: rs(isSm, space[6], space[8]) }}
            >
              Write something sweet for your partner
            </AppText>

            <Textbox
              name="message"
              placeholder={placeholder ?? "Enter your message here..."}
              info="This note will be saved so you can reuse it anytime."
              hasBg
            />

            <View style={{ marginVertical: rs(isSm, space[8], space[12]) }}>
              <AppText size="sm" color={PRIMARY} style={styles.tagTitle}>
                Tag this note
              </AppText>
              <View
                style={styles.tones}
                accessibilityLabel="Tones, choose up to 2"
              >
                {TONES.map((tone) => (
                  <ToneItem
                    key={tone.value}
                    tone={tone.name}
                    isSelected={values.tones.includes(tone.value)}
                    onPress={() => toggleTone(tone.value)}
                  />
                ))}
              </View>
            </View>

            <View style={styles.actions}>
              <Submit
                title="Save & Copy"
                loading={isSubmitting && !savingOnly}
                disable={savingOnly}
              />
              <Button
                title="Save only"
                variant="outline-secondary"
                size="lg"
                loading={savingOnly}
                disabled={isSubmitting}
                onPress={async () => {
                  modeRef.current = "save";
                  setSavingOnly(true);
                  try {
                    await submitForm();
                  } finally {
                    modeRef.current = "copy";
                    setSavingOnly(false);
                  }
                }}
              />
            </View>
          </>
        );
      }}
    </Formik>
  );
};

const styles = StyleSheet.create({
  tagTitle: { marginBottom: space[4] },
  // `flex-row flex-wrap gap-y-4 gap-x-2`
  tones: {
    flexDirection: "row",
    flexWrap: "wrap",
    rowGap: space[4],
    columnGap: space[2],
  },
  actions: { gap: space[4] },
});

export default NoteForm;
