import { Header } from "@/src/components";
import { MainLayout } from "@/src/layouts";
import { rs, space, useResponsive } from "@/src/theme";
import { ReactNode } from "react";
import { ScrollView, StyleSheet, View } from "react-native";

/** Page frame for the new / edit note screens. */
const NoteScreen = ({
  title,
  rightAction,
  children,
}: {
  title: string;
  rightAction?: ReactNode;
  children: ReactNode;
}) => {
  const { isSm } = useResponsive();
  return (
    <MainLayout>
      <Header title={title} rightAction={rightAction} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scroll}
      >
        <View style={[styles.fill, { padding: rs(isSm, space[4], space[6]) }]}>
          {children}
        </View>
      </ScrollView>
    </MainLayout>
  );
};

const styles = StyleSheet.create({
  fill: { flex: 1 },
  scroll: { flexGrow: 1, paddingBottom: space[16] },
});

export default NoteScreen;
