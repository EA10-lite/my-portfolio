import { useTabBarMetrics } from "@/src/components/tabBarMetrics";
import HistoryIcon from "@/assets/icons/file-primary.svg";
import {
  Button,
  Empty,
  FilterModal,
  MessageCardSkeleton,
  ReusableTab,
  TabScreenHeader,
} from "@/src/components";
import { MainLayout } from "@/src/layouts/index";
import ping from "@/src/services/ping";
import { useFilterStore, useNavigationStore } from "@/src/stores";
import { PRIMARY, SECONDARY, rs, space, useResponsive } from "@/src/theme";
import { AntDesign } from "@expo/vector-icons";
import { BottomSheetModal } from "@gorhom/bottom-sheet";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useMemo, useRef } from "react";
import { StyleSheet, TouchableOpacity, View } from "react-native";
import useSWR from "swr";
import type { Nudge } from "./components/MessageList";
import History from "./tabs/History";
import Nudges from "./tabs/Nudges";
import Saved from "./tabs/Saved";

export default function MessagesScreen() {
  const filterRef = useRef<BottomSheetModal>(null);
  const openFilterModal = () => filterRef.current?.present();
  const closeFilterModal = () => filterRef.current?.dismiss();
  const { messagesActiveTab, setMessagesActiveTab } = useNavigationStore();
  const { selectedTones } = useFilterStore();
  const { isSm } = useResponsive();
  // The + button floats 16px above the tab bar (was a fixed 120px, which
  // overlapped the bar on Android phones with 3-button navigation).
  const { space: tabBarSpace } = useTabBarMetrics();

  const { data, isLoading, error, mutate } = useSWR(
    "/ping/all",
    ping.getAllPing,
    {
      revalidateOnFocus: false,
      dedupingInterval: 30000,
      keepPreviousData: true,
    },
  );

  const handleChange = () => {
    mutate();
  };

  useFocusEffect(
    useCallback(() => {
      mutate(undefined, { revalidate: true });
    }, [mutate]),
  );

  const filteredData = useMemo(() => {
    const nudges: Nudge[] = data?.data ?? [];
    const wanted = selectedTones.map((t) => t.toLowerCase());
    if (wanted.length === 0) return nudges;
    return nudges.filter((nudge) =>
      nudge.tones?.some((tone) => wanted.includes(tone.toLowerCase())),
    );
  }, [data?.data, selectedTones]);

  const tabs = [
    {
      id: "nudges",
      label: "Nudges",
      content: <Nudges data={filteredData} onChange={handleChange} />,
    },
    {
      id: "saved",
      label: "Saved",
      content: (
        <Saved
          data={filteredData.filter((nudge) => nudge.isSaved)}
          onChange={handleChange}
        />
      ),
    },
    {
      id: "history",
      label: "History",
      content: (
        <History
          data={filteredData.filter((nudge) => nudge.status === "delivered")}
          onChange={handleChange}
        />
      ),
    },
  ];

  const fabSize = rs(isSm, space[12], space[14]);

  return (
    <MainLayout showBottomPadding={false}>
      <TabScreenHeader
        title="Messages"
        onSearch={() => router.push("/search")}
        onFilter={openFilterModal}
        activeFilters={selectedTones.length}
      />

      {error && !data ? (
        // Was a bare red "Error" with no header and no way out.
        <View style={styles.fill}>
          <Empty
            icon={<HistoryIcon width={24} height={24} />}
            description="We couldn't load your messages"
          />
          <View style={[styles.retry, { paddingBottom: tabBarSpace }]}>
            <Button
              title="Try again"
              variant="outline-secondary"
              onPress={() => mutate()}
            />
          </View>
        </View>
      ) : isLoading && !data ? (
        <View style={styles.fill}>
          <MessageCardSkeleton />
        </View>
      ) : (
        <View style={styles.fill}>
          <ReusableTab
            tabs={tabs}
            activeTab={messagesActiveTab}
            onTabChange={(tab) =>
              setMessagesActiveTab(tab as "nudges" | "saved" | "history")
            }
          />

          <View style={[styles.fabWrap, { bottom: tabBarSpace + space[4] }]}>
            <TouchableOpacity
              style={[
                styles.fab,
                { width: fabSize, height: fabSize, borderRadius: fabSize / 2 },
              ]}
              onPress={() => router.push("/messages/new")}
              accessibilityRole="button"
              accessibilityLabel="New message"
            >
              <AntDesign name="plus" size={24} color={SECONDARY} />
            </TouchableOpacity>
          </View>
        </View>
      )}

      <FilterModal ref={filterRef} onClose={closeFilterModal} type="message" />
    </MainLayout>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  retry: { alignItems: "center" },
  // `absolute bottom-[120px] right-4 z-50`
  fabWrap: { position: "absolute", right: space[4], zIndex: 50 },
  fab: {
    backgroundColor: PRIMARY,
    alignItems: "center",
    justifyContent: "center",
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
});
