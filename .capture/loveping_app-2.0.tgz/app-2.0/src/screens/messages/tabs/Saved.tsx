import SaveIcon from "@/assets/icons/save.svg";
import MessageList, { Nudge } from "../components/MessageList";

const Saved = ({
  data,
  onChange,
}: {
  data: Nudge[];
  onChange?: () => void;
}) => (
  <MessageList
    data={data?.filter((nudge) => nudge.isSaved)}
    onChange={onChange}
    forceSaved
    emptyIcon={<SaveIcon width={24} height={24} />}
    emptyText="Your saved items are empty"
  />
);

export default Saved;
