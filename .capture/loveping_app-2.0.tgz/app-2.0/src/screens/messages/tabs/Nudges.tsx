import HistoryIcon from "@/assets/icons/file-primary.svg";
import MessageList, { Nudge } from "../components/MessageList";

const Nudges = ({
  data,
  onChange,
}: {
  data: Nudge[];
  onChange: () => void;
}) => (
  <MessageList
    data={data}
    onChange={onChange}
    emptyIcon={<HistoryIcon width={24} height={24} />}
    emptyText="Your nudges are empty"
  />
);

export default Nudges;
