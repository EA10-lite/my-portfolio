import HistoryIcon from "@/assets/icons/file-primary.svg";
import MessageList, { Nudge } from "../components/MessageList";

const History = ({
  data,
  onChange,
}: {
  data: Nudge[];
  onChange: () => void;
}) => (
  <MessageList
    data={data}
    onChange={onChange}
    isHistory
    emptyIcon={<HistoryIcon width={24} height={24} />}
    emptyText="Your history is empty"
  />
);

export default History;
