import { useNudgeStore } from "@/src/stores/nudgeStore";
import * as Notifications from "expo-notifications";
import { useEffect, useRef } from "react";
import { Platform } from "react-native";

// Configure how notifications should be handled when the app is in the foreground
// Note: You may see a warning about remote push notifications not working in Expo Go,
// but local scheduled notifications (which we're using) still work fine.
try {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
} catch (error) {
  // Silently handle if notification handler setup fails (e.g., in some environments)
  console.debug("Notification handler setup skipped:", error);
}

// const ensureAndroidChannelAsync = async () => {
//   if (Platform.OS !== "android") {
//     return;
//   }

//   await Notifications.setNotificationChannelAsync("default", {
//     name: "Default",
//     importance: Notifications.AndroidImportance.MAX,
//   });
// };

interface PushNotificationProviderProps {
  children: React.ReactNode;
}

// Map day names to weekday numbers for WeeklyTriggerInput (1 = Sunday, 2 = Monday, ..., 7 = Saturday)
// Note: WeeklyTriggerInput uses 1-7 (1 = Sunday), different from JavaScript Date (0 = Sunday)
const dayNameToWeekday: Record<string, number> = {
  sunday: 1,
  monday: 2,
  tuesday: 3,
  wednesday: 4,
  thursday: 5,
  friday: 6,
  saturday: 7,
};

// Generate random time between 8 AM (8) and 4 PM (16)
const getRandomTime = (): { hour: number; minute: number } => {
  const hour = Math.floor(Math.random() * 9) + 8; // 8-16 (8 AM to 4 PM)
  const minute = Math.floor(Math.random() * 60); // 0-59
  return { hour, minute };
};

export default function PushNotificationProvider({
  children,
}: PushNotificationProviderProps) {
  const notificationListener = useRef<Notifications.Subscription | undefined>(
    undefined,
  );
  const responseListener = useRef<Notifications.Subscription | undefined>(
    undefined,
  );
  const { nudge } = useNudgeStore();

  useEffect(() => {
    // Request notification permissions and schedule notifications based on nudge settings
    const requestPermissions = async () => {
      try {
        // await ensureAndroidChannelAsync();
        const permissions = await Notifications.getPermissionsAsync();
        let finalStatus = permissions.status;

        if (permissions.status !== "granted") {
          const requestResult = await Notifications.requestPermissionsAsync();
          finalStatus = requestResult.status;
        }

        if (finalStatus !== "granted") {
          console.warn(
            "Failed to get notification permissions. Notifications will not be scheduled.",
          );
          return;
        }

        // 👉 ADD THIS BLOCK
        try {
          const tokenResponse = await Notifications.getExpoPushTokenAsync();
          const token = tokenResponse.data;

          console.log("📱 Expo Push Token:", token);
        } catch (error) {
          console.warn("Failed to get Expo push token:", error);
        }

        // Configure notification channel for Android
        if (Platform.OS === "android") {
          try {
            await Notifications.setNotificationChannelAsync("default", {
              name: "Default",
              importance: Notifications.AndroidImportance.MAX,
              vibrationPattern: [0, 250, 250, 250],
              lightColor: "#FF231F7C",
            });
          } catch (error) {
            console.warn("Failed to set notification channel:", error);
          }
        }

        // Cancel all existing notifications to avoid duplicates
        try {
          await Notifications.cancelAllScheduledNotificationsAsync();
          console.log("✅ Cleared existing notifications");
        } catch (error) {
          console.warn("Failed to cancel existing notifications:", error);
        }

        // Schedule an initial test notification to verify notifications are working
        try {
          await Notifications.scheduleNotificationAsync({
            content: {
              title: "Loveping Notifications Active",
              body: "Push notifications are working! You'll receive reminders based on your nudge settings. 🔔",
              sound: true,
              priority: Notifications.AndroidNotificationPriority.HIGH,
            },
            trigger: {
              type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
              seconds: 5, // Fire after 5 seconds
            },
          });
          console.log(
            "✅ Initial test notification scheduled (will fire in 5 seconds)",
          );
        } catch (error) {
          console.warn("Failed to schedule initial test notification:", error);
        }

        // Schedule notifications based on nudge settings
        if (nudge && nudge.days && nudge.days.length > 0) {
          const { repeat, days } = nudge;
          const { hour, minute } = getRandomTime();

          console.log(
            `📅 Scheduling notifications for days: ${days.join(", ")}, repeat: ${repeat}, time: ${hour}:${minute.toString().padStart(2, "0")}`,
          );

          if (repeat === "once_a_week") {
            // For once_a_week: schedule one notification for the first day only
            const day = days[0];
            const weekday = dayNameToWeekday[day.toLowerCase()];

            if (weekday !== undefined) {
              try {
                const notificationId =
                  await Notifications.scheduleNotificationAsync({
                    content: {
                      title: "Loveping Reminder",
                      body: "Time to check your messages! 💕",
                      sound: true,
                      priority: Notifications.AndroidNotificationPriority.HIGH,
                    },
                    trigger: {
                      type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
                      weekday,
                      hour,
                      minute,
                    },
                  });
                console.log(
                  `✅ Scheduled weekly notification for ${day} at ${hour}:${minute.toString().padStart(2, "0")}. ID: ${notificationId}`,
                );
              } catch (error) {
                console.warn(
                  `Failed to schedule notification for ${day}:`,
                  error,
                );
              }
            } else {
              console.warn(`Invalid day name: ${day}`);
            }
          } else if (repeat === "repeat") {
            // For repeat: schedule separate weekly notifications for each day
            for (const day of days) {
              const weekday = dayNameToWeekday[day.toLowerCase()];

              if (weekday !== undefined) {
                // Generate a random time for each day
                const dayTime = getRandomTime();

                try {
                  const notificationId =
                    await Notifications.scheduleNotificationAsync({
                      content: {
                        title: "Loveping Reminder",
                        body: "Time to check your messages! 💕",
                        sound: true,
                        priority:
                          Notifications.AndroidNotificationPriority.HIGH,
                      },
                      trigger: {
                        type: Notifications.SchedulableTriggerInputTypes.WEEKLY,
                        weekday,
                        hour: dayTime.hour,
                        minute: dayTime.minute,
                      },
                    });
                  console.log(
                    `✅ Scheduled weekly notification for ${day} at ${dayTime.hour}:${dayTime.minute.toString().padStart(2, "0")}. ID: ${notificationId}`,
                  );
                } catch (error) {
                  console.warn(
                    `Failed to schedule notification for ${day}:`,
                    error,
                  );
                }
              } else {
                console.warn(`Invalid day name: ${day}`);
              }
            }
          }

          // Get all scheduled notifications to verify
          try {
            const allNotifications =
              await Notifications.getAllScheduledNotificationsAsync();
            console.log(`\n📋 ===== NOTIFICATION SCHEDULE SUMMARY =====`);
            console.log(
              `Total scheduled notifications: ${allNotifications.length}`,
            );
            if (allNotifications.length > 0) {
              allNotifications.forEach((notif, index) => {
                const trigger = notif.trigger as any;
                const weekdayNames = [
                  "",
                  "Sunday",
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                  "Saturday",
                ];
                const weekday = trigger.weekday
                  ? weekdayNames[trigger.weekday]
                  : "N/A";
                const time =
                  trigger.hour !== undefined && trigger.minute !== undefined
                    ? `${trigger.hour}:${trigger.minute.toString().padStart(2, "0")}`
                    : "N/A";
                console.log(`  ${index + 1}. ID: ${notif.identifier}`);
                console.log(`     Day: ${weekday} | Time: ${time}`);
                console.log(`     Trigger:`, trigger);
              });
              console.log(`==========================================\n`);
            } else {
              console.log(
                `⚠️  No notifications were scheduled. Check nudge settings.\n`,
              );
            }
          } catch (error) {
            console.warn("Failed to get scheduled notifications:", error);
          }
        } else {
          console.log(
            "ℹ️ No nudge settings found. Notifications not scheduled.",
          );
        }
      } catch (error) {
        console.warn("Error setting up notifications:", error);
      }
    };

    // Handle notifications received while app is foregrounded
    try {
      notificationListener.current =
        Notifications.addNotificationReceivedListener((notification) => {
          console.log("🔔 Notification received:", {
            title: notification.request.content.title,
            body: notification.request.content.body,
            trigger: notification.request.trigger,
          });
        });
      console.log("✅ Notification received listener added");
    } catch (error) {
      console.warn("Failed to add notification received listener:", error);
    }

    // Handle user interaction with notifications
    try {
      responseListener.current =
        Notifications.addNotificationResponseReceivedListener((response) => {
          console.log("👆 User interacted with notification:", {
            title: response.notification.request.content.title,
            body: response.notification.request.content.body,
            actionIdentifier: response.actionIdentifier,
          });
        });
      console.log("✅ Notification response listener added");
    } catch (error) {
      console.warn("Failed to add notification response listener:", error);
    }

    requestPermissions();

    return () => {
      if (notificationListener.current) {
        notificationListener.current.remove();
      }
      if (responseListener.current) {
        responseListener.current.remove();
      }
    };
  }, [nudge]); // Re-run when nudge settings change

  return <>{children}</>;
}
