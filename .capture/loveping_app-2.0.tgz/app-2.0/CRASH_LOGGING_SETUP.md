# Crash Logging Setup Guide

This app uses **Sentry** for crash reporting and error tracking. All crashes and errors are automatically logged and sent to Sentry for investigation.

## Setup Instructions

### 1. Create a Sentry Account and Project

1. Go to [https://sentry.io](https://sentry.io) and create an account (or sign in)
2. Create a new project:
   - Select **React Native** as the platform
   - Give it a name (e.g., "Loveping Mobile")
   - Copy the **DSN** (Data Source Name) - you'll need this in the next step

### 2. Configure Sentry DSN

Add your Sentry DSN to your environment variables:

**Option A: Using .env file (Recommended for development)**
Create a `.env` file in the root directory:

```env
EXPO_PUBLIC_SENTRY_DSN=your-sentry-dsn-here
```

**Option B: Using app.config.js (For production builds)**
The DSN can also be set directly in `app.config.js` under `extra.sentryDsn`.

### 3. Rebuild the App

After setting up the DSN, rebuild your app:

```bash
npm run build:android
```

## How It Works

### Automatic Crash Logging

The following are automatically logged:

- ✅ JavaScript errors and exceptions
- ✅ React component errors (via ErrorBoundary)
- ✅ Unhandled promise rejections
- ✅ Native crashes (Android/iOS)

### Error Boundary

The app is wrapped with an `ErrorBoundary` component that:

- Catches React component errors
- Displays a user-friendly error screen
- Logs the error to Sentry
- Allows users to try again

### Manual Logging

You can manually log errors, warnings, or info messages:

```typescript
import { logError, logWarning, logInfo, setUser, addBreadcrumb } from '@/src/services/crashLogger';

// Log an error
try {
  // some code
} catch (error) {
  logError(error, { 
    action: 'user_login',
    userId: '123' 
  });
}

// Log a warning
logWarning('API response was slower than expected', {
  endpoint: '/api/users',
  responseTime: 2000
});

// Log info (for debugging)
logInfo('User navigated to profile screen', {
  screen: 'profile',
  timestamp: Date.now()
});

// Set user information (helps identify which users experience crashes)
setUser({
  id: '123',
  email: 'user@example.com',
  username: 'johndoe'
});

// Add breadcrumb (track user actions leading to a crash)
addBreadcrumb('User clicked login button', 'user_action', 'info');
```

## Viewing Crash Reports

1. Go to your Sentry dashboard: [https://sentry.io](https://sentry.io)
2. Select your project
3. Navigate to **Issues** to see all crashes and errors
4. Click on any issue to see:
   - Stack trace
   - User information
   - Device information
   - Breadcrumbs (user actions before the crash)
   - Environment (development/production)

## Best Practices

1. **Set user information after login:**

   ```typescript
   import { setUser } from '@/src/services/crashLogger';
   
   // After successful login
   setUser({
     id: user.id,
     email: user.email_address,
     username: user.username
   });
   ```

2. **Clear user information on logout:**

   ```typescript
   import { clearUser } from '@/src/services/crashLogger';
   
   // On logout
   clearUser();
   ```

3. **Add context to errors:**

   ```typescript
   logError(error, {
     screen: 'MessagesScreen',
     action: 'save_message',
     messageId: message.id
   });
   ```

4. **Use breadcrumbs to track user flow:**

   ```typescript
   // Track navigation
   addBreadcrumb('Navigated to messages', 'navigation', 'info');
   
   // Track user actions
   addBreadcrumb('User saved a message', 'user_action', 'info', {
     messageId: '123'
   });
   ```

## Troubleshooting

### Crashes not appearing in Sentry?

1. **Check DSN configuration:**
   - Verify `EXPO_PUBLIC_SENTRY_DSN` is set correctly
   - Rebuild the app after setting the DSN

2. **Check network connectivity:**
   - Sentry requires internet connection to send reports
   - Reports are queued and sent when connection is available

3. **Check Sentry dashboard:**
   - Make sure you're looking at the correct project
   - Check if there are any rate limits or quota issues

### Error Boundary not catching errors?

- Error Boundaries only catch errors in:
  - Component rendering
  - Lifecycle methods
  - Constructors
  
- They do NOT catch errors in:
  - Event handlers (use try-catch)
  - Async code (use try-catch)
  - Server-side rendering
  - Errors thrown in the error boundary itself

## Additional Resources

- [Sentry React Native Documentation](https://docs.sentry.io/platforms/react-native/)
- [Sentry Dashboard](https://sentry.io)
