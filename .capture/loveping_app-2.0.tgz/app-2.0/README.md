# LovePing Mobile App

A React Native mobile application built with Expo and React Native.

## Overview

LovePing is a mobile application that helps users connect and communicate with their partners through messages, gifts, and nudges. The app is built using Expo SDK 54, React Native, and styles every screen with `StyleSheet.create()` and the shared tokens in `src/theme`.

## Tech Stack

- **Framework**: Expo ~54.0.20
- **React Native**: 0.81.5
- **React**: 19.1.0
- **Routing**: Expo Router ~6.0.13
- **Styling**: React Native `StyleSheet` + design tokens in `src/theme` (colors, spacing, radii, typography, touch targets)
- **State Management**: Zustand 5.0.8
- **Data Fetching**: TanStack React Query 5.90.7, SWR 2.3.6
- **Forms**: Formik 2.4.6, Yup 1.7.1
- **Notifications**: @notifee/react-native 9.1.8

## Prerequisites

- Node.js (v18 or higher recommended)
- npm or yarn
- Expo CLI (installed globally or via npx)
- Expo account (free account works for building)

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Environment Variables

Create a `.env` file in the root directory with your API configuration:

```env
BASE_API=your_api_url_here
```

### 3. Start Development Server

```bash
npm start
# or
npx expo start
```

In the output, you'll find options to open the app in:

- [Development build](https://docs.expo.dev/develop/development-builds/introduction/)
- [Android emulator](https://docs.expo.dev/workflow/android-studio-emulator/)
- [iOS simulator](https://docs.expo.dev/workflow/ios-simulator/)
- [Expo Go](https://expo.dev/go) (limited sandbox)

### 4. Run on Specific Platform

```bash
# Android
npm run android

# iOS
npm run ios

# Web
npm run web
```

## Building and Publishing Android APK

### Prerequisites for Building

1. **Install EAS CLI** (Expo Application Services)

   ```bash
   npm install -g eas-cli
   ```

2. **Login to Expo Account**

   ```bash
   eas login
   ```

   If you don't have an account, create one at [expo.dev](https://expo.dev) or run:

   ```bash
   eas register
   ```

3. **Configure EAS Build** (Already done - `eas.json` is configured)

   The project includes an `eas.json` configuration file with three build profiles:
   - **development**: For development builds with development client
   - **preview**: For testing APK builds (internal distribution)
   - **production**: For production APK builds

### Building the APK

#### Option 1: Build Preview APK (Recommended for Testing)

This creates an APK that you can download and install directly:

```bash
npm run build:android
# or
eas build --platform android --profile preview
```

#### Option 2: Build Production APK

For production-ready builds:

```bash
npm run build:android:prod
# or
eas build --platform android --profile production
```

#### Option 3: Interactive Build

For more control over the build process:

```bash
eas build --platform android
```

This will prompt you to:
- Choose a build profile (development, preview, or production)
- Select build type (APK or AAB)
- Configure other build options

### Build Process

1. **Start the Build**: Run one of the build commands above
2. **Wait for Build**: The build will be queued and processed on Expo's servers
   - You'll see a build URL in the terminal
   - Builds typically take 10-20 minutes
3. **Monitor Progress**: 
   - Check status in terminal
   - Or visit [expo.dev/builds](https://expo.dev/builds) to see your builds
4. **Download APK**: 
   - Once complete, you'll get a download link
   - Click the link or run: `eas build:list` to see all builds
   - Download the APK file directly

### Downloading Your APK

After the build completes, you can:

1. **From Terminal**: The build command will provide a download URL
2. **From Expo Dashboard**: 
   - Visit [expo.dev/builds](https://expo.dev/builds)
   - Find your build and click "Download"
3. **Using EAS CLI**:
   ```bash
   eas build:list
   ```
   This shows all your builds with download links

### Installing the APK

1. Transfer the APK file to your Android device
2. Enable "Install from Unknown Sources" in your device settings
3. Open the APK file and follow the installation prompts

### Build Configuration

The build configuration is in `eas.json`:

- **Preview Profile**: Builds APK for internal testing
- **Production Profile**: Builds APK for production release
- **Development Profile**: Builds with development client enabled

You can customize these profiles in `eas.json` if needed.

## Project Structure

```
loveping/
├── app/                    # Expo Router pages (file-based routing)
│   ├── (tabs)/            # Tab navigation screens
│   ├── auth/              # Authentication screens
│   ├── messages/          # Message-related screens
│   ├── nudge/             # Nudge feature screens
│   └── profile/           # Profile and settings screens
├── assets/                 # Images, icons, fonts
├── src/
│   ├── components/        # Reusable UI components
│   ├── screens/           # Screen components
│   ├── services/          # API services
│   ├── stores/            # Zustand state management
│   ├── utils/             # Utility functions
│   └── config/            # Configuration files
├── app.json               # Expo configuration
├── app.config.js          # Dynamic Expo config (with env vars)
├── eas.json               # EAS Build configuration
└── package.json          # Dependencies and scripts
```

## Available Scripts

- `npm start` - Start Expo development server
- `npm run android` - Start Expo and open on Android
- `npm run ios` - Start Expo and open on iOS
- `npm run web` - Start Expo and open in web browser
- `npm run lint` - Run ESLint
- `npm run build:android` - Build preview APK for Android
- `npm run build:android:prod` - Build production APK for Android

## Testing

Run the linter:

```bash
npm run lint
```

## Known Limitations

- The app requires an Expo account to build APKs using EAS Build
- Free Expo accounts have build limits (check [expo.dev/pricing](https://expo.dev/pricing))
- Environment variables must be set in `.env` file for API connections

## Additional Resources

- [Expo Documentation](https://docs.expo.dev/)
- [EAS Build Documentation](https://docs.expo.dev/build/introduction/)
- [React Native Documentation](https://reactnative.dev/)
- [Expo Router Documentation](https://docs.expo.dev/router/introduction/)

## Support

For issues or questions:
- Check [Expo Discord](https://chat.expo.dev)
- Visit [Expo GitHub](https://github.com/expo/expo)
