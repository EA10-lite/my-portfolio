// app.config.js
// .env is loaded automatically by the Expo CLI (no dotenv import needed).

// NOTE: this file exports a plain object, so Expo ignores app.json entirely.
export default {
  expo: {
    name: "Loveping",
    slug: "loveping",
    version: "1.0.1",
    orientation: "portrait",
    icon: "./assets/app-icon/icon.png",
    scheme: "loveping",
    userInterfaceStyle: "automatic",
    newArchEnabled: true,
    ios: {
      bundleIdentifier: "com.loveping.app",
      supportsTablet: true,
      icon: {
        light: "./assets/app-icon/icon.png",
        dark: "./assets/app-icon/ios-dark.png",
        tinted: "./assets/app-icon/ios-tinted.png",
      },
    },
    android: {
      package: "com.loveping.app",
      adaptiveIcon: {
        backgroundColor: "#02231A",
        foregroundImage: "./assets/app-icon/adaptive-foreground.png",
        monochromeImage: "./assets/app-icon/adaptive-monochrome.png",
      },
      edgeToEdgeEnabled: true,
      predictiveBackGestureEnabled: false,
      permissions: [
        "android.permission.POST_NOTIFICATIONS",
        "android.permission.VIBRATE",
      ],
      // Remote push on Android needs Firebase. Add google-services.json from
      // your Firebase project, then uncomment:
      // googleServicesFile: "./google-services.json",
    },
    web: {
      output: "static",
      favicon: "./assets/app-icon/favicon.png",
    },
    plugins: [
      "expo-router",
      [
        "expo-splash-screen",
        {
          // Native splash: logo mark on the brand background. It stays up
          // until app/index.tsx has decided where to route (no fixed delay).
          image: "./assets/splash/splash-logo.png",
          imageWidth: 150,
          resizeMode: "contain",
          backgroundColor: "#02231A",
          dark: {
            image: "./assets/splash/splash-logo.png",
            backgroundColor: "#02231A",
          },
        },
      ],
      [
        "expo-notifications",
        {
          // Android status-bar icon: white silhouette, tinted brand green.
          icon: "./assets/notifications/notification-icon.png",
          color: "#48D962",
          defaultChannel: "default",
        },
      ],
    ],
    experiments: {
      typedRoutes: true,
      // React Compiler is experimental and can cause build failures
      // Disabling for production builds - re-enable when stable
      // reactCompiler: true,
    },
    // Inter is loaded at runtime with useFonts in app/_layout.tsx.
    extra: {
      BASE_API: process.env.BASE_API,
      sentryDsn: process.env.EXPO_PUBLIC_SENTRY_DSN,
      // Numeric App Store id (apps.apple.com/app/id<THIS>). Used to open the
      // store from the update prompt when the backend sends no store_url.
      iosAppStoreId: process.env.EXPO_PUBLIC_IOS_APP_STORE_ID,
      eas: {
        projectId: "6eb9c9f7-33a3-4a53-8b6f-7bfb5c8bc1df",
      },
    },
  },
};
