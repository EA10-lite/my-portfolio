declare module 'expo-blur' {
  import type * as React from 'react';
    import type { ViewProps } from 'react-native';

  export type BlurTint =
    | 'default'
    | 'light'
    | 'dark'
    | 'extraLight'
    | 'prominent'
    | 'regular'
    | 'systemMaterial';

  export interface BlurViewProps extends ViewProps {
    intensity?: number; // 0 - 100
    tint?: BlurTint;
  }

  export const BlurView: React.ComponentType<BlurViewProps>;
}


